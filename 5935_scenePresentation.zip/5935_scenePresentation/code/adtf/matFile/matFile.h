// InnoDrive Hybrid Display
// MATLAB File Interface

#ifndef __MATFILE_H
#define __MATFILE_H

typedef class _matFile {

protected:
	struct _FILEHEADER {
		long type;
		long mrows;
		long ncols;
		long imagf;
		long namelen;
	} fileHeader;

	char	*name;
	double	*data;

public:
	_matFile(const char *matrixName, int columns, int rows);
	~_matFile();

	void		SetValue(int column, int row, double value);
	bool		SaveToFile(const char *fileName, bool overwriteFile);

} matFile_T;


typedef class _matFileStream {

protected:
	struct _FILEHEADER {
		long type;
		long mrows;
		long ncols;
		long imagf;
		long namelen;
	} fileHeader;

	HANDLE		hFile;
	DWORD		filePointer;
	LONG		filePointerHigh;
public:
	_matFileStream();
	~_matFileStream();

	bool		Create(const char *fileName, const char *matrixName, int rows, bool overwriteFile);
	bool		AddColumn(double values[]);
	bool		SaveAndClose();

} matFileStream_T;

#endif