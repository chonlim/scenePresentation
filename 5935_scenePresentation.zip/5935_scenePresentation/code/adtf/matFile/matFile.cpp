// InnoDrive Hybrid Display
// MATLAB File Interface
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <windows.h>
#include "matFile.h"


_matFile::_matFile(const char *matrixName, int columns, int rows)
{
	this->name = new char[strlen(matrixName)+1];
	strcpy(this->name,  matrixName);

	if(strlen(this->name) > 63) {
		this->name[64] = '\0';
	}

	this->data = new double[columns * rows];
	memset(this->data, 0, sizeof(double)* (columns * rows));

	this->fileHeader.type		= 0;
	this->fileHeader.imagf		= 0;
	this->fileHeader.ncols		= columns;
	this->fileHeader.mrows		= rows;
	this->fileHeader.namelen	= (long)strlen(this->name);
}


_matFile::~_matFile()
{
	delete this->name;
	delete this->data;
}


void _matFile::SetValue(int column, int row, double value)
{
	this->data[(column * this->fileHeader.mrows) + row] = value;
}


bool _matFile::SaveToFile(const char *fileName, bool overwriteFile)
{
	HANDLE hFile = CreateFileA(fileName, GENERIC_WRITE, 0, NULL, (overwriteFile ? CREATE_ALWAYS : OPEN_ALWAYS), FILE_ATTRIBUTE_NORMAL, NULL);
	SetFilePointer(hFile, 0, 0, FILE_END);

	if (!hFile || hFile == INVALID_HANDLE_VALUE)
		return false;

	DWORD dwWritten;
	if (!WriteFile(hFile, (LPCVOID)&this->fileHeader, sizeof(this->fileHeader), &dwWritten, NULL)) {
		CloseHandle(hFile);
		return false;
	}

	if (!WriteFile(hFile, (LPCVOID)this->name, this->fileHeader.namelen, &dwWritten, NULL)) {
		CloseHandle(hFile);
		return false;
	}

	if (!WriteFile(hFile, (LPCVOID)this->data, this->fileHeader.ncols * this->fileHeader.mrows * sizeof(double), &dwWritten, NULL)) {
		CloseHandle(hFile);
		return false;
	}

	CloseHandle(hFile);
	return true;
}


_matFileStream::_matFileStream()
{
	memset(&this->fileHeader, 0, sizeof(this->fileHeader));
	this->hFile				= NULL;
	this->filePointer		= NULL;
	this->filePointerHigh	= NULL;
}


_matFileStream::~_matFileStream()
{
	if (this->hFile) {
		this->SaveAndClose();
	}
}


bool _matFileStream::Create(const char *fileName, const char *matrixName, int rows, bool overwriteFile)
{

	if (hFile){
		/* last matrix has not been saved yet. run SaveAndClose() first. */
		return false;
	}

	this->hFile = CreateFileA(fileName, GENERIC_WRITE, 0, NULL, (overwriteFile ? CREATE_ALWAYS : OPEN_ALWAYS), FILE_ATTRIBUTE_NORMAL, NULL);

	this->filePointer		= NULL;
	this->filePointerHigh	= NULL;
	this->filePointer = SetFilePointer(hFile, 0, &filePointerHigh, FILE_END);

	if (!hFile || hFile == INVALID_HANDLE_VALUE) {
		this->hFile = NULL;
		return false;
	}

	this->fileHeader.type		= 0;
	this->fileHeader.imagf		= 0;
	this->fileHeader.ncols		= 0;
	this->fileHeader.mrows		= rows;
	this->fileHeader.namelen	= (long)strlen(matrixName);

	DWORD dwWritten;
	if (!WriteFile(hFile, (LPCVOID)&this->fileHeader, sizeof(this->fileHeader), &dwWritten, NULL)) {
		CloseHandle(hFile);
		this->hFile = NULL;

		return false;
	}

	if (!WriteFile(hFile, (LPCVOID)matrixName, this->fileHeader.namelen, &dwWritten, NULL)) {
		CloseHandle(hFile);
		this->hFile = NULL;

		return false;
	}

	return true;
}


bool _matFileStream::AddColumn(double values[])
{
	if (!this->hFile) {
		return false;
	}

	DWORD dwWritten;
	if (!WriteFile(hFile, (LPCVOID)values, sizeof(double) * this->fileHeader.mrows, &dwWritten, NULL)) {
		return false;
	}

	this->fileHeader.ncols++;

	return true;
}


bool _matFileStream::SaveAndClose()
{
	if (!hFile)
		return false;

	SetFilePointer(hFile, this->filePointer, &filePointerHigh, FILE_BEGIN);

	DWORD dwWritten;
	if (!WriteFile(hFile, (LPCVOID)&this->fileHeader, sizeof(this->fileHeader), &dwWritten, NULL)) {
		CloseHandle(hFile);
		return false;
	}

	CloseHandle(hFile);
	this->hFile = NULL;
	this->filePointer = NULL;
	this->filePointerHigh = NULL;

	return true;
}