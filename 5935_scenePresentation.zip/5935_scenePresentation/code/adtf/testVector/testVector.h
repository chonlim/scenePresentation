#ifndef _testVector_H_
#define _testVector_H_

#include <Windows.h>
#include <stdexcept>
#include <string.h>

template<class T> class testVector_T
{
private:
	HANDLE		hFile;
	int			currentSample;
	int			sampleCount;

public:
	testVector_T(void) {
		this->hFile = NULL;
		this->currentSample = 0;
		this->sampleCount	= 0;
	}

	~testVector_T(void) {
		if (this->hFile) {
			this->Close();
		}
	};

	bool		OpenWrite(const char* fileName) {

		this->hFile = CreateFileA(fileName,
								  GENERIC_WRITE,
								  FILE_SHARE_READ,
								  NULL,
								  CREATE_ALWAYS,
								  NULL,
								  NULL);

		if (this->hFile == INVALID_HANDLE_VALUE) {
			this->hFile = NULL;
			return false;
		}

		return true;
	}

	bool		OpenRead(const char* fileName) {

		this->hFile = CreateFileA(fileName,
								  GENERIC_READ,
								  FILE_SHARE_READ,
								  NULL,
								  OPEN_EXISTING,
								  NULL,
								  NULL);

		if (this->hFile == INVALID_HANDLE_VALUE) {
			this->hFile = NULL;
			return false;
		}

		if(0 != GetFileSize(this->hFile, NULL) % sizeof(T)) {
			this->Close();
			return false;
		}

		this->sampleCount	= GetFileSize(this->hFile, NULL) / sizeof(T);
		this->currentSample	= 0;

		return true;
	}

	bool		IsFileOpen(void) {
		return this->hFile != NULL;
	}

	bool		Close(void) {
		CloseHandle(this->hFile);

		this->hFile = NULL;
		this->sampleCount = 0;

		return true;
	};

	bool		ReadSample(T*	sample) {
		DWORD dwRead;

		memset(sample, 0, sizeof(*sample));

		if(!ReadFile( this->hFile,
					  sample, 
					  sizeof(*sample),
					 &dwRead,
					  NULL)) { return false; }

		if(dwRead != sizeof(*sample)) { return false; }

		this->currentSample++;

		return true;
	}

	bool		WriteSample(const T* sample) {
		DWORD dwWritten;

		if(!WriteFile( this->hFile,
					   sample, 
					   sizeof(*sample),
					  &dwWritten,
					   NULL)) { return false; }

		if(dwWritten != sizeof(*sample)) { return false; }

		return true;
	}

	bool		Reset(void) {
		if (INVALID_SET_FILE_POINTER == SetFilePointer(this->hFile, 0, NULL, FILE_BEGIN)) {
			return false;
		}

		this->currentSample = 0;

		return true;
	}

	int			GetCurrentSample(void) {
		return this->currentSample;
	}

	int			GetSampleCount(void) {
		return this->sampleCount;
	}

	bool		SeekToSample(int sample) {
		if (!this->hFile) {
			return false;
		}

		if (sample >= this->sampleCount) {
			return false;
		}

		if (!SetFilePointer(this->hFile, sizeof(T) * sample, NULL, FILE_BEGIN)) {
			return false;
		}

		this->currentSample = sample;

		return true;
	}

};


typedef class _bufferedTestVector
{
private:
	void		*vector;
	int			 currentSample;
	int			 byteCount;

public:
	_bufferedTestVector(void) {
		this->vector		= NULL;
		this->currentSample	= 0;
		this->byteCount		= 0;
	}


	~_bufferedTestVector(void) {
		this->Close();
	};


	bool		LoadFile(const wchar_t* fileName)
	{
		this->Close();

		HANDLE hFile;
		hFile =  CreateFileW(fileName,
							 GENERIC_READ,
							 FILE_SHARE_READ,
							 NULL,
							 OPEN_EXISTING,
							 NULL,
							 NULL);

		if (hFile == INVALID_HANDLE_VALUE) {
			return false;
		}

		this->byteCount = GetFileSize(hFile, NULL);
		this->currentSample	= 0;

		HANDLE hMapping;
		hMapping = CreateFileMapping(hFile,
									 NULL,
									 PAGE_READONLY,
									 0,
									 0,
									 NULL);

		if(!hMapping) {
			CloseHandle(hFile);
			return false;
		}

		this->vector = MapViewOfFile(hMapping,
									 FILE_MAP_READ,
									 0,
									 0,
									 0);

		CloseHandle(hFile);
		CloseHandle(hMapping);

		if(!this->vector) {
			this->Close();
			return false;
		}

		return true;
	}


	bool		LoadFile(const char* fileName)
	{
		this->Close();

		HANDLE hFile;
		hFile =  CreateFileA(fileName,
							 GENERIC_READ,
							 FILE_SHARE_READ,
							 NULL,
							 OPEN_EXISTING,
							 NULL,
							 NULL);

		if (hFile == INVALID_HANDLE_VALUE) {
			return false;
		}

		if (hFile == INVALID_HANDLE_VALUE) {
			return false;
		}

		this->byteCount = GetFileSize(hFile, NULL);
		this->currentSample	= 0;

		HANDLE hMapping;
		hMapping = CreateFileMapping(hFile,
									 NULL,
									 PAGE_READONLY,
									 0,
									 0,
									 NULL);

		if(!hMapping) {
			CloseHandle(hFile);
			return false;
		}

		this->vector = MapViewOfFile(hMapping,
									 FILE_MAP_READ,
									 0,
									 0,
									 0);

		CloseHandle(hFile);
		CloseHandle(hMapping);

		if(!this->vector) {
			this->Close();
			return false;
		}

		return true;
	}


	bool		Close(void) {
		if(this->vector) {
			UnmapViewOfFile(this->vector);
			this->vector = NULL;
		}

		this->currentSample	= 0;
		this->byteCount		= 0;

		return true;
	};


	template<typename T> 
	bool		ReadSample(T*	sample) 
	{
		memset(sample, 0, sizeof(T));

		if(this->currentSample >= this->byteCount / sizeof(T)) {
			return false;
		}

		*sample = ((T*)this->vector)[this->currentSample];
		this->currentSample++;

		return true;
	}


	template<typename T> 
	bool		GetSample(unsigned int index,	T*	sample) 
	{
		memset(sample, 0, sizeof(T));

		if(index >= this->byteCount / sizeof(T)) {
			return false;
		}

		T	*typeVector = (T*)this->vector;
		*sample = typeVector[index];

		return true;
	}


	bool		Reset(void) {
		this->currentSample = 0;

		return true;
	}


	int			GetCurrentSample(void) {
		return this->currentSample;
	}


	template<typename T>
	int			GetSampleCount(void) {
		return this->byteCount / sizeof(T);
	}

	template<typename T>
	bool		SeekToSample(int sample) {
		if (sample >= this->byteCount / sizeof(T)) {
			return false;
		}

		this->currentSample = sample;

		return true;
	}


	const void*	GetData(void) 
	{
		return this->vector;
	}


	size_t		GetByteCount(void)
	{
		return this->byteCount;
	}

} bufferedTestVector_T;


#endif
