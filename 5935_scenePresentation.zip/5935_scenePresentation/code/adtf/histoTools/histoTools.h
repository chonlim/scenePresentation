#ifndef __histoTools_h_
#define __histoTools_h_

#include <math.h>


template<unsigned int sizeX, unsigned int sizeY> class fixedHistoXY_T {
private:
	double		data[sizeX][sizeY];
	double		minX, maxX;
	double		minY, maxY;

public:
	fixedHistoXY_T(double minX, double maxX, double minY, double maxY) {
		this->Reset(minX, maxX, minY, maxY);
	};

	void	Reset(double minX, double maxX, double minY, double maxY)
	{
		memset(this->data, 0, sizeof(this->data));

		this->minX = minX;
		this->maxX = maxX;
		this->minY = minY;
		this->maxY = maxY;
	};

	void	Reset(void)
	{
		this->Reset(this->minX, this->maxX, this->minY, this->maxY);
	};

	bool	RegisterEvent(double x, double y, double magnitude = 1.0) {
		int		numX = sizeX;
		int		numY = sizeY;

		double	realX = (x - minX) / (maxX - minX) * double(numX);
		double	realY = (y - minY) / (maxY - minY) * double(numY);

		int indexX = (int)floor(realX);
		int indexY = (int)floor(realY);

		if ((indexX >= 0 && indexX < sizeX)
			&& (indexY >= 0 && indexY < sizeY)) {
			this->data[indexX][indexY] += magnitude;
			return true;
		}

		return false;
	};

	unsigned int	GetSizeX() {
		return sizeX;
	};

	unsigned int	GetSizeY() {
		return sizeY;
	};

	double	GetMinX(unsigned int indexX) {
		return minX + (maxX - minX) * double(indexX) / double(sizeX);
	}

	double	GetMaxX(unsigned int indexX) {
		return minX + (maxX - minX) * double(indexX+1) / double(sizeX);
	}

	double	GetMinY(unsigned int indexY) {
		return minY + (maxY - minY) * double(indexY) / double(sizeY);
	}

	double	GetMaxY(unsigned int indexY) {
		return minY + (maxY - minY) * double(indexY+1) / double(sizeY);
	}

	double	GetMaxCount() {
		double count = 0.0;

		for (unsigned int x = 0; x < sizeX; x++) {
			for (unsigned int y = 0; y < sizeY; y++) {
				count = max(count, this->data[x][y]);
			}
		}

		return count;
	}

	double	GetTotalCount() {
		double count = 0.0;

		for (unsigned int x = 0; x < sizeX; x++) {
			for (unsigned int y = 0; y < sizeY; y++) {
				count += this->data[x][y];
			}
		}

		return count;
	}

	double	GetColumnCount(unsigned int indexX) {
		if (indexX >= sizeX) {
			return 0.0;
		}

		double count = 0.0;

		for (unsigned int y = 0; y < sizeY; y++) {
			count += this->data[indexX][y];
		}

		return count;
	}

	double	GetCellCount(unsigned int indexX, unsigned int indexY) {
		if (indexX >= sizeX && indexY >= sizeY) {
			return 0.0;
		}

		return this->data[indexX][indexY];
	};
};


template<unsigned int sizeX> class fixedHisto_T {
private:
	double		data[sizeX];
	double		minX, maxX;

public:
	fixedHisto_T(double minX, double maxX) {
		this->Reset(minX, maxX);
	};

	void	Reset(double minX, double maxX)
	{
		memset(this->data, 0, sizeof(this->data));

		this->minX = minX;
		this->maxX = maxX;
	};

	void	Reset(void)
	{
		this->Reset(this->minX, this->maxX);
	};

	bool	RegisterEvent(double x, double magnitude = 1.0) {
		int		numX = sizeX;
		
		double	realX = (x - minX) / (maxX - minX) * double(numX);
		
		int indexX = (int)floor(realX);
		
		if (indexX >= 0 && indexX < sizeX) {
			this->data[indexX] += magnitude;
			return true;
		}

		return false;
	};

	unsigned int	GetSizeX() {
		return sizeX;
	};

	double	GetMinX(unsigned int indexX) {
		return minX + (maxX - minX) * double(indexX) / double(sizeX);
	}

	double	GetMaxX(unsigned int indexX) {
		return minX + (maxX - minX) * double(indexX+1) / double(sizeX);
	}

	double	GetMaxCount() {
		double count = 0.0;

		for (unsigned int x = 0; x < sizeX; x++) {
			count = max(count, this->data[x]);
		}

		return count;
	}

	double	GetTotalCount() {
		double count = 0.0;

		for (unsigned int x = 0; x < sizeX; x++) {
			count += this->data[x];
		}

		return count;
	}

	double	GetColumnCount(unsigned int indexX) {
		if (indexX >= sizeX) {
			return 0.0;
		}

		return this->data[indexX];
	}
};


#endif