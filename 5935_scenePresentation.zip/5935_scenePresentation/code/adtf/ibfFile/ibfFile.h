#ifndef _ibfFile_H_
#define _ibfFile_H_

#include <Windows.h>
#include <memory.h>

template<class T> class ibfFile_T
{
private:
	HANDLE		 hFile;
	T			*data;

public:
	ibfFile_T(void) {
		this->hFile = NULL;
		this->data	= new T;
	}


	~ibfFile_T(void) {
		if (this->hFile) {
			this->Close();
		}
		
		if(this->data) {
			delete this->data;
		}
	};


	bool		OpenWrite(const char* fileName) {

		this->hFile = CreateFileA(fileName,
								  GENERIC_WRITE,
								  FILE_SHARE_READ,
								  NULL,
								  CREATE_ALWAYS,
								  NULL,
								  NULL);

		if (this->hFile == INVALID_HANDLE_VALUE) {
			this->hFile = NULL;
			return false;
		}

		return true;
	}

	bool		OpenReadWrite(const char* fileName) {

		this->hFile = CreateFileA(fileName,
			GENERIC_WRITE | GENERIC_READ,
			FILE_SHARE_READ,
			NULL,
			OPEN_ALWAYS,
			NULL,
			NULL);

		if (this->hFile == INVALID_HANDLE_VALUE) {
			this->hFile = NULL;
			return false;
		}

		if (sizeof(T) != GetFileSize(this->hFile, NULL)) {
			this->Close();
			return false;
		}

		if (!this->ReadData()) {
			this->Close();
			return false;
		}

		return true;
	}


	bool		OpenRead(const char* fileName) {

		this->hFile = CreateFileA(fileName,
								  GENERIC_READ,
								  FILE_SHARE_READ,
								  NULL,
								  OPEN_EXISTING,
								  NULL,
								  NULL);

		if (this->hFile == INVALID_HANDLE_VALUE) {
			this->hFile = NULL;
			return false;
		}

		if (sizeof(T) != GetFileSize(this->hFile, NULL)) {
			this->Close();
			return false;
		}

		if (!this->ReadData()) {
			this->Close();
			return false;
		}

		return true;
	}


	bool		OpenReadT(const TCHAR* fileName) {

		this->hFile = CreateFile(fileName,
								 GENERIC_READ,
								 FILE_SHARE_READ,
								 NULL,
								 OPEN_EXISTING,
								 NULL,
								 NULL);

		if (this->hFile == INVALID_HANDLE_VALUE) {
			this->hFile = NULL;
			return false;
		}

		if (sizeof(T) != GetFileSize(this->hFile, NULL)) {
			this->Close();
			return false;
		}

		if (!this->ReadData()) {
			this->Close();
			return false;
		}

		return true;
	}


	bool		Close(void) {
		CloseHandle(this->hFile);
		this->hFile = NULL;

		return true;
	};


	bool		ReadData(void) {
		DWORD dwRead;

		if(!this->data) {
			return false;
		}

		memset(this->data, 0, sizeof(T));

		if(INVALID_SET_FILE_POINTER == SetFilePointer(this->hFile, 0, NULL, FILE_BEGIN)) { return false; }

		if(!ReadFile( this->hFile,
					  this->data, 
					  sizeof(T),
					 &dwRead,
					  NULL)) { return false; }

		if(dwRead != sizeof(T)) { return false; }

		return true;
	}


	bool		WriteData(void) {
		DWORD dwWritten;

		if(INVALID_SET_FILE_POINTER == SetFilePointer(this->hFile, 0, NULL, FILE_BEGIN)) { return false; }

		if(!WriteFile( this->hFile,
					   this->data, 
					   sizeof(T),
					  &dwWritten,
					   NULL)) { return false; }

		if(dwWritten != sizeof(T)) { return false; }

		return true;
	}


	T*			GetData(void) {
		return this->data;
	}


	void		SetData(T* newData) 
	{
		uint32_T uinumberOfElements = sizeof(*this->data);
		uint32_T uicount = sizeof(T);

		memcpy_s(this->data, uinumberOfElements, (void*)newData, uicount);
		return;
	}


	bool		IsFileOpen(void)
	{
		if(this->hFile == NULL) {
			return false;
		}

		return true;
	}
};

#endif