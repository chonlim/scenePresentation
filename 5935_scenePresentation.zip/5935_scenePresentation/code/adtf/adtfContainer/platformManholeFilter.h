#ifndef guard_platformManholeFilter_h
#define guard_platformManholeFilter_h


#include "baseFilter.h"

#define ADTF_FILTER_ID_platformManholeFilter		"IDII.platformManholeFilter"
#define ADTF_FILTER_NAME_platformManholeFilter		"IDII platformManholeFilter"


class platformManholeFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_platformManholeFilter, ADTF_FILTER_NAME_platformManholeFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

	static		platformManholeFilter_T*	logFilter;

public:
	platformManholeFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	void		OnShutdownNormal(void);
	
	void		OnReceive(void);

	void		OutputMessage(const char_T type, const char_T *message);

	static void	InfoLogCallback(const char_T *message);
	static void	WarningLogCallback(const char_T *message);
	static void	ErrorLogCallback(const char_T *message);
};


#endif
