#ifndef guard_groundFilter_h
#define guard_groundFilter_h


#include "inputPin.h"
#include "outputPin.h"
#include "signalInterface.h"

#include <map>
#include <string>


class groundFilter_T
  : public adtf::ISignalProvider,
	public adtf::IRunnable,
	public signalCallback_T
{
protected:
	std::map<std::string,	inputPin_T*>		inputPins;			/**< Liste der Input-Pins des Filters */
	std::map<std::string,	outputPin_T*>		outputPins;			/**< Liste der Output-Pins des Filters */
	std::map<int,			tHandle>			timers;				/**< Liste der Timer, die f�r diesen Filter angelegt sind. */

	std::map<std::string,	tSignalID>			inSignalOffset;		/**< Erste Signal-ID der Input-Pins des Filters */
	std::map<std::string,	tSignalID>			outSignalOffset;	/**< Erste Signal-ID des Output-Pins des Filters */
	ucom::cObjectPtr<ISignalRegistryExtended>	signalRegistry;		/**< Pointer auf die ADTF Signal Registry */
	cKernelMutex								signalLock;			/**< Lock f�r das Bearbeiten der Liste aktiver Signale */
	std::set<tSignalID>							activeSignals;		/**< Liste aktuell aktiver Signale */
	tSignalID									nextSignal;			/**< ID des n�chsten Signals, das registriert wird */
	std::vector<tFloat64>						signalBuffer;		/**< Letzter Ausgabewert f�r alle Signalwerte */

private:
	adtf::IKernel*								groundKernel;
	cKernelMutex								mutex;

public:
					 groundFilter_T(void);
					~groundFilter_T();


	void			Cleanup();

	virtual tResult	Init(adtf::cFilter::tInitStage eStage, IPinEventSink *pinEventSink, __exception = NULL);
	virtual tResult	Shutdown(adtf::cFilter::tInitStage eStage, __exception = NULL);

	virtual tResult	OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);
	virtual tResult	Run(tInt nActivationType, const tVoid* pvUserData, tInt szUserDataSize, __exception);

	virtual tResult	Start(__exception = NULL);
	virtual tResult	Stop(__exception = NULL);

	void			RegisterKernel(adtf::IKernel *_kernel);

	bool			AddTimer(int id, int cycleTime);
	bool			RemoveTimer(int id);
	
	void			AddInputPin(std::string name, const pinHeader_T &header);
	void			AddInputPin(std::string name, std::string type, size_t size);
	void			AddInputPin(std::string name, uint32_T majorType, uint32_T subType);
	void			AddInputPin(std::string name, uint32_T majorType, uint32_T subType, size_t size);
	void			AddInputPin(std::string name);

	inputPin_T*		GetInputPin(std::string name);

	void			AddOutputPin(std::string name, const pinHeader_T &header);
	void			AddOutputPin(std::string name, std::string type, size_t size);
	void			AddOutputPin(std::string name, uint32_T majorType, uint32_T subType);
	void			AddOutputPin(std::string name);

	void			EnterMutex();
	void			LeaveMutex();

	virtual void	OnReceive(void);
	virtual void	OnRun(int32_T type, const void *data, size_t size);

	virtual bool	OnInitFirst(void);
	virtual bool	OnInitNormal(void);
	virtual bool	OnGraphReady(void);

	virtual bool	OnStart(void);
	virtual bool	OnStop(void);

	virtual void	OnShutdownFirst(void);
	virtual void	OnShutdownNormal(void);

	virtual void	OnTimer(int id);

	void			ShowErrorBox(const char *text, const char *title);

	tResult			Submit(std::string pinName, void *data, size_t size);

	void			RegisterSignal(const char *name);
	void			UpdateSignal(tSignalID id, real64_T value);

	tResult			GetSignalValue(tSignalID nSignalID, tSignalValue * pValue);
	tResult			ActivateSignalEvents(tSignalID nSignalID, tTimeStamp nUpdateRate);
	tResult			DeactivateSignalEvents(tSignalID nSignalID);

private:
	virtual	tTimeStamp		GetStreamTime() = 0;
	virtual	tBool			GetPropertyBool(const tChar* strName, tBool bDefault = tFalse) = 0;
	virtual	tResult			AllocMediaSample(IMediaSample** ppMediaSample, ucom::IException** __exception_ptr=NULL) = 0;
	virtual	const tChar*	OIGetInstanceName() = 0;
	virtual	tResult			RegisterPin(IPin* pIPin) = 0;
	virtual	tResult			ReleasePins(void) = 0;
	virtual	tResult			SetPropertyBool(const tChar* strName, tBool bValue) = 0;

	virtual tResult			GetInterface(const tChar* idInterface, tVoid** ppvObject) = 0;
	virtual tUInt			Ref() = 0;
	virtual tUInt			Unref() = 0;
	virtual tVoid			Destroy() = 0;

};





#endif
