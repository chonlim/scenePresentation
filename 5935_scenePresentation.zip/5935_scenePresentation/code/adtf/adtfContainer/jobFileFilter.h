#ifndef guard_jobFileFilter_h
#define guard_jobFileFilter_h

#include "baseFilter.h"

#define ADTF_FILTER_ID_jobFileFilter		"IDII.jobFileFilter"
#define ADTF_FILTER_NAME_jobFileFilter		"IDII jobFileFilter"

#include "tools/replayTools/tstring.h"
#include "tools/replayTools/jobFile.h"
#include "tools/replayTools/velocityRing.h"
#include "tools/replayTools/constraintRing.h"
#include "tools/replayTools/statusRing.h"

#include "tools/replayTools/controlBuffer.h"
#include "tools/replayTools/strategyBuffer.h"
#include "tools/replayTools/traceBuffer.h"


class jobFileFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_jobFileFilter, ADTF_FILTER_NAME_jobFileFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	cObjectPtr<adtf_devicetb::IFlexRayCoder>	flexrayCoder;

	/* FIBEX-IDs der Signale und PDUs, die wir ben�tigen */
	struct {
		struct {
			tUInt32		pdu;
			tUInt32		NP_LatDegree;
			tUInt32		NP_LongDegree;
			tUInt32		NP_LatDirection;
			tUInt32		NP_LongDirection;
		} NavPos_01;
	} id;

	jobFile_T			 jobFile;

	inputPin_T			*inputPin_flexray;
	inputPin_T			*inputPin_pemControl;
	inputPin_T			*inputPin_pemPlanning;

	velocityRing_T		 velocityRing;
	constraintRing_T	 constraintRing;
	statusRing_T		 statusRing;

	controlBuffer_T		 controlBuffer;
	strategyBuffer_T	 strategyBuffer;

	real64_T			 latitude;
	real64_T			 longitude;

	real32_T			 firstPosition;
	uint32_T			 firstTickCount;

public:
	jobFileFilter_T(const tChar* __info);

	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	bool		OnStart(void);
	bool		OnStop(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);
};


#endif
