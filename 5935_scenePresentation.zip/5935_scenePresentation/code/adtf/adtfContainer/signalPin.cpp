#include "stdafx.h"
#include "signalPin.h"


signalPin_T::signalPin_T(const pinHeader_T &header)
{
	this->header			= header.Duplicate();
	this->signalsEnabled	= false;
}


signalPin_T::signalPin_T(void)
{
	this->header			= NULL;
	this->signalsEnabled	= false;
}


signalPin_T::~signalPin_T(void)
{
	if(this->header) {
		delete this->header;
	}
}


void		signalPin_T::RegisterSignals(signalCallback_T *callback, const char *baseName)
{
	if(this->header) {
		uint8_T *dataBuffer = new uint8_T[header->GetTypeSize()];
		memset(dataBuffer, 0, header->GetTypeSize());

		this->header->ExploreMembers(dataBuffer, &this->RegisterCallback_bool, callback, baseName);
		this->header->ExploreMembers(dataBuffer, &this->RegisterCallback_int,  callback, baseName);
		this->header->ExploreMembers(dataBuffer, &this->RegisterCallback_real, callback, baseName);

		delete[] dataBuffer;

		this->signalsEnabled = true;
	}
}


void		signalPin_T::UpdateSignals(signalCallback_T *callback, const void *data, size_t size, tSignalID firstID)
{
	updateContext_T	context;

	if(!this->signalsEnabled) {
		return;
	}

	context.callback	= callback;
	context.nextID		= firstID;

	if(this->header && size == this->header->GetTypeSize()) {
		uint8_T *dataBuffer = new uint8_T[header->GetTypeSize()];
		memcpy(dataBuffer, data, header->GetTypeSize());

		this->header->ExploreMembers(dataBuffer, &this->UpdateCallback_bool, &context, "");
		this->header->ExploreMembers(dataBuffer, &this->UpdateCallback_int,  &context, "");
		this->header->ExploreMembers(dataBuffer, &this->UpdateCallback_real, &context, "");

		delete[] dataBuffer;
	}
}


bool	signalPin_T::SignalsPossible(void)
{
	if(this->header) {
		return true;
	}

	return false;
}


bool_T		signalPin_T::RegisterCallback_bool(const void *callback, const char *name, const char *description, bool_T value)
{
	((signalCallback_T*)callback)->RegisterSignal(name);

	return value;
}


int32_T		signalPin_T::RegisterCallback_int(const void *callback, const char *name, const char *description, int32_T value)
{
	((signalCallback_T*)callback)->RegisterSignal(name);

	return value;
}


real64_T	signalPin_T::RegisterCallback_real(const void *callback, const char *name, const char *description, real64_T value)
{
	((signalCallback_T*)callback)->RegisterSignal(name);

	return value;
}


bool_T		signalPin_T::UpdateCallback_bool(const void *context, const char *name, const char *description, bool_T value)
{
	((updateContext_T*)context)->callback->UpdateSignal(((updateContext_T*)context)->nextID++, value);

	return value;
}


int32_T		signalPin_T::UpdateCallback_int(const void *context, const char *name, const char *description, int32_T value)
{
	((updateContext_T*)context)->callback->UpdateSignal(((updateContext_T*)context)->nextID++, value);

	return value;
}


real64_T	signalPin_T::UpdateCallback_real(const void *context, const char *name, const char *description, real64_T value)
{
	((updateContext_T*)context)->callback->UpdateSignal(((updateContext_T*)context)->nextID++, value);

	return value;
}

