#ifndef guard_clusterGatewayFilter_h
#define guard_clusterGatewayFilter_h

#include "baseFilter.h"
#include <vector>

#define ADTF_FILTER_ID_clusterGatewayFilter		"IDII.clusterGatewayFilter"
#define ADTF_FILTER_NAME_clusterGatewayFilter	"IDII clusterGatewayFilter"


class clusterGatewayFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_clusterGatewayFilter, ADTF_FILTER_NAME_clusterGatewayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	tUInt32					idPACC02_02;

	cObjectPtr<adtf_devicetb::IFlexRayCoder>	flexrayCoder;


public:
	clusterGatewayFilter_T(const tChar* __info);
	~clusterGatewayFilter_T();

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	tResult		OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);
	void		OnReceive(void);

	void		OnRun(int32_T type, const void *data, size_t size);


private:
	void		OnTrigger(void);
};


#endif
