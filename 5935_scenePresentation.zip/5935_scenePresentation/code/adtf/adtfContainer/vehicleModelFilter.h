#ifndef guard_vehicleModelFilter_h
#define guard_vehicleModelFilter_h

#include "baseFilter.h"

#include "common/vehicleModel/vehicleModel_private.h"
#include "../ibfFile/ibfFile.h"

#define ADTF_FILTER_ID_vehicleModelFilter		"IDII.vehicleModelFilter"
#define ADTF_FILTER_NAME_vehicleModelFilter		"IDII vehicleModelFilter"


class vehicleModelFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_vehicleModelFilter, ADTF_FILTER_NAME_vehicleModelFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	ibfFile_T<vehicleModel_T>	ibf;

public:
	vehicleModelFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnStart(void);
};


#endif
