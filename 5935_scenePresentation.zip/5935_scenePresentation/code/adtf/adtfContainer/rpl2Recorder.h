#ifndef guard_rpl2Recorder_h
#define guard_rpl2Recorder_h

#include "baseFilter.h"

#define ADTF_FILTER_ID_rpl2Recorder		"IDII.rpl2Recorder"
#define ADTF_FILTER_NAME_rpl2Recorder	"IDII rpl2Recorder"

#include <tools/rpl2Tools/rpl2File.h>


class rpl2Recorder_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_rpl2Recorder, ADTF_FILTER_NAME_rpl2Recorder, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	inputPin_T		*inputPin_flexray;
	inputPin_T		*inputPin_canPSD;
	inputPin_T		*inputPin_pemControl;
	inputPin_T		*inputPin_pemPlanning;
	inputPin_T		*inputPin_evaluatedScenes;

	bool			 canPSDReceived;
	bool			 PACC02_received;


	/* FIBEX-IDs der Signale und PDUs, die wir ben�tigen */
	struct {
		struct {
			tUInt32		pdu;
		} PSD_04;

		struct {
			tUInt32		pdu;
		} PSD_05;

		struct {
			tUInt32		pdu;
		} PSD_06;

		struct {
			tUInt32		pdu;
			tUInt32		ACC_zul_Regelabw_unten;
			tUInt32		ACC_Sollbeschleunigung_02;
			tUInt32		ACC_zul_Regelabw_oben;
			tUInt32		ACC_neg_Sollbeschl_Grad_02;
			tUInt32		ACC_pos_Sollbeschl_Grad_02;
			tUInt32		ACC_Status_ACC;
		} ACC_06;

		struct {
			tUInt32		pdu;
			tUInt32		ACC_Folgebeschl;
			tUInt32		ACC_Freilauf_Info;
		} ACC_07;

		struct {
			tUInt32		pdu;
			tUInt32		ACC_Gesetzte_Zeitluecke;
		} ACC_12;

		struct {
			tUInt32		pdu;
			tUInt32		ACC_Fahrprogramm_PACC;
			tUInt32		ACC_Nutzung_VZ_PACC;
			tUInt32		ACC_Regelung_durch_PACC;
			tUInt32		ACC_Sensibilitaet_PACC;
			tUInt32		ACC_vLimit1_PACC;
			tUInt32		ACC_Offset_Default_PACC;
		} ACC_16;

		struct {
			tUInt32		pdu;
			tUInt32		BM_links;
			tUInt32		BM_rechts;
			tUInt32		BM_Autobahn;
		} Blinkmodi_02;

		struct {
			tUInt32		pdu;
			tUInt32		BV1_LIN_05_BeginnX;
			tUInt32		BV1_LIN_05_VorgaengerID;
			tUInt32		BV1_LIN_05_ID;
			tUInt32		BV1_LIN_05_AbstandY;
			tUInt32		BV1_LIN_05_GierWnkl;
			tUInt32		BV1_LIN_05_HorKruemm;
			tUInt32		BV1_LIN_05_HorKruemmAend;
			tUInt32		BV1_LIN_05_ExistMass;
			tUInt32		BV1_LIN_05_NachfolgerID;
			tUInt32		BV1_LIN_05_EndeX;
			tUInt32		BV1_LIN_05_Breite;
			tUInt32		BV1_LIN_05_Typ;
			tUInt32		BV1_LIN_05_Hoehe;
			tUInt32		BV1_LIN_05_Farbe;
			tUInt32		BV1_LIN_06_BeginnX;
			tUInt32		BV1_LIN_06_VorgaengerID;
			tUInt32		BV1_LIN_06_ID;
			tUInt32		BV1_LIN_06_AbstandY;
			tUInt32		BV1_LIN_06_GierWnkl;
			tUInt32		BV1_LIN_06_HorKruemm;
			tUInt32		BV1_LIN_06_HorKruemmAend;
			tUInt32		BV1_LIN_06_ExistMass;
			tUInt32		BV1_LIN_06_NachfolgerID;
			tUInt32		BV1_LIN_06_EndeX;
			tUInt32		BV1_LIN_06_Breite;
			tUInt32		BV1_LIN_06_Typ;
			tUInt32		BV1_LIN_06_Hoehe;
			tUInt32		BV1_LIN_06_Farbe;
		} BV2_Linien_Ego_Doppel;

		struct {
			tUInt32		pdu;
			tUInt32		BV1_LIN_01_BeginnX;
			tUInt32		BV1_LIN_01_VorgaengerID;
			tUInt32		BV1_LIN_01_ID;
			tUInt32		BV1_LIN_01_AbstandY;
			tUInt32		BV1_LIN_01_GierWnkl;
			tUInt32		BV1_LIN_01_HorKruemm;
			tUInt32		BV1_LIN_01_HorKruemmAend;
			tUInt32		BV1_LIN_01_ExistMass;
			tUInt32		BV1_LIN_01_NachfolgerID;
			tUInt32		BV1_LIN_01_EndeX;
			tUInt32		BV1_LIN_01_Breite;
			tUInt32		BV1_LIN_01_Typ;
			tUInt32		BV1_LIN_01_Hoehe;
			tUInt32		BV1_LIN_01_Farbe;
			tUInt32		BV1_LIN_01_Seg01_StdA_E;
			tUInt32		BV1_LIN_01_Seg01_StdA_M;
			tUInt32		BV1_LIN_07_BeginnX;
			tUInt32		BV1_LIN_07_VorgaengerID;
			tUInt32		BV1_LIN_07_ID;
			tUInt32		BV1_LIN_07_AbstandY;
			tUInt32		BV1_LIN_07_GierWnkl;
			tUInt32		BV1_LIN_07_HorKruemm;
			tUInt32		BV1_LIN_07_HorKruemmAend;
			tUInt32		BV1_LIN_07_ExistMass;
			tUInt32		BV1_LIN_07_NachfolgerID;
			tUInt32		BV1_LIN_07_EndeX;
			tUInt32		BV1_LIN_07_Seg02_StdA_A;
			tUInt32		BV1_LIN_07_Seg02_StdA_E;
			tUInt32		BV1_LIN_07_Seg02_StdA_M;
		} BV2_Linien_Ego_Links;

		struct {
			tUInt32		pdu;
			tUInt32		BV1_LIN_02_BeginnX;
			tUInt32		BV1_LIN_02_VorgaengerID;
			tUInt32		BV1_LIN_02_ID;
			tUInt32		BV1_LIN_02_AbstandY;
			tUInt32		BV1_LIN_02_GierWnkl;
			tUInt32		BV1_LIN_02_HorKruemm;
			tUInt32		BV1_LIN_02_HorKruemmAend;
			tUInt32		BV1_LIN_02_ExistMass;
			tUInt32		BV1_LIN_02_NachfolgerID;
			tUInt32		BV1_LIN_02_EndeX;
			tUInt32		BV1_LIN_02_Breite;
			tUInt32		BV1_LIN_02_Typ;
			tUInt32		BV1_LIN_02_Hoehe;
			tUInt32		BV1_LIN_02_Farbe;
			tUInt32		BV1_LIN_02_Seg01_StdA_E;
			tUInt32		BV1_LIN_02_Seg01_StdA_M;
			tUInt32		BV1_LIN_08_BeginnX;
			tUInt32		BV1_LIN_08_VorgaengerID;
			tUInt32		BV1_LIN_08_ID;
			tUInt32		BV1_LIN_08_AbstandY;
			tUInt32		BV1_LIN_08_GierWnkl;
			tUInt32		BV1_LIN_08_HorKruemm;
			tUInt32		BV1_LIN_08_HorKruemmAend;
			tUInt32		BV1_LIN_08_ExistMass;
			tUInt32		BV1_LIN_08_NachfolgerID;
			tUInt32		BV1_LIN_08_EndeX;
			tUInt32		BV1_LIN_08_Seg02_StdA_A;
			tUInt32		BV1_LIN_08_Seg02_StdA_E;
			tUInt32		BV1_LIN_08_Seg02_StdA_M;
		} BV2_Linien_Ego_Rechts;

		struct {
			tUInt32		pdu;
			tUInt32		BV1_LIN_03_BeginnX;
			tUInt32		BV1_LIN_03_VorgaengerID;
			tUInt32		BV1_LIN_03_ID;
			tUInt32		BV1_LIN_03_AbstandY;
			tUInt32		BV1_LIN_03_GierWnkl;
			tUInt32		BV1_LIN_03_HorKruemm;
			tUInt32		BV1_LIN_03_HorKruemmAend;
			tUInt32		BV1_LIN_03_ExistMass;
			tUInt32		BV1_LIN_03_NachfolgerID;
			tUInt32		BV1_LIN_03_EndeX;
			tUInt32		BV1_LIN_03_Breite;
			tUInt32		BV1_LIN_03_Typ;
			tUInt32		BV1_LIN_03_Hoehe;
			tUInt32		BV1_LIN_03_Farbe;
			tUInt32		BV1_LIN_04_BeginnX;
			tUInt32		BV1_LIN_04_VorgaengerID;
			tUInt32		BV1_LIN_04_ID;
			tUInt32		BV1_LIN_04_AbstandY;
			tUInt32		BV1_LIN_04_GierWnkl;
			tUInt32		BV1_LIN_04_HorKruemm;
			tUInt32		BV1_LIN_04_HorKruemmAend;
			tUInt32		BV1_LIN_04_ExistMass;
			tUInt32		BV1_LIN_04_NachfolgerID;
			tUInt32		BV1_LIN_04_EndeX;
			tUInt32		BV1_LIN_04_Breite;
			tUInt32		BV1_LIN_04_Typ;
			tUInt32		BV1_LIN_04_Hoehe;
			tUInt32		BV1_LIN_04_Farbe;
		} BV2_Linien_Nebenspuren;

		struct {
			tUInt32		pdu;
			tUInt32		CHA_EV_LED;
		} Charisma_03;

		struct {
			tUInt32		pdu;
			tUInt32		CHA_Ziel_FahrPr_PACC;
		} Charisma_08;

		struct {
			tUInt32		pdu;
			tUInt32		EM1_Max_Moment;
			tUInt32		EM1_Min_Moment;
			tUInt32		EM1_MaxDyn_Moment;
		} EM1_HYB_06;

		struct {
			tUInt32		pdu;
			tUInt32		EM1_IstMoment;
			tUInt32		EM1_IstDrehzahl;
		} EM1_HYB_12;

		struct {
			tUInt32		pdu;
			tUInt32		EM1_MaxPred_Moment;
			tUInt32		EM1_MaxPred_Abknickdrehzahl;
		} EM1_HYB_14;

		struct {
			tUInt32		pdu;
			tUInt32		EM2_Max_Moment;
			tUInt32		EM2_MaxDyn_Moment;
		} EM2_HYB_06;

		struct {
			tUInt32		pdu;
			tUInt32		EM2_IstMoment;
			tUInt32		EM2_IstDrehzahl;
		} EM2_HYB_12;

		struct {
			tUInt32		pdu;
			tUInt32		EML_BeschlX;
			tUInt32		EML_GeschwX;
			tUInt32		EML_GierRate;
		} EML_01;

		struct {
			tUInt32		pdu;
			tUInt32		EML_BeschlY;
		} EML_03;

		struct {
			tUInt32		pdu;
			tUInt32		EML_Gierwinkel;
			tUInt32		EML_PositionX;
			tUInt32		EML_PositionY;
		} EML_04;

		struct {
			tUInt32		pdu;
			tUInt32		ESP_Status_Bremsdruck;
		} ESP_05;

		struct {
			tUInt32		pdu;
			tUInt32		ESP_v_Signal;
		} ESP_21;

		struct {
			tUInt32		pdu;
			tUInt32		ESP_QBit_VL_Bremsmoment;
			tUInt32		ESP_QBit_VR_Bremsmoment;
			tUInt32		ESP_QBit_HL_Bremsmoment;
			tUInt32		ESP_QBit_HR_Bremsmoment;
			tUInt32		ESP_VL_Bremsmoment;
			tUInt32		ESP_VR_Bremsmoment;
			tUInt32		ESP_HL_Bremsmoment;
			tUInt32		ESP_HR_Bremsmoment;
		} ESP_22;

		struct {
			tUInt32		pdu;
			tUInt32		EFP_NaesseLevel;
			tUInt32		EFP_NaesseLevel_Classifier;
		} Fahrwerk_07;

		struct {
			tUInt32		pdu;
			tUInt32		GE_Fahrstufe;
			tUInt32		GE_Schaltablauf;
			tUInt32		GE_Status_Kraftschluss;
			tUInt32		GE_Zielgang;
		} Getriebe_11;

		struct {
			tUInt32		pdu;
			tUInt32		GE_Verlustmoment;
		} Getriebe_13;

		struct {
			tUInt32		pdu;
			tUInt32		GE_Freilauf_Status;
			tUInt32		GE_Uefkt_Praed;
		} Getriebe_17;

		struct {
			tUInt32		pdu;
			tUInt32		GRA_Hauptschalter;
			tUInt32		GRA_Abbrechen;
			tUInt32		GRA_Limiter;
			tUInt32		GRA_Tip_Setzen;
			tUInt32		GRA_Tip_Hoch;
			tUInt32		GRA_Tip_Runter;
			tUInt32		GRA_Tip_Wiederaufnahme;
			tUInt32		GRA_Verstellung_Zeitluecke;
			tUInt32		GRA_Tip_Stufe_2;
			tUInt32		GRA_Typ_Bedienteil;
		} GRA_ACC_01;

		struct {
			tUInt32		pdu;
			tUInt32		HAL_VZ_Radwinkel;
			tUInt32		HAL_QBit_Radwinkel;
			tUInt32		HAL_Radwinkel;
		} HAL_01;

		struct {
			tUInt32		pdu;
			tUInt32		KBI_angez_Geschw;
			tUInt32		KBI_Einheit_Tacho;
		} Kombi_01;

		struct  {
			tUInt32		pdu;
			tUInt32		KBI_aktive_Laengsfunktion;
		} Kombi_02;

		struct {
			tUInt32		pdu;
			tUInt32		LWI_Lenkradwinkel;
			tUInt32		LWI_VZ_Lenkradwinkel;
			tUInt32		LWI_Lenkradw_Geschw;
			tUInt32		LWI_VZ_Lenkradw_Geschw;
		} LWI_01;

		struct {
			tUInt32		pdu;
			tUInt32		MO_KVS;
		} Motor_04;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Kuehlmittel_Temp;
		} Motor_07;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Mom_Ist_Summe;
			tUInt32		MO_Mom_Schub;
		} Motor_11;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Mom_Begr_stat;
			tUInt32		MO_Mom_Begr_dyn;
		} Motor_12;

		struct {
			tUInt32		pdu;
			tUInt32		MO_HYB_VM_aktiv;
			tUInt32		MO_Fahrer_bremst;
		} Motor_14;

		struct {
			tUInt32		pdu;
			tUInt32		TSK_Steigung_02;
			tUInt32		TSK_QBit_Steigung;
			tUInt32		TSK_QBit_Fahrzeugmasse;
			tUInt32		TSK_Fahrzeugmasse_02;
			tUInt32		TSK_Grundmasse;
		} Motor_16;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Fahrzeugtyp;
		} Motor_18;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Fahrpedalrohwert_01;
		} Motor_20;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Leistungsvermoegen;
		} Motor_27;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Drehzahl_VM;
		} Motor_28;

		struct {
			tUInt32		pdu;
			tUInt32		MO_Faktor_Momente_02;
			tUInt32		MO_Hybridfahrzeug;
			tUInt32		MO_Code;
			tUInt32		MO_Getriebe_Code;
			tUInt32		MO_Anzahl_Zyl;
			tUInt32		MO_Kraftstoffart;
			tUInt32		MO_Hubraum;
			tUInt32		MO_Ansaugsystem;
			tUInt32		MO_Leistung;
		} Motor_Code_01;

		struct {
			tUInt32		pdu;
			tUInt32		Ladezustand_02;
			tUInt32		MO_Zust_Betriebsstrategie;
		} Motor_Hybrid_03;

		struct {
			tUInt32		pdu;
			tUInt32		NP_LatDegree;
			tUInt32		NP_LongDegree;
			tUInt32		NP_LatDirection;
			tUInt32		NP_LongDirection;
		} NavPos_01;

		struct {
			tUInt32		pdu;
			tUInt32		PACC_Wunschuebersetzung;
			tUInt32		PACC_Sollbeschleunigung;
			tUInt32		PACC_zul_Regelabw_oben;
			tUInt32		PACC_neg_Sollbeschl_Grad;
			tUInt32		PACC_pos_Sollbeschl_Grad;
			tUInt32		PACC_Ausrollmanoever;
			tUInt32		PACC_zul_Regelabw_unten;
		} PACC_01;

		struct {
			tUInt32		pdu;
			tUInt32		PACC_Sytemstatus_Anzeige;
			tUInt32		PACC_Automode;
			tUInt32		PACC_Segelanteil;
			tUInt32		PACC_Durchschnittsgeschw;
			tUInt32		PACC_Uebernahmeaufforderung;
			tUInt32		PACC_Systemstatus;
			tUInt32		PACC_Vorausschaugeschw;
			tUInt32		PACC_Offset;
			tUInt32		PACC_Sollgeschwindigkeit;
			tUInt32		PACC_naechstes_Event;
		} PACC_02;

		struct {
			tUInt32		pdu;
			tUInt32		PACC02_Wunschuebersetzung;
			tUInt32		PACC02_Sollbeschleunigung;
			tUInt32		PACC02_zul_Regelabw_oben;
			tUInt32		PACC02_neg_Sollbeschl_Grad;
			tUInt32		PACC02_pos_Sollbeschl_Grad;
			tUInt32		PACC02_Ausrollmanoever;
			tUInt32		PACC02_zul_Regelabw_unten;
		} PACC02_01;

		struct {
			tUInt32		pdu;
			tUInt32		PACC02_InnoDrive_Texte;
			tUInt32		PACC02_Systemstatus_Anzeige;
			tUInt32		PACC02_Automode;
			tUInt32		PACC02_Segelanteil;
			tUInt32		PACC02_Durchschnittsgeschw;
			tUInt32		PACC02_Uebernahmeaufforderung;
			tUInt32		PACC02_Systemstatus;
			tUInt32		PACC02_Vorausschaugeschw;
			tUInt32		PACC02_Offset;
			tUInt32		PACC02_Sollgeschwindigkeit;
			tUInt32		PACC02_naechstes_Event;
		} PACC02_02;

		struct {
			tUInt32		pdu;
			tUInt32		PACC02_Geschw_Vorausschau;
			tUInt32		PACC02_Event_aktiv;
			tUInt32		PACC02_Hinweis_Geschw;
			tUInt32		PACC02_Offset_aktiv;
			tUInt32		PACC02_Offset_Anzeige;
		} PACC02_03;

		struct {
			tUInt32		pdu;
			tUInt32		PIDM_HS_Richtung;
			tUInt32		PIDM_HS_Attribut;
			tUInt32		PIDM_HS_Abstand;
			tUInt32		PIDM_HS_Heading;
			tUInt32		PIDM_HS_Index;
			tUInt32		PIDM_Status;
			tUInt32		PIDM_HS_Typnummer;
		} PIDM_01;

		struct {
			tUInt32		pdu;
			tUInt32		pVS_vLimit_Range_HMI;
		} pVS_01;

		struct {
			tUInt32		pdu;
			tUInt32		SARA_Accel_X_r;
			tUInt32		SARA_Accel_Y_r;
			tUInt32		SARA_Omega_Z_r;
		} SARA_11;

		struct {
			tUInt32		pdu;
			tUInt32		SDF1_Obj_01_ID;
			tUInt32		SDF1_Obj_01_Gemessen;
			tUInt32		SDF1_Obj_01_Historie;
			tUInt32		SDF1_Obj_01_ExistenzMass;
			tUInt32		SDF1_Obj_01_Alter;
			tUInt32		SDF1_Obj_01_Klasse;
			tUInt32		SDF1_Obj_01_KlassePlausib;
			tUInt32		SDF1_Obj_01_Bezugspunkt;
			tUInt32		SDF1_Obj_01_PositionX;
			tUInt32		SDF1_Obj_01_PositionXStdA;
			tUInt32		SDF1_Obj_01_PositionY;
			tUInt32		SDF1_Obj_01_PositionYStdA;
			tUInt32		SDF1_Obj_01_PositionZ;
			tUInt32		SDF1_Obj_01_PositionZStdA;
			tUInt32		SDF1_Obj_01_GeschwRelX;
			tUInt32		SDF1_Obj_01_GeschwRelXStdA;
			tUInt32		SDF1_Obj_01_GeschwRelY;
			tUInt32		SDF1_Obj_01_GeschwRelYStdA;
			tUInt32		SDF1_Obj_01_BeschlRelX;
			tUInt32		SDF1_Obj_01_BeschlRelXStdA;
			tUInt32		SDF1_Obj_01_BeschlRelY;
			tUInt32		SDF1_Obj_01_BeschlRelYStdA;
			tUInt32		SDF1_Obj_01_Hoehe;
			tUInt32		SDF1_Obj_01_HoeheStdA;
			tUInt32		SDF1_Obj_01_Breite;
			tUInt32		SDF1_Obj_01_BreiteStdA;
			tUInt32		SDF1_Obj_01_Laenge;
			tUInt32		SDF1_Obj_01_LaengeStdA;
			tUInt32		SDF1_Obj_01_GierWnkl;
			tUInt32		SDF1_Obj_01_GierWnklStdA;
		} SDF1_Objekt_01;

		struct {
			tUInt32		pdu;
			tUInt32		SDF1_Obj_04_PositionX;
			tUInt32		SDF1_Obj_04_GeschwRelX;
		} SDF1_Objekt_04;

		struct {
			tUInt32		pdu;
			tUInt32		SDF2_Pos_Inhibitzeit;
			tUInt32		SDF2_Pos_Segment_ID;
			tUInt32		SDF2_Pos_Offset;
			tUInt32		SDF2_Pos_Standort_Eindeutig;
			tUInt32		SDF2_Pos_Distanz_Rampe_rechts;
			tUInt32		SDF2_Pos_Spurtype;
			tUInt32		SDF2_Pos_Distanz_Rampe_links;
			tUInt32		SDF2_Pos_AnzRampenRechts;
			tUInt32		SDF2_Pos_AnzRampenLinks;
			tUInt32		SDF2_Pos_Fehler_Laengsrichtung;
			tUInt32		SDF2_Pos_AnzHauptspuren;
			tUInt32		SDF2_Pos_Spurnummer;
			tUInt32		SDF2_Pos_GueteZuordnung;
		} SDF2_Pos_01;

		struct {
			tUInt32		pdu;
			tUInt32		SpoilerSG_HSpoiler_IstPos;
		} SpoilerSG_01;

		struct {
			tUInt32		pdu;
			tUInt32		TSK_Status;
			tUInt32		TSK_Hauptschalter_GRA_ACC;
			tUInt32		TSK_Limiter_ausgewaehlt;
		} TSK_06;

		struct {
			tUInt32		pdu;
			tUInt32		TSK_vMax_Fahrerassistenz;
			tUInt32		TSK_vMax_aktuell;
			tUInt32		TSK_Einheit_vMax_Fahrerassistenz;
		} TSK_08;

		struct {
			tUInt32		pdu;
			tUInt32		VZE_Anzeigemodus;
			tUInt32		VZE_Hinweistext;
			tUInt32		VZE_Anzeigeunterdrueck_Zeichen_3;
			tUInt32		VZE_Anzeigeunterdrueck_Zeichen_2;
			tUInt32		VZE_Verkehrszeichen_1;
			tUInt32		VZE_Verkehrszeichen_2;
			tUInt32		VZE_Verkehrszeichen_3;
			tUInt32		VZE_Warnung_Verkehrszeichen_1;
			tUInt32		VZE_Warnung_Verkehrszeichen_2;
			tUInt32		VZE_Warnung_Verkehrszeichen_3;
			tUInt32		VZE_Zusatzschild_1;
			tUInt32		VZE_Zusatzschild_2;
			tUInt32		VZE_Zusatzschild_3;
			tUInt32		VZE_Anzeigeunterdrueck_Zeichen_1;
			tUInt32		VZE_Zeichen_01_KameraWied;
			tUInt32		VZE_Zeichen_02_KameraWied;
			tUInt32		VZE_Zeichen_03_KameraWied;
			tUInt32		VZE_Zeichen_01_Kamera;
			tUInt32		VZE_Zeichen_01_Karte;
			tUInt32		VZE_Zeichen_01_Gesetz;
			tUInt32		VZE_Zeichen_02_Kamera;
			tUInt32		VZE_Zeichen_02_Karte;
			tUInt32		VZE_Zeichen_02_Gesetz;
			tUInt32		VZE_Zeichen_03_Kamera;
			tUInt32		VZE_Zeichen_03_Karte;
			tUInt32		VZE_Zeichen_03_Gesetz;
			tUInt32		VZE_Gong;
			tUInt32		VZE_Verkehrszeichen_Einheit;
		} VZE_01;

		struct {
			tUInt32		pdu;
			tUInt32		VZE_Anzeigeunterdrueck_Zeichen_5;
			tUInt32		VZE_Zeichen_05_KameraWied;
			tUInt32		VZE_Zeichen_05_Kamera;
			tUInt32		VZE_Verkehrszeichen_4;
			tUInt32		VZE_Verkehrszeichen_5;
			tUInt32		VZE_Anhaenger_Vmax;
			tUInt32		VZE_Zeichen_04_Gesetz;
			tUInt32		VZE_Zeichen_04_Kamera;
			tUInt32		VZE_Zeichen_04_KameraWied;
			tUInt32		VZE_Zeichen_04_Karte;
			tUInt32		VZE_Warnung_Verkehrszeichen_4;
			tUInt32		VZE_Warnung_Verkehrszeichen_5;
			tUInt32		VZE_Zeichen_05_Gesetz;
			tUInt32		VZE_Zusatzschild_4;
			tUInt32		VZE_Zusatzschild_5;
			tUInt32		VZE_Baustelle;
			tUInt32		VZE_Zeichen_05_Karte;
			tUInt32		VZE_Zeichen_05_Entfernung;
			tUInt32		VZE_Zeichen_05_Entfernung_StdA;
			tUInt32		VZE_Anzeigeunterdrueck_Zeichen_4;
		} VZE_02;

		struct {
			tUInt32		pdu;
			tUInt32		VZE_Verkehrszeichen_6;
			tUInt32		VZE_Zusatzschild_6;
			tUInt32		VZE_Zeichen_06_Entfernung;
			tUInt32		VZE_Zeichen_06_Entfernung_StdA;
			tUInt32		VZE_Umweltinfo_Naesse;
			tUInt32		VZE_Umweltinfo_Nebel;
			tUInt32		VZE_Umweltinfo_Anhaengerbetrieb;
			tUInt32		VZE_Erweiterte_Information;
			tUInt32		VZE_Tempowarnung_Status;
			tUInt32		VZE_Tempowarnung_Einheit;
			tUInt32		VZE_Tempowarnung_Offset;
		} VZE_03;

		struct {
			tUInt32		pdu;
			tUInt32		DEV_BVS_02_Data_01;
			tUInt32		DEV_BVS_02_Data_02;
			tUInt32		DEV_BVS_02_Data_03;
			tUInt32		DEV_BVS_02_Data_04;
			tUInt32		DEV_BVS_02_Data_05;
			tUInt32		DEV_BVS_02_Data_06;
			tUInt32		DEV_BVS_02_Data_07;
			tUInt32		DEV_BVS_02_Data_08;
			tUInt32		DEV_BVS_02_Data_09;
			tUInt32		DEV_BVS_02_Data_10;
			tUInt32		DEV_BVS_02_Data_11;
			tUInt32		DEV_BVS_02_Data_12;
			tUInt32		DEV_BVS_02_Data_13;
			tUInt32		DEV_BVS_02_Data_14;
			tUInt32		DEV_BVS_02_Data_15;
			tUInt32		DEV_BVS_02_Data_16;
			tUInt32		DEV_BVS_02_Data_17;
			tUInt32		DEV_BVS_02_Data_18;
			tUInt32		DEV_BVS_02_Data_19;
			tUInt32		DEV_BVS_02_Data_20;
			tUInt32		DEV_BVS_02_Data_21;
		} DEV_BVS_02;


		struct {
			tUInt32		pdu;
			tUInt32		DEV_BVS_03_Data_01;
			tUInt32		DEV_BVS_03_Data_02;
			tUInt32		DEV_BVS_03_Data_03;
			tUInt32		DEV_BVS_03_Data_04;
			tUInt32		DEV_BVS_03_Data_05;
			tUInt32		DEV_BVS_03_Data_06;
			tUInt32		DEV_BVS_03_Data_07;
			tUInt32		DEV_BVS_03_Data_08;
			tUInt32		DEV_BVS_03_Data_09;
			tUInt32		DEV_BVS_03_Data_10;
			tUInt32		DEV_BVS_03_Data_11;
			tUInt32		DEV_BVS_03_Data_12;
			tUInt32		DEV_BVS_03_Data_13;
			tUInt32		DEV_BVS_03_Data_14;
			tUInt32		DEV_BVS_03_Data_15;
			tUInt32		DEV_BVS_03_Data_16;
			tUInt32		DEV_BVS_03_Data_17;
			tUInt32		DEV_BVS_03_Data_18;
			tUInt32		DEV_BVS_03_Data_19;
			tUInt32		DEV_BVS_03_Data_20;
			tUInt32		DEV_BVS_03_Data_21;
			tUInt32		DEV_BVS_03_Data_22;
		} DEV_BVS_03;


		struct {
			tUInt32		pdu;
			tUInt32		DEV_BVS_04_Data_01;
			tUInt32		DEV_BVS_04_Data_02;
			tUInt32		DEV_BVS_04_Data_03;
			tUInt32		DEV_BVS_04_Data_04;
			tUInt32		DEV_BVS_04_Data_05;
			tUInt32		DEV_BVS_04_Data_06;
			tUInt32		DEV_BVS_04_Data_07;
			tUInt32		DEV_BVS_04_Data_08;
			tUInt32		DEV_BVS_04_Data_09;
			tUInt32		DEV_BVS_04_Data_10;
			tUInt32		DEV_BVS_04_Data_11;
			tUInt32		DEV_BVS_04_Data_12;
			tUInt32		DEV_BVS_04_Data_13;
			tUInt32		DEV_BVS_04_Data_14;
			tUInt32		DEV_BVS_04_Data_15;
			tUInt32		DEV_BVS_04_Data_16;
			tUInt32		DEV_BVS_04_Data_17;
			tUInt32		DEV_BVS_04_Data_18;
			tUInt32		DEV_BVS_04_Data_19;
			tUInt32		DEV_BVS_04_Data_20;
			tUInt32		DEV_BVS_04_Data_21;
			tUInt32		DEV_BVS_04_Data_22;
		} DEV_BVS_04;

	} id;

	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;

	rpl2File_T		rpl2File;


public:
	rpl2Recorder_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);


private:
	void		Process_PSD(uint32_T id, const uint8_T *data, tTimeStamp time);
};


#endif
