#ifndef guard_dobsHistDisplayFilter_h
#define guard_dobsHistDisplayFilter_h

#include "displayFilter.h"

#define ADTF_FILTER_ID_dobsHistDisplayFilter		"IDII.dobsHistDisplayFilter"
#define ADTF_FILTER_NAME_dobsHistDisplayFilter		"IDII dobsHistDisplayFilter"


#include "tools/hpDisplayBlocks/dobsHistPainter.h"


#include "Rte_Type.h"



#include "../testVector/testVector.h"


class dobsHistDisplayFilter_T
  : public displayFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_dobsHistDisplayFilter, ADTF_FILTER_NAME_dobsHistDisplayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	dobsHistPainter_T		dobsHistPainter;
	driverState_T			driverState;

	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;
	tUInt32					idPIF_01;
	tUInt32				tickCount;
	

public:
	dobsHistDisplayFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);
	void		OnRun(int32_T type, const void *data, size_t size);

	void		OnReceive(void);

	void		PrePaint(void);

	void		runAlgorithm(void);



private:


};

#endif
