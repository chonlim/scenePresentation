#include "stdafx.h"
#include "zfasConverterFilter.h"

#include "common/swcCommunication/PpPemControl.h"
#include "common/swcCommunication/PpPemPlanning.h"

extern "C" {
	#include "control/rteInterface/rteEML.h"
	#include "control/rteInterface/rteFRInnoDriveIn.h"
	#include "control/rteInterface/rteOBFLightIn.h"
	#include "control/rteInterface/rteVZE.h"
	#include "control/rteInterface/rteRGLanes.h"
	#include "control/rteInterface/rteFRRGout.h"
}

#include "control/inputCodec/inputCodec_adtfTools.h"


zfasConverterFilter_T::zfasConverterFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("DePemControl",		768, 0);
	this->AddInputPin("DePemPlanning",		768, 0);

	this->AddInputPin("DeEML",				768, 0);
	this->AddInputPin("DeFRInnoDriveIn",	768, 0);
	this->AddInputPin("DeOBFLight",			768, 0);
	this->AddInputPin("DeVZE",				768, 0);
	this->AddInputPin("DeLanes",			768, 0);
	this->AddInputPin("DeFRRGOut",			768, 0);

	this->AddOutputPin("pemControl",		pemControl_header());
	this->AddOutputPin("pemPlanning",		pemPlanning_header());

	this->AddOutputPin("emlInput",			emlInput_header());
	this->AddOutputPin("flexrayInput",		flexrayInput_header());
	this->AddOutputPin("obfInput",			obfInput_header());
	this->AddOutputPin("laneInput",			laneInput_header());
	this->AddOutputPin("vzeInput",			vzeInput_header());
	this->AddOutputPin("lapInput",			lapInput_header());


	inputPin_DePemControl		= this->GetInputPin("DePemControl");
	inputPin_DePemPlanning		= this->GetInputPin("DePemPlanning");

	inputPin_DeEML				= this->GetInputPin("DeEML");
	inputPin_DeFRInnoDriveIn	= this->GetInputPin("DeFRInnoDriveIn");
	inputPin_DeOBFLight			= this->GetInputPin("DeOBFLight");
	inputPin_DeVZE				= this->GetInputPin("DeVZE");
	inputPin_DeLanes			= this->GetInputPin("DeLanes");
	inputPin_DeFRRGOut			= this->GetInputPin("DeFRRGOut");

}


void	zfasConverterFilter_T::OnReceive(void)
{
	if(inputPin_DePemControl->Unflag() && inputPin_DePemControl->GetDataSize() == sizeof(Dt_RECORD_PemControl)) {
		const Dt_RECORD_PemControl *input = (Dt_RECORD_PemControl*)inputPin_DePemControl->GetDataPtr();
		pemControl_T	output;

		rteInConvert_pemControl(input, &output);

		this->Submit("pemControl", &output, sizeof(output));
	}


	if(inputPin_DePemPlanning->Unflag() && inputPin_DePemPlanning->GetDataSize() == sizeof(Dt_RECORD_PemControl)) {
		const Dt_RECORD_PemPlanning *input = (Dt_RECORD_PemPlanning*)inputPin_DePemPlanning->GetDataPtr();
		pemPlanning_T	output;

		rteInConvert_pemPlanning(input, &output);

		this->Submit("pemPlanning", &output, sizeof(output));
	}

	if(inputPin_DeEML->Unflag() && inputPin_DeEML->GetDataSize() == sizeof(Dt_RECORD_EML)) {
		const Dt_RECORD_EML *input = (Dt_RECORD_EML*)inputPin_DeEML->GetDataPtr();
		emlInput_T		output;

		rteInConvert_emlInput(input, &output);

		this->Submit("emlInput", &output, sizeof(output));
	}

	if(inputPin_DeFRInnoDriveIn->Unflag() && inputPin_DeFRInnoDriveIn->GetDataSize() == sizeof(Dt_RECORD_FRInnoDriveIn)) {
		const Dt_RECORD_FRInnoDriveIn *input = (Dt_RECORD_FRInnoDriveIn*)inputPin_DeFRInnoDriveIn->GetDataPtr();
		flexrayInput_T	output;

		rteInConvert_flexrayInput(input, &output);

		this->Submit("flexrayInput", &output, sizeof(output));
	}

	if(inputPin_DeOBFLight->Unflag() && inputPin_DeOBFLight->GetDataSize() == sizeof(Dt_RECORD_ObjectListOBFLightOut)) {
		const Dt_RECORD_ObjectListOBFLightOut *input = (Dt_RECORD_ObjectListOBFLightOut*)inputPin_DeOBFLight->GetDataPtr();
		obfInput_T	output;

		rteInConvert_obfInput(input, &output);

		this->Submit("obfInput", &output, sizeof(output));
	}

	if(inputPin_DeVZE->Unflag() && inputPin_DeVZE->GetDataSize() == sizeof(Dt_RECORD_VZE)) {
		const Dt_RECORD_VZE *input = (Dt_RECORD_VZE*)inputPin_DeVZE->GetDataPtr();
		vzeInput_T		output;

		rteInConvert_vzeInput(input, &output);

		this->Submit("vzeInput", &output, sizeof(output));
	}

	if(inputPin_DeLanes->Unflag() && inputPin_DeLanes->GetDataSize() == sizeof(Dt_RECORD_GeometryLanes)) {
		const Dt_RECORD_GeometryLanes *input = (Dt_RECORD_GeometryLanes*)inputPin_DeLanes->GetDataPtr();
		laneInput_T		output;

		rteInConvert_laneInput(input, &output);

		this->Submit("laneInput", &output, sizeof(output));
	}

	if(inputPin_DeFRRGOut->Unflag() && inputPin_DeFRRGOut->GetDataSize() == sizeof(Dt_RECORD_FRRGout)) {
		const Dt_RECORD_FRRGout *input = (Dt_RECORD_FRRGout*)inputPin_DeFRRGOut->GetDataPtr();
		lapInput_T		output;

		rteInConvert_lapInput(input, &output);

		this->Submit("lapInput", &output, sizeof(output));
	}
}


bool	zfasConverterFilter_T::OnInitNormal(void)
{
	return true;
}
