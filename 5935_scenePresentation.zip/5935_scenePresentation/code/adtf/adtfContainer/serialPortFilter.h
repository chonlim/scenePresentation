#ifndef guard_serialPortFilter_h
#define guard_serialPortFilter_h

#include "baseFilter.h"

#include "common/vehicleModel/vehicleModel_private.h"
#include "../ibfFile/ibfFile.h"

#define ADTF_FILTER_ID_serialPortFilter		"IDII.serialPortFilter"
#define ADTF_FILTER_NAME_serialPortFilter		"IDII serialPortFilter"


class serialPortFilter_T
	: public baseFilter_T,
	  public cKernelCyclicThread
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_serialPortFilter, ADTF_FILTER_NAME_serialPortFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	HANDLE		 portHandle;


public:
	serialPortFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	void		OnShutdownNormal(void);

	bool		InitPort(void);

	tResult		CyclicFunc();
};


#endif
