#ifndef guard_rglConverterFilter_h
#define guard_rglConverterFilter_h

#define SKIP_MAGIC_NUMBER

#include "baseFilter.h"

#include <control/psdWrapper/eifTypes.h>


#define ADTF_FILTER_ID_rglConverterFilter		"IDII.rglConverterFilter"
#define ADTF_FILTER_NAME_rglConverterFilter		"IDII rglConverterFilter"


class rglConverterFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_rglConverterFilter, ADTF_FILTER_NAME_rglConverterFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	inputPin_T	*inputPin_canPSD;
	inputPin_T	*inputPin_psdInput;

public:
				 rglConverterFilter_T(const tChar* __info);

	void		 OnReceive(void);


private:
	bool		 Process_CAN(uint32_T id, const uint8_T *data, tTimeStamp time);
	bool		 Process_Input(psdInput_T *input, tTimeStamp time);
};


#endif
