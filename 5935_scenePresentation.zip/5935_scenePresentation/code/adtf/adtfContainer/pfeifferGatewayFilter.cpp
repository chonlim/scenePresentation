#include "stdafx.h"
#include "pfeifferGatewayFilter.h"

#undef		GetObject
#pragma warning(disable : 4355)

#pragma pack(push, 1)
typedef struct canMessage_tag {
	uint16_T	id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


typedef struct canMessageExt_tag {
	uint32_T	id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessageExt_T;
#pragma pack(pop)



pfeifferGatewayFilter_T::pfeifferGatewayFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("flexray",			MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);
	this->AddOutputPin("canKombi",			MEDIA_TYPE_CAN,			MEDIA_SUBTYPE_CAN_RAW_MESSAGE);
	this->AddOutputPin("canKombiExt",		MEDIA_TYPE_CAN,			MEDIA_SUBTYPE_CAN_RAW_MESSAGE_EXT);
}


pfeifferGatewayFilter_T::~pfeifferGatewayFilter_T()
{
}



bool	pfeifferGatewayFilter_T::OnInitNormal(void)
{
	cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
	if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
		LOG_ERROR("No FlexRay support service available");
		return false;
	}


	cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
	if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
		LOG_ERROR("Failed to get FIBEX database");
		return false;
	}


	/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
	cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
	if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
		LOG_ERROR("Failed to create FlexRay coder");
		return false;
	}


	this->flexrayCoder = coder;
	this->flexrayCoder->ResetData();

	this->flexrayCoder->SetListener((groundFilter_T*)this);


	/* Abfragen der IDs f�r die PDUs, die uns interessieren.
	Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
	tUInt32 count;
	fibexDB->GetPDUCount(&count);

	for(tUInt32 i = 0; i < count; i++) {
		const tChar *name;
		fibexDB->GetPDUName(i, &name);

		if(!strcmp(name, "PACC02_02")) {
			this->idPACC02_02 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}

		if(!strcmp(name, "PACC02_03")) {
			this->idPACC02_03 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}

		if(!strcmp(name, "Kombi_01")) {
			this->idKombi_01 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}

		if(!strcmp(name, "ACC_12")) {
			this->idACC_12 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}

		if(!strcmp(name, "ACC_13")) {
			this->idACC_13 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}

		if(!strcmp(name, "GRA_ACC_01")) {
			this->idGRA_ACC_01 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}
	}

	return true;
}


bool	pfeifferGatewayFilter_T::OnGraphReady(void)
{
	return true;
}


void	pfeifferGatewayFilter_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}


tResult	pfeifferGatewayFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	return baseFilter_T::OnPinEvent(pSource, nEventCode, nParam1, nParam2, pMediaSample);
}


void	pfeifferGatewayFilter_T::OnReceive(void)
{
	if(this->GetInputPin("flexray")->Unflag()) {
		if(this->flexrayCoder) {
			this->EnterMutex();

			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
									  (tInt)this->GetInputPin("flexray")->GetDataSize(),
											this->GetInputPin("flexray")->GetTimeStamp());

			this->LeaveMutex();
		}
	}
}


void	pfeifferGatewayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }

		if(coderEvent->nPDUID == this->idPACC02_02) {
			canMessage_T	canMessage = {0};

			canMessage.id		= 970;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombi", &canMessage, sizeof(canMessage));
		}

		if(coderEvent->nPDUID == this->idPACC02_03) {
			canMessageExt_T	canMessage = {0};

			canMessage.id		= 2463978731;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombiExt", &canMessage, sizeof(canMessage));
		}

		if(coderEvent->nPDUID == this->idKombi_01) {
			canMessage_T	canMessage = {0};

			canMessage.id		= 779;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombi", &canMessage, sizeof(canMessage));
		}

		if(coderEvent->nPDUID == this->idACC_12) {
			canMessage_T	canMessage = {0};

			canMessage.id		= 678;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombi", &canMessage, sizeof(canMessage));
		}

		if(coderEvent->nPDUID == this->idACC_13) {
			canMessage_T	canMessage = {0};

			canMessage.id		= 679;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombi", &canMessage, sizeof(canMessage));
		}

		if(coderEvent->nPDUID == this->idGRA_ACC_01) {
			canMessage_T	canMessage = {0};

			canMessage.id		= 299;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombi", &canMessage, sizeof(canMessage));
		}
	}
}
