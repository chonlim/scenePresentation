#include "stdafx.h"
#include "clusterGatewayFilter.h"

#undef		GetObject
#pragma warning(disable : 4355)


typedef struct canMessage_tag {
	int16_T		id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


clusterGatewayFilter_T::clusterGatewayFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("flexray",			MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);
	this->AddOutputPin("canKombi",			MEDIA_TYPE_CAN,			MEDIA_SUBTYPE_CAN_RAW_MESSAGE);
}


clusterGatewayFilter_T::~clusterGatewayFilter_T()
{
}



bool	clusterGatewayFilter_T::OnInitNormal(void)
{
	cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
	if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
		LOG_ERROR("No FlexRay support service available");
		return false;
	}


	cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
	if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
		LOG_ERROR("Failed to get FIBEX database");
		return false;
	}


	/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
	cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
	if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
		LOG_ERROR("Failed to create FlexRay coder");
		return false;
	}


	this->flexrayCoder = coder;
	this->flexrayCoder->ResetData();

	this->flexrayCoder->SetListener((groundFilter_T*)this);


	/* Abfragen der IDs f�r die PDUs, die uns interessieren.
	Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
	tUInt32 count;
	fibexDB->GetPDUCount(&count);

	for(tUInt32 i = 0; i < count; i++) {
		const tChar *name;
		fibexDB->GetPDUName(i, &name);

		if(!strcmp(name, "PACC02_02")) {
			this->idPACC02_02 = i;
			this->flexrayCoder->ActivePDUEvents(i);
		}
	}

	return true;
}


bool	clusterGatewayFilter_T::OnGraphReady(void)
{
	return true;
}


void	clusterGatewayFilter_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}


tResult	clusterGatewayFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	return baseFilter_T::OnPinEvent(pSource, nEventCode, nParam1, nParam2, pMediaSample);
}


void	clusterGatewayFilter_T::OnReceive(void)
{
	if(this->GetInputPin("flexray")->Unflag()) {
		if(this->flexrayCoder) {
			this->EnterMutex();

			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
									  (tInt)this->GetInputPin("flexray")->GetDataSize(),
											this->GetInputPin("flexray")->GetTimeStamp());

			this->LeaveMutex();
		}
	}
}


void	clusterGatewayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }

		if(coderEvent->nPDUID == this->idPACC02_02) {
			canMessage_T	canMessage = {0};

			canMessage.id		= 908;
			canMessage.channel	= 0;
			canMessage.length	= coderEvent->nPayloadLength;
			memcpy(&canMessage.data, coderEvent->pData, sizeof(canMessage.data));

			this->Submit("canKombi", &canMessage, sizeof(canMessage));
		}
	}
}
