#include "stdafx.h"
#include "driverPredictorDisplayFilter.h"

extern "C" {
#include "Algorithmus/control/rteInterface/rteTraceDataOut.h"
}


#undef		GetObject

#define		dp_minPosition		  -55.0f
#define		dp_maxPosition			80.0f
#define		dp_minVelocity		   -100.0f
#define		dp_maxVelocity			600.0f
#define		dp_minAcceleration	    -4.0f
#define		dp_maxAcceleration		 4.0f


#pragma warning(disable : 4355)


driverPredictorDisplayFilter_T::driverPredictorDisplayFilter_T(const tChar* __info)
	: displayFilter_T(__info, dp_minPosition, dp_maxPosition, dp_minVelocity, dp_maxVelocity, dp_minAcceleration, dp_maxAcceleration),
  binHorizonPainter(&this->control->graph),
  binHistoryPainter(&this->control->graph),
  dynamicHistoryPainter(&this->control->graph),
  driverPredictorDisplayPainter(&this->control->graph),
  trajectoryPainter(&this->control->graph),
  wassersteinPainter(&this->control->graph)
{
	this->AddInputPin("pemControl",		pemControl_header());
	this->AddInputPin("vehicleModel",	vehicleModel_header());
	this->AddInputPin("wsDistance",		wassersteinList_header());
	this->AddInputPin("InnoDriveOut_DeTraceData", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("flexray", MEDIA_TYPE_FLEXRAY, MEDIA_SUBTYPE_FLEXRAY);

}


bool	driverPredictorDisplayFilter_T::OnInitNormal(void)
{	
	/* Initialisieren der Painter */
	dynamicHistoryPainter.Init();
	binHorizonPainter.Init();
	driverPredictorDisplayPainter.Init();
	wassersteinPainter.Init();
	binHistoryPainter.Init();
	trajectoryPainter.Init();

	heapFlag	 = false;
	flexrayFlag	 = false;
	frOutputFlag = false;

	vehicleStateTmp.tickCount = 0;

	return true;
}


bool	driverPredictorDisplayFilter_T::OnGraphReady(void)
{
	do{
		if (this->GetInputPin("flexray")->IsConnected()) {
			cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
			if (IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**)&flexrayService))) {
				LOG_ERROR("No FlexRay support service available");
				return false;
			}

			cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
			if (IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
				LOG_ERROR("Failed to get FIBEX database");
				return false;
			}

			/* Abfragen der IDs f�r die PDUs, die uns interessieren.
			Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
			tUInt32 count;
			fibexDB->GetPDUCount(&count);

			for (tUInt32 i = 0; i < count; i++) {
				const tChar *name;
				fibexDB->GetPDUName(i, &name);

				if (!strcmp(name, "PIF_01")) { this->idPIF_01 = i; }
				if (!strcmp(name, "EML_01")) { this->idEML_01 = i; }
				if (!strcmp(name, "EML_03")) { this->idEML_03 = i; }
				if (!strcmp(name, "Motor_16")) { this->idMotor_16 = i; }
				if (!strcmp(name, "Kombi_01")) { this->idKombi_01 = i; }
			}

			cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
			if (IS_FAILED(flexrayService->CreateCoder(&coder))) {
				LOG_ERROR("Failed to create FlexRay coder");
				break;
			}

			fibexDB->GetSignalID("PIF_Identifier", &this->idPIF_Identifier);
			fibexDB->GetSignalID("PIF_LT_Bin_0", &this->idPIF_LT_Bin_0);
			fibexDB->GetSignalID("PIF_LT_Bin_1", &this->idPIF_LT_Bin_1);
			fibexDB->GetSignalID("PIF_LT_Bin_2", &this->idPIF_LT_Bin_2);
			fibexDB->GetSignalID("PIF_LT_Bin_3", &this->idPIF_LT_Bin_3);
			fibexDB->GetSignalID("PIF_LT_Bin_4", &this->idPIF_LT_Bin_4);
			fibexDB->GetSignalID("PIF_LT_Bin_5", &this->idPIF_LT_Bin_5);
			fibexDB->GetSignalID("PIF_LT_Bin_6", &this->idPIF_LT_Bin_6);
			fibexDB->GetSignalID("PIF_LT_Bin_7", &this->idPIF_LT_Bin_7);
			fibexDB->GetSignalID("PIF_LT_Bin_8", &this->idPIF_LT_Bin_8);
			fibexDB->GetSignalID("PIF_LT_Status", &this->idPIF_LT_Status);
			fibexDB->GetSignalID("PIF_MT_Bin_0", &this->idPIF_MT_Bin_0);
			fibexDB->GetSignalID("PIF_MT_Bin_1", &this->idPIF_MT_Bin_1);
			fibexDB->GetSignalID("PIF_MT_Bin_2", &this->idPIF_MT_Bin_2);
			fibexDB->GetSignalID("PIF_MT_Bin_3", &this->idPIF_MT_Bin_3);
			fibexDB->GetSignalID("PIF_MT_Bin_4", &this->idPIF_MT_Bin_4);
			fibexDB->GetSignalID("PIF_MT_Bin_5", &this->idPIF_MT_Bin_5);
			fibexDB->GetSignalID("PIF_MT_Bin_6", &this->idPIF_MT_Bin_6);
			fibexDB->GetSignalID("PIF_MT_Bin_7", &this->idPIF_MT_Bin_7);
			fibexDB->GetSignalID("PIF_MT_Bin_8", &this->idPIF_MT_Bin_8);
			fibexDB->GetSignalID("PIF_MT_Status", &this->idPIF_MT_Status);
			fibexDB->GetSignalID("PIF_ST_Bin_0", &this->idPIF_ST_Bin_0);
			fibexDB->GetSignalID("PIF_ST_Bin_1", &this->idPIF_ST_Bin_1);
			fibexDB->GetSignalID("PIF_ST_Bin_2", &this->idPIF_ST_Bin_2);
			fibexDB->GetSignalID("PIF_ST_Bin_3", &this->idPIF_ST_Bin_3);
			fibexDB->GetSignalID("PIF_ST_Bin_4", &this->idPIF_ST_Bin_4);
			fibexDB->GetSignalID("PIF_ST_Bin_5", &this->idPIF_ST_Bin_5);
			fibexDB->GetSignalID("PIF_ST_Bin_6", &this->idPIF_ST_Bin_6);
			fibexDB->GetSignalID("PIF_ST_Bin_7", &this->idPIF_ST_Bin_7);
			fibexDB->GetSignalID("PIF_ST_Bin_8", &this->idPIF_ST_Bin_8);
			fibexDB->GetSignalID("PIF_ST_Status", &this->idPIF_ST_Status);

			fibexDB->GetSignalID("EML_GeschwX", &this->idEML_GeschwX);
			fibexDB->GetSignalID("EML_BeschlX", &this->idEML_BeschlX);
			fibexDB->GetSignalID("EML_BeschlY", &this->idEML_BeschlY);
			fibexDB->GetSignalID("TSK_Steigung_02", &this->idTSK_Steigung_02);
			fibexDB->GetSignalID("KBI_angez_Geschw", &this->idKBI_angez_Geschw);

			this->flexrayCoder = coder;
			this->flexrayCoder->SetListener((groundFilter_T*)this);

			this->flexrayCoder->ActivePDUEvents(this->idPIF_01);
			this->flexrayCoder->ActivePDUEvents(this->idEML_01);
			this->flexrayCoder->ActivePDUEvents(this->idEML_03);
			this->flexrayCoder->ActivePDUEvents(this->idMotor_16);
			this->flexrayCoder->ActivePDUEvents(this->idKombi_01);
		}
	}while (false);

	return true;
}


void	driverPredictorDisplayFilter_T::OnShutdownNormal(void)
{
	if (this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}

void	driverPredictorDisplayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	if (type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		adtf_devicetb::tCoderPDUEvent *coderEvent = (adtf_devicetb::tCoderPDUEvent*)data;
		if (!coderEvent) { return; }

		if (coderEvent->nPayloadLength == 8) {

			if (coderEvent->nPDUID == this->idPIF_01) {
				flexrayFlag = true;
				this->vehicleStateTmp.tickCount = this->vehicleStateTmp.tickCount + 4;
				demuxPIFSignal();
				runAlgorithm();
			}

			if (coderEvent->nPDUID == this->idEML_01) {

				adtf_devicetb::tSignalValue EML_BeschlX;
				this->flexrayCoder->GetSignalValue(this->idEML_BeschlX, &EML_BeschlX);
				this->vehicleStateTmp.unfiltered.longAcceleration = (real32_T)EML_BeschlX.nf64Value;
			}
			if (coderEvent->nPDUID == this->idEML_03) {

				adtf_devicetb::tSignalValue EML_BeschlY;
				this->flexrayCoder->GetSignalValue(this->idEML_BeschlY, &EML_BeschlY);
				this->vehicleStateTmp.unfiltered.latAcceleration = (real32_T)EML_BeschlY.nf64Value;
			}
			if (coderEvent->nPDUID == this->idKombi_01) {

				adtf_devicetb::tSignalValue KBI_angez_Geschw;
				this->flexrayCoder->GetSignalValue(this->idKBI_angez_Geschw, &KBI_angez_Geschw);
				this->vehicleStateTmp.velocity.velocity = (real32_T)KBI_angez_Geschw.nf64Value/3.6f;
			}

			if (coderEvent->nPDUID == this->idMotor_16) {

				adtf_devicetb::tSignalValue TSK_Steigung_02;
				this->flexrayCoder->GetSignalValue(this->idTSK_Steigung_02, &TSK_Steigung_02);
				this->vehicleStateTmp.slope.slope = (real32_T)TSK_Steigung_02.nf64Value/100.0f;
			}
		}
	}
	else
	{
	}
}

void	driverPredictorDisplayFilter_T::OnReceive(void)
{
	Dt_RECORD_TraceData *traceData;

	if(this->GetInputPin("flexray")->Unflag()) {
		if (this->flexrayCoder) {
			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
											(tInt)this->GetInputPin("flexray")->GetDataSize(),
											this->GetInputPin("flexray")->GetTimeStamp());
		}
	}
	if (this->GetInputPin("InnoDriveOut_DeTraceData")->Unflag()) {
		traceData = (Dt_RECORD_TraceData *)this->GetInputPin("InnoDriveOut_DeTraceData")->GetDataPtr();
		rteInConvert_traceData(traceData, &this->controlHeapTmp.driverState, &this->controlHeapTmp.dprdDebugBuffer);
	}
	if (this->GetInputPin("pemControl")->Unflag()){
		this->runAlgorithm();
	}

}

void driverPredictorDisplayFilter_T::runAlgorithm()
{
	static real32_T	 lastTime	 = 0.0f;
	real32_T		 timeOF		 = 0.0f;
	real32_T		 time		 = 0.0f;

	driverState_T		*driverState   = &this->controlHeapTmp.driverState;
	flexrayOutput_T		*flexrayOutput = &this->flexrayOutputTmp;
	vehicleState_T		*vehicleState  = &this->vehicleStateTmp;
	pemControlHeap_T	*controlHeap   = &this->controlHeapTmp;

	this->EnterMutex();
		vehicleModel_T		*vehicleModel	= (vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();
		wassersteinList_T	*wsList			= (wassersteinList_T*)this->GetInputPin("wsDistance")->GetDataPtr();
		pemControl_T		*pemControl		= (pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();
	this->LeaveMutex();
	
	if (flexrayOutput->DePIF_Identifier == PIF_Identifier_Strassenklasse)
	{
		for (uint8_T i = 0; i < dprdTHINNEDTRAJECTORY_COUNT; i++)
		{
			controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory.vector[i].latAcceleration = controlHeapTmp.dprdDebugBuffer.trajectoryLatAccelOut[i];
			controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory.vector[i].longAcceleration = controlHeapTmp.dprdDebugBuffer.trajectoryLonAccelOut[i];
			controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory.vector[i].wheelPower = controlHeapTmp.dprdDebugBuffer.trajectoryWhlPowerOut[i];
			controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory.vector[i].position = controlHeapTmp.dprdDebugBuffer.trajectoryPositionOut[i];
			controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory.vector[i].velocity = controlHeapTmp.dprdDebugBuffer.trajectoryVelocityOut[i];
			controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory.count = i;
		}
	}
	
	this->control->graph.MutexEnter();
	
	lastTime	= timeOF;
	time		= vehicleState->tickCount * controlCYCLETIME;
	timeOF		= time;


	/*Zeichnen des Displays*/
	/*velocity layer*/
	driverPredictorDisplayPainter.process_velocityLayer(timeOF);
	driverPredictorDisplayPainter.process_latAccelLayer(vehicleState, timeOF);
	driverPredictorDisplayPainter.process_lonAccelLayer(vehicleState, timeOF);
	driverPredictorDisplayPainter.process_powerLayer(vehicleState, timeOF);
	driverPredictorDisplayPainter.process_streetCatLayer(vehicleState, timeOF);
	
	/*Bisherige Fahrdynamikwerte plotten */
	dynamicHistoryPainter.process_developersInfo(vehicleState, driverState, timeOF);
	dynamicHistoryPainter.Process_velocity(vehicleState, driverState, timeOF);
	dynamicHistoryPainter.Process_latAccel(vehicleState, driverState, timeOF);
	dynamicHistoryPainter.Process_lonAccel(vehicleState, driverState, timeOF);
	dynamicHistoryPainter.Process_power(vehicleState, driverState, vehicleModel, timeOF);
	
	wassersteinPainter.Process_velocity(vehicleState, wsList->wsDistance, 0);
	wassersteinPainter.Process_velocity(vehicleState, wsList->wsDistance, 1);
	wassersteinPainter.Process_velocity(vehicleState, wsList->wsDistance, 2);

	wassersteinPainter.Process_lonAccel(vehicleState, wsList->wsDistance, 0);
	wassersteinPainter.Process_lonAccel(vehicleState, wsList->wsDistance, 1);
	wassersteinPainter.Process_lonAccel(vehicleState, wsList->wsDistance, 2);

	wassersteinPainter.Process_latAccel(vehicleState, wsList->wsDistance, 0);
	wassersteinPainter.Process_latAccel(vehicleState, wsList->wsDistance, 1);
	wassersteinPainter.Process_latAccel(vehicleState, wsList->wsDistance, 2);

	wassersteinPainter.Process_power(vehicleState, vehicleModel, wsList->wsDistance, 0);
	wassersteinPainter.Process_power(vehicleState, vehicleModel, wsList->wsDistance, 1);
	wassersteinPainter.Process_power(vehicleState, vehicleModel, wsList->wsDistance, 2);
	
	/*Vorausschau Historie Plotten*/
	binHistoryPainter.Process(flexrayOutput, vehicleState, timeOF);

	/*Vorausschau plotten*/
	binHorizonPainter.Process(flexrayOutput, timeOF);
	
	/*Trajektorie plotten*/
	trajectoryPainter.Process_velocity(&controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory, vehicleState);
	trajectoryPainter.Process_latAccel(&controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory, vehicleState);
	trajectoryPainter.Process_lonAccel(&controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory, vehicleState);
	trajectoryPainter.Process_wheelpower(&controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory, vehicleState);

	
	this->control->graph.MutexLeave();
}

void	driverPredictorDisplayFilter_T::PrePaint(void)
{

}

void driverPredictorDisplayFilter_T::demuxPIFSignal(void)
{
	static driverPrediction_T	driverPrediction;
	static flexrayOutput_T		flexrayOutput;

	adtf_devicetb::tSignalValue					PIF_Identifier;
	adtf_devicetb::tSignalValue					PIF_LT_Bin[dprdBIN_COUNT];
	adtf_devicetb::tSignalValue					PIF_LT_Status;
	adtf_devicetb::tSignalValue					PIF_MT_Bin[dprdBIN_COUNT];
	adtf_devicetb::tSignalValue					PIF_MT_Status;
	adtf_devicetb::tSignalValue					PIF_ST_Bin[dprdBIN_COUNT];
	adtf_devicetb::tSignalValue					PIF_ST_Status;
	adtf_devicetb::tSignalValue					PIF_Toggle;

	this->flexrayCoder->GetSignalValue(this->idPIF_Identifier, &PIF_Identifier);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_0, &PIF_LT_Bin[0]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_1, &PIF_LT_Bin[1]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_2, &PIF_LT_Bin[2]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_3, &PIF_LT_Bin[3]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_4, &PIF_LT_Bin[4]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_5, &PIF_LT_Bin[5]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_6, &PIF_LT_Bin[6]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_7, &PIF_LT_Bin[7]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_8, &PIF_LT_Bin[8]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Status, &PIF_LT_Status);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_0, &PIF_MT_Bin[0]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_1, &PIF_MT_Bin[1]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_2, &PIF_MT_Bin[2]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_3, &PIF_MT_Bin[3]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_4, &PIF_MT_Bin[4]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_5, &PIF_MT_Bin[5]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_6, &PIF_MT_Bin[6]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_7, &PIF_MT_Bin[7]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_8, &PIF_MT_Bin[8]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Status, &PIF_MT_Status);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_0, &PIF_ST_Bin[0]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_1, &PIF_ST_Bin[1]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_2, &PIF_ST_Bin[2]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_3, &PIF_ST_Bin[3]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_4, &PIF_ST_Bin[4]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_5, &PIF_ST_Bin[5]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_6, &PIF_ST_Bin[6]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_7, &PIF_ST_Bin[7]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_8, &PIF_ST_Bin[8]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Status, &PIF_ST_Status);
	this->flexrayCoder->GetSignalValue(this->idPIF_Toggle, &PIF_Toggle);

	this->flexrayOutputTmp = flexrayOutput;

	flexrayOutput.DePIF_Identifier = (uint8_T)PIF_Identifier.nf64Value;
	flexrayOutput.DePIF_LT_Bin_0 = (uint8_T)PIF_LT_Bin[0].nf64Value;
	flexrayOutput.DePIF_LT_Bin_1 = (uint8_T)PIF_LT_Bin[1].nf64Value;
	flexrayOutput.DePIF_LT_Bin_2 = (uint8_T)PIF_LT_Bin[2].nf64Value; 
	flexrayOutput.DePIF_LT_Bin_3 = (uint8_T)PIF_LT_Bin[3].nf64Value;
	flexrayOutput.DePIF_LT_Bin_4 = (uint8_T)PIF_LT_Bin[4].nf64Value;
	flexrayOutput.DePIF_LT_Bin_5 = (uint8_T)PIF_LT_Bin[5].nf64Value;
	flexrayOutput.DePIF_LT_Bin_6 = (uint8_T)PIF_LT_Bin[6].nf64Value;
	flexrayOutput.DePIF_LT_Bin_7 = (uint8_T)PIF_LT_Bin[7].nf64Value;
	flexrayOutput.DePIF_LT_Bin_8 = (uint8_T)PIF_LT_Bin[8].nf64Value;
	flexrayOutput.DePIF_LT_Status = (uint8_T)PIF_LT_Status.nf64Value;

	flexrayOutput.DePIF_MT_Bin_0 = (uint8_T)PIF_MT_Bin[0].nf64Value;
	flexrayOutput.DePIF_MT_Bin_1 = (uint8_T)PIF_MT_Bin[1].nf64Value;
	flexrayOutput.DePIF_MT_Bin_2 = (uint8_T)PIF_MT_Bin[2].nf64Value;
	flexrayOutput.DePIF_MT_Bin_3 = (uint8_T)PIF_MT_Bin[3].nf64Value;
	flexrayOutput.DePIF_MT_Bin_4 = (uint8_T)PIF_MT_Bin[4].nf64Value;
	flexrayOutput.DePIF_MT_Bin_5 = (uint8_T)PIF_MT_Bin[5].nf64Value;
	flexrayOutput.DePIF_MT_Bin_6 = (uint8_T)PIF_MT_Bin[6].nf64Value;
	flexrayOutput.DePIF_MT_Bin_7 = (uint8_T)PIF_MT_Bin[7].nf64Value;
	flexrayOutput.DePIF_MT_Bin_8 = (uint8_T)PIF_MT_Bin[8].nf64Value;
	flexrayOutput.DePIF_MT_Status = (uint8_T)PIF_MT_Status.nf64Value;

	flexrayOutput.DePIF_ST_Bin_0 = (uint8_T)PIF_ST_Bin[0].nf64Value;
	flexrayOutput.DePIF_ST_Bin_1 = (uint8_T)PIF_ST_Bin[1].nf64Value;
	flexrayOutput.DePIF_ST_Bin_2 = (uint8_T)PIF_ST_Bin[2].nf64Value;
	flexrayOutput.DePIF_ST_Bin_3 = (uint8_T)PIF_ST_Bin[3].nf64Value;
	flexrayOutput.DePIF_ST_Bin_4 = (uint8_T)PIF_ST_Bin[4].nf64Value;
	flexrayOutput.DePIF_ST_Bin_5 = (uint8_T)PIF_ST_Bin[5].nf64Value;
	flexrayOutput.DePIF_ST_Bin_6 = (uint8_T)PIF_ST_Bin[6].nf64Value;
	flexrayOutput.DePIF_ST_Bin_7 = (uint8_T)PIF_ST_Bin[7].nf64Value;
	flexrayOutput.DePIF_ST_Bin_8 = (uint8_T)PIF_ST_Bin[8].nf64Value;
	flexrayOutput.DePIF_ST_Status = (uint8_T)PIF_ST_Status.nf64Value;

	switch ((uint8_T)PIF_Identifier.nf64Value)
	{
	case (uint8_T)PIF_Identifier_Init:
		break;
	case (uint8_T)PIF_Identifier_Geschwindigkeit:

		this->driverPredictionTmp = driverPrediction;
		memset(&driverPrediction, 0, sizeof(driverPrediction_T));

		if ((uint8_T)PIF_ST_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.shortTermWindow.velocity[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_MT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.midTermWindow.velocity[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_LT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.longTermWindow.velocity[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
			}
		}
		break;
	case (uint8_T)PIF_Identifier_Laengsbeschleunigung:
		if ((uint8_T)PIF_ST_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.shortTermWindow.longAcceleration[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_MT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.midTermWindow.longAcceleration[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_LT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.longTermWindow.longAcceleration[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
			}
		}
		break;
	case (uint8_T)PIF_Identifier_Leistung:
		if ((uint8_T)PIF_ST_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.shortTermWindow.wheelPower[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_MT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.midTermWindow.wheelPower[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_LT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.longTermWindow.wheelPower[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
			}
		}
		break;
	case (uint8_T)PIF_Identifier_Querbeschleunigung:
		if ((uint8_T)PIF_ST_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.shortTermWindow.absLatAcceleration[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_MT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.midTermWindow.absLatAcceleration[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_LT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.longTermWindow.absLatAcceleration[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
			}
		}
		break;
	case (uint8_T)PIF_Identifier_Strassenklasse:
		if ((uint8_T)PIF_ST_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.shortTermWindow.streetClass[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_MT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.midTermWindow.streetClass[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
			}
		}
		if ((uint8_T)PIF_LT_Status.nf64Value == 2)
		{
			for (size_t i = 0; i < dprdBIN_COUNT; i++)
			{
				driverPrediction.longTermWindow.streetClass[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
			}
		}
		break;
	default:
		break;
	}
}
