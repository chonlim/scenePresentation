#include "stdafx.h"
#include "dobsHistDisplayFilter.h"


#undef		GetObject
#include "common/swcCommunication/swcComm_adtfTools.h"
#include "common/vehicleModel/vehicleModel_adtfTools.h"
#include "control/controlTask/controlTask_adtfTools.h"
#include "strategy/strategyTask/strategyTask_adtfTools.h"
#include "control/outputCodec/outputCodec_adtfTools.h"

#include "tools/rpl2Tools/psdProcessor/pprWGS84.h"

extern "C" {
#include "control/rteInterface/rteTraceDataOut.h"
}

#define		dobs_minAcceleration	 -1.0f
#define		dobs_maxAcceleration	  5.0f


#pragma warning(disable : 4355)


dobsHistDisplayFilter_T::dobsHistDisplayFilter_T(const tChar* __info)
	: displayFilter_T(__info, dobs_minPosition-10, dobs_maxPosition+10, dobs_minAcceleration-1.0f, dobs_maxAcceleration+1.0f, dobs_minVelocity-1.0f, dobs_maxVelocity+1.0f),
  dobsHistPainter(&this->control->graph)
{
	this->AddInputPin("InnoDriveOut_DeTraceData",	 MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("flexray",					 MEDIA_TYPE_FLEXRAY, MEDIA_SUBTYPE_FLEXRAY);

}


bool	dobsHistDisplayFilter_T::OnInitNormal(void)
{	
	/* Initialisieren der Painter */

	tickCount = 0;
	dobsHistPainter.Init();

	return true;
}


bool	dobsHistDisplayFilter_T::OnGraphReady(void)
{
	do{
		if (this->GetInputPin("flexray")->IsConnected()) {
			cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
			if (IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**)&flexrayService))) {
				LOG_ERROR("No FlexRay support service available");
				return false;
			}

			cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
			if (IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
				LOG_ERROR("Failed to get FIBEX database");
				return false;
			}
			tUInt32 count;
			fibexDB->GetPDUCount(&count);

			for (tUInt32 i = 0; i < count; i++) {
				const tChar *name;
				fibexDB->GetPDUName(i, &name);

				if (!strcmp(name, "PIF_01")) { this->idPIF_01 = i; }

			}

			cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
			if (IS_FAILED(flexrayService->CreateCoder(&coder))) {
				LOG_ERROR("Failed to create FlexRay coder");
				break;
			}
			/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
			this->flexrayCoder = coder;
			this->flexrayCoder->SetListener((groundFilter_T*)this);


			this->flexrayCoder->ActivePDUEvents(this->idPIF_01);
		}
	}while (false);

	return true;
}


void	dobsHistDisplayFilter_T::OnShutdownNormal(void)
{
	if (this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}

void	dobsHistDisplayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	uint8_T test = 1;
	if (type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		adtf_devicetb::tCoderPDUEvent *coderEvent = (adtf_devicetb::tCoderPDUEvent*)data;
		if (!coderEvent) { return; }

		if (coderEvent->nPayloadLength == 8) {

			if (coderEvent->nPDUID == this->idPIF_01) {
	
				this->tickCount++;
			}
		}
	}
	else
	{

	}
}


void	dobsHistDisplayFilter_T::OnReceive(void)
{
	if (this->GetInputPin("flexray")->Unflag()) {
		if (this->flexrayCoder) {
			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
				(tInt)this->GetInputPin("flexray")->GetDataSize(),
				this->GetInputPin("flexray")->GetTimeStamp());


		}
	}
	else if (this->GetInputPin("InnoDriveOut_DeTraceData")->Unflag()) {
		Dt_RECORD_TraceData *traceData;
		driverPredictorDebugBuffer_T dprdDebugBuffer;		

		traceData = (Dt_RECORD_TraceData *)this->GetInputPin("InnoDriveOut_DeTraceData")->GetDataPtr();

		rteInConvert_traceData(traceData, &this->driverState, &dprdDebugBuffer);

		this->control->graph.MutexEnter();

		runAlgorithm();

		this->control->graph.MutexLeave();

	}
}

void dobsHistDisplayFilter_T::runAlgorithm()
{
	real32_T time = 0.0f;
	static real32_T timeOF	= 0.0f;

	
	time = tickCount * 0.08f;
	if (time < timeOF){
		time = time + timeOF;
	}
	timeOF = time;

	/*velocity*/
	dobsHistPainter.processObserverParameter(&this->driverState,
											  timeOF);	
}

void	dobsHistDisplayFilter_T::PrePaint(void)
{

}

