#include "stdafx.h"
#include "waveFile.h"


waveFile_T::waveFile_T(void) {
	this->file			= INVALID_HANDLE_VALUE;
	this->dataSize		= 0;
	this->headerSize	= 0;
}


waveFile_T::~waveFile_T() {
	this->Close();
}


bool	waveFile_T::Open(const char_T *fileName, const uint16_T numChannels, const uint32_T samplesPerSecond, const uint32_T bitsPerSample)
{
	this->Close();

	this->file = CreateFileA(fileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, NULL, NULL);

	if(this->file == INVALID_HANDLE_VALUE) {
		return false;
	}

	this->WriteWaveHeader(numChannels, samplesPerSecond, bitsPerSample);

	return true;
}


bool	waveFile_T::AddData(const int16_T *data, const uint16_T size)
{
	DWORD bytesWritten;

	if(!WriteFile(this->file, data, size, &bytesWritten, NULL) || bytesWritten != size) {
		return false;
	}

	this->dataSize += bytesWritten;

	return true;
}


bool	waveFile_T::Close(void)
{
	if(this->file != INVALID_HANDLE_VALUE) {
		this->FinalizeAudioData();
		CloseHandle(this->file);
	}

	this->file			= INVALID_HANDLE_VALUE;
	this->dataSize		= 0;
	this->headerSize	= 0;

	return true;
}


bool	waveFile_T::IsFileOpen(void)
{
	return this->file != INVALID_HANDLE_VALUE;
}


bool	waveFile_T::WriteWaveHeader(const uint16_T numChannels, const uint32_T samplesPerSecond, const uint32_T bitsPerSample)
{
	DWORD bytesWritten;

	/* 1 - 4  "RIFF"	Marks the file as a riff file.Characters are each 1 byte long. */
	if(!WriteFile(this->file, "RIFF", 4, &bytesWritten, NULL) || bytesWritten != 4) { return false; }
	this->headerSize += bytesWritten;


	/*  5 - 8			File size(integer)  Size of the overall file - 8 bytes, in bytes(32 - bit integer).Typically, you'd fill this in after creation. */
	if(!WriteFile(this->file, &this->dataSize, sizeof(this->dataSize), &bytesWritten, NULL) || bytesWritten != sizeof(this->dataSize)) { return false; }
	this->headerSize += bytesWritten;


	/*  9 - 12  "WAVE"	File Type Header.For our purposes, it always equals "WAVE". */
	if(!WriteFile(this->file, "WAVE", 4, &bytesWritten, NULL) || bytesWritten != 4) { return false; }
	this->headerSize += bytesWritten;


	/* 13 - 16  "fmt "	Format chunk marker.Includes trailing null */
	if(!WriteFile(this->file, "fmt ", 4, &bytesWritten, NULL) || bytesWritten != 4) { return false; }
	this->headerSize += bytesWritten;


	/* 17 - 20  16		Length of format data as listed above */
	if(!this->WriteBigEndian(16, 4)) { return false; }
	this->headerSize += 4;


	/* 21 - 22  1		Type of format(1 is PCM) - 2 byte integer */
	if(!this->WriteBigEndian(SF_FORMAT_PCM, 2)) { return false; }    /* PCM is format 1 */
	this->headerSize += 2;


	/* 23 - 24  1		Number of Channels - 2 byte integer */
	if(!this->WriteBigEndian(numChannels, 2)) { return false; }
	this->headerSize += 2;


	/* 25 - 28  44100	Sample Rate - 32 byte integer.Common values are 44100 (CD), 48000 (DAT).Sample Rate = Number of Samples per second, or Hertz. */
	if(!this->WriteBigEndian(samplesPerSecond, 4)) { return false; }
	this->headerSize += 4;


	/* 29 - 32  88200	(Sample Rate * BitsPerSample * Channels) / 8 */
	if(!this->WriteBigEndian(samplesPerSecond * 16 / 8, 4)) { return false; }
	this->headerSize += 4;


	/* 33 - 34  4		(BitsPerSample * Channels) / 8. 1 - 8 bit mono, 2 - 8 bit stereo / 16 bit mono4 - 16 bit stereo */
	if(!this->WriteBigEndian((numChannels * bitsPerSample + 7) / 8, 2)) { return false; }  /* block align */
	this->headerSize += 2;


	/* 35 - 36  16		Bits per sample */
	if(!this->WriteBigEndian(bitsPerSample, 2)) { return false; }
	this->headerSize += 2;


	/* 37 - 40  "data"	"data" chunk header.Marks the beginning of the data section. */
	if(!WriteFile(this->file, "data", 4, &bytesWritten, NULL) || bytesWritten != 4) { return false; }
	this->headerSize += bytesWritten;


	/* 41 - 44   File size(data)  write L�nge des Datenblocks = Deteigr��e  - 44, wird mit 0 initialisert */
	if(!WriteFile(this->file, &this->dataSize, sizeof(this->dataSize), &bytesWritten, NULL) || bytesWritten != sizeof(this->dataSize)) { return false; }
	this->headerSize += bytesWritten;


	return true;
}


bool	waveFile_T::WriteBigEndian(int32_T data, uint32_T numBytes)
{
	DWORD	bytesWritten;

	if(!WriteFile(this->file, &data, numBytes, &bytesWritten, NULL) || bytesWritten != numBytes) {
		return false;
	}

	return true;
}


bool	waveFile_T::FinalizeAudioData(void)
{
	DWORD bytesWritten;


	if(INVALID_SET_FILE_POINTER == SetFilePointer(this->file, this->headerSize - sizeof(DWORD), NULL, FILE_BEGIN)) {
		return false;
	}


	if(!WriteFile(this->file, &this->dataSize, sizeof(this->dataSize), &bytesWritten, NULL) || bytesWritten != sizeof(this->dataSize)){
		return false;
	}


	if(INVALID_SET_FILE_POINTER == SetFilePointer(this->file, 4, NULL, FILE_BEGIN)) {
		return false;
	}


	DWORD riffSize = this->headerSize + this->dataSize - 8;
	if(!WriteFile(this->file, &riffSize, sizeof(riffSize), &bytesWritten, NULL) || bytesWritten != sizeof(riffSize)) {
		return false;
	}


	return true;
}
