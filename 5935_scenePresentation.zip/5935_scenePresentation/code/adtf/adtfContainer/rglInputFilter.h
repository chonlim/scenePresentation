#ifndef guard_rglInputFilter_h
#define guard_rglInputFilter_h

#define SKIP_MAGIC_NUMBER

#include "baseFilter.h"


#define ADTF_FILTER_ID_rglInputFilter		"IDII.rglInputFilter"
#define ADTF_FILTER_NAME_rglInputFilter	"IDII rglInputFilter"


class rglInputFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_rglInputFilter, ADTF_FILTER_NAME_rglInputFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
public:
				 rglInputFilter_T(const tChar* __info);

	void		 OnReceive(void);
};


#endif
