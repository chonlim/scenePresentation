#include "stdafx.h"
#include "vehicleModelFilter.h"

#include "base.h"
#include "common/vehicleModel/vehicleModel_adtfTools.h"

vehicleModelFilter_T::vehicleModelFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddOutputPin("vehicleModel",			vehicleModel_header());

	this->SetPropertyStr("dataFile", "$CFGDIR$\\..\\..\\..\\data\\vehicleModels\\991C4S.ibf");
	this->SetPropertyBool("dataFile" NSSUBPROP_FILENAME, tTrue);
}


bool	vehicleModelFilter_T::OnInitNormal(void)
{
	if(!this->ibf.OpenRead(this->GetPropertyStr("dataFile"))) {
		char message[1024];

		sprintf_s(message, "Failed to load vehicleModel file  \"%s\".", this->GetPropertyStr("dataFile"));

		this->ShowErrorBox(message, "vehicleModelFilter");
		LOG_ERROR(message);

		return false;
	}

	return true;
}


bool	vehicleModelFilter_T::OnStart(void)
{
	this->Submit("vehicleModel", ibf.GetData(), sizeof(vehicleModel_T));

	return true;
}
