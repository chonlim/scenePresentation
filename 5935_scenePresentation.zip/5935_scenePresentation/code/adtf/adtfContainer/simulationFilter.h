#ifndef guard_simulationFilter_h
#define guard_simulationFilter_h

#include "baseFilter.h"

#include "../testVector/testVector.h"
#include "tools/rpl2Tools/rpl2Simulation.h"

#include "strategy/strategyTask/strategyTask_private.h"
#include "simulation/vehicleSimulation/vehicleSimulation_private.h"

#define simPSDMESSAGECOUNT		64

#define ADTF_FILTER_ID_simulationFilter		"IDII.simulationFilter"
#define ADTF_FILTER_NAME_simulationFilter	"IDII simulationFilter"


class simulationFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_simulationFilter, ADTF_FILTER_NAME_simulationFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	vehicleSimulation_T		vehicleSimulation;
	rpl2Simulation_T		replay;
	bufferedTestVector_T	testVector;


	struct _psdBuffer {
		uint16_T		count;
		uint16_T		offset;
		psdInput_T		psdInput[simPSDMESSAGECOUNT];
	} psdBuffer;


public:
	simulationFilter_T(const tChar* __info);

	void		OnReceive(void);
	bool		OnInitNormal(void);

private:
	void		QueueMessage(psdInput_T *psdInput);
	void		RunAlgorithm(void);
};


#endif
