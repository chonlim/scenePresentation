#ifndef guard_parameterSetFilter_h
#define guard_parameterSetFilter_h

#include "baseFilter.h"

#include "control/parameterSet/ParameterSetCtrl_private.h"
#include "strategy/parameterSet/parameterSetStgy_private.h"

#define ADTF_FILTER_ID_parameterSetFilter		"IDII.parameterSetFilter"
#define ADTF_FILTER_NAME_parameterSetFilter		"IDII parameterSetFilter"


class parameterSetFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_parameterSetFilter, ADTF_FILTER_NAME_parameterSetFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

	typedef struct readContext_tag {
		class parameterSetFilter_T	*filter;
		const char					*nameChanged;
	} readContext_T;

private:
	parameterSetCtrl_T		controlSet;
	parameterSetStgy_T		strategySet;

	bool_T					armed;

public:
	parameterSetFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	bool		OnStart(void);

	void		OnPropertyChange(const char_T *name);

private:
	static int32_T		CreateProperty_int(const void* thisPtr, const char *name, const char *description, int32_T  value);
	static real64_T		CreateProperty_real(const void* thisPtr, const char *name, const char *description, real64_T  value);
	static bool_T		CreateProperty_bool(const void* thisPtr, const char *name, const char *description, bool_T  value);

	static int32_T		ReadProperty_int(const void* thisPtr, const char *name, const char *description, int32_T  value);
	static real64_T		ReadProperty_real(const void* thisPtr, const char *name, const char *description, real64_T  value);
	static bool_T		ReadProperty_bool(const void* thisPtr, const char *name, const char *description, bool_T  value);
};


#endif
