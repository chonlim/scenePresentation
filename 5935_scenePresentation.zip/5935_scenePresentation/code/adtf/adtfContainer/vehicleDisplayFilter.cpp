#include "stdafx.h"
#include "vehicleDisplayFilter.h"

#include "common/vehicleObserverCommon/vehicleObserver_adtfTools.h"
#include "common/vehicleModel/vehicleModel_adtfTools.h"
#include "common/swcCommunication/swcComm_adtfTools.h"
#include "control/controlTask/controlTask_adtfTools.h"
#include "strategy/strategyTask/strategyTask_adtfTools.h"

#include "../../Lib/rapidxml/rapidxml.hpp"
#include "../../Lib/rapidxml/rapidxml_print.hpp"

extern "C" {
	#include "common/platformInterface/pltfDiag.h"
}


#undef GetObject

#define		def_minPosition		-100.0f
#define		def_maxPosition		 400.0f
#define		def_minVelocity		   0.0f
#define		def_maxVelocity		  50.0f
#define		def_minAcceleration	  -4.0f
#define		def_maxAcceleration	   4.0f


extern bool_T	globalToggle;


#pragma warning(disable : 4355)



typedef struct canMessage_tag {
	int16_T		id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


vehicleDisplayFilter_T::vehicleDisplayFilter_T(const tChar* __info)
  : displayFilter_T(__info, def_minPosition, def_maxPosition, def_minVelocity, def_maxVelocity, def_minAcceleration, def_maxAcceleration),
    sceneContainer(nullptr)
{
	this->AddInputPin("pemControl",		pemControl_header());
	this->AddInputPin("controlStack",	pemControlStack_header());
	this->AddInputPin("controlHeap",	pemControlHeap_header());

	this->AddInputPin("pemPlanning",	pemPlanning_header());
	this->AddInputPin("planningHeap",	pemPlanningHeap_header());
	this->AddInputPin("planningStack",	pemPlanningStack_header());

	this->AddInputPin("vehicleModel",	vehicleModel_header());

	this->AddInputPin("canPSD",			MEDIA_TYPE_CAN,				MEDIA_SUBTYPE_CAN_RAW_MESSAGE);
	this->AddInputPin("flexrayPSD",		MEDIA_TYPE_FLEXRAY,			MEDIA_SUBTYPE_FLEXRAY);
	this->AddInputPin("nmea",			MEDIA_TYPE_STRUCTURED_DATA,	MEDIA_SUBTYPE_STRUCT_UINT8);
	this->AddInputPin("psdInput",		MEDIA_TYPE_STRUCTURED_DATA,	0);

	this->AddInputPin("measurementTrigger",	"uint16",	sizeof(uint16_T));
	this->AddInputPin("curveCategory",		"int8",		sizeof(int8_T));

	this->AddOutputPin("evaluatedScenes",	MEDIA_TYPE_STRUCTURED_DATA,		MEDIA_SUBTYPE_STRUCT_UINT16);

	this->inputPin_pemControl			= this->GetInputPin("pemControl");
	this->inputPin_controlStack			= this->GetInputPin("controlStack");
	this->inputPin_controlHeap			= this->GetInputPin("controlHeap");

	this->inputPin_pemPlanning			= this->GetInputPin("pemPlanning");
	this->inputPin_planningHeap			= this->GetInputPin("planningHeap");
	this->inputPin_planningStack		= this->GetInputPin("planningStack");

	this->inputPin_vehicleModel			= this->GetInputPin("vehicleModel");

	this->inputPin_canPSD				= this->GetInputPin("canPSD");
	this->inputPin_flexrayPSD			= this->GetInputPin("flexrayPSD");
	this->inputPin_nmea					= this->GetInputPin("nmea");
	this->inputPin_psdInput				= this->GetInputPin("psdInput");

	this->inputPin_measurementTrigger	= this->GetInputPin("measurementTrigger");
	this->inputPin_curveCategory		= this->GetInputPin("curveCategory");


	/* Dateiname f�r das Erstellen einer PSD-Trace-Datei */
	this->SetPropertyStr("psdTraceFile",	"");
	this->SetPropertyBool("psdTraceFile" NSSUBPROP_FILENAME, tTrue);

	/* Soll der sceneEvalDlg default-m��ig angezeigt werden? */
	this->SetPropertyBool("showSceneEvalDlg", tFalse);

	this->overviewProcessor.SetEventCallback(&this->EventCallback, nullptr);

	this->overviewProcessor.SetCallback(this);
	this->statusProcessor.SetCallback(this);
	this->modelContainer.SetCallback(this);
	this->sceneContainer.SetCallback(this);

	this->lastToggle = false;
}


bool	vehicleDisplayFilter_T::OnInitNormal(void)
{
	this->overviewProcessor.Init(NULL);
	this->statusProcessor.Init(NULL);
	this->modelContainer.Init(NULL);
	this->sceneContainer.Init(NULL);

	this->overviewProcessor.mainControl.graph.SetYWindow(this->overviewProcessor.mainControl.graph.GetYWindow()); 
	this->overviewProcessor.OnFrameChange();

	/* Ggf. wird eine PSD-Trace-Datei erstellt */
	if(strlen(this->GetPropertyStr("psdTraceFile"))) {
		if(!this->psdTraceFile.OpenWrite(this->GetPropertyStr("psdTraceFile"))) {
			char message[1024];
			sprintf_s(message, "Failed to open PSD Trace File \"%s\".", this->GetPropertyStr("psdTraceFile"));

			this->ShowErrorBox(message, "mapDisplayFilter");
			LOG_ERROR(message);

			return false;
		}
	}

	this->controlFlag	= false;
	this->strategyFlag	= false;
	this->psdCount		= 0;
	this->psdOffset		= 0;

	this->SelectPage(pageOverview);

	this->shutdown = false;
	this->flagged.Create();
	cKernelCyclicThread::Create();

	this->sceneEvalDlg.ShowAsync(NULL);

	return true;
}


bool	vehicleDisplayFilter_T::OnGraphReady(void)
{
	/* Zur�cksetzen der mapTreePainters */
	this->overviewProcessor.Reset();


	/* Wenn der Flexray-Pin verbunden ist, fragen wir die Fibex-Datenbank nach den IDs f�r die PSD-PDUs */
	do {
		if(this->inputPin_flexrayPSD->IsConnected()) {
			cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
			if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
				LOG_ERROR("No FlexRay support service available");
				break;
			}


			cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
			if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
				LOG_ERROR("Failed to get FIBEX database");
				break;
			}


			/* Abfragen der IDs f�r die PDUs, die uns interessieren.
			   Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
			tUInt32 count;
			fibexDB->GetPDUCount(&count);

			for(tUInt32 i = 0; i < count; i++) {
				const tChar *name;
				fibexDB->GetPDUName(i, &name);

				if(!strcmp(name, "ACC_06"))		{ this->idACC_06 = i; }
				if(!strcmp(name, "Motor_11"))	{ this->idMotor_11 = i; }
				if(!strcmp(name, "Motor_12"))	{ this->idMotor_12 = i; }
				if(!strcmp(name, "Motor_20"))	{ this->idMotor_20 = i; }
				if(!strcmp(name, "Motor_Code"))	{ this->idMotor_Code = i; }
				if(!strcmp(name, "PACC02_02"))	{ this->idPACC02_02 = i; }
				if(!strcmp(name, "PSD_04"))		{ this->idPSD04 = i; }
				if(!strcmp(name, "PSD_05"))		{ this->idPSD05 = i; }
				if(!strcmp(name, "PSD_06"))		{ this->idPSD06 = i; }
			}


			cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
			if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
				LOG_ERROR("Failed to create FlexRay coder");
				break;
			}

			fibexDB->GetSignalID("ACC_Sollbeschleunigung_02",			&this->idACC_Sollbeschleunigung_02);
			fibexDB->GetSignalID("PACC02_Durchschnittsgeschw",			&this->idPACC02_Durchschnittsgeschw);
			fibexDB->GetSignalID("MO_Drehzahl_01",						&this->idMO_Drehzahl_01);
			fibexDB->GetSignalID("MO_Mom_Begr_dyn",						&this->idMO_Mom_Begr_dyn);
			fibexDB->GetSignalID("MO_Mom_Begr_stat",					&this->idMO_Mom_Begr_stat);
			fibexDB->GetSignalID("MO_Mom_Schub",						&this->idMO_Mom_Schub);
			fibexDB->GetSignalID("MO_Faktor_Momente_02",				&this->idMO_Faktor_Momente_02);
			fibexDB->GetSignalID("TSK_a_Soll_gradientenbegrenzt",		&this->idTSK_a_Soll_gradientenbegrenzt);


			/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
			this->flexrayCoder = coder;
			this->flexrayCoder->SetListener((groundFilter_T*)this);

			/* Wir h�ren auf die drei PSD-PDUs */
			this->flexrayCoder->ActivePDUEvents(this->idACC_06);
			this->flexrayCoder->ActivePDUEvents(this->idMotor_11);
			this->flexrayCoder->ActivePDUEvents(this->idMotor_12);
			this->flexrayCoder->ActivePDUEvents(this->idMotor_20);
			this->flexrayCoder->ActivePDUEvents(this->idMotor_Code);
			this->flexrayCoder->ActivePDUEvents(this->idPACC02_02);
			this->flexrayCoder->ActivePDUEvents(this->idPSD04);
			this->flexrayCoder->ActivePDUEvents(this->idPSD05);
			this->flexrayCoder->ActivePDUEvents(this->idPSD06);
		}
	} while(false);


	if(this->GetPropertyStr("showSceneEvalDlg")) {
		this->sceneEvalDlg.MakeVisible();
	}


	return true;
}


void	vehicleDisplayFilter_T::OnShutdownNormal(void)
{
	/* Zyklischen Thread abbrechen */
	this->shutdown = true;
	this->flagged.Set();
	cKernelCyclicThread::Release();
	this->flagged.Release();

	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}

	/* Ggf. PSD-Trace-File schlie�en */
	if(this->psdTraceFile.IsFileOpen()) {
		this->psdTraceFile.Close();
	}

	this->sceneEvalDlg.Destroy();
}


void	vehicleDisplayFilter_T::OnReceive(void)
{
	if(this->inputPin_pemControl->Unflag()) {
		this->EnterMutex();
		this->controlFlag = true;
		this->flagged.Set();
		this->LeaveMutex();
	}


	if(this->inputPin_pemPlanning->Unflag()) {
		this->EnterMutex();
		this->strategyFlag = true;
		this->flagged.Set();
		this->LeaveMutex();
	}


	if(this->inputPin_psdInput->Unflag()) {
		this->EnterMutex();
		psdInput_T	psdInput = *(psdInput_T*)this->inputPin_psdInput->GetDataPtr();

		/* Daten im Speicher ablegen */
		if(psdInput.type != psdMessageNone) {
			if(this->psdCount < sizeof(this->psdBuffer) / sizeof(this->psdBuffer[0])) {
				uint16_T index = (uint16_T)((this->psdOffset + this->psdCount) % (sizeof(this->psdBuffer) / sizeof(this->psdBuffer[0])));
				this->psdBuffer[index] = psdInput;

				this->psdCount++;
			}
		}


		this->flagged.Set();
		this->LeaveMutex();
	}


	if(this->inputPin_flexrayPSD->Unflag()) {
		if(this->flexrayCoder) {
			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->inputPin_flexrayPSD->GetDataPtr(),
									  (tInt)this->inputPin_flexrayPSD->GetDataSize(),
											this->inputPin_flexrayPSD->GetTimeStamp());
		}
	}


	if(this->inputPin_canPSD->Unflag()) {
		/* CAN-Nachrichten k�nnen direkt verarbeitet werden */
		if(sizeof(canMessage_T) == this->inputPin_canPSD->GetDataSize()) {
			psdMessageType_T messageType = psdMessageNone;
			canMessage_T *message = (canMessage_T*)this->inputPin_canPSD->GetDataPtr();

			if(message->id == 1122) { messageType = psdMessage4; }
			if(message->id == 1123) { messageType = psdMessage5; }
			if(message->id == 1124) { messageType = psdMessage6; }

			if(messageType != psdMessageNone) {
				this->overviewProcessor.Process(messageType, message->data, false);

				if(this->psdTraceFile.IsFileOpen()) {
					psdRaw_T psdRaw;

					psdRaw.type = messageType;
					memcpy(psdRaw.data, message->data, sizeof(psdRaw.data));

					this->psdTraceFile.WriteSample(&psdRaw);
				}
			}
		}
	}


	if(this->inputPin_nmea->Unflag()) {
		if(this->inputPin_nmea->GetDataSize() > 0) {
			this->EnterMutex();
			pemControl_T		pemControl			= *(pemControl_T*)this->inputPin_pemControl->GetDataPtr();
			this->LeaveMutex();

			char_T *buffer = new char_T[this->inputPin_nmea->GetDataSize() + 1];
			memset(buffer, 0, this->inputPin_nmea->GetDataSize() + 1);
			memcpy(buffer, this->inputPin_nmea->GetDataPtr(), this->inputPin_nmea->GetDataSize());

			this->overviewProcessor.Process(buffer);

			delete[] buffer;
		}
	}


	if(this->inputPin_curveCategory->Unflag()) {
		if(this->inputPin_curveCategory->GetDataSize() == sizeof(int8_T)) {
			this->overviewProcessor.Process((int8_T)*(int8_T*)this->inputPin_curveCategory->GetDataPtr());
		}
	}


	if(this->inputPin_vehicleModel->Unflag()) {
		this->EnterMutex();
		vehicleModel_T vehicleModel = *(vehicleModel_T*)this->inputPin_vehicleModel->GetDataPtr();
		this->LeaveMutex();

		if(this->inputPin_vehicleModel->GetDataSize()) {
			this->overviewProcessor.Process(&vehicleModel);
			this->modelContainer.Process(&vehicleModel);
		}
	}
}


void	vehicleDisplayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		adtf_devicetb::tCoderPDUEvent *coderEvent = (adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }

		if(coderEvent->nPayloadLength == 8) {
			psdMessageType_T messageType = psdMessageNone;

			if(coderEvent->nPDUID == this->idPSD04) { messageType = psdMessage4; }
			if(coderEvent->nPDUID == this->idPSD05) { messageType = psdMessage5; }
			if(coderEvent->nPDUID == this->idPSD06) { messageType = psdMessage6; }

			if(messageType != psdMessageNone) {
				this->overviewProcessor.Process(messageType, coderEvent->pData, false);

				if(this->psdTraceFile.IsFileOpen()) {
					psdRaw_T psdRaw;

					psdRaw.type = messageType;
					memcpy(psdRaw.data, coderEvent->pData, sizeof(psdRaw.data));

					this->psdTraceFile.WriteSample(&psdRaw);
				}
			}

			if(coderEvent->nPDUID == this->idPACC02_02) {
				adtf_devicetb::tSignalValue		PACC02_Durchschnittsgeschw;

				this->flexrayCoder->GetSignalValue(this->idPACC02_Durchschnittsgeschw, &PACC02_Durchschnittsgeschw);

				this->DecodeControlCode((real32_T)PACC02_Durchschnittsgeschw.nf64Value);
			}

			if(coderEvent->nPDUID == this->idACC_06) {
				adtf_devicetb::tSignalValue		ACC_Sollbeschleunigung_02;
				adtf_devicetb::tSignalValue		TSK_a_Soll_gradientenbegrenzt;

				this->flexrayCoder->GetSignalValue(this->idACC_Sollbeschleunigung_02,		&ACC_Sollbeschleunigung_02);
				this->flexrayCoder->GetSignalValue(this->idTSK_a_Soll_gradientenbegrenzt,	&TSK_a_Soll_gradientenbegrenzt);

				this->overviewProcessor.Process(ACC_Sollbeschleunigung_02.nf64Value, TSK_a_Soll_gradientenbegrenzt.nf64Value);
			}

			if(coderEvent->nPDUID == this->idMotor_12) {
				adtf_devicetb::tSignalValue		MO_Faktor_Momente_02;
				adtf_devicetb::tSignalValue		MO_Drehzahl_01;
				adtf_devicetb::tSignalValue		MO_Mom_Begr_dyn;
				adtf_devicetb::tSignalValue		MO_Mom_Begr_stat;
				adtf_devicetb::tSignalValue		MO_Mom_Schub;

				this->flexrayCoder->GetSignalValue(this->idMO_Faktor_Momente_02,	&MO_Faktor_Momente_02);
				this->flexrayCoder->GetSignalValue(this->idMO_Drehzahl_01,			&MO_Drehzahl_01);
				this->flexrayCoder->GetSignalValue(this->idMO_Mom_Begr_dyn,			&MO_Mom_Begr_dyn);
				this->flexrayCoder->GetSignalValue(this->idMO_Mom_Begr_stat,		&MO_Mom_Begr_stat);
				this->flexrayCoder->GetSignalValue(this->idMO_Mom_Schub,			&MO_Mom_Schub);

				this->modelContainer.Process(MO_Faktor_Momente_02.nf64Value,
											 MO_Drehzahl_01.nf64Value,
											 MO_Mom_Begr_dyn.nf64Value,
											 MO_Mom_Begr_stat.nf64Value,
											 MO_Mom_Schub.nf64Value);
			}
		}
	}
}


tResult	vehicleDisplayFilter_T::OnSize(tHandle hCanvas, tInt nLeft, tInt nTop, tInt nRight, tInt nBottom)
{
	RETURN_IF_FAILED(displayFilter_T::OnSize(hCanvas, nLeft, nTop, nRight, nBottom));

	this->overviewProcessor.Reshape(0, 0, nRight-nLeft+1, nBottom-nTop+1);
	this->statusProcessor.mainControl.graph.Reshape(0, 0, nRight-nLeft+1, nBottom-nTop+1);
	this->modelContainer.Reshape(0, 0, nRight-nLeft+1, nBottom-nTop+1);
	this->sceneContainer.Reshape(0, 0, nRight-nLeft+1, nBottom-nTop+1);
	
	RETURN_NOERROR;
}


tResult	vehicleDisplayFilter_T::OnTimer(tHandle hCanvas)
{
	displayFilter_T::OnTimer(hCanvas);

	if(globalToggle && !this->lastToggle) {
		this->SelectNextPage();
	}

	this->lastToggle = globalToggle;

	RETURN_NOERROR;
}


tResult	vehicleDisplayFilter_T::OnControlEvent(tControlEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags,  tVoid* pEventData)
{
	Invalidate(tTrue);

	if(eCode == EC_KeyInput || eCode == EC_KeyUp) {
		this->overviewProcessor.OnKeyInput(this->ConvertKey(nParam1), (GetKeyState(VK_CONTROL) & 0x8000) == 0x8000, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
		this->statusProcessor.OnKeyInput(this->ConvertKey(nParam1), (GetKeyState(VK_CONTROL) & 0x8000) == 0x8000, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
		this->modelContainer.OnKeyInput(this->ConvertKey(nParam1), (GetKeyState(VK_CONTROL) & 0x8000) == 0x8000, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
		this->sceneContainer.OnKeyInput(this->ConvertKey(nParam1), (GetKeyState(VK_CONTROL) & 0x8000) == 0x8000, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);

		if(this->ConvertKey(nParam1) == _graphControl::KEY_TAB) {
			this->SelectNextPage();
		}
	}

	if(eCode == EC_MouseLDown) {
		if(nParam1 < 50 && nParam2 < 50) {
			this->SelectNextPage();

			RETURN_NOERROR;
		}
	}

	RETURN_IF_FAILED(displayFilter_T::OnControlEvent(eCode, nParam1, nParam2, nFlags, pEventData));

	RETURN_NOERROR;
}


void	vehicleDisplayFilter_T::SelectPage(plotPage_T page)
{
	switch(page) {
		case pageOverview:
			this->AssignControl(&this->overviewProcessor.mainControl);
			break;

		case pageStatus:
			this->AssignControl(&this->statusProcessor.mainControl);
			break;

		case pageModel:
			this->AssignControl(&this->modelContainer.mainControl);
			break;

		case pageScenes:
			this->AssignControl(&this->sceneContainer.mainControl);
			break;

		default:
			break;
	}

	this->selectedPage	= page;
	this->pageValid		= true;
}


void	vehicleDisplayFilter_T::ProcessControl(void)
{
	this->EnterMutex();
	pemControl_T		pemControl			= *(pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();
	pemControlStack_T	controlStack		= *(pemControlStack_T*)this->GetInputPin("controlStack")->GetDataPtr();
	pemControlHeap_T	controlHeap			= *(pemControlHeap_T*)this->GetInputPin("controlHeap")->GetDataPtr();
	pemPlanning_T		pemPlanning			= *(pemPlanning_T*)this->GetInputPin("pemPlanning")->GetDataPtr();
	pemPlanningHeap_T	strategyHeap		= *(pemPlanningHeap_T*)this->GetInputPin("planningHeap")->GetDataPtr();
	uint16_T			measurementTrigger	= *(uint16_T*)this->GetInputPin("measurementTrigger")->GetDataPtr();
	this->controlFlag = false;
	this->LeaveMutex();

	this->overviewProcessor.Process(&pemControl,
									&controlStack,
									&controlHeap,
									&pemPlanning,
									&strategyHeap,
									measurementTrigger);

	this->statusProcessor.Process(&pemControl,
								  &controlStack,
								  &controlHeap,
								  &pemPlanning,
								  &strategyHeap,
								   measurementTrigger);

	this->modelContainer.Process(&pemControl,
								 &controlStack,
								 &controlHeap,
								 &pemPlanning,
								 &strategyHeap,
								  measurementTrigger);

	this->sceneCollector.Process(&pemControl,
								 &pemPlanning);

	this->sceneEvalDlg.SetPosition(pemControl.vehicleState.velocity.position);
	this->sceneEvalDlg.SetTime(pemControl.vehicleState.tickCount * controlCYCLETIME);

	if(this->sceneEvalDlg.ProcessScenes(this->sceneCollector.GetScenes())) {
		this->SendScenes();
	}
	
}


void	vehicleDisplayFilter_T::ProcessStrategy(void)
{
	this->EnterMutex();
	pemControl_T		pemControl		= *(pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();
	pemPlanning_T		pemPlanning		= *(pemPlanning_T*)this->GetInputPin("pemPlanning")->GetDataPtr();
	pemPlanningHeap_T	strategyHeap	= *(pemPlanningHeap_T*)this->GetInputPin("planningHeap")->GetDataPtr();
	pemPlanningStack_T	strategyStack	= *(pemPlanningStack_T*)this->GetInputPin("planningStack")->GetDataPtr();
	this->strategyFlag = false;
	this->LeaveMutex();

	this->overviewProcessor.Process(&pemControl,
								    &pemPlanning,
								    &strategyStack,
								    &strategyHeap);

	this->statusProcessor.Process(&pemControl,
								  &pemPlanning,
								  &strategyStack,
								  &strategyHeap);

	this->modelContainer.Process(&pemControl,
								 &pemPlanning,
								 &strategyStack,
								 &strategyHeap);
}


void	vehicleDisplayFilter_T::ProcessPSD(void)
{
	this->EnterMutex();

	bool_T			valid = psdCount > 0;
	bool_T			skipUpdate = false;
	psdInput_T		psdInput = this->psdBuffer[this->psdOffset];

	this->psdCount--;
	this->psdOffset++;
	this->psdOffset %= sizeof(this->psdBuffer) / sizeof(this->psdBuffer[0]);

	/* Wenn es noch Nachrichten zu verarbeiten gibt, setzen wir das Flag direkt wieder */
	if(this->psdCount > 0) {
		this->flagged.Set();
	}

	/* Wenn wir noch mehr als einen Nachrichtenzyklus im Speicher haben, sparen wir uns das
	   Update der Grafik bis zum letzten Zyklus */
	if(this->psdCount > 4) {
		skipUpdate = true;
	}

	this->LeaveMutex();

	if(psdInput.type != psdMessageNone) {
		this->overviewProcessor.Process(&psdInput, skipUpdate);
	}
}


void	vehicleDisplayFilter_T::SendScenes(void)
{
	std::vector<sceneEvent_T> evaluated;

	this->sceneEvalDlg.PullEvaluated(evaluated);

	this->sceneContainer.Process(evaluated);

	for(std::vector<sceneEvent_T>::const_iterator it = evaluated.begin(); it != evaluated.end(); it++) {
		rapidxml::xml_document<TCHAR> doc;
		rapidxml::xml_node<TCHAR> *node = doc.allocate_node(rapidxml::node_element, L"scene");

		doc.append_node(node);

		if(it->GenerateXML(&doc, node)) {
			tstring		xmlData;
			rapidxml::print(std::back_inserter(xmlData), doc, 0);

			this->Submit("evaluatedScenes", &xmlData[0], (xmlData.size() + 1) * sizeof(TCHAR));
		}
	}
}


void	vehicleDisplayFilter_T::SelectNextPage(void)
{
	if(!this->pageValid) {
		this->SelectPage(this->selectedPage);
		return;
	}

	switch(this->selectedPage) {
		case pageOverview:
			this->SelectPage(pageStatus);
			break;

		case pageStatus:
			this->SelectPage(pageModel);
			break;

		case pageModel:
			this->SelectPage(pageScenes);
			break;

		case pageScenes:
			this->SelectPage(pageOverview);
			break;
	}
}


void	vehicleDisplayFilter_T::EventCallback(IN	const	psdEventType_T		 type,
											  IN	const	char_T				*message,
											  IN	const	void				*data)
{
	char buffer[1024];

	sprintf_s(buffer, "%s: %s", (type == psdEventError) ? "PSD Error" : "PSD Tree Reset", message);
	LOG_INFO(buffer);
}


tResult	vehicleDisplayFilter_T::CyclicFunc()
{
	if(!this->shutdown) {
		this->flagged.Wait(2000);
	}

	if(this->controlFlag) {
		this->ProcessControl();
	}

	if(this->strategyFlag) {
		this->ProcessStrategy();
	}

	if(this->psdCount > 0) {
		this->ProcessPSD();
	}

	RETURN_NOERROR;
}


void	vehicleDisplayFilter_T::DecodeControlCode(real32_T DePACC02_Durchschnittsgeschw)
{
	uint16_T coded = (uint16_T)((DePACC02_Durchschnittsgeschw / 0.3f) + 0.1f);

	if(coded) {
		char message[256];

		bool_T	 first = true;
		uint16_T module = (coded >> 5);
		uint16_T line   = (coded & 31) - 1;

		if(module != 31) {
			sprintf_s(message, "Control Code (%4.1f | %4.4i): Error in ", DePACC02_Durchschnittsgeschw, coded);

			for(uint16_T index = 0; index < diagModule_Unknown; index++) {
				if(((uint16_T)index % 31) == module) {
					if(!first) {
						strcat_s(message, "/");
					}

					strcat_s(message, diagGetModuleName((diagModule_T)index));

					first = false;
				}
			}
			sprintf_s(message, "%s at line %%%i", message, line);
			LOG_INFO(message);
		}
		else {
			sprintf_s(message, "Control Code (%4.1f | %4.4i): %s", DePACC02_Durchschnittsgeschw, coded, diagGetInfoText((diagInfo_T)line));
			LOG_INFO(message);
		}
	}
}


void	vehicleDisplayFilter_T::ForceUpdate(void)
{
	this->Invalidate(tTrue);
}



void	vehicleDisplayFilter_T::PushControl(graphControl_T *control)
{
	this->AssignControl(control);
	this->pageValid = false;
}
