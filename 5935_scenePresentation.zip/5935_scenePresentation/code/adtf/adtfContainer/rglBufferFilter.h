#ifndef guard_rglBufferFilter_h
#define guard_rglBufferFilter_h

#define SKIP_MAGIC_NUMBER

#include "baseFilter.h"


#define ADTF_FILTER_ID_rglBufferFilter		"IDII.rglBufferFilter"
#define ADTF_FILTER_NAME_rglBufferFilter	"IDII rglBufferFilter"


class rglBufferFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_rglBufferFilter, ADTF_FILTER_NAME_rglBufferFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	inputPin_T	*inputPin_trigger;
	inputPin_T	*inputPin_PpPSD15__DePSD04;
	inputPin_T	*inputPin_PpPSD15__DePSD05;
	inputPin_T	*inputPin_PpPSD15__DePSD06m0;
	inputPin_T	*inputPin_PpPSD15__DePSD06m1;
	inputPin_T	*inputPin_PpPSD15__DePSD06m2;
	inputPin_T	*inputPin_PpPSD15__DePSD06m3;
	inputPin_T	*inputPin_PpPSD15__DePSD06m4;


public:
				 rglBufferFilter_T(const tChar* __info);

	void		 OnReceive(void);
};


#endif