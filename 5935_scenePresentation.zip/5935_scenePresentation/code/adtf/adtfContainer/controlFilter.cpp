#include "stdafx.h"
#include "controlFilter.h"

extern "C" {
	#include "base.h"
	#include "control/controlTask/controlTask.h"
	#include "control/psdWrapper/ehrInterface.h"
	#include "control/psdWrapper/eifSynchro.h"
}

#include "control/controlTask/controlTask_adtfTools.h"
#include "control/outputCodec/outputCodec_adtfTools.h"
#include "control/inputCodec/inputCodec_adtfTools.h"

#include "common/vehicleModel/vehicleModel_adtfTools.h"
#include "common/swcCommunication/swcComm_adtfTools.h"
#include "common/vehicleObserverCommon/vehicleObserver_adtfTools.h"
#include "common/systemControllerCommon/systemController_adtfTools.h"

controlFilter_T::controlFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("controlTrigger");

	this->AddInputPin("vehicleModel",	vehicleModel_header());
	this->AddInputPin("pemPlanning",	pemPlanning_header());
	this->AddInputPin("psdInput",		MEDIA_TYPE_STRUCTURED_DATA,		0);

	this->AddInputPin("flexrayInput",	flexrayInput_header());
	this->AddInputPin("emlInput",		emlInput_header());
	this->AddInputPin("laneInput",		laneInput_header());
	this->AddInputPin("vzeInput",		vzeInput_header());
	this->AddInputPin("obfInput",		obfInput_header());
	this->AddInputPin("lapInput",		lapInput_header());
	this->AddInputPin("codingInput",	codingInput_header());
	this->AddInputPin("fodInput",		fodInput_header());

	this->AddOutputPin("pemControl",	pemControl_header());
	this->AddOutputPin("flexrayOutput",	flexrayOutput_header());
	this->AddOutputPin("fodOutput",		fodOutput_header());

	this->AddOutputPin("controlHeap",	pemControlHeap_header());
	this->AddOutputPin("controlStack",	pemControlStack_header());

	this->AddInputPin("_pushHeap",		pemControlHeap_header());

	this->SetPropertyBool("Enable pushHeap", tTrue);
	this->SetPropertyBool("Enable pushHeap" NSSUBPROP_ISCHANGEABLE, tTrue);
}


void	controlFilter_T::OnReceive(void)
{
	if(this->GetInputPin("controlTrigger")->Unflag()) {
		this->RunAlgorithm();
	}

	if(this->GetInputPin("_pushHeap")->Unflag()) {
		if(this->GetPropertyBool("Enable pushHeap")) {
			this->EnterMutex();
			this->heap = *(pemControlHeap_T*)this->GetInputPin("_pushHeap")->GetDataPtr();
			this->LeaveMutex();
		}
	}
}


bool	controlFilter_T::OnInitNormal(void)
{
	memset(&this->heap, 0, sizeof(this->heap));
	memset(&this->eifMemory, 0, sizeof(this->eifMemory));

	return true;
}

#ifdef ID2FP_DEBUG
extern "C" __declspec(dllexport) vehicleModel_T*	   ID2_RP_ctrl_ref_vehicleModel = 0;
extern "C" __declspec(dllexport) pemPlanning_T*		   ID2_RP_ctrl_ref_pemPlanning = 0;
extern "C" __declspec(dllexport) psdInput_T*		   ID2_RP_ctrl_ref_psdInput = 0;
extern "C" __declspec(dllexport) flexrayInput_T*	   ID2_RP_ctrl_ref_flexrayInput = 0;
extern "C" __declspec(dllexport) emlInput_T*		   ID2_RP_ctrl_ref_emlInput = 0;
extern "C" __declspec(dllexport) laneInput_T*		   ID2_RP_ctrl_ref_laneInput = 0;
extern "C" __declspec(dllexport) vzeInput_T*		   ID2_RP_ctrl_ref_vzeInput = 0;
extern "C" __declspec(dllexport) obfInput_T*		   ID2_RP_ctrl_ref_obfInput = 0;
extern "C" __declspec(dllexport) lapInput_T*		   ID2_RP_ctrl_ref_lapInput = 0;
extern "C" __declspec(dllexport) codingInput_T*		   ID2_RP_ctrl_ref_codingInput = 0;
extern "C" __declspec(dllexport) pemControl_T*		   ID2_RP_ctrl_ref_pemControl = 0;
extern "C" __declspec(dllexport) flexrayOutput_T*	   ID2_RP_ctrl_ref_flexrayOutput = 0;
extern "C" __declspec(dllexport) fodOutput_T*		   ID2_RP_ctrl_ref_fodOutput = 0;
extern "C" __declspec(dllexport) controlMeasurement_T* ID2_RP_ctrl_ref_controlMeasurement = 0; 
extern "C" __declspec(dllexport) pemControlStack_T*	   ID2_RP_ctrl_ref_pemControlStack = 0;
extern "C" __declspec(dllexport) pemControlHeap_T*     ID2_RP_ctrl_ref_pemControlHeap = 0;
extern "C" __declspec(dllexport) checkState_T*		   ID2_RP_ctrl_ref_checkState = 0;
extern "C" __declspec(dllexport) unsigned char		ID2_RP_ctrl_references_initialized = 0;
#endif

void	controlFilter_T::RunAlgorithm(void)
{
	this->EnterMutex();

#ifndef ID2FP_DEBUG
	vehicleModel_T	vehicleModel	= *(vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();
	pemPlanning_T	pemPlanning		= *(pemPlanning_T*)this->GetInputPin("pemPlanning")->GetDataPtr();
	psdInput_T		psdInput		= *(psdInput_T*)this->GetInputPin("psdInput")->GetDataPtr();
	flexrayInput_T	flexrayInput	= *(flexrayInput_T*)this->GetInputPin("flexrayInput")->GetDataPtr();
	emlInput_T		emlInput		= *(emlInput_T*)this->GetInputPin("emlInput")->GetDataPtr();
	laneInput_T		laneInput		= *(laneInput_T*)this->GetInputPin("laneInput")->GetDataPtr();
	vzeInput_T		vzeInput		= *(vzeInput_T*)this->GetInputPin("vzeInput")->GetDataPtr();
	obfInput_T		obfInput		= *(obfInput_T*)this->GetInputPin("obfInput")->GetDataPtr();
	lapInput_T		lapInput		= *(lapInput_T*)this->GetInputPin("lapInput")->GetDataPtr();
	codingInput_T	codingInput		= *(codingInput_T*)this->GetInputPin("codingInput")->GetDataPtr();
	fodInput_T		fodInput		= *(fodInput_T*)this->GetInputPin("fodInput")->GetDataPtr();

	controlRteInfo_T		controlRteInfo;

	pemControlStack_T		controlStack		= {0};
	pemControl_T			pemControl			= {0};
	flexrayOutput_T			flexrayOutput		= {0};
	fodOutput_T				fodOutput			= {0};
	controlMeasurement_T	controlMeasurement	= {0};
	checkState_T			checkState			= {0};

	memset(&controlRteInfo, 0, sizeof(controlRteInfo));

#else
	// input
	static vehicleModel_T	vehicleModel;
	static pemPlanning_T	pemPlanning;
	static psdInput_T		psdInput;
	static flexrayInput_T	flexrayInput;
	static emlInput_T		emlInput;
	static laneInput_T		laneInput;
	static vzeInput_T		vzeInput;
	static obfInput_T		obfInput;
	static lapInput_T		lapInput;
	static codingInput_T	codingInput;
	static fodInput_T		fodInput;
	// state
	static pemControlStack_T	controlStack;
	// output
	static pemControl_T			pemControl;
	static flexrayOutput_T		flexrayOutput;
	static fodOutput_T			fodOutput;
	static controlMeasurement_T	controlMeasurement;
	static checkState_T			checkState;

	controlRteInfo_T	controlRteInfo;

	vehicleModel	= *(vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();
	pemPlanning		= *(pemPlanning_T*)this->GetInputPin("pemPlanning")->GetDataPtr();
	psdInput		= *(psdInput_T*)this->GetInputPin("psdInput")->GetDataPtr();
	flexrayInput	= *(flexrayInput_T*)this->GetInputPin("flexrayInput")->GetDataPtr();
	emlInput		= *(emlInput_T*)this->GetInputPin("emlInput")->GetDataPtr();
	laneInput		= *(laneInput_T*)this->GetInputPin("laneInput")->GetDataPtr();
	vzeInput		= *(vzeInput_T*)this->GetInputPin("vzeInput")->GetDataPtr();
	obfInput		= *(obfInput_T*)this->GetInputPin("obfInput")->GetDataPtr();
	lapInput		= *(lapInput_T*)this->GetInputPin("lapInput")->GetDataPtr();
	codingInput		= *(codingInput_T*)this->GetInputPin("codingInput")->GetDataPtr();
	fodInput		= *(fodInput_T*)this->GetInputPin("fodInput")->GetDataPtr();

	memset(&controlStack,       0, sizeof(pemControlStack_T));
	memset(&pemControl,         0, sizeof(pemControl_T));
	memset(&flexrayOutput,      0, sizeof(flexrayOutput_T));
	memset(&fodOutput,		    0, sizeof(fodOutput_T));
	memset(&controlMeasurement, 0, sizeof(controlMeasurement_T));
	memset(&checkState,			0, sizeof(checkState_T));
	memset(&controlRteInfo,     0, sizeof(controlRteInfo));

	if (!ID2_RP_ctrl_references_initialized) {
		ID2_RP_ctrl_ref_vehicleModel	   = &vehicleModel;
		ID2_RP_ctrl_ref_pemPlanning		   = &pemPlanning;
		ID2_RP_ctrl_ref_psdInput		   = &psdInput;
		ID2_RP_ctrl_ref_flexrayInput	   = &flexrayInput;
		ID2_RP_ctrl_ref_emlInput		   = &emlInput;
		ID2_RP_ctrl_ref_laneInput		   = &laneInput;
		ID2_RP_ctrl_ref_vzeInput		   = &vzeInput;
		ID2_RP_ctrl_ref_obfInput		   = &obfInput;
		ID2_RP_ctrl_ref_lapInput           = &lapInput;
		ID2_RP_ctrl_ref_codingInput        = &codingInput;
		ID2_RP_ctrl_ref_pemControlStack	   = &controlStack;
		ID2_RP_ctrl_ref_pemControlHeap     = &this->heap;
		ID2_RP_ctrl_ref_pemControl		   = &pemControl;
		ID2_RP_ctrl_ref_flexrayOutput	   = &flexrayOutput;
		ID2_RP_ctrl_ref_fodOutput	   = &fodOutput;
		ID2_RP_ctrl_ref_controlMeasurement = &controlMeasurement;
		ID2_RP_ctrl_ref_checkState		   = &checkState;
		ID2_RP_ctrl_references_initialized = 1;
	}
#endif

#if (1 || defined(USE_PSDEHR_LIB))
	eifPushCoreData(&this->eifMemory);

	eifInput(&this->eifMemory, &psdInput);

	iccRunControl(&this->heap,
				  &vehicleModel,
				  &pemPlanning,
				  &flexrayInput,
				  &emlInput,
				  &laneInput,
				  &vzeInput,
				  &obfInput,
				  &lapInput,
				  &codingInput,
				  &fodInput,
				  &controlRteInfo,
				  &controlStack,
				  &pemControl,
				  &flexrayOutput,
				  &fodOutput,
				  &controlMeasurement,
				  &checkState);

	eifPullCoreData(&this->eifMemory);

#else

	iccRunControl(&this->heap,
				  &vehicleModel,
				  &pemPlanning,
				  &flexrayInput,
				  &emlInput,
				  &laneInput,
				  &vzeInput,
				  &obfInput,
				  &lapInput,
				  &controlRteInfo,
				  &controlStack,
				  &pemControl,
				  &flexrayOutput);

#endif

	this->LeaveMutex();

	/* pemControl wird als letztes ausgegeben, da es die Verarbeitung von controlMemory und flexrayOutput in den Displays triggert */
	this->Submit("controlHeap",		&this->heap,		sizeof(this->heap));
	this->Submit("controlStack",	&controlStack,		sizeof(controlStack));
	this->Submit("flexrayOutput",	&flexrayOutput,		sizeof(flexrayOutput));
	this->Submit("pemControl",		&pemControl,		sizeof(pemControl));
}
