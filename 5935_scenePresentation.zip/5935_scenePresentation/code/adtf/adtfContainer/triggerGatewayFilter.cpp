#include "stdafx.h"
#include "triggerGatewayFilter.h"

#undef		GetObject

#pragma warning(disable : 4355)


bool_T	globalToggle;


typedef struct canMessage_tag {
	int16_T		id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


triggerGatewayFilter_T::triggerGatewayFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("flexray",				MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);
	this->AddInputPin("canInfotainment",		MEDIA_TYPE_CAN,			MEDIA_SUBTYPE_CAN_RAW_MESSAGE);

	this->AddOutputPin("measurementTrigger",	"uint16",				sizeof(uint16_T));
	this->AddOutputPin("curveCategory",			"int8",					sizeof(int8_T));

	this->inputPin_flexray				= this->GetInputPin("flexray");
	this->inputPin_canInfotainment		= this->GetInputPin("canInfotainment");

	this->SetPropertyStr("commentFolder",		"$CFGDIR$\\..\\..\\..\\measurements\\$USERNAME$_$DATE$_$TIME$");
	this->SetPropertyBool("commentFolder" NSSUBPROP_FILENAME, tTrue);
}


bool	triggerGatewayFilter_T::OnInitFirst(void)
{
	if(IS_FAILED(pinIn_audioIn.Create("audioIn", IPin::PD_Input, static_cast<IPinEventSink*> (this)))) { return false; }
	if(IS_FAILED(RegisterPin(&pinIn_audioIn))) { return false; }

	if(IS_FAILED(pinOut_audioOut.Create("audioOut", IPin::PD_Output, static_cast<IPinEventSink*> (this)))) { return false; }
	if(IS_FAILED(RegisterPin(&pinOut_audioOut))) { return false; }

	return true;
}


bool	triggerGatewayFilter_T::OnInitNormal(void)
{
	this->triggerActive = false;

	this->fileCount = 0;

	this->flexrayTrigger	= false;
	this->canTrigger		= false;
	this->keyTrigger		= false;

	this->flexrayToggle		= false;
	this->canToggle			= false;
	globalToggle			= false;

	this->canUp				= false;
	this->canDown			= false;
	this->flexrayUp			= false;
	this->flexrayDown		= false;

	this->curveTime			= 0;
	this->curveValue		= 0;

	this->lastUp			= false;
	this->lastDown			= false;

	cObjectPtr<IApplication> pApplication;
	if(IS_OK(_runtime->GetObject( OID_ADTF_APPLICATION, IID_ADTF_APPLICATION, (tVoid**)&pApplication))) {
		tHandle hKeyEventManager = NULL;
		cException oLocalEx;
		tResult nResult = pApplication->GetInternalHandle(ADTF_APPLICATION_KEYEVENTMANAGER_HANDLE, &hKeyEventManager, &oLocalEx);
		if(IS_OK(nResult)) { 
			this->keyEventManager = static_cast<IGlobalKeyEventManager*>(hKeyEventManager);
		}
		else
		{
			__catch_exception(oLocalEx)
			{
				LOG_EXCEPTION(oLocalEx);
			}
		}
	}


	return true;
}


bool	triggerGatewayFilter_T::OnGraphReady(void)
{
	if(this->inputPin_flexray->IsConnected()) {
		cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
		if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
			LOG_ERROR("No FlexRay support service available");
			return false;
		}

		cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
		if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
			LOG_ERROR("Failed to get FIBEX database");
			return false;
		}


		/* Abfragen der IDs f�r die PDUs, die uns interessieren.
			Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
		tUInt32 count;
		fibexDB->GetPDUCount(&count);

		for(tUInt32 i = 0; i < count; i++) {
			const tChar *name;
			fibexDB->GetPDUName(i, &name);

			if(!strcmp(name, "MFL_Tasten_01"))		{
				this->id.MFL_Tasten_01.pdu.insert(i);
			}
		}


		/* Abfragen der Signal-IDs, f�r die wir uns interessieren. */
		if(IS_FAILED(fibexDB->GetSignalID("MFL_Tastencode_1",					&this->id.MFL_Tasten_01.MFL_Tastencode_1)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MFL_Tastencode_2",					&this->id.MFL_Tasten_01.MFL_Tastencode_2)))				{ return false; }


		/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
		cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
		if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
			LOG_ERROR("Failed to create FlexRay coder");
			return false;
		}

		this->flexrayCoder = coder;
		this->flexrayCoder->ResetData();
		this->flexrayCoder->SetListener((groundFilter_T*)this);

		for(std::set<tUInt32>::iterator pdu = this->id.MFL_Tasten_01.pdu.begin(); pdu != this->id.MFL_Tasten_01.pdu.end(); pdu++) { this->flexrayCoder->ActivePDUEvents(*pdu); }
	}
	else {
		this->flexrayCoder							= nullptr;
		this->id.MFL_Tasten_01.pdu.clear();
		this->id.MFL_Tasten_01.MFL_Tastencode_1		= 0;
		this->id.MFL_Tasten_01.MFL_Tastencode_2		= 0;
	}


	// check if a format descriptor is available for adjusting the internal bitmap info
	cObjectPtr<IMediaType> type;
	if (IS_OK(pinIn_audioIn.GetMediaType(&type))) {
		if (   type->GetMajorType()	== MEDIA_TYPE_AUDIO
			&& type->GetSubType()	== MEDIA_SUBTYPE_AUDIO_UNCOMPRESSED)
		{
			const tWaveFormat* sourceFormat = pinIn_audioIn.GetFormat();
			if (sourceFormat) {
				tWaveFormat formatBuffer;
				memcpy(&formatBuffer, sourceFormat, sizeof(formatBuffer));
				this->pinOut_audioOut.SetFormat(&formatBuffer);
			}
		}
	}

	sprintf_s(this->commentFolder, "%s", this->GetPropertyStr("commentFolder"));

	if(strlen(this->commentFolder) > 0) {
		CreateDirectoryA(this->commentFolder, NULL);
	}

	return true;
}


bool	triggerGatewayFilter_T::OnStart(void)
{
	if(this->keyEventManager) {
		ucom::cException oLocalEx;
		if (IS_FAILED(this->keyEventManager->RegisterKeyEventHandler(this, 0, &oLocalEx))) {
			__catch_exception(oLocalEx) {
				LOG_EXCEPTION(oLocalEx);
			}
		}
	}

	return true;
}


bool	triggerGatewayFilter_T::OnStop(void)
{
	if(this->keyEventManager) {
		this->keyEventManager->UnregisterKeyEventHandler(this);
	}

	return true;
}

void	triggerGatewayFilter_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}


	if (this->keyEventManager) {
		this->keyEventManager = NULL;
	}
}


void	triggerGatewayFilter_T::OnReceive(void)
{
	if(this->inputPin_flexray->Unflag()) {
		if(this->flexrayCoder) {
			this->EnterMutex();

			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->inputPin_flexray->GetDataPtr(),
									  (tInt)this->inputPin_flexray->GetDataSize(),
											this->inputPin_flexray->GetTimeStamp());

			this->LeaveMutex();
		}
	}


	if(this->inputPin_canInfotainment->Unflag()) {
		canMessage_T *message = (canMessage_T*)this->inputPin_canInfotainment->GetDataPtr();

		if(message->id == 0x5BF) {
			this->canTrigger = (message->data[0] == 33 || message->data[1] == 33);

			this->canToggle  = (message->data[0] == 29 || message->data[1] == 29);
			globalToggle = this->flexrayToggle || this->canToggle;

			this->canUp		= (message->data[0] == 16 || message->data[1] == 16);
			this->canDown	= (message->data[0] == 17 || message->data[1] == 17);

			this->OnTrigger();
		}
	}


	if((this->flexrayUp   || this->canUp)   && !this->lastUp) {
		this->curveTime = _clock->GetStreamTime();
		this->curveValue++;
	}

	this->lastUp	= (this->flexrayUp || this->canUp);


	if((this->flexrayDown || this->canDown) && !this->lastDown) {
		this->curveTime = _clock->GetStreamTime();
		this->curveValue--;
	}

	this->lastDown	= (this->flexrayDown || this->canDown);


	if(   (this->curveTime > 0)
	   && (_clock->GetStreamTime() - this->curveTime)) {
		this->Submit("curveCategory", &this->curveValue, sizeof(this->curveValue));

		this->curveTime		= 0;
		this->curveValue	= 0;
	}

}


void	triggerGatewayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }


		/* PSD */
		if(   (this->id.MFL_Tasten_01.pdu.end() != this->id.MFL_Tasten_01.pdu.find(coderEvent->nPDUID))
		   && (coderEvent->nPayloadLength == 4)) {
			this->flexrayTrigger	= (coderEvent->pData[0] == 33 || coderEvent->pData[1] == 33);

			this->flexrayToggle		=    (coderEvent->pData[0] == 29 || coderEvent->pData[1] == 29)
									  || (coderEvent->pData[0] == 28 || coderEvent->pData[1] == 28);

			globalToggle			= this->flexrayToggle || this->canToggle;

			this->flexrayUp			= (coderEvent->pData[0] == 16 || coderEvent->pData[1] == 16);
			this->flexrayDown		= (coderEvent->pData[0] == 17 || coderEvent->pData[1] == 17);

			this->OnTrigger();
		}
	}
}


void	triggerGatewayFilter_T::OnTrigger(void)
{
	if(this->flexrayTrigger || this->canTrigger || this->keyTrigger) {
		if(!this->triggerActive) {
			char fileName[1024];

			sprintf_s(fileName, "%s\\comment_%3.3i_%2.2ih%2.2im%2.2is.wav", 
								commentFolder,
								this->fileCount,
								((_clock->GetStreamTime() / 1000000) / 3600),
								((_clock->GetStreamTime() / 1000000) % 3600) / 60,
								((_clock->GetStreamTime() / 1000000) % 60));

			const tWaveFormat* sourceFormat = pinIn_audioIn.GetFormat();

			if(strlen(commentFolder)) {
				this->commentFile.Open(fileName, (uint16_T)sourceFormat->nChannels, sourceFormat->nSamplesPerSec, sourceFormat->nBitsPerSample);
			}

			this->fileCount++;
		}

		this->triggerActive = true;
	}
	else {
		if(this->triggerActive) {
			this->commentFile.Close();
		}

		this->triggerActive = false;
	}

	/* flexrayInput zuletzt ausliefern, da der controlFilter dar�ber getriggert wird */
	uint16_T triggerOut = (this->triggerActive ? (uint16_T)this->fileCount : 0);
	this->Submit("measurementTrigger",	&triggerOut,	sizeof(triggerOut));
}


tResult	triggerGatewayFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	RETURN_IF_FAILED(baseFilter_T::OnPinEvent(pSource, nEventCode, nParam1, nParam2, pMediaSample));

	if (nEventCode == IPinEventSink::PE_MediaSampleReceived) {
		if(pSource == &this->pinIn_audioIn) {
			if(this->triggerActive) {
				RETURN_IF_FAILED(pinOut_audioOut.Transmit(pMediaSample));
			}

			if(this->commentFile.IsFileOpen()) {
				__adtf_sample_read_lock(pMediaSample, int16_T, pData);
				this->commentFile.AddData(pData, (uint16_T)pMediaSample->GetSize());
			}
		}
	}

	RETURN_NOERROR;
}


tResult	triggerGatewayFilter_T::OnKeyEvent(tKeyEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags, tVoid* pEventData)
{
	if(eCode == IKeyEventHandler::EC_KeyDown) {
		if ((nParam2 & IKeyEventHandler::KS_CtrlKeyDown) &&
			nParam1 == IKeyEventHandler::KEY_T) {
			this->keyTrigger = true;

			this->OnTrigger();
		}
	}

	if(eCode == IKeyEventHandler::EC_KeyUp) {
		if ((nParam2 & IKeyEventHandler::KS_CtrlKeyDown) &&
			nParam1 == IKeyEventHandler::KEY_T) {
			this->keyTrigger = false;

			this->OnTrigger();
		}
	}

	RETURN_NOERROR;
}
