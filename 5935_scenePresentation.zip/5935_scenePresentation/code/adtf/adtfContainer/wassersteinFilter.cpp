#include "stdafx.h"
#include "wassersteinFilter.h"

#include "base.h"
#include "control/controlTask/controlTask_adtfTools.h"	/*pemControlHeap_header, pemControlStack_header*/
#include "common/vehicleModel/vehicleModel_adtfTools.h" /*vehicleModel_header*/
#include "common/swcCommunication/swcComm_adtfTools.h"	/*pemControl_header*/

#include "simulation/wasserstein/wasserstein_adtfTools.h"

#include "simulation/wasserstein/wsCycle.h"

#undef GetObject

wassersteinFilter_T::wassersteinFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{	
	// constructor: Definiert Eingangs- und Ausgangspins des ADTF-Filters

	//Input Pins
	this->AddInputPin("vehicleModel", vehicleModel_header());
	this->AddInputPin("pemControl",		pemControl_header());			// vehicleState
	this->AddInputPin("pemControlStack", pemControlStack_header());		// driverPrediction
	// this->AddInputPin("pemControlHeap",	pemControlHeap_header());
	this->AddInputPin("flexray", MEDIA_TYPE_FLEXRAY, MEDIA_SUBTYPE_FLEXRAY);

	// Output Pins
	this->AddOutputPin("wsDistance", wassersteinList_header());
}


void	wassersteinFilter_T::OnReceive(void)
{
	if (this->GetInputPin("pemControl")->IsConnected()){
		if (this->GetInputPin("pemControl")->Unflag()) {
			this->RunAlgorithm(pem);
		}
	}
	else
	{
		if (this->GetInputPin("flexray")->Unflag()) {
			if (this->flexrayCoder) {
				/* Daten an der FlexRay-Coder weiterleiten */
				this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
					(tInt)	this->GetInputPin("flexray")->GetDataSize(),
					this->GetInputPin("flexray")->GetTimeStamp());
			}
		}
	}
}


bool	wassersteinFilter_T::OnInitNormal(void)
{
	memset(&this->wsHeap, 0, sizeof(wsHeap_T));

	this->shutdown = false;
	this->flagged.Create();
	//cKernelCyclicThread::Create();

	return true;
}

bool	wassersteinFilter_T::OnGraphReady(void)
{
	/* Wenn der Flexray-Pin verbunden ist, fragen wir die Fibex-Datenbank nach den IDs f�r die PSD-PDUs */
	do {
		if (this->GetInputPin("flexray")->IsConnected()) {
			cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
			if (IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**)&flexrayService))) {
				LOG_ERROR("No FlexRay support service available");
				break;
			}


			cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
			if (IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
				LOG_ERROR("Failed to get FIBEX database");
				break;
			}


			/* Abfragen der IDs f�r die PDUs, die uns interessieren.
			Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
			tUInt32 count;
			fibexDB->GetPDUCount(&count);

			for (tUInt32 i = 0; i < count; i++) {
				const tChar *name;
				fibexDB->GetPDUName(i, &name);

				if (!strcmp(name, "PIF_01"))		{ this->idPIF_01 = i; }
				if (!strcmp(name, "EML_01"))		{ this->idEML_01 = i; }
				if (!strcmp(name, "EML_03"))		{ this->idEML_03 = i; }
				if (!strcmp(name, "Motor_16"))		{ this->idMotor_16 = i; }
				if (!strcmp(name, "Kombi_01"))		{ this->idKombi_01 = i; }
			}


			cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
			if (IS_FAILED(flexrayService->CreateCoder(&coder))) {
				LOG_ERROR("Failed to create FlexRay coder");
				break;
			}

			fibexDB->GetSignalID("PIF_Identifier", &this->idPIF_Identifier);
			fibexDB->GetSignalID("PIF_LT_Bin_0", &this->idPIF_LT_Bin_0);
			fibexDB->GetSignalID("PIF_LT_Bin_1", &this->idPIF_LT_Bin_1);
			fibexDB->GetSignalID("PIF_LT_Bin_2", &this->idPIF_LT_Bin_2);
			fibexDB->GetSignalID("PIF_LT_Bin_3", &this->idPIF_LT_Bin_3);
			fibexDB->GetSignalID("PIF_LT_Bin_4", &this->idPIF_LT_Bin_4);
			fibexDB->GetSignalID("PIF_LT_Bin_5", &this->idPIF_LT_Bin_5);
			fibexDB->GetSignalID("PIF_LT_Bin_6", &this->idPIF_LT_Bin_6);
			fibexDB->GetSignalID("PIF_LT_Bin_7", &this->idPIF_LT_Bin_7);
			fibexDB->GetSignalID("PIF_LT_Bin_8", &this->idPIF_LT_Bin_8);
			fibexDB->GetSignalID("PIF_LT_Status", &this->idPIF_LT_Status);
			fibexDB->GetSignalID("PIF_MT_Bin_0", &this->idPIF_MT_Bin_0);
			fibexDB->GetSignalID("PIF_MT_Bin_1", &this->idPIF_MT_Bin_1);
			fibexDB->GetSignalID("PIF_MT_Bin_2", &this->idPIF_MT_Bin_2);
			fibexDB->GetSignalID("PIF_MT_Bin_3", &this->idPIF_MT_Bin_3);
			fibexDB->GetSignalID("PIF_MT_Bin_4", &this->idPIF_MT_Bin_4);
			fibexDB->GetSignalID("PIF_MT_Bin_5", &this->idPIF_MT_Bin_5);
			fibexDB->GetSignalID("PIF_MT_Bin_6", &this->idPIF_MT_Bin_6);
			fibexDB->GetSignalID("PIF_MT_Bin_7", &this->idPIF_MT_Bin_7);
			fibexDB->GetSignalID("PIF_MT_Bin_8", &this->idPIF_MT_Bin_8);
			fibexDB->GetSignalID("PIF_MT_Status", &this->idPIF_MT_Status);
			fibexDB->GetSignalID("PIF_ST_Bin_0", &this->idPIF_ST_Bin_0);
			fibexDB->GetSignalID("PIF_ST_Bin_1", &this->idPIF_ST_Bin_1);
			fibexDB->GetSignalID("PIF_ST_Bin_2", &this->idPIF_ST_Bin_2);
			fibexDB->GetSignalID("PIF_ST_Bin_3", &this->idPIF_ST_Bin_3);
			fibexDB->GetSignalID("PIF_ST_Bin_4", &this->idPIF_ST_Bin_4);
			fibexDB->GetSignalID("PIF_ST_Bin_5", &this->idPIF_ST_Bin_5);
			fibexDB->GetSignalID("PIF_ST_Bin_6", &this->idPIF_ST_Bin_6);
			fibexDB->GetSignalID("PIF_ST_Bin_7", &this->idPIF_ST_Bin_7);
			fibexDB->GetSignalID("PIF_ST_Bin_8", &this->idPIF_ST_Bin_8);
			fibexDB->GetSignalID("PIF_ST_Status", &this->idPIF_ST_Status);

			fibexDB->GetSignalID("EML_GeschwX", &this->idEML_GeschwX);
			fibexDB->GetSignalID("EML_BeschlX", &this->idEML_BeschlX);
			fibexDB->GetSignalID("EML_BeschlY", &this->idEML_BeschlY);
			fibexDB->GetSignalID("TSK_Steigung_02", &this->idTSK_Steigung_02);
			fibexDB->GetSignalID("KBI_angez_Geschw", &this->idKBI_angez_Geschw);

			/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
			this->flexrayCoder = coder;
			this->flexrayCoder->SetListener((groundFilter_T*)this);

			/* Wir h�ren auf die drei PSD-PDUs */
			this->flexrayCoder->ActivePDUEvents(this->idPIF_01);
			this->flexrayCoder->ActivePDUEvents(this->idEML_01);
			this->flexrayCoder->ActivePDUEvents(this->idEML_03);
			this->flexrayCoder->ActivePDUEvents(this->idMotor_16);
			this->flexrayCoder->ActivePDUEvents(this->idKombi_01);
		}
	} while (false);

	return true;
}

void	wassersteinFilter_T::OnShutdownNormal(void)
{
	/* Zyklischen Thread abbrechen */
	this->shutdown = true;
	this->flagged.Set();
	/* cKernelCyclicThread::Release(); */
	this->flagged.Release();

	if (this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}

void	wassersteinFilter_T::OnRun(int32_T type, const void *data, size_t size)
{

	/* Eine unserer PDUs ist da! */
	if (type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		adtf_devicetb::tCoderPDUEvent *coderEvent = (adtf_devicetb::tCoderPDUEvent*)data;
		if (!coderEvent) { return; }

		if (coderEvent->nPayloadLength == 8) {

			if (coderEvent->nPDUID == this->idPIF_01) {
				this->vehicleState_FR.tickCount++; // PDU kommt alle 80ms, �berlauf sollte kein Problem sein
				this->demuxPIF();
				this->RunAlgorithm(flexray);
			}

			if (coderEvent->nPDUID == this->idEML_01) {
				// adtf_devicetb::tSignalValue					EML_GeschwX;
				adtf_devicetb::tSignalValue					EML_BeschlX;

				// this->flexrayCoder->GetSignalValue(this->idEML_GeschwX, &EML_GeschwX);
				this->flexrayCoder->GetSignalValue(this->idEML_BeschlX, &EML_BeschlX);

				// this->vehicleState_FR.unfiltered.velocity = EML_GeschwX.nf64Value;
				this->vehicleState_FR.unfiltered.longAcceleration = (real32_T)EML_BeschlX.nf64Value;
			}

			if (coderEvent->nPDUID == this->idEML_03) {
				adtf_devicetb::tSignalValue					EML_BeschlY;

				this->flexrayCoder->GetSignalValue(this->idEML_BeschlY, &EML_BeschlY);
				this->vehicleState_FR.unfiltered.latAcceleration = (real32_T)EML_BeschlY.nf64Value;
			}

			if (coderEvent->nPDUID == this->idKombi_01) {
				adtf_devicetb::tSignalValue					KBI_angez_Geschw;

				this->flexrayCoder->GetSignalValue(this->idKBI_angez_Geschw, &KBI_angez_Geschw);
				this->vehicleState_FR.unfiltered.velocity = (real32_T)KBI_angez_Geschw.nf64Value/3.6f;
			}

			if (coderEvent->nPDUID == this->idMotor_16) {
				adtf_devicetb::tSignalValue					TSK_Steigung_02;

				this->flexrayCoder->GetSignalValue(this->idTSK_Steigung_02, &TSK_Steigung_02);
				this->vehicleState_FR.slope.slope = (real32_T)TSK_Steigung_02.nf64Value;
			}
		}
	}
}

bool wassersteinFilter_T::demuxPIF(void){

	static driverPrediction_T	driverPrediction;

	adtf_devicetb::tSignalValue					PIF_Identifier;
	adtf_devicetb::tSignalValue					PIF_LT_Bin[dprdBIN_COUNT];
	adtf_devicetb::tSignalValue					PIF_LT_Status;
	adtf_devicetb::tSignalValue					PIF_MT_Bin[dprdBIN_COUNT];
	adtf_devicetb::tSignalValue					PIF_MT_Status;
	adtf_devicetb::tSignalValue					PIF_ST_Bin[dprdBIN_COUNT];
	adtf_devicetb::tSignalValue					PIF_ST_Status;
	adtf_devicetb::tSignalValue					PIF_Toggle;

	this->flexrayCoder->GetSignalValue(this->idPIF_Identifier, &PIF_Identifier);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_0, &PIF_LT_Bin[0]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_1, &PIF_LT_Bin[1]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_2, &PIF_LT_Bin[2]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_3, &PIF_LT_Bin[3]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_4, &PIF_LT_Bin[4]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_5, &PIF_LT_Bin[5]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_6, &PIF_LT_Bin[6]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_7, &PIF_LT_Bin[7]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Bin_8, &PIF_LT_Bin[8]);
	this->flexrayCoder->GetSignalValue(this->idPIF_LT_Status, &PIF_LT_Status);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_0, &PIF_MT_Bin[0]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_1, &PIF_MT_Bin[1]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_2, &PIF_MT_Bin[2]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_3, &PIF_MT_Bin[3]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_4, &PIF_MT_Bin[4]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_5, &PIF_MT_Bin[5]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_6, &PIF_MT_Bin[6]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_7, &PIF_MT_Bin[7]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Bin_8, &PIF_MT_Bin[8]);
	this->flexrayCoder->GetSignalValue(this->idPIF_MT_Status, &PIF_MT_Status);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_0, &PIF_ST_Bin[0]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_1, &PIF_ST_Bin[1]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_2, &PIF_ST_Bin[2]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_3, &PIF_ST_Bin[3]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_4, &PIF_ST_Bin[4]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_5, &PIF_ST_Bin[5]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_6, &PIF_ST_Bin[6]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_7, &PIF_ST_Bin[7]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Bin_8, &PIF_ST_Bin[8]);
	this->flexrayCoder->GetSignalValue(this->idPIF_ST_Status, &PIF_ST_Status);
	this->flexrayCoder->GetSignalValue(this->idPIF_Toggle, &PIF_Toggle);
	
	switch ((uint8_T)PIF_Identifier.nf64Value)
	{
		case (uint8_T)PIF_Identifier_Init:
			break;
		case (uint8_T)PIF_Identifier_Geschwindigkeit:

			this->driverPrediction_FR = driverPrediction;
			memset(&driverPrediction, 0, sizeof(driverPrediction_T));

			if ((uint8_T)PIF_ST_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.shortTermWindow.velocity[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_MT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.midTermWindow.velocity[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_LT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.longTermWindow.velocity[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
				}
			}
			break;
		case (uint8_T)PIF_Identifier_Laengsbeschleunigung:	
			if ((uint8_T)PIF_ST_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.shortTermWindow.longAcceleration[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_MT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.midTermWindow.longAcceleration[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_LT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.longTermWindow.longAcceleration[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
				}
			}
			break;
		case (uint8_T)PIF_Identifier_Leistung:		
			if ((uint8_T)PIF_ST_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.shortTermWindow.wheelPower[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_MT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.midTermWindow.wheelPower[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_LT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.longTermWindow.wheelPower[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
				}
			}
			break;
		case (uint8_T)PIF_Identifier_Querbeschleunigung:
			if ((uint8_T)PIF_ST_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.shortTermWindow.absLatAcceleration[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_MT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.midTermWindow.absLatAcceleration[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_LT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.longTermWindow.absLatAcceleration[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
				}
			}
			break;
		case (uint8_T)PIF_Identifier_Strassenklasse:
			if ((uint8_T)PIF_ST_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.shortTermWindow.streetClass[i] = (uint8_T)PIF_ST_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_MT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.midTermWindow.streetClass[i] = (uint8_T)PIF_MT_Bin[i].nf64Value;
				}
			}
			if ((uint8_T)PIF_LT_Status.nf64Value == 2)
			{
				for (size_t i = 0; i < dprdBIN_COUNT; i++)
				{
					driverPrediction.longTermWindow.streetClass[i] = (uint8_T)PIF_LT_Bin[i].nf64Value;
				}
			}
			break;
		default:	
			break;
	}

	return true;
}


void	wassersteinFilter_T::RunAlgorithm(input input)
{
    // input
	vehicleModel_T		vehicleModel;
	vehicleState_T		vehicleState;
	pemControl_T		pemControl;
	pemControlStack_T	pemControlStack;
	driverPrediction_T	driverPrediction;

	real32_T			cycleTime;

	//output
	static wassersteinList_T		wsList = {0};

    // read input
    vehicleModel    = *(vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();	
    
	if (input == pem)
	{
		pemControl = *(pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();
		vehicleState = pemControl.vehicleState;

		pemControlStack = *(pemControlStack_T*)this->GetInputPin("pemControlStack")->GetDataPtr();
		driverPrediction = pemControlStack.driverPrediction;

		cycleTime = controlCYCLETIME;
	}
	else if (input == flexray)
	{
		vehicleState = this->vehicleState_FR;
		driverPrediction = this->driverPrediction_FR;

		cycleTime = 0.08f;
	}	

	// Rechenschritt
	wsCycle(&vehicleModel, &vehicleState, &driverPrediction, cycleTime, wsList.wsDistance);

	// write output
	this->Submit("wsDistance", &wsList, sizeof(wassersteinList_T));
}

