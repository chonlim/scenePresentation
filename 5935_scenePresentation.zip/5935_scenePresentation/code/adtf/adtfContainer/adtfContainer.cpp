#include "stdafx.h"

/* app */
#include "consoleInterfaceFilter.h"
#include "controlFilter.h"
#include "parameterSetFilter.h"
#include "platformManholeFilter.h"
#include "schedulerFilter.h"
#include "strategyFilter.h"
#include "vehicleModelFilter.h"
#include "rglConverterFilter.h"
#include "rglInputFilter.h"
#include "psdInputFilter.h"
#include "rglBufferFilter.h"

/* sim */
#include "replayFilter.h"
#include "serialPortFilter.h"
#include "simulationFilter.h"

/* display */
#include "planningDisplayFilter.h"
#include "triggerGatewayFilter.h"
#include "vehicleDisplayFilter.h"
#include "wassersteinFilter.h"

/* filter */
#include "gen2FlexrayFilter.h"

/* replay */
#include "rpl2Recorder.h"

/* jobFile */
#include "jobFileFilter.h"

/* zfas */
#include "zfasConverterFilter.h"
#include "clusterGatewayFilter.h"
#include "pfeifferGatewayFilter.h"


#define ADTF_FILTER_ID "IDII.adtfContainer"


ADTF_PLUGIN_BEGIN(adtfContainerPlugin, "IDII ADTF Container", 0x00)

	/* app */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_consoleInterfaceFilter,			consoleInterfaceFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_controlFilter,					controlFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_parameterSetFilter,				parameterSetFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_platformManholeFilter,			platformManholeFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_schedulerFilter,					schedulerFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_strategyFilter,					strategyFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_triggerGatewayFilter,			triggerGatewayFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_vehicleModelFilter,				vehicleModelFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_rglConverterFilter,				rglConverterFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_rglInputFilter,					rglInputFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_psdInputFilter,					psdInputFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_rglBufferFilter,					rglBufferFilter_T)

	/* sim */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_replayFilter,					replayFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_serialPortFilter,				serialPortFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_simulationFilter,				simulationFilter_T)

	/* display */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_planningDisplayFilter,			planningDisplayFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_vehicleDisplayFilter,			vehicleDisplayFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_wassersteinFilter,				wassersteinFilter_T)

	/* filter */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_gen2FlexrayFilter,				gen2FlexrayFilter_T)

	/* replay */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_rpl2Recorder,					rpl2Recorder_T)

	/* jobFile */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_jobFileFilter,					jobFileFilter_T)

	/* zfas */
	ADTF_MAP_FILTER(ADTF_FILTER_ID_zfasConverterFilter,				zfasConverterFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_clusterGatewayFilter,			clusterGatewayFilter_T)
	ADTF_MAP_FILTER(ADTF_FILTER_ID_pfeifferGatewayFilter,			pfeifferGatewayFilter_T)

ADTF_PLUGIN_END(adtfContainerPlugin)
