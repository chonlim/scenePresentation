#ifndef guard_consoleInterfaceFilter_h
#define guard_consoleInterfaceFilter_h


#include "baseFilter.h"

#define ADTF_FILTER_ID_consoleInterfaceFilter		"IDII.consoleInterfaceFilter"
#define ADTF_FILTER_NAME_consoleInterfaceFilter	"IDII consoleInterfaceFilter"


class consoleInterfaceFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_consoleInterfaceFilter, ADTF_FILTER_NAME_consoleInterfaceFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

public:
	consoleInterfaceFilter_T(const tChar* __info);

	void		OnReceive(void);
};


#endif
