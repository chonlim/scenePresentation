#include "stdafx.h"
#include "rglConverterFilter.h"
#include "rglConverterTypes.h"

#undef		GetObject
#pragma warning(disable : 4355)


typedef struct canMessage_tag {
	int16_T		id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


rglConverterFilter_T::rglConverterFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("psdInput",			MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("canPSD",				MEDIA_TYPE_CAN,				MEDIA_SUBTYPE_CAN_RAW_MESSAGE);

	this->inputPin_canPSD	= this->GetInputPin("canPSD");
	this->inputPin_psdInput	= this->GetInputPin("psdInput");

	this->AddOutputPin("PpPSD15__DePSD04",   MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD05",   MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m0", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m1", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m2", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m3", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m4", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
}


void	rglConverterFilter_T::OnReceive(void)
{
	if(this->inputPin_canPSD->Unflag()) {
		if(sizeof(canMessage_T) == this->inputPin_canPSD->GetDataSize()) {
			canMessage_T message = *(canMessage_T*)this->inputPin_canPSD->GetDataPtr();
			this->Process_CAN(message.id, message.data, _clock->GetStreamTime());
		}
	}


	if(this->inputPin_psdInput->Unflag()) {
		if(sizeof(psdInput_T) == this->inputPin_psdInput->GetDataSize()) {
			psdInput_T psdInput = *(psdInput_T*)this->inputPin_psdInput->GetDataPtr();
			this->Process_Input(&psdInput, _clock->GetStreamTime());
		}
	}

}


bool rglConverterFilter_T::Process_CAN(uint32_T id, const uint8_T *data, tTimeStamp time)
{
	/* PSD_04 */
	if (id == 1122)	{
		Dt_RECORD_PsdEhr_Psd4Message psdMsg04 = { 0 };

		psdMsg04.PSD_Segment_ID						= ((data[0] & 0x3F) >> 0);								// psdMsg04.id
		psdMsg04.PSD_Vorgaenger_Segment_ID			= ((data[0] & 0xC0) >> 6) | ((data[1] & 0x0F) << 2);	// psdMsg04.parentId
		psdMsg04.PSD_Segmentlaenge					= ((data[1] & 0xF0) >> 4) | ((data[2] & 0x07) << 4);	// psdMsg04.length
		psdMsg04.PSD_Strassenkategorie				= ((data[2] & 0x38) >> 3);								// psdMsg04.streetClass
		psdMsg04.PSD_Endkruemmung					= ((data[2] & 0xC0) >> 6) | ((data[3] & 0x3F) << 2);	// psdMsg04.curvatureEnd
		psdMsg04.PSD_Endkruemmung_Vorz				= ((data[3] & 0x40) >> 6);								// psdMsg04.curvatureEndSign
		psdMsg04.PSD_Idenditaets_ID					= ((data[3] & 0x80) >> 7) | ((data[4] & 0x1F) << 1);	// psdMsg04.identity
		psdMsg04.PSD_ADAS_Qualitaet					= ((data[4] & 0x20) >> 5);								// psdMsg04.isADASQuality
		psdMsg04.PSD_wahrscheinlichster_Pfad		= ((data[4] & 0x40) >> 6);								// psdMsg04.isMostProbablePath
		psdMsg04.PSD_Geradester_Pfad				= ((data[4] & 0x80) >> 7);								// psdMsg04.isStraightestPath
		psdMsg04.PSD_Fahrspuren_Anzahl				= ((data[5] & 0x07) >> 0);								// psdMsg04.lanes
		psdMsg04.PSD_Bebauung						= ((data[5] & 0x08) >> 3);								// psdMsg04.isBuiltUpArea
		psdMsg04.PSD_Segment_Komplett				= ((data[5] & 0x10) >> 4);								// psdMsg04.completeFlag
		psdMsg04.PSD_Rampe							= ((data[5] & 0x60) >> 5);								// psdMsg04.ramp
		psdMsg04.PSD_Anfangskruemmung				= ((data[5] & 0x80) >> 7) | ((data[6] & 0x7F) << 1);	// psdMsg04.curvatureStart
		psdMsg04.PSD_Anfangskruemmung_Vorz			= ((data[6] & 0x80) >> 7);								// psdMsg04.curvatureStartSign
		psdMsg04.PSD_Abzweigerichtung				= ((data[7] & 0x01) >> 0);								// psdMsg04.branchDirection
		psdMsg04.PSD_Abzweigewinkel					= ((data[7] & 0xFE) >> 1);								// psdMsg04.branchAngle

		psdMsg04.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
		psdMsg04.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg04.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
		psdMsg04.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg04.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
		psdMsg04.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

		this->Submit("PpPSD15__DePSD04", &psdMsg04, sizeof(psdMsg04));
	}


	/* PSD_05 */
	if (id == 1123) {
		static Dt_RECORD_PsdEhr_Psd5Message psdMsg05 = { 0 };

		psdMsg05.PSD_Pos_Segment_ID					= ((data[0] & 0x3F) >> 0);								// psdMsg05.positionId
		psdMsg05.PSD_Pos_Segmentlaenge				= ((data[0] & 0xC0) >> 6) | ((data[1] & 0x1F) << 2);	// psdMsg05.positionLength
		psdMsg05.PSD_Pos_Inhibitzeit				= ((data[1] & 0xE0) >> 5) | ((data[2] & 0x03) << 3);	// psdMsg05.positionInhibitTime
		psdMsg05.PSD_Pos_Standort_Eindeutig			= ((data[2] & 0x04) >> 2);								// psdMsg05.positionIsLocationUnique
		psdMsg05.PSD_Pos_Fehler_Laengsrichtung		= ((data[2] & 0x38) >> 3);								// psdMsg05.positionLongitudinalError
		psdMsg05.PSD_Pos_Fahrspur					= ((data[2] & 0xC0) >> 6) | ((data[3] & 0x01) << 2);	// psdMsg05.positionLane
		psdMsg05.PSD_Attribut_Segment_ID_05			= ((data[3] & 0x7E) >> 1);								// psdMsg05.attributesSegmentId
		psdMsg05.PSD_Attribut_1_ID					= ((data[3] & 0x80) >> 7) | ((data[4] & 0x0F) << 1);	// psdMsg05.attribute1Type
		psdMsg05.PSD_Attribut_1_Wert				= ((data[4] & 0xF0) >> 4);								// psdMsg05.attribute1Value
		psdMsg05.PSD_Attribut_1_Offset				= ((data[5] & 0x7F) >> 0);								// psdMsg05.attribute1Offset
		psdMsg05.PSD_Attribut_2_ID					= ((data[5] & 0x80) >> 7) | ((data[6] & 0x0F) << 1);	// psdMsg05.attribute2Type
		psdMsg05.PSD_Attribut_2_Wert				= ((data[6] & 0xF0) >> 4);								// psdMsg05.attribute2Value
		psdMsg05.PSD_Attribut_2_Offset				= ((data[7] & 0x7F) >> 0);								// psdMsg05.attribute2Offset
		psdMsg05.PSD_Attribute_Komplett_05			= ((data[7] & 0x80) >> 7);								// psdMsg05.completeFlag

		psdMsg05.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
		psdMsg05.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg05.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
		psdMsg05.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg05.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
		psdMsg05.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

		this->Submit("PpPSD15__DePSD05", &psdMsg05, sizeof(psdMsg05));
	}


	/* PSD_06 */
	if (id == 1124) {
		if ((data[0] & 0x07) == 0) {
			static Dt_RECORD_PsdEhr_Psd60Message psdMsg60 = { 0 };

			psdMsg60.PSD_Sys_Segment_ID					= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);		// psdMsg060.id
			psdMsg60.PSD_Sys_Laendercode				= ((data[1] & 0xFE) >> 1) | ((data[2] & 0x01) << 7);		// psdMsg060.countryCode
			psdMsg60.PSD_Sys_Geschwindigkeit_Einheit	= ((data[2] & 0x02) >> 1);									// psdMsg060.unitSpeed
			psdMsg60.PSD_Sys_Verkehrsrichtung			= ((data[2] & 0x04) >> 2);									// psdMsg060.trafficDirection
			psdMsg60.PSD_Sys_Quali_Geometrien			= ((data[2] & 0x18) >> 3);									// psdMsg060.qualityGeometry
			psdMsg60.PSD_Sys_Mapmatchingguete			= ((data[2] & 0x60) >> 5);									// psdMsg060.qualityMapMatching
			psdMsg60.PSD_Sys_Alter_Karte				= ((data[2] & 0x80) >> 7) | ((data[3] & 0x03) << 1);		// psdMsg060.ageMapData
			psdMsg60.PSD_Sys_Zielfuehrung				= ((data[3] & 0x04) >> 2);									// psdMsg060.isRoutingActive
			psdMsg60.PSD_Sys_US_State					= ((data[3] & 0xF8) >> 3) | ((data[4] & 0x01) << 5);		// psdMsg060.usStateCode

			psdMsg60.PSD_Sys_Zielfuehrung_geaendert		= ((data[4] & 0x80) >> 7);									// psdMsg060.isRoutingChanged
			psdMsg60.PSD_Sys_Geometrieguete_erweitert	= ((data[5] & 0xFF) >> 0);									// psdMsg060.qualityGeometryExt
			psdMsg60.PSD_Sys_Geometrieguete				= ((data[4] & 0x0E) >> 1);									// psdMsg060.regionQualiGeometry
			psdMsg60.PSD_Sys_Quali_Ortsinfo				= ((data[4] & 0x30) >> 4);									// psdMsg060.regionQualiPlaceInfo
			psdMsg60.PSD_Sys_Quali_verfuegbar			= ((data[4] & 0x40) >> 6);									// psdMsg060.regionQualiAvailable
			psdMsg60.PSD_Sys_Quali_sonstige_Attribute	= ((data[6] & 0x07) >> 0);									// psdMsg060.regionQualiSpecialInfo
			psdMsg60.PSD_Sys_Quali_Steigungen			= ((data[6] & 0x38) >> 3);									// psdMsg060.regionQualiSlope
			psdMsg60.PSD_Sys_Quali_Strassenkennz		= ((data[6] & 0xC0) >> 6) | ((data[7] & 0x01 << 2));		// psdMsg060.regionQualiStreetLabel
			psdMsg60.PSD_Sys_Quali_Tempolimits			= ((data[7] & 0x0E) >> 1);									// psdMsg060.regionQualiSpeedLimit
			psdMsg60.PSD_Sys_Quali_Vorfahrtsregelung	= ((data[7] & 0x70) >> 4);									// psdMsg060.regionQualiRightOfWayRules

			psdMsg60.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg60.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg60.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg60.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg60.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg60.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m0", &psdMsg60, sizeof(psdMsg60));
		}

		if ((data[0] & 0x07) == 1) {
			static Dt_RECORD_PsdEhr_Psd61Message psdMsg61 = { 0 };

			psdMsg61.PSD_Attribut_Segment_ID			= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);		// psdMsg061.attributesSegmentId
			psdMsg61.PSD_Attribut_3_ID					= ((data[1] & 0x3E) >> 1);									// psdMsg061.attribute1Type

			psdMsg61.PSD_Attribut_3_Wert				= ((data[2] & 0xE0) >> 5) | ((data[3] & 0x01) << 3);		// psdMsg061.attribute1Value
			psdMsg61.PSD_Attribut_3_Offset				= ((data[1] & 0xC0) >> 6) | ((data[2] & 0x1F) << 2);		// psdMsg061.attribute1Offset
			psdMsg61.PSD_Attribut_4_ID					= ((data[3] & 0x3E) >> 1);									// psdMsg061.attribute2Type
			psdMsg61.PSD_Attribut_4_Wert				= ((data[3] & 0xC0) >> 6) | ((data[4] & 0x03) << 2);		// psdMsg061.attribute2Value
			psdMsg61.PSD_Attribut_4_Offset				= ((data[4] & 0xFC) >> 2) | ((data[5] & 0x01) << 6);		// psdMsg061.attribute2Offset
			psdMsg61.PSD_Attribut_5_ID					= ((data[5] & 0x3E) >> 1);									// psdMsg061.attribute3Type

			psdMsg61.PSD_Attribut_5_Wert				= ((data[6] & 0xE0) >> 5) | ((data[7] & 0x01) << 3);		// psdMsg061.attribute3Value
			psdMsg61.PSD_Attribut_5_Offset				= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x1F) << 2);		// psdMsg061.attribute3Offset
			psdMsg61.PSD_Attribute_Komplett_06			= ((data[7] & 0x02) >> 1);									// psdMsg061.completeFlag

			psdMsg61.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg61.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg61.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg61.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg61.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg61.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m1", &psdMsg61, sizeof(psdMsg61));
		}

		if ((data[0] & 0x07) == 2) {
			static Dt_RECORD_PsdEhr_Psd62Message psdMsg62 = { 0 };

			psdMsg62.PSD_Ges_Segment_ID					= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);		// psdMsg062.id
			psdMsg62.PSD_Ges_Offset						= ((data[1] & 0xFE) >> 1);									// psdMsg062.offset
			psdMsg62.PSD_Ges_Geschwindigkeit			= ((data[2] & 0x1F) >> 0);									// psdMsg062.speedLimit
			psdMsg62.PSD_Ges_Typ						= ((data[2] & 0x60) >> 5);									// psdMsg062.type
			psdMsg62.PSD_Ges_Spur_Geschw_Begrenzung		= ((data[2] & 0x80) >> 7) | ((data[3] & 0x1F) << 1);		// psdMsg062.constraintLane
			psdMsg62.PSD_Ges_Geschwindigkeit_Gespann	= ((data[3] & 0x60) >> 5);									// psdMsg062.constraintTrailer
			psdMsg62.PSD_Ges_Geschwindigkeit_Witter		= ((data[3] & 0x80) >> 7) | ((data[4] & 0x01) << 1);		// psdMsg062.constraintWeather
			psdMsg62.PSD_Ges_Geschwindigkeit_Tag_Anf	= ((data[4] & 0x0E) >> 1);									// psdMsg062.constraintWeekDayStart
			psdMsg62.PSD_Ges_Geschwindigkeit_Tag_Ende	= ((data[4] & 0x70) >> 4);									// psdMsg062.constraintWeekDayEnd
			psdMsg62.PSD_Ges_Geschwindigkeit_Std_Anf	= ((data[4] & 0x80) >> 7) | ((data[5] & 0x0F) << 1);		// psdMsg062.constraintHourStart
			psdMsg62.PSD_Ges_Geschwindigkeit_Std_Ende	= ((data[5] & 0xF0) >> 4) | ((data[6] & 0x01) << 4);		// psdMsg062.constraintHourEnd
			psdMsg62.PSD_Ges_Ueberholverbot				= ((data[6] & 0x06) >> 1);									// psdMsg062.noPassingSign
			psdMsg62.PSD_Ges_Wechselverkehrszeichen		= ((data[6] & 0x38) >> 3);									// psdMsg062.variableMessageSign
			psdMsg62.PSD_Wechselverkehrszeichen_Typ		= ((data[6] & 0xC0) >> 6);									// psdMsg062.variableMessageSignType
			psdMsg62.PSD_Ges_Gesetzlich_Kategorie		= ((data[7] & 0x07) >> 0);									// psdMsg062.constraintLegalStreetClass
			psdMsg62.PSD_Ges_Gesetzlich_Zusatz			= ((data[7] & 0x18) >> 3);									// psdMsg062.constraintLegalAddition
			psdMsg62.PSD_Ges_Verkehrszeichen_Quelle		= ((data[7] & 0x60) >> 5);									// psdMsg062.sourceSpeedLimit
			psdMsg62.PSD_Ges_Attribute_Komplett			= ((data[7] & 0x80) >> 7);									// psdMsg062.completeFlag

			psdMsg62.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg62.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg62.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg62.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg62.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg62.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m2", &psdMsg62, sizeof(psdMsg62));
		}

		if ((data[0] & 0x07) == 3) {
			static Dt_RECORD_PsdEhr_Psd63Message psdMsg63 = { 0 };

			psdMsg63.PSD_Baum_Laenge_VZ		= ((data[0] & 0x08) >> 3);																						// psdMsg063.longitudeSign
			psdMsg63.PSD_Baum_Laenge		= ((data[0] & 0xF0) >> 4) | ((data[1] & 0xFF) << 4) | ((data[2] & 0xFF) << 12) | ((data[3] & 0x1F) << 20);		// psdMsg063.longitude
			psdMsg63.PSD_Baum_Breite_VZ		= ((data[3] & 0x10) >> 4);																						// psdMsg063.latitudeSign
			psdMsg63.PSD_Baum_Breite		= ((data[3] & 0xC0) >> 6) | ((data[4] & 0xFF) << 2) | ((data[5] & 0xFF) << 10) | ((data[6] & 0x3F) << 18);		// psdMsg063.latitude
			psdMsg63.PSD_Baum_Ausrichtung	= ((data[6] & 0xC0) >> 6) | ((data[7] & 0xFF) << 2);															// psdMsg063.direction

			psdMsg63.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg63.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg63.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg63.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg63.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg63.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m3", &psdMsg63, sizeof(psdMsg63));
	}

		if ((data[0] & 0x07) == 4) {
			static Dt_RECORD_PsdEhr_Psd64Message psdMsg64 = { 0 };

			psdMsg64.PSD_Steigung_1_Segment_ID		= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);				// psdMsg064.segment1Id
			psdMsg64.PSD_Steigung_1_A_Steigung		= ((data[1] & 0xFE) >> 1);											// psdMsg064.segment1Slope1Value
			psdMsg64.PSD_Steigung_1_A_Vorz			= ((data[2] & 0x01) >> 0);											// psdMsg064.segment1Slope1Sign
			psdMsg64.PSD_Steigung_1_A_Offset		= ((data[2] & 0xFE) >> 1);											// psdMsg064.segment1Slope1Offset
			psdMsg64.PSD_Steigung_1_B_Steigung		= ((data[3] & 0x7F) >> 0);											// psdMsg064.segment1Slope2Value
			psdMsg64.PSD_Steigung_1_B_Vorz			= ((data[3] & 0x80) >> 7);											// psdMsg064.segment1Slope2Sign
			psdMsg64.PSD_Steigung_1_B_Offset		= ((data[4] & 0x7F) >> 0);											// psdMsg064.segment1Slope2Offset
			psdMsg64.PSD_Steigung_1_Attribute_kompl = ((data[4] & 0x80) >> 7);											// psdMsg064.segment1CompleteFlag
			psdMsg64.PSD_Steigung_2_Segment_ID		= ((data[5] & 0x3F) >> 0);											// psdMsg064.segment2Id
			psdMsg64.PSD_Steigung_2_Steigung		= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x1F) << 2);				// psdMsg064.segment2Slope1Value
			psdMsg64.PSD_Steigung_2_Vorz			= ((data[6] & 0x20) >> 5);											// psdMsg064.segment2Slope1Sign
			psdMsg64.PSD_Steigung_2_Offset			= ((data[6] & 0xC0) >> 6) | ((data[7] & 0x1F) << 2);				// psdMsg064.segment2Slope1Offset
			psdMsg64.PSD_Steigung_2_Attribute_kompl = ((data[7] & 0x20) >> 5);											// psdMsg064.segment2CompleteFlag

			psdMsg64.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg64.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg64.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg64.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg64.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg64.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m4", &psdMsg64, sizeof(psdMsg64));
		}
	}


	return true;
}


bool rglConverterFilter_T::Process_Input(psdInput_T *psdInput, tTimeStamp time)
{
	/* PSD_04 */
	if (psdInput->type == psdMessage4)	{
		Dt_RECORD_PsdEhr_Psd4Message psdMsg04 = { 0 };

		psdMsg04.PSD_Segment_ID						= psdInput->data.psd4.id;
		psdMsg04.PSD_Vorgaenger_Segment_ID			= psdInput->data.psd4.parentId;
		psdMsg04.PSD_Segmentlaenge					= psdInput->data.psd4.length;
		psdMsg04.PSD_Strassenkategorie				= psdInput->data.psd4.streetClass;
		psdMsg04.PSD_Endkruemmung					= psdInput->data.psd4.curvatureEnd;
		psdMsg04.PSD_Endkruemmung_Vorz				= psdInput->data.psd4.curvatureEndSign;
		psdMsg04.PSD_Idenditaets_ID					= psdInput->data.psd4.identity;
		psdMsg04.PSD_ADAS_Qualitaet					= psdInput->data.psd4.isADASQuality;
		psdMsg04.PSD_wahrscheinlichster_Pfad		= psdInput->data.psd4.isMostProbablePath;
		psdMsg04.PSD_Geradester_Pfad				= psdInput->data.psd4.isStraightestPath;
		psdMsg04.PSD_Fahrspuren_Anzahl				= psdInput->data.psd4.lanes;
		psdMsg04.PSD_Bebauung						= psdInput->data.psd4.isBuiltUpArea;
		psdMsg04.PSD_Segment_Komplett				= psdInput->data.psd4.completeFlag;
		psdMsg04.PSD_Rampe							= psdInput->data.psd4.ramp;
		psdMsg04.PSD_Anfangskruemmung				= psdInput->data.psd4.curvatureStart;
		psdMsg04.PSD_Anfangskruemmung_Vorz			= psdInput->data.psd4.curvatureStartSign;
		psdMsg04.PSD_Abzweigerichtung				= psdInput->data.psd4.branchDirection;
		psdMsg04.PSD_Abzweigewinkel					= psdInput->data.psd4.branchAngle;

		psdMsg04.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
		psdMsg04.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg04.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
		psdMsg04.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg04.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
		psdMsg04.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

		this->Submit("PpPSD15__DePSD04", &psdMsg04, sizeof(psdMsg04));
	}


	/* PSD_05 */
	if (psdInput->type == psdMessage5) {
		static Dt_RECORD_PsdEhr_Psd5Message psdMsg05 = { 0 };

		psdMsg05.PSD_Pos_Segment_ID					= psdInput->data.psd5.positionId;
		psdMsg05.PSD_Pos_Segmentlaenge				= psdInput->data.psd5.positionLength;
		psdMsg05.PSD_Pos_Inhibitzeit				= psdInput->data.psd5.positionInhibitTime;
		psdMsg05.PSD_Pos_Standort_Eindeutig			= psdInput->data.psd5.positionIsLocationUnique;
		psdMsg05.PSD_Pos_Fehler_Laengsrichtung		= psdInput->data.psd5.positionLongitudinalError;
		psdMsg05.PSD_Pos_Fahrspur					= psdInput->data.psd5.positionLane;
		psdMsg05.PSD_Attribut_Segment_ID_05			= psdInput->data.psd5.attributesSegmentId;
		psdMsg05.PSD_Attribut_1_ID					= psdInput->data.psd5.attribute1Type;
		psdMsg05.PSD_Attribut_1_Wert				= psdInput->data.psd5.attribute1Value;
		psdMsg05.PSD_Attribut_1_Offset				= psdInput->data.psd5.attribute1Offset;
		psdMsg05.PSD_Attribut_2_ID					= psdInput->data.psd5.attribute2Type;
		psdMsg05.PSD_Attribut_2_Wert				= psdInput->data.psd5.attribute2Value;
		psdMsg05.PSD_Attribut_2_Offset				= psdInput->data.psd5.attribute2Offset;
		psdMsg05.PSD_Attribute_Komplett_05			= psdInput->data.psd5.completeFlag;

		psdMsg05.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
		psdMsg05.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg05.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
		psdMsg05.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
		psdMsg05.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
		psdMsg05.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

		this->Submit("PpPSD15__DePSD05", &psdMsg05, sizeof(psdMsg05));
	}


	/* PSD_06 */
	if (psdInput->type == psdMessage6) {
		if (psdInput->data.psd6.multiplex == 0) {
			static Dt_RECORD_PsdEhr_Psd60Message psdMsg60 = { 0 };

			psdMsg60.PSD_Sys_Segment_ID					= psdInput->data.psd6.message.m0.id;
			psdMsg60.PSD_Sys_Laendercode				= psdInput->data.psd6.message.m0.countryCode;
			psdMsg60.PSD_Sys_Geschwindigkeit_Einheit	= psdInput->data.psd6.message.m0.unitSpeed;
			psdMsg60.PSD_Sys_Verkehrsrichtung			= psdInput->data.psd6.message.m0.trafficDirection;
			psdMsg60.PSD_Sys_Geometrieguete				= psdInput->data.psd6.message.m0.qualityGeometry;
			psdMsg60.PSD_Sys_Mapmatchingguete			= psdInput->data.psd6.message.m0.qualityMapMatching;
			psdMsg60.PSD_Sys_Alter_Karte				= psdInput->data.psd6.message.m0.ageMapData;
			psdMsg60.PSD_Sys_Zielfuehrung				= psdInput->data.psd6.message.m0.isRoutingActive;
			psdMsg60.PSD_Sys_US_State					= psdInput->data.psd6.message.m0.usStateCode;

			psdMsg60.PSD_Sys_Zielfuehrung_geaendert		= psdInput->data.psd6.message.m0.isRoutingChanged;
			psdMsg60.PSD_Sys_Geometrieguete_erweitert	= psdInput->data.psd6.message.m0.qualityGeometryExt;
			psdMsg60.PSD_Sys_Quali_Geometrien			= psdInput->data.psd6.message.m0.regionQualiGeometry;
			psdMsg60.PSD_Sys_Quali_Ortsinfo				= psdInput->data.psd6.message.m0.regionQualiPlaceInfo;
			psdMsg60.PSD_Sys_Quali_verfuegbar			= psdInput->data.psd6.message.m0.regionQualiAvailable;
			psdMsg60.PSD_Sys_Quali_sonstige_Attribute	= psdInput->data.psd6.message.m0.regionQualiSpecialInfo;
			psdMsg60.PSD_Sys_Quali_Steigungen			= psdInput->data.psd6.message.m0.regionQualiSlope;
			psdMsg60.PSD_Sys_Quali_Strassenkennz		= psdInput->data.psd6.message.m0.regionQualiStreetLabel;
			psdMsg60.PSD_Sys_Quali_Tempolimits			= psdInput->data.psd6.message.m0.regionQualiSpeedLimit;
			psdMsg60.PSD_Sys_Quali_Vorfahrtsregelung	= psdInput->data.psd6.message.m0.regionQualiRightOfWayRules;

			psdMsg60.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg60.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg60.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg60.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg60.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg60.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m0", &psdMsg60, sizeof(psdMsg60));
		}

		if (psdInput->data.psd6.multiplex == 1) {
			static Dt_RECORD_PsdEhr_Psd61Message psdMsg61 = { 0 };

			psdMsg61.PSD_Attribut_Segment_ID			= psdInput->data.psd6.message.m1.attributesSegmentId;
			psdMsg61.PSD_Attribut_3_ID					= psdInput->data.psd6.message.m1.attribute1Type;

			psdMsg61.PSD_Attribut_3_Wert				= psdInput->data.psd6.message.m1.attribute1Value;
			psdMsg61.PSD_Attribut_3_Offset				= psdInput->data.psd6.message.m1.attribute1Offset;
			psdMsg61.PSD_Attribut_4_ID					= psdInput->data.psd6.message.m1.attribute2Type;
			psdMsg61.PSD_Attribut_4_Wert				= psdInput->data.psd6.message.m1.attribute2Value;
			psdMsg61.PSD_Attribut_4_Offset				= psdInput->data.psd6.message.m1.attribute2Offset;
			psdMsg61.PSD_Attribut_5_ID					= psdInput->data.psd6.message.m1.attribute3Type;

			psdMsg61.PSD_Attribut_5_Wert				= psdInput->data.psd6.message.m1.attribute3Value;
			psdMsg61.PSD_Attribut_5_Offset				= psdInput->data.psd6.message.m1.attribute3Offset;
			psdMsg61.PSD_Attribute_Komplett_06			= psdInput->data.psd6.message.m1.completeFlag;

			psdMsg61.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg61.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg61.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg61.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg61.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg61.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m1", &psdMsg61, sizeof(psdMsg61));
		}

		if (psdInput->data.psd6.multiplex == 2) {
			static Dt_RECORD_PsdEhr_Psd62Message psdMsg62 = { 0 };

			psdMsg62.PSD_Ges_Segment_ID					= psdInput->data.psd6.message.m2.id;
			psdMsg62.PSD_Ges_Offset						= psdInput->data.psd6.message.m2.offset;
			psdMsg62.PSD_Ges_Geschwindigkeit			= psdInput->data.psd6.message.m2.speedLimit;
			psdMsg62.PSD_Ges_Typ						= psdInput->data.psd6.message.m2.type;
			psdMsg62.PSD_Ges_Spur_Geschw_Begrenzung		= psdInput->data.psd6.message.m2.constraintLane;
			psdMsg62.PSD_Ges_Geschwindigkeit_Gespann	= psdInput->data.psd6.message.m2.constraintTrailer;
			psdMsg62.PSD_Ges_Geschwindigkeit_Witter		= psdInput->data.psd6.message.m2.constraintWeather;
			psdMsg62.PSD_Ges_Geschwindigkeit_Tag_Anf	= psdInput->data.psd6.message.m2.constraintWeekDayStart;
			psdMsg62.PSD_Ges_Geschwindigkeit_Tag_Ende	= psdInput->data.psd6.message.m2.constraintWeekDayEnd;
			psdMsg62.PSD_Ges_Geschwindigkeit_Std_Anf	= psdInput->data.psd6.message.m2.constraintHourStart;
			psdMsg62.PSD_Ges_Geschwindigkeit_Std_Ende	= psdInput->data.psd6.message.m2.constraintHourEnd;
			psdMsg62.PSD_Ges_Ueberholverbot				= psdInput->data.psd6.message.m2.noPassingSign;
			psdMsg62.PSD_Ges_Wechselverkehrszeichen		= psdInput->data.psd6.message.m2.variableMessageSign;
			psdMsg62.PSD_Wechselverkehrszeichen_Typ		= psdInput->data.psd6.message.m2.variableMessageSignType;
			psdMsg62.PSD_Ges_Gesetzlich_Kategorie		= psdInput->data.psd6.message.m2.constraintLegalStreetClass;
			psdMsg62.PSD_Ges_Gesetzlich_Zusatz			= psdInput->data.psd6.message.m2.constraintLegalAddition;
			psdMsg62.PSD_Ges_Verkehrszeichen_Quelle		= psdInput->data.psd6.message.m2.sourceSpeedLimit;
			psdMsg62.PSD_Ges_Attribute_Komplett			= psdInput->data.psd6.message.m2.completeFlag;

			psdMsg62.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg62.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg62.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg62.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg62.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg62.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m2", &psdMsg62, sizeof(psdMsg62));
		}

		if (psdInput->data.psd6.multiplex == 3) {
			static Dt_RECORD_PsdEhr_Psd63Message psdMsg63 = { 0 };

			psdMsg63.PSD_Baum_Laenge_VZ		= psdInput->data.psd6.message.m3.longitudeSign;
			psdMsg63.PSD_Baum_Laenge		= psdInput->data.psd6.message.m3.longitude;
			psdMsg63.PSD_Baum_Breite_VZ		= psdInput->data.psd6.message.m3.latitudeSign;
			psdMsg63.PSD_Baum_Breite		= psdInput->data.psd6.message.m3.latitude;
			psdMsg63.PSD_Baum_Ausrichtung	= psdInput->data.psd6.message.m3.direction;

			psdMsg63.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg63.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg63.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg63.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg63.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg63.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m3", &psdMsg63, sizeof(psdMsg63));
	}

		if (psdInput->data.psd6.multiplex == 4) {
			static Dt_RECORD_PsdEhr_Psd64Message psdMsg64 = { 0 };

			psdMsg64.PSD_Steigung_1_Segment_ID		= psdInput->data.psd6.message.m4.segment1Id;
			psdMsg64.PSD_Steigung_1_A_Steigung		= psdInput->data.psd6.message.m4.segment1Slope1Value;
			psdMsg64.PSD_Steigung_1_A_Vorz			= psdInput->data.psd6.message.m4.segment1Slope1Sign;
			psdMsg64.PSD_Steigung_1_A_Offset		= psdInput->data.psd6.message.m4.segment1Slope1Offset;
			psdMsg64.PSD_Steigung_1_B_Steigung		= psdInput->data.psd6.message.m4.segment1Slope2Value;
			psdMsg64.PSD_Steigung_1_B_Vorz			= psdInput->data.psd6.message.m4.segment1Slope2Sign;
			psdMsg64.PSD_Steigung_1_B_Offset		= psdInput->data.psd6.message.m4.segment1Slope2Offset;
			psdMsg64.PSD_Steigung_1_Attribute_kompl = psdInput->data.psd6.message.m4.segment1CompleteFlag;
			psdMsg64.PSD_Steigung_2_Segment_ID		= psdInput->data.psd6.message.m4.segment2Id;
			psdMsg64.PSD_Steigung_2_Steigung		= psdInput->data.psd6.message.m4.segment2Slope1Value;
			psdMsg64.PSD_Steigung_2_Vorz			= psdInput->data.psd6.message.m4.segment2Slope1Sign;
			psdMsg64.PSD_Steigung_2_Offset			= psdInput->data.psd6.message.m4.segment2Slope1Offset;
			psdMsg64.PSD_Steigung_2_Attribute_kompl = psdInput->data.psd6.message.m4.segment2CompleteFlag;

			psdMsg64.DeTimestamp.DeTimestampMW_RX.DeTimestampHigh	= time >> 32;
			psdMsg64.DeTimestamp.DeTimestampMW_RX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg64.DeTimestamp.DeTimestampMW_TX.DeTimestampHigh	= time >> 32;
			psdMsg64.DeTimestamp.DeTimestampMW_TX.DeTimestampLow	= time & 0xFFFFFFFF;
			psdMsg64.DeTimestamp.DeTimestampZGT.DeTimestampHigh		= time >> 32;
			psdMsg64.DeTimestamp.DeTimestampZGT.DeTimestampLow		= time & 0xFFFFFFFF;

			this->Submit("PpPSD15__DePSD06m4", &psdMsg64, sizeof(psdMsg64));
		}
	}


	return true;
}


