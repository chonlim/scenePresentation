#ifndef guard_waveFile_h
#define guard_waveFile_h

#include <windows.h>
#include "../adtfFilter.h"


class waveFile_T {
private:
	HANDLE			file;
	uint32_T		dataSize;
	uint32_T		headerSize;

	enum waveFormat_T
	{	/* Major formats. */
		SF_FORMAT_WAV = 0x010000,		/* Microsoft WAV format (little endian default). */
		SF_FORMAT_AIFF = 0x020000,		/* Apple/SGI AIFF format (big endian). */
		SF_FORMAT_AU = 0x030000,		/* Sun/NeXT AU format (big endian). */
		SF_FORMAT_RAW = 0x040000,		/* RAW PCM data. */
		SF_FORMAT_PAF = 0x050000,		/* Ensoniq PARIS file format. */
		SF_FORMAT_SVX = 0x060000,		/* Amiga IFF / SVX8 / SV16 format. */
		SF_FORMAT_NIST = 0x070000,		/* Sphere NIST format. */
		SF_FORMAT_VOC = 0x080000,		/* VOC files. */
		SF_FORMAT_IRCAM = 0x0A0000,		/* Berkeley/IRCAM/CARL */
		SF_FORMAT_W64 = 0x0B0000,		/* Sonic Foundry's 64 bit RIFF/WAV */

		/* Subtypes from here on. */
		SF_FORMAT_PCM = 0x0001,		    /* PCM. */

		SF_FORMAT_PCM_S8 = 0x0001,		/* Signed 8 bit data */
		SF_FORMAT_PCM_16 = 0x0002,		/* Signed 16 bit data */
		SF_FORMAT_PCM_24 = 0x0003,		/* Signed 24 bit data */
		SF_FORMAT_PCM_32 = 0x0004,		/* Signed 32 bit data */

		SF_FORMAT_PCM_U8 = 0x0005,		/* Unsigned 8 bit data (WAV and RAW only) */

		SF_FORMAT_FLOAT = 0x0006,		/* 32 bit float data */
		SF_FORMAT_DOUBLE = 0x0007,		/* 64 bit float data */
	};


public:
	waveFile_T();
	~waveFile_T();

	bool		Open(const char_T *fileName, const uint16_T numChannels, const uint32_T samplesPerSecond, const uint32_T bitsPerSample);
	bool		AddData(const int16_T *data, const uint16_T size);
	bool		Close(void);

	bool		IsFileOpen(void);


private:
	bool		WriteWaveHeader(const uint16_T numChannels, const uint32_T samplesPerSecond, const uint32_T bitsPerSample);
	bool		WriteBigEndian(int32_T data, uint32_T numBytes);
	bool		FinalizeAudioData(void);

};


#endif
