#pragma once

#define ADTF_A_UTILS_LEGACY_NAMES

#include <adtf_plugin_sdk.h>
#include <adtf_platform_inc.h>
#include <additional/harddiskstorage_intf.h>
#include <additional/adtf_signal_registry_support.h>
#include <graphics/adtf_graphics.h>

#ifndef INNODRIVE_ZFAS_SWC_BUILD
#pragma warning(disable: 4267)
#include <adtf_devicetb.h>
#pragma warning(default: 4267)
#endif

#include <windows.h>


using namespace adtf;
