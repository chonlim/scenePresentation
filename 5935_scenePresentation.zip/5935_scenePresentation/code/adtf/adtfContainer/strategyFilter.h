#ifndef guard_strategyFilter_h
#define guard_strategyFilter_h

#include "baseFilter.h"
#include "strategy/strategyTask/strategyTask_private.h"


#define ADTF_FILTER_ID_strategyFilter	"IDII.strategyFilter"
#define ADTF_FILTER_NAME_strategyFilter	"IDII strategyFilter"


class strategyFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_strategyFilter, ADTF_FILTER_NAME_strategyFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	pemPlanningHeap_T		heap;
	pemPlanningStack_T		stack;

public:
	strategyFilter_T(const tChar* __info);

	void		OnReceive(void);
	bool		OnInitNormal(void);

private:
	void		RunAlgorithm(void);
};


#endif
