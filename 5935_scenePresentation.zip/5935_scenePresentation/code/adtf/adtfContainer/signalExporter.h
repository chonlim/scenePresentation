#ifndef guard_signalExporter_h
#define guard_signalExporter_h

#include "baseFilter.h"
#include "control/controlTask/controlTask_private.h" /* ohne kein heap*/
//#include "../ibfFile/ibfFile.h"

#define ADTF_FILTER_ID_signalExporterFilter		"IDII.signalExporterFilter"
#define ADTF_FILTER_NAME_signalExporterFilter		"IDII signalExporterFilter"


class signalExporterFilter_T
	: public baseFilter_T//,
	//public cKernelCyclicThread
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_signalExporterFilter, ADTF_FILTER_NAME_signalExporterFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	pemControlHeap_T		heap;
	unsigned long receive_counter;
	unsigned long transmit_counter;

public:
	signalExporterFilter_T(const tChar* __info);
	bool		OnInitNormal(void);
	void		OnShutdownNormal(void);
	bool		InitPort(void);
	tResult		CyclicFunc();
	void		OnReceive(void);	
};


#endif
