#ifndef guard_wassersteinFilter_h
#define guard_wassersteinFilter_h

#include "baseFilter.h"

#include "control/controlTask/controlTask_private.h"	
#include "common/vehicleModel/vehicleModel_private.h" 
#include "common/swcCommunication/swcComm_private.h"	

#include "simulation/wasserstein/wasserstein_private.h"


#define ADTF_FILTER_ID_wassersteinFilter	"IDII.wassersteinFilter"
#define ADTF_FILTER_NAME_wassersteinFilter	"IDII wassersteinFilter"


class wassersteinFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_wassersteinFilter, ADTF_FILTER_NAME_wassersteinFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	wsHeap_T	wsHeap;

	driverPrediction_T driverPrediction_FR;
	vehicleState_T vehicleState_FR;

	enum input { flexray, pem };

	typedef enum PIF_Identifier {
		PIF_Identifier_Init = 0,
		PIF_Identifier_Geschwindigkeit = 1,
		PIF_Identifier_Laengsbeschleunigung = 2,
		PIF_Identifier_Leistung = 3,
		PIF_Identifier_Querbeschleunigung = 4,
		PIF_Identifier_Strassenklasse = 5,
		PIF_Identifier_INVALID = 8
	} PIF_Identifier_T;

	tUInt32					idEML_01;
	tUInt32					idEML_GeschwX;
	tUInt32 				idEML_BeschlX;

	tUInt32					idEML_03;
	tUInt32					idEML_BeschlY;

	tUInt32					idKombi_01;
	tUInt32					idKBI_angez_Geschw;

	tUInt32					idMotor_16;
	tUInt32					idTSK_Steigung_02;

	tUInt32					idPIF_01;
	tUInt32					idPIF_Identifier;
	tUInt32					idPIF_LT_Bin_0;
	tUInt32					idPIF_LT_Bin_1;
	tUInt32					idPIF_LT_Bin_2;
	tUInt32					idPIF_LT_Bin_3;
	tUInt32					idPIF_LT_Bin_4;
	tUInt32					idPIF_LT_Bin_5;
	tUInt32					idPIF_LT_Bin_6;
	tUInt32					idPIF_LT_Bin_7;
	tUInt32					idPIF_LT_Bin_8;
	tUInt32					idPIF_LT_Status;
	tUInt32					idPIF_MT_Bin_0;
	tUInt32					idPIF_MT_Bin_1;
	tUInt32					idPIF_MT_Bin_2;
	tUInt32					idPIF_MT_Bin_3;
	tUInt32					idPIF_MT_Bin_4;
	tUInt32					idPIF_MT_Bin_5;
	tUInt32					idPIF_MT_Bin_6;
	tUInt32					idPIF_MT_Bin_7;
	tUInt32					idPIF_MT_Bin_8;
	tUInt32					idPIF_MT_Status;
	tUInt32					idPIF_ST_Bin_0;
	tUInt32					idPIF_ST_Bin_1;
	tUInt32					idPIF_ST_Bin_2;
	tUInt32					idPIF_ST_Bin_3;
	tUInt32					idPIF_ST_Bin_4;
	tUInt32					idPIF_ST_Bin_5;
	tUInt32					idPIF_ST_Bin_6;
	tUInt32					idPIF_ST_Bin_7;
	tUInt32					idPIF_ST_Bin_8;
	tUInt32					idPIF_ST_Status;
	tUInt32					idPIF_Toggle;

	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;

	cKernelEvent			 flagged;
	bool_T					 shutdown;

public:
	wassersteinFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);

	void		OnShutdownNormal(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);

private:
	void		RunAlgorithm(input input);
	bool		demuxPIF(void);
};

#endif
