#ifndef guard_canCoderFilter_h
#define guard_canCoderFilter_h

#include "baseFilter.h"


#define ADTF_FILTER_ID_canCoderFilter		"IDII.canCoderFilter"
#define ADTF_FILTER_NAME_canCoderFilter		"IDII canCoderFilter"


class canCoderFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_canCoderFilter, ADTF_FILTER_NAME_canCoderFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

	bool		isRunning;

public:
	canCoderFilter_T(const tChar* __info);

	void		OnPropertyChange(const char_T *name);
	void		OnReceive(void);

	bool		OnInitNormal(void);
	void		OnShutdownNormal(void);


private:
	void		RunAlgorithm(void);
};


#endif
