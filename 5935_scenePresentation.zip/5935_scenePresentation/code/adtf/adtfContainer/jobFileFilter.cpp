#include "stdafx.h"
#include "jobFileFilter.h"

#include "Algorithmus/common/swcCommunication/swcComm_adtfTools.h"

extern "C" LPSTR __declspec(dllimport) __stdcall PathFindFileNameA(LPCSTR pszPath);
extern "C" LPWSTR __declspec(dllimport) __stdcall PathFindFileNameW(LPCWSTR pszPath);
#ifdef UNICODE
#define PathFindFileName  PathFindFileNameW
#else
#define PathFindFileName  PathFindFileNameA
#endif // !UNICODE

#pragma comment(lib, "shlwapi.lib")

#undef		GetObject

#pragma warning(disable : 4355)


jobFileFilter_T::jobFileFilter_T(const tChar* __info)
  : baseFilter_T(__info),
	velocityRing(100000, 1.0f),
	constraintRing(25000),
	statusRing(5000)
{
	this->AddInputPin("flexray",				MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);

	this->AddInputPin("pemControl",				pemControl_header());
	this->AddInputPin("pemPlanning",			pemPlanning_header());

	//this->AddInputPin("measurementTrigger",		"uint16",				sizeof(uint16_T));
	//this->AddInputPin("curveCategory",			"int8",					sizeof(int8_T));

	this->SetPropertyStr("jobFile",		"$CFGDIR$\\..\\..\\..\\measurements\\$USERNAME$_$DATE$_$TIME$\\jobFile.jobfile");
	this->SetPropertyBool("jobFile" NSSUBPROP_FILENAME, tTrue);

	this->inputPin_flexray			= this->GetInputPin("flexray");
	this->inputPin_pemControl		= this->GetInputPin("pemControl");
	this->inputPin_pemPlanning		= this->GetInputPin("pemPlanning");
}


bool	jobFileFilter_T::OnGraphReady(void)
{
	if(this->inputPin_flexray->IsConnected()) {
		cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
		if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
			LOG_ERROR("No FlexRay support service available");
			return false;
		}

		cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
		if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
			LOG_ERROR("Failed to get FIBEX database");
			return false;
		}


		/* Abfragen der IDs f�r die PDUs, die uns interessieren.
			Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
		tUInt32 count;
		fibexDB->GetPDUCount(&count);

		for(tUInt32 i = 0; i < count; i++) {
			const tChar *name;
			fibexDB->GetPDUName(i, &name);

			if(!strcmp(name, "NavPos_01"))		{ this->id.NavPos_01.pdu = i; }
		}


		/* Abfragen der Signal-IDs, f�r die wir uns interessieren. */
		if(IS_FAILED(fibexDB->GetSignalID("NP_LatDegree",						&this->id.NavPos_01.NP_LatDegree)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("NP_LatDirection",					&this->id.NavPos_01.NP_LatDirection)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("NP_LongDegree",						&this->id.NavPos_01.NP_LongDegree)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("NP_LongDirection",					&this->id.NavPos_01.NP_LongDirection)))				{ return false; }


		/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
		cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
		if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
			LOG_ERROR("Failed to create FlexRay coder");
			return false;
		}

		this->flexrayCoder = coder;
		this->flexrayCoder->ResetData();
		this->flexrayCoder->SetListener((groundFilter_T*)this);
		this->flexrayCoder->ActivePDUEvents(this->id.NavPos_01.pdu);
	}
	else {
		this->flexrayCoder							= nullptr;
		this->id.NavPos_01.pdu					= 0;
		this->id.NavPos_01.NP_LatDegree			= 0;
		this->id.NavPos_01.NP_LatDirection		= 0;
		this->id.NavPos_01.NP_LongDegree		= 0;
		this->id.NavPos_01.NP_LongDirection		= 0;
	}

	return true;
}


bool	jobFileFilter_T::OnStart(void)
{
	tchar_T		 fileName[1024];
	tchar_T		 folderName[1024];

	swprintf_s(fileName, L"%S", this->GetPropertyStr("jobFile"));
	swprintf_s(folderName, L"%S", this->GetPropertyStr("jobFile"));

	*PathFindFileName(folderName) = L'\0';
	if(wcslen(folderName) > 0) {
		CreateDirectory(folderName, NULL);
	}

	if(!this->jobFile.OpenWrite(fileName)) {
		LOG_ERROR("Failed to open jobFile for writing.");

		return false;
	}

	this->firstPosition		= INVALID_VALUE;
	this->firstTickCount	= 0xFFFFFFFF;

	this->latitude			= INVALID_VALUE;
	this->longitude			= INVALID_VALUE;

	return true;
}


bool	jobFileFilter_T::OnStop(void)
{
	if(this->velocityRing.GetCount() > 0)		{ jobFile.AppendDataRing(L"velocity",		&this->velocityRing); }
	if(this->constraintRing.GetCount() > 0)		{ jobFile.AppendDataRing(L"constraint",		&this->constraintRing); }
	if(this->statusRing.GetCount() > 0)			{ jobFile.AppendDataRing(L"status",			&this->statusRing); }

	this->EnterMutex();
	pemControl_T		pemControl			= *(pemControl_T*)this->inputPin_pemControl->GetDataPtr();
	this->LeaveMutex();

	if(pemControl.vehicleState.tickCount > 0) {
		real32_T	distance = pemControl.vehicleState.velocity.position - this->firstPosition;
		real32_T	duration = (controlCYCLETIME) * (pemControl.vehicleState.tickCount - this->firstTickCount);

		if(!jobFile.AppendDistance(distance))	{ return false; }
		if(!jobFile.AppendTime(duration))		{ return false; }

		if(!jobFile.AppendResult(TEXT("avgVelocity"),			distance / duration))	{ return false; }
	}

	this->jobFile.CloseWrite();

	return true;
}


void	jobFileFilter_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}


void	jobFileFilter_T::OnReceive(void)
{
	if(this->inputPin_flexray->Unflag()) {
		if(this->flexrayCoder) {
			this->EnterMutex();

			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->inputPin_flexray->GetDataPtr(),
									  (tInt)this->inputPin_flexray->GetDataSize(),
											this->inputPin_flexray->GetTimeStamp());

			this->LeaveMutex();
		}
	}


	if(this->inputPin_pemControl->Unflag()) {
		this->EnterMutex();
		this->controlBuffer.Process((pemControl_T*)this->inputPin_pemControl->GetDataPtr());

		const controlDebugData_T  *controlData	= this->controlBuffer.GetData();
		const strategyDebugData_T *strategyData	= this->strategyBuffer.GetData();

		pemControl_T		pemControl			= *(pemControl_T*)this->inputPin_pemControl->GetDataPtr();
		pemPlanning_T		pemPlanning			= *(pemPlanning_T*)this->GetInputPin("pemPlanning")->GetDataPtr();

		this->velocityRing.Process(&controlData->vehicleInput,
								   &pemControl.vehicleState,
								   &pemControl.systemControl,
								   &pemControl.mapPath,
								   &pemPlanning.longTorque);

		this->velocityRing.Process(&pemControl.vehicleState,
								    this->latitude,
								    this->longitude);

		this->statusRing.Process(&pemControl.vehicleState,
								 &pemControl.systemControl);

		if(pemControl.vehicleState.tickCount > 0) {
			this->firstPosition		= min(this->firstPosition,	pemControl.vehicleState.velocity.position);
			this->firstTickCount	= min(this->firstTickCount,	pemControl.vehicleState.tickCount);
		}

		this->LeaveMutex();
	}


	if(this->inputPin_pemPlanning->Unflag()) {
		this->EnterMutex();
		this->strategyBuffer.Process((pemPlanning_T*)this->inputPin_pemPlanning->GetDataPtr());

		if(this->strategyBuffer.Unflag()) {
			const strategyDebugData_T *strategyData	= this->strategyBuffer.GetData();

			this->constraintRing.Process(&(velocityConstraints_T)strategyData->velocityConstraints);
		}

		this->LeaveMutex();
	}
}


void	jobFileFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }

		if(coderEvent->nPDUID == this->id.NavPos_01.pdu) {
			adtf_devicetb::tSignalValue		NP_LatDegree;
			adtf_devicetb::tSignalValue		NP_LatDirection;
			adtf_devicetb::tSignalValue		NP_LongDegree;
			adtf_devicetb::tSignalValue		NP_LongDirection;

			this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LatDegree,				&NP_LatDegree);
			this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LatDirection,			&NP_LatDirection);
			this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LongDegree,			&NP_LongDegree);
			this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LongDirection,			&NP_LongDirection);

			this->latitude	= NP_LatDegree.nf64Value  * (NP_LatDirection.nRawValue  ? -1.0 : 1.0);
			this->longitude	= NP_LongDegree.nf64Value * (NP_LongDirection.nRawValue ? -1.0 : 1.0);

			if(NP_LatDegree.nf64Value > 1000.0 || NP_LongDegree.nf64Value > 1000.0) {
				this->latitude	= INVALID_VALUE;
				this->longitude	= INVALID_VALUE;
			}
		}
	}
}
