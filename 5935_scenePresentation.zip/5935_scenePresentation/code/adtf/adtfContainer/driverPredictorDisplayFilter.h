#ifndef guard_driverPredictorDisplayFilter_h
#define guard_driverPredictorDisplayFilter_h

#include "displayFilter.h"

#define ADTF_FILTER_ID_driverPredictorDisplayFilter		"IDII.driverPredictorDisplayFilter"
#define ADTF_FILTER_NAME_driverPredictorDisplayFilter	"IDII driverPredictorDisplayFilter"

#include "Algorithmus/control/controlTask/controlTask_adtfTools.h"
#include "Algorithmus/common/vehicleObserverCommon/vehicleObserver_adtfTools.h"
#include "Algorithmus/common/swcCommunication/swcComm_adtfTools.h"
#include "Algorithmus/common/vehicleModel/vehicleModel_adtfTools.h"
#include "Algorithmus/strategy/strategyTask/strategyTask_adtfTools.h"
#include "Algorithmus/control/outputCodec/outputCodec_adtfTools.h"
#include "Algorithmus/simulation/wasserstein/wasserstein_adtfTools.h"


#include "tools/hpDisplayBlocks/binHorizonPainter.h"
#include "tools/hpDisplayBlocks/dynamicHistoryPainter.h"
#include "tools/hpDisplayBlocks/binHistoryPainter.h"
#include "tools/hpDisplayBlocks/driverPredictorDisplayPainter.h"
#include "tools/hpDisplayBlocks/trajectoryPainter.h"
#include "tools/hpDisplayBlocks/wassersteinPainter.h"
#include "Algorithmus\common\vehicleModel\vehicleModel.h"
#include "Algorithmus\control\pathRouter\prtTools.h"

#include "Rte_Type.h"

#include "../testVector/testVector.h"


class driverPredictorDisplayFilter_T
  : public displayFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_driverPredictorDisplayFilter, ADTF_FILTER_NAME_driverPredictorDisplayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	bool							positionTracking;

	binHorizonPainter_T				binHorizonPainter;
	binHistoryPainter_T				binHistoryPainter;
	dynamicHistoryPainter_T			dynamicHistoryPainter;
	driverPredictorDisplayPainter_T	driverPredictorDisplayPainter;
	trajectoryPainter_T				trajectoryPainter;
	wassersteinPainter_T			wassersteinPainter;
	
	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;

	driverPrediction_T				driverPredictionTmp;
	pemControlHeap_T				controlHeapTmp;
	vehicleState_T					vehicleStateTmp;
	flexrayOutput_T					flexrayOutputTmp;
	real32_T						trajectoryVelocityOut[dprdTHINNEDTRAJECTORY_COUNT];

	tUInt32		idPIF_01;
	tUInt32		idEML_01;
	tUInt32		idEML_03;
	tUInt32		idMotor_16;
	tUInt32		idKombi_01;


	tUInt32					idEML_GeschwX;
	tUInt32 				idEML_BeschlX;
	tUInt32					idEML_BeschlY;

	tUInt32					idKBI_angez_Geschw;

	tUInt32					idTSK_Steigung_02;
	
	tUInt32					idPIF_Identifier;
	tUInt32					idPIF_LT_Bin_0;
	tUInt32					idPIF_LT_Bin_1;
	tUInt32					idPIF_LT_Bin_2;
	tUInt32					idPIF_LT_Bin_3;
	tUInt32					idPIF_LT_Bin_4;
	tUInt32					idPIF_LT_Bin_5;
	tUInt32					idPIF_LT_Bin_6;
	tUInt32					idPIF_LT_Bin_7;
	tUInt32					idPIF_LT_Bin_8;
	tUInt32					idPIF_LT_Status;
	tUInt32					idPIF_MT_Bin_0;
	tUInt32					idPIF_MT_Bin_1;
	tUInt32					idPIF_MT_Bin_2;
	tUInt32					idPIF_MT_Bin_3;
	tUInt32					idPIF_MT_Bin_4;
	tUInt32					idPIF_MT_Bin_5;
	tUInt32					idPIF_MT_Bin_6;
	tUInt32					idPIF_MT_Bin_7;
	tUInt32					idPIF_MT_Bin_8;
	tUInt32					idPIF_MT_Status;
	tUInt32					idPIF_ST_Bin_0;
	tUInt32					idPIF_ST_Bin_1;
	tUInt32					idPIF_ST_Bin_2;
	tUInt32					idPIF_ST_Bin_3;
	tUInt32					idPIF_ST_Bin_4;
	tUInt32					idPIF_ST_Bin_5;
	tUInt32					idPIF_ST_Bin_6;
	tUInt32					idPIF_ST_Bin_7;
	tUInt32					idPIF_ST_Bin_8;
	tUInt32					idPIF_ST_Status;
	tUInt32					idPIF_Toggle;

	bool_T		flexrayFlag;
	bool_T		heapFlag;
	bool_T		frOutputFlag;

public:
	driverPredictorDisplayFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);
	void		OnRun(int32_T type, const void *data, size_t size);

	void		OnReceive(void);

	void		PrePaint(void);

	void		demuxPIFSignal(void);
	void		runAlgorithm(void);



private:


};

#endif
