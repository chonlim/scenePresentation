#ifndef	guard_vehicleDisplayFilter_h
#define	guard_vehicleDisplayFilter_h

#include "displayFilter.h"

#define ADTF_FILTER_ID_vehicleDisplayFilter		"IDII.vehicleDisplayFilter"
#define ADTF_FILTER_NAME_vehicleDisplayFilter	"IDII vehicleDisplayFilter"

#include "tools/klbDisplayBlocks/overviewProcessor.h"
#include "tools/klbDisplayBlocks/statusProcessor.h"
#include "tools/klbDisplayBlocks/modelContainer.h"
#include "tools/klbDisplayBlocks/sceneContainer.h"

#include "tools/klbDisplayBlocks/containerCallback.h"

#include "tools/displayWindow/sceneEvalDlg.h"
#include "tools/replayTools/sceneCollector.h"


class vehicleDisplayFilter_T
  : public displayFilter_T,
	public containerCallback_T,
	public cKernelCyclicThread
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_vehicleDisplayFilter, ADTF_FILTER_NAME_vehicleDisplayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	overviewProcessor_T		 overviewProcessor;
	statusProcessor_T		 statusProcessor;
	modelContainer_T		 modelContainer;
	sceneContainer_T		 sceneContainer;

	sceneCollector_T		 sceneCollector;
	sceneEvalDlg_T			 sceneEvalDlg;

	tUInt32					 idPSD04;
	tUInt32					 idPSD05;
	tUInt32					 idPSD06;

	tUInt32					 idPACC02_02;
	tUInt32					 idPACC02_Durchschnittsgeschw;

	tUInt32					 idMotor_11;
	tUInt32					 idMO_Mom_Schub;

	tUInt32					 idMotor_12;
	tUInt32					 idMO_Mom_Begr_stat;
	tUInt32					 idMO_Mom_Begr_dyn;
	tUInt32					 idMO_Drehzahl_01;

	tUInt32					 idMotor_20;
	tUInt32					 idTSK_a_Soll_gradientenbegrenzt;

	tUInt32					 idMotor_Code;
	tUInt32					 idMO_Faktor_Momente_02;

	tUInt32					 idACC_06;
	tUInt32					 idACC_Sollbeschleunigung_02;

	bool_T					 controlFlag;
	pemControl_T			 pemControl;
	pemControlStack_T		 controlStack;
	pemControlHeap_T		 controlHeap;

	bool_T					 strategyFlag;
	pemPlanning_T			 pemPlanning;
	pemPlanningStack_T		 strategyStack;
	pemPlanningHeap_T		 strategyHeap;

	psdInput_T				 psdBuffer[64];
	uint16_T				 psdOffset;
	uint16_T				 psdCount;

	cKernelEvent			 flagged;
	bool_T					 shutdown;

	bool_T					 lastToggle;

	inputPin_T				*inputPin_pemControl;
	inputPin_T				*inputPin_controlStack;
	inputPin_T				*inputPin_controlHeap;

	inputPin_T				*inputPin_pemPlanning;
	inputPin_T				*inputPin_planningHeap;
	inputPin_T				*inputPin_planningStack;

	inputPin_T				*inputPin_vehicleModel;

	inputPin_T				*inputPin_canPSD;
	inputPin_T				*inputPin_flexrayPSD;
	inputPin_T				*inputPin_nmea;
	inputPin_T				*inputPin_psdInput;

	inputPin_T				*inputPin_measurementTrigger;
	inputPin_T				*inputPin_curveCategory;

	enum plotPage_T {
		pageOverview,
		pageStatus,
		pageModel,
		pageScenes
	} selectedPage;

	bool_T					 pageValid;

	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;

	testVector_T<psdRaw_T>	psdTraceFile;


public:
	vehicleDisplayFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);

	void		OnShutdownNormal(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);

	tResult		OnSize(tHandle hCanvas, tInt nLeft, tInt nTop, tInt nRight, tInt nBottom);
	tResult		OnTimer(tHandle hCanvas);
	tResult		OnControlEvent(tControlEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags,  tVoid* pEventData);

	void		ProcessControl(void);
	void		ProcessStrategy(void);
	void		ProcessPSD(void);

	void		SendScenes(void);

	void		SelectPage(plotPage_T page);
	void		SelectNextPage(void);

	void		DecodeControlCode(real32_T DePACC02_Durchschnittsgeschw);

	void		ForceUpdate(void);
	void		PushControl(graphControl_T *control);


private:
	/** \brief	Callback f�r das Weiterleiten von EHR-Events an die Konsole */
	static void		  EventCallback(IN	const	psdEventType_T		 type,
									IN	const	char_T				*message,
									IN	const	void				*data);

	tResult		CyclicFunc();
};




#endif
