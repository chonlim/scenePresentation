#include "stdafx.h"
#include "replayFilter.h"

#include "base.h"

#include "simulation/vehicleSimulation/vehicleSimulation_adtfTools.h"


replayFilter_T::replayFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("vehicleSimulation",		vehicleSimulation_header());

	this->AddOutputPin("positionRecord",		MEDIA_TYPE_STRUCTURED_DATA,		0);
	this->AddOutputPin("psdInput",				MEDIA_TYPE_STRUCTURED_DATA,		0);

	this->SetPropertyStr("replayFile", "$(WORK_PATH)\\replay\\B10 Runde.replay");
	this->SetPropertyBool("replayFile" NSSUBPROP_FILENAME, tTrue);

	this->SetPropertyFloat("initTime", 0.0);
}


void	replayFilter_T::OnReceive(void)
{
	if(this->GetInputPin("vehicleSimulation")->Unflag()) {
		this->RunAlgorithm();
	}
}


bool	replayFilter_T::OnInitNormal(void)
{
	wchar_t replayFile[1024];
	swprintf_s(replayFile, L"%S", this->GetPropertyStr("replayFile"));

	if(!this->replay.LoadFile(replayFile)) {
		char message[1024];

		sprintf_s(message, "Failed to load replay file  \"%S\".", replayFile);

		this->ShowErrorBox(message, "replayFilter");
		LOG_ERROR(message);

		return false;
	}

	this->replay.Seek(this->GetPropertyFloat("initTime"));

	return true;
}


void	replayFilter_T::RunAlgorithm(void)
{
	this->EnterMutex();

	vehicleSimulation_T	vehicleSimulation	= *(vehicleSimulation_T*)this->GetInputPin("vehicleSimulation")->GetDataPtr();

	this->LeaveMutex();

	positionRecord_T	positionRecord = {0};

	this->replay.TimeStep(simulationCYCLETIME, vehicleSimulation.longModel.state.velocity);

	/* Verarbeiten aller angefallenen PSD Frames */
	psdInput_T psdInput;
	while (this->replay.PopPSD(&psdInput)) {
		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}

	this->replay.GetPositionRecord(&positionRecord);

	this->Submit("positionRecord", &positionRecord, sizeof(positionRecord_T));
}
