#include "stdafx.h"
#include "driverObserverDisplayFilter.h"


#undef		GetObject

#include "Algorithmus/common/vehicleObserverCommon/vehicleObserver_adtfTools.h"
#include "Algorithmus/common/swcCommunication/swcComm_adtfTools.h"
#include "Algorithmus/control/controlTask/controlTask_adtfTools.h"
#include "Algorithmus/strategy/strategyTask/strategyTask_adtfTools.h"
#include "Algorithmus/control/outputCodec/outputCodec_adtfTools.h"

#include "tools/rpl2Tools/psdProcessor/pprWGS84.h"

extern "C" {
#include "Algorithmus/control/rteInterface/rteTraceDataOut.h"
}


#define		def_minPosition		-100.0f
#define		def_maxPosition		 400.0f
#define		def_minVelocity		   0.0f
#define		def_maxVelocity		  50.0f
#define		def_minAcceleration	  -4.0f
#define		def_maxAcceleration	   4.0f


#pragma warning(disable : 4355)


driverObserverDisplayFilter_T::driverObserverDisplayFilter_T(const tChar* __info)
  : displayFilter_T(__info, def_minPosition, def_maxPosition, def_minVelocity, def_maxVelocity, def_minAcceleration, def_maxAcceleration),
  dynamicLevelPainter(&this->control->graph)
{
	this->AddInputPin("InnoDriveOut_DeTraceData", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
}


bool	driverObserverDisplayFilter_T::OnInitNormal(void)
{	
	/* Initialisieren der Painter */
	this->dynamicLevelPainter.Init();
		
	return true;
}


bool	driverObserverDisplayFilter_T::OnGraphReady(void)
{
	return true;

}


void	driverObserverDisplayFilter_T::OnShutdownNormal(void)
{
	
}

void	driverObserverDisplayFilter_T::OnReceive(void)
{
	
	if (this->GetInputPin("InnoDriveOut_DeTraceData")->Unflag()) {
		Dt_RECORD_TraceData *traceData;
		driverPredictorDebugBuffer_T dprdDebugBuffer;
		traceData = (Dt_RECORD_TraceData *)this->GetInputPin("InnoDriveOut_DeTraceData")->GetDataPtr();

		rteInConvert_traceData(traceData, &this->driverStateTmp, &dprdDebugBuffer);


		this->control->graph.MutexEnter();
		/*Fahrdynamiklevel plotten */
		this->dynamicLevelPainter.Process_dynamicSet(&this->driverStateTmp);
		this->control->graph.MutexLeave();
	}
}

void	driverObserverDisplayFilter_T::PrePaint(void)
{

}
