#ifndef	guard_planningDisplayFilter_h
#define	guard_planningDisplayFilter_h

#include "displayFilter.h"

#define ADTF_FILTER_ID_planningDisplayFilter	"IDII.planningDisplayFilter"
#define ADTF_FILTER_NAME_planningDisplayFilter	"IDII planningDisplayFilter"

#include "tools/klbDisplayBlocks/ctmHorizonPainter.h"
#include "tools/klbDisplayBlocks/longHorizonPainter.h"
#include "tools/klbDisplayBlocks/lnptHorizonPainter.h"
#include "tools/klbDisplayBlocks/lnstHorizonPainter.h"
#include "tools/klbDisplayBlocks/lntqHorizonPainter.h"


class planningDisplayFilter_T
  : public displayFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_planningDisplayFilter, ADTF_FILTER_NAME_planningDisplayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	bool	 positionTracking;
	bool	 velocityTracking;
	bool	 accelerationTracking;
	bool	 showBlueBand;


	ctmHorizonPainter_T		 ctmHorizonPainter;
	longHorizonPainter_T	 longHorizonPainter;
	lnptHorizonPainter_T	 lnptHorizonPainter;
	lnstHorizonPainter_T	 lnstHorizonPainter;
	lntqHorizonPainter_T	 lntqHorizonPainter;


public:
	planningDisplayFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	void		OnReceive(void);

};




#endif
