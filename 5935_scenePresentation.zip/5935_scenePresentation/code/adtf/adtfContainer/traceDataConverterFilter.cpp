#include "stdafx.h"
#include "traceDataConverterFilter.h"

#include "common/swcCommunication/PpPemControl.h"

extern "C" {
#include "control/rteInterface/rteTraceDataOut.h"
}


traceDataConverterFilter_T::traceDataConverterFilter_T(const tChar* __info)
	: baseFilter_T(__info)
{
	this->AddInputPin("controlHeap", pemControlHeap_header());

	this->AddOutputPin("DeTraceData", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
}


bool	traceDataConverterFilter_T::OnInitNormal(void)
{
	return true;
}


void	traceDataConverterFilter_T::OnReceive(void)
{
	if (this->GetInputPin("controlHeap")->Unflag() && this->GetInputPin("controlHeap")->GetDataSize() == sizeof(pemControlHeap_T)){
		this->EnterMutex();
		pemControlHeap_T	*controlHeap = (pemControlHeap_T*)this->GetInputPin("controlHeap")->GetDataPtr();
		this->LeaveMutex();

		Dt_RECORD_TraceData		recTraceData;

		rteOutConvert_traceData(controlHeap, &recTraceData);

		this->Submit("DeTraceData", &recTraceData, sizeof(recTraceData));
	}

}