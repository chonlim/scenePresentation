#include "stdafx.h"
#include "rglInputFilter.h"
#include "rglConverterTypes.h"

#undef		GetObject
#pragma warning(disable : 4355)

#include <control/psdWrapper/eifTypes.h>


rglInputFilter_T::rglInputFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("PpPSD15__DePSD04",   MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("PpPSD15__DePSD05",   MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("PpPSD15__DePSD06m0", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("PpPSD15__DePSD06m1", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("PpPSD15__DePSD06m2", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("PpPSD15__DePSD06m3", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddInputPin("PpPSD15__DePSD06m4", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);

	this->AddOutputPin("psdInput",			MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
}


void	rglInputFilter_T::OnReceive(void)
{
	if(this->GetInputPin("PpPSD15__DePSD04")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd4Message psdMsg04 = *(Dt_RECORD_PsdEhr_Psd4Message*)this->GetInputPin("PpPSD15__DePSD04")->GetDataPtr();
		psdInput_T psdInput;
	
		psdInput.type = psdMessage4;
		psdInput.data.psd4.id					= psdMsg04.PSD_Segment_ID;
		psdInput.data.psd4.parentId				= psdMsg04.PSD_Vorgaenger_Segment_ID;
		psdInput.data.psd4.length				= psdMsg04.PSD_Segmentlaenge;
		psdInput.data.psd4.streetClass			= psdMsg04.PSD_Strassenkategorie;
		psdInput.data.psd4.curvatureEnd			= psdMsg04.PSD_Endkruemmung;
		psdInput.data.psd4.curvatureEndSign		= psdMsg04.PSD_Endkruemmung_Vorz;
		psdInput.data.psd4.identity				= psdMsg04.PSD_Idenditaets_ID;
		psdInput.data.psd4.isADASQuality		= psdMsg04.PSD_ADAS_Qualitaet;
		psdInput.data.psd4.isMostProbablePath	= psdMsg04.PSD_wahrscheinlichster_Pfad;
		psdInput.data.psd4.isStraightestPath	= psdMsg04.PSD_Geradester_Pfad;
		psdInput.data.psd4.lanes				= psdMsg04.PSD_Fahrspuren_Anzahl;
		psdInput.data.psd4.isBuiltUpArea		= psdMsg04.PSD_Bebauung;
		psdInput.data.psd4.completeFlag			= psdMsg04.PSD_Segment_Komplett;
		psdInput.data.psd4.ramp					= psdMsg04.PSD_Rampe;
		psdInput.data.psd4.curvatureStart		= psdMsg04.PSD_Anfangskruemmung;
		psdInput.data.psd4.curvatureStartSign	= psdMsg04.PSD_Anfangskruemmung_Vorz;
		psdInput.data.psd4.branchDirection		= psdMsg04.PSD_Abzweigerichtung;
		psdInput.data.psd4.branchAngle			= psdMsg04.PSD_Abzweigewinkel;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}


	if(this->GetInputPin("PpPSD15__DePSD05")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd5Message psdMsg05 = *(Dt_RECORD_PsdEhr_Psd5Message*)this->GetInputPin("PpPSD15__DePSD05")->GetDataPtr();
		psdInput_T psdInput;
	
		psdInput.type = psdMessage5;
		psdInput.data.psd5.positionId						= psdMsg05.PSD_Pos_Segment_ID;
		psdInput.data.psd5.positionLength					= psdMsg05.PSD_Pos_Segmentlaenge;
		psdInput.data.psd5.positionInhibitTime				= psdMsg05.PSD_Pos_Inhibitzeit;
		psdInput.data.psd5.positionIsLocationUnique			= psdMsg05.PSD_Pos_Standort_Eindeutig;
		psdInput.data.psd5.positionLongitudinalError		= psdMsg05.PSD_Pos_Fehler_Laengsrichtung;
		psdInput.data.psd5.positionLane						= psdMsg05.PSD_Pos_Fahrspur;
		psdInput.data.psd5.attributesSegmentId				= psdMsg05.PSD_Attribut_Segment_ID_05;
		psdInput.data.psd5.attribute1Type					= psdMsg05.PSD_Attribut_1_ID;
		psdInput.data.psd5.attribute1Value					= psdMsg05.PSD_Attribut_1_Wert;
		psdInput.data.psd5.attribute1Offset					= psdMsg05.PSD_Attribut_1_Offset;
		psdInput.data.psd5.attribute2Type					= psdMsg05.PSD_Attribut_2_ID;
		psdInput.data.psd5.attribute2Value					= psdMsg05.PSD_Attribut_2_Wert;
		psdInput.data.psd5.attribute2Offset					= psdMsg05.PSD_Attribut_2_Offset;
		psdInput.data.psd5.completeFlag						= psdMsg05.PSD_Attribute_Komplett_05;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}


	if(this->GetInputPin("PpPSD15__DePSD06m0")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd60Message psdMsg60 = *(Dt_RECORD_PsdEhr_Psd60Message*)this->GetInputPin("PpPSD15__DePSD06m0")->GetDataPtr();
		psdInput_T psdInput;
	

		psdInput.type = psdMessage6;
		psdInput.data.psd6.multiplex = 0;

		psdInput.data.psd6.message.m0.id							= psdMsg60.PSD_Sys_Segment_ID;
		psdInput.data.psd6.message.m0.countryCode					= psdMsg60.PSD_Sys_Laendercode;
		psdInput.data.psd6.message.m0.unitSpeed						= psdMsg60.PSD_Sys_Geschwindigkeit_Einheit;
		psdInput.data.psd6.message.m0.trafficDirection				= psdMsg60.PSD_Sys_Verkehrsrichtung;
		psdInput.data.psd6.message.m0.qualityGeometry				= psdMsg60.PSD_Sys_Quali_Geometrien;
		psdInput.data.psd6.message.m0.qualityMapMatching			= psdMsg60.PSD_Sys_Mapmatchingguete;
		psdInput.data.psd6.message.m0.ageMapData					= psdMsg60.PSD_Sys_Alter_Karte;
		psdInput.data.psd6.message.m0.isRoutingActive				= psdMsg60.PSD_Sys_Zielfuehrung;
		psdInput.data.psd6.message.m0.usStateCode					= psdMsg60.PSD_Sys_US_State;
		psdInput.data.psd6.message.m0.isRoutingChanged				= psdMsg60.PSD_Sys_Zielfuehrung_geaendert;
		psdInput.data.psd6.message.m0.qualityGeometryExt			= psdMsg60.PSD_Sys_Geometrieguete_erweitert;
		psdInput.data.psd6.message.m0.regionQualiGeometry			= psdMsg60.PSD_Sys_Geometrieguete;
		psdInput.data.psd6.message.m0.regionQualiPlaceInfo			= psdMsg60.PSD_Sys_Quali_Ortsinfo;
		psdInput.data.psd6.message.m0.regionQualiAvailable			= psdMsg60.PSD_Sys_Quali_verfuegbar;
		psdInput.data.psd6.message.m0.regionQualiSpecialInfo		= psdMsg60.PSD_Sys_Quali_sonstige_Attribute;
		psdInput.data.psd6.message.m0.regionQualiSlope				= psdMsg60.PSD_Sys_Quali_Steigungen;
		psdInput.data.psd6.message.m0.regionQualiStreetLabel		= psdMsg60.PSD_Sys_Quali_Strassenkennz;
		psdInput.data.psd6.message.m0.regionQualiSpeedLimit			= psdMsg60.PSD_Sys_Quali_Tempolimits;
		psdInput.data.psd6.message.m0.regionQualiRightOfWayRules	= psdMsg60.PSD_Sys_Quali_Vorfahrtsregelung;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}


	if(this->GetInputPin("PpPSD15__DePSD06m1")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd61Message psdMsg61 = *(Dt_RECORD_PsdEhr_Psd61Message*)this->GetInputPin("PpPSD15__DePSD06m1")->GetDataPtr();
		psdInput_T psdInput;

		psdInput.type = psdMessage6;
		psdInput.data.psd6.multiplex = 1;
		
		psdInput.data.psd6.message.m1.attributesSegmentId			= psdMsg61.PSD_Attribut_Segment_ID;
		psdInput.data.psd6.message.m1.attribute1Type				= psdMsg61.PSD_Attribut_3_ID;
		psdInput.data.psd6.message.m1.attribute1Value				= psdMsg61.PSD_Attribut_3_Wert;
		psdInput.data.psd6.message.m1.attribute1Offset				= psdMsg61.PSD_Attribut_3_Offset;
		psdInput.data.psd6.message.m1.attribute2Type				= psdMsg61.PSD_Attribut_4_ID;
		psdInput.data.psd6.message.m1.attribute2Value				= psdMsg61.PSD_Attribut_4_Wert;
		psdInput.data.psd6.message.m1.attribute2Offset				= psdMsg61.PSD_Attribut_4_Offset;
		psdInput.data.psd6.message.m1.attribute3Type				= psdMsg61.PSD_Attribut_5_ID;
		psdInput.data.psd6.message.m1.attribute3Value				= psdMsg61.PSD_Attribut_5_Wert;
		psdInput.data.psd6.message.m1.attribute3Offset				= psdMsg61.PSD_Attribut_5_Offset;
		psdInput.data.psd6.message.m1.completeFlag					= psdMsg61.PSD_Attribute_Komplett_06;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}


	if(this->GetInputPin("PpPSD15__DePSD06m2")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd62Message psdMsg62 = *(Dt_RECORD_PsdEhr_Psd62Message*)this->GetInputPin("PpPSD15__DePSD06m2")->GetDataPtr();
		psdInput_T psdInput;

		psdInput.type = psdMessage6;
		psdInput.data.psd6.multiplex = 2;

		psdInput.data.psd6.message.m2.id							= psdMsg62.PSD_Ges_Segment_ID;
		psdInput.data.psd6.message.m2.offset						= psdMsg62.PSD_Ges_Offset;
		psdInput.data.psd6.message.m2.speedLimit					= psdMsg62.PSD_Ges_Geschwindigkeit;
		psdInput.data.psd6.message.m2.type							= psdMsg62.PSD_Ges_Typ;
		psdInput.data.psd6.message.m2.constraintLane				= psdMsg62.PSD_Ges_Spur_Geschw_Begrenzung;
		psdInput.data.psd6.message.m2.constraintTrailer				= psdMsg62.PSD_Ges_Geschwindigkeit_Gespann;
		psdInput.data.psd6.message.m2.constraintWeather				= psdMsg62.PSD_Ges_Geschwindigkeit_Witter;
		psdInput.data.psd6.message.m2.constraintWeekDayStart		= psdMsg62.PSD_Ges_Geschwindigkeit_Tag_Anf;
		psdInput.data.psd6.message.m2.constraintWeekDayEnd			= psdMsg62.PSD_Ges_Geschwindigkeit_Tag_Ende;
		psdInput.data.psd6.message.m2.constraintHourStart			= psdMsg62.PSD_Ges_Geschwindigkeit_Std_Anf;
		psdInput.data.psd6.message.m2.constraintHourEnd				= psdMsg62.PSD_Ges_Geschwindigkeit_Std_Ende;
		psdInput.data.psd6.message.m2.noPassingSign					= psdMsg62.PSD_Ges_Ueberholverbot;
		psdInput.data.psd6.message.m2.variableMessageSign			= psdMsg62.PSD_Ges_Wechselverkehrszeichen;
		psdInput.data.psd6.message.m2.variableMessageSignType		= psdMsg62.PSD_Wechselverkehrszeichen_Typ;
		psdInput.data.psd6.message.m2.constraintLegalStreetClass	= psdMsg62.PSD_Ges_Gesetzlich_Kategorie;
		psdInput.data.psd6.message.m2.constraintLegalAddition		= psdMsg62.PSD_Ges_Gesetzlich_Zusatz;
		psdInput.data.psd6.message.m2.sourceSpeedLimit				= psdMsg62.PSD_Ges_Verkehrszeichen_Quelle;
		psdInput.data.psd6.message.m2.completeFlag					= psdMsg62.PSD_Ges_Attribute_Komplett;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}


	if(this->GetInputPin("PpPSD15__DePSD06m3")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd63Message psdMsg63 = *(Dt_RECORD_PsdEhr_Psd63Message*)this->GetInputPin("PpPSD15__DePSD06m3")->GetDataPtr();
		psdInput_T psdInput;

		psdInput.type = psdMessage6;
		psdInput.data.psd6.multiplex = 3;

		psdInput.data.psd6.message.m3.longitudeSign					= psdMsg63.PSD_Baum_Laenge_VZ;
		psdInput.data.psd6.message.m3.longitude						= psdMsg63.PSD_Baum_Laenge;
		psdInput.data.psd6.message.m3.latitudeSign					= psdMsg63.PSD_Baum_Breite_VZ;
		psdInput.data.psd6.message.m3.latitude						= psdMsg63.PSD_Baum_Breite;
		psdInput.data.psd6.message.m3.direction						= psdMsg63.PSD_Baum_Ausrichtung;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}


	if(this->GetInputPin("PpPSD15__DePSD06m4")->Unflag()) {
		Dt_RECORD_PsdEhr_Psd64Message psdMsg64 = *(Dt_RECORD_PsdEhr_Psd64Message*)this->GetInputPin("PpPSD15__DePSD06m4")->GetDataPtr();
		psdInput_T psdInput;

		psdInput.type = psdMessage6;
		psdInput.data.psd6.multiplex = 4;

		psdInput.data.psd6.message.m4.segment1Id					= psdMsg64.PSD_Steigung_1_Segment_ID;
		psdInput.data.psd6.message.m4.segment1Slope1Value			= psdMsg64.PSD_Steigung_1_A_Steigung;
		psdInput.data.psd6.message.m4.segment1Slope1Sign			= psdMsg64.PSD_Steigung_1_A_Vorz;
		psdInput.data.psd6.message.m4.segment1Slope1Offset			= psdMsg64.PSD_Steigung_1_A_Offset;
		psdInput.data.psd6.message.m4.segment1Slope2Value			= psdMsg64.PSD_Steigung_1_B_Steigung;
		psdInput.data.psd6.message.m4.segment1Slope2Sign			= psdMsg64.PSD_Steigung_1_B_Vorz;
		psdInput.data.psd6.message.m4.segment1Slope2Offset			= psdMsg64.PSD_Steigung_1_B_Offset;
		psdInput.data.psd6.message.m4.segment1CompleteFlag			= psdMsg64.PSD_Steigung_1_Attribute_kompl;
		psdInput.data.psd6.message.m4.segment2Id					= psdMsg64.PSD_Steigung_2_Segment_ID;
		psdInput.data.psd6.message.m4.segment2Slope1Value			= psdMsg64.PSD_Steigung_2_Steigung;
		psdInput.data.psd6.message.m4.segment2Slope1Sign			= psdMsg64.PSD_Steigung_2_Vorz;
		psdInput.data.psd6.message.m4.segment2Slope1Offset			= psdMsg64.PSD_Steigung_2_Offset;
		psdInput.data.psd6.message.m4.segment2CompleteFlag			= psdMsg64.PSD_Steigung_2_Attribute_kompl;

		this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
	}
}
