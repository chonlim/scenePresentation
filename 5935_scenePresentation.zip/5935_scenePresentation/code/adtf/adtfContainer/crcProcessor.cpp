#include "stdafx.h"
#include "crcProcessor.h"


crcProcessor_T::crcProcessor_T(void)
{
	static const uint32_T	poly32 = 0xEDB88320L;

	uint16_T entry;
	uint16_T bit;
	uint32_T crc;

	for (entry = 0; entry < 256; entry++) {
		crc = (uint32_T) entry;

		for(bit = 0; bit < 8; bit++) {
			if(crc & 0x00000001L) {
				crc = ( crc >> 1 ) ^ poly32;
			}
			else {
				crc = crc >> 1;
			}
		}

		this->crcTable[entry] = crc;
	}
}


uint32_T	crcProcessor_T::GetCRC(void *data, size_t size)
{
	uint32_T crc = 0;

	for(size_t i = 0; i < size; i++) {
		uint32_T byte = 0x000000ffU & ((char*)data)[i];
		uint32_T temp = crc ^ byte;

		crc = (crc << 8 ) ^ this->crcTable[temp & 0xff];
	}

	return crc;
}
