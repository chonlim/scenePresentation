#ifndef guard_displayFilter_h
#define guard_displayFilter_h


#include "groundFilter.h"
#include "tools/dataGraph/graphControl.h"


class displayFilter_T
  : public adtf_graphics::cBaseDisplayFilter,
	public groundFilter_T,
	public graphCallback_T
{
public:
	graphControl_T		*control;
	graphControl_T		 defaultControl;

	bool				 canTimer;

public:
	displayFilter_T(const tChar* __info, float minX, float maxX, float minY, float maxY, float minZ, float maxZ);
	~displayFilter_T(void);

	virtual tResult	Init(tInitStage eStage, __exception = NULL);
	virtual tResult	Shutdown(tInitStage eStage, __exception = NULL);

	virtual tResult	OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);

	virtual tResult	Start(__exception = NULL);
	virtual tResult	Stop(__exception = NULL);

	tResult			GetInterface(const tChar* idInterface, tVoid** ppvObject);
	tUInt			Ref();
	tUInt			Unref();
	tVoid			Destroy();

	tTimeStamp		GetStreamTime();
	tBool			GetPropertyBool(const tChar* strName, tBool bDefault = tFalse);
	tResult			AllocMediaSample(IMediaSample** ppMediaSample, ucom::IException** __exception_ptr=NULL);
	const tChar*	OIGetInstanceName();
	tResult			RegisterPin(IPin* pIPin);
	tResult			ReleasePins(void);
	tResult			SetPropertyBool(const tChar* strName, tBool bValue);

	virtual	bool	ProcessMenuCommand(int cmd);
	virtual bool	ModifyContextMenu(HMENU hMenu);
	virtual void	PostRender();

	_graphControl::inputKey_T	ConvertKey(tInt nParam1);

	tResult			OnPaint(adtf_graphics::ICanvas* pCanvas, const adtf_graphics::cRect& rectInvalid);
	tResult			OnSize(tHandle hCanvas, tInt nLeft, tInt nTop, tInt nRight, tInt nBottom);
	tResult			OnTimer(tHandle hCanvas);
	tResult			OnIdle(tHandle hCanvas);
	tResult			OnControlEvent(tControlEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags, tVoid* pEventData);

	virtual void	AssignControl(graphControl_T *control);

	virtual void	PrePaint(void);
};



#endif