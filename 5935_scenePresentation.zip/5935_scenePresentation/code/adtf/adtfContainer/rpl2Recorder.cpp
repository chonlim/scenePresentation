#include "stdafx.h"
#include "rpl2Recorder.h"

#undef		GetObject


#include "tools/rpl2Tools/psdProcessor/psdProcessor.h"
#include <common/swcCommunication/swcComm_adtfTools.h>


extern "C" LPSTR __declspec(dllimport) __stdcall PathFindFileNameA(LPCSTR pszPath);
extern "C" LPWSTR __declspec(dllimport) __stdcall PathFindFileNameW(LPCWSTR pszPath);
#ifdef UNICODE
#define PathFindFileName  PathFindFileNameW
#else
#define PathFindFileName  PathFindFileNameA
#endif // !UNICODE

#pragma comment(lib, "shlwapi.lib")


#pragma warning(disable : 4355)
typedef struct canMessage_tag {
	int16_T		id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


rpl2Recorder_T::rpl2Recorder_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("flexray",			MEDIA_TYPE_FLEXRAY,				MEDIA_SUBTYPE_FLEXRAY);
	this->AddInputPin("canPSD",				MEDIA_TYPE_CAN,					MEDIA_SUBTYPE_CAN_RAW_MESSAGE);

	this->AddInputPin("pemControl",		pemControl_header());
	this->AddInputPin("pemPlanning",	pemPlanning_header());

	this->AddInputPin("evaluatedScenes",	MEDIA_TYPE_STRUCTURED_DATA,		MEDIA_SUBTYPE_STRUCT_UINT16);

	this->inputPin_flexray			= this->GetInputPin("flexray");
	this->inputPin_canPSD			= this->GetInputPin("canPSD");
	this->inputPin_pemControl		= this->GetInputPin("pemControl");
	this->inputPin_pemPlanning		= this->GetInputPin("pemPlanning");
	this->inputPin_evaluatedScenes	= this->GetInputPin("evaluatedScenes");

	this->SetPropertyStr("rpl2File",						"Replay$DATE$$TIME$.rpl2");
	this->SetPropertyBool("rpl2File"	NSSUBPROP_FILENAME,	tTrue);
}


bool	rpl2Recorder_T::OnInitNormal(void)
{
	this->rpl2File.ClearOut();

	return true;
}


bool	rpl2Recorder_T::OnGraphReady(void)
{
	/* Wenn der Flexray-Pin verbunden ist, fragen wir die Fibex-Datenbank nach den IDs f�r die PSD-PDUs */
	if(this->GetInputPin("flexray")->IsConnected()) {
		cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
		if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
			LOG_ERROR("No FlexRay support service available");
			return false;
		}


		cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
		if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
			LOG_ERROR("Failed to get FIBEX database");
			return false;
		}


		/* Nullsetzen der id-Strukur */
		memset(&this->id, 0, sizeof(this->id));



		/* Abfragen der IDs f�r die PDUs, die uns interessieren.
		   Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
		tUInt32 count;
		fibexDB->GetPDUCount(&count);

		for(tUInt32 i = 0; i < count; i++) {
			const tChar *name;
			fibexDB->GetPDUName(i, &name);

			if (!strcmp(name, "PSD_04"))					{ this->id.PSD_04.pdu = i;					continue; }
			if (!strcmp(name, "PSD_05"))					{ this->id.PSD_05.pdu = i;					continue; }
			if (!strcmp(name, "PSD_06"))					{ this->id.PSD_06.pdu = i;					continue; }
			if (!strcmp(name, "ACC_06"))					{ this->id.ACC_06.pdu = i;					continue; }
			if (!strcmp(name, "ACC_07"))					{ this->id.ACC_07.pdu = i;					continue; }
			if (!strcmp(name, "ACC_12"))					{ this->id.ACC_12.pdu = i;					continue; }
			if (!strcmp(name, "ACC_16"))					{ this->id.ACC_16.pdu = i;					continue; }
			if (!strcmp(name, "Blinkmodi_02"))				{ this->id.Blinkmodi_02.pdu = i;			continue; }
			if (!strcmp(name, "BV2_Linien_Ego_Doppel"))		{ this->id.BV2_Linien_Ego_Doppel.pdu = i;	continue; }
			if (!strcmp(name, "BV2_Linien_Ego_Links"))		{ this->id.BV2_Linien_Ego_Links.pdu = i;	continue; }
			if (!strcmp(name, "BV2_Linien_Ego_Rechts"))		{ this->id.BV2_Linien_Ego_Rechts.pdu = i;	continue; }
			if (!strcmp(name, "BV2_Linien_Nebenspuren"))	{ this->id.BV2_Linien_Nebenspuren.pdu = i;	continue; }
			if (!strcmp(name, "Charisma_03"))				{ this->id.Charisma_03.pdu = i;				continue; }
			if (!strcmp(name, "Charisma_08"))				{ this->id.Charisma_08.pdu = i;				continue; }
			if (!strcmp(name, "EM1_HYB_06"))				{ this->id.EM1_HYB_06.pdu = i;				continue; }
			if (!strcmp(name, "EM1_HYB_12"))				{ this->id.EM1_HYB_12.pdu = i;				continue; }
			if (!strcmp(name, "EM1_HYB_14"))				{ this->id.EM1_HYB_14.pdu = i;				continue; }
			if (!strcmp(name, "EM2_HYB_06"))				{ this->id.EM2_HYB_06.pdu = i;				continue; }
			if (!strcmp(name, "EM2_HYB_12"))				{ this->id.EM2_HYB_12.pdu = i;				continue; }
			if (!strcmp(name, "EML_01"))					{ this->id.EML_01.pdu = i;					continue; }
			if (!strcmp(name, "EML_03"))					{ this->id.EML_03.pdu = i;					continue; }
			if (!strcmp(name, "EML_04"))					{ this->id.EML_04.pdu = i;					continue; }
			if (!strcmp(name, "ESP_05"))					{ this->id.ESP_05.pdu = i;					continue; }
			if (!strcmp(name, "ESP_21"))					{ this->id.ESP_21.pdu = i;					continue; }
			if (!strcmp(name, "ESP_22"))					{ this->id.ESP_22.pdu = i;					continue; }
			if (!strcmp(name, "Fahrwerk_07"))				{ this->id.Fahrwerk_07.pdu = i;				continue; }
			if (!strcmp(name, "Getriebe_11"))				{ this->id.Getriebe_11.pdu = i;				continue; }
			if (!strcmp(name, "Getriebe_13"))				{ this->id.Getriebe_13.pdu = i;				continue; }
			if (!strcmp(name, "Getriebe_17"))				{ this->id.Getriebe_17.pdu = i;				continue; }
			if (!strcmp(name, "GRA_ACC_01"))				{ this->id.GRA_ACC_01.pdu = i;				continue; }
			if (!strcmp(name, "HAL_01"))					{ this->id.HAL_01.pdu = i;					continue; }
			if (!strcmp(name, "Kombi_01"))					{ this->id.Kombi_01.pdu = i;				continue; }
			if (!strcmp(name, "Kombi_02"))					{ this->id.Kombi_02.pdu = i;				continue; }
			if (!strcmp(name, "LWI_01"))					{ this->id.LWI_01.pdu = i;					continue; }
			if (!strcmp(name, "Motor_04"))					{ this->id.Motor_04.pdu = i;				continue; }
			if (!strcmp(name, "Motor_07"))					{ this->id.Motor_07.pdu = i;				continue; }
			if (!strcmp(name, "Motor_11"))					{ this->id.Motor_11.pdu = i;				continue; }
			if (!strcmp(name, "Motor_14"))					{ this->id.Motor_14.pdu = i;				continue; }
			if (!strcmp(name, "Motor_16"))					{ this->id.Motor_16.pdu = i;				continue; }
			if (!strcmp(name, "Motor_18"))					{ this->id.Motor_18.pdu = i;				continue; }
			if (!strcmp(name, "Motor_20"))					{ this->id.Motor_20.pdu = i;				continue; }
			if (!strcmp(name, "Motor_27"))					{ this->id.Motor_27.pdu = i;				continue; }
			if (!strcmp(name, "Motor_28"))					{ this->id.Motor_28.pdu = i;				continue; }
			if (!strcmp(name, "Motor_Code_01"))				{ this->id.Motor_Code_01.pdu = i;			continue; }
			if (!strcmp(name, "Motor_Hybrid_03"))			{ this->id.Motor_Hybrid_03.pdu = i;			continue; }
			if (!strcmp(name, "NavPos_01"))					{ this->id.NavPos_01.pdu = i;				continue; }
			if (!strcmp(name, "PACC_01"))					{ this->id.PACC_01.pdu = i;					continue; }
			if (!strcmp(name, "PACC_02"))					{ this->id.PACC_02.pdu = i;					continue; }
			if (!strcmp(name, "PACC02_01"))					{ this->id.PACC02_01.pdu = i;				continue; }
			if (!strcmp(name, "PACC02_02"))					{ this->id.PACC02_02.pdu = i;				continue; }
			if (!strcmp(name, "PACC02_03"))					{ this->id.PACC02_03.pdu = i;				continue; }
			if (!strcmp(name, "PIDM_01"))					{ this->id.PIDM_01.pdu = i;					continue; }
			if (!strcmp(name, "pVS_01"))					{ this->id.pVS_01.pdu = i;					continue; }
			if (!strcmp(name, "SDF1_Objekt_01"))			{ this->id.SDF1_Objekt_01.pdu = i;			continue; }
			if (!strcmp(name, "SDF1_Objekt_04"))			{ this->id.SDF1_Objekt_04.pdu = i;			continue; }
			if (!strcmp(name, "SDF2_Pos_01"))				{ this->id.SDF2_Pos_01.pdu = i;				continue; }
			if (!strcmp(name, "SpoilerSG_01"))				{ this->id.SpoilerSG_01.pdu = i;			continue; }
			if (!strcmp(name, "SARA_11"))					{ this->id.SARA_11.pdu = i;					continue; }
			if (!strcmp(name, "TSK_06"))					{ this->id.TSK_06.pdu = i;					continue; }
			if (!strcmp(name, "TSK_08"))					{ this->id.TSK_08.pdu = i;					continue; }
			if (!strcmp(name, "VZE_01"))					{ this->id.VZE_01.pdu = i;					continue; }
			if (!strcmp(name, "VZE_02"))					{ this->id.VZE_02.pdu = i;					continue; }
			if (!strcmp(name, "VZE_03"))					{ this->id.VZE_03.pdu = i;					continue; }
			if (!strcmp(name, "DEV_BVS_02"))				{ this->id.DEV_BVS_02.pdu = i;				continue; }
			if (!strcmp(name, "DEV_BVS_03"))				{ this->id.DEV_BVS_03.pdu = i;				continue; }
			if (!strcmp(name, "DEV_BVS_04"))				{ this->id.DEV_BVS_04.pdu = i;				continue; }
		}


		/* Abfragen der Signal-IDs, f�r die wir uns interessieren. */

		if(IS_FAILED(fibexDB->GetSignalID("ACC_zul_Regelabw_unten",				&this->id.ACC_06.ACC_zul_Regelabw_unten)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Sollbeschleunigung_02",			&this->id.ACC_06.ACC_Sollbeschleunigung_02)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_zul_Regelabw_oben",				&this->id.ACC_06.ACC_zul_Regelabw_oben)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_neg_Sollbeschl_Grad_02",			&this->id.ACC_06.ACC_neg_Sollbeschl_Grad_02)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_pos_Sollbeschl_Grad_02",			&this->id.ACC_06.ACC_pos_Sollbeschl_Grad_02)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Status_ACC",						&this->id.ACC_06.ACC_Status_ACC)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("ACC_Folgebeschl",					&this->id.ACC_07.ACC_Folgebeschl)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Freilauf_Info",					&this->id.ACC_07.ACC_Freilauf_Info)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("ACC_Gesetzte_Zeitluecke",			&this->id.ACC_12.ACC_Gesetzte_Zeitluecke)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("ACC_Fahrprogramm_PACC",				&this->id.ACC_16.ACC_Fahrprogramm_PACC)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Nutzung_VZ_PACC",				&this->id.ACC_16.ACC_Nutzung_VZ_PACC)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Regelung_durch_PACC",			&this->id.ACC_16.ACC_Regelung_durch_PACC)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Sensibilitaet_PACC",				&this->id.ACC_16.ACC_Sensibilitaet_PACC)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_vLimit1_PACC",					&this->id.ACC_16.ACC_vLimit1_PACC)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ACC_Offset_Default_PACC",			&this->id.ACC_16.ACC_Offset_Default_PACC)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("BM_links",							&this->id.Blinkmodi_02.BM_links)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BM_rechts",							&this->id.Blinkmodi_02.BM_rechts)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BM_Autobahn",						&this->id.Blinkmodi_02.BM_Autobahn)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_BeginnX",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_VorgaengerID",			&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_ID",						&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_ID)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_AbstandY",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_GierWnkl",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_HorKruemm",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_HorKruemm)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_HorKruemmAend",			&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_HorKruemmAend)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_ExistMass",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_ExistMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_NachfolgerID",			&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_EndeX",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_EndeX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_Breite",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Breite)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_Typ",						&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Typ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_Hoehe",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Hoehe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_05_Farbe",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Farbe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_BeginnX",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_VorgaengerID",			&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_ID",						&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_ID)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_AbstandY",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_GierWnkl",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_HorKruemm",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_HorKruemm)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_HorKruemmAend",			&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_HorKruemmAend)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_ExistMass",				&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_ExistMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_NachfolgerID",			&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_EndeX",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_EndeX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_Breite",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Breite)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_Typ",						&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Typ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_Hoehe",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Hoehe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_06_Farbe",					&this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Farbe)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_BeginnX",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_VorgaengerID",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_ID",						&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_ID)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_AbstandY",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_GierWnkl",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_HorKruemm",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_HorKruemm)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_HorKruemmAend",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_HorKruemmAend)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_ExistMass",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_ExistMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_NachfolgerID",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_EndeX",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_EndeX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_Breite",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Breite)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_Typ",						&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Typ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_Hoehe",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Hoehe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_Farbe",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Farbe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_Seg01_StdA_E",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Seg01_StdA_E)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_01_Seg01_StdA_M",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Seg01_StdA_M)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_BeginnX",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_VorgaengerID",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_ID",						&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_ID)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_AbstandY",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_GierWnkl",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_HorKruemm",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_HorKruemm)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_HorKruemmAend",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_HorKruemmAend)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_ExistMass",				&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_ExistMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_NachfolgerID",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_EndeX",					&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_EndeX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_Seg02_StdA_A",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_Seg02_StdA_A)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_Seg02_StdA_E",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_Seg02_StdA_E)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_07_Seg02_StdA_M",			&this->id.BV2_Linien_Ego_Links.BV1_LIN_07_Seg02_StdA_M)))		{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_BeginnX",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_VorgaengerID",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_ID",						&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_ID)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_AbstandY",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_GierWnkl",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_HorKruemm",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_HorKruemm)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_HorKruemmAend",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_HorKruemmAend)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_ExistMass",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_ExistMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_NachfolgerID",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_EndeX",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_EndeX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_Breite",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Breite)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_Typ",						&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Typ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_Hoehe",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Hoehe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_Farbe",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Farbe)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_Seg01_StdA_E",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Seg01_StdA_E)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_02_Seg01_StdA_M",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Seg01_StdA_M)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_BeginnX",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_VorgaengerID",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_ID",						&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_ID)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_AbstandY",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_GierWnkl",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_HorKruemm",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_HorKruemm)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_HorKruemmAend",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_HorKruemmAend)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_ExistMass",				&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_ExistMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_NachfolgerID",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_EndeX",					&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_EndeX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_Seg02_StdA_A",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_Seg02_StdA_A)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_Seg02_StdA_E",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_Seg02_StdA_E)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_08_Seg02_StdA_M",			&this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_Seg02_StdA_M)))		{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_BeginnX",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_VorgaengerID",			&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_ID",						&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_ID)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_AbstandY",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_GierWnkl",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_HorKruemm",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_HorKruemm)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_HorKruemmAend",			&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_HorKruemmAend)))	{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_ExistMass",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_ExistMass)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_NachfolgerID",			&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_EndeX",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_EndeX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_Breite",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Breite)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_Typ",						&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Typ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_Hoehe",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Hoehe)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_03_Farbe",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Farbe)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_BeginnX",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_BeginnX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_VorgaengerID",			&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_VorgaengerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_ID",						&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_ID)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_AbstandY",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_AbstandY)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_GierWnkl",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_GierWnkl)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_HorKruemm",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_HorKruemm)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_HorKruemmAend",			&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_HorKruemmAend)))	{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_ExistMass",				&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_ExistMass)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_NachfolgerID",			&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_NachfolgerID)))		{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_EndeX",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_EndeX)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_Breite",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Breite)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_Typ",						&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Typ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_Hoehe",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Hoehe)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("BV1_LIN_04_Farbe",					&this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Farbe)))			{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("CHA_EV_LED",							&this->id.Charisma_03.CHA_EV_LED)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("CHA_Ziel_FahrPr_PACC",				&this->id.Charisma_08.CHA_Ziel_FahrPr_PACC)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EM1_Max_Moment",						&this->id.EM1_HYB_06.EM1_Max_Moment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EM1_Min_Moment",						&this->id.EM1_HYB_06.EM1_Min_Moment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EM1_MaxDyn_Moment",					&this->id.EM1_HYB_06.EM1_MaxDyn_Moment)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EM1_IstMoment",						&this->id.EM1_HYB_12.EM1_IstMoment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EM1_IstDrehzahl",					&this->id.EM1_HYB_12.EM1_IstDrehzahl)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EM1_MaxPred_Moment",					&this->id.EM1_HYB_14.EM1_MaxPred_Moment)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EM1_MaxPred_Abknickdrehzahl",		&this->id.EM1_HYB_14.EM1_MaxPred_Abknickdrehzahl)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EM2_Max_Moment",						&this->id.EM2_HYB_06.EM2_Max_Moment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EM2_MaxDyn_Moment",					&this->id.EM2_HYB_06.EM2_MaxDyn_Moment)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EM2_IstMoment",						&this->id.EM2_HYB_12.EM2_IstMoment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EM2_IstDrehzahl",					&this->id.EM2_HYB_12.EM2_IstDrehzahl)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EML_BeschlX",						&this->id.EML_01.EML_BeschlX)))									{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EML_GeschwX",						&this->id.EML_01.EML_GeschwX)))									{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EML_GierRate",						&this->id.EML_01.EML_GierRate)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EML_BeschlY",						&this->id.EML_03.EML_BeschlY)))									{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EML_Gierwinkel",						&this->id.EML_04.EML_Gierwinkel)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EML_PositionX",						&this->id.EML_04.EML_PositionX)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EML_PositionY",						&this->id.EML_04.EML_PositionY)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("ESP_Status_Bremsdruck",				&this->id.ESP_05.ESP_Status_Bremsdruck)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("ESP_v_Signal",						&this->id.ESP_21.ESP_v_Signal)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("ESP_QBit_VL_Bremsmoment",			&this->id.ESP_22.ESP_QBit_VL_Bremsmoment)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_QBit_VR_Bremsmoment",			&this->id.ESP_22.ESP_QBit_VR_Bremsmoment)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_QBit_HL_Bremsmoment",			&this->id.ESP_22.ESP_QBit_HL_Bremsmoment)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_QBit_HR_Bremsmoment",			&this->id.ESP_22.ESP_QBit_HR_Bremsmoment)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_VL_Bremsmoment",					&this->id.ESP_22.ESP_VL_Bremsmoment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_VR_Bremsmoment",					&this->id.ESP_22.ESP_VR_Bremsmoment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_HL_Bremsmoment",					&this->id.ESP_22.ESP_HL_Bremsmoment)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("ESP_HR_Bremsmoment",					&this->id.ESP_22.ESP_HR_Bremsmoment)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("EFP_NaesseLevel",					&this->id.Fahrwerk_07.EFP_NaesseLevel)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("EFP_NaesseLevel_Classifier",			&this->id.Fahrwerk_07.EFP_NaesseLevel_Classifier)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("GE_Fahrstufe",						&this->id.Getriebe_11.GE_Fahrstufe)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GE_Schaltablauf",					&this->id.Getriebe_11.GE_Schaltablauf)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GE_Status_Kraftschluss",				&this->id.Getriebe_11.GE_Status_Kraftschluss)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GE_Zielgang",						&this->id.Getriebe_11.GE_Zielgang)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("GE_Verlustmoment",					&this->id.Getriebe_13.GE_Verlustmoment)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("GE_Freilauf_Status",					&this->id.Getriebe_17.GE_Freilauf_Status)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GE_Uefkt_Praed",						&this->id.Getriebe_17.GE_Uefkt_Praed)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("GRA_Hauptschalter",					&this->id.GRA_ACC_01.GRA_Hauptschalter)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Abbrechen",						&this->id.GRA_ACC_01.GRA_Abbrechen)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Limiter",						&this->id.GRA_ACC_01.GRA_Limiter)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Tip_Setzen",						&this->id.GRA_ACC_01.GRA_Tip_Setzen)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Tip_Hoch",						&this->id.GRA_ACC_01.GRA_Tip_Hoch)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Tip_Runter",						&this->id.GRA_ACC_01.GRA_Tip_Runter)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Tip_Wiederaufnahme",				&this->id.GRA_ACC_01.GRA_Tip_Wiederaufnahme)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Verstellung_Zeitluecke",			&this->id.GRA_ACC_01.GRA_Verstellung_Zeitluecke)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Tip_Stufe_2",					&this->id.GRA_ACC_01.GRA_Tip_Stufe_2)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("GRA_Typ_Bedienteil",					&this->id.GRA_ACC_01.GRA_Typ_Bedienteil)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("HAL_VZ_Radwinkel",					&this->id.HAL_01.HAL_VZ_Radwinkel)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("HAL_QBit_Radwinkel",					&this->id.HAL_01.HAL_QBit_Radwinkel)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("HAL_Radwinkel",						&this->id.HAL_01.HAL_Radwinkel)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("KBI_angez_Geschw",					&this->id.Kombi_01.KBI_angez_Geschw)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("KBI_Einheit_Tacho",					&this->id.Kombi_01.KBI_Einheit_Tacho)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("KBI_aktive_Laengsfunktion",			&this->id.Kombi_02.KBI_aktive_Laengsfunktion)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("LWI_Lenkradwinkel",					&this->id.LWI_01.LWI_Lenkradwinkel)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("LWI_Lenkradw_Geschw",				&this->id.LWI_01.LWI_Lenkradw_Geschw)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("LWI_VZ_Lenkradwinkel",				&this->id.LWI_01.LWI_VZ_Lenkradwinkel)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("LWI_VZ_Lenkradw_Geschw",				&this->id.LWI_01.LWI_VZ_Lenkradw_Geschw)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_KVS",								&this->id.Motor_04.MO_KVS)))									{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Kuehlmittel_Temp",				&this->id.Motor_07.MO_Kuehlmittel_Temp)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Mom_Ist_Summe",					&this->id.Motor_11.MO_Mom_Ist_Summe)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Mom_Schub",						&this->id.Motor_11.MO_Mom_Schub)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Mom_Begr_stat",					&this->id.Motor_12.MO_Mom_Begr_stat)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Mom_Begr_dyn",					&this->id.Motor_12.MO_Mom_Begr_dyn)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_HYB_VM_aktiv",					&this->id.Motor_14.MO_HYB_VM_aktiv)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Fahrer_bremst",					&this->id.Motor_14.MO_Fahrer_bremst)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("TSK_Steigung_02",					&this->id.Motor_16.TSK_Steigung_02)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_QBit_Steigung",					&this->id.Motor_16.TSK_QBit_Steigung)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_QBit_Fahrzeugmasse",				&this->id.Motor_16.TSK_QBit_Fahrzeugmasse)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_Fahrzeugmasse_02",				&this->id.Motor_16.TSK_Fahrzeugmasse_02)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_Grundmasse",						&this->id.Motor_16.TSK_Grundmasse)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Fahrzeugtyp",						&this->id.Motor_18.MO_Fahrzeugtyp)))							{ return false; }
		
		if(IS_FAILED(fibexDB->GetSignalID("MO_Fahrpedalrohwert_01",				&this->id.Motor_20.MO_Fahrpedalrohwert_01)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Leistungsvermoegen",				&this->id.Motor_27.MO_Leistungsvermoegen)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Drehzahl_VM",						&this->id.Motor_28.MO_Drehzahl_VM)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("MO_Faktor_Momente_02",				&this->id.Motor_Code_01.MO_Faktor_Momente_02)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Hybridfahrzeug",					&this->id.Motor_Code_01.MO_Hybridfahrzeug)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Code",							&this->id.Motor_Code_01.MO_Code)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Getriebe_Code",					&this->id.Motor_Code_01.MO_Getriebe_Code)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Anzahl_Zyl",						&this->id.Motor_Code_01.MO_Anzahl_Zyl)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Kraftstoffart",					&this->id.Motor_Code_01.MO_Kraftstoffart)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Hubraum",							&this->id.Motor_Code_01.MO_Hubraum)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Ansaugsystem",					&this->id.Motor_Code_01.MO_Ansaugsystem)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Leistung",						&this->id.Motor_Code_01.MO_Leistung)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("Ladezustand_02",						&this->id.Motor_Hybrid_03.Ladezustand_02)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("MO_Zust_Betriebsstrategie",			&this->id.Motor_Hybrid_03.MO_Zust_Betriebsstrategie)))			{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("NP_LatDegree",						&this->id.NavPos_01.NP_LatDegree)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("NP_LatDirection",					&this->id.NavPos_01.NP_LatDirection)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("NP_LongDegree",						&this->id.NavPos_01.NP_LongDegree)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("NP_LongDirection",					&this->id.NavPos_01.NP_LongDirection)))							{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("PACC_Wunschuebersetzung",			&this->id.PACC_01.PACC_Wunschuebersetzung)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Sollbeschleunigung",			&this->id.PACC_01.PACC_Sollbeschleunigung)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_zul_Regelabw_oben",				&this->id.PACC_01.PACC_zul_Regelabw_oben)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_neg_Sollbeschl_Grad",			&this->id.PACC_01.PACC_neg_Sollbeschl_Grad)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_pos_Sollbeschl_Grad",			&this->id.PACC_01.PACC_pos_Sollbeschl_Grad)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Ausrollmanoever",				&this->id.PACC_01.PACC_Ausrollmanoever)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_zul_Regelabw_unten",			&this->id.PACC_01.PACC_zul_Regelabw_unten)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("PACC_Sytemstatus_Anzeige",			&this->id.PACC_02.PACC_Sytemstatus_Anzeige)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Automode",						&this->id.PACC_02.PACC_Automode)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Segelanteil",					&this->id.PACC_02.PACC_Segelanteil)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Durchschnittsgeschw",			&this->id.PACC_02.PACC_Durchschnittsgeschw)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Uebernahmeaufforderung",		&this->id.PACC_02.PACC_Uebernahmeaufforderung)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Systemstatus",					&this->id.PACC_02.PACC_Systemstatus)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Vorausschaugeschw",				&this->id.PACC_02.PACC_Vorausschaugeschw)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Offset",						&this->id.PACC_02.PACC_Offset)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_Sollgeschwindigkeit",			&this->id.PACC_02.PACC_Sollgeschwindigkeit)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC_naechstes_Event",				&this->id.PACC_02.PACC_naechstes_Event)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Wunschuebersetzung",			&this->id.PACC02_01.PACC02_Wunschuebersetzung)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Sollbeschleunigung",			&this->id.PACC02_01.PACC02_Sollbeschleunigung)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_zul_Regelabw_oben",			&this->id.PACC02_01.PACC02_zul_Regelabw_oben)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_neg_Sollbeschl_Grad",			&this->id.PACC02_01.PACC02_neg_Sollbeschl_Grad)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_pos_Sollbeschl_Grad",			&this->id.PACC02_01.PACC02_pos_Sollbeschl_Grad)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Ausrollmanoever",				&this->id.PACC02_01.PACC02_Ausrollmanoever)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_zul_Regelabw_unten",			&this->id.PACC02_01.PACC02_zul_Regelabw_unten)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("PACC02_InnoDrive_Texte",				&this->id.PACC02_02.PACC02_InnoDrive_Texte)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Systemstatus_Anzeige",		&this->id.PACC02_02.PACC02_Systemstatus_Anzeige)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Automode",					&this->id.PACC02_02.PACC02_Automode)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Segelanteil",					&this->id.PACC02_02.PACC02_Segelanteil)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Durchschnittsgeschw",			&this->id.PACC02_02.PACC02_Durchschnittsgeschw)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Uebernahmeaufforderung",		&this->id.PACC02_02.PACC02_Uebernahmeaufforderung)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Systemstatus",				&this->id.PACC02_02.PACC02_Systemstatus)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Vorausschaugeschw",			&this->id.PACC02_02.PACC02_Vorausschaugeschw)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Offset",						&this->id.PACC02_02.PACC02_Offset)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Sollgeschwindigkeit",			&this->id.PACC02_02.PACC02_Sollgeschwindigkeit)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_naechstes_Event",				&this->id.PACC02_02.PACC02_naechstes_Event)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Geschw_Vorausschau",			&this->id.PACC02_03.PACC02_Geschw_Vorausschau)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Event_aktiv",					&this->id.PACC02_03.PACC02_Event_aktiv)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Hinweis_Geschw",				&this->id.PACC02_03.PACC02_Hinweis_Geschw)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Offset_aktiv",				&this->id.PACC02_03.PACC02_Offset_aktiv)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("PACC02_Offset_Anzeige",				&this->id.PACC02_03.PACC02_Offset_Anzeige)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("PIDM_HS_Richtung",					&this->id.PIDM_01.PIDM_HS_Richtung)))							{  }
		if(IS_FAILED(fibexDB->GetSignalID("PIDM_HS_Attribut",					&this->id.PIDM_01.PIDM_HS_Attribut)))							{  }
		if(IS_FAILED(fibexDB->GetSignalID("PIDM_HS_Abstand",					&this->id.PIDM_01.PIDM_HS_Abstand)))							{  }
		if(IS_FAILED(fibexDB->GetSignalID("PIDM_HS_Heading",					&this->id.PIDM_01.PIDM_HS_Heading)))							{  }
		if(IS_FAILED(fibexDB->GetSignalID("PIDM_HS_Index",						&this->id.PIDM_01.PIDM_HS_Index)))								{  }
		if(IS_FAILED(fibexDB->GetSignalID("PIDM_Status",						&this->id.PIDM_01.PIDM_Status)))								{  }
		if(IS_FAILED(fibexDB->GetSignalID("PIDM_HS_Typnummer",					&this->id.PIDM_01.PIDM_HS_Typnummer)))							{  }

		if(IS_FAILED(fibexDB->GetSignalID("pVS_vLimit_Range_HMI",				&this->id.pVS_01.pVS_vLimit_Range_HMI)))						{  }

		if(IS_FAILED(fibexDB->GetSignalID("SARA_Accel_X_r",						&this->id.SARA_11.SARA_Accel_X_r)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SARA_Accel_Y_r",						&this->id.SARA_11.SARA_Accel_Y_r)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SARA_Omega_Z_r",						&this->id.SARA_11.SARA_Omega_Z_r)))								{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("TSK_Status",							&this->id.TSK_06.TSK_Status)))									{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_Hauptschalter_GRA_ACC",			&this->id.TSK_06.TSK_Hauptschalter_GRA_ACC)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_Limiter_ausgewaehlt",			&this->id.TSK_06.TSK_Limiter_ausgewaehlt)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("TSK_Einheit_vMax_Fahrerassistenz",	&this->id.TSK_08.TSK_Einheit_vMax_Fahrerassistenz)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_vMax_aktuell",					&this->id.TSK_08.TSK_vMax_aktuell)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("TSK_vMax_Fahrerassistenz",			&this->id.TSK_08.TSK_vMax_Fahrerassistenz)))					{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_ID",						&this->id.SDF1_Objekt_01.SDF1_Obj_01_ID)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Gemessen",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_Gemessen)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Historie",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_Historie)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_ExistenzMass",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_ExistenzMass)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Alter",					&this->id.SDF1_Objekt_01.SDF1_Obj_01_Alter)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Klasse",					&this->id.SDF1_Objekt_01.SDF1_Obj_01_Klasse)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_KlassePlausib",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_KlassePlausib)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Bezugspunkt",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_Bezugspunkt)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_PositionX",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_PositionXStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionXStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_PositionY",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionY)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_PositionYStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionYStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_PositionZ",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionZ)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_PositionZStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionZStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_GeschwRelX",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_GeschwRelXStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelXStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_GeschwRelY",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelY)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_GeschwRelYStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelYStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_BeschlRelX",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_BeschlRelXStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelXStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_BeschlRelY",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelY)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_BeschlRelYStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelYStdA)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Hoehe",					&this->id.SDF1_Objekt_01.SDF1_Obj_01_Hoehe)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_HoeheStdA",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_HoeheStdA)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Breite",					&this->id.SDF1_Objekt_01.SDF1_Obj_01_Breite)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_BreiteStdA",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_BreiteStdA)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_Laenge",					&this->id.SDF1_Objekt_01.SDF1_Obj_01_Laenge)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_LaengeStdA",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_LaengeStdA)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_GierWnkl",				&this->id.SDF1_Objekt_01.SDF1_Obj_01_GierWnkl)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_01_GierWnklStdA",			&this->id.SDF1_Objekt_01.SDF1_Obj_01_GierWnklStdA)))			{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_04_PositionX",				&this->id.SDF1_Objekt_04.SDF1_Obj_04_PositionX)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF1_Obj_04_GeschwRelX",				&this->id.SDF1_Objekt_04.SDF1_Obj_04_GeschwRelX)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Inhibitzeit",				&this->id.SDF2_Pos_01.SDF2_Pos_Inhibitzeit)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Segment_ID",				&this->id.SDF2_Pos_01.SDF2_Pos_Segment_ID)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Offset",					&this->id.SDF2_Pos_01.SDF2_Pos_Offset)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Standort_Eindeutig",		&this->id.SDF2_Pos_01.SDF2_Pos_Standort_Eindeutig)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Distanz_Rampe_rechts",		&this->id.SDF2_Pos_01.SDF2_Pos_Distanz_Rampe_rechts)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Spurtype",					&this->id.SDF2_Pos_01.SDF2_Pos_Spurtype)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Distanz_Rampe_links",		&this->id.SDF2_Pos_01.SDF2_Pos_Distanz_Rampe_links)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_AnzRampenRechts",			&this->id.SDF2_Pos_01.SDF2_Pos_AnzRampenRechts)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_AnzRampenLinks",			&this->id.SDF2_Pos_01.SDF2_Pos_AnzRampenLinks)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Fehler_Laengsrichtung",		&this->id.SDF2_Pos_01.SDF2_Pos_Fehler_Laengsrichtung)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_AnzHauptspuren",			&this->id.SDF2_Pos_01.SDF2_Pos_AnzHauptspuren)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_Spurnummer",				&this->id.SDF2_Pos_01.SDF2_Pos_Spurnummer)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("SDF2_Pos_GueteZuordnung",			&this->id.SDF2_Pos_01.SDF2_Pos_GueteZuordnung)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("SpoilerSG_HSpoiler_IstPos",			&this->id.SpoilerSG_01.SpoilerSG_HSpoiler_IstPos)))				{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anzeigemodus",					&this->id.VZE_01.VZE_Anzeigemodus)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Hinweistext",					&this->id.VZE_01.VZE_Hinweistext)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anzeigeunterdrueck_Zeichen_3",	&this->id.VZE_01.VZE_Anzeigeunterdrueck_Zeichen_3)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anzeigeunterdrueck_Zeichen_2",	&this->id.VZE_01.VZE_Anzeigeunterdrueck_Zeichen_2)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_1",				&this->id.VZE_01.VZE_Verkehrszeichen_1)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_2",				&this->id.VZE_01.VZE_Verkehrszeichen_2)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_3",				&this->id.VZE_01.VZE_Verkehrszeichen_3)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Warnung_Verkehrszeichen_1",		&this->id.VZE_01.VZE_Warnung_Verkehrszeichen_1)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Warnung_Verkehrszeichen_2",		&this->id.VZE_01.VZE_Warnung_Verkehrszeichen_2)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Warnung_Verkehrszeichen_3",		&this->id.VZE_01.VZE_Warnung_Verkehrszeichen_3)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zusatzschild_1",					&this->id.VZE_01.VZE_Zusatzschild_1)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zusatzschild_2",					&this->id.VZE_01.VZE_Zusatzschild_2)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zusatzschild_3",					&this->id.VZE_01.VZE_Zusatzschild_3)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anzeigeunterdrueck_Zeichen_1",	&this->id.VZE_01.VZE_Anzeigeunterdrueck_Zeichen_1)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_01_KameraWied",			&this->id.VZE_01.VZE_Zeichen_01_KameraWied)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_02_KameraWied",			&this->id.VZE_01.VZE_Zeichen_02_KameraWied)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_03_KameraWied",			&this->id.VZE_01.VZE_Zeichen_03_KameraWied)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_01_Kamera",				&this->id.VZE_01.VZE_Zeichen_01_Kamera)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_01_Karte",				&this->id.VZE_01.VZE_Zeichen_01_Karte)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_01_Gesetz",				&this->id.VZE_01.VZE_Zeichen_01_Gesetz)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_02_Kamera",				&this->id.VZE_01.VZE_Zeichen_02_Kamera)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_02_Karte",				&this->id.VZE_01.VZE_Zeichen_02_Karte)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_02_Gesetz",				&this->id.VZE_01.VZE_Zeichen_02_Gesetz)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_03_Kamera",				&this->id.VZE_01.VZE_Zeichen_03_Kamera)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_03_Karte",				&this->id.VZE_01.VZE_Zeichen_03_Karte)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_03_Gesetz",				&this->id.VZE_01.VZE_Zeichen_03_Gesetz)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Gong",							&this->id.VZE_01.VZE_Gong)))									{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_Einheit",		&this->id.VZE_01.VZE_Verkehrszeichen_Einheit)))									{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anzeigeunterdrueck_Zeichen_5",	&this->id.VZE_02.VZE_Anzeigeunterdrueck_Zeichen_5)))			{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_05_KameraWied",			&this->id.VZE_02.VZE_Zeichen_05_KameraWied)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_05_Kamera",				&this->id.VZE_02.VZE_Zeichen_05_Kamera)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_4",				&this->id.VZE_02.VZE_Verkehrszeichen_4)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_5",				&this->id.VZE_02.VZE_Verkehrszeichen_5)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anhaenger_Vmax",					&this->id.VZE_02.VZE_Anhaenger_Vmax)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_04_Gesetz",				&this->id.VZE_02.VZE_Zeichen_04_Gesetz)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_04_Kamera",				&this->id.VZE_02.VZE_Zeichen_04_Kamera)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_04_KameraWied",			&this->id.VZE_02.VZE_Zeichen_04_KameraWied)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_04_Karte",				&this->id.VZE_02.VZE_Zeichen_04_Karte)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Warnung_Verkehrszeichen_4",		&this->id.VZE_02.VZE_Warnung_Verkehrszeichen_4)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Warnung_Verkehrszeichen_5",		&this->id.VZE_02.VZE_Warnung_Verkehrszeichen_5)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_05_Gesetz",				&this->id.VZE_02.VZE_Zeichen_05_Gesetz)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zusatzschild_4",					&this->id.VZE_02.VZE_Zusatzschild_4)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zusatzschild_5",					&this->id.VZE_02.VZE_Zusatzschild_5)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Baustelle",						&this->id.VZE_02.VZE_Baustelle)))								{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_05_Karte",				&this->id.VZE_02.VZE_Zeichen_05_Karte)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_05_Entfernung",			&this->id.VZE_02.VZE_Zeichen_05_Entfernung)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_05_Entfernung_StdA",		&this->id.VZE_02.VZE_Zeichen_05_Entfernung_StdA)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Anzeigeunterdrueck_Zeichen_4",	&this->id.VZE_02.VZE_Anzeigeunterdrueck_Zeichen_4)))			{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("VZE_Verkehrszeichen_6",				&this->id.VZE_03.VZE_Verkehrszeichen_6)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zusatzschild_6",					&this->id.VZE_03.VZE_Zusatzschild_6)))							{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_06_Entfernung",			&this->id.VZE_03.VZE_Zeichen_06_Entfernung)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Zeichen_06_Entfernung_StdA",		&this->id.VZE_03.VZE_Zeichen_06_Entfernung_StdA)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Umweltinfo_Naesse",				&this->id.VZE_03.VZE_Umweltinfo_Naesse)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Umweltinfo_Nebel",				&this->id.VZE_03.VZE_Umweltinfo_Nebel)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Umweltinfo_Anhaengerbetrieb",	&this->id.VZE_03.VZE_Umweltinfo_Anhaengerbetrieb)))				{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Erweiterte_Information",			&this->id.VZE_03.VZE_Erweiterte_Information)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Tempowarnung_Status",			&this->id.VZE_03.VZE_Tempowarnung_Status)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Tempowarnung_Einheit",			&this->id.VZE_03.VZE_Tempowarnung_Einheit)))					{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("VZE_Tempowarnung_Offset",			&this->id.VZE_03.VZE_Tempowarnung_Offset)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_01",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_01)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_02",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_02)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_03",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_03)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_04",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_04)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_05",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_05)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_06",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_06)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_07",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_07)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_08",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_08)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_09",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_09)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_10",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_10)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_11",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_11)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_12",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_12)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_13",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_13)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_14",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_14)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_15",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_15)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_16",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_16)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_17",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_17)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_18",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_18)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_19",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_19)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_20",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_20)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_02_Data_21",					&this->id.DEV_BVS_02.DEV_BVS_02_Data_21)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_01",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_01)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_02",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_02)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_03",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_03)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_04",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_04)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_05",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_05)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_06",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_06)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_07",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_07)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_08",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_08)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_09",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_09)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_10",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_10)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_11",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_11)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_12",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_12)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_13",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_13)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_14",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_14)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_15",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_15)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_16",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_16)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_17",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_17)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_18",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_18)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_19",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_19)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_20",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_20)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_21",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_21)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_03_Data_22",					&this->id.DEV_BVS_03.DEV_BVS_03_Data_22)))						{ return false; }

		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_01",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_01)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_02",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_02)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_03",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_03)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_04",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_04)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_05",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_05)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_06",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_06)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_07",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_07)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_08",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_08)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_09",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_09)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_10",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_10)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_11",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_11)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_12",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_12)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_13",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_13)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_14",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_14)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_15",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_15)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_16",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_16)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_17",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_17)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_18",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_18)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_19",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_19)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_20",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_20)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_21",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_21)))						{ return false; }
		if(IS_FAILED(fibexDB->GetSignalID("DEV_BVS_04_Data_22",					&this->id.DEV_BVS_04.DEV_BVS_04_Data_22)))						{ return false; }

		/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
		cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
		if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
			LOG_ERROR("Failed to create FlexRay coder");
			return false;
		}

		this->flexrayCoder = coder;
		this->flexrayCoder->ResetData();

		this->flexrayCoder->SetListener((groundFilter_T*)this);

		this->flexrayCoder->ActivePDUEvents(this->id.PSD_04.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PSD_05.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PSD_06.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ACC_06.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ACC_07.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ACC_12.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ACC_16.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Blinkmodi_02.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.BV2_Linien_Ego_Doppel.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.BV2_Linien_Ego_Links.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.BV2_Linien_Ego_Rechts.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.BV2_Linien_Nebenspuren.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Charisma_03.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Charisma_08.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EM1_HYB_06.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EM1_HYB_12.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EM1_HYB_14.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EM2_HYB_06.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EM2_HYB_12.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EML_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EML_03.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.EML_04.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ESP_05.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ESP_21.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.ESP_22.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Fahrwerk_07.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Getriebe_11.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Getriebe_13.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Getriebe_17.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.GRA_ACC_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.HAL_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Kombi_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Kombi_02.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.LWI_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_04.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_07.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_11.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_12.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_14.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_16.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_18.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_20.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_27.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_28.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_Code_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.Motor_Hybrid_03.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.NavPos_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PACC_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PACC_02.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PACC02_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PACC02_02.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PACC02_03.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PIDM_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.pVS_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.SARA_11.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.SDF1_Objekt_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.SDF1_Objekt_04.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.SDF2_Pos_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.TSK_06.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.TSK_08.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.VZE_01.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.VZE_02.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.VZE_03.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.DEV_BVS_02.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.DEV_BVS_03.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.DEV_BVS_04.pdu);
	}
	else {
		/* Wir ben�tigen die PDU-IDs f�r die Verarbeitung von CAN-PSD */
		this->id.PSD_04.pdu = 1122;
		this->id.PSD_05.pdu = 1123;
		this->id.PSD_06.pdu = 1124;
	}

	this->canPSDReceived	= false;


	WCHAR	fileName[1024];
	swprintf_s(fileName, L"%S", this->GetPropertyStr("rpl2File"));

	WCHAR	folderName[1024];
	swprintf_s(folderName, L"%s", fileName);

	*PathFindFileName(folderName) = L'\0';
	if(wcslen(folderName) > 0) {
		CreateDirectory(folderName, NULL);
	}


	if(!this->rpl2File.OpenExport(fileName)) {
		LOG_ERROR("Failed to open file");
		return false;
	}


	return true;
}


void	rpl2Recorder_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}


	if(!this->rpl2File.CloseExport()) {
		LOG_ERROR("Failed to finalize replay file");
	}
}


void	rpl2Recorder_T::OnReceive(void)
{
	if(this->inputPin_flexray->Unflag()) {
		if(this->flexrayCoder) {
			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
									  (tInt)this->GetInputPin("flexray")->GetDataSize(),
											this->GetInputPin("flexray")->GetTimeStamp());
		}
	}


	if(this->inputPin_canPSD->Unflag()) {
		/* CAN-Nachrichten k�nnen direkt verarbeitet werden */
		if(sizeof(canMessage_T) == this->GetInputPin("canPSD")->GetDataSize()) {
			uint32_T	id = 0;
			canMessage_T *message = (canMessage_T*)this->GetInputPin("canPSD")->GetDataPtr();

			if(message->id == 1122) { id = this->id.PSD_04.pdu; }
			if(message->id == 1123) { id = this->id.PSD_05.pdu; }
			if(message->id == 1124) { id = this->id.PSD_06.pdu; }

			if(id != 0) {
				this->canPSDReceived = true;

				this->Process_PSD(id, message->data, _clock->GetStreamTime());
			}
		}
	}


	if(this->inputPin_pemControl->Unflag()) {
		rpl2File_T::controlData_T	sample;

		sample.time			 = (real32_T)_clock->GetStreamTime() / 1000000.0f;
		sample.pemControl	= *((pemControl_T*)this->inputPin_pemControl->GetDataPtr());

		this->rpl2File.PushControlData(sample);
	}


	if(this->inputPin_pemPlanning->Unflag()) {
		rpl2File_T::strategyData_T	sample;

		sample.time			= (real32_T)_clock->GetStreamTime() / 1000000.0f;
		sample.pemPlanning	= *((pemPlanning_T*)this->inputPin_pemPlanning->GetDataPtr());

		this->rpl2File.PushStrategyData(sample);
	}


	if(this->inputPin_evaluatedScenes->Unflag()) {
		tstring scene((const wchar_t*)this->inputPin_evaluatedScenes->GetDataPtr());

		this->rpl2File.PushScene(scene);
	}
}


void	rpl2Recorder_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }


		/* PSD */
		if(coderEvent->nPDUID == this->id.PSD_04.pdu ||
		   coderEvent->nPDUID == this->id.PSD_05.pdu ||
		   coderEvent->nPDUID == this->id.PSD_06.pdu) {
			if(coderEvent->nPayloadLength == 8) {
				if(!this->canPSDReceived) {
					this->Process_PSD(coderEvent->nPDUID, coderEvent->pData, _clock->GetStreamTime());
				}
			}
		}


		/* ACC_06 */
		if(coderEvent->nPDUID == this->id.ACC_06.pdu) {
			rpl2File_T::ACC_06_T	sample;

			adtf_devicetb::tSignalValue	ACC_zul_Regelabw_unten;
			adtf_devicetb::tSignalValue	ACC_Sollbeschleunigung_02;
			adtf_devicetb::tSignalValue	ACC_zul_Regelabw_oben;
			adtf_devicetb::tSignalValue	ACC_neg_Sollbeschl_Grad_02;
			adtf_devicetb::tSignalValue	ACC_pos_Sollbeschl_Grad_02;
			adtf_devicetb::tSignalValue	ACC_Status_ACC;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_06.ACC_zul_Regelabw_unten,		&ACC_zul_Regelabw_unten));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_06.ACC_Sollbeschleunigung_02,	&ACC_Sollbeschleunigung_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_06.ACC_zul_Regelabw_oben,		&ACC_zul_Regelabw_oben));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_06.ACC_neg_Sollbeschl_Grad_02,	&ACC_neg_Sollbeschl_Grad_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_06.ACC_pos_Sollbeschl_Grad_02,	&ACC_pos_Sollbeschl_Grad_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_06.ACC_Status_ACC,				&ACC_Status_ACC));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ACC_zul_Regelabw_unten		= (real32_T)ACC_zul_Regelabw_unten.nf64Value;
			sample.ACC_Sollbeschleunigung_02	= (real32_T)ACC_Sollbeschleunigung_02.nf64Value;
			sample.ACC_zul_Regelabw_oben		= (real32_T)ACC_zul_Regelabw_oben.nf64Value;
			sample.ACC_neg_Sollbeschl_Grad_02	= (real32_T)ACC_neg_Sollbeschl_Grad_02.nf64Value;
			sample.ACC_pos_Sollbeschl_Grad_02	= (real32_T)ACC_pos_Sollbeschl_Grad_02.nf64Value;
			sample.ACC_Status_ACC				= (uint8_T) ACC_Status_ACC.nRawValue;

			if(valid) {
				this->rpl2File.PushACC_06(sample);
			}
		}


		/* ACC_07 */
		if (coderEvent->nPDUID == this->id.ACC_07.pdu) {
			rpl2File_T::ACC_07_T	sample;

			adtf_devicetb::tSignalValue	ACC_Folgebeschl;
			adtf_devicetb::tSignalValue	ACC_Freilauf_Info;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_07.ACC_Folgebeschl,		&ACC_Folgebeschl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_07.ACC_Freilauf_Info,	&ACC_Freilauf_Info));

			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ACC_Folgebeschl = (real32_T)ACC_Folgebeschl.nf64Value;
			sample.ACC_Freilauf_Info = (uint8_T)ACC_Freilauf_Info.nRawValue;

			if (valid) {
				this->rpl2File.PushACC_07(sample);
			}
		}


		/* ACC_12 */
		if(coderEvent->nPDUID == this->id.ACC_12.pdu) {
			rpl2File_T::ACC_12_T	sample;

			adtf_devicetb::tSignalValue	ACC_Gesetzte_Zeitluecke;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_12.ACC_Gesetzte_Zeitluecke,		&ACC_Gesetzte_Zeitluecke));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ACC_Gesetzte_Zeitluecke		= (uint8_T) ACC_Gesetzte_Zeitluecke.nRawValue;

			if(valid) {
				this->rpl2File.PushACC_12(sample);
			}
		}


		/* ACC_16 */
		if(coderEvent->nPDUID == this->id.ACC_16.pdu) {
			rpl2File_T::ACC_16_T	sample;

			adtf_devicetb::tSignalValue	ACC_Fahrprogramm_PACC;
			adtf_devicetb::tSignalValue	ACC_Nutzung_VZ_PACC;
			adtf_devicetb::tSignalValue	ACC_Regelung_durch_PACC;
			adtf_devicetb::tSignalValue	ACC_Sensibilitaet_PACC;
			adtf_devicetb::tSignalValue	ACC_vLimit1_PACC;
			adtf_devicetb::tSignalValue	ACC_Offset_Default_PACC;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_16.ACC_Fahrprogramm_PACC,		&ACC_Fahrprogramm_PACC));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_16.ACC_Nutzung_VZ_PACC,			&ACC_Nutzung_VZ_PACC));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_16.ACC_Regelung_durch_PACC,		&ACC_Regelung_durch_PACC));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_16.ACC_Sensibilitaet_PACC,		&ACC_Sensibilitaet_PACC));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_16.ACC_vLimit1_PACC,				&ACC_vLimit1_PACC));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ACC_16.ACC_Offset_Default_PACC,		&ACC_Offset_Default_PACC));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ACC_Fahrprogramm_PACC	= (int16_T) ACC_Fahrprogramm_PACC.nRawValue;
			sample.ACC_Nutzung_VZ_PACC		= (uint8_T) ACC_Nutzung_VZ_PACC.nRawValue;
			sample.ACC_Regelung_durch_PACC	= (uint8_T) ACC_Regelung_durch_PACC.nRawValue;
			sample.ACC_Sensibilitaet_PACC	= (uint8_T)ACC_Sensibilitaet_PACC.nRawValue;
			sample.ACC_vLimit1_PACC			= (uint8_T)ACC_vLimit1_PACC.nRawValue;
			sample.ACC_Offset_Default_PACC	= (int8_T)ACC_Offset_Default_PACC.nRawValue;

			if(valid) {
				this->rpl2File.PushACC_16(sample);
			}
		}


		/* Blinkmodi_02 */
		if(coderEvent->nPDUID == this->id.Blinkmodi_02.pdu) {
			rpl2File_T::Blinkmodi_02_T	sample;

			adtf_devicetb::tSignalValue	BM_links;
			adtf_devicetb::tSignalValue	BM_rechts;
			adtf_devicetb::tSignalValue	BM_Autobahn;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Blinkmodi_02.BM_links,				&BM_links));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Blinkmodi_02.BM_rechts	,			&BM_rechts));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Blinkmodi_02.BM_Autobahn,			&BM_Autobahn));

			sample.time			= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.BM_links		= (bool_T)BM_links.nRawValue;
			sample.BM_rechts	= (bool_T)BM_rechts.nRawValue;
			sample.BM_Autobahn	= (bool_T)BM_Autobahn.nRawValue;

			if(valid) {
				this->rpl2File.PushBlinkmodi_02(sample);
			}
		}


		/* BV2_Linien_Ego_Doppel */
		if(coderEvent->nPDUID == this->id.BV2_Linien_Ego_Doppel.pdu) {
			rpl2File_T::BV2_Linien_Ego_Doppel_T	sample;

			adtf_devicetb::tSignalValue	BV1_LIN_05_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_05_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_05_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_05_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_05_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_05_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_05_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_05_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_05_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_05_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_05_Breite;
			adtf_devicetb::tSignalValue	BV1_LIN_05_Typ;
			adtf_devicetb::tSignalValue	BV1_LIN_05_Hoehe;
			adtf_devicetb::tSignalValue	BV1_LIN_05_Farbe;
			adtf_devicetb::tSignalValue	BV1_LIN_06_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_06_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_06_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_06_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_06_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_06_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_06_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_06_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_06_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_06_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_06_Breite;
			adtf_devicetb::tSignalValue	BV1_LIN_06_Typ;
			adtf_devicetb::tSignalValue	BV1_LIN_06_Hoehe;
			adtf_devicetb::tSignalValue	BV1_LIN_06_Farbe;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_BeginnX,			&BV1_LIN_05_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_VorgaengerID,		&BV1_LIN_05_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_ID,					&BV1_LIN_05_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_AbstandY,			&BV1_LIN_05_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_GierWnkl,			&BV1_LIN_05_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_HorKruemm,			&BV1_LIN_05_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_HorKruemmAend,		&BV1_LIN_05_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_ExistMass,			&BV1_LIN_05_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_NachfolgerID,		&BV1_LIN_05_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_EndeX,				&BV1_LIN_05_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Breite,				&BV1_LIN_05_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Typ,				&BV1_LIN_05_Typ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Hoehe,				&BV1_LIN_05_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_05_Farbe,				&BV1_LIN_05_Farbe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_BeginnX,			&BV1_LIN_06_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_VorgaengerID,		&BV1_LIN_06_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_ID,					&BV1_LIN_06_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_AbstandY,			&BV1_LIN_06_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_GierWnkl,			&BV1_LIN_06_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_HorKruemm,			&BV1_LIN_06_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_HorKruemmAend,		&BV1_LIN_06_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_ExistMass,			&BV1_LIN_06_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_NachfolgerID,		&BV1_LIN_06_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_EndeX,				&BV1_LIN_06_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Breite,				&BV1_LIN_06_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Typ,				&BV1_LIN_06_Typ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Hoehe,				&BV1_LIN_06_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Doppel.BV1_LIN_06_Farbe,				&BV1_LIN_06_Farbe));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.BV1_LIN_05_BeginnX		= (real32_T)BV1_LIN_05_BeginnX.nf64Value;
			sample.BV1_LIN_05_VorgaengerID	= (uint8_T)	BV1_LIN_05_VorgaengerID.nRawValue;
			sample.BV1_LIN_05_ID			= (uint8_T)	BV1_LIN_05_ID.nRawValue;
			sample.BV1_LIN_05_AbstandY		= (real32_T)BV1_LIN_05_AbstandY.nf64Value;
			sample.BV1_LIN_05_GierWnkl		= (real32_T)BV1_LIN_05_GierWnkl.nf64Value;
			sample.BV1_LIN_05_HorKruemm		= (real32_T)BV1_LIN_05_HorKruemm.nf64Value;
			sample.BV1_LIN_05_HorKruemmAend	= (real32_T)BV1_LIN_05_HorKruemmAend.nf64Value;
			sample.BV1_LIN_05_ExistMass		= (real32_T)BV1_LIN_05_ExistMass.nf64Value;
			sample.BV1_LIN_05_NachfolgerID	= (uint8_T)	BV1_LIN_05_NachfolgerID.nRawValue;
			sample.BV1_LIN_05_EndeX			= (real32_T)BV1_LIN_05_EndeX.nf64Value;
			sample.BV1_LIN_05_Breite		= (real32_T)BV1_LIN_05_Breite.nf64Value;
			sample.BV1_LIN_05_Typ			= (uint8_T)	BV1_LIN_05_Typ.nRawValue;
			sample.BV1_LIN_05_Hoehe			= (real32_T)BV1_LIN_05_Hoehe.nf64Value;
			sample.BV1_LIN_05_Farbe			= (uint8_T)	BV1_LIN_05_Farbe.nRawValue;
			sample.BV1_LIN_06_BeginnX		= (real32_T)BV1_LIN_06_BeginnX.nf64Value;
			sample.BV1_LIN_06_VorgaengerID	= (uint8_T)	BV1_LIN_06_VorgaengerID.nRawValue;
			sample.BV1_LIN_06_ID			= (uint8_T)	BV1_LIN_06_ID.nRawValue;
			sample.BV1_LIN_06_AbstandY		= (real32_T)BV1_LIN_06_AbstandY.nf64Value;
			sample.BV1_LIN_06_GierWnkl		= (real32_T)BV1_LIN_06_GierWnkl.nf64Value;
			sample.BV1_LIN_06_HorKruemm		= (real32_T)BV1_LIN_06_HorKruemm.nf64Value;
			sample.BV1_LIN_06_HorKruemmAend	= (real32_T)BV1_LIN_06_HorKruemmAend.nf64Value;
			sample.BV1_LIN_06_ExistMass		= (real32_T)BV1_LIN_06_ExistMass.nf64Value;
			sample.BV1_LIN_06_NachfolgerID	= (uint8_T)	BV1_LIN_06_NachfolgerID.nRawValue;
			sample.BV1_LIN_06_EndeX			= (real32_T)BV1_LIN_06_EndeX.nf64Value;
			sample.BV1_LIN_06_Breite		= (real32_T)BV1_LIN_06_Breite.nf64Value;
			sample.BV1_LIN_06_Typ			= (uint8_T)	BV1_LIN_06_Typ.nRawValue;
			sample.BV1_LIN_06_Hoehe			= (real32_T)BV1_LIN_06_Hoehe.nf64Value;
			sample.BV1_LIN_06_Farbe			= (uint8_T)	BV1_LIN_06_Farbe.nRawValue;

			if(valid) {
				this->rpl2File.PushBV2_Linien_Ego_Doppel(sample);
			}
		}


		/* BV2_Linien_Ego_Links */
		if(coderEvent->nPDUID == this->id.BV2_Linien_Ego_Links.pdu) {
			rpl2File_T::BV2_Linien_Ego_Links_T	sample;

			adtf_devicetb::tSignalValue	BV1_LIN_01_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_01_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_01_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_01_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_01_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_01_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_01_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_01_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_01_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_01_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_01_Breite;
			adtf_devicetb::tSignalValue	BV1_LIN_01_Typ;
			adtf_devicetb::tSignalValue	BV1_LIN_01_Hoehe;
			adtf_devicetb::tSignalValue	BV1_LIN_01_Farbe;
			adtf_devicetb::tSignalValue	BV1_LIN_01_Seg01_StdA_E;
			adtf_devicetb::tSignalValue	BV1_LIN_01_Seg01_StdA_M;
			adtf_devicetb::tSignalValue	BV1_LIN_07_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_07_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_07_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_07_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_07_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_07_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_07_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_07_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_07_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_07_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_07_Seg02_StdA_A;
			adtf_devicetb::tSignalValue	BV1_LIN_07_Seg02_StdA_E;
			adtf_devicetb::tSignalValue	BV1_LIN_07_Seg02_StdA_M;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_BeginnX,				&BV1_LIN_01_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_VorgaengerID,		&BV1_LIN_01_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_ID,					&BV1_LIN_01_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_AbstandY,			&BV1_LIN_01_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_GierWnkl,			&BV1_LIN_01_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_HorKruemm,			&BV1_LIN_01_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_HorKruemmAend,		&BV1_LIN_01_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_ExistMass,			&BV1_LIN_01_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_NachfolgerID,		&BV1_LIN_01_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_EndeX,				&BV1_LIN_01_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Breite,				&BV1_LIN_01_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Typ,					&BV1_LIN_01_Typ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Hoehe,				&BV1_LIN_01_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Farbe,				&BV1_LIN_01_Farbe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Seg01_StdA_E,		&BV1_LIN_01_Seg01_StdA_E));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_01_Seg01_StdA_M,		&BV1_LIN_01_Seg01_StdA_M));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_BeginnX,				&BV1_LIN_07_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_VorgaengerID,		&BV1_LIN_07_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_ID,					&BV1_LIN_07_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_AbstandY,			&BV1_LIN_07_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_GierWnkl,			&BV1_LIN_07_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_HorKruemm,			&BV1_LIN_07_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_HorKruemmAend,		&BV1_LIN_07_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_ExistMass,			&BV1_LIN_07_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_NachfolgerID,		&BV1_LIN_07_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_EndeX,				&BV1_LIN_07_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_Seg02_StdA_A,		&BV1_LIN_07_Seg02_StdA_A));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_Seg02_StdA_E,		&BV1_LIN_07_Seg02_StdA_E));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Links.BV1_LIN_07_Seg02_StdA_M,		&BV1_LIN_07_Seg02_StdA_M));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.BV1_LIN_01_BeginnX		= (real32_T)BV1_LIN_01_BeginnX.nf64Value;
			sample.BV1_LIN_01_VorgaengerID	= (uint8_T) BV1_LIN_01_VorgaengerID.nRawValue;
			sample.BV1_LIN_01_ID			= (uint8_T) BV1_LIN_01_ID.nRawValue;
			sample.BV1_LIN_01_AbstandY		= (real32_T)BV1_LIN_01_AbstandY.nf64Value;
			sample.BV1_LIN_01_GierWnkl		= (real32_T)BV1_LIN_01_GierWnkl.nf64Value;
			sample.BV1_LIN_01_HorKruemm		= (real32_T)BV1_LIN_01_HorKruemm.nf64Value;
			sample.BV1_LIN_01_HorKruemmAend	= (real32_T)BV1_LIN_01_HorKruemmAend.nf64Value;
			sample.BV1_LIN_01_ExistMass		= (real32_T)BV1_LIN_01_ExistMass.nf64Value;
			sample.BV1_LIN_01_NachfolgerID	= (uint8_T)	BV1_LIN_01_NachfolgerID.nRawValue;
			sample.BV1_LIN_01_EndeX			= (real32_T)BV1_LIN_01_EndeX.nf64Value;
			sample.BV1_LIN_01_Breite		= (real32_T)BV1_LIN_01_Breite.nf64Value;
			sample.BV1_LIN_01_Typ			= (uint8_T)	BV1_LIN_01_Typ.nRawValue;
			sample.BV1_LIN_01_Hoehe			= (real32_T)BV1_LIN_01_Hoehe.nf64Value;
			sample.BV1_LIN_01_Farbe			= (uint8_T)	BV1_LIN_01_Farbe.nRawValue;
			sample.BV1_LIN_01_Seg01_StdA_E	= (real32_T)BV1_LIN_01_Seg01_StdA_E.nf64Value;
			sample.BV1_LIN_01_Seg01_StdA_M	= (real32_T)BV1_LIN_01_Seg01_StdA_M.nf64Value;
			sample.BV1_LIN_07_BeginnX		= (real32_T)BV1_LIN_07_BeginnX.nf64Value;
			sample.BV1_LIN_07_VorgaengerID	= (uint8_T)	BV1_LIN_07_VorgaengerID.nRawValue;
			sample.BV1_LIN_07_ID			= (uint8_T)	BV1_LIN_07_ID.nRawValue;
			sample.BV1_LIN_07_AbstandY		= (real32_T)BV1_LIN_07_AbstandY.nf64Value;
			sample.BV1_LIN_07_GierWnkl		= (real32_T)BV1_LIN_07_GierWnkl.nf64Value;
			sample.BV1_LIN_07_HorKruemm		= (real32_T)BV1_LIN_07_HorKruemm.nf64Value;
			sample.BV1_LIN_07_HorKruemmAend	= (real32_T)BV1_LIN_07_HorKruemmAend.nf64Value;
			sample.BV1_LIN_07_ExistMass		= (real32_T)BV1_LIN_07_ExistMass.nf64Value;
			sample.BV1_LIN_07_NachfolgerID	= (uint8_T)	BV1_LIN_07_NachfolgerID.nRawValue;
			sample.BV1_LIN_07_EndeX			= (real32_T)BV1_LIN_07_EndeX.nf64Value;
			sample.BV1_LIN_07_Seg02_StdA_A	= (real32_T)BV1_LIN_07_Seg02_StdA_A.nf64Value;
			sample.BV1_LIN_07_Seg02_StdA_E	= (real32_T)BV1_LIN_07_Seg02_StdA_E.nf64Value;
			sample.BV1_LIN_07_Seg02_StdA_M	= (real32_T)BV1_LIN_07_Seg02_StdA_M.nf64Value;

			if(valid) {
				this->rpl2File.PushBV2_Linien_Ego_Links(sample);
			}
		}


		/* BV2_Linien_Ego_Rechts */
		if(coderEvent->nPDUID == this->id.BV2_Linien_Ego_Rechts.pdu) {
			rpl2File_T::BV2_Linien_Ego_Rechts_T	sample;

			adtf_devicetb::tSignalValue	BV1_LIN_02_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_02_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_02_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_02_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_02_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_02_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_02_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_02_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_02_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_02_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_02_Breite;
			adtf_devicetb::tSignalValue	BV1_LIN_02_Typ;
			adtf_devicetb::tSignalValue	BV1_LIN_02_Hoehe;
			adtf_devicetb::tSignalValue	BV1_LIN_02_Farbe;
			adtf_devicetb::tSignalValue	BV1_LIN_02_Seg02_StdA_E;
			adtf_devicetb::tSignalValue	BV1_LIN_02_Seg02_StdA_M;
			adtf_devicetb::tSignalValue	BV1_LIN_08_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_08_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_08_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_08_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_08_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_08_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_08_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_08_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_08_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_08_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_08_Seg02_StdA_A;
			adtf_devicetb::tSignalValue	BV1_LIN_08_Seg02_StdA_E;
			adtf_devicetb::tSignalValue	BV1_LIN_08_Seg02_StdA_M;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_BeginnX,			&BV1_LIN_02_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_VorgaengerID,		&BV1_LIN_02_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_ID,					&BV1_LIN_02_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_AbstandY,			&BV1_LIN_02_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_GierWnkl,			&BV1_LIN_02_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_HorKruemm,			&BV1_LIN_02_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_HorKruemmAend,		&BV1_LIN_02_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_ExistMass,			&BV1_LIN_02_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_NachfolgerID,		&BV1_LIN_02_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_EndeX,				&BV1_LIN_02_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Breite,				&BV1_LIN_02_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Typ,				&BV1_LIN_02_Typ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Hoehe,				&BV1_LIN_02_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Farbe,				&BV1_LIN_02_Farbe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Seg01_StdA_E,		&BV1_LIN_02_Seg02_StdA_E));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_02_Seg01_StdA_M,		&BV1_LIN_02_Seg02_StdA_M));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_BeginnX,			&BV1_LIN_08_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_VorgaengerID,		&BV1_LIN_08_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_ID,					&BV1_LIN_08_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_AbstandY,			&BV1_LIN_08_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_GierWnkl,			&BV1_LIN_08_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_HorKruemm,			&BV1_LIN_08_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_HorKruemmAend,		&BV1_LIN_08_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_ExistMass,			&BV1_LIN_08_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_NachfolgerID,		&BV1_LIN_08_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_EndeX,				&BV1_LIN_08_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_Seg02_StdA_A,		&BV1_LIN_08_Seg02_StdA_A));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_Seg02_StdA_E,		&BV1_LIN_08_Seg02_StdA_E));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Ego_Rechts.BV1_LIN_08_Seg02_StdA_M,		&BV1_LIN_08_Seg02_StdA_M));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.BV1_LIN_02_BeginnX		= (real32_T)BV1_LIN_02_BeginnX.nf64Value;
			sample.BV1_LIN_02_VorgaengerID	= (uint8_T) BV1_LIN_02_VorgaengerID.nRawValue;
			sample.BV1_LIN_02_ID			= (uint8_T) BV1_LIN_02_ID.nRawValue;
			sample.BV1_LIN_02_AbstandY		= (real32_T)BV1_LIN_02_AbstandY.nf64Value;
			sample.BV1_LIN_02_GierWnkl		= (real32_T)BV1_LIN_02_GierWnkl.nf64Value;
			sample.BV1_LIN_02_HorKruemm		= (real32_T)BV1_LIN_02_HorKruemm.nf64Value;
			sample.BV1_LIN_02_HorKruemmAend	= (real32_T)BV1_LIN_02_HorKruemmAend.nf64Value;
			sample.BV1_LIN_02_ExistMass		= (real32_T)BV1_LIN_02_ExistMass.nf64Value;
			sample.BV1_LIN_02_NachfolgerID	= (uint8_T)	BV1_LIN_02_NachfolgerID.nRawValue;
			sample.BV1_LIN_02_EndeX			= (real32_T)BV1_LIN_02_EndeX.nf64Value;
			sample.BV1_LIN_02_Breite		= (real32_T)BV1_LIN_02_Breite.nf64Value;
			sample.BV1_LIN_02_Typ			= (uint8_T)	BV1_LIN_02_Typ.nRawValue;
			sample.BV1_LIN_02_Hoehe			= (real32_T)BV1_LIN_02_Hoehe.nf64Value;
			sample.BV1_LIN_02_Farbe			= (uint8_T)	BV1_LIN_02_Farbe.nRawValue;
			sample.BV1_LIN_02_Seg01_StdA_E	= (real32_T)BV1_LIN_02_Seg02_StdA_E.nf64Value;
			sample.BV1_LIN_02_Seg01_StdA_M	= (real32_T)BV1_LIN_02_Seg02_StdA_M.nf64Value;
			sample.BV1_LIN_08_BeginnX		= (real32_T)BV1_LIN_08_BeginnX.nf64Value;
			sample.BV1_LIN_08_VorgaengerID	= (uint8_T)	BV1_LIN_08_VorgaengerID.nRawValue;
			sample.BV1_LIN_08_ID			= (uint8_T)	BV1_LIN_08_ID.nRawValue;
			sample.BV1_LIN_08_AbstandY		= (real32_T)BV1_LIN_08_AbstandY.nf64Value;
			sample.BV1_LIN_08_GierWnkl		= (real32_T)BV1_LIN_08_GierWnkl.nf64Value;
			sample.BV1_LIN_08_HorKruemm		= (real32_T)BV1_LIN_08_HorKruemm.nf64Value;
			sample.BV1_LIN_08_HorKruemmAend	= (real32_T)BV1_LIN_08_HorKruemmAend.nf64Value;
			sample.BV1_LIN_08_ExistMass		= (real32_T)BV1_LIN_08_ExistMass.nf64Value;
			sample.BV1_LIN_08_NachfolgerID	= (uint8_T)	BV1_LIN_08_NachfolgerID.nRawValue;
			sample.BV1_LIN_08_EndeX			= (real32_T)BV1_LIN_08_EndeX.nf64Value;
			sample.BV1_LIN_08_Seg02_StdA_A	= (real32_T)BV1_LIN_08_Seg02_StdA_A.nf64Value;
			sample.BV1_LIN_08_Seg02_StdA_E	= (real32_T)BV1_LIN_08_Seg02_StdA_E.nf64Value;
			sample.BV1_LIN_08_Seg02_StdA_M	= (real32_T)BV1_LIN_08_Seg02_StdA_M.nf64Value;

			if(valid) {
				this->rpl2File.PushBV2_Linien_Ego_Rechts(sample);
			}
		}


		/* BV2_Linien_Nebenspuren */
		if(coderEvent->nPDUID == this->id.BV2_Linien_Nebenspuren.pdu) {
			rpl2File_T::BV2_Linien_Nebenspuren_T	sample;

			adtf_devicetb::tSignalValue	BV1_LIN_03_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_03_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_03_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_03_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_03_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_03_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_03_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_03_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_03_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_03_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_03_Breite;
			adtf_devicetb::tSignalValue	BV1_LIN_03_Typ;
			adtf_devicetb::tSignalValue	BV1_LIN_03_Hoehe;
			adtf_devicetb::tSignalValue	BV1_LIN_03_Farbe;
			adtf_devicetb::tSignalValue	BV1_LIN_04_BeginnX;
			adtf_devicetb::tSignalValue	BV1_LIN_04_VorgaengerID;
			adtf_devicetb::tSignalValue	BV1_LIN_04_ID;
			adtf_devicetb::tSignalValue	BV1_LIN_04_AbstandY;
			adtf_devicetb::tSignalValue	BV1_LIN_04_GierWnkl;
			adtf_devicetb::tSignalValue	BV1_LIN_04_HorKruemm;
			adtf_devicetb::tSignalValue	BV1_LIN_04_HorKruemmAend;
			adtf_devicetb::tSignalValue	BV1_LIN_04_ExistMass;
			adtf_devicetb::tSignalValue	BV1_LIN_04_NachfolgerID;
			adtf_devicetb::tSignalValue	BV1_LIN_04_EndeX;
			adtf_devicetb::tSignalValue	BV1_LIN_04_Breite;
			adtf_devicetb::tSignalValue	BV1_LIN_04_Typ;
			adtf_devicetb::tSignalValue	BV1_LIN_04_Hoehe;
			adtf_devicetb::tSignalValue	BV1_LIN_04_Farbe;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_BeginnX,			&BV1_LIN_03_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_VorgaengerID,		&BV1_LIN_03_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_ID,				&BV1_LIN_03_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_AbstandY,			&BV1_LIN_03_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_GierWnkl,			&BV1_LIN_03_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_HorKruemm,			&BV1_LIN_03_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_HorKruemmAend,		&BV1_LIN_03_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_ExistMass,			&BV1_LIN_03_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_NachfolgerID,		&BV1_LIN_03_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_EndeX,				&BV1_LIN_03_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Breite,			&BV1_LIN_03_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Typ,				&BV1_LIN_03_Typ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Hoehe,				&BV1_LIN_03_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_03_Farbe,				&BV1_LIN_03_Farbe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_BeginnX,			&BV1_LIN_04_BeginnX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_VorgaengerID,		&BV1_LIN_04_VorgaengerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_ID,				&BV1_LIN_04_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_AbstandY,			&BV1_LIN_04_AbstandY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_GierWnkl,			&BV1_LIN_04_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_HorKruemm,			&BV1_LIN_04_HorKruemm));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_HorKruemmAend,		&BV1_LIN_04_HorKruemmAend));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_ExistMass,			&BV1_LIN_04_ExistMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_NachfolgerID,		&BV1_LIN_04_NachfolgerID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_EndeX,				&BV1_LIN_04_EndeX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Breite,			&BV1_LIN_04_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Typ,				&BV1_LIN_04_Typ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Hoehe,				&BV1_LIN_04_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.BV2_Linien_Nebenspuren.BV1_LIN_04_Farbe,				&BV1_LIN_04_Farbe));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.BV1_LIN_03_BeginnX		= (real32_T)BV1_LIN_03_BeginnX.nf64Value;
			sample.BV1_LIN_03_VorgaengerID	= (uint8_T)	BV1_LIN_03_VorgaengerID.nRawValue;
			sample.BV1_LIN_03_ID			= (uint8_T)	BV1_LIN_03_ID.nRawValue;
			sample.BV1_LIN_03_AbstandY		= (real32_T)BV1_LIN_03_AbstandY.nf64Value;
			sample.BV1_LIN_03_GierWnkl		= (real32_T)BV1_LIN_03_GierWnkl.nf64Value;
			sample.BV1_LIN_03_HorKruemm		= (real32_T)BV1_LIN_03_HorKruemm.nf64Value;
			sample.BV1_LIN_03_HorKruemmAend	= (real32_T)BV1_LIN_03_HorKruemmAend.nf64Value;
			sample.BV1_LIN_03_ExistMass		= (real32_T)BV1_LIN_03_ExistMass.nf64Value;
			sample.BV1_LIN_03_NachfolgerID	= (uint8_T)	BV1_LIN_03_NachfolgerID.nRawValue;
			sample.BV1_LIN_03_EndeX			= (real32_T)BV1_LIN_03_EndeX.nf64Value;
			sample.BV1_LIN_03_Breite		= (real32_T)BV1_LIN_03_Breite.nf64Value;
			sample.BV1_LIN_03_Typ			= (uint8_T)	BV1_LIN_03_Typ.nRawValue;
			sample.BV1_LIN_03_Hoehe			= (real32_T)BV1_LIN_03_Hoehe.nf64Value;
			sample.BV1_LIN_03_Farbe			= (uint8_T)	BV1_LIN_03_Farbe.nRawValue;
			sample.BV1_LIN_04_BeginnX		= (real32_T)BV1_LIN_04_BeginnX.nf64Value;
			sample.BV1_LIN_04_VorgaengerID	= (uint8_T)	BV1_LIN_04_VorgaengerID.nRawValue;
			sample.BV1_LIN_04_ID			= (uint8_T)	BV1_LIN_04_ID.nRawValue;
			sample.BV1_LIN_04_AbstandY		= (real32_T)BV1_LIN_04_AbstandY.nf64Value;
			sample.BV1_LIN_04_GierWnkl		= (real32_T)BV1_LIN_04_GierWnkl.nf64Value;
			sample.BV1_LIN_04_HorKruemm		= (real32_T)BV1_LIN_04_HorKruemm.nf64Value;
			sample.BV1_LIN_04_HorKruemmAend	= (real32_T)BV1_LIN_04_HorKruemmAend.nf64Value;
			sample.BV1_LIN_04_ExistMass		= (real32_T)BV1_LIN_04_ExistMass.nf64Value;
			sample.BV1_LIN_04_NachfolgerID	= (uint8_T)	BV1_LIN_04_NachfolgerID.nRawValue;
			sample.BV1_LIN_04_EndeX			= (real32_T)BV1_LIN_04_EndeX.nf64Value;
			sample.BV1_LIN_04_Breite		= (real32_T)BV1_LIN_04_Breite.nf64Value;
			sample.BV1_LIN_04_Typ			= (uint8_T)	BV1_LIN_04_Typ.nRawValue;
			sample.BV1_LIN_04_Hoehe			= (real32_T)BV1_LIN_04_Hoehe.nf64Value;
			sample.BV1_LIN_04_Farbe			= (uint8_T)	BV1_LIN_04_Farbe.nRawValue;

			if(valid) {
				this->rpl2File.PushBV2_Linien_Nebenspuren(sample);
			}
		}


		/* Charisma_03 */
		if(coderEvent->nPDUID == this->id.Charisma_03.pdu) {
			rpl2File_T::Charisma_03_T	sample;

			adtf_devicetb::tSignalValue	CHA_EV_LED;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Charisma_03.CHA_EV_LED,			&CHA_EV_LED));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.CHA_EV_LED		= (uint8_T) CHA_EV_LED.nRawValue;

			if(valid) {
				this->rpl2File.PushCharisma_03(sample);
			}
		}


		/* Charisma_08 */
		if(coderEvent->nPDUID == this->id.Charisma_08.pdu) {
			rpl2File_T::Charisma_08_T	sample;

			adtf_devicetb::tSignalValue	CHA_Ziel_FahrPr_PACC;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Charisma_08.CHA_Ziel_FahrPr_PACC,	&CHA_Ziel_FahrPr_PACC));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.CHA_Ziel_FahrPr_PACC	= (uint8_T) CHA_Ziel_FahrPr_PACC.nRawValue;

			if(valid) {
				this->rpl2File.PushCharisma_08(sample);
			}
		}


		/* EM1_HYB_06 */
		if(coderEvent->nPDUID == this->id.EM1_HYB_06.pdu) {
			rpl2File_T::EM1_HYB_06_T	sample;

			adtf_devicetb::tSignalValue	EM1_Max_Moment;
			adtf_devicetb::tSignalValue	EM1_Min_Moment;
			adtf_devicetb::tSignalValue	EM1_MaxDyn_Moment;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_06.EM1_Max_Moment,		&EM1_Max_Moment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_06.EM1_Min_Moment,		&EM1_Min_Moment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_06.EM1_MaxDyn_Moment,	&EM1_MaxDyn_Moment));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EM1_Max_Moment		= (int16_T)EM1_Max_Moment.nRawValue;
			sample.EM1_Min_Moment		= (int16_T)EM1_Min_Moment.nRawValue;
			sample.EM1_MaxDyn_Moment	= (int16_T)EM1_MaxDyn_Moment.nRawValue;

			if(valid) {
				this->rpl2File.PushEM1_HYB_06(sample);
			}
		}


		/* EM1_HYB_12 */
		if(coderEvent->nPDUID == this->id.EM1_HYB_12.pdu) {
			rpl2File_T::EM1_HYB_12_T	sample;

			adtf_devicetb::tSignalValue	EM1_IstMoment;
			adtf_devicetb::tSignalValue	EM1_IstDrehzahl;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_12.EM1_IstMoment,		&EM1_IstMoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_12.EM1_IstDrehzahl,		&EM1_IstDrehzahl));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EM1_IstMoment		= (real32_T)EM1_IstMoment.nf64Value;
			sample.EM1_IstDrehzahl		= (int16_T)EM1_IstDrehzahl.nRawValue;

			if(valid) {
				this->rpl2File.PushEM1_HYB_12(sample);
			}
		}


		/* EM1_HYB_14 */
		if (coderEvent->nPDUID == this->id.EM1_HYB_14.pdu) {
			rpl2File_T::EM1_HYB_14_T	sample;

			adtf_devicetb::tSignalValue	EM1_MaxPred_Moment;
			adtf_devicetb::tSignalValue	EM1_MaxPred_Abknickdrehzahl;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_14.EM1_MaxPred_Moment,			&EM1_MaxPred_Moment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM1_HYB_14.EM1_MaxPred_Abknickdrehzahl,	&EM1_MaxPred_Abknickdrehzahl));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EM1_MaxPred_Moment			= (int16_T)EM1_MaxPred_Moment.nRawValue;
			sample.EM1_MaxPred_Abknickdrehzahl	= (uint16_T)EM1_MaxPred_Abknickdrehzahl.nRawValue;

			if (valid) {
				this->rpl2File.PushEM1_HYB_14(sample);
			}
		}


		/* EM2_HYB_06 */
		if (coderEvent->nPDUID == this->id.EM2_HYB_06.pdu) {
			rpl2File_T::EM2_HYB_06_T	sample;

			adtf_devicetb::tSignalValue	EM2_Max_Moment;
			adtf_devicetb::tSignalValue	EM2_MaxDyn_Moment;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM2_HYB_06.EM2_Max_Moment,		&EM2_Max_Moment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM2_HYB_06.EM2_MaxDyn_Moment,	&EM2_MaxDyn_Moment));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EM2_Max_Moment		= (int16_T)EM2_Max_Moment.nRawValue;
			sample.EM2_MaxDyn_Moment	= (int16_T)EM2_MaxDyn_Moment.nRawValue;

			if (valid) {
				this->rpl2File.PushEM2_HYB_06(sample);
			}
		}


		/* EM2_HYB_12 */
		if (coderEvent->nPDUID == this->id.EM2_HYB_12.pdu) {
			rpl2File_T::EM2_HYB_12_T	sample;

			adtf_devicetb::tSignalValue	EM2_IstMoment;
			adtf_devicetb::tSignalValue	EM2_IstDrehzahl;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM2_HYB_12.EM2_IstMoment, &EM2_IstMoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EM2_HYB_12.EM2_IstDrehzahl, &EM2_IstDrehzahl));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EM2_IstMoment	= (real32_T)EM2_IstMoment.nf64Value;
			sample.EM2_IstDrehzahl	= (int16_T)EM2_IstDrehzahl.nRawValue;

			if (valid) {
				this->rpl2File.PushEM2_HYB_12(sample);
			}
		}


		/* EML_01 */
		if(coderEvent->nPDUID == this->id.EML_01.pdu) {
			rpl2File_T::EML_01_T	sample;

			adtf_devicetb::tSignalValue	EML_BeschlX;
			adtf_devicetb::tSignalValue	EML_GeschwX;
			adtf_devicetb::tSignalValue	EML_GierRate;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_01.EML_BeschlX,				&EML_BeschlX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_01.EML_GeschwX,				&EML_GeschwX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_01.EML_GierRate,				&EML_GierRate));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EML_BeschlX		= (real32_T)EML_BeschlX.nf64Value;
			sample.EML_GeschwX		= (real32_T)EML_GeschwX.nf64Value;
			sample.EML_GierRate		= (real32_T)EML_GierRate.nf64Value;

			if(valid) {
				this->rpl2File.PushEML_01(sample);
			}
		}


		/* EML_03 */
		if (coderEvent->nPDUID == this->id.EML_03.pdu) {
			rpl2File_T::EML_03_T	sample;

			adtf_devicetb::tSignalValue	EML_BeschlY;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_03.EML_BeschlY, &EML_BeschlY));

			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EML_BeschlY = (real32_T)EML_BeschlY.nf64Value;

			if (valid) {
				this->rpl2File.PushEML_03(sample);
			}
		}


		/* EML_04 */
		if(coderEvent->nPDUID == this->id.EML_04.pdu) {
			rpl2File_T::EML_04_T	sample;

			adtf_devicetb::tSignalValue	EML_Gierwinkel;
			adtf_devicetb::tSignalValue	EML_PositionX;
			adtf_devicetb::tSignalValue	EML_PositionY;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_04.EML_Gierwinkel,			&EML_Gierwinkel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_04.EML_PositionX,			&EML_PositionX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.EML_04.EML_PositionY,			&EML_PositionY));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EML_Gierwinkel	= (real32_T)EML_Gierwinkel.nf64Value;
			sample.EML_PositionX	= (real32_T)EML_PositionX.nf64Value;
			sample.EML_PositionY	= (real32_T)EML_PositionY.nf64Value;

			if(valid) {
				this->rpl2File.PushEML_04(sample);
			}
		}


		/* ESP_05 */
		if (coderEvent->nPDUID == this->id.ESP_05.pdu) {
			rpl2File_T::ESP_05_T	sample;

			adtf_devicetb::tSignalValue	ESP_Status_Bremsdruck;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_05.ESP_Status_Bremsdruck, &ESP_Status_Bremsdruck));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ESP_Status_Bremsdruck	= (bool_T)ESP_Status_Bremsdruck.nRawValue;

			if (valid) {
				this->rpl2File.PushESP_05(sample);
			}
		}


		/* ESP_21 */
		if(coderEvent->nPDUID == this->id.ESP_21.pdu) {
			rpl2File_T::ESP_21_T	sample;

			adtf_devicetb::tSignalValue	ESP_v_Signal;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_21.ESP_v_Signal,					&ESP_v_Signal));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ESP_v_Signal			= (real32_T)ESP_v_Signal.nf64Value;

			if(valid) {
				this->rpl2File.PushESP_21(sample);
			}
		}


		/* ESP_22 */
		if(coderEvent->nPDUID == this->id.ESP_22.pdu) {
			rpl2File_T::ESP_22_T	sample;

			adtf_devicetb::tSignalValue	ESP_VL_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_VR_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_HL_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_HR_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_QBit_VL_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_QBit_VR_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_QBit_HL_Bremsmoment;
			adtf_devicetb::tSignalValue	ESP_QBit_HR_Bremsmoment;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_VL_Bremsmoment,			&ESP_VL_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_VR_Bremsmoment,			&ESP_VR_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_HL_Bremsmoment,			&ESP_HL_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_HR_Bremsmoment,			&ESP_HR_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_QBit_VL_Bremsmoment,		&ESP_QBit_VL_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_QBit_VR_Bremsmoment,		&ESP_QBit_VR_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_QBit_HL_Bremsmoment,		&ESP_QBit_HL_Bremsmoment));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.ESP_22.ESP_QBit_HR_Bremsmoment,		&ESP_QBit_HR_Bremsmoment));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.ESP_VL_Bremsmoment		= (real32_T)ESP_VL_Bremsmoment.nf64Value;
			sample.ESP_VR_Bremsmoment		= (real32_T)ESP_VR_Bremsmoment.nf64Value;
			sample.ESP_HL_Bremsmoment		= (real32_T)ESP_HL_Bremsmoment.nf64Value;
			sample.ESP_HR_Bremsmoment		= (real32_T)ESP_HR_Bremsmoment.nf64Value;
			sample.ESP_QBit_VL_Bremsmoment	= (uint8_T) ESP_QBit_VL_Bremsmoment.nRawValue;
			sample.ESP_QBit_VR_Bremsmoment	= (uint8_T) ESP_QBit_VR_Bremsmoment.nRawValue;
			sample.ESP_QBit_HL_Bremsmoment	= (uint8_T) ESP_QBit_HL_Bremsmoment.nRawValue;
			sample.ESP_QBit_HR_Bremsmoment	= (uint8_T) ESP_QBit_HR_Bremsmoment.nRawValue;

			if(valid) {
				this->rpl2File.PushESP_22(sample);
			}
		}


		/* Fahrwerk_07 */
		if (coderEvent->nPDUID == this->id.Fahrwerk_07.pdu) {
			rpl2File_T::Fahrwerk_07_T	sample;

			adtf_devicetb::tSignalValue	EFP_NaesseLevel;
			adtf_devicetb::tSignalValue	EFP_NaesseLevel_Classifier;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Fahrwerk_07.EFP_NaesseLevel,				&EFP_NaesseLevel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Fahrwerk_07.EFP_NaesseLevel_Classifier,	&EFP_NaesseLevel_Classifier));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.EFP_NaesseLevel				= (uint8_T)EFP_NaesseLevel.nRawValue;
			sample.EFP_NaesseLevel_Classifier	= (uint8_T)EFP_NaesseLevel_Classifier.nRawValue;

			if (valid) {
				this->rpl2File.PushFahrwerk_07(sample);
			}
		}


		/* Getriebe_11 */
		if(coderEvent->nPDUID == this->id.Getriebe_11.pdu) {
			rpl2File_T::Getriebe_11_T	sample;

			adtf_devicetb::tSignalValue	GE_Fahrstufe;
			adtf_devicetb::tSignalValue	GE_Schaltablauf;
			adtf_devicetb::tSignalValue	GE_Status_Kraftschluss;
			adtf_devicetb::tSignalValue	GE_Zielgang;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_11.GE_Fahrstufe,			&GE_Fahrstufe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_11.GE_Schaltablauf,			&GE_Schaltablauf));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_11.GE_Status_Kraftschluss,	&GE_Status_Kraftschluss));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_11.GE_Zielgang,				&GE_Zielgang));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.GE_Fahrstufe				= (uint8_T) GE_Fahrstufe.nRawValue;
			sample.GE_Schaltablauf			= (uint8_T) GE_Schaltablauf.nRawValue;
			sample.GE_Status_Kraftschluss	= (uint8_T) GE_Status_Kraftschluss.nRawValue;
			sample.GE_Zielgang				= (uint8_T) GE_Zielgang.nRawValue;

			if(valid) {
				this->rpl2File.PushGetriebe_11(sample);
			}
		}


		/* Getriebe_13 */
		if (coderEvent->nPDUID == this->id.Getriebe_13.pdu) {
			rpl2File_T::Getriebe_13_T	sample;

			adtf_devicetb::tSignalValue	GE_Verlustmoment;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_13.GE_Verlustmoment, &GE_Verlustmoment));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.GE_Verlustmoment = (uint8_T)GE_Verlustmoment.nRawValue;

			if (valid) {
				this->rpl2File.PushGetriebe_13(sample);
			}
		}


		/* Getriebe_17 */
		if(coderEvent->nPDUID == this->id.Getriebe_17.pdu) {
			rpl2File_T::Getriebe_17_T	sample;

			adtf_devicetb::tSignalValue	GE_Freilauf_Status;
			adtf_devicetb::tSignalValue	GE_Uefkt_Praed;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_17.GE_Freilauf_Status,		&GE_Freilauf_Status));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Getriebe_17.GE_Uefkt_Praed,			&GE_Uefkt_Praed));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.GE_Freilauf_Status		= (uint8_T) GE_Freilauf_Status.nRawValue;
			sample.GE_Uefkt_Praed			= (real32_T)GE_Uefkt_Praed.nf64Value;

			if(valid) {
				this->rpl2File.PushGetriebe_17(sample);
			}
		}


		/* GRA_ACC_01 */
		if(coderEvent->nPDUID == this->id.GRA_ACC_01.pdu) {
			rpl2File_T::GRA_ACC_01_T	sample;

			adtf_devicetb::tSignalValue	GRA_Hauptschalter;
			adtf_devicetb::tSignalValue	GRA_Abbrechen;
			adtf_devicetb::tSignalValue	GRA_Limiter;
			adtf_devicetb::tSignalValue	GRA_Tip_Setzen;
			adtf_devicetb::tSignalValue	GRA_Tip_Hoch;
			adtf_devicetb::tSignalValue	GRA_Tip_Runter;
			adtf_devicetb::tSignalValue	GRA_Tip_Wiederaufnahme;
			adtf_devicetb::tSignalValue	GRA_Verstellung_Zeitluecke;
			adtf_devicetb::tSignalValue	GRA_Tip_Stufe_2;
			adtf_devicetb::tSignalValue	GRA_Typ_Bedienteil;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Hauptschalter,			&GRA_Hauptschalter));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Abbrechen,				&GRA_Abbrechen));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Limiter,					&GRA_Limiter));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Tip_Setzen,				&GRA_Tip_Setzen));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Tip_Hoch,					&GRA_Tip_Hoch));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Tip_Runter,				&GRA_Tip_Runter));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Tip_Wiederaufnahme,		&GRA_Tip_Wiederaufnahme));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Verstellung_Zeitluecke,	&GRA_Verstellung_Zeitluecke));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Tip_Stufe_2,				&GRA_Tip_Stufe_2));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.GRA_ACC_01.GRA_Typ_Bedienteil,			&GRA_Typ_Bedienteil));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.GRA_Hauptschalter			= (uint8_T) GRA_Hauptschalter.nRawValue;
			sample.GRA_Abbrechen				= (uint8_T)	GRA_Abbrechen.nRawValue;
			sample.GRA_Limiter					= (uint8_T)	GRA_Limiter.nRawValue;
			sample.GRA_Tip_Setzen				= (uint8_T)	GRA_Tip_Setzen.nRawValue;
			sample.GRA_Tip_Hoch					= (uint8_T)	GRA_Tip_Hoch.nRawValue;
			sample.GRA_Tip_Runter				= (uint8_T)	GRA_Tip_Runter.nRawValue;
			sample.GRA_Tip_Wiederaufnahme		= (uint8_T)	GRA_Tip_Wiederaufnahme.nRawValue;
			sample.GRA_Verstellung_Zeitluecke	= (uint8_T)	GRA_Verstellung_Zeitluecke.nRawValue;
			sample.GRA_Tip_Stufe_2				= (uint8_T)	GRA_Tip_Stufe_2.nRawValue;
			sample.GRA_Typ_Bedienteil			= (uint8_T)	GRA_Typ_Bedienteil.nRawValue;

			if(valid) {
				this->rpl2File.PushGRA_ACC_01(sample);
			}
		}


		/* HAL_01 */
		if(coderEvent->nPDUID == this->id.HAL_01.pdu) {
			rpl2File_T::HAL_01_T	sample;

			adtf_devicetb::tSignalValue	HAL_VZ_Radwinkel;
			adtf_devicetb::tSignalValue	HAL_QBit_Radwinkel;
			adtf_devicetb::tSignalValue	HAL_Radwinkel;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.HAL_01.HAL_VZ_Radwinkel,			&HAL_VZ_Radwinkel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.HAL_01.HAL_QBit_Radwinkel,		&HAL_QBit_Radwinkel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.HAL_01.HAL_Radwinkel,			&HAL_Radwinkel));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.HAL_VZ_Radwinkel		= (uint8_T)	HAL_VZ_Radwinkel.nRawValue;
			sample.HAL_QBit_Radwinkel	= (uint8_T)	HAL_QBit_Radwinkel.nRawValue;
			sample.HAL_Radwinkel		= (real32_T)HAL_Radwinkel.nf64Value;

			if(valid) {
				this->rpl2File.PushHAL_01(sample);
			}
		}


		/* Kombi_01 */
		if(coderEvent->nPDUID == this->id.Kombi_01.pdu) {
			rpl2File_T::Kombi_01_T	sample;

			adtf_devicetb::tSignalValue	KBI_angez_Geschw;
			adtf_devicetb::tSignalValue	KBI_Einheit_Tacho;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Kombi_01.KBI_angez_Geschw,		&KBI_angez_Geschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Kombi_01.KBI_Einheit_Tacho,		&KBI_Einheit_Tacho));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.KBI_angez_Geschw		= (real32_T)KBI_angez_Geschw.nf64Value;
			sample.KBI_Einheit_Tacho	= (uint8_T) KBI_Einheit_Tacho.nRawValue;

			if(valid) {
				this->rpl2File.PushKombi_01(sample);
			}
		}


		/* Kombi_02 */
		if(coderEvent->nPDUID == this->id.Kombi_02.pdu) {
			rpl2File_T::Kombi_02_T	sample;

			adtf_devicetb::tSignalValue	KBI_aktive_Laengsfunktion;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Kombi_02.KBI_aktive_Laengsfunktion,		&KBI_aktive_Laengsfunktion));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.KBI_aktive_Laengsfunktion	= (uint8_T) KBI_aktive_Laengsfunktion.nRawValue;

			if(valid) {
				this->rpl2File.PushKombi_02(sample);
			}
		}


		/* LWI_01 */
		if(coderEvent->nPDUID == this->id.LWI_01.pdu) {
			rpl2File_T::LWI_01_T	sample;

			adtf_devicetb::tSignalValue	LWI_Lenkradwinkel;
			adtf_devicetb::tSignalValue	LWI_Lenkradw_Geschw;
			adtf_devicetb::tSignalValue	LWI_VZ_Lenkradwinkel;
			adtf_devicetb::tSignalValue	LWI_VZ_Lenkradw_Geschw;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.LWI_01.LWI_Lenkradwinkel,			&LWI_Lenkradwinkel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.LWI_01.LWI_Lenkradw_Geschw,			&LWI_Lenkradw_Geschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.LWI_01.LWI_VZ_Lenkradwinkel,			&LWI_VZ_Lenkradwinkel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.LWI_01.LWI_VZ_Lenkradw_Geschw,		&LWI_VZ_Lenkradw_Geschw));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.LWI_Lenkradwinkel		= (real32_T)LWI_Lenkradwinkel.nf64Value;
			sample.LWI_Lenkradw_Geschw		= (uint16_T)LWI_Lenkradw_Geschw.nRawValue;
			sample.LWI_VZ_Lenkradwinkel		= (bool_T)  LWI_VZ_Lenkradwinkel.nRawValue;
			sample.LWI_VZ_Lenkradw_Geschw	= (bool_T)  LWI_VZ_Lenkradw_Geschw.nRawValue;

			if(valid) {
				this->rpl2File.PushLWI_01(sample);
			}
		}


		/* Motor_04 */
		if (coderEvent->nPDUID == this->id.Motor_04.pdu) {
			rpl2File_T::Motor_04_T	sample;

			adtf_devicetb::tSignalValue	MO_KVS;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_04.MO_KVS, &MO_KVS));

			sample.time		= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_KVS	= (uint16_T)MO_KVS.nRawValue;

			if (valid) {
				this->rpl2File.PushMotor_04(sample);
			}
		}


		/* Motor_07 */
		if (coderEvent->nPDUID == this->id.Motor_07.pdu) {
			rpl2File_T::Motor_07_T	sample;

			adtf_devicetb::tSignalValue	MO_Kuehlmittel_Temp;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_07.MO_Kuehlmittel_Temp, &MO_Kuehlmittel_Temp));

			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Kuehlmittel_Temp = (uint16_T)MO_Kuehlmittel_Temp.nf64Value;

			if (valid) {
				this->rpl2File.PushMotor_07(sample);
			}
		}


		/* Motor_11 */
		if(coderEvent->nPDUID == this->id.Motor_11.pdu) {
			rpl2File_T::Motor_11_T	sample;

			adtf_devicetb::tSignalValue	MO_Mom_Ist_Summe;
			adtf_devicetb::tSignalValue	MO_Mom_Schub;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_11.MO_Mom_Ist_Summe,			&MO_Mom_Ist_Summe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_11.MO_Mom_Schub,				&MO_Mom_Schub));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Mom_Ist_Summe		= (int16_T)MO_Mom_Ist_Summe.nRawValue;
			sample.MO_Mom_Schub			= (int16_T)MO_Mom_Schub.nRawValue;

			if(valid) {
				this->rpl2File.PushMotor_11(sample);
			}
		}


		/* Motor_12 */
		if (coderEvent->nPDUID == this->id.Motor_12.pdu) {
			rpl2File_T::Motor_12_T	sample;

			adtf_devicetb::tSignalValue	MO_Mom_Begr_stat;
			adtf_devicetb::tSignalValue	MO_Mom_Begr_dyn;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_12.MO_Mom_Begr_stat,			&MO_Mom_Begr_stat));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_12.MO_Mom_Begr_dyn,			&MO_Mom_Begr_dyn));

			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Mom_Begr_stat = (uint16_T)MO_Mom_Begr_stat.nRawValue;
			sample.MO_Mom_Begr_dyn = (int16_T)MO_Mom_Begr_dyn.nRawValue;

			if (valid) {
				this->rpl2File.PushMotor_12(sample);
			}
		}


		/* Motor_14 */
		if(coderEvent->nPDUID == this->id.Motor_14.pdu) {
			rpl2File_T::Motor_14_T	sample;

			adtf_devicetb::tSignalValue	MO_HYB_VM_aktiv;
			adtf_devicetb::tSignalValue	MO_Fahrer_bremst;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_14.MO_HYB_VM_aktiv,			&MO_HYB_VM_aktiv));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_14.MO_Fahrer_bremst,			&MO_Fahrer_bremst));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_HYB_VM_aktiv		= (uint8_T) MO_HYB_VM_aktiv.nRawValue;
			sample.MO_Fahrer_bremst		= (uint8_T)MO_Fahrer_bremst.nRawValue;

			if(valid) {
				this->rpl2File.PushMotor_14(sample);
			}
		}


		/* Motor_16 */
		if(coderEvent->nPDUID == this->id.Motor_16.pdu) {
			rpl2File_T::Motor_16_T	sample;

			adtf_devicetb::tSignalValue	TSK_Steigung_02;
			adtf_devicetb::tSignalValue	TSK_QBit_Steigung;
			adtf_devicetb::tSignalValue	TSK_QBit_Fahrzeugmasse;
			adtf_devicetb::tSignalValue	TSK_Fahrzeugmasse_02;
			adtf_devicetb::tSignalValue	TSK_Grundmasse;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_16.TSK_Steigung_02,			&TSK_Steigung_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_16.TSK_QBit_Steigung,			&TSK_QBit_Steigung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_16.TSK_QBit_Fahrzeugmasse,		&TSK_QBit_Fahrzeugmasse));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_16.TSK_Fahrzeugmasse_02,		&TSK_Fahrzeugmasse_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_16.TSK_Grundmasse,				&TSK_Grundmasse));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.TSK_Steigung_02			= (real32_T)TSK_Steigung_02.nf64Value;
			sample.TSK_QBit_Steigung		= (bool_T)	TSK_QBit_Steigung.nRawValue;
			sample.TSK_QBit_Fahrzeugmasse	= (bool_T)	TSK_QBit_Fahrzeugmasse.nRawValue;
			sample.TSK_Fahrzeugmasse_02		= (uint16_T)TSK_Fahrzeugmasse_02.nRawValue;
			sample.TSK_Grundmasse			= (uint16_T)TSK_Grundmasse.nRawValue;

			if(valid) {
				this->rpl2File.PushMotor_16(sample);
			}
		}


		/* Motor_18 */
		if(coderEvent->nPDUID == this->id.Motor_18.pdu) {
			rpl2File_T::Motor_18_T	sample;

			adtf_devicetb::tSignalValue	MO_Fahrzeugtyp;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_18.MO_Fahrzeugtyp,			&MO_Fahrzeugtyp));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Fahrzeugtyp		= (uint8_T) MO_Fahrzeugtyp.nRawValue;

			if(valid) {
				this->rpl2File.PushMotor_18(sample);
			}
		}


		/* Motor_20 */
		if(coderEvent->nPDUID == this->id.Motor_20.pdu) {
			rpl2File_T::Motor_20_T	sample;

			adtf_devicetb::tSignalValue	MO_Fahrpedalrohwert_01;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_20.MO_Fahrpedalrohwert_01,	&MO_Fahrpedalrohwert_01));

			sample.time						= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Fahrpedalrohwert_01	= (real32_T)MO_Fahrpedalrohwert_01.nf64Value;

			if(valid) {
				this->rpl2File.PushMotor_20(sample);
			}
		}


		/* Motor_27 */
		if (coderEvent->nPDUID == this->id.Motor_27.pdu) {
			rpl2File_T::Motor_27_T	sample;

			adtf_devicetb::tSignalValue	MO_Leistungsvermoegen;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_27.MO_Leistungsvermoegen, &MO_Leistungsvermoegen));

			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Leistungsvermoegen = (real32_T)MO_Leistungsvermoegen.nf64Value;

			if (valid) {
				this->rpl2File.PushMotor_27(sample);
			}
		}


		/* Motor_28 */
		if (coderEvent->nPDUID == this->id.Motor_28.pdu) {
			rpl2File_T::Motor_28_T	sample;

			adtf_devicetb::tSignalValue	MO_Drehzahl_VM;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_28.MO_Drehzahl_VM,			&MO_Drehzahl_VM));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Drehzahl_VM	= (real32_T)MO_Drehzahl_VM.nf64Value;

			if (valid) {
				this->rpl2File.PushMotor_28(sample);
			}
		}


		/* Motor_Code_01 */
		if(coderEvent->nPDUID == this->id.Motor_Code_01.pdu) {
			rpl2File_T::Motor_Code_01_T	sample;

			adtf_devicetb::tSignalValue	MO_Faktor_Momente_02;
			adtf_devicetb::tSignalValue	MO_Hybridfahrzeug;
			adtf_devicetb::tSignalValue	MO_Code;
			adtf_devicetb::tSignalValue	MO_Getriebe_Code;
			adtf_devicetb::tSignalValue	MO_Anzahl_Zyl;
			adtf_devicetb::tSignalValue	MO_Kraftstoffart;
			adtf_devicetb::tSignalValue	MO_Hubraum;
			adtf_devicetb::tSignalValue	MO_Ansaugsystem;
			adtf_devicetb::tSignalValue	MO_Leistung;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Faktor_Momente_02,		&MO_Faktor_Momente_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Hybridfahrzeug,			&MO_Hybridfahrzeug));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Code,					&MO_Code));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Getriebe_Code,			&MO_Getriebe_Code));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Anzahl_Zyl,				&MO_Anzahl_Zyl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Kraftstoffart,			&MO_Kraftstoffart));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Hubraum,				&MO_Hubraum));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Ansaugsystem,			&MO_Ansaugsystem));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Code_01.MO_Leistung,				&MO_Leistung));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.MO_Faktor_Momente_02	= (uint8_T) MO_Faktor_Momente_02.nRawValue;
			sample.MO_Hybridfahrzeug	= (uint8_T) MO_Hybridfahrzeug.nRawValue;
			sample.MO_Code				= (uint8_T) MO_Code.nRawValue;
			sample.MO_Getriebe_Code		= (uint8_T) MO_Getriebe_Code.nRawValue;
			sample.MO_Anzahl_Zyl		= (uint8_T) MO_Anzahl_Zyl.nRawValue;
			sample.MO_Kraftstoffart		= (uint8_T) MO_Kraftstoffart.nf64Value;
			sample.MO_Hubraum			= (real32_T)MO_Hubraum.nf64Value;
			sample.MO_Ansaugsystem		= (uint8_T) MO_Ansaugsystem.nRawValue;
			sample.MO_Leistung			= (real32_T)MO_Leistung.nf64Value;

			if(valid) {
				this->rpl2File.PushMotor_Code_01(sample);
			}
		}


		/* Motor_Hybrid_03 */
		if (coderEvent->nPDUID == this->id.Motor_Hybrid_03.pdu) {
			rpl2File_T::Motor_Hybrid_03_T	sample;

			adtf_devicetb::tSignalValue	Ladezustand_02;
			adtf_devicetb::tSignalValue	MO_Zust_Betriebsstrategie;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Hybrid_03.Ladezustand_02,				&Ladezustand_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.Motor_Hybrid_03.MO_Zust_Betriebsstrategie,	&MO_Zust_Betriebsstrategie));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.Ladezustand_02				= (real32_T)Ladezustand_02.nf64Value;
			sample.MO_Zust_Betriebsstrategie	= (uint8_T)MO_Zust_Betriebsstrategie.nRawValue;

			if (valid) {
				this->rpl2File.PushMotor_Hybrid_03(sample);
			}
		}


		/* NavPos_01 */
		if(coderEvent->nPDUID == this->id.NavPos_01.pdu) {
			rpl2File_T::NavPos_01_T	sample;

			adtf_devicetb::tSignalValue	NP_LatDegree;
			adtf_devicetb::tSignalValue	NP_LatDirection;
			adtf_devicetb::tSignalValue	NP_LongDegree;
			adtf_devicetb::tSignalValue	NP_LongDirection;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LatDegree,			&NP_LatDegree));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LatDirection,		&NP_LatDirection));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LongDegree,			&NP_LongDegree));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.NavPos_01.NP_LongDirection,		&NP_LongDirection));


			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.NP_LatDegree		= NP_LatDegree.nf64Value;
			sample.NP_LongDegree	= NP_LongDegree.nf64Value;
			sample.NP_LatDirection	= (bool_T)NP_LatDirection.nRawValue;
			sample.NP_LongDirection	= (bool_T)NP_LongDirection.nRawValue;

			if(valid) {
				this->rpl2File.PushNavPos_01(sample);
			}
		}


		/* PACC_01 */
		if(coderEvent->nPDUID == this->id.PACC_01.pdu) {
			rpl2File_T::PACC_01_T	sample;

			adtf_devicetb::tSignalValue	PACC_Wunschuebersetzung;
			adtf_devicetb::tSignalValue	PACC_Sollbeschleunigung;
			adtf_devicetb::tSignalValue	PACC_zul_Regelabw_oben;
			adtf_devicetb::tSignalValue	PACC_neg_Sollbeschl_Grad;
			adtf_devicetb::tSignalValue	PACC_pos_Sollbeschl_Grad;
			adtf_devicetb::tSignalValue	PACC_Ausrollmanoever;
			adtf_devicetb::tSignalValue	PACC_zul_Regelabw_unten;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_Wunschuebersetzung,			&PACC_Wunschuebersetzung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_Sollbeschleunigung,			&PACC_Sollbeschleunigung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_zul_Regelabw_oben,			&PACC_zul_Regelabw_oben));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_neg_Sollbeschl_Grad,		&PACC_neg_Sollbeschl_Grad));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_pos_Sollbeschl_Grad,		&PACC_pos_Sollbeschl_Grad));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_Ausrollmanoever,			&PACC_Ausrollmanoever));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_01.PACC_zul_Regelabw_unten,			&PACC_zul_Regelabw_unten));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.PACC_Wunschuebersetzung		= PACC_Wunschuebersetzung.nf64Value;
			sample.PACC_Sollbeschleunigung		= PACC_Sollbeschleunigung.nf64Value;
			sample.PACC_zul_Regelabw_oben		= PACC_zul_Regelabw_oben.nf64Value;
			sample.PACC_neg_Sollbeschl_Grad		= PACC_neg_Sollbeschl_Grad.nf64Value;
			sample.PACC_pos_Sollbeschl_Grad		= PACC_pos_Sollbeschl_Grad.nf64Value;
			sample.PACC_Ausrollmanoever			= (uint8_T) PACC_Ausrollmanoever.nRawValue;
			sample.PACC_zul_Regelabw_unten		= (real32_T)PACC_zul_Regelabw_unten.nf64Value;

			if(valid) {
				this->rpl2File.PushPACC_01(sample);
			}
		}


		/* PACC_02 */
		if(coderEvent->nPDUID == this->id.PACC_02.pdu) {
			rpl2File_T::PACC_02_T	sample;

			adtf_devicetb::tSignalValue	PACC_Sytemstatus_Anzeige;
			adtf_devicetb::tSignalValue	PACC_Automode;
			adtf_devicetb::tSignalValue	PACC_Segelanteil;
			adtf_devicetb::tSignalValue	PACC_Durchschnittsgeschw;
			adtf_devicetb::tSignalValue	PACC_Uebernahmeaufforderung;
			adtf_devicetb::tSignalValue	PACC_Systemstatus;
			adtf_devicetb::tSignalValue	PACC_Vorausschaugeschw;
			adtf_devicetb::tSignalValue	PACC_Offset;
			adtf_devicetb::tSignalValue	PACC_Sollgeschwindigkeit;
			adtf_devicetb::tSignalValue	PACC_naechstes_Event;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Sytemstatus_Anzeige,		&PACC_Sytemstatus_Anzeige));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Automode,					&PACC_Automode));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Segelanteil,				&PACC_Segelanteil));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Durchschnittsgeschw,		&PACC_Durchschnittsgeschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Uebernahmeaufforderung,		&PACC_Uebernahmeaufforderung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Systemstatus,				&PACC_Systemstatus));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Vorausschaugeschw,			&PACC_Vorausschaugeschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Offset,						&PACC_Offset));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_Sollgeschwindigkeit,		&PACC_Sollgeschwindigkeit));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC_02.PACC_naechstes_Event,			&PACC_naechstes_Event));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.PACC_Sytemstatus_Anzeige		= (uint8_T) PACC_Sytemstatus_Anzeige.nRawValue;
			sample.PACC_Automode				= (uint8_T) PACC_Automode.nRawValue;
			sample.PACC_Segelanteil				= PACC_Segelanteil.nf64Value;
			sample.PACC_Durchschnittsgeschw		= PACC_Durchschnittsgeschw.nf64Value;
			sample.PACC_Uebernahmeaufforderung	= (uint8_T) PACC_Uebernahmeaufforderung.nRawValue;
			sample.PACC_Systemstatus			= (uint8_T) PACC_Systemstatus.nRawValue;
			sample.PACC_Vorausschaugeschw		= PACC_Vorausschaugeschw.nf64Value;
			sample.PACC_Offset					= PACC_Offset.nf64Value;
			sample.PACC_Sollgeschwindigkeit		= PACC_Sollgeschwindigkeit.nf64Value;
			sample.PACC_naechstes_Event			= (uint8_T) PACC_naechstes_Event.nRawValue;

			if(valid) {
				this->rpl2File.PushPACC_02(sample);
			}
		}


		/* PACC02_01 */
		if(coderEvent->nPDUID == this->id.PACC02_01.pdu) {
			rpl2File_T::PACC02_01_T	sample;

			adtf_devicetb::tSignalValue	PACC02_Wunschuebersetzung;
			adtf_devicetb::tSignalValue	PACC02_Sollbeschleunigung;
			adtf_devicetb::tSignalValue	PACC02_zul_Regelabw_oben;
			adtf_devicetb::tSignalValue	PACC02_neg_Sollbeschl_Grad;
			adtf_devicetb::tSignalValue	PACC02_pos_Sollbeschl_Grad;
			adtf_devicetb::tSignalValue	PACC02_Ausrollmanoever;
			adtf_devicetb::tSignalValue	PACC02_zul_Regelabw_unten;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_Wunschuebersetzung,			&PACC02_Wunschuebersetzung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_Sollbeschleunigung,			&PACC02_Sollbeschleunigung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_zul_Regelabw_oben,			&PACC02_zul_Regelabw_oben));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_neg_Sollbeschl_Grad,		&PACC02_neg_Sollbeschl_Grad));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_pos_Sollbeschl_Grad,		&PACC02_pos_Sollbeschl_Grad));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_Ausrollmanoever,			&PACC02_Ausrollmanoever));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_01.PACC02_zul_Regelabw_unten,			&PACC02_zul_Regelabw_unten));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.PACC02_Wunschuebersetzung		= (real64_T)PACC02_Wunschuebersetzung.nf64Value;
			sample.PACC02_Sollbeschleunigung		= (real64_T)PACC02_Sollbeschleunigung.nf64Value;
			sample.PACC02_zul_Regelabw_oben			= (real64_T)PACC02_zul_Regelabw_oben.nf64Value;
			sample.PACC02_neg_Sollbeschl_Grad		= (real64_T)PACC02_neg_Sollbeschl_Grad.nf64Value;
			sample.PACC02_pos_Sollbeschl_Grad		= (real64_T)PACC02_pos_Sollbeschl_Grad.nf64Value;
			sample.PACC02_Ausrollmanoever			= (uint8_T) PACC02_Ausrollmanoever.nRawValue;
			sample.PACC02_zul_Regelabw_unten		= (real64_T)PACC02_zul_Regelabw_unten.nf64Value;

			if(valid) {
				this->rpl2File.PushPACC02_01(sample);
			}
		}


		/* PACC02_02 */
		if(coderEvent->nPDUID == this->id.PACC02_02.pdu) {
			rpl2File_T::PACC02_02_T	sample;

			adtf_devicetb::tSignalValue	PACC02_InnoDrive_Texte;
			adtf_devicetb::tSignalValue	PACC02_Systemstatus_Anzeige;
			adtf_devicetb::tSignalValue	PACC02_Automode;
			adtf_devicetb::tSignalValue	PACC02_Segelanteil;
			adtf_devicetb::tSignalValue	PACC02_Durchschnittsgeschw;
			adtf_devicetb::tSignalValue	PACC02_Uebernahmeaufforderung;
			adtf_devicetb::tSignalValue	PACC02_Systemstatus;
			adtf_devicetb::tSignalValue	PACC02_Vorausschaugeschw;
			adtf_devicetb::tSignalValue	PACC02_Offset;
			adtf_devicetb::tSignalValue	PACC02_Sollgeschwindigkeit;
			adtf_devicetb::tSignalValue	PACC02_naechstes_Event;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_InnoDrive_Texte,			&PACC02_InnoDrive_Texte));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Systemstatus_Anzeige,		&PACC02_Systemstatus_Anzeige));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Automode,					&PACC02_Automode));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Segelanteil,				&PACC02_Segelanteil));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Durchschnittsgeschw,		&PACC02_Durchschnittsgeschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Uebernahmeaufforderung,		&PACC02_Uebernahmeaufforderung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Systemstatus,				&PACC02_Systemstatus));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Vorausschaugeschw,			&PACC02_Vorausschaugeschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Offset,						&PACC02_Offset));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_Sollgeschwindigkeit,		&PACC02_Sollgeschwindigkeit));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_02.PACC02_naechstes_Event,			&PACC02_naechstes_Event));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.PACC02_InnoDrive_Texte			= (uint8_T) PACC02_InnoDrive_Texte.nRawValue;
			sample.PACC02_Systemstatus_Anzeige		= (uint8_T)	PACC02_Systemstatus_Anzeige.nRawValue;
			sample.PACC02_Automode					= (uint8_T)	PACC02_Automode.nRawValue;
			sample.PACC02_Segelanteil				= (real64_T)PACC02_Segelanteil.nf64Value;
			sample.PACC02_Durchschnittsgeschw		= (real64_T)PACC02_Durchschnittsgeschw.nf64Value;
			sample.PACC02_Uebernahmeaufforderung	= (uint8_T)	PACC02_Uebernahmeaufforderung.nRawValue;
			sample.PACC02_Systemstatus				= (uint8_T)	PACC02_Systemstatus.nRawValue;
			sample.PACC02_Vorausschaugeschw			= (real64_T)PACC02_Vorausschaugeschw.nf64Value;
			sample.PACC02_Offset					= (real64_T)PACC02_Offset.nf64Value;
			sample.PACC02_Sollgeschwindigkeit		= (real64_T)PACC02_Sollgeschwindigkeit.nf64Value;
			sample.PACC02_naechstes_Event			= (uint8_T)	PACC02_naechstes_Event.nRawValue;

			if(valid) {
				this->rpl2File.PushPACC02_02(sample);
			}
		}


		/* PACC02_03 */
		if(coderEvent->nPDUID == this->id.PACC02_03.pdu) {
			rpl2File_T::PACC02_03_T	sample;

			adtf_devicetb::tSignalValue	PACC02_Geschw_Vorausschau;
			adtf_devicetb::tSignalValue	PACC02_Event_aktiv;
			adtf_devicetb::tSignalValue	PACC02_Hinweis_Geschw;
			adtf_devicetb::tSignalValue	PACC02_Offset_aktiv;
			adtf_devicetb::tSignalValue	PACC02_Offset_Anzeige;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_03.PACC02_Geschw_Vorausschau,			&PACC02_Geschw_Vorausschau));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_03.PACC02_Event_aktiv,				&PACC02_Event_aktiv));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_03.PACC02_Hinweis_Geschw,				&PACC02_Hinweis_Geschw));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_03.PACC02_Offset_aktiv,				&PACC02_Offset_aktiv));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PACC02_03.PACC02_Offset_Anzeige,				&PACC02_Offset_Anzeige));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.PACC02_Geschw_Vorausschau		= (uint8_T) PACC02_Geschw_Vorausschau.nRawValue;
			sample.PACC02_Event_aktiv				= (uint8_T) PACC02_Event_aktiv.nRawValue;
			sample.PACC02_Hinweis_Geschw			= (uint8_T) PACC02_Hinweis_Geschw.nRawValue;
			sample.PACC02_Offset_aktiv				= (uint8_T) PACC02_Offset_aktiv.nRawValue;
			sample.PACC02_Offset_Anzeige			= (real64_T)PACC02_Offset_Anzeige.nf64Value;

			if(valid) {
				this->rpl2File.PushPACC02_03(sample);
			}
		}


		/* PIDM_01_T */
		if (coderEvent->nPDUID == this->id.PIDM_01.pdu) {
			rpl2File_T::PIDM_01_T	sample;

			adtf_devicetb::tSignalValue	PIDM_HS_Richtung;
			adtf_devicetb::tSignalValue	PIDM_HS_Attribut;
			adtf_devicetb::tSignalValue	PIDM_HS_Abstand;
			adtf_devicetb::tSignalValue	PIDM_HS_Heading;
			adtf_devicetb::tSignalValue	PIDM_HS_Index;
			adtf_devicetb::tSignalValue	PIDM_Status;
			adtf_devicetb::tSignalValue	PIDM_HS_Typnummer;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_HS_Richtung,	&PIDM_HS_Richtung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_HS_Attribut,	&PIDM_HS_Attribut));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_HS_Abstand,		&PIDM_HS_Abstand));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_HS_Heading,		&PIDM_HS_Heading));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_HS_Index,		&PIDM_HS_Index));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_Status,			&PIDM_Status));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.PIDM_01.PIDM_HS_Typnummer,	&PIDM_HS_Typnummer));

			sample.time					= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.PIDM_HS_Richtung		= (real32_T)PIDM_HS_Richtung.nf64Value;
			sample.PIDM_HS_Attribut		= (uint16_T)PIDM_HS_Attribut.nRawValue;
			sample.PIDM_HS_Abstand		= (uint16_T)PIDM_HS_Abstand.nRawValue;
			sample.PIDM_HS_Heading		= (uint16_T)PIDM_HS_Heading.nRawValue;
			sample.PIDM_HS_Index		= (uint16_T)PIDM_HS_Index.nRawValue;
			sample.PIDM_Status			= (uint8_T)PIDM_Status.nRawValue;
			sample.PIDM_HS_Typnummer	= (uint8_T)PIDM_HS_Typnummer.nRawValue;

			if (valid) {
				this->rpl2File.PushPIDM_01(sample);
			}
		}


		/* pVS_01 */
		if (coderEvent->nPDUID == this->id.pVS_01.pdu) {
			rpl2File_T::pVS_01_T	sample;

			adtf_devicetb::tSignalValue	pVS_vLimit_Range_HMI;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.pVS_01.pVS_vLimit_Range_HMI, &pVS_vLimit_Range_HMI));

			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.pVS_vLimit_Range_HMI = (real32_T)pVS_vLimit_Range_HMI.nf64Value;

			if (valid) {
				this->rpl2File.PushpVS_01(sample);
			}
		}


		/* SARA_11 */
		if(coderEvent->nPDUID == this->id.SARA_11.pdu) {
			rpl2File_T::SARA_11_T	sample;

			adtf_devicetb::tSignalValue	SARA_Accel_X_r;
			adtf_devicetb::tSignalValue	SARA_Accel_Y_r;
			adtf_devicetb::tSignalValue	SARA_Omega_Z_r;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SARA_11.SARA_Accel_X_r,			&SARA_Accel_X_r));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SARA_11.SARA_Accel_Y_r,			&SARA_Accel_Y_r));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SARA_11.SARA_Omega_Z_r,			&SARA_Omega_Z_r));

			sample.time				= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.SARA_Accel_X_r	= (real32_T)SARA_Accel_X_r.nf64Value;
			sample.SARA_Accel_Y_r	= (real32_T)SARA_Accel_Y_r.nf64Value;
			sample.SARA_Omega_Z_r	= (real32_T)SARA_Omega_Z_r.nf64Value;

			if(valid) {
				this->rpl2File.PushSARA_11(sample);
			}
		}


		/* SDF1_Objekt_01 */
		if(coderEvent->nPDUID == this->id.SDF1_Objekt_01.pdu) {
			rpl2File_T::SDF1_Objekt_01_T	sample;

			adtf_devicetb::tSignalValue	SDF1_Obj_01_ID;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Gemessen;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Historie;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_ExistenzMass;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Alter;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Klasse;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_KlassePlausib;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Bezugspunkt;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_PositionX;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_PositionXStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_PositionY;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_PositionYStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_PositionZ;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_PositionZStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_GeschwRelX;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_GeschwRelXStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_GeschwRelY;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_GeschwRelYStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_BeschlRelX;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_BeschlRelXStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_BeschlRelY;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_BeschlRelYStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Hoehe;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_HoeheStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Breite;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_BreiteStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_Laenge;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_LaengeStdA;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_GierWnkl;
			adtf_devicetb::tSignalValue	SDF1_Obj_01_GierWnklStdA;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_ID,					&SDF1_Obj_01_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Gemessen,				&SDF1_Obj_01_Gemessen));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Historie,				&SDF1_Obj_01_Historie));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_ExistenzMass,			&SDF1_Obj_01_ExistenzMass));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Alter,				&SDF1_Obj_01_Alter));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Klasse,				&SDF1_Obj_01_Klasse));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_KlassePlausib,		&SDF1_Obj_01_KlassePlausib));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Bezugspunkt,			&SDF1_Obj_01_Bezugspunkt));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionX,			&SDF1_Obj_01_PositionX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionXStdA,		&SDF1_Obj_01_PositionXStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionY,			&SDF1_Obj_01_PositionY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionYStdA,		&SDF1_Obj_01_PositionYStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionZ,			&SDF1_Obj_01_PositionZ));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_PositionZStdA,		&SDF1_Obj_01_PositionZStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelX,			&SDF1_Obj_01_GeschwRelX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelXStdA,		&SDF1_Obj_01_GeschwRelXStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelY,			&SDF1_Obj_01_GeschwRelY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_GeschwRelYStdA,		&SDF1_Obj_01_GeschwRelYStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelX,			&SDF1_Obj_01_BeschlRelX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelXStdA,		&SDF1_Obj_01_BeschlRelXStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelY,			&SDF1_Obj_01_BeschlRelY));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_BeschlRelYStdA,		&SDF1_Obj_01_BeschlRelYStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Hoehe,				&SDF1_Obj_01_Hoehe));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_HoeheStdA,			&SDF1_Obj_01_HoeheStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Breite,				&SDF1_Obj_01_Breite));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_BreiteStdA,			&SDF1_Obj_01_BreiteStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_Laenge,				&SDF1_Obj_01_Laenge));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_LaengeStdA,			&SDF1_Obj_01_LaengeStdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_GierWnkl,				&SDF1_Obj_01_GierWnkl));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_01.SDF1_Obj_01_GierWnklStdA,			&SDF1_Obj_01_GierWnklStdA));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.SDF1_Obj_01_ID				= (uint8_T) SDF1_Obj_01_ID.nRawValue;
			sample.SDF1_Obj_01_Gemessen			= (uint8_T) SDF1_Obj_01_Gemessen.nRawValue;
			sample.SDF1_Obj_01_Historie			= (bool_T)  SDF1_Obj_01_Historie.nRawValue;
			sample.SDF1_Obj_01_ExistenzMass		= (real32_T)SDF1_Obj_01_ExistenzMass.nf64Value;
			sample.SDF1_Obj_01_Alter			= (real32_T)SDF1_Obj_01_Alter.nf64Value;
			sample.SDF1_Obj_01_Klasse			= (uint8_T) SDF1_Obj_01_Klasse.nRawValue;
			sample.SDF1_Obj_01_KlassePlausib	= (real32_T)SDF1_Obj_01_KlassePlausib.nf64Value;
			sample.SDF1_Obj_01_Bezugspunkt		= (uint8_T) SDF1_Obj_01_Bezugspunkt.nRawValue;
			sample.SDF1_Obj_01_PositionX		= (real32_T)SDF1_Obj_01_PositionX.nf64Value;
			sample.SDF1_Obj_01_PositionXStdA	= (real32_T)SDF1_Obj_01_PositionXStdA.nf64Value;
			sample.SDF1_Obj_01_PositionY		= (real32_T)SDF1_Obj_01_PositionY.nf64Value;
			sample.SDF1_Obj_01_PositionYStdA	= (real32_T)SDF1_Obj_01_PositionYStdA.nf64Value;
			sample.SDF1_Obj_01_PositionZ		= (real32_T)SDF1_Obj_01_PositionZ.nf64Value;
			sample.SDF1_Obj_01_PositionZStdA	= (real32_T)SDF1_Obj_01_PositionZStdA.nf64Value;
			sample.SDF1_Obj_01_GeschwRelX		= (real32_T)SDF1_Obj_01_GeschwRelX.nf64Value;
			sample.SDF1_Obj_01_GeschwRelXStdA	= (real32_T)SDF1_Obj_01_GeschwRelXStdA.nf64Value;
			sample.SDF1_Obj_01_GeschwRelY		= (real32_T)SDF1_Obj_01_GeschwRelY.nf64Value;
			sample.SDF1_Obj_01_GeschwRelYStdA	= (real32_T)SDF1_Obj_01_GeschwRelYStdA.nf64Value;
			sample.SDF1_Obj_01_BeschlRelX		= (real32_T)SDF1_Obj_01_BeschlRelX.nf64Value;
			sample.SDF1_Obj_01_BeschlRelXStdA	= (real32_T)SDF1_Obj_01_BeschlRelXStdA.nf64Value;
			sample.SDF1_Obj_01_BeschlRelY		= (real32_T)SDF1_Obj_01_BeschlRelY.nf64Value;
			sample.SDF1_Obj_01_BeschlRelYStdA	= (real32_T)SDF1_Obj_01_BeschlRelYStdA.nf64Value;
			sample.SDF1_Obj_01_Hoehe			= (real32_T)SDF1_Obj_01_Hoehe.nf64Value;
			sample.SDF1_Obj_01_HoeheStdA		= (real32_T)SDF1_Obj_01_HoeheStdA.nf64Value;
			sample.SDF1_Obj_01_Breite			= (real32_T)SDF1_Obj_01_Breite.nf64Value;
			sample.SDF1_Obj_01_BreiteStdA		= (real32_T)SDF1_Obj_01_BreiteStdA.nf64Value;
			sample.SDF1_Obj_01_Laenge			= (real32_T)SDF1_Obj_01_Laenge.nf64Value;
			sample.SDF1_Obj_01_LaengeStdA		= (real32_T)SDF1_Obj_01_LaengeStdA.nf64Value;
			sample.SDF1_Obj_01_GierWnkl			= (real32_T)SDF1_Obj_01_GierWnkl.nf64Value;
			sample.SDF1_Obj_01_GierWnklStdA		= (real32_T)SDF1_Obj_01_GierWnklStdA.nf64Value;

			if(valid) {
				this->rpl2File.PushSDF1_Objekt_01(sample);
			}
		}


		/* SDF1_Objekt_04 */
		if (coderEvent->nPDUID == this->id.SDF1_Objekt_04.pdu) {
			rpl2File_T::SDF1_Objekt_04_T	sample;

			adtf_devicetb::tSignalValue	SDF1_Obj_04_PositionX;
			adtf_devicetb::tSignalValue	SDF1_Obj_04_GeschwRelX;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_04.SDF1_Obj_04_PositionX,	&SDF1_Obj_04_PositionX));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF1_Objekt_04.SDF1_Obj_04_GeschwRelX,	&SDF1_Obj_04_GeschwRelX));


			sample.time = (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.SDF1_Obj_04_PositionX	= (real32_T)SDF1_Obj_04_PositionX.nf64Value;
			sample.SDF1_Obj_04_GeschwRelX	= (real32_T)SDF1_Obj_04_GeschwRelX.nf64Value;

			if (valid) {
				this->rpl2File.PushSDF1_Objekt_04(sample);
			}
		}


		/* SDF2_Pos_01 */
		if(coderEvent->nPDUID == this->id.SDF2_Pos_01.pdu) {
			rpl2File_T::SDF2_Pos_01_T	sample;

			adtf_devicetb::tSignalValue	SDF2_Pos_Inhibitzeit;
			adtf_devicetb::tSignalValue	SDF2_Pos_Segment_ID;
			adtf_devicetb::tSignalValue	SDF2_Pos_Offset;
			adtf_devicetb::tSignalValue	SDF2_Pos_Standort_Eindeutig;
			adtf_devicetb::tSignalValue	SDF2_Pos_Distanz_Rampe_rechts;
			adtf_devicetb::tSignalValue	SDF2_Pos_Spurtype;
			adtf_devicetb::tSignalValue	SDF2_Pos_Distanz_Rampe_links;
			adtf_devicetb::tSignalValue	SDF2_Pos_AnzRampenRechts;
			adtf_devicetb::tSignalValue	SDF2_Pos_AnzRampenLinks;
			adtf_devicetb::tSignalValue	SDF2_Pos_Fehler_Laengsrichtung;
			adtf_devicetb::tSignalValue	SDF2_Pos_AnzHauptspuren;
			adtf_devicetb::tSignalValue	SDF2_Pos_Spurnummer;
			adtf_devicetb::tSignalValue	SDF2_Pos_GueteZuordnung;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Inhibitzeit,				&SDF2_Pos_Inhibitzeit));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Segment_ID,					&SDF2_Pos_Segment_ID));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Offset,						&SDF2_Pos_Offset));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Standort_Eindeutig,			&SDF2_Pos_Standort_Eindeutig));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Distanz_Rampe_rechts,		&SDF2_Pos_Distanz_Rampe_rechts));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Spurtype,					&SDF2_Pos_Spurtype));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Distanz_Rampe_links,		&SDF2_Pos_Distanz_Rampe_links));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_AnzRampenRechts,			&SDF2_Pos_AnzRampenRechts));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_AnzRampenLinks,				&SDF2_Pos_AnzRampenLinks));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Fehler_Laengsrichtung,		&SDF2_Pos_Fehler_Laengsrichtung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_AnzHauptspuren,				&SDF2_Pos_AnzHauptspuren));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_Spurnummer,					&SDF2_Pos_Spurnummer));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SDF2_Pos_01.SDF2_Pos_GueteZuordnung,				&SDF2_Pos_GueteZuordnung));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.SDF2_Pos_Inhibitzeit				= (real32_T)SDF2_Pos_Inhibitzeit.nf64Value;
			sample.SDF2_Pos_Segment_ID				= (uint8_T)	SDF2_Pos_Segment_ID.nRawValue;
			sample.SDF2_Pos_Offset					= (uint8_T)	SDF2_Pos_Offset.nRawValue;
			sample.SDF2_Pos_Standort_Eindeutig		= (uint8_T)	SDF2_Pos_Standort_Eindeutig.nRawValue;
			sample.SDF2_Pos_Distanz_Rampe_rechts	= (real32_T)SDF2_Pos_Distanz_Rampe_rechts.nf64Value;
			sample.SDF2_Pos_Spurtype				= (uint8_T)	SDF2_Pos_Spurtype.nRawValue;
			sample.SDF2_Pos_Distanz_Rampe_links		= (real32_T)SDF2_Pos_Distanz_Rampe_links.nf64Value;
			sample.SDF2_Pos_AnzRampenRechts			= (uint8_T)	SDF2_Pos_AnzRampenRechts.nRawValue;
			sample.SDF2_Pos_AnzRampenLinks			= (uint8_T)	SDF2_Pos_AnzRampenLinks.nRawValue;
			sample.SDF2_Pos_Fehler_Laengsrichtung	= (uint8_T)	SDF2_Pos_Fehler_Laengsrichtung.nRawValue;
			sample.SDF2_Pos_AnzHauptspuren			= (uint8_T)	SDF2_Pos_AnzHauptspuren.nRawValue;
			sample.SDF2_Pos_Spurnummer				= (uint8_T)	SDF2_Pos_Spurnummer.nRawValue;
			sample.SDF2_Pos_GueteZuordnung			= (real32_T)SDF2_Pos_GueteZuordnung.nf64Value;

			if(valid) {
				this->rpl2File.PushSDF2_Pos_01(sample);
			}
		}


		/* SpoilerSG_01 */
		if (coderEvent->nPDUID == this->id.SpoilerSG_01.pdu) {
			rpl2File_T::SpoilerSG_01_T	sample;

			adtf_devicetb::tSignalValue	SpoilerSG_HSpoiler_IstPos;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.SpoilerSG_01.SpoilerSG_HSpoiler_IstPos,	&SpoilerSG_HSpoiler_IstPos));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.SpoilerSG_HSpoiler_IstPos	= (uint16_T)SpoilerSG_HSpoiler_IstPos.nRawValue;


			if (valid) {
				this->rpl2File.PushSpoilerSG_01(sample);
			}
		}


		/* TSK_06 */
		if(coderEvent->nPDUID == this->id.TSK_06.pdu) {
			rpl2File_T::TSK_06_T	sample;

			adtf_devicetb::tSignalValue	TSK_Status;
			adtf_devicetb::tSignalValue	TSK_Hauptschalter_GRA_ACC;
			adtf_devicetb::tSignalValue	TSK_Limiter_ausgewaehlt;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.TSK_06.TSK_Status,					&TSK_Status));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.TSK_06.TSK_Hauptschalter_GRA_ACC,	&TSK_Hauptschalter_GRA_ACC));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.TSK_06.TSK_Limiter_ausgewaehlt,		&TSK_Limiter_ausgewaehlt));

			sample.time							= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.TSK_Status					= (uint8_T)TSK_Status.nRawValue;
			sample.TSK_Hauptschalter_GRA_ACC	= (uint8_T)TSK_Hauptschalter_GRA_ACC.nRawValue;
			sample.TSK_Limiter_ausgewaehlt		= (uint8_T)TSK_Limiter_ausgewaehlt.nRawValue;

			if(valid) {
				this->rpl2File.PushTSK_06(sample);
			}
		}


		/* TSK_08 */
		if(coderEvent->nPDUID == this->id.TSK_08.pdu) {
			rpl2File_T::TSK_08_T	sample;

			adtf_devicetb::tSignalValue	TSK_vMax_Fahrerassistenz;
			adtf_devicetb::tSignalValue	TSK_vMax_aktuell;
			adtf_devicetb::tSignalValue	TSK_Einheit_vMax_Fahrerassistenz;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.TSK_08.TSK_vMax_Fahrerassistenz,			&TSK_vMax_Fahrerassistenz));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.TSK_08.TSK_vMax_aktuell,					&TSK_vMax_aktuell));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.TSK_08.TSK_Einheit_vMax_Fahrerassistenz, &TSK_Einheit_vMax_Fahrerassistenz));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.TSK_vMax_Fahrerassistenz			= (real32_T)TSK_vMax_Fahrerassistenz.nRawValue;
			sample.TSK_vMax_aktuell					= (uint8_T)TSK_vMax_aktuell.nRawValue;
			sample.TSK_Einheit_vMax_Fahrerassistenz = (uint8_T)TSK_Einheit_vMax_Fahrerassistenz.nRawValue;

			if(valid) {
				this->rpl2File.PushTSK_08(sample);
			}
		}


		/* VZE_01 */
		if(coderEvent->nPDUID == this->id.VZE_01.pdu) {
			rpl2File_T::VZE_01_T	sample;

			adtf_devicetb::tSignalValue	VZE_Anzeigemodus;
			adtf_devicetb::tSignalValue	VZE_Hinweistext;
			adtf_devicetb::tSignalValue	VZE_Anzeigeunterdrueck_Zeichen_3;
			adtf_devicetb::tSignalValue	VZE_Anzeigeunterdrueck_Zeichen_2;
			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_1;
			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_2;
			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_3;
			adtf_devicetb::tSignalValue	VZE_Warnung_Verkehrszeichen_1;
			adtf_devicetb::tSignalValue	VZE_Warnung_Verkehrszeichen_2;
			adtf_devicetb::tSignalValue	VZE_Warnung_Verkehrszeichen_3;
			adtf_devicetb::tSignalValue	VZE_Zusatzschild_1;
			adtf_devicetb::tSignalValue	VZE_Zusatzschild_2;
			adtf_devicetb::tSignalValue	VZE_Zusatzschild_3;
			adtf_devicetb::tSignalValue	VZE_Anzeigeunterdrueck_Zeichen_1;
			adtf_devicetb::tSignalValue	VZE_Zeichen_01_KameraWied;
			adtf_devicetb::tSignalValue	VZE_Zeichen_02_KameraWied;
			adtf_devicetb::tSignalValue	VZE_Zeichen_03_KameraWied;
			adtf_devicetb::tSignalValue	VZE_Zeichen_01_Kamera;
			adtf_devicetb::tSignalValue	VZE_Zeichen_01_Karte;
			adtf_devicetb::tSignalValue	VZE_Zeichen_01_Gesetz;
			adtf_devicetb::tSignalValue	VZE_Zeichen_02_Kamera;
			adtf_devicetb::tSignalValue	VZE_Zeichen_02_Karte;
			adtf_devicetb::tSignalValue	VZE_Zeichen_02_Gesetz;
			adtf_devicetb::tSignalValue	VZE_Zeichen_03_Kamera;
			adtf_devicetb::tSignalValue	VZE_Zeichen_03_Karte;
			adtf_devicetb::tSignalValue	VZE_Zeichen_03_Gesetz;
			adtf_devicetb::tSignalValue	VZE_Gong;
			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_Einheit;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Anzeigemodus,						&VZE_Anzeigemodus));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Hinweistext,						&VZE_Hinweistext));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Anzeigeunterdrueck_Zeichen_3,		&VZE_Anzeigeunterdrueck_Zeichen_3));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Anzeigeunterdrueck_Zeichen_2,		&VZE_Anzeigeunterdrueck_Zeichen_2));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Verkehrszeichen_1,				&VZE_Verkehrszeichen_1));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Verkehrszeichen_2,				&VZE_Verkehrszeichen_2));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Verkehrszeichen_3,				&VZE_Verkehrszeichen_3));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Warnung_Verkehrszeichen_1,		&VZE_Warnung_Verkehrszeichen_1));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Warnung_Verkehrszeichen_2,		&VZE_Warnung_Verkehrszeichen_2));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Warnung_Verkehrszeichen_3,		&VZE_Warnung_Verkehrszeichen_3));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zusatzschild_1,					&VZE_Zusatzschild_1));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zusatzschild_2,					&VZE_Zusatzschild_2));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zusatzschild_3,					&VZE_Zusatzschild_3));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Anzeigeunterdrueck_Zeichen_1,		&VZE_Anzeigeunterdrueck_Zeichen_1));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_01_KameraWied,			&VZE_Zeichen_01_KameraWied));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_02_KameraWied,			&VZE_Zeichen_02_KameraWied));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_03_KameraWied,			&VZE_Zeichen_03_KameraWied));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_01_Kamera,				&VZE_Zeichen_01_Kamera));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_01_Karte,					&VZE_Zeichen_01_Karte));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_01_Gesetz,				&VZE_Zeichen_01_Gesetz));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_02_Kamera,				&VZE_Zeichen_02_Kamera));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_02_Karte,					&VZE_Zeichen_02_Karte));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_02_Gesetz,				&VZE_Zeichen_02_Gesetz));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_03_Kamera,				&VZE_Zeichen_03_Kamera));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_03_Karte,					&VZE_Zeichen_03_Karte));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Zeichen_03_Gesetz,				&VZE_Zeichen_03_Gesetz));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Gong,								&VZE_Gong));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_01.VZE_Verkehrszeichen_Einheit,			&VZE_Verkehrszeichen_Einheit));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.VZE_Anzeigemodus					= (uint8_T)VZE_Anzeigemodus.nRawValue;
			sample.VZE_Hinweistext					= (uint8_T)VZE_Hinweistext.nRawValue;
			sample.VZE_Anzeigeunterdrueck_Zeichen_3	= (uint8_T)VZE_Anzeigeunterdrueck_Zeichen_3.nRawValue;
			sample.VZE_Anzeigeunterdrueck_Zeichen_2	= (uint8_T)VZE_Anzeigeunterdrueck_Zeichen_2.nRawValue;
			sample.VZE_Verkehrszeichen_1			= (uint8_T)VZE_Verkehrszeichen_1.nRawValue;
			sample.VZE_Verkehrszeichen_2			= (uint8_T)VZE_Verkehrszeichen_2.nRawValue;
			sample.VZE_Verkehrszeichen_3			= (uint8_T)VZE_Verkehrszeichen_3.nRawValue;
			sample.VZE_Warnung_Verkehrszeichen_1	= (uint8_T)VZE_Warnung_Verkehrszeichen_1.nRawValue;
			sample.VZE_Warnung_Verkehrszeichen_2	= (uint8_T)VZE_Warnung_Verkehrszeichen_2.nRawValue;
			sample.VZE_Warnung_Verkehrszeichen_3	= (uint8_T)VZE_Warnung_Verkehrszeichen_3.nRawValue;
			sample.VZE_Zusatzschild_1				= (uint8_T)VZE_Zusatzschild_1.nRawValue;
			sample.VZE_Zusatzschild_2				= (uint8_T)VZE_Zusatzschild_2.nRawValue;
			sample.VZE_Zusatzschild_3				= (uint8_T)VZE_Zusatzschild_3.nRawValue;
			sample.VZE_Anzeigeunterdrueck_Zeichen_1	= (uint8_T)VZE_Anzeigeunterdrueck_Zeichen_1.nRawValue;
			sample.VZE_Zeichen_01_KameraWied		= (uint8_T)VZE_Zeichen_01_KameraWied.nRawValue;
			sample.VZE_Zeichen_02_KameraWied		= (uint8_T)VZE_Zeichen_02_KameraWied.nRawValue;
			sample.VZE_Zeichen_03_KameraWied		= (uint8_T)VZE_Zeichen_03_KameraWied.nRawValue;
			sample.VZE_Zeichen_01_Kamera			= (uint8_T)VZE_Zeichen_01_Kamera.nRawValue;
			sample.VZE_Zeichen_01_Karte				= (uint8_T)VZE_Zeichen_01_Karte.nRawValue;
			sample.VZE_Zeichen_01_Gesetz			= (uint8_T)VZE_Zeichen_01_Gesetz.nRawValue;
			sample.VZE_Zeichen_02_Kamera			= (uint8_T)VZE_Zeichen_02_Kamera.nRawValue;
			sample.VZE_Zeichen_02_Karte				= (uint8_T)VZE_Zeichen_02_Karte.nRawValue;
			sample.VZE_Zeichen_02_Gesetz			= (uint8_T)VZE_Zeichen_02_Gesetz.nRawValue;
			sample.VZE_Zeichen_03_Kamera			= (uint8_T)VZE_Zeichen_03_Kamera.nRawValue;
			sample.VZE_Zeichen_03_Karte				= (uint8_T)VZE_Zeichen_03_Karte.nRawValue;
			sample.VZE_Zeichen_03_Gesetz			= (uint8_T)VZE_Zeichen_03_Gesetz.nRawValue;
			sample.VZE_Gong							= (uint8_T)VZE_Gong.nRawValue;
			sample.VZE_Verkehrszeichen_Einheit		= (uint8_T)VZE_Verkehrszeichen_Einheit.nRawValue;

			if(valid) {
				this->rpl2File.PushVZE_01(sample);
			}
		}


		/* VZE_02 */
		if(coderEvent->nPDUID == this->id.VZE_02.pdu) {
			rpl2File_T::VZE_02_T	sample;

			adtf_devicetb::tSignalValue	VZE_Anzeigeunterdrueck_Zeichen_5;
			adtf_devicetb::tSignalValue	VZE_Zeichen_05_KameraWied;
			adtf_devicetb::tSignalValue	VZE_Zeichen_05_Kamera;
			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_4;
			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_5;
			adtf_devicetb::tSignalValue	VZE_Anhaenger_Vmax;
			adtf_devicetb::tSignalValue	VZE_Zeichen_04_Gesetz;
			adtf_devicetb::tSignalValue	VZE_Zeichen_04_Kamera;
			adtf_devicetb::tSignalValue	VZE_Zeichen_04_KameraWied;
			adtf_devicetb::tSignalValue	VZE_Zeichen_04_Karte;
			adtf_devicetb::tSignalValue	VZE_Warnung_Verkehrszeichen_4;
			adtf_devicetb::tSignalValue	VZE_Warnung_Verkehrszeichen_5;
			adtf_devicetb::tSignalValue	VZE_Zeichen_05_Gesetz;
			adtf_devicetb::tSignalValue	VZE_Zusatzschild_4;
			adtf_devicetb::tSignalValue	VZE_Zusatzschild_5;
			adtf_devicetb::tSignalValue	VZE_Baustelle;
			adtf_devicetb::tSignalValue	VZE_Zeichen_05_Karte;
			adtf_devicetb::tSignalValue	VZE_Zeichen_05_Entfernung;
			adtf_devicetb::tSignalValue	VZE_Zeichen_05_Entfernung_StdA;
			adtf_devicetb::tSignalValue	VZE_Anzeigeunterdrueck_Zeichen_4;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Anzeigeunterdrueck_Zeichen_5,			&VZE_Anzeigeunterdrueck_Zeichen_5));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_05_KameraWied,				&VZE_Zeichen_05_KameraWied));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_05_Kamera,					&VZE_Zeichen_05_Kamera));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Verkehrszeichen_4,					&VZE_Verkehrszeichen_4));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Verkehrszeichen_5,					&VZE_Verkehrszeichen_5));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Anhaenger_Vmax,						&VZE_Anhaenger_Vmax));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_04_Gesetz,					&VZE_Zeichen_04_Gesetz));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_04_Kamera,					&VZE_Zeichen_04_Kamera));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_04_KameraWied,				&VZE_Zeichen_04_KameraWied));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_04_Karte,						&VZE_Zeichen_04_Karte));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Warnung_Verkehrszeichen_4,			&VZE_Warnung_Verkehrszeichen_4));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Warnung_Verkehrszeichen_5,			&VZE_Warnung_Verkehrszeichen_5));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_05_Gesetz,					&VZE_Zeichen_05_Gesetz));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zusatzschild_4,						&VZE_Zusatzschild_4));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zusatzschild_5,						&VZE_Zusatzschild_5));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Baustelle,							&VZE_Baustelle));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_05_Karte,						&VZE_Zeichen_05_Karte));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_05_Entfernung,				&VZE_Zeichen_05_Entfernung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Zeichen_05_Entfernung_StdA,			&VZE_Zeichen_05_Entfernung_StdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_02.VZE_Anzeigeunterdrueck_Zeichen_4,			&VZE_Anzeigeunterdrueck_Zeichen_4));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.VZE_Anzeigeunterdrueck_Zeichen_5	= (uint8_T)VZE_Anzeigeunterdrueck_Zeichen_5.nRawValue;
			sample.VZE_Zeichen_05_KameraWied		= (uint8_T)VZE_Zeichen_05_KameraWied.nRawValue;
			sample.VZE_Zeichen_05_Kamera			= (uint8_T)VZE_Zeichen_05_Kamera.nRawValue;
			sample.VZE_Verkehrszeichen_4			= (uint8_T)VZE_Verkehrszeichen_4.nRawValue;
			sample.VZE_Verkehrszeichen_5			= (uint8_T)VZE_Verkehrszeichen_5.nRawValue;
			sample.VZE_Anhaenger_Vmax				= (uint8_T)VZE_Anhaenger_Vmax.nRawValue;
			sample.VZE_Zeichen_04_Gesetz			= (uint8_T)VZE_Zeichen_04_Gesetz.nRawValue;
			sample.VZE_Zeichen_04_Kamera			= (uint8_T)VZE_Zeichen_04_Kamera.nRawValue;
			sample.VZE_Zeichen_04_KameraWied		= (uint8_T)VZE_Zeichen_04_KameraWied.nRawValue;
			sample.VZE_Zeichen_04_Karte				= (uint8_T)VZE_Zeichen_04_Karte.nRawValue;
			sample.VZE_Warnung_Verkehrszeichen_4	= (uint8_T)VZE_Warnung_Verkehrszeichen_4.nRawValue;
			sample.VZE_Warnung_Verkehrszeichen_5	= (uint8_T)VZE_Warnung_Verkehrszeichen_5.nRawValue;
			sample.VZE_Zeichen_05_Gesetz			= (uint8_T)VZE_Zeichen_05_Gesetz.nRawValue;
			sample.VZE_Zusatzschild_4				= (uint8_T)VZE_Zusatzschild_4.nRawValue;
			sample.VZE_Zusatzschild_5				= (uint8_T)VZE_Zusatzschild_5.nRawValue;
			sample.VZE_Baustelle					= (uint8_T)VZE_Baustelle.nRawValue;
			sample.VZE_Zeichen_05_Karte				= (uint8_T)VZE_Zeichen_05_Karte.nRawValue;
			sample.VZE_Zeichen_05_Entfernung		= (uint8_T)VZE_Zeichen_05_Entfernung.nRawValue;
			sample.VZE_Zeichen_05_Entfernung_StdA	= (uint8_T)VZE_Zeichen_05_Entfernung_StdA.nRawValue;
			sample.VZE_Anzeigeunterdrueck_Zeichen_4	= (uint8_T)VZE_Anzeigeunterdrueck_Zeichen_4.nRawValue;

			if(valid) {
				this->rpl2File.PushVZE_02(sample);
			}
		}


		/* VZE_03 */
		if(coderEvent->nPDUID == this->id.VZE_03.pdu) {
			rpl2File_T::VZE_03_T	sample;

			adtf_devicetb::tSignalValue	VZE_Verkehrszeichen_6;
			adtf_devicetb::tSignalValue	VZE_Zusatzschild_6;
			adtf_devicetb::tSignalValue	VZE_Zeichen_06_Entfernung;
			adtf_devicetb::tSignalValue	VZE_Zeichen_06_Entfernung_StdA;
			adtf_devicetb::tSignalValue	VZE_Umweltinfo_Naesse;
			adtf_devicetb::tSignalValue	VZE_Umweltinfo_Nebel;
			adtf_devicetb::tSignalValue	VZE_Umweltinfo_Anhaengerbetrieb;
			adtf_devicetb::tSignalValue	VZE_Erweiterte_Information;
			adtf_devicetb::tSignalValue	VZE_Tempowarnung_Status;
			adtf_devicetb::tSignalValue	VZE_Tempowarnung_Einheit;
			adtf_devicetb::tSignalValue	VZE_Tempowarnung_Offset;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Verkehrszeichen_6,				&VZE_Verkehrszeichen_6));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Zusatzschild_6,					&VZE_Zusatzschild_6));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Zeichen_06_Entfernung,			&VZE_Zeichen_06_Entfernung));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Zeichen_06_Entfernung_StdA,		&VZE_Zeichen_06_Entfernung_StdA));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Umweltinfo_Naesse,				&VZE_Umweltinfo_Naesse));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Umweltinfo_Nebel,					&VZE_Umweltinfo_Nebel));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Umweltinfo_Anhaengerbetrieb,		&VZE_Umweltinfo_Anhaengerbetrieb));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Erweiterte_Information,			&VZE_Erweiterte_Information));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Tempowarnung_Status,				&VZE_Tempowarnung_Status));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Tempowarnung_Einheit,				&VZE_Tempowarnung_Einheit));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.VZE_03.VZE_Tempowarnung_Offset,				&VZE_Tempowarnung_Offset));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.VZE_Verkehrszeichen_6			= (uint8_T)VZE_Verkehrszeichen_6.nRawValue;
			sample.VZE_Zusatzschild_6				= (uint8_T)VZE_Zusatzschild_6.nRawValue;
			sample.VZE_Zeichen_06_Entfernung		= (uint8_T)VZE_Zeichen_06_Entfernung.nRawValue;
			sample.VZE_Zeichen_06_Entfernung_StdA	= (uint8_T)VZE_Zeichen_06_Entfernung_StdA.nRawValue;
			sample.VZE_Umweltinfo_Naesse			= (uint8_T)VZE_Umweltinfo_Naesse.nRawValue;
			sample.VZE_Umweltinfo_Nebel				= (uint8_T)VZE_Umweltinfo_Nebel.nRawValue;
			sample.VZE_Umweltinfo_Anhaengerbetrieb	= (uint8_T)VZE_Umweltinfo_Anhaengerbetrieb.nRawValue;
			sample.VZE_Erweiterte_Information		= (uint8_T)VZE_Erweiterte_Information.nRawValue;
			sample.VZE_Tempowarnung_Status			= (uint8_T)VZE_Tempowarnung_Status.nRawValue;
			sample.VZE_Tempowarnung_Einheit			= (uint8_T)VZE_Tempowarnung_Einheit.nRawValue;
			sample.VZE_Tempowarnung_Offset			= (uint8_T)VZE_Tempowarnung_Offset.nRawValue;

			if(valid) {
				this->rpl2File.PushVZE_03(sample);
			}
		}


		/* DEV_BVS_02 */
		if(coderEvent->nPDUID == this->id.DEV_BVS_02.pdu) {
			rpl2File_T::DEV_BVS_02_T	sample;

			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_01;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_02;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_03;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_04;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_05;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_06;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_07;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_08;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_09;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_10;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_11;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_12;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_13;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_14;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_15;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_16;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_17;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_18;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_19;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_20;
			adtf_devicetb::tSignalValue	DEV_BVS_02_Data_21;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_01,				&DEV_BVS_02_Data_01));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_02,				&DEV_BVS_02_Data_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_03,				&DEV_BVS_02_Data_03));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_04,				&DEV_BVS_02_Data_04));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_05,				&DEV_BVS_02_Data_05));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_06,				&DEV_BVS_02_Data_06));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_07,				&DEV_BVS_02_Data_07));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_08,				&DEV_BVS_02_Data_08));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_09,				&DEV_BVS_02_Data_09));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_10,				&DEV_BVS_02_Data_10));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_11,				&DEV_BVS_02_Data_11));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_12,				&DEV_BVS_02_Data_12));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_13,				&DEV_BVS_02_Data_13));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_14,				&DEV_BVS_02_Data_14));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_15,				&DEV_BVS_02_Data_15));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_16,				&DEV_BVS_02_Data_16));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_17,				&DEV_BVS_02_Data_17));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_18,				&DEV_BVS_02_Data_18));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_19,				&DEV_BVS_02_Data_19));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_20,				&DEV_BVS_02_Data_20));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_02.DEV_BVS_02_Data_21,				&DEV_BVS_02_Data_21));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.DEV_BVS_02_Data_01				= (uint32_T)DEV_BVS_02_Data_01.nRawValue;
			sample.DEV_BVS_02_Data_02				= (uint32_T)DEV_BVS_02_Data_02.nRawValue;
			sample.DEV_BVS_02_Data_03				= (uint32_T)DEV_BVS_02_Data_03.nRawValue;
			sample.DEV_BVS_02_Data_04				= (uint32_T)DEV_BVS_02_Data_04.nRawValue;
			sample.DEV_BVS_02_Data_05				= (uint32_T)DEV_BVS_02_Data_05.nRawValue;
			sample.DEV_BVS_02_Data_06				= (uint32_T)DEV_BVS_02_Data_06.nRawValue;
			sample.DEV_BVS_02_Data_07				= (uint32_T)DEV_BVS_02_Data_07.nRawValue;
			sample.DEV_BVS_02_Data_08				= (uint32_T)DEV_BVS_02_Data_08.nRawValue;
			sample.DEV_BVS_02_Data_09				= (uint32_T)DEV_BVS_02_Data_09.nRawValue;
			sample.DEV_BVS_02_Data_10				= (uint32_T)DEV_BVS_02_Data_10.nRawValue;
			sample.DEV_BVS_02_Data_11				= (uint32_T)DEV_BVS_02_Data_11.nRawValue;
			sample.DEV_BVS_02_Data_12				= (uint32_T)DEV_BVS_02_Data_12.nRawValue;
			sample.DEV_BVS_02_Data_13				= (uint32_T)DEV_BVS_02_Data_13.nRawValue;
			sample.DEV_BVS_02_Data_14				= (uint32_T)DEV_BVS_02_Data_14.nRawValue;
			sample.DEV_BVS_02_Data_15				= (uint32_T)DEV_BVS_02_Data_15.nRawValue;
			sample.DEV_BVS_02_Data_16				= (uint32_T)DEV_BVS_02_Data_16.nRawValue;
			sample.DEV_BVS_02_Data_17				= (uint32_T)DEV_BVS_02_Data_17.nRawValue;
			sample.DEV_BVS_02_Data_18				= (uint32_T)DEV_BVS_02_Data_18.nRawValue;
			sample.DEV_BVS_02_Data_19				= (uint32_T)DEV_BVS_02_Data_19.nRawValue;
			sample.DEV_BVS_02_Data_20				= (uint32_T)DEV_BVS_02_Data_20.nRawValue;
			sample.DEV_BVS_02_Data_21				= (uint32_T)DEV_BVS_02_Data_21.nRawValue;

			if(valid) {
				this->rpl2File.PushDEV_BVS_02(sample);
			}
		}


		/* DEV_BVS_03 */
		if(coderEvent->nPDUID == this->id.DEV_BVS_03.pdu) {
			rpl2File_T::DEV_BVS_03_T	sample;

			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_01;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_02;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_03;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_04;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_05;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_06;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_07;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_08;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_09;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_10;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_11;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_12;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_13;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_14;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_15;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_16;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_17;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_18;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_19;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_20;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_21;
			adtf_devicetb::tSignalValue	DEV_BVS_03_Data_22;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_01,				&DEV_BVS_03_Data_01));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_02,				&DEV_BVS_03_Data_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_03,				&DEV_BVS_03_Data_03));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_04,				&DEV_BVS_03_Data_04));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_05,				&DEV_BVS_03_Data_05));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_06,				&DEV_BVS_03_Data_06));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_07,				&DEV_BVS_03_Data_07));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_08,				&DEV_BVS_03_Data_08));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_09,				&DEV_BVS_03_Data_09));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_10,				&DEV_BVS_03_Data_10));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_11,				&DEV_BVS_03_Data_11));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_12,				&DEV_BVS_03_Data_12));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_13,				&DEV_BVS_03_Data_13));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_14,				&DEV_BVS_03_Data_14));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_15,				&DEV_BVS_03_Data_15));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_16,				&DEV_BVS_03_Data_16));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_17,				&DEV_BVS_03_Data_17));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_18,				&DEV_BVS_03_Data_18));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_19,				&DEV_BVS_03_Data_19));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_20,				&DEV_BVS_03_Data_20));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_21,				&DEV_BVS_03_Data_21));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_03.DEV_BVS_03_Data_22,				&DEV_BVS_03_Data_22));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.DEV_BVS_03_Data_01				= (uint32_T)DEV_BVS_03_Data_01.nRawValue;
			sample.DEV_BVS_03_Data_02				= (uint32_T)DEV_BVS_03_Data_02.nRawValue;
			sample.DEV_BVS_03_Data_03				= (uint32_T)DEV_BVS_03_Data_03.nRawValue;
			sample.DEV_BVS_03_Data_04				= (uint32_T)DEV_BVS_03_Data_04.nRawValue;
			sample.DEV_BVS_03_Data_05				= (uint32_T)DEV_BVS_03_Data_05.nRawValue;
			sample.DEV_BVS_03_Data_06				= (uint32_T)DEV_BVS_03_Data_06.nRawValue;
			sample.DEV_BVS_03_Data_07				= (uint32_T)DEV_BVS_03_Data_07.nRawValue;
			sample.DEV_BVS_03_Data_08				= (uint32_T)DEV_BVS_03_Data_08.nRawValue;
			sample.DEV_BVS_03_Data_09				= (uint32_T)DEV_BVS_03_Data_09.nRawValue;
			sample.DEV_BVS_03_Data_10				= (uint32_T)DEV_BVS_03_Data_10.nRawValue;
			sample.DEV_BVS_03_Data_11				= (uint32_T)DEV_BVS_03_Data_11.nRawValue;
			sample.DEV_BVS_03_Data_12				= (uint32_T)DEV_BVS_03_Data_12.nRawValue;
			sample.DEV_BVS_03_Data_13				= (uint32_T)DEV_BVS_03_Data_13.nRawValue;
			sample.DEV_BVS_03_Data_14				= (uint32_T)DEV_BVS_03_Data_14.nRawValue;
			sample.DEV_BVS_03_Data_15				= (uint32_T)DEV_BVS_03_Data_15.nRawValue;
			sample.DEV_BVS_03_Data_16				= (uint32_T)DEV_BVS_03_Data_16.nRawValue;
			sample.DEV_BVS_03_Data_17				= (uint32_T)DEV_BVS_03_Data_17.nRawValue;
			sample.DEV_BVS_03_Data_18				= (uint32_T)DEV_BVS_03_Data_18.nRawValue;
			sample.DEV_BVS_03_Data_19				= (uint32_T)DEV_BVS_03_Data_19.nRawValue;
			sample.DEV_BVS_03_Data_20				= (uint32_T)DEV_BVS_03_Data_20.nRawValue;
			sample.DEV_BVS_03_Data_21				= (uint32_T)DEV_BVS_03_Data_21.nRawValue;
			sample.DEV_BVS_03_Data_22				= (uint32_T)DEV_BVS_03_Data_22.nRawValue;

			if(valid) {
				this->rpl2File.PushDEV_BVS_03(sample);
			}
		}


		/* DEV_BVS_04 */
		if(coderEvent->nPDUID == this->id.DEV_BVS_04.pdu) {
			rpl2File_T::DEV_BVS_04_T	sample;

			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_01;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_02;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_03;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_04;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_05;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_06;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_07;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_08;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_09;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_10;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_11;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_12;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_13;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_14;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_15;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_16;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_17;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_18;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_19;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_20;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_21;
			adtf_devicetb::tSignalValue	DEV_BVS_04_Data_22;

			bool valid = true;
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_01,				&DEV_BVS_04_Data_01));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_02,				&DEV_BVS_04_Data_02));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_03,				&DEV_BVS_04_Data_03));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_04,				&DEV_BVS_04_Data_04));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_05,				&DEV_BVS_04_Data_05));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_06,				&DEV_BVS_04_Data_06));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_07,				&DEV_BVS_04_Data_07));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_08,				&DEV_BVS_04_Data_08));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_09,				&DEV_BVS_04_Data_09));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_10,				&DEV_BVS_04_Data_10));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_11,				&DEV_BVS_04_Data_11));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_12,				&DEV_BVS_04_Data_12));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_13,				&DEV_BVS_04_Data_13));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_14,				&DEV_BVS_04_Data_14));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_15,				&DEV_BVS_04_Data_15));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_16,				&DEV_BVS_04_Data_16));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_17,				&DEV_BVS_04_Data_17));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_18,				&DEV_BVS_04_Data_18));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_19,				&DEV_BVS_04_Data_19));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_20,				&DEV_BVS_04_Data_20));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_21,				&DEV_BVS_04_Data_21));
			valid &= IS_OK(this->flexrayCoder->GetSignalValue(this->id.DEV_BVS_04.DEV_BVS_04_Data_22,				&DEV_BVS_04_Data_22));

			sample.time								= (real32_T)_clock->GetStreamTime() / 1000000.0f;
			sample.DEV_BVS_04_Data_01				= (uint32_T)DEV_BVS_04_Data_01.nRawValue;
			sample.DEV_BVS_04_Data_02				= (uint32_T)DEV_BVS_04_Data_02.nRawValue;
			sample.DEV_BVS_04_Data_03				= (uint32_T)DEV_BVS_04_Data_03.nRawValue;
			sample.DEV_BVS_04_Data_04				= (uint32_T)DEV_BVS_04_Data_04.nRawValue;
			sample.DEV_BVS_04_Data_05				= (uint32_T)DEV_BVS_04_Data_05.nRawValue;
			sample.DEV_BVS_04_Data_06				= (uint32_T)DEV_BVS_04_Data_06.nRawValue;
			sample.DEV_BVS_04_Data_07				= (uint32_T)DEV_BVS_04_Data_07.nRawValue;
			sample.DEV_BVS_04_Data_08				= (uint32_T)DEV_BVS_04_Data_08.nRawValue;
			sample.DEV_BVS_04_Data_09				= (uint32_T)DEV_BVS_04_Data_09.nRawValue;
			sample.DEV_BVS_04_Data_10				= (uint32_T)DEV_BVS_04_Data_10.nRawValue;
			sample.DEV_BVS_04_Data_11				= (uint32_T)DEV_BVS_04_Data_11.nRawValue;
			sample.DEV_BVS_04_Data_12				= (uint32_T)DEV_BVS_04_Data_12.nRawValue;
			sample.DEV_BVS_04_Data_13				= (uint32_T)DEV_BVS_04_Data_13.nRawValue;
			sample.DEV_BVS_04_Data_14				= (uint32_T)DEV_BVS_04_Data_14.nRawValue;
			sample.DEV_BVS_04_Data_15				= (uint32_T)DEV_BVS_04_Data_15.nRawValue;
			sample.DEV_BVS_04_Data_16				= (uint32_T)DEV_BVS_04_Data_16.nRawValue;
			sample.DEV_BVS_04_Data_17				= (uint32_T)DEV_BVS_04_Data_17.nRawValue;
			sample.DEV_BVS_04_Data_18				= (uint32_T)DEV_BVS_04_Data_18.nRawValue;
			sample.DEV_BVS_04_Data_19				= (uint32_T)DEV_BVS_04_Data_19.nRawValue;
			sample.DEV_BVS_04_Data_20				= (uint32_T)DEV_BVS_04_Data_20.nRawValue;
			sample.DEV_BVS_04_Data_21				= (uint32_T)DEV_BVS_04_Data_21.nRawValue;
			sample.DEV_BVS_04_Data_22				= (uint32_T)DEV_BVS_04_Data_22.nRawValue;

			if(valid) {
				this->rpl2File.PushDEV_BVS_04(sample);
			}
		}
	}
}


void	rpl2Recorder_T::Process_PSD(uint32_T id, const uint8_T *data, tTimeStamp time)
{
	rpl2File_T::PSD_T sample;

	if(     id == this->id.PSD_04.pdu)	{ sample.psd.type = psdMessage4; }
	else if(id == this->id.PSD_05.pdu)	{ sample.psd.type = psdMessage5; }
	else if(id == this->id.PSD_06.pdu)	{ sample.psd.type = psdMessage6; }
	else								{ return; }


	if(psdMessage4 == sample.psd.type) {
		PsdEhr_Psd4Message_t psdMsg04;

		psdMsg04.id					= ((data[0] & 0x3F) >> 0);
		psdMsg04.parentId			= ((data[0] & 0xC0) >> 6) | ((data[1] & 0x0F) << 2);
		psdMsg04.length				= ((data[1] & 0xF0) >> 4) | ((data[2] & 0x07) << 4);
		psdMsg04.streetClass		= ((data[2] & 0x38) >> 3);
		psdMsg04.curvatureEnd		= ((data[2] & 0xC0) >> 6) | ((data[3] & 0x3F) << 2);
		psdMsg04.curvatureEndSign	= ((data[3] & 0x40) >> 6);
		psdMsg04.identity			= ((data[3] & 0x80) >> 7) | ((data[4] & 0x1F) << 1);
		psdMsg04.isADASQuality		= ((data[4] & 0x20) >> 5);
		psdMsg04.isMostProbablePath	= ((data[4] & 0x40) >> 6);
		psdMsg04.isStraightestPath	= ((data[4] & 0x80) >> 7);
		psdMsg04.lanes				= ((data[5] & 0x07) >> 0);
		psdMsg04.isBuiltUpArea		= ((data[5] & 0x08) >> 3);
		psdMsg04.completeFlag		= ((data[5] & 0x10) >> 4);
		psdMsg04.ramp				= ((data[5] & 0x60) >> 5);
		psdMsg04.curvatureStart		= ((data[5] & 0x80) >> 7) | ((data[6] & 0x7F) << 1);
		psdMsg04.curvatureStartSign	= ((data[6] & 0x80) >> 7);
		psdMsg04.branchDirection	= ((data[7] & 0x01) >> 0);
		psdMsg04.branchAngle		= ((data[7] & 0xFE) >> 1);

		sample.psd.data.psd4 = psdMsg04;
	}


	/* PSD_05 */
	if(psdMessage5 == sample.psd.type) {
		PsdEhr_Psd5Message_t psdMsg05;

		psdMsg05.positionId					= ((data[0] & 0x3F) >> 0);
		psdMsg05.positionLength				= ((data[0] & 0xC0) >> 6) | ((data[1] & 0x1F) << 2);
		psdMsg05.positionInhibitTime		= ((data[1] & 0xE0) >> 5) | ((data[2] & 0x03) << 3);
		psdMsg05.positionIsLocationUnique	= ((data[2] & 0x04) >> 2);
		psdMsg05.positionLongitudinalError	= ((data[2] & 0x38) >> 3);
		psdMsg05.positionLane				= ((data[2] & 0xC0) >> 6) | ((data[3] & 0x01) << 2);
		psdMsg05.attributesSegmentId		= ((data[3] & 0x7E) >> 1);
		psdMsg05.attribute1Type				= ((data[3] & 0x80) >> 7) | ((data[4] & 0x0F) << 1);
		psdMsg05.attribute1Value			= ((data[4] & 0xF0) >> 4);
		psdMsg05.attribute1Offset			= ((data[5] & 0x7F) >> 0);
		psdMsg05.attribute2Type				= ((data[5] & 0x80) >> 7) | ((data[6] & 0x0F) << 1);
		psdMsg05.attribute2Value			= ((data[6] & 0xF0) >> 4);
		psdMsg05.attribute2Offset			= ((data[7] & 0x7F) >> 0);
		psdMsg05.completeFlag				= ((data[7] & 0x80) >> 7);

		sample.psd.data.psd5 = psdMsg05;
	}


	/* PSD_06 */
	if(psdMessage6 == sample.psd.type) {
		if((data[0] & 0x07) == 0) {
			PsdEhr_Psd60Message_t psdMsg060;

			psdMsg060.id					= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg060.countryCode			= ((data[1] & 0xFE) >> 1) | ((data[2] & 0x01) << 7);
			psdMsg060.unitSpeed				= ((data[2] & 0x02) >> 1);
			psdMsg060.trafficDirection		= ((data[2] & 0x04) >> 2);
			psdMsg060.qualityGeometry		= ((data[2] & 0x18) >> 3);
			psdMsg060.qualityMapMatching	= ((data[2] & 0x60) >> 5);
			psdMsg060.ageMapData			= ((data[2] & 0x80) >> 7) | ((data[3] & 0x03) << 1);
			psdMsg060.isRoutingActive		= ((data[3] & 0x04) >> 2);
			psdMsg060.usStateCode			= ((data[3] & 0xF8) >> 3) | ((data[4] & 0x01) << 5);

#if defined(PSD_EHR_SYSTEM_VERSION_USED) && (PSD_EHR_SYSTEM_VERSION_USED == PSD_EHR_SYSTEM_VERSION_152)
			psdMsg060.isRoutingChanged				= ((data[4] & 0x80) >> 7);
			psdMsg060.qualityGeometryExt			= ((data[5] & 0xFF) >> 0);

			psdMsg060.regionQualiGeometry			= ((data[4] & 0x0E) >> 1);
			psdMsg060.regionQualiPlaceInfo			= ((data[4] & 0x30) >> 4);
			psdMsg060.regionQualiAvailable			= ((data[4] & 0x40) >> 6);
			psdMsg060.regionQualiSpecialInfo		= ((data[6] & 0x07) >> 0);
			psdMsg060.regionQualiSlope				= ((data[6] & 0x38) >> 3);
			psdMsg060.regionQualiStreetLabel		= ((data[6] & 0xC0) >> 6) | ((data[7] & 0x01 << 2));
			psdMsg060.regionQualiSpeedLimit			= ((data[7] & 0x0E) >> 1);
			psdMsg060.regionQualiRightOfWayRules	= ((data[7] & 0x70) >> 4);
#endif

			sample.psd.data.psd6.multiplex	= 0;
			sample.psd.data.psd6.message.m0	= psdMsg060;
		}

		if((data[0] & 0x07) == 1) {
			PsdEhr_Psd61Message_t psdMsg061 = {0};

			psdMsg061.attributesSegmentId	= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg061.attribute1Type		= ((data[1] & 0x3E) >> 1);
			/* ALT:	psdMsg061.attribute1Value		= ((data[1] & 0xC0) >> 6) | ((data[2] & 0x03) << 2);*/
			/* ALT:	psdMsg061.attribute1Offset		= ((data[2] & 0xFC) >> 2) | ((data[3] & 0x01) << 6);*/
			psdMsg061.attribute1Value		= ((data[2] & 0xE0) >> 5) | ((data[3] & 0x01) << 3);/**< PSD_06.PSD_Attribut_3_Wert */
			psdMsg061.attribute1Offset		= ((data[1] & 0xC0) >> 6) | ((data[2] & 0x1F) << 2);/**< PSD_06.PSD_Attribut_3_Offset */
			psdMsg061.attribute2Type		= ((data[3] & 0x3E) >> 1);
			psdMsg061.attribute2Value		= ((data[3] & 0xC0) >> 6) | ((data[4] & 0x03) << 2);
			psdMsg061.attribute2Offset		= ((data[4] & 0xFC) >> 2) | ((data[5] & 0x01) << 6);
			psdMsg061.attribute3Type		= ((data[5] & 0x3E) >> 1);
			/* ALT:	psdMsg061.attribute3Value		= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x03) << 2);*/
			/* ALT:	psdMsg061.attribute3Offset		= ((data[6] & 0xFC) >> 2) | ((data[7] & 0x01) << 6);*/
			psdMsg061.attribute3Value		= ((data[6] & 0xE0) >> 5) | ((data[7] & 0x01) << 3);/**< PSD_06.PSD_Attribut_5_Wert */
			psdMsg061.attribute3Offset		= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x1F) << 2);/**< PSD_06.PSD_Attribut_5_Offset */
			psdMsg061.completeFlag			= ((data[7] & 0x02) >> 1);

			sample.psd.data.psd6.multiplex	= 1;
			sample.psd.data.psd6.message.m1	= psdMsg061;
		}

		if((data[0] & 0x07) == 2) {
			PsdEhr_Psd62Message_t psdMsg062;

			psdMsg062.id							= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg062.offset						= ((data[1] & 0xFE) >> 1);
			psdMsg062.speedLimit					= ((data[2] & 0x1F) >> 0);
			psdMsg062.type							= ((data[2] & 0x60) >> 5);
			psdMsg062.constraintLane				= ((data[2] & 0x80) >> 7) | ((data[3] & 0x1F) << 1);
			psdMsg062.constraintTrailer				= ((data[3] & 0x60) >> 5);
			psdMsg062.constraintWeather				= ((data[3] & 0x80) >> 7) | ((data[4] & 0x01) << 1);
			psdMsg062.constraintWeekDayStart		= ((data[4] & 0x0E) >> 1);
			psdMsg062.constraintWeekDayEnd			= ((data[4] & 0x70) >> 4);
			psdMsg062.constraintHourStart			= ((data[4] & 0x80) >> 7) | ((data[5] & 0x0F) << 1);
			psdMsg062.constraintHourEnd				= ((data[5] & 0xF0) >> 4) | ((data[6] & 0x01) << 4);
			psdMsg062.noPassingSign					= ((data[6] & 0x06) >> 1);
			psdMsg062.variableMessageSign			= ((data[6] & 0x38) >> 3);
			psdMsg062.variableMessageSignType		= ((data[6] & 0xC0) >> 6);
			psdMsg062.constraintLegalStreetClass	= ((data[7] & 0x07) >> 0);
			psdMsg062.constraintLegalAddition		= ((data[7] & 0x18) >> 3);/**< PSD_06.PSD_Ges_Gesetzlich_Zusatz */
			psdMsg062.sourceSpeedLimit				= ((data[7] & 0x60) >> 5);/**< PSD_06.PSD_Ges_Verkehrszeichen_Quelle */		
			psdMsg062.completeFlag					= ((data[7] & 0x80) >> 7);

			sample.psd.data.psd6.multiplex	= 2;
			sample.psd.data.psd6.message.m2	= psdMsg062;
		}

		if((data[0] & 0x07) == 3) {
			PsdEhr_Psd63Message_t psdMsg063;

			psdMsg063.longitudeSign				= ((data[0] & 0x08) >> 3);
			psdMsg063.longitude					= ((data[0] & 0xF0) >> 4) | ((data[1] & 0xFF) << 4) | ((data[2] & 0xFF) << 12) | ((data[3] & 0x1F) << 20);
			psdMsg063.latitudeSign				= ((data[3] & 0x10) >> 4);
			psdMsg063.latitude					= ((data[3] & 0xC0) >> 6) | ((data[4] & 0xFF) << 2) | ((data[5] & 0xFF) << 10) | ((data[6] & 0x3F) << 18);
			psdMsg063.direction					= ((data[6] & 0xC0) >> 6) | ((data[7] & 0xFF) << 2);

			sample.psd.data.psd6.multiplex	= 3;
			sample.psd.data.psd6.message.m3	= psdMsg063;
		}

		if((data[0] & 0x07) == 4) {
			PsdEhr_Psd64Message_t psdMsg064;

			psdMsg064.segment1Id			= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg064.segment1Slope1Value	= ((data[1] & 0xFE) >> 1);
			psdMsg064.segment1Slope1Sign	= ((data[2] & 0x01) >> 0);
			psdMsg064.segment1Slope1Offset	= ((data[2] & 0xFE) >> 1);
			psdMsg064.segment1Slope2Value	= ((data[3] & 0x7F) >> 0);
			psdMsg064.segment1Slope2Sign	= ((data[3] & 0x80) >> 7);
			psdMsg064.segment1Slope2Offset	= ((data[4] & 0x7F) >> 0);
			psdMsg064.segment1CompleteFlag	= ((data[4] & 0x80) >> 7);
			psdMsg064.segment2Id			= ((data[5] & 0x3F) >> 0);
			psdMsg064.segment2Slope1Value	= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x1F) << 2);
			psdMsg064.segment2Slope1Sign	= ((data[6] & 0x20) >> 5);
			psdMsg064.segment2Slope1Offset	= ((data[6] & 0xC0) >> 6) | ((data[7] & 0x1F) << 2);
			psdMsg064.segment2CompleteFlag	= ((data[7] & 0x20) >> 5);

			sample.psd.data.psd6.multiplex	= 4;
			sample.psd.data.psd6.message.m4	= psdMsg064;
		}
	}

	sample.time = (real64_T)(time / 1000000.0);
	this->rpl2File.PushPSD(sample);;
}
