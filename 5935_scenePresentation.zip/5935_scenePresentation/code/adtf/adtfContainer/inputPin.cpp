#include "stdafx.h"
#include "inputPin.h"

#include "crcProcessor.h"


inputPin_T::inputPin_T(const pinHeader_T &header)
  : signalPin_T(header)
{
	crcProcessor_T crc;

	this->majorType		= crc.GetCRC((void*)header.GetTypeName().c_str(), strlen(header.GetTypeName().c_str()));
	this->subType		= (uint32_T)header.GetTypeSize();

	this->maxSize		= header.GetTypeSize();
	this->dataSize		= this->maxSize;
	this->dataBuffer	= new uint8_T[this->maxSize];
	this->sizeFixed		= true;

	memset(this->dataBuffer, 0, this->maxSize);

	this->flagged		= false;
	this->autoLock		= false;

	this->mutex.Create();
}


inputPin_T::inputPin_T(std::string typeName, size_t typeSize)
{
	crcProcessor_T crc;

	this->majorType		= crc.GetCRC((void*)typeName.c_str(), strlen(typeName.c_str()));
	this->subType		= (uint32_T)typeSize;

	this->maxSize		= typeSize;
	this->dataSize		= this->maxSize;
	this->dataBuffer	= new uint8_T[this->maxSize];
	this->sizeFixed		= true;

	memset(this->dataBuffer, 0, this->maxSize);

	this->flagged		= false;
	this->autoLock		= false;

	this->mutex.Create();
}


inputPin_T::inputPin_T(uint32_T majorType, uint32_T subType, size_t typeSize)
{
	this->majorType		= majorType;
	this->subType		= subType;

	this->maxSize		= typeSize;
	this->dataSize		= this->maxSize;
	this->dataBuffer	= new uint8_T[this->maxSize];
	this->sizeFixed		= true;

	memset(this->dataBuffer, 0, this->maxSize);

	this->flagged		= false;
	this->autoLock		= false;

	this->mutex.Create();
}


inputPin_T::inputPin_T(uint32_T majorType, uint32_T subType)
{
	this->majorType		= majorType;
	this->subType		= subType;

	this->maxSize		= 16;
	this->dataSize		= 0;
	this->dataBuffer	= new uint8_T[this->maxSize];
	this->sizeFixed		= false;

	memset(this->dataBuffer, 0, this->maxSize);

	this->flagged		= false;
	this->autoLock		= false;

	this->mutex.Create();
}


inputPin_T::inputPin_T(void)
{
	this->majorType		= 0;
	this->subType		= 0;

	this->maxSize		= 16;
	this->dataSize		= 0;
	this->dataBuffer	= new uint8_T[this->maxSize];
	this->sizeFixed		= false;

	memset(this->dataBuffer, 0, this->maxSize);

	this->flagged		= false;
	this->autoLock		= false;

	this->mutex.Create();
}


inputPin_T::~inputPin_T()
{
	delete[] this->dataBuffer;
	this->mutex.Release();
}


cInputPin*	inputPin_T::Create(const char *name, IPinEventSink *eventSink)
{
	this->adtfPin.Create(name, new adtf::cMediaType(this->majorType, this->subType), eventSink);

	return &this->adtfPin;
}


bool		inputPin_T::OnReceive(IPin* pSource, IMediaSample* pMediaSample)
{
	/* An unserem Pin sind neue Daten angekommen! */
	if(pSource == &this->adtfPin) {
		__sample_read_lock(pMediaSample, void, sampleData);

		if(this->sizeFixed && pMediaSample->GetSize() != this->dataSize) {
			char message[512];
			sprintf_s(message, "Pin \"%s\" received sample of wrong size (%d instead of %d).", this->adtfPin.GetName(), pMediaSample->GetSize(), this->dataSize);
			LOG_ERROR(message);
		}
		else {
			this->EnterMutex();

			this->flagged = true;

			/* Ggf. muss der Buffers vergr��ert werden */
			if(pMediaSample->GetSize() > this->maxSize) {
				delete[] this->dataBuffer;
				
				this->dataBuffer	= new uint8_T[pMediaSample->GetSize()];
				this->maxSize		= pMediaSample->GetSize();
			}

			this->dataSize	= pMediaSample->GetSize();
			memcpy(this->dataBuffer, sampleData, pMediaSample->GetSize());

			return true;
		}
	}

	return false;
}


void		inputPin_T::EnterMutex(void)
{
	this->mutex.Enter();
}


void		inputPin_T::LeaveMutex(void)
{
	this->mutex.Leave();
}


bool		inputPin_T::IsConnected(void)
{
	return this->adtfPin.IsConnected();
}


bool		inputPin_T::IsFlagged(void)
{
	return this->flagged;
}


bool		inputPin_T::Unflag(void)
{
	bool wasFlagged	= this->flagged;
	this->flagged	= false;

	return wasFlagged;
}


void*		inputPin_T::GetDataPtr(void)
{
	return (void*)this->dataBuffer;
}


size_t		inputPin_T::GetDataSize(void)
{
	return this->dataSize;
}


tTimeStamp	inputPin_T::GetTimeStamp(void)
{
	return this->timeStamp;
}


void		inputPin_T::SetAutoLock(bool autoLock)
{
	this->autoLock = autoLock;
}
