#include "stdafx.h"
#include "rglBufferFilter.h"
#include "rglConverterTypes.h"

#undef		GetObject
#pragma warning(disable : 4355)

#include <control/psdWrapper/eifTypes.h>


rglBufferFilter_T::rglBufferFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("trigger",				MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);

	this->AddInputPin("In_PpPSD15__DePSD04",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd4Message));
	this->AddInputPin("In_PpPSD15__DePSD05",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd5Message));
	this->AddInputPin("In_PpPSD15__DePSD06m0",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd60Message));
	this->AddInputPin("In_PpPSD15__DePSD06m1",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd61Message));
	this->AddInputPin("In_PpPSD15__DePSD06m2",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd62Message));
	this->AddInputPin("In_PpPSD15__DePSD06m3",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd63Message));
	this->AddInputPin("In_PpPSD15__DePSD06m4",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED, sizeof(Dt_RECORD_PsdEhr_Psd64Message));

	this->inputPin_trigger				= this->GetInputPin("trigger");
	this->inputPin_PpPSD15__DePSD04		= this->GetInputPin("In_PpPSD15__DePSD04");
	this->inputPin_PpPSD15__DePSD05		= this->GetInputPin("In_PpPSD15__DePSD05");
	this->inputPin_PpPSD15__DePSD06m0	= this->GetInputPin("In_PpPSD15__DePSD06m0");
	this->inputPin_PpPSD15__DePSD06m1	= this->GetInputPin("In_PpPSD15__DePSD06m1");
	this->inputPin_PpPSD15__DePSD06m2	= this->GetInputPin("In_PpPSD15__DePSD06m2");
	this->inputPin_PpPSD15__DePSD06m3	= this->GetInputPin("In_PpPSD15__DePSD06m3");
	this->inputPin_PpPSD15__DePSD06m4	= this->GetInputPin("In_PpPSD15__DePSD06m4");

	this->AddOutputPin("PpPSD15__DePSD04",		MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD05",		MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m0",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m1",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m2",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m3",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	this->AddOutputPin("PpPSD15__DePSD06m4",	MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
}


void	rglBufferFilter_T::OnReceive(void)
{
	if(this->GetInputPin("trigger")->Unflag()) {
		this->Submit("PpPSD15__DePSD04",		this->inputPin_PpPSD15__DePSD04->GetDataPtr(),		sizeof(Dt_RECORD_PsdEhr_Psd4Message));
		this->Submit("PpPSD15__DePSD05",		this->inputPin_PpPSD15__DePSD05->GetDataPtr(),		sizeof(Dt_RECORD_PsdEhr_Psd5Message));
		this->Submit("PpPSD15__DePSD06m0",		this->inputPin_PpPSD15__DePSD06m0->GetDataPtr(),	sizeof(Dt_RECORD_PsdEhr_Psd60Message));
		this->Submit("PpPSD15__DePSD06m1",		this->inputPin_PpPSD15__DePSD06m1->GetDataPtr(),	sizeof(Dt_RECORD_PsdEhr_Psd61Message));
		this->Submit("PpPSD15__DePSD06m2",		this->inputPin_PpPSD15__DePSD06m2->GetDataPtr(),	sizeof(Dt_RECORD_PsdEhr_Psd62Message));
		this->Submit("PpPSD15__DePSD06m3",		this->inputPin_PpPSD15__DePSD06m3->GetDataPtr(),	sizeof(Dt_RECORD_PsdEhr_Psd63Message));
		this->Submit("PpPSD15__DePSD06m4",		this->inputPin_PpPSD15__DePSD06m4->GetDataPtr(),	sizeof(Dt_RECORD_PsdEhr_Psd64Message));
	}
}
