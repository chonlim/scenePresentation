#ifndef guard_zfasConverterFilter_h
#define guard_zfasConverterFilter_h

#include "baseFilter.h"
#include "common/swcCommunication/swcComm_adtfTools.h"


#define ADTF_FILTER_ID_zfasConverterFilter		"IDII.zfasConverterFilter"
#define ADTF_FILTER_NAME_zfasConverterFilter	"IDII zfasConverterFilter"


class zfasConverterFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_zfasConverterFilter, ADTF_FILTER_NAME_zfasConverterFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	inputPin_T			*inputPin_DePemControl;
	inputPin_T			*inputPin_DePemPlanning;

	inputPin_T			*inputPin_DeEML;
	inputPin_T			*inputPin_DeFRInnoDriveIn;
	inputPin_T			*inputPin_DeOBFLight;
	inputPin_T			*inputPin_DeVZE;
	inputPin_T			*inputPin_DeLanes;
	inputPin_T			*inputPin_DeFRRGOut;


public:
	zfasConverterFilter_T(const tChar* __info);

	void		OnReceive(void);
	bool		OnInitNormal(void);
};


#endif
