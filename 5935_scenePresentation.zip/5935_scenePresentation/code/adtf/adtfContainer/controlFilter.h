#ifndef guard_controlFilter_h
#define guard_controlFilter_h

#include "baseFilter.h"
#include "control/controlTask/controlTask_private.h"
#include "control/psdWrapper/eifTypes.h"


#define ADTF_FILTER_ID_controlFilter	"IDII.controlFilter"
#define ADTF_FILTER_NAME_controlFilter	"IDII controlFilter"


class controlFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_controlFilter, ADTF_FILTER_NAME_controlFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	pemControlHeap_T		heap;
	eifMemory_T				eifMemory;

public:
	controlFilter_T(const tChar* __info);

	void		OnReceive(void);
	bool		OnInitNormal(void);

private:
	void		RunAlgorithm(void);
};


#endif
