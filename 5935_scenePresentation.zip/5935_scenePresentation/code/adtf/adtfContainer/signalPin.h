#ifndef guard_signalPin_h
#define guard_signalPin_h


#include "../adtfFilter.h"
#include "signalInterface.h"


class signalPin_T
{
private:
	const pinHeader_T	*header;
	bool				 signalsEnabled;

	typedef struct updateContext_tag {
		signalCallback_T *callback;
		tSignalID		  nextID;
	} updateContext_T;


public:
					signalPin_T(const pinHeader_T &header);
					signalPin_T(void);

					~signalPin_T();

	void			RegisterSignals(signalCallback_T *callback, const char *baseName);
	void			UpdateSignals(signalCallback_T *callback, const void *data, size_t size, tSignalID firstID);

	bool			SignalsPossible(void);


private:
	static bool_T	UpdateCallback_bool(const void* callback, const char *name, const char *description,	bool_T   value);
	static int32_T	UpdateCallback_int(const void* callback, const char *name, const char *description,		int32_T  value);
	static real64_T	UpdateCallback_real(const void* callback, const char *name, const char *description,	real64_T value);

	static bool_T	RegisterCallback_bool(const void* callback, const char *name, const char *description,	bool_T   value);
	static int32_T	RegisterCallback_int(const void* callback, const char *name, const char *description,	int32_T  value);
	static real64_T	RegisterCallback_real(const void* callback, const char *name, const char *description,	real64_T value);
};


#endif
