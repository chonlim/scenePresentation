#ifndef guard_gen2FlexrayFilter_h
#define guard_gen2FlexrayFilter_h

#include "baseFilter.h"
#include <vector>

#define ADTF_FILTER_ID_gen2FlexrayFilter	"IDII.gen2FlexrayFilter"
#define ADTF_FILTER_NAME_gen2FlexrayFilter	"IDII gen2FlexrayFilter"


class gen2FlexrayFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_gen2FlexrayFilter, ADTF_FILTER_NAME_gen2FlexrayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	bool_T					sampleRelevant;

	std::vector<tUInt32>	relevantIDs;

	cObjectPtr<adtf_devicetb::IFlexRayCoder>	flexrayCoder;


public:
	gen2FlexrayFilter_T(const tChar* __info);
	~gen2FlexrayFilter_T();

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	tResult		OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);
	void		OnReceive(void);

	void		OnRun(int32_T type, const void *data, size_t size);


private:
	void		OnTrigger(void);
};


#endif
