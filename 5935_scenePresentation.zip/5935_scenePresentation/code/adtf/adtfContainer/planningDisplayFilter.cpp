#include "stdafx.h"
#include "planningDisplayFilter.h"


#include "common/vehicleObserverCommon/vehicleObserver_adtfTools.h"
#include "common/swcCommunication/swcComm_adtfTools.h"
#include "control/controlTask/controlTask_adtfTools.h"
#include "strategy/strategyTask/strategyTask_adtfTools.h"


#define		def_minPosition		-100.0f
#define		def_maxPosition		 400.0f
#define		def_minVelocity		   0.0f
#define		def_maxVelocity		  50.0f
#define		def_minAcceleration	  -4.0f
#define		def_maxAcceleration	   4.0f


#pragma warning(disable : 4355)


planningDisplayFilter_T::planningDisplayFilter_T(const tChar* __info)
  : displayFilter_T(__info, def_minPosition, def_maxPosition, def_minVelocity, def_maxVelocity, def_minAcceleration, def_maxAcceleration),
	ctmHorizonPainter(&this->control->graph),
	longHorizonPainter(&this->control->graph),
	lnptHorizonPainter(&this->control->graph),
	lnstHorizonPainter(&this->control->graph),
	lntqHorizonPainter(&this->control->graph)
{
	this->showBlueBand			= false;

	this->AddInputPin("pemControl",		pemControl_header());
	this->AddInputPin("controlStack",	pemControlStack_header());
	this->AddInputPin("controlHeap",	pemControlHeap_header());

	this->AddInputPin("pemPlanning",	pemPlanning_header());
	this->AddInputPin("planningHeap",	pemPlanningHeap_header());
	this->AddInputPin("planningStack",	pemPlanningStack_header());
}


bool	planningDisplayFilter_T::OnInitNormal(void)
{
	this->longHorizonPainter.InitGrid();

	this->ctmHorizonPainter.Init();
	this->lnptHorizonPainter.Init();
	this->lnstHorizonPainter.Init();
	this->lntqHorizonPainter.Init();
	this->longHorizonPainter.Init();

	return true;
}


void	planningDisplayFilter_T::OnReceive(void)
{
	if(this->GetInputPin("pemControl")->Unflag()) 
	{
		this->EnterMutex();
		pemControl_T		pemControl		= *(pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();
		pemControlStack_T	controlStack	= *(pemControlStack_T*)this->GetInputPin("controlStack")->GetDataPtr();
		pemControlHeap_T	controlHeap		= *(pemControlHeap_T*)this->GetInputPin("controlHeap")->GetDataPtr();
		this->LeaveMutex();

		this->longHorizonPainter.Process(&pemControl.vehicleState,
										 &pemControl.systemControl,
										 &controlStack.vehicleInput,
										 &controlStack.displayControl,
										 &controlStack.longControl,
										 &controlHeap.longControlInfo);
	}


	if(this->GetInputPin("pemPlanning")->Unflag()) {
		this->EnterMutex();
		pemPlanning_T		pemPlanning		= *(pemPlanning_T*)this->GetInputPin("pemPlanning")->GetDataPtr();
		pemPlanningHeap_T	planningHeap	= *(pemPlanningHeap_T*)this->GetInputPin("planningHeap")->GetDataPtr();
		pemPlanningStack_T	planningStack	= *(pemPlanningStack_T*)this->GetInputPin("planningStack")->GetDataPtr();
		this->LeaveMutex();

		this->ctmHorizonPainter.Process(&planningHeap.velocityConstraints);
		this->lnstHorizonPainter.Process(&planningHeap.longStabilization);
		this->lnptHorizonPainter.Process(&planningHeap.longPath);
		this->lntqHorizonPainter.Process(&pemPlanning.longTorque);
	}
}
