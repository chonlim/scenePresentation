#ifndef guard_driverObserverDisplayFilter_h
#define guard_driverObserverDisplayFilter_h

#include "displayFilter.h"

#define ADTF_FILTER_ID_driverObserverDisplayFilter		"IDII.driverObserverDisplayFilter"
#define ADTF_FILTER_NAME_driverObserverDisplayFilter	"IDII driverObserverDisplayFilter"


#include "tools/hpDisplayBlocks/dynamicLevelPainter.h"

#include "Rte_Type.h"


#include "../testVector/testVector.h"


class driverObserverDisplayFilter_T
  : public displayFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_driverObserverDisplayFilter, ADTF_FILTER_NAME_driverObserverDisplayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	bool					positionTracking;
	
	dynamicLevelPainter_T	dynamicLevelPainter;
	driverState_T			driverStateTmp;

	
public:
	driverObserverDisplayFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	void		OnReceive(void);

	void		PrePaint(void);


private:


};

#endif
