#ifndef guard_signalInterface_h
#define guard_signalInterface_h


class signalCallback_T {
public:
	virtual void	RegisterSignal(const char *name)			= 0;
	virtual void	UpdateSignal(tSignalID id, real64_T value)	= 0;
};


#endif
