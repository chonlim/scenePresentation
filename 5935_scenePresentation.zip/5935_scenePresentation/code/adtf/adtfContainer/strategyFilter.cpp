#include "stdafx.h"
#include "strategyFilter.h"

extern "C" {
	#include "strategy/strategyTask/strategyTask.h"
}
#include "base.h"
#include "control/controlTask/controlTask_adtfTools.h"
#include "strategy/strategyTask/strategyTask_adtfTools.h"
#include "common/vehicleModel/vehicleModel_adtfTools.h"
#include "common/swcCommunication/swcComm_adtfTools.h"
#include "common/vehicleObserverCommon/vehicleObserver_adtfTools.h"

#ifdef ID2FP_DEBUG
#include "strategy/parameterSet/parameterSetStgy.h"
#endif

strategyFilter_T::strategyFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("trigger");
	
	this->AddInputPin("vehicleModel",	vehicleModel_header());
	this->AddInputPin("pemControl",		pemControl_header());

	this->AddOutputPin("pemPlanning",	pemPlanning_header());
	this->AddOutputPin("strategyTrace",	strategyTrace_header());
	this->AddOutputPin("strategyHeap",	pemPlanningHeap_header());
	this->AddOutputPin("strategyStack",	pemPlanningStack_header());

	this->AddInputPin("_pushHeap",		pemPlanningHeap_header());//"pemPlanningHeap_T",	sizeof(pemPlanningHeap_T));

	this->SetPropertyBool("Enable pushHeap", tTrue);
	this->SetPropertyBool("Enable pushHeap" NSSUBPROP_ISCHANGEABLE, tTrue);

#ifdef ID2FP_DEBUG
    memset(&this->heap,0,sizeof(pemPlanningHeap_T));
#endif
}


void	strategyFilter_T::OnReceive(void)
{
	if(this->GetInputPin("trigger")->Unflag()) {
		this->RunAlgorithm();
	}

	if(this->GetInputPin("_pushHeap")->Unflag()) {
		if(this->GetPropertyBool("Enable pushHeap")) {
			this->EnterMutex();
			this->heap = *(pemPlanningHeap_T*)this->GetInputPin("_pushHeap")->GetDataPtr();
			this->LeaveMutex();
		}
	}
}


bool	strategyFilter_T::OnInitNormal(void)
{
	memset(&this->heap,		0,	sizeof(this->heap));
	memset(&this->stack,	0,	sizeof(this->stack));

	return true;
}

#ifdef ID2FP_DEBUG
extern "C" __declspec(dllexport) vehicleModel_T*	ID2_RP_stgy_ref_vehicleModel = 0;
extern "C" __declspec(dllexport) pemPlanning_T*		ID2_RP_stgy_ref_pemPlanning = 0;
extern "C" __declspec(dllexport) pemControl_T*		ID2_RP_stgy_ref_pemControl = 0;
extern "C" __declspec(dllexport) const parameterSetStgy_T* ID2_RP_stgy_ref_ParameterSetStgy = 0;
extern "C" __declspec(dllexport) pemPlanningHeap_T* ID2_RP_stgy_ref_pemPlanningHeap = 0;
extern "C" __declspec(dllexport) unsigned char		ID2_RP_stgy_references_initialized = 0;
#endif

void	strategyFilter_T::RunAlgorithm(void)
{
	this->EnterMutex();

#ifndef ID2FP_DEBUG
    // input
	vehicleModel_T	vehicleModel	= *(vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();
	pemControl_T	pemControl		= *(pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();
	//output
	pemPlanning_T	pemPlanning		= {0};
	strategyTrace_T	strategyTrace	= {0};

#else
    // input
	static vehicleModel_T	vehicleModel;
	static pemControl_T	pemControl;
	//output
    static pemPlanning_T	pemPlanning;
	static strategyTrace_T  strategyTrace;

	/* fast project filter needs 2 cycles for parameter initialization */
	static int input_delay = 2;
	if (input_delay > 0){
	    input_delay--;
		return;
	}

    // read input
    vehicleModel    = *(vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();
    pemControl      = *(pemControl_T*)this->GetInputPin("pemControl")->GetDataPtr();

    // initialize stack
    memset(&this->stack,0,sizeof(pemPlanningStack_T));
    // initialize output
    memset(&pemPlanning,0,sizeof(pemPlanning_T));
	memset(&strategyTrace,0,sizeof(strategyTrace_T));

    if (!ID2_RP_stgy_references_initialized) {
		ID2_RP_stgy_ref_vehicleModel	= &vehicleModel;
		ID2_RP_stgy_ref_pemPlanning		= &pemPlanning;
		ID2_RP_stgy_ref_pemControl		= &pemControl;
		ID2_RP_stgy_ref_pemPlanningHeap	= &this->heap;
		/* prmGetParameterSetStgy is defined in different library */
		/* ID2_RP_stgy_ref_ParameterSetStgy = prmGetParameterSetStgy(); */
		ID2_RP_stgy_references_initialized = 1;
	}
#endif

	this->LeaveMutex();

	iscRunStrategy(&vehicleModel,
				   &pemControl,
				   &this->heap,
				   &this->stack,
				   &pemPlanning,
				   &strategyTrace);

	this->Submit("pemPlanning",		&pemPlanning,	sizeof(pemPlanning));
	this->Submit("strategyTrace",	&strategyTrace,	sizeof(strategyTrace));
	this->Submit("strategyHeap",	&heap,			sizeof(heap));
	this->Submit("strategyStack",	&stack,			sizeof(stack));
}


