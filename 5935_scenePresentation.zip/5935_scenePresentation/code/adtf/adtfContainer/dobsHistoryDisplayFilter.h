#ifndef	guard_dobsHistoryDisplayFilter_h
#define	guard_dobsHistoryDisplayFilter_h

#include "displayFilter.h"

#define ADTF_FILTER_ID_dobsHistoryDisplayFilter		"IDII.dobsHistoryDisplayFilter"
#define ADTF_FILTER_NAME_dobsHistoryDisplayFilter	"IDII dobsHistoryDisplayFilter"

#include	"tools/hpDisplayBlocks/obsHistoryProcessor.h"
#include "Rte_Type.h"

class dobsHistoryDisplayFilter_T
  : public displayFilter_T,
	// public containerCallback_T,
	public cKernelCyclicThread
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_dobsHistoryDisplayFilter, ADTF_FILTER_NAME_dobsHistoryDisplayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	obsHistoryProcessor_T	 obsHistoryProcessor;

	cKernelEvent			 flagged;
	bool_T					 shutdown;

	bool_T					 lastToggle;

	inputPin_T				*inputPin_vehicleModel;
	inputPin_T				*inputPin_flexray;
	inputPin_T				*inputPin_traceData;

	bool_T					 pageValid;

	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;

public:
	dobsHistoryDisplayFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);

	void		OnShutdownNormal(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);

	tResult		OnSize(tHandle hCanvas, tInt nLeft, tInt nTop, tInt nRight, tInt nBottom);
	tResult		OnTimer(tHandle hCanvas);
	tResult		OnControlEvent(tControlEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags,  tVoid* pEventData);

	void		Process(void);

	void		DecodeControlCode(real32_T DePACC02_Durchschnittsgeschw);

	void		ForceUpdate(void);
	void		PushControl(graphControl_T *control);


private:
	tUInt32					idPIF_01;
	tUInt32					idPIF_Identifier;

	tResult		CyclicFunc();

	driverState_T	driverState;

	real32_T	tickCount;
};
#endif