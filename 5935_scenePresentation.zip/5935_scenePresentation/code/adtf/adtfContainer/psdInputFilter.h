#ifndef guard_psdInputFilter_h
#define guard_psdInputFilter_h

#define SKIP_MAGIC_NUMBER

#include "baseFilter.h"


#define ADTF_FILTER_ID_psdInputFilter	"IDII.psdInputFilter"
#define ADTF_FILTER_NAME_psdInputFilter	"IDII psdInputFilter"


class psdInputFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_psdInputFilter, ADTF_FILTER_NAME_psdInputFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	inputPin_T		*inputPin_flexray;



	/* FIBEX-IDs der Signale und PDUs, die wir ben�tigen */
	struct {
		struct {
			tUInt32		pdu;
		} PSD_04;

		struct {
			tUInt32		pdu;
		} PSD_05;

		struct {
			tUInt32		pdu;
		} PSD_06;
		
	} id;
	
	cObjectPtr<adtf_devicetb::IFlexRayCoder> flexrayCoder;

public:
	psdInputFilter_T(const tChar* __info);			 

	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);


private:
	void		Process_PSD(uint32_T id, const uint8_T *data, tTimeStamp time);
};


#endif
