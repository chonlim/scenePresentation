#include "stdafx.h"
#include "gen2FlexrayFilter.h"

#undef		GetObject
#pragma warning(disable : 4355)


gen2FlexrayFilter_T::gen2FlexrayFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("flexrayFull",		MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);
	this->AddOutputPin("flexrayFiltered",	MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);
}


gen2FlexrayFilter_T::~gen2FlexrayFilter_T()
{
}



bool	gen2FlexrayFilter_T::OnInitNormal(void)
{
	cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
	if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
		LOG_ERROR("No FlexRay support service available");
		return false;
	}


	cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
	if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
		LOG_ERROR("Failed to get FIBEX database");
		return false;
	}


	/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
	cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
	if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
		LOG_ERROR("Failed to create FlexRay coder");
		return false;
	}


	this->flexrayCoder = coder;
	this->flexrayCoder->ResetData();

	this->flexrayCoder->SetListener((groundFilter_T*)this);


	/* Abfragen der IDs f�r die PDUs, die uns interessieren.
	Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
	tUInt32 count;
	fibexDB->GetPDUCount(&count);

	for(tUInt32 i = 0; i < count; i++) {
		const tChar *name;
		fibexDB->GetPDUName(i, &name);

		if(   (!strcmp(name, "ACC_06"))
		   || (!strcmp(name, "ACC_12"))
		   || (!strcmp(name, "ACC_16"))
		   || (!strcmp(name, "Blinkmodi_02"))
		   || (!strcmp(name, "Charisma_08"))
		   || (!strcmp(name, "ESP_22"))
		   || (!strcmp(name, "Getriebe_11"))
		   || (!strcmp(name, "Getriebe_17"))
		   || (!strcmp(name, "GRA_ACC_01"))
		   || (!strcmp(name, "Kombi_01"))
		   || (!strcmp(name, "Kombi_02"))
		   || (!strcmp(name, "LWI_01"))
		   || (!strcmp(name, "Motor_11"))
		   || (!strcmp(name, "Motor_14"))
		   || (!strcmp(name, "Motor_16"))
		   || (!strcmp(name, "Motor_20"))
		   || (!strcmp(name, "Motor_Code_01"))
		   || (!strcmp(name, "SDF1_Objekt_01"))
		   || (!strcmp(name, "TSK_06"))
		   || (!strcmp(name, "VZE_01"))
		   || (!strcmp(name, "VZE_02"))
		   || (!strcmp(name, "ESP_21"))
		   || (!strcmp(name, "BV_Fahrstreifen_01"))
		   || (!strcmp(name, "BV_Fahrstreifen_02"))
		   || (!strcmp(name, "BV_Fahrstreifen_03"))
		   || (!strcmp(name, "BV_Fahrstreifen_04"))
		   || (!strcmp(name, "BV_Fahrstreifen_05"))
		   || (!strcmp(name, "BV_Fahrstreifen_06"))
		   || (!strcmp(name, "BV_Fahrstreifen_07"))
		   || (!strcmp(name, "BV_Fahrstreifen_08"))
		   || (!strcmp(name, "SARA_11"))
		   || (!strcmp(name, "NavData_01"))
		   || (!strcmp(name, "PSD_04"))
		   || (!strcmp(name, "PSD_05"))
		   || (!strcmp(name, "PSD_06"))) {
			this->flexrayCoder->ActivePDUEvents(i);
		}
	}

	return true;
}


bool	gen2FlexrayFilter_T::OnGraphReady(void)
{
	return true;
}


void	gen2FlexrayFilter_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}


tResult	gen2FlexrayFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	return baseFilter_T::OnPinEvent(pSource, nEventCode, nParam1, nParam2, pMediaSample);
}


void	gen2FlexrayFilter_T::OnReceive(void)
{
	if(this->GetInputPin("flexrayFull")->Unflag()) {
		if(this->flexrayCoder) {
			this->EnterMutex();

			this->sampleRelevant = false;

			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexrayFull")->GetDataPtr(),
									  (tInt)this->GetInputPin("flexrayFull")->GetDataSize(),
											this->GetInputPin("flexrayFull")->GetTimeStamp());

			if(this->sampleRelevant) {
				this->Submit("flexrayFiltered", this->GetInputPin("flexrayFull")->GetDataPtr(), this->GetInputPin("flexrayFull")->GetDataSize());
			}

			this->LeaveMutex();
		}
	}
}


void	gen2FlexrayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }

		this->sampleRelevant = true;
	}
}
