#include "stdafx.h"
#include "serialPortFilter.h"


serialPortFilter_T::serialPortFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddOutputPin("nmea",		MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_UINT8);

	this->SetPropertyStr("Port", "COM2");
	this->SetPropertyStr("Port" NSSUBPROP_VALUELIST , "COM1@COM1|COM2@COM2|COM3@COM3|COM4@COM4|COM5@COM5|COM6@COM6|COM7@COM7|COM8@COM8|COM9@COM9");

	this->portHandle = INVALID_HANDLE_VALUE;
}


bool	serialPortFilter_T::OnInitNormal(void)
{
	char portName[128];

	this->GetPropertyStr("Port", portName, sizeof(portName));
	this->portHandle = CreateFileA(portName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);

	if(this->portHandle == INVALID_HANDLE_VALUE) {
		char message[1024];

		sprintf_s(message, "Failed to open port \"%s\".", this->GetPropertyStr("dataFile"));
		this->ShowErrorBox(message, "serialPortFilter");

		return false;
	}

	COMMTIMEOUTS timeouts;
	timeouts.ReadIntervalTimeout			= 100;
	timeouts.ReadTotalTimeoutMultiplier		= MAXDWORD;
	timeouts.ReadTotalTimeoutConstant		= 500;
	timeouts.WriteTotalTimeoutMultiplier	= MAXDWORD;
	timeouts.WriteTotalTimeoutConstant		= MAXDWORD;


	if(!SetCommTimeouts(this->portHandle ,&timeouts)) {
		CloseHandle(this->portHandle);
		this->portHandle = INVALID_HANDLE_VALUE;

		char message[1024];

		sprintf_s(message, "Failed to set timeout for port.");
		this->ShowErrorBox(message, "serialPortFilter");

		return false;
	}


	cKernelCyclicThread::Create();

	return true;
}


void	serialPortFilter_T::OnShutdownNormal(void)
{
	/* Zyklischen Thread abbrechen */
	cKernelCyclicThread::Release();

	if(this->portHandle != INVALID_HANDLE_VALUE) {
		CloseHandle(this->portHandle);
		this->portHandle = INVALID_HANDLE_VALUE;
	}
}


tResult	serialPortFilter_T::CyclicFunc(void)
{
	char readBuffer[1024] = {0};
	DWORD bytesRead;

	if(ReadFile(this->portHandle, readBuffer, sizeof(readBuffer)-1, &bytesRead, NULL)) {
		this->Submit("nmea", readBuffer, bytesRead);
	}

	RETURN_NOERROR;
}
