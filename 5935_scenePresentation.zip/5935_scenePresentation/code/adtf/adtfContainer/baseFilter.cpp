#include "stdafx.h"
#include "baseFilter.h"


#undef GetObject


baseFilter_T::baseFilter_T(const tChar* __info) : cFilter(__info)
{
}


baseFilter_T::~baseFilter_T()
{
	groundFilter_T::Cleanup();
}


tResult	baseFilter_T::Init(adtf::cFilter::tInitStage eStage, __exception)
{
	RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr));

	if(eStage == StageFirst) {
		groundFilter_T::RegisterKernel(_kernel);
	}

	return groundFilter_T::Init(eStage, this, __exception_ptr);
}


tResult	baseFilter_T::Shutdown(tInitStage eStage, __exception)
{
	RETURN_IF_FAILED(groundFilter_T::Shutdown(eStage, __exception_ptr));

	return cFilter::Shutdown(eStage, __exception_ptr);
}


tResult	baseFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	return groundFilter_T::OnPinEvent(pSource, nEventCode, nParam1, nParam2, pMediaSample);
}


tResult	baseFilter_T::Start(__exception)
{
	RETURN_IF_FAILED(cFilter::Start(__exception_ptr));

	return groundFilter_T::Start(__exception_ptr);
}


tResult	baseFilter_T::Stop(__exception)
{
	RETURN_IF_FAILED(groundFilter_T::Stop(__exception_ptr));

	return cFilter::Stop(__exception_ptr);
}


tResult	baseFilter_T::GetInterface(const tChar *idInterface, tVoid **ppvObject)
{
	if(idmatch(idInterface, IID_ADTF_SIGNAL_PROVIDER)) {
		*ppvObject = static_cast<ISignalProvider*> (this);
		Ref();
	}
	else {
		return cFilter::GetInterface(idInterface, ppvObject);
	}

	RETURN_NOERROR;
}


tUInt	baseFilter_T::Ref()
{
	return cFilter::Ref();
}


tUInt	baseFilter_T::Unref()
{
	return cFilter::Unref();
}


tVoid	baseFilter_T::Destroy()
{
	delete this;
}


tTimeStamp	baseFilter_T::GetStreamTime(void)
{
	return this->_clock->GetStreamTime();
}


tBool		baseFilter_T::GetPropertyBool(const tChar* strName, tBool bDefault)
{
	return cFilter::GetPropertyBool(strName, bDefault);
}


tResult		baseFilter_T::AllocMediaSample(IMediaSample** ppMediaSample, ucom::IException** __exception_ptr)
{
	return cFilter::AllocMediaSample(ppMediaSample, __exception_ptr);
}


const tChar* baseFilter_T::OIGetInstanceName()
{
	return cFilter::OIGetInstanceName();
}


tResult		baseFilter_T::RegisterPin(IPin* pIPin)
{
	return cFilter::RegisterPin(pIPin);
}


tResult		baseFilter_T::ReleasePins(void)
{
	return cFilter::ReleasePins();
}


tResult		baseFilter_T::SetPropertyBool(const tChar* strName, tBool bValue)
{
	return cFilter::SetPropertyBool(strName, bValue);
}


tResult		baseFilter_T::PropertyChanged(const tChar *strName)
{
	this->OnPropertyChange(strName);

	RETURN_NOERROR;
}


void		baseFilter_T::OnPropertyChange(const char_T *name)
{
}
