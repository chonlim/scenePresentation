#include "stdafx.h"
#include "psdInputFilter.h"
#include "rglConverterTypes.h"

#undef		GetObject
#pragma warning(disable : 4355)

#include <control/psdWrapper/eifTypes.h>


psdInputFilter_T::psdInputFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{	
	this->AddInputPin("flexray",		MEDIA_TYPE_FLEXRAY,		MEDIA_SUBTYPE_FLEXRAY);
	this->AddOutputPin("psdInput",		MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	
	this->inputPin_flexray		= this->GetInputPin("flexray");
}


bool	psdInputFilter_T::OnGraphReady(void)
{
	/* Wenn der Flexray-Pin verbunden ist, fragen wir die Fibex-Datenbank nach den IDs f�r die PSD-PDUs */
	//if(this->GetInputPin("flexray")->IsConnected()) //CAN-Alternative wird hier nicht implementiert.
	{
		cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
		if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
			LOG_ERROR("No FlexRay support service available");
			return false;
		}


		cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
		if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
			LOG_ERROR("Failed to get FIBEX database");
			return false;
		}


		/* Nullsetzen der id-Strukur */
		memset(&this->id, 0, sizeof(this->id));



		/* Abfragen der IDs f�r die PDUs, die uns interessieren.
		   Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
		tUInt32 count;
		fibexDB->GetPDUCount(&count);

		for(tUInt32 i = 0; i < count; i++) {
			const tChar *name;
			fibexDB->GetPDUName(i, &name);

			if (!strcmp(name, "PSD_04"))					{ this->id.PSD_04.pdu = i;					continue; }
			if (!strcmp(name, "PSD_05"))					{ this->id.PSD_05.pdu = i;					continue; }
			if (!strcmp(name, "PSD_06"))					{ this->id.PSD_06.pdu = i;					continue; }
		}


		/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
		cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
		if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
			LOG_ERROR("Failed to create FlexRay coder");
			return false;
		}

		this->flexrayCoder = coder;
		this->flexrayCoder->ResetData();

		this->flexrayCoder->SetListener((groundFilter_T*)this);

		this->flexrayCoder->ActivePDUEvents(this->id.PSD_04.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PSD_05.pdu);
		this->flexrayCoder->ActivePDUEvents(this->id.PSD_06.pdu);
	}
	
	return true;
}


void	psdInputFilter_T::OnShutdownNormal(void)
{
	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}

}


void	psdInputFilter_T::OnReceive(void)
{
	if(this->inputPin_flexray->Unflag()) {
		if(this->flexrayCoder) {
			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->GetInputPin("flexray")->GetDataPtr(),
									  (tInt)this->GetInputPin("flexray")->GetDataSize(),
											this->GetInputPin("flexray")->GetTimeStamp());
		}
	}
}


void	psdInputFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		const adtf_devicetb::tCoderPDUEvent *coderEvent = (const adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }


		/* PSD */
		if(coderEvent->nPDUID == this->id.PSD_04.pdu ||
		   coderEvent->nPDUID == this->id.PSD_05.pdu ||
		   coderEvent->nPDUID == this->id.PSD_06.pdu) {
			if(coderEvent->nPayloadLength == 8) {
				//if(!this->canPSDReceived) 
				{
					this->Process_PSD(coderEvent->nPDUID, coderEvent->pData, _clock->GetStreamTime());
				}
			}
		}
	}
}


void	psdInputFilter_T::Process_PSD(uint32_T id, const uint8_T *data, tTimeStamp time)
{		
	psdInput_T psdInput;


	if(     id == this->id.PSD_04.pdu)	{ psdInput.type = psdMessage4; }
	else if(id == this->id.PSD_05.pdu)	{ psdInput.type = psdMessage5; }
	else if(id == this->id.PSD_06.pdu)	{ psdInput.type = psdMessage6; }
	else								{ return; }


	if(psdMessage4 == psdInput.type) {
		PsdEhr_Psd4Message_t psdMsg04;

		psdMsg04.id					= ((data[0] & 0x3F) >> 0);
		psdMsg04.parentId			= ((data[0] & 0xC0) >> 6) | ((data[1] & 0x0F) << 2);
		psdMsg04.length				= ((data[1] & 0xF0) >> 4) | ((data[2] & 0x07) << 4);
		psdMsg04.streetClass		= ((data[2] & 0x38) >> 3);
		psdMsg04.curvatureEnd		= ((data[2] & 0xC0) >> 6) | ((data[3] & 0x3F) << 2);
		psdMsg04.curvatureEndSign	= ((data[3] & 0x40) >> 6);
		psdMsg04.identity			= ((data[3] & 0x80) >> 7) | ((data[4] & 0x1F) << 1);
		psdMsg04.isADASQuality		= ((data[4] & 0x20) >> 5);
		psdMsg04.isMostProbablePath	= ((data[4] & 0x40) >> 6);
		psdMsg04.isStraightestPath	= ((data[4] & 0x80) >> 7);
		psdMsg04.lanes				= ((data[5] & 0x07) >> 0);
		psdMsg04.isBuiltUpArea		= ((data[5] & 0x08) >> 3);
		psdMsg04.completeFlag		= ((data[5] & 0x10) >> 4);
		psdMsg04.ramp				= ((data[5] & 0x60) >> 5);
		psdMsg04.curvatureStart		= ((data[5] & 0x80) >> 7) | ((data[6] & 0x7F) << 1);
		psdMsg04.curvatureStartSign	= ((data[6] & 0x80) >> 7);
		psdMsg04.branchDirection	= ((data[7] & 0x01) >> 0);
		psdMsg04.branchAngle		= ((data[7] & 0xFE) >> 1);

		psdInput.data.psd4 = psdMsg04;
	}


	/* PSD_05 */
	if(psdMessage5 == psdInput.type) {
		PsdEhr_Psd5Message_t psdMsg05;

		psdMsg05.positionId					= ((data[0] & 0x3F) >> 0);
		psdMsg05.positionLength				= ((data[0] & 0xC0) >> 6) | ((data[1] & 0x1F) << 2);
		psdMsg05.positionInhibitTime		= ((data[1] & 0xE0) >> 5) | ((data[2] & 0x03) << 3);
		psdMsg05.positionIsLocationUnique	= ((data[2] & 0x04) >> 2);
		psdMsg05.positionLongitudinalError	= ((data[2] & 0x38) >> 3);
		psdMsg05.positionLane				= ((data[2] & 0xC0) >> 6) | ((data[3] & 0x01) << 2);
		psdMsg05.attributesSegmentId		= ((data[3] & 0x7E) >> 1);
		psdMsg05.attribute1Type				= ((data[3] & 0x80) >> 7) | ((data[4] & 0x0F) << 1);
		psdMsg05.attribute1Value			= ((data[4] & 0xF0) >> 4);
		psdMsg05.attribute1Offset			= ((data[5] & 0x7F) >> 0);
		psdMsg05.attribute2Type				= ((data[5] & 0x80) >> 7) | ((data[6] & 0x0F) << 1);
		psdMsg05.attribute2Value			= ((data[6] & 0xF0) >> 4);
		psdMsg05.attribute2Offset			= ((data[7] & 0x7F) >> 0);
		psdMsg05.completeFlag				= ((data[7] & 0x80) >> 7);

		psdInput.data.psd5 = psdMsg05;
	}


	/* PSD_06 */
	if(psdMessage6 == psdInput.type) {
		if((data[0] & 0x07) == 0) {
			PsdEhr_Psd60Message_t psdMsg060;

			psdMsg060.id					= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg060.countryCode			= ((data[1] & 0xFE) >> 1) | ((data[2] & 0x01) << 7);
			psdMsg060.unitSpeed				= ((data[2] & 0x02) >> 1);
			psdMsg060.trafficDirection		= ((data[2] & 0x04) >> 2);
			psdMsg060.qualityGeometry		= ((data[2] & 0x18) >> 3);
			psdMsg060.qualityMapMatching	= ((data[2] & 0x60) >> 5);
			psdMsg060.ageMapData			= ((data[2] & 0x80) >> 7) | ((data[3] & 0x03) << 1);
			psdMsg060.isRoutingActive		= ((data[3] & 0x04) >> 2);
			psdMsg060.usStateCode			= ((data[3] & 0xF8) >> 3) | ((data[4] & 0x01) << 5);

#if defined(PSD_EHR_SYSTEM_VERSION_USED) && (PSD_EHR_SYSTEM_VERSION_USED == PSD_EHR_SYSTEM_VERSION_152)
			psdMsg060.isRoutingChanged				= ((data[4] & 0x80) >> 7);
			psdMsg060.qualityGeometryExt			= ((data[5] & 0xFF) >> 0);

			psdMsg060.regionQualiGeometry			= ((data[4] & 0x0E) >> 1);
			psdMsg060.regionQualiPlaceInfo			= ((data[4] & 0x30) >> 4);
			psdMsg060.regionQualiAvailable			= ((data[4] & 0x40) >> 6);
			psdMsg060.regionQualiSpecialInfo		= ((data[6] & 0x07) >> 0);
			psdMsg060.regionQualiSlope				= ((data[6] & 0x38) >> 3);
			psdMsg060.regionQualiStreetLabel		= ((data[6] & 0xC0) >> 6) | ((data[7] & 0x01 << 2));
			psdMsg060.regionQualiSpeedLimit			= ((data[7] & 0x0E) >> 1);
			psdMsg060.regionQualiRightOfWayRules	= ((data[7] & 0x70) >> 4);
#endif

			psdInput.data.psd6.multiplex	= 0;
			psdInput.data.psd6.message.m0	= psdMsg060;
		}

		if((data[0] & 0x07) == 1) {
			PsdEhr_Psd61Message_t psdMsg061 = {0};

			psdMsg061.attributesSegmentId	= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg061.attribute1Type		= ((data[1] & 0x3E) >> 1);
			/* ALT:	psdMsg061.attribute1Value		= ((data[1] & 0xC0) >> 6) | ((data[2] & 0x03) << 2);*/
			/* ALT:	psdMsg061.attribute1Offset		= ((data[2] & 0xFC) >> 2) | ((data[3] & 0x01) << 6);*/
			psdMsg061.attribute1Value		= ((data[2] & 0xE0) >> 5) | ((data[3] & 0x01) << 3);/**< PSD_06.PSD_Attribut_3_Wert */
			psdMsg061.attribute1Offset		= ((data[1] & 0xC0) >> 6) | ((data[2] & 0x1F) << 2);/**< PSD_06.PSD_Attribut_3_Offset */
			psdMsg061.attribute2Type		= ((data[3] & 0x3E) >> 1);
			psdMsg061.attribute2Value		= ((data[3] & 0xC0) >> 6) | ((data[4] & 0x03) << 2);
			psdMsg061.attribute2Offset		= ((data[4] & 0xFC) >> 2) | ((data[5] & 0x01) << 6);
			psdMsg061.attribute3Type		= ((data[5] & 0x3E) >> 1);
			/* ALT:	psdMsg061.attribute3Value		= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x03) << 2);*/
			/* ALT:	psdMsg061.attribute3Offset		= ((data[6] & 0xFC) >> 2) | ((data[7] & 0x01) << 6);*/
			psdMsg061.attribute3Value		= ((data[6] & 0xE0) >> 5) | ((data[7] & 0x01) << 3);/**< PSD_06.PSD_Attribut_5_Wert */
			psdMsg061.attribute3Offset		= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x1F) << 2);/**< PSD_06.PSD_Attribut_5_Offset */
			psdMsg061.completeFlag			= ((data[7] & 0x02) >> 1);

			psdInput.data.psd6.multiplex	= 1;
			psdInput.data.psd6.message.m1	= psdMsg061;
		}

		if((data[0] & 0x07) == 2) {
			PsdEhr_Psd62Message_t psdMsg062;

			psdMsg062.id							= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg062.offset						= ((data[1] & 0xFE) >> 1);
			psdMsg062.speedLimit					= ((data[2] & 0x1F) >> 0);
			psdMsg062.type							= ((data[2] & 0x60) >> 5);
			psdMsg062.constraintLane				= ((data[2] & 0x80) >> 7) | ((data[3] & 0x1F) << 1);
			psdMsg062.constraintTrailer				= ((data[3] & 0x60) >> 5);
			psdMsg062.constraintWeather				= ((data[3] & 0x80) >> 7) | ((data[4] & 0x01) << 1);
			psdMsg062.constraintWeekDayStart		= ((data[4] & 0x0E) >> 1);
			psdMsg062.constraintWeekDayEnd			= ((data[4] & 0x70) >> 4);
			psdMsg062.constraintHourStart			= ((data[4] & 0x80) >> 7) | ((data[5] & 0x0F) << 1);
			psdMsg062.constraintHourEnd				= ((data[5] & 0xF0) >> 4) | ((data[6] & 0x01) << 4);
			psdMsg062.noPassingSign					= ((data[6] & 0x06) >> 1);
			psdMsg062.variableMessageSign			= ((data[6] & 0x38) >> 3);
			psdMsg062.variableMessageSignType		= ((data[6] & 0xC0) >> 6);
			psdMsg062.constraintLegalStreetClass	= ((data[7] & 0x07) >> 0);
			psdMsg062.constraintLegalAddition		= ((data[7] & 0x18) >> 3);/**< PSD_06.PSD_Ges_Gesetzlich_Zusatz */
			psdMsg062.sourceSpeedLimit				= ((data[7] & 0x60) >> 5);/**< PSD_06.PSD_Ges_Verkehrszeichen_Quelle */		
			psdMsg062.completeFlag					= ((data[7] & 0x80) >> 7);

			psdInput.data.psd6.multiplex	= 2;
			psdInput.data.psd6.message.m2	= psdMsg062;
		}

		if((data[0] & 0x07) == 3) {
			PsdEhr_Psd63Message_t psdMsg063;

			psdMsg063.longitudeSign				= ((data[0] & 0x08) >> 3);
			psdMsg063.longitude					= ((data[0] & 0xF0) >> 4) | ((data[1] & 0xFF) << 4) | ((data[2] & 0xFF) << 12) | ((data[3] & 0x1F) << 20);
			psdMsg063.latitudeSign				= ((data[3] & 0x10) >> 4);
			psdMsg063.latitude					= ((data[3] & 0xC0) >> 6) | ((data[4] & 0xFF) << 2) | ((data[5] & 0xFF) << 10) | ((data[6] & 0x3F) << 18);
			psdMsg063.direction					= ((data[6] & 0xC0) >> 6) | ((data[7] & 0xFF) << 2);

			psdInput.data.psd6.multiplex	= 3;
			psdInput.data.psd6.message.m3	= psdMsg063;
		}

		if((data[0] & 0x07) == 4) {
			PsdEhr_Psd64Message_t psdMsg064;

			psdMsg064.segment1Id			= ((data[0] & 0xF8) >> 3) | ((data[1] & 0x01) << 5);
			psdMsg064.segment1Slope1Value	= ((data[1] & 0xFE) >> 1);
			psdMsg064.segment1Slope1Sign	= ((data[2] & 0x01) >> 0);
			psdMsg064.segment1Slope1Offset	= ((data[2] & 0xFE) >> 1);
			psdMsg064.segment1Slope2Value	= ((data[3] & 0x7F) >> 0);
			psdMsg064.segment1Slope2Sign	= ((data[3] & 0x80) >> 7);
			psdMsg064.segment1Slope2Offset	= ((data[4] & 0x7F) >> 0);
			psdMsg064.segment1CompleteFlag	= ((data[4] & 0x80) >> 7);
			psdMsg064.segment2Id			= ((data[5] & 0x3F) >> 0);
			psdMsg064.segment2Slope1Value	= ((data[5] & 0xC0) >> 6) | ((data[6] & 0x1F) << 2);
			psdMsg064.segment2Slope1Sign	= ((data[6] & 0x20) >> 5);
			psdMsg064.segment2Slope1Offset	= ((data[6] & 0xC0) >> 6) | ((data[7] & 0x1F) << 2);
			psdMsg064.segment2CompleteFlag	= ((data[7] & 0x20) >> 5);

			psdInput.data.psd6.multiplex	= 4;
			psdInput.data.psd6.message.m4	= psdMsg064;
		}
	}

	this->Submit("psdInput", &psdInput, sizeof(psdInput_T));
}
