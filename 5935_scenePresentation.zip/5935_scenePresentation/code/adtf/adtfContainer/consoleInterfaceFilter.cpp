#include "stdafx.h"
#include "consoleInterfaceFilter.h"


consoleInterfaceFilter_T::consoleInterfaceFilter_T(const tChar* __info) : baseFilter_T(__info)
{
	this->AddInputPin("consoleLog", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_UINT8);
}


void	consoleInterfaceFilter_T::OnReceive(void)
{
	inputPin_T *consoleLog = this->GetInputPin("consoleLog");

	if(consoleLog->Unflag()) {
		this->EnterMutex();

		char_T *message = (char_T*)consoleLog->GetDataPtr();

		/* Sicherstellen, dass die Nachricht NULL-terminiert ist */
		if(consoleLog->GetDataSize() == 0 || message[consoleLog->GetDataSize()-1] != '\0') {
			LOG_ERROR("Illegal console message");
		}
		else {
			if(message[0] == 'I') {
				LOG_INFO(message+1);
			}
			else if(message[0] == 'W') {
				LOG_WARNING(message+1);
			}
			else if(message[0] == 'E') {
				LOG_ERROR(message+1);
			}
			else {
				LOG_INFO(message);
			}
		}

		this->LeaveMutex();
	}
}