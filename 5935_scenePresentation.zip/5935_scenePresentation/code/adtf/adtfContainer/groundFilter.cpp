#include "stdafx.h"
#include "groundFilter.h"


#undef GetObject


groundFilter_T::groundFilter_T(void)
{
	this->mutex.Create();
}


groundFilter_T::~groundFilter_T()
{
	this->mutex.Release();
}


void	groundFilter_T::Cleanup()
{
	this->ReleasePins();

	for(std::map<std::string, inputPin_T*>::iterator it = this->inputPins.begin(); it != this->inputPins.end(); it++) {
		delete it->second;
	}

	for(std::map<std::string, outputPin_T*>::iterator it = this->outputPins.begin(); it != this->outputPins.end(); it++) {
		delete it->second;
	}
}


tResult	groundFilter_T::Init(adtf::cFilter::tInitStage eStage, IPinEventSink *pinEventSink, __exception)
{
	if (eStage == adtf::cFilter::StageFirst)
	{
		/* Alle Input-Pins registrieren */
		for(std::map<std::string, inputPin_T*>::iterator it = this->inputPins.begin(); it != this->inputPins.end(); it++) {
			this->RegisterPin(it->second->Create(it->first.c_str(), pinEventSink));

			if(it->second->SignalsPossible()) {
				this->SetPropertyBool(std::string(std::string("provideSignals::in::") + it->first).c_str(), this->GetPropertyBool(std::string(std::string("provideSignals::in::") + it->first).c_str(), tFalse));
			}
		}

		/* Alle Output-Pins registrieren */
		for(std::map<std::string, outputPin_T*>::iterator it = this->outputPins.begin(); it != this->outputPins.end(); it++) {
			this->RegisterPin(it->second->Create(it->first.c_str()));
		
			if(it->second->SignalsPossible()) {
				this->SetPropertyBool(std::string(std::string("provideSignals::out::") + it->first).c_str(), this->GetPropertyBool(std::string(std::string("provideSignals::out::") + it->first).c_str(), tFalse));
			}
		}


		if(!this->OnInitFirst()) {
			RETURN_ERROR(ERR_CANCELLED);
		}
	}
	else if (eStage == adtf::cFilter::StageNormal)
	{
		/* Initialisieren der ADTF Signalschnittstelle */
		THROW_IF_FAILED(this->signalLock.Create());
		RETURN_IF_FAILED(_runtime->GetObject(OID_ADTF_SIGNAL_REGISTRY, IID_ADTF_SIGNAL_REGISTRY_EXTENDED, (tVoid**) &this->signalRegistry, __exception_ptr));
		RETURN_IF_FAILED(this->signalRegistry->RegisterProvider(this, OIGetInstanceName(), __exception_ptr));

		this->nextSignal = 0;

		for(std::map<std::string, inputPin_T*>::iterator it = this->inputPins.begin(); it != this->inputPins.end(); it++) {
			if(this->GetPropertyBool(std::string(std::string("provideSignals::in::") + it->first).c_str())) {
				this->inSignalOffset[it->first] = this->nextSignal;
				it->second->RegisterSignals(this, it->first.c_str());
			}
		}

		for(std::map<std::string, outputPin_T*>::iterator it = this->outputPins.begin(); it != this->outputPins.end(); it++) {
			if(this->GetPropertyBool(std::string(std::string("provideSignals::out::") + it->first).c_str())) {
				this->outSignalOffset[it->first] = this->nextSignal;
				it->second->RegisterSignals(this, it->first.c_str());
			}
		}

		this->signalBuffer.resize(this->nextSignal);

		if(!this->OnInitNormal()) {
			RETURN_ERROR(ERR_CANCELLED);
		}
	}
	else if (eStage == adtf::cFilter::StageGraphReady) 
	{
		if(!this->OnGraphReady()) {
			RETURN_ERROR(ERR_CANCELLED);
		}
	}
	
	RETURN_NOERROR;
}


tResult	groundFilter_T::Shutdown(adtf::cFilter::tInitStage eStage, __exception)
{
	if (eStage == adtf::cFilter::StageFirst) {
		this->OnShutdownFirst();
	}
	else if(eStage == adtf::cFilter::StageNormal) {
		this->OnShutdownNormal();

		/* Alle aktiven Timer l�schen */
		for(std::map<int, tHandle>::iterator it = this->timers.begin(); it != this->timers.end(); it++) {
			this->groundKernel->TimerDestroy(it->second);
			it->second = 0;
		}

		/* Liste Timer leeren */
		this->timers.clear();


		/* Wir melden uns als Signal Provider ab */
		this->signalRegistry->UnregisterSignalProvider(this);
		this->activeSignals.clear();
		this->signalLock.Release();
		this->signalBuffer.clear();
	}
	else if(eStage == adtf::cFilter::StageGraphReady) {
	}


	RETURN_NOERROR;
}


tResult	groundFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	bool hasFired = false;

	if (nEventCode == IPinEventSink::PE_MediaSampleReceived) {
		/* Bei allen Pins klingeln und fragen, ob das hier ihr Sample ist... */
		for(std::map<std::string, inputPin_T*>::iterator it = this->inputPins.begin(); it != this->inputPins.end(); it++) {
			if(it->second->OnReceive(pSource, pMediaSample)) {
				it->second->UpdateSignals(this, it->second->GetDataPtr(), it->second->GetDataSize(), this->inSignalOffset[it->first]);

				hasFired = true;

				this->OnReceive();
				it->second->LeaveMutex();
			}
		}

		if(!hasFired) {
			this->OnReceive();
		}
	}

	RETURN_NOERROR;
}


tResult	groundFilter_T::Run(tInt nActivationType, const tVoid* pvUserData, tInt szUserDataSize, __exception)
{
	if(nActivationType == IRunnable::RUN_TIMER) {
		this->OnTimer((int)pvUserData);
	}
	else {
		this->OnRun(nActivationType, pvUserData, szUserDataSize);
	}

	RETURN_NOERROR;
}


tResult	groundFilter_T::Start(__exception)
{
	if(!this->OnStart()) {
		RETURN_ERROR(ERR_CANCELLED);
	}

	RETURN_NOERROR;
}


tResult	groundFilter_T::Stop(__exception)
{
	if(!this->OnStop()) {
		RETURN_ERROR(ERR_CANCELLED);
	}

	RETURN_NOERROR;
}


void	groundFilter_T::RegisterKernel(adtf::IKernel *kernel)
{
	this->groundKernel = kernel;
}


bool	groundFilter_T::AddTimer(int id, int cycleTime)
{
	this->timers[id] = this->groundKernel->TimerCreate((tTimeStamp)(cycleTime * 1000.0f), 0, static_cast<IRunnable*>(this), NULL, (tVoid*)id, 0, IKernel::TI_REALTIME_PRIORITY | IKernel::TI_CLOCK_MONOTONIC);

	if(!this->timers[id]) {
		LOG_ERROR("Unable to create timer.");
		return false;
	}

	return true;
}


bool	groundFilter_T::RemoveTimer(int id)
{
	/* Timer l�schen */
	this->groundKernel->TimerDestroy(timers[id]);
	timers.erase(id);

	return true;
}


void	groundFilter_T::AddInputPin(std::string name, const pinHeader_T &header)
{
	this->inputPins[name] = new inputPin_T(header);
}


void	groundFilter_T::AddInputPin(std::string name, std::string type, size_t size)
{
	this->inputPins[name] = new inputPin_T(type, size);
}


void	groundFilter_T::AddInputPin(std::string name, uint32_T majorType, uint32_T subType)
{
	this->inputPins[name] = new inputPin_T(majorType, subType);
}


void	groundFilter_T::AddInputPin(std::string name, uint32_T majorType, uint32_T subType, size_t size)
{
	this->inputPins[name] = new inputPin_T(majorType, subType, size);
}


void	groundFilter_T::AddInputPin(std::string name)
{
	this->inputPins[name] = new inputPin_T();
}


inputPin_T *groundFilter_T::GetInputPin(std::string name)
{
	return this->inputPins[name];
}


void	groundFilter_T::AddOutputPin(std::string name, const pinHeader_T &header)
{
	this->outputPins[name] = new outputPin_T(header);
}


void	groundFilter_T::AddOutputPin(std::string name, std::string type, size_t size)
{
	this->outputPins[name] = new outputPin_T(type, size);
}


void	groundFilter_T::AddOutputPin(std::string name, uint32_T majorType, uint32_T subType)
{
	this->outputPins[name] = new outputPin_T(majorType, subType);
}


void	groundFilter_T::AddOutputPin(std::string name)
{
	this->outputPins[name] = new outputPin_T();
}


void	groundFilter_T::EnterMutex(void)
{
	this->mutex.Enter();
}


void	groundFilter_T::LeaveMutex(void)
{
	this->mutex.Leave();
}


void	groundFilter_T::OnReceive(void)
{
}


void	groundFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
}


bool	groundFilter_T::OnInitFirst(void)
{
	return true;
}


bool	groundFilter_T::OnInitNormal(void)
{
	return true;
}


bool	groundFilter_T::OnGraphReady(void)
{
	return true;
}


bool	groundFilter_T::OnStart(void)
{
	return true;
}


bool	groundFilter_T::OnStop(void)
{
	return true;
}


void	groundFilter_T::OnShutdownFirst(void)
{
}


void	groundFilter_T::OnShutdownNormal(void)
{
}


void	groundFilter_T::OnTimer(int id)
{
}


void	groundFilter_T::ShowErrorBox(const char *text, const char *title)
{
	cObjectPtr<IXApplication> application;
	tResult result = _runtime->GetObject(OID_ADTF_APPLICATION, IID_ADTF_XAPPLICATION, (tVoid**)&application);
	
	if(IS_OK(result)) {
		adtf_graphics::IMessageBox* messageBox = NULL;

		if(messageBox != NULL) {
			tUInt32 boxResult = 0;

			messageBox->Message( adtf_graphics::IMessageBox::AMBT_Error,
								 title,
								 text,
								 adtf_graphics::IMessageBox::AMB_OK,
								&boxResult);
		}
	}
}


tResult	groundFilter_T::Submit(std::string pinName, void *data, size_t size) 
{
	cObjectPtr<IMediaSample> sample;

	RETURN_IF_FAILED(this->AllocMediaSample(&sample, NULL));
	RETURN_IF_FAILED(sample->Update(this->GetStreamTime(), data, (tInt)size, 0));

	RETURN_IF_FAILED(this->outputPins[pinName]->Submit(sample));

	this->outputPins[pinName]->UpdateSignals(this, data, size, this->outSignalOffset[pinName]);

	RETURN_NOERROR;
}


void	groundFilter_T::RegisterSignal(const char *name)
{
	std::string adjName(name);
	size_t pos;

	while(adjName.npos != (pos = adjName.find("::"))) {
		adjName = adjName.replace(pos, 2, "/");
	}

	this->signalRegistry->RegisterSignal(this, this->nextSignal++, adjName.c_str(), "", "", 0.0, 1.0);
}


void	groundFilter_T::UpdateSignal(tSignalID id, real64_T value)
{
	this->signalLock.Enter();

	if(this->activeSignals.end() != this->activeSignals.find(id)) {
		tSignalValue signalValue = {0};

		signalValue.f64Value	= value;
		signalValue.nTimeStamp	= this->GetStreamTime();
		this->signalRegistry->UpdateSignal(this, id, signalValue);
	}

	this->signalBuffer[id] = value;

	this->signalLock.Leave();
}


tResult	groundFilter_T::GetSignalValue(tSignalID nSignalID, tSignalValue *pValue)
{
	if (nSignalID < 0 || nSignalID >= this->nextSignal) {
		RETURN_ERROR(ERR_NOT_FOUND);
	}

	pValue->f64Value		= this->signalBuffer[nSignalID];
	pValue->nRawValue		= 0;
	pValue->nTimeStamp		= 0;
	pValue->strTextValue	= "";

	RETURN_NOERROR;
}


tResult	groundFilter_T::ActivateSignalEvents(tSignalID nSignalID, tTimeStamp nUpdateRate)
{
	if (nSignalID < 0 || nSignalID >= this->nextSignal) {
		RETURN_ERROR(ERR_NOT_FOUND);
	}

	this->signalLock.Enter();
	this->activeSignals.insert(nSignalID);
	this->signalLock.Leave();

	RETURN_NOERROR;
}


tResult	groundFilter_T::DeactivateSignalEvents(tSignalID nSignalID)
{
	if (nSignalID < 0 || nSignalID >= this->nextSignal) {
		RETURN_ERROR(ERR_NOT_FOUND);
	}

	this->signalLock.Enter();
	this->activeSignals.erase(nSignalID);
	this->signalLock.Leave();

	RETURN_NOERROR;
}
