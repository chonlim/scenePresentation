#ifndef guard_baseFilter_h
#define guard_baseFilter_h

#include "../adtfFilter.h"
#include "groundFilter.h"


class baseFilter_T
  : public adtf::cFilter,
	public groundFilter_T
{
public:
	baseFilter_T(const tChar* __info);
	~baseFilter_T(void);

	virtual tResult	Init(tInitStage eStage, __exception = NULL);
	virtual tResult	Shutdown(tInitStage eStage, __exception = NULL);

	virtual tResult	OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);

	virtual tResult	Start(__exception = NULL);
	virtual tResult Stop(__exception = NULL);

	tResult			GetInterface(const tChar* idInterface, tVoid** ppvObject);
	tUInt			Ref();
	tUInt			Unref();
	tVoid			Destroy();

	tTimeStamp		GetStreamTime();
	tBool			GetPropertyBool(const tChar* strName, tBool bDefault = tFalse);
	tResult			AllocMediaSample(IMediaSample** ppMediaSample, ucom::IException** __exception_ptr=NULL);
	const tChar*	OIGetInstanceName();
	tResult			RegisterPin(IPin* pIPin);
	tResult			ReleasePins(void);
	tResult			SetPropertyBool(const tChar* strName, tBool bValue);

	virtual tResult	PropertyChanged(const tChar *strName);
	virtual void	OnPropertyChange(const char_T *name);
};

#endif
