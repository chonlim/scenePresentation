#ifndef guard_inputPin_h
#define guard_inputPin_h

#include <string>

#include "../adtfFilter.h"
#include "signalPin.h"


class inputPin_T
  : public signalPin_T
{
private:
	cInputPin			 adtfPin;
	cKernelMutex		 mutex;

	uint32_T			 majorType;
	uint32_T			 subType;

	uint8_T				*dataBuffer;
	size_t				 dataSize;
	size_t				 maxSize;
	bool				 sizeFixed;
	tTimeStamp			 timeStamp;

	bool				 flagged;
	bool				 autoLock;

public:
	inputPin_T(const pinHeader_T &header);
	inputPin_T(std::string typeName, size_t typeSize);
	inputPin_T(uint32_T majorType, uint32_T subType);
	inputPin_T(uint32_T majorType, uint32_T subType, size_t typeSize);
	inputPin_T(void);

	~inputPin_T();

	cInputPin*		Create(const char *name, IPinEventSink *eventSink);

	void			EnterMutex(void);
	void			LeaveMutex(void);

	bool			OnReceive(IPin* pSource, IMediaSample *pMediaSample);

	bool			IsConnected(void);
	bool			IsFlagged(void);
	bool			Unflag(void);

	void*			GetDataPtr(void);
	size_t			GetDataSize(void);
	tTimeStamp		GetTimeStamp(void);

	void			SetAutoLock(bool autoLock);
};


#endif
