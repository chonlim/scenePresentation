#ifndef guard_traceDataConverterFilter_h
#define guard_traceDataConverterFilter_h

#include "baseFilter.h"
#include "common/swcCommunication/swcComm_adtfTools.h"


#define ADTF_FILTER_ID_traceDataConverterFilter		"IDII.traceDataConverterFilter"
#define ADTF_FILTER_NAME_traceDataConverterFilter	"IDII traceDataConverterFilter"


#include "control/controlTask/controlTask_adtfTools.h"


class traceDataConverterFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_traceDataConverterFilter, ADTF_FILTER_NAME_traceDataConverterFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__);

private:
	

public:
	traceDataConverterFilter_T(const tChar* __info);

	bool		OnInitNormal(void);
	void		OnReceive(void);


private:


};

#endif
