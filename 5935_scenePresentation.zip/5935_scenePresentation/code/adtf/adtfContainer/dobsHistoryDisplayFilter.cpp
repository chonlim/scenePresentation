#include "stdafx.h"
#include "dobsHistoryDisplayFilter.h"

#include "Algorithmus/common/vehicleObserverCommon/vehicleObserver_adtfTools.h"
#include "Algorithmus/common/vehicleModel/vehicleModel_adtfTools.h"
#include "Algorithmus/common/swcCommunication/swcComm_adtfTools.h"
#include "Algorithmus/control/controlTask/controlTask_adtfTools.h"
#include "Algorithmus/strategy/strategyTask/strategyTask_adtfTools.h"

extern "C" {
	#include "Algorithmus/common/platformInterface/pltfDiag.h"
}

#include "psdChannel_adtfTools.h"

#undef GetObject

#define		def_minPosition		-100.0f
#define		def_maxPosition		 400.0f
#define		def_minVelocity		   0.0f
#define		def_maxVelocity		  50.0f
#define		def_minAcceleration	  -4.0f
#define		def_maxAcceleration	   4.0f

extern bool_T	globalToggle;


#pragma warning(disable : 4355)


typedef struct canMessage_tag {
	int16_T		id;
	uint8_T		channel;
	uint8_T		length;
	uint8_T		data[8];
} canMessage_T;


dobsHistoryDisplayFilter_T::dobsHistoryDisplayFilter_T(const tChar* __info)
  : displayFilter_T(__info, def_minPosition, def_maxPosition, def_minVelocity, def_maxVelocity, def_minAcceleration, def_maxAcceleration)
{
	this->AddInputPin("vehicleModel",	vehicleModel_header());
	this->AddInputPin("flexray",		MEDIA_TYPE_FLEXRAY,			MEDIA_SUBTYPE_FLEXRAY);
	this->AddInputPin("traceData",		MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);

	this->inputPin_vehicleModel			= this->GetInputPin("vehicleModel");
	this->inputPin_flexray				= this->GetInputPin("flexray");
	this->inputPin_traceData			= this->GetInputPin("traceData");

	// this->obsHistoryProcessor.SetEventCallback(&this->EventCallback, nullptr);

	// this->obsHistoryProcessor.SetCallback(this);

	this->lastToggle = false;
}


bool	dobsHistoryDisplayFilter_T::OnInitNormal(void)
{
	this->obsHistoryProcessor.Init(NULL);

	this->obsHistoryProcessor.mainControl.graph.SetYWindow(this->obsHistoryProcessor.mainControl.graph.GetYWindow());

	this->shutdown = false;
	this->flagged.Create();
	cKernelCyclicThread::Create();

	return true;
}


bool	dobsHistoryDisplayFilter_T::OnGraphReady(void)
{
	/* Wenn der Flexray-Pin verbunden ist, fragen wir die Fibex-Datenbank nach den IDs f�r die PSD-PDUs */
	do {
		if(this->inputPin_flexray->IsConnected()) {
			cObjectPtr<adtf_devicetb::IFlexRaySupport> flexrayService;
			if(IS_FAILED(_runtime->GetObject(OID_ADTF_FLEXRAY_SUPPORT, IID_ADTF_FLEXRAY_SUPPORT, (tVoid**) &flexrayService))) {
				LOG_ERROR("No FlexRay support service available");
				break;
			}


			cObjectPtr<adtf_devicetb::IFIBEXDatabase> fibexDB;
			if(IS_FAILED(flexrayService->GetFIBEXDatabase(&fibexDB))) {
				LOG_ERROR("Failed to get FIBEX database");
				break;
			}


			/* Abfragen der IDs f�r die PDUs, die uns interessieren.
			   Die "normale" ID-Abfrage funktioniert irgendwie nicht... */
			tUInt32 count;
			fibexDB->GetPDUCount(&count);

			for(tUInt32 i = 0; i < count; i++) {
				const tChar *name;
				fibexDB->GetPDUName(i, &name);

				if (!strcmp(name, "PIF_01"))	{ this->idPIF_01 = i; }
			}


			cObjectPtr<adtf_devicetb::IFlexRayCoder> coder;
			if(IS_FAILED(flexrayService->CreateCoder(&coder))) {
				LOG_ERROR("Failed to create FlexRay coder");
				break;
			}
			
			fibexDB->GetSignalID("PIF_Identifier",			&this->idPIF_Identifier);
			

			/* Die Flexray-Event sollen an der groundFilter und von dort wieder zur�ck an uns gehen */
			this->flexrayCoder = coder;
			this->flexrayCoder->SetListener((groundFilter_T*)this);

			/* Wir h�ren auf die drei PSD-PDUs */
			this->flexrayCoder->ActivePDUEvents(this->idPIF_01);
		}
	} while(false);


	return true;
}


void	dobsHistoryDisplayFilter_T::OnShutdownNormal(void)
{
	/* Zyklischen Thread abbrechen */
	this->shutdown = true;
	this->flagged.Set();
	cKernelCyclicThread::Release();
	this->flagged.Release();

	if(this->flexrayCoder) {
		/* Abmelden vom FlexRay-Coder */
		this->flexrayCoder->SetListener(NULL);
	}
}


void	dobsHistoryDisplayFilter_T::OnReceive(void)
{
	if (this->inputPin_flexray->Unflag()) {
		if (this->flexrayCoder) {
			/* Daten an der FlexRay-Coder weiterleiten */
			this->flexrayCoder->ReceiveData(this->inputPin_flexray->GetDataPtr(),
				(tInt)this->inputPin_flexray->GetDataSize(),
				this->inputPin_flexray->GetTimeStamp());
		}
	}

	if (this->inputPin_traceData->Unflag()) {
		Dt_RECORD_TraceData *traceData;

		size_t dynamicSetListPos = 0;
		size_t dynamicSetListSize = sizeof(dynamicSetList_T); /* 168 Bytes */

		size_t environmentStatePos = dynamicSetListPos + dynamicSetListSize;
		size_t environmentStateSize = sizeof(environmentState_T); /* 16 Bytes */

		size_t desiredSpeedPos = environmentStatePos + environmentStateSize;
		size_t desiredSpeedSize = sizeof(real32_T); /* 4 Bytes */

		size_t maxVelocityPos = desiredSpeedPos + desiredSpeedSize;
		size_t maxVelocitySize = sizeof(maxVelocity_T); /* 8 Bytes */

		size_t nextLimitInfoPos = maxVelocityPos + maxVelocitySize;
		size_t nextLimitInfoSize = sizeof(dobsNextLimitInfo_T); /* 12 Bytes */

		traceData = (Dt_RECORD_TraceData *)this->inputPin_traceData->GetDataPtr();

		memcpy(&this->driverState.dynamicSetList, &traceData->DeData[dynamicSetListPos], dynamicSetListSize);
		memcpy(&this->driverState.environmentState, &traceData->DeData[environmentStatePos], environmentStateSize);
		memcpy(&this->driverState.velocitySet.desiredSpeed.value, &traceData->DeData[desiredSpeedPos], desiredSpeedSize);
		memcpy(&this->driverState.maxVelocity,&traceData->DeData[maxVelocityPos], maxVelocitySize);
		memcpy(&this->driverState.nextLimitInfo,&traceData->DeData[nextLimitInfoPos], nextLimitInfoSize);
	}
}


void	dobsHistoryDisplayFilter_T::OnRun(int32_T type, const void *data, size_t size)
{
	/* Eine unserer PDUs ist da! */
	if(type == adtf_devicetb::RUN_CODER_PDU_EVENT) {
		adtf_devicetb::tCoderPDUEvent *coderEvent = (adtf_devicetb::tCoderPDUEvent*)data;
		if(!coderEvent) { return; }

		if(coderEvent->nPayloadLength == 8) {
			if(coderEvent->nPDUID == this->idPIF_01) {
				adtf_devicetb::tSignalValue		PIF_Identifier;
				
				this->flexrayCoder->GetSignalValue(this->idPIF_Identifier, &PIF_Identifier);

				this->tickCount++;
				
				this->Process();
			}
		}
	}
}


tResult	dobsHistoryDisplayFilter_T::OnSize(tHandle hCanvas, tInt nLeft, tInt nTop, tInt nRight, tInt nBottom)
{
	RETURN_IF_FAILED(displayFilter_T::OnSize(hCanvas, nLeft, nTop, nRight, nBottom));

	this->obsHistoryProcessor.Reshape(0, 0, nRight-nLeft+1, nBottom-nTop+1);

	RETURN_NOERROR;
}


tResult	dobsHistoryDisplayFilter_T::OnTimer(tHandle hCanvas)
{
	displayFilter_T::OnTimer(hCanvas);

	RETURN_NOERROR;
}


tResult	dobsHistoryDisplayFilter_T::OnControlEvent(tControlEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags, tVoid* pEventData)
{
	Invalidate(tTrue);

	RETURN_IF_FAILED(displayFilter_T::OnControlEvent(eCode, nParam1, nParam2, nFlags, pEventData));

	RETURN_NOERROR;
}

void	dobsHistoryDisplayFilter_T::Process(void)
{
	static real32_T	timeOF = 0.0f;

	real32_T time = 0.0f;
	time = this->tickCount * 0.08f;
	if (time < timeOF){
		time = time + timeOF;
	}
	timeOF = time;

	this->obsHistoryProcessor.Process(&this->driverState, time);
}

tResult	dobsHistoryDisplayFilter_T::CyclicFunc()
{
	if(!this->shutdown) {
		this->flagged.Wait(2000);
	}

	RETURN_NOERROR;
}


void	dobsHistoryDisplayFilter_T::ForceUpdate(void)
{
	this->Invalidate(tTrue);
}



void	dobsHistoryDisplayFilter_T::PushControl(graphControl_T *control)
{
	this->AssignControl(control);
	this->pageValid = false;
}