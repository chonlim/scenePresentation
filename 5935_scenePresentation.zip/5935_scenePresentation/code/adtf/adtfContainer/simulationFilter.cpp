#include "stdafx.h"
#include "simulationFilter.h"

#include "base.h"

#include "control/controlTask/controlTask_adtfTools.h"
#include "control/outputCodec/outputCodec_adtfTools.h"
#include "common/vehicleModel/vehicleModel_adtfTools.h"
#include "simulation/vehicleSimulation/vehicleSimulation_adtfTools.h"
#include "control/inputCodec/inputCodec_adtfTools.h"
#include "simulation/vehicleSimulation/vehicleSimulation.h"


simulationFilter_T::simulationFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddInputPin("trigger", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_STRUCTURED);
	
	this->AddInputPin("flexrayOutput",		flexrayOutput_header());
	this->AddInputPin("vehicleModel",		vehicleModel_header());
	this->AddInputPin("positionRecord",		MEDIA_TYPE_STRUCTURED_DATA,		0);
	this->AddInputPin("psdInput",			MEDIA_TYPE_STRUCTURED_DATA,		0);

	this->AddOutputPin("vehicleSimulation",	vehicleSimulation_header());
	this->AddOutputPin("flexrayInput",		flexrayInput_header());
	this->AddOutputPin("emlInput",			emlInput_header());
	this->AddOutputPin("laneInput",			laneInput_header());
	this->AddOutputPin("vzeInput",			vzeInput_header());
	this->AddOutputPin("obfInput",			obfInput_header());
	this->AddOutputPin("lapInput",			lapInput_header());
	this->AddOutputPin("codingInput",		codingInput_header());
	this->AddOutputPin("fodInput",			fodInput_header());
	this->AddOutputPin("psdOutput",			MEDIA_TYPE_STRUCTURED_DATA,		0);
	this->AddOutputPin("controlTrigger");

	this->SetPropertyStr("replayFile", "$(WORK_PATH)\\replay\\B10 Runde.replay");
	this->SetPropertyBool("replayFile" NSSUBPROP_FILENAME, tTrue);
}


void	simulationFilter_T::OnReceive(void)
{
	if(this->GetInputPin("trigger")->Unflag()) {
		this->RunAlgorithm();
	}

	if(this->GetInputPin("psdInput")->Unflag()) {
		if(this->GetInputPin("psdInput")->GetDataSize() == sizeof(psdInput_T)) {
			this->QueueMessage((psdInput_T*)this->GetInputPin("psdInput")->GetDataPtr());
		}
	}
}


bool	simulationFilter_T::OnInitNormal(void)
{
	memset(&this->vehicleSimulation,	0,	sizeof(vehicleSimulation_T));
	memset(&this->psdBuffer,			0,	sizeof(this->psdBuffer));

	vsimSimulationInit( 0.0f,
					    0.0f,
					   &this->vehicleSimulation);

	return true;
}


void	simulationFilter_T::QueueMessage(psdInput_T *psdInput)
{
	this->EnterMutex();

	/* Wenn in der Warteschlage noch Platz ist, wird die PSD-Botschaft angeh�ngt */
	if(this->psdBuffer.count < simPSDMESSAGECOUNT) {
		uint16_T index = (uint16_T)((this->psdBuffer.offset + this->psdBuffer.count) % simPSDMESSAGECOUNT);

		this->psdBuffer.psdInput[index] = *psdInput;
		this->psdBuffer.count++;
	}

	this->LeaveMutex();
}


void	simulationFilter_T::RunAlgorithm(void)
{
	this->EnterMutex();

	flexrayOutput_T		flexrayOutput		= *(flexrayOutput_T*)this->GetInputPin("flexrayOutput")->GetDataPtr();
	positionRecord_T	positionRecord		= *(positionRecord_T*)this->GetInputPin("positionRecord")->GetDataPtr();
	vehicleModel_T		vehicleModel		= *(vehicleModel_T*)this->GetInputPin("vehicleModel")->GetDataPtr();

	flexrayInput_T	flexrayInput	= {0};
	emlInput_T		emlInput		= {0};
	laneInput_T		laneInput		= {0};
	vzeInput_T		vzeInput		= {0};
	obfInput_T		obfInput		= {0};
	lapInput_T		lapInput		= {0};
	codingInput_T	codingInput		= {0};
	fodInput_T		fodInput		= {0};
	psdInput_T		psdInput		= {(psdMessageType_T)0};

	uint8_T			dummy			= 0;

	/* Wenn Nachrichten im Puffer vorhanden sind, wird die n�chste an die den Control-Task ausgeliefert */
	if(this->psdBuffer.count > 0) {
		uint16_T index = this->psdBuffer.offset;

#ifdef ID2FP_DEBUG
		memset(&psdInput, 0, sizeof(psdInput));
#endif

		psdInput				= this->psdBuffer.psdInput[index];

		this->psdBuffer.count--;
		this->psdBuffer.offset++;
		this->psdBuffer.offset %= simPSDMESSAGECOUNT;
	}

	this->LeaveMutex();


	vsimSimulationStep(&this->vehicleSimulation,
					   &flexrayOutput,
					   &vehicleModel,
					   &positionRecord,
					   &flexrayInput,
					   &emlInput,
					   &laneInput,
					   &vzeInput,
					   &obfInput,
					   &lapInput,
					   &codingInput,
					   &fodInput);

#ifdef ID2FP_DEBUG
	if (flexrayInput.DeLWI_VZ_Lenkradwinkel > 1)
		flexrayInput.DeLWI_VZ_Lenkradwinkel = 0;
	if (flexrayInput.DeLWI_VZ_Lenkradw_Geschw > 1)
		flexrayInput.DeLWI_VZ_Lenkradw_Geschw = 0;

	/* analog zu rteFRInnoDriveIn */
	flexrayInput.DeACC_Nutzung_VZ_PACC     = flexrayInput.DeACC_Nutzung_VZ_PACC != 0u;
	flexrayInput.DeACC_Regelung_durch_PACC = flexrayInput.DeACC_Regelung_durch_PACC != 0u;
	flexrayInput.DeBM_Autobahn             = flexrayInput.DeBM_Autobahn != 0u;
	flexrayInput.DeBM_links                = flexrayInput.DeBM_links != 0u;
	flexrayInput.DeBM_rechts               = flexrayInput.DeBM_rechts != 0u;
	flexrayInput.DeESP_QBit_HL_Bremsmoment = flexrayInput.DeESP_QBit_HL_Bremsmoment != 0u;
	flexrayInput.DeESP_QBit_HR_Bremsmoment = flexrayInput.DeESP_QBit_HR_Bremsmoment != 0u;
	flexrayInput.DeESP_QBit_VR_Bremsmoment = flexrayInput.DeESP_QBit_VR_Bremsmoment != 0u;
	flexrayInput.DeESP_QBit_VL_Bremsmoment = flexrayInput.DeESP_QBit_VL_Bremsmoment != 0u;
	flexrayInput.DeHAL_QBit_Radwinkel      = flexrayInput.DeHAL_QBit_Radwinkel != 0u;
	flexrayInput.DeHAL_VZ_Radwinkel        = flexrayInput.DeHAL_VZ_Radwinkel != 0u;
	flexrayInput.DeGRA_Tip_Hoch            = flexrayInput.DeGRA_Tip_Hoch != 0u;
	flexrayInput.DeGRA_Tip_Runter          = flexrayInput.DeGRA_Tip_Runter != 0u;
	flexrayInput.DeGRA_Tip_Setzen          = flexrayInput.DeGRA_Tip_Setzen != 0u;
	flexrayInput.DeGRA_Tip_Wiederaufnahme  = flexrayInput.DeGRA_Tip_Wiederaufnahme != 0u;
	flexrayInput.DeLWI_VZ_Lenkradwinkel    = flexrayInput.DeLWI_VZ_Lenkradwinkel != 0u;
	flexrayInput.DeLWI_VZ_Lenkradw_Geschw  = flexrayInput.DeLWI_VZ_Lenkradw_Geschw != 0u;
	flexrayInput.DeMO_HYB_VM_aktiv         = flexrayInput.DeMO_HYB_VM_aktiv != 0u;
	flexrayInput.DeCHA_EV_LED              = flexrayInput.DeCHA_EV_LED != 0u;

	/* analog zu rteVZE.c */
	vzeInput.VZE_Umweltinfo_Anhaengerbetrieb = vzeInput.VZE_Umweltinfo_Anhaengerbetrieb != 0u;
	vzeInput.VZE_Umweltinfo_Naesse           = vzeInput.VZE_Umweltinfo_Naesse != 0u;
	vzeInput.VZE_Umweltinfo_Nebel            = vzeInput.VZE_Umweltinfo_Nebel != 0u;
	vzeInput.VZE_Zeichen_01_Gesetz           = vzeInput.VZE_Zeichen_01_Gesetz != 0u;
	vzeInput.VZE_Zeichen_01_Kamera           = vzeInput.VZE_Zeichen_01_Kamera != 0u;
	vzeInput.VZE_Zeichen_01_Karte            = vzeInput.VZE_Zeichen_01_Karte != 0u;
#endif

	/* set validity flags (as if rte-wrapper provided valid data) */
	flexrayInput.DataValidFlag = 1;
	emlInput.DataValidFlag = 1;
	vzeInput.DataValidFlag = 1;
	laneInput.DataValidFlag = 1;
	/**\todo OBF-Daten als valid markieren*/

#ifdef ID2FP_DEBUG
	/* fast project filter needs 2 cycles for parameter initialization,
		do not send data during these two cycles
		(avoid problems of synchronization due to queuing of EML data) */
	static int input_delay = 2;
	if (input_delay > 0){
		input_delay--;
		return;
	}
#endif


	/* flexrayInput zuletzt ausliefern, da der controlFilter dar�ber getriggert wird */
	this->Submit("codingInput",			&codingInput,		sizeof(codingInput));
	this->Submit("obfInput",			&obfInput,			sizeof(obfInput));
	this->Submit("lapInput",			&lapInput,			sizeof(lapInput));
	this->Submit("vzeInput",			&vzeInput,			sizeof(vzeInput));
	this->Submit("emlInput",			&emlInput,			sizeof(emlInput));
	this->Submit("laneInput",			&laneInput,			sizeof(laneInput));
	this->Submit("vehicleSimulation",	&vehicleSimulation,	sizeof(vehicleSimulation));
	this->Submit("psdOutput",			&psdInput,			sizeof(psdInput));
	this->Submit("fodInput",			&fodInput,			sizeof(fodInput));
	this->Submit("flexrayInput",		&flexrayInput,		sizeof(flexrayInput));
	this->Submit("controlTrigger",		&dummy,				sizeof(dummy));
}


