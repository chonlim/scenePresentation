#ifndef guard_schedulerFilter_h
#define guard_schedulerFilter_h

#include "baseFilter.h"

#define ADTF_FILTER_ID_schedulerFilter		"IDII.schedulerFilter"
#define ADTF_FILTER_NAME_schedulerFilter	"IDII schedulerFilter"


class schedulerFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_schedulerFilter, ADTF_FILTER_NAME_schedulerFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:

public:
	schedulerFilter_T(const tChar* __info);

	bool		OnStart(void);
	bool		OnStop(void);

	void		OnTimer(int id);

	typedef enum timerID_tag {

		timerControl,
		timerStrategy
	} timerID_T;
};


#endif
