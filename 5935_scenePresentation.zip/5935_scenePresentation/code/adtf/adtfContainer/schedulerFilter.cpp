#include "stdafx.h"
#include "schedulerFilter.h"

#include "base.h"


schedulerFilter_T::schedulerFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddOutputPin("controlTrigger",		MEDIA_TYPE_STRUCTURED_DATA,		0);
	this->AddOutputPin("strategyTrigger",		MEDIA_TYPE_STRUCTURED_DATA,		0);
}


bool	schedulerFilter_T::OnStart(void)
{
	this->AddTimer(timerControl,	(int)(controlCYCLETIME		* 1000.0f));
	this->AddTimer(timerStrategy,	(int)(strategyCYCLETIME		* 1000.0f));

	return true;
}


bool	schedulerFilter_T::OnStop(void)
{
	this->RemoveTimer(timerControl);
	this->RemoveTimer(timerStrategy);

	return true;
}


void	schedulerFilter_T::OnTimer(int id)
{
	uint8_T	dummy = 0;

	if(id == timerControl) {
		this->Submit("controlTrigger", &dummy, sizeof(dummy));
	}
	else if(id == timerStrategy) {
		this->Submit("strategyTrigger", &dummy, sizeof(dummy));
	}
}
