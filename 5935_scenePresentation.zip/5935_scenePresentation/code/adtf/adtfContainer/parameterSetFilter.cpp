#include "stdafx.h"
#include "parameterSetFilter.h"

#include "base.h"
#include "control/parameterSet/ParameterSetCtrl_adtfTools.h"
#include "strategy/parameterSet/parameterSetStgy_adtfTools.h"

extern "C" {
#include "control/controlTask/iccDataInterface.h"
#include "strategy/strategyTask/icsDataInterface.h"
}


parameterSetFilter_T::parameterSetFilter_T(const tChar* __info)
  : baseFilter_T(__info)
{
	this->AddOutputPin("controlSet",			parameterSetCtrl_header());
	this->AddOutputPin("strategySet",			parameterSetStgy_header());

	this->armed = false;
}


bool	parameterSetFilter_T::OnInitNormal(void)
{
	iccBusInitParameterSet(&this->controlSet);
	iscBusInitParameterSet(&this->strategySet);

	parameterSetCtrl_header	controlHeader;
	parameterSetStgy_header	strategyHeader;

	controlHeader.ExploreMembers(&this->controlSet, this->CreateProperty_bool, this, "controlSet");
	controlHeader.ExploreMembers(&this->controlSet, this->CreateProperty_int,  this, "controlSet");
	controlHeader.ExploreMembers(&this->controlSet, this->CreateProperty_real, this, "controlSet");

	strategyHeader.ExploreMembers(&this->strategySet, this->CreateProperty_bool, this, "strategySet");
	strategyHeader.ExploreMembers(&this->strategySet, this->CreateProperty_int,  this, "strategySet");
	strategyHeader.ExploreMembers(&this->strategySet, this->CreateProperty_real, this, "strategySet");

	return true;
}


bool	parameterSetFilter_T::OnGraphReady(void)
{
	this->armed = true;

	return true;
}


void	parameterSetFilter_T::OnShutdownNormal(void)
{
	this->armed = false;
}


bool	parameterSetFilter_T::OnStart(void)
{
	this->Submit("controlSet", &this->controlSet, sizeof(this->controlSet));
	this->Submit("strategySet", &this->strategySet, sizeof(this->strategySet));

	return true;
}


void	parameterSetFilter_T::OnPropertyChange(const char_T *name)
{
	readContext_T	context;

	if(this->armed) {
		context.filter		= this;
		context.nameChanged	= name;

		parameterSetCtrl_header	controlHeader;
		parameterSetStgy_header	strategyHeader;

		controlHeader.ExploreMembers(&this->controlSet, this->ReadProperty_bool, &context, "controlSet");
		controlHeader.ExploreMembers(&this->controlSet, this->ReadProperty_int,  &context, "controlSet");
		controlHeader.ExploreMembers(&this->controlSet, this->ReadProperty_real, &context, "controlSet");

		strategyHeader.ExploreMembers(&this->strategySet, this->ReadProperty_bool, &context, "strategySet");
		strategyHeader.ExploreMembers(&this->strategySet, this->ReadProperty_int,  &context, "strategySet");
		strategyHeader.ExploreMembers(&this->strategySet, this->ReadProperty_real, &context, "strategySet");

		this->Submit("controlSet", &this->controlSet, sizeof(this->controlSet));
		this->Submit("strategySet", &this->strategySet, sizeof(this->strategySet));
	}
}


bool_T		parameterSetFilter_T::CreateProperty_bool(const void* thisPtr, const char *name, const char *description, bool_T  value)
{
	parameterSetFilter_T *filter = (parameterSetFilter_T*)thisPtr;
	bool_T setVal = filter->GetPropertyBool(name, (tBool)(value > 0));

	char subName[1024];
	sprintf_s(subName, "%s%s", name, NSSUBPROP_ISCHANGEABLE);

	filter->SetPropertyBool(name, (tBool)(setVal > 0));
	filter->SetPropertyBool(subName, tTrue);

	return setVal;
}


int32_T		parameterSetFilter_T::CreateProperty_int(const void* thisPtr, const char *name, const char *description, int32_T  value)
{
	parameterSetFilter_T *filter = (parameterSetFilter_T*)thisPtr;
	int32_T setVal = filter->GetPropertyInt(name, value);

	char subName[1024];
	sprintf_s(subName, "%s%s", name, NSSUBPROP_ISCHANGEABLE);

	filter->SetPropertyInt(name, setVal);
	filter->SetPropertyBool(subName, tTrue);

	return setVal;
}


real64_T	parameterSetFilter_T::CreateProperty_real(const void* thisPtr, const char *name, const char *description, real64_T  value)
{
	parameterSetFilter_T *filter = (parameterSetFilter_T*)thisPtr;
	real64_T setVal = filter->GetPropertyFloat(name, value);

	char subName[1024];
	sprintf_s(subName, "%s%s", name, NSSUBPROP_ISCHANGEABLE);

	filter->SetPropertyFloat(name, setVal);
	filter->SetPropertyBool(subName, tTrue);

	return setVal;
}


bool_T		parameterSetFilter_T::ReadProperty_bool(const void* thisPtr, const char *name, const char *description, bool_T  value)
{
	readContext_T *context = (readContext_T*)thisPtr;
	bool_T setVal = value;

	if(!strcmp(context->nameChanged, name)) {
		setVal = context->filter->GetPropertyBool(name, (tBool)(value > 0));
	}

	return setVal;
}


int32_T		parameterSetFilter_T::ReadProperty_int(const void* thisPtr, const char *name, const char *description, int32_T  value)
{
	readContext_T *context = (readContext_T*)thisPtr;
	int32_T setVal = value;

	if(!strcmp(context->nameChanged, name)) {
		setVal = context->filter->GetPropertyInt(name, value);
	}

	return setVal;
}


real64_T	parameterSetFilter_T::ReadProperty_real(const void* thisPtr, const char *name, const char *description, real64_T  value)
{
	readContext_T *context = (readContext_T*)thisPtr;
	real64_T setVal = value;

	if(!strcmp(context->nameChanged, name)) {
		setVal = context->filter->GetPropertyFloat(name, value);
	}

	return setVal;
}
