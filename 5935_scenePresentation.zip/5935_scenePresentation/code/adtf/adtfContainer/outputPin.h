#ifndef guard_outputPin_h
#define guard_outputPin_h


#include "../adtfFilter.h"
#include "signalPin.h"

#include <string>


class outputPin_T
  : public signalPin_T
{
private:
	cOutputPin			 adtfPin;

	uint32_T			 majorType;
	uint32_T			 subType;

public:
	outputPin_T(const pinHeader_T &header);
	outputPin_T(std::string typeName, size_t typeSize);
	outputPin_T(uint32_T majorType, uint32_T subType);
	outputPin_T(void);

	cOutputPin*	Create(const char *name);

	tResult		Submit(IMediaSample *sample);
};


#endif
