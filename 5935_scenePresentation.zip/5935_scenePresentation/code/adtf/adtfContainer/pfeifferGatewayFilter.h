#ifndef guard_pfeifferGatewayFilter_h
#define guard_pfeifferGatewayFilter_h

#include "baseFilter.h"
#include <vector>

#define ADTF_FILTER_ID_pfeifferGatewayFilter		"IDII.pfeifferGatewayFilter"
#define ADTF_FILTER_NAME_pfeifferGatewayFilter	"IDII pfeifferGatewayFilter"


class pfeifferGatewayFilter_T
  : public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_pfeifferGatewayFilter, ADTF_FILTER_NAME_pfeifferGatewayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	tUInt32					idPACC02_02;		// 970
	tUInt32					idPACC02_03;		// 316495083
	tUInt32					idKombi_01;			// 779
	tUInt32					idACC_12;			// 678
	tUInt32					idACC_13;			// 679
	tUInt32					idGRA_ACC_01;		// 299


	cObjectPtr<adtf_devicetb::IFlexRayCoder>	flexrayCoder;


public:
	pfeifferGatewayFilter_T(const tChar* __info);
	~pfeifferGatewayFilter_T();

	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	void		OnShutdownNormal(void);

	tResult		OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);
	void		OnReceive(void);

	void		OnRun(int32_T type, const void *data, size_t size);


private:
	void		OnTrigger(void);
};


#endif
