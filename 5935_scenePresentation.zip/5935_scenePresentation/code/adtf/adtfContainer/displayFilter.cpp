#include "stdafx.h"
#include "displayFilter.h"


#pragma warning(disable : 4355)


displayFilter_T::displayFilter_T(const tChar* __info, float minX, float maxX, float minY, float maxY, float minZ, float maxZ)
  : cBaseDisplayFilter(__info),
	defaultControl(this, "", rgbColor_T(255, 255, 255), minX, maxX, maxY, minY, maxZ, minZ),
	control(&defaultControl)
{
	this->canTimer = true;
}


displayFilter_T::~displayFilter_T(void)
{
	groundFilter_T::Cleanup();

	this->canTimer = false;
}


tResult	displayFilter_T::Init(tInitStage eStage, __exception)
{
	RETURN_IF_FAILED(cBaseDisplayFilter::Init(eStage, __exception_ptr));

	if(eStage == StageFirst) {
		groundFilter_T::RegisterKernel(_kernel);
	}

	return groundFilter_T::Init(eStage, this, __exception_ptr);
}


tResult	displayFilter_T::Shutdown(tInitStage eStage, __exception)
{
	RETURN_IF_FAILED(groundFilter_T::Shutdown(eStage, __exception_ptr));

	return cBaseDisplayFilter::Shutdown(eStage, __exception_ptr);
}


tResult	displayFilter_T::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
	return groundFilter_T::OnPinEvent(pSource, nEventCode, nParam1, nParam2, pMediaSample);
}


tResult	displayFilter_T::Start(__exception)
{
	RETURN_IF_FAILED(cBaseDisplayFilter::Start(__exception_ptr));

	return groundFilter_T::Start(__exception_ptr);
}


tResult	displayFilter_T::Stop(__exception)
{
	RETURN_IF_FAILED(groundFilter_T::Stop(__exception_ptr));

	return cBaseDisplayFilter::Stop(__exception_ptr);
}


tResult	displayFilter_T::GetInterface(const tChar *idInterface, tVoid **ppvObject)
{
	if(idmatch(idInterface, IID_ADTF_SIGNAL_PROVIDER)) {
		*ppvObject = static_cast<ISignalProvider*> (this);
		Ref();
	}
	else {
		return cBaseDisplayFilter::GetInterface(idInterface, ppvObject);
	}

	RETURN_NOERROR;
}


tUInt	displayFilter_T::Ref()
{
	return cBaseDisplayFilter::Ref();
}


tUInt	displayFilter_T::Unref()
{
	return cBaseDisplayFilter::Unref();
}


tVoid	displayFilter_T::Destroy()
{
	delete this;
}


tTimeStamp	displayFilter_T::GetStreamTime(void)
{
	return this->_clock->GetStreamTime();
}


tBool	displayFilter_T::GetPropertyBool(const tChar* strName, tBool bDefault)
{
	return cBaseDisplayFilter::GetPropertyBool(strName, bDefault);
}


tResult	displayFilter_T::AllocMediaSample(IMediaSample** ppMediaSample, ucom::IException** __exception_ptr)
{
	return cBaseDisplayFilter::AllocMediaSample(ppMediaSample, __exception_ptr);
}


const tChar* displayFilter_T::OIGetInstanceName()
{
	return cBaseDisplayFilter::OIGetInstanceName();
}


tResult	displayFilter_T::RegisterPin(IPin* pIPin)
{
	return cBaseDisplayFilter::RegisterPin(pIPin);
}


tResult	displayFilter_T::ReleasePins(void)
{
	return cBaseDisplayFilter::ReleasePins();
}


tResult	displayFilter_T::SetPropertyBool(const tChar* strName, tBool bValue)
{
	return cBaseDisplayFilter::SetPropertyBool(strName, bValue);
}


bool	displayFilter_T::ProcessMenuCommand(int cmd)
{
	return false;
}


bool	displayFilter_T::ModifyContextMenu(HMENU hMenu)
{
	return true;
}


void	displayFilter_T::PostRender(void)
{
}


tResult	displayFilter_T::OnPaint(adtf_graphics::ICanvas* pCanvas, const adtf_graphics::cRect& rectInvalid)
{
	RETURN_IF_FAILED(cBaseDisplayFilter::OnPaint(pCanvas, rectInvalid));

	this->PrePaint();

	this->control->PrePaint();
	this->control->graph.Render();
	this->control->PostRender();
	this->PostRender();

	RETURN_NOERROR;
}


tResult	displayFilter_T::OnSize(tHandle hCanvas, tInt nLeft, tInt nTop, tInt nRight, tInt nBottom)
{
	RETURN_IF_FAILED(cBaseDisplayFilter::OnSize(hCanvas, nLeft, nTop, nRight, nBottom));

	this->control->graph.Reshape(0,0,nRight-nLeft+1, nBottom-nTop+1);

	RETURN_NOERROR;
}


tResult	displayFilter_T::OnTimer(tHandle hCanvas)
{
	cBaseDisplayFilter::OnTimer(hCanvas);

	if(!this->canTimer) {
		RETURN_NOERROR;
	}
	
	this->control->OnTimer();

	RETURN_NOERROR;
}


tResult displayFilter_T::OnIdle(tHandle hCanvas)
{
	cBaseDisplayFilter::OnIdle(hCanvas);

	if (this->control->isDisplayActive && this->control->UpdateNecessary()) {
		Invalidate(tFalse);
	}

	RETURN_NOERROR;
}


_graphControl::inputKey_T displayFilter_T::ConvertKey(tInt nParam1) 
{
	if(nParam1 == cBaseDisplayFilter::KEY_ESCAPE)	 { return _graphControl::KEY_ESCAPE; }
	if(nParam1 == cBaseDisplayFilter::KEY_TAB)		 { return _graphControl::KEY_TAB; }
	if(nParam1 == cBaseDisplayFilter::KEY_BACKSPACE) { return _graphControl::KEY_BACKSPACE; }
	if(nParam1 == cBaseDisplayFilter::KEY_RETURN)	 { return _graphControl::KEY_RETURN; }
	if(nParam1 == cBaseDisplayFilter::KEY_INSERT)	 { return _graphControl::KEY_INSERT; }
	if(nParam1 == cBaseDisplayFilter::KEY_DELETE)	 { return _graphControl::KEY_DELETE; }
	if(nParam1 == cBaseDisplayFilter::KEY_PRINT)	 { return _graphControl::KEY_PRINT; }
	if(nParam1 == cBaseDisplayFilter::KEY_HOME)		 { return _graphControl::KEY_HOME; }
	if(nParam1 == cBaseDisplayFilter::KEY_END)		 { return _graphControl::KEY_END; }
	if(nParam1 == cBaseDisplayFilter::KEY_LEFT)		 { return _graphControl::KEY_LEFT; }
	if(nParam1 == cBaseDisplayFilter::KEY_UP)		 { return _graphControl::KEY_UP; }
	if(nParam1 == cBaseDisplayFilter::KEY_RIGHT)	 { return _graphControl::KEY_RIGHT; }
	if(nParam1 == cBaseDisplayFilter::KEY_DOWN)		 { return _graphControl::KEY_DOWN; }
	if(nParam1 == cBaseDisplayFilter::KEY_PAGEUP)	 { return _graphControl::KEY_PAGEUP; }
	if(nParam1 == cBaseDisplayFilter::KEY_PAGEDOWN)	 { return _graphControl::KEY_PAGEDOWN; }
	if(nParam1 == cBaseDisplayFilter::KEY_SPACE)	 { return _graphControl::KEY_SPACE; }
	if(nParam1 == cBaseDisplayFilter::KEY_NUMLOCK)	 { return _graphControl::KEY_NUMLOCK; }

	if(nParam1 == cBaseDisplayFilter::KEY_F1)		 { return _graphControl::KEY_F1; }
	if(nParam1 == cBaseDisplayFilter::KEY_F2)		 { return _graphControl::KEY_F2; }
	if(nParam1 == cBaseDisplayFilter::KEY_F3)		 { return _graphControl::KEY_F3; }
	if(nParam1 == cBaseDisplayFilter::KEY_F4)		 { return _graphControl::KEY_F4; }
	if(nParam1 == cBaseDisplayFilter::KEY_F5)		 { return _graphControl::KEY_F5; }
	if(nParam1 == cBaseDisplayFilter::KEY_F6)		 { return _graphControl::KEY_F6; }
	if(nParam1 == cBaseDisplayFilter::KEY_F7)		 { return _graphControl::KEY_F7; }
	if(nParam1 == cBaseDisplayFilter::KEY_F8)		 { return _graphControl::KEY_F8; }
	if(nParam1 == cBaseDisplayFilter::KEY_F9)		 { return _graphControl::KEY_F9; }
	if(nParam1 == cBaseDisplayFilter::KEY_F10)		 { return _graphControl::KEY_F10; }
	if(nParam1 == cBaseDisplayFilter::KEY_F11)		 { return _graphControl::KEY_F11; }
	if(nParam1 == cBaseDisplayFilter::KEY_F12)		 { return _graphControl::KEY_F12; }

	if(nParam1 == cBaseDisplayFilter::KEY_PLUS)		 { return _graphControl::KEY_PLUS; }
	if(nParam1 == cBaseDisplayFilter::KEY_COMMA)	 { return _graphControl::KEY_COMMA; }
	if(nParam1 == cBaseDisplayFilter::KEY_MINUS)	 { return _graphControl::KEY_MINUS; }
	if(nParam1 == cBaseDisplayFilter::KEY_PERIOD)	 { return _graphControl::KEY_PERIOD; }

	if(nParam1 == cBaseDisplayFilter::KEY_0)		 { return _graphControl::KEY_0; }
	if(nParam1 == cBaseDisplayFilter::KEY_1)		 { return _graphControl::KEY_1; }
	if(nParam1 == cBaseDisplayFilter::KEY_2)		 { return _graphControl::KEY_2; }
	if(nParam1 == cBaseDisplayFilter::KEY_3)		 { return _graphControl::KEY_3; }
	if(nParam1 == cBaseDisplayFilter::KEY_4)		 { return _graphControl::KEY_4; }
	if(nParam1 == cBaseDisplayFilter::KEY_5)		 { return _graphControl::KEY_5; }
	if(nParam1 == cBaseDisplayFilter::KEY_6)		 { return _graphControl::KEY_6; }
	if(nParam1 == cBaseDisplayFilter::KEY_7)		 { return _graphControl::KEY_7; }
	if(nParam1 == cBaseDisplayFilter::KEY_8)		 { return _graphControl::KEY_8; }
	if(nParam1 == cBaseDisplayFilter::KEY_9)		 { return _graphControl::KEY_9; }

	if(nParam1 == cBaseDisplayFilter::KEY_A)		 { return _graphControl::KEY_A; }
	if(nParam1 == cBaseDisplayFilter::KEY_B)		 { return _graphControl::KEY_B; }
	if(nParam1 == cBaseDisplayFilter::KEY_C)		 { return _graphControl::KEY_C; }
	if(nParam1 == cBaseDisplayFilter::KEY_D)		 { return _graphControl::KEY_D; }
	if(nParam1 == cBaseDisplayFilter::KEY_E)		 { return _graphControl::KEY_E; }
	if(nParam1 == cBaseDisplayFilter::KEY_F)		 { return _graphControl::KEY_F; }
	if(nParam1 == cBaseDisplayFilter::KEY_G)		 { return _graphControl::KEY_G; }
	if(nParam1 == cBaseDisplayFilter::KEY_H)		 { return _graphControl::KEY_H; }
	if(nParam1 == cBaseDisplayFilter::KEY_I)		 { return _graphControl::KEY_I; }
	if(nParam1 == cBaseDisplayFilter::KEY_J)		 { return _graphControl::KEY_J; }
	if(nParam1 == cBaseDisplayFilter::KEY_K)		 { return _graphControl::KEY_K; }
	if(nParam1 == cBaseDisplayFilter::KEY_L)		 { return _graphControl::KEY_L; }
	if(nParam1 == cBaseDisplayFilter::KEY_M)		 { return _graphControl::KEY_M; }
	if(nParam1 == cBaseDisplayFilter::KEY_N)		 { return _graphControl::KEY_N; }
	if(nParam1 == cBaseDisplayFilter::KEY_O)		 { return _graphControl::KEY_O; }
	if(nParam1 == cBaseDisplayFilter::KEY_P)		 { return _graphControl::KEY_P; }
	if(nParam1 == cBaseDisplayFilter::KEY_Q)		 { return _graphControl::KEY_Q; }
	if(nParam1 == cBaseDisplayFilter::KEY_R)		 { return _graphControl::KEY_R; }
	if(nParam1 == cBaseDisplayFilter::KEY_S)		 { return _graphControl::KEY_S; }
	if(nParam1 == cBaseDisplayFilter::KEY_T)		 { return _graphControl::KEY_T; }
	if(nParam1 == cBaseDisplayFilter::KEY_U)		 { return _graphControl::KEY_U; }
	if(nParam1 == cBaseDisplayFilter::KEY_V)		 { return _graphControl::KEY_V; }
	if(nParam1 == cBaseDisplayFilter::KEY_W)		 { return _graphControl::KEY_W; }
	if(nParam1 == cBaseDisplayFilter::KEY_X)		 { return _graphControl::KEY_X; }
	if(nParam1 == cBaseDisplayFilter::KEY_Y)		 { return _graphControl::KEY_Y; }
	if(nParam1 == cBaseDisplayFilter::KEY_Z)		 { return _graphControl::KEY_Z; }

	if(nParam1 == cBaseDisplayFilter::KEY_SHIFT)	 { return _graphControl::KEY_SHIFT; }
	if(nParam1 == cBaseDisplayFilter::KEY_CTRL)		 { return _graphControl::KEY_CTRL; }
	if(nParam1 == cBaseDisplayFilter::KEY_ALT)		 { return _graphControl::KEY_ALT; }

	return _graphControl::KEY_ESCAPE;
}


tResult	displayFilter_T::OnControlEvent(tControlEventCode eCode, tInt nParam1, tInt nParam2, tInt nFlags,  tVoid* pEventData)
{
	RETURN_IF_FAILED(cBaseDisplayFilter::OnControlEvent(eCode, nParam1, nParam2, nFlags, pEventData));

	Invalidate(tTrue);

	if(eCode == EC_KeyInput) {
		this->control->OnKeyInput(this->ConvertKey(nParam1), (GetKeyState(VK_CONTROL) & 0x8000) == 0x8000, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
	}

	if(eCode == EC_MouseLDown) {
		this->control->OnMouseLDown(nParam1, this->m_nViewportHeight - nParam2);
	}

	if(eCode == EC_MouseMDown) {
		this->control->OnMouseMDown(nParam1, this->m_nViewportHeight - nParam2);
	}

	if(eCode == EC_MouseLDblClk) {
		this->control->OnMouseLDblClick(nParam1, this->m_nViewportHeight - nParam2);
	}
	
	if(eCode == EC_MouseMDblClk) {
		this->control->OnMouseMDblClick(nParam1, this->m_nViewportHeight - nParam2);
	}
	
	if(eCode == EC_MouseLUp) {
		this->control->OnMouseLUp(nParam1, this->m_nViewportHeight - nParam2, (nFlags & MS_CtrlKeyDown) == MS_CtrlKeyDown, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
	}

	if(eCode == EC_MouseMUp) {
		this->control->OnMouseMUp(nParam1, this->m_nViewportHeight - nParam2, (nFlags & MS_CtrlKeyDown) == MS_CtrlKeyDown);
	}

	if(eCode == EC_MouseRUp) {
		this->control->OnMouseRUp(nParam1, this->m_nViewportHeight - nParam2, (nFlags & MS_CtrlKeyDown) == MS_CtrlKeyDown);
	}

	if(eCode == EC_MouseMove) {
		this->control->OnMouseMove(nParam1, this->m_nViewportHeight - nParam2, (nFlags & MS_LeftButtonDown) == MS_LeftButtonDown, (nFlags & MS_MiddleButtonDown) == MS_MiddleButtonDown, (nFlags & MS_RightButtonDown) == MS_RightButtonDown, (nFlags & MS_CtrlKeyDown) == MS_CtrlKeyDown, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
	}

	if(eCode == EC_MouseWheel) {
		this->control->OnMouseWheel(nParam1, (GetKeyState(VK_CONTROL) & 0x8000) == 0x8000, (GetKeyState(VK_SHIFT) & 0x8000) == 0x8000);
	}

	this->control->OnTimer();

	RETURN_NOERROR;
}


void	displayFilter_T::AssignControl(graphControl_T *control)
{
	this->control = control;
}


void	displayFilter_T::PrePaint(void)
{
}
