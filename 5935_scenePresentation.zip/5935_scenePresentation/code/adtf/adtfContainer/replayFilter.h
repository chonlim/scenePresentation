#ifndef guard_replayFilter_h
#define guard_replayFilter_h

#include "baseFilter.h"

#include "tools/rpl2Tools/rpl2Simulation.h"
#include "../testVector/testVector.h"

#define ADTF_FILTER_ID_replayFilter		"IDII.replayFilter"
#define ADTF_FILTER_NAME_replayFilter	"IDII replayFilter"


class replayFilter_T
	: public baseFilter_T
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_replayFilter, ADTF_FILTER_NAME_replayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	rpl2Simulation_T		replay;
	bufferedTestVector_T	testVector;

public:
	replayFilter_T(const tChar* __info);

	void		OnReceive(void);
	bool		OnInitNormal(void);

private:
	void		RunAlgorithm(void);
};


#endif
