#include "stdafx.h"
#include "platformManholeFilter.h"

#include "control/parameterSet/parameterSetCtrl_adtfTools.h"
#include "strategy/parameterSet/parameterSetStgy_adtfTools.h"
#include "simulation/parameterSet/parameterSetSimu_adtfTools.h"

extern "C" {
	#include "control/controlTask/iccDataInterface.h"
	#include "strategy/strategyTask/icsDataInterface.h"
	#include "simulation/simulationContainer.h"
}


platformManholeFilter_T*	platformManholeFilter_T::logFilter;


platformManholeFilter_T::platformManholeFilter_T(const tChar* __info) : baseFilter_T(__info)
{
	this->AddInputPin("controlSet",		parameterSetCtrl_header());
	this->AddInputPin("strategySet",	parameterSetStgy_header());

	this->AddOutputPin("consoleLog", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_UINT8);
}


bool	platformManholeFilter_T::OnInitNormal(void)
{
	this->logFilter = this;

	iccRegisterLogCallbacks(this->InfoLogCallback, this->WarningLogCallback, this->ErrorLogCallback);
	iscRegisterLogCallbacks(this->InfoLogCallback, this->WarningLogCallback, this->ErrorLogCallback);
	simcRegisterLogCallbacks(this->InfoLogCallback, this->WarningLogCallback, this->ErrorLogCallback);

	return true;
}


void	platformManholeFilter_T::OnShutdownNormal(void)
{
	iccRegisterLogCallbacks(NULL, NULL, NULL);
	iscRegisterLogCallbacks(NULL, NULL, NULL);
	simcRegisterLogCallbacks(NULL, NULL, NULL);

	this->logFilter = NULL;
}


void	platformManholeFilter_T::OnReceive(void)
{
	if(this->GetInputPin("controlSet")->Unflag()) {
		this->EnterMutex();
		iccApplyParameterSet((parameterSetCtrl_T*)this->GetInputPin("controlSet")->GetDataPtr());
		this->LeaveMutex();
	}

	if(this->GetInputPin("strategySet")->Unflag()) {
		this->EnterMutex();
		iscApplyParameterSet((parameterSetStgy_T*)this->GetInputPin("strategySet")->GetDataPtr());
		this->LeaveMutex();
	}
}


void	platformManholeFilter_T::OutputMessage(const char_T type, const char_T *message)
{
	size_t  entrySize	= strlen(message) + 2;
	char_T *logEntry	= new char_T[entrySize];

	sprintf_s(logEntry, entrySize, "%c%s", type, message);

	this->Submit("consoleLog", logEntry, entrySize);

	delete[] logEntry;
}


void	platformManholeFilter_T::InfoLogCallback(const char_T *message)
{
	if(logFilter) {
		logFilter->OutputMessage('I', message);
	}
}


void	platformManholeFilter_T::WarningLogCallback(const char_T *message)
{
	if(logFilter) {
		logFilter->OutputMessage('W', message);
	}
}


void	platformManholeFilter_T::ErrorLogCallback(const char_T *message)
{
	if(logFilter) {
		logFilter->OutputMessage('E', message);
	}
}
