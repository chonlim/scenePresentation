#ifndef guard_crcProcessor_h
#define guard_crcProcessor_h

#include "../adtfFilter.h"


class crcProcessor_T {
private:
	uint32_T			 crcTable[256];

public:
	crcProcessor_T(void);

	uint32_T	GetCRC(void *data, size_t length);
};


#endif
