#include "stdafx.h"
#include "outputPin.h"

#include "crcProcessor.h"


outputPin_T::outputPin_T(const pinHeader_T &header)
  : signalPin_T(header)
{
	crcProcessor_T crc;

	this->majorType		= crc.GetCRC((void*)header.GetTypeName().c_str(), strlen(header.GetTypeName().c_str()));
	this->subType		= (uint32_T)header.GetTypeSize();
}


outputPin_T::outputPin_T(std::string typeName, size_t typeSize)
{
	crcProcessor_T crc;

	this->majorType		= crc.GetCRC((void*)typeName.c_str(), strlen(typeName.c_str()));
	this->subType		= (uint32_T)typeSize;
}


outputPin_T::outputPin_T(uint32_T majorType, uint32_T subType)
{
	this->majorType		= majorType;
	this->subType		= subType;
}


outputPin_T::outputPin_T(void)
{
	this->majorType		= 0;
	this->subType		= 0;
}


cOutputPin*	outputPin_T::Create(const char *name)
{
	this->adtfPin.Create(name, new adtf::cMediaType(this->majorType, this->subType));

	return &this->adtfPin;
}


tResult		outputPin_T::Submit(IMediaSample *sample)
{
	RETURN_IF_FAILED(this->adtfPin.Transmit(sample));
	RETURN_NOERROR;
}
