#ifndef guard_rglConverterTypes_h
#define guard_rglConverterTypes_h

#include "Algorithmus\FastProject\rteInterfaceCtrl\Rte_Type.h"

#define Rte_TypeDef_Coding_PSD_Segment_ID 
typedef uint8 Coding_PSD_Segment_ID; 
# define Coding_PSD_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segmentinformationen_vorhanden 
#  define Cx00_keine_Segmentinformationen_vorhanden (0U)
# endif 
# ifndef Cx01_Fehlerwert 
#  define Cx01_Fehlerwert (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Vorgaenger_Segment_ID 
typedef uint8 Coding_PSD_Vorgaenger_Segment_ID; 
# define Coding_PSD_Vorgaenger_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Vorgaenger_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segmentinformation_vorhanden 
#  define Cx00_keine_Segmentinformation_vorhanden (0U)
# endif 
# ifndef Cx01_Fehlerwert 
#  define Cx01_Fehlerwert (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Segmentlaenge 
typedef uint8 Coding_PSD_Segmentlaenge; 
# define Coding_PSD_Segmentlaenge_LowerLimit (0U)
# define Coding_PSD_Segmentlaenge_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Strassenkategorie 
typedef uint8 Coding_PSD_Strassenkategorie; 
# define Coding_PSD_Strassenkategorie_LowerLimit (0U)
# define Coding_PSD_Strassenkategorie_UpperLimit (7U)
# ifndef Cx0_Rest_Feldweg_Schotterweg_Privatweg 
#  define Cx0_Rest_Feldweg_Schotterweg_Privatweg (0U)
# endif 
# ifndef Cx1_Ortsstrasse 
#  define Cx1_Ortsstrasse (1U)
# endif 
# ifndef Cx2_Kreisstrasse 
#  define Cx2_Kreisstrasse (2U)
# endif 
# ifndef Cx3_Landstrasse 
#  define Cx3_Landstrasse (3U)
# endif 
# ifndef Cx4_Bundesstrasse 
#  define Cx4_Bundesstrasse (4U)
# endif 
# ifndef Cx5_Autobahn 
#  define Cx5_Autobahn (5U)
# endif 
# ifndef Cx7_Init 
#  define Cx7_Init (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Endkruemmung 
typedef uint8 Coding_PSD_Endkruemmung; 
# define Coding_PSD_Endkruemmung_LowerLimit (0U)
# define Coding_PSD_Endkruemmung_UpperLimit (255U)
# ifndef CxFF_Gerade 
#  define CxFF_Gerade (255U)
# endif 
#define Rte_TypeDef_Coding_PSD_Endkruemmung_Vorz 
typedef uint8 Coding_PSD_Endkruemmung_Vorz; 
# define Coding_PSD_Endkruemmung_Vorz_LowerLimit (0U)
# define Coding_PSD_Endkruemmung_Vorz_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Idenditaets_ID 
typedef uint8 Coding_PSD_Idenditaets_ID; 
# define Coding_PSD_Idenditaets_ID_LowerLimit (0U)
# define Coding_PSD_Idenditaets_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segment_Informationen_vorhanden 
#  define Cx00_keine_Segment_Informationen_vorhanden (0U)
# endif 
# ifndef Cx01_Fehler 
#  define Cx01_Fehler (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_ADAS_Qualitaet 
typedef uint8 Coding_PSD_ADAS_Qualitaet; 
# define Coding_PSD_ADAS_Qualitaet_LowerLimit (0U)
# define Coding_PSD_ADAS_Qualitaet_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_wahrscheinlichster_Pfad 
typedef uint8 Coding_PSD_wahrscheinlichster_Pfad; 
# define Coding_PSD_wahrscheinlichster_Pfad_LowerLimit (0U)
# define Coding_PSD_wahrscheinlichster_Pfad_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Geradester_Pfad 
typedef uint8 Coding_PSD_Geradester_Pfad; 
# define Coding_PSD_Geradester_Pfad_LowerLimit (0U)
# define Coding_PSD_Geradester_Pfad_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Fahrspuren_Anzahl 
typedef uint8 Coding_PSD_Fahrspuren_Anzahl; 
# define Coding_PSD_Fahrspuren_Anzahl_LowerLimit (0U)
# define Coding_PSD_Fahrspuren_Anzahl_UpperLimit (7U)
# ifndef Cx0_Einbahnstrasse_in_falsche_Richtung 
#  define Cx0_Einbahnstrasse_in_falsche_Richtung (0U)
# endif 
# ifndef Cx1_eine_Fahrspur 
#  define Cx1_eine_Fahrspur (1U)
# endif 
# ifndef Cx2_zwei_Fahrspuren 
#  define Cx2_zwei_Fahrspuren (2U)
# endif 
# ifndef Cx3_drei_Fahrspuren 
#  define Cx3_drei_Fahrspuren (3U)
# endif 
# ifndef Cx4_vier_Fahrspuren 
#  define Cx4_vier_Fahrspuren (4U)
# endif 
# ifndef Cx5_fuenf_Fahrspuren 
#  define Cx5_fuenf_Fahrspuren (5U)
# endif 
# ifndef Cx6_sechs_Fahrspuren 
#  define Cx6_sechs_Fahrspuren (6U)
# endif 
# ifndef Cx7_mehr_als_sechs_Fahrspuren 
#  define Cx7_mehr_als_sechs_Fahrspuren (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Bebauung 
typedef uint8 Coding_PSD_Bebauung; 
# define Coding_PSD_Bebauung_LowerLimit (0U)
# define Coding_PSD_Bebauung_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Segment_Komplett 
typedef uint8 Coding_PSD_Segment_Komplett; 
# define Coding_PSD_Segment_Komplett_LowerLimit (0U)
# define Coding_PSD_Segment_Komplett_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Rampe 
typedef uint8 Coding_PSD_Rampe; 
# define Coding_PSD_Rampe_LowerLimit (0U)
# define Coding_PSD_Rampe_UpperLimit (3U)
# ifndef Cx0_Strasse_mit_Gegenverkehr 
#  define Cx0_Strasse_mit_Gegenverkehr (0U)
# endif 
# ifndef Cx1_Auffahrt_Einbahnstr 
#  define Cx1_Auffahrt_Einbahnstr (1U)
# endif 
# ifndef Cx2_Abfahrt_Einbahnstr 
#  define Cx2_Abfahrt_Einbahnstr (2U)
# endif 
# ifndef Cx3_Einbahnstrasse 
#  define Cx3_Einbahnstrasse (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Anfangskruemmung 
typedef uint8 Coding_PSD_Anfangskruemmung; 
# define Coding_PSD_Anfangskruemmung_LowerLimit (0U)
# define Coding_PSD_Anfangskruemmung_UpperLimit (255U)
# ifndef CxFF_Gerade 
#  define CxFF_Gerade (255U)
# endif 
#define Rte_TypeDef_Coding_PSD_Anfangskruemmung_Vorz 
typedef uint8 Coding_PSD_Anfangskruemmung_Vorz; 
# define Coding_PSD_Anfangskruemmung_Vorz_LowerLimit (0U)
# define Coding_PSD_Anfangskruemmung_Vorz_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Abzweigerichtung 
typedef uint8 Coding_PSD_Abzweigerichtung; 
# define Coding_PSD_Abzweigerichtung_LowerLimit (0U)
# define Coding_PSD_Abzweigerichtung_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Abzweigewinkel 
typedef uint8 Coding_PSD_Abzweigewinkel; 
# define Coding_PSD_Abzweigewinkel_LowerLimit (0U)
# define Coding_PSD_Abzweigewinkel_UpperLimit (127U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd4Message 
typedef struct _Dt_RECORD_PsdEhr_Psd4Message
  {
    Coding_PSD_Segment_ID PSD_Segment_ID;
        /* PSD_04.PSD_Segment_ID                                     */
    Coding_PSD_Vorgaenger_Segment_ID PSD_Vorgaenger_Segment_ID;
        /* PSD_04.PSD_Vorgaenger_Segment_ID                          */
    Coding_PSD_Segmentlaenge PSD_Segmentlaenge;
        /* PSD_04.PSD_Segmentlaenge                                  */
    Coding_PSD_Strassenkategorie PSD_Strassenkategorie;
        /* PSD_04.PSD_Strassenkategorie                              */
    Coding_PSD_Endkruemmung PSD_Endkruemmung;
        /* PSD_04.PSD_Endkruemmung                                   */
    Coding_PSD_Endkruemmung_Vorz PSD_Endkruemmung_Vorz;
        /* PSD_04.PSD_Endkruemmung_Vorz                              */
    Coding_PSD_Idenditaets_ID PSD_Idenditaets_ID;
        /* PSD_04.PSD_Identitaets_ID                                 */
    Coding_PSD_ADAS_Qualitaet PSD_ADAS_Qualitaet;
        /* PSD_04.PSD_ADAS_Qualitaet                                 */
    Coding_PSD_wahrscheinlichster_Pfad PSD_wahrscheinlichster_Pfad;
        /* PSD_04.PSD_Wahrscheinlichster_Pfad                        */
    Coding_PSD_Geradester_Pfad PSD_Geradester_Pfad;
        /* PSD_04.PSD_Geradester_Pfad                                */
    Coding_PSD_Fahrspuren_Anzahl PSD_Fahrspuren_Anzahl;
        /* PSD_04.PSD_Fahrspuren_Anzahl                              */
    Coding_PSD_Bebauung PSD_Bebauung;
        /* PSD_04.PSD_Bebauung                                       */
    Coding_PSD_Segment_Komplett PSD_Segment_Komplett;
        /* PSD_04.PSD_Segment_Komplett                               */
    Coding_PSD_Rampe PSD_Rampe;
        /* PSD_04.PSD_Rampe                                          */
    Coding_PSD_Anfangskruemmung PSD_Anfangskruemmung;
        /* PSD_04.PSD_Anfangskruemmung                               */
    Coding_PSD_Anfangskruemmung_Vorz PSD_Anfangskruemmung_Vorz;
        /* PSD_04.PSD_Anfangskruemmung_Vorz                          */
    Coding_PSD_Abzweigerichtung PSD_Abzweigerichtung;
        /* PSD_04.PSD_Abzweigrichtung                                */
    Coding_PSD_Abzweigewinkel PSD_Abzweigewinkel;
        /* PSD_04.PSD_Abzeigwinkel                                   */
    UINT_GAP_16 PaddingGap16_1;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd4Message; 
#define Rte_TypeDef_Coding_PSD_Pos_Segment_ID 
typedef uint8 Coding_PSD_Pos_Segment_ID; 
# define Coding_PSD_Pos_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Pos_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Position_gegeben 
#  define Cx00_keine_Position_gegeben (0U)
# endif 
# ifndef Cx01_Fehlerwert 
#  define Cx01_Fehlerwert (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Pos_Segmentlaenge 
typedef uint8 Coding_PSD_Pos_Segmentlaenge; 
# define Coding_PSD_Pos_Segmentlaenge_LowerLimit (0U)
# define Coding_PSD_Pos_Segmentlaenge_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Pos_Inhibitzeit 
typedef uint8 Coding_PSD_Pos_Inhibitzeit; 
# define Coding_PSD_Pos_Inhibitzeit_LowerLimit (0U)
# define Coding_PSD_Pos_Inhibitzeit_UpperLimit (31U)
#define Rte_TypeDef_Coding_PSD_Pos_Standort_Eindeutig 
typedef uint8 Coding_PSD_Pos_Standort_Eindeutig; 
# define Coding_PSD_Pos_Standort_Eindeutig_LowerLimit (0U)
# define Coding_PSD_Pos_Standort_Eindeutig_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Pos_Fehler_Laengsrichtung 
typedef uint8 Coding_PSD_Pos_Fehler_Laengsrichtung; 
# define Coding_PSD_Pos_Fehler_Laengsrichtung_LowerLimit (0U)
# define Coding_PSD_Pos_Fehler_Laengsrichtung_UpperLimit (7U)
# ifndef Cx0_Init 
#  define Cx0_Init (0U)
# endif 
# ifndef Cx1_2m 
#  define Cx1_2m (1U)
# endif 
# ifndef Cx2_5m 
#  define Cx2_5m (2U)
# endif 
# ifndef Cx3_10m 
#  define Cx3_10m (3U)
# endif 
# ifndef Cx4_20m 
#  define Cx4_20m (4U)
# endif 
# ifndef Cx5_50m 
#  define Cx5_50m (5U)
# endif 
# ifndef Cx6_50m 
#  define Cx6_50m (6U)
# endif 
# ifndef Cx7_Off_Road 
#  define Cx7_Off_Road (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Pos_Fahrspur 
typedef uint8 Coding_PSD_Pos_Fahrspur; 
# define Coding_PSD_Pos_Fahrspur_LowerLimit (0U)
# define Coding_PSD_Pos_Fahrspur_UpperLimit (7U)
# ifndef Cx0_unbekannt 
#  define Cx0_unbekannt (0U)
# endif 
# ifndef Cx1_Erste_Spur_von_rechts 
#  define Cx1_Erste_Spur_von_rechts (1U)
# endif 
# ifndef Cx2_Zweite_Spur_von_rechts 
#  define Cx2_Zweite_Spur_von_rechts (2U)
# endif 
# ifndef Cx3_Dritte_Spur_von_rechts 
#  define Cx3_Dritte_Spur_von_rechts (3U)
# endif 
# ifndef Cx4_Vierte_Spur_von_rechts 
#  define Cx4_Vierte_Spur_von_rechts (4U)
# endif 
# ifndef Cx5_Fuenfte_Spur_von_rechts 
#  define Cx5_Fuenfte_Spur_von_rechts (5U)
# endif 
# ifndef Cx6_Sechte_Spur_von_rechts 
#  define Cx6_Sechte_Spur_von_rechts (6U)
# endif 
# ifndef Cx7_Siebte_oder_weitere_Spur_von_rechts 
#  define Cx7_Siebte_oder_weitere_Spur_von_rechts (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_Segment_ID_05 
typedef uint8 Coding_PSD_Attribut_Segment_ID_05; 
# define Coding_PSD_Attribut_Segment_ID_05_LowerLimit (0U)
# define Coding_PSD_Attribut_Segment_ID_05_UpperLimit (63U)
# ifndef Cx00_keine_Segment_Information 
#  define Cx00_keine_Segment_Information (0U)
# endif 
# ifndef Cx01_Fehler 
#  define Cx01_Fehler (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_1_ID 
typedef uint8 Coding_PSD_Attribut_1_ID; 
# define Coding_PSD_Attribut_1_ID_LowerLimit (0U)
# define Coding_PSD_Attribut_1_ID_UpperLimit (31U)
# ifndef Cx00_keine_Information 
#  define Cx00_keine_Information (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_1_Wert 
typedef uint8 Coding_PSD_Attribut_1_Wert; 
# define Coding_PSD_Attribut_1_Wert_LowerLimit (0U)
# define Coding_PSD_Attribut_1_Wert_UpperLimit (15U)
#define Rte_TypeDef_Coding_PSD_Attribut_1_Offset 
typedef uint8 Coding_PSD_Attribut_1_Offset; 
# define Coding_PSD_Attribut_1_Offset_LowerLimit (0U)
# define Coding_PSD_Attribut_1_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Attribut_2_ID 
typedef uint8 Coding_PSD_Attribut_2_ID; 
# define Coding_PSD_Attribut_2_ID_LowerLimit (0U)
# define Coding_PSD_Attribut_2_ID_UpperLimit (31U)
# ifndef Cx00_keine_Information 
#  define Cx00_keine_Information (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_2_Wert 
typedef uint8 Coding_PSD_Attribut_2_Wert; 
# define Coding_PSD_Attribut_2_Wert_LowerLimit (0U)
# define Coding_PSD_Attribut_2_Wert_UpperLimit (15U)
#define Rte_TypeDef_Coding_PSD_Attribut_2_Offset 
typedef uint8 Coding_PSD_Attribut_2_Offset; 
# define Coding_PSD_Attribut_2_Offset_LowerLimit (0U)
# define Coding_PSD_Attribut_2_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Attribute_Komplett_05 
typedef uint8 Coding_PSD_Attribute_Komplett_05; 
# define Coding_PSD_Attribute_Komplett_05_LowerLimit (0U)
# define Coding_PSD_Attribute_Komplett_05_UpperLimit (1U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd5Message 
typedef struct _Dt_RECORD_PsdEhr_Psd5Message
  {
    Coding_PSD_Pos_Segment_ID PSD_Pos_Segment_ID;
        /* PSD_05.PSD_Pos_Segment_ID                                 */
    Coding_PSD_Pos_Segmentlaenge PSD_Pos_Segmentlaenge;
        /* PSD_05.PSD_Pos_Segmentlaenge                              */
    Coding_PSD_Pos_Inhibitzeit PSD_Pos_Inhibitzeit;
        /* PSD_05.PSD_Pos_Inhibitzeit                                */
    Coding_PSD_Pos_Standort_Eindeutig PSD_Pos_Standort_Eindeutig;
        /* PSD_05.PSD_Pos_Standort_Eindeutig                         */
    Coding_PSD_Pos_Fehler_Laengsrichtung PSD_Pos_Fehler_Laengsrichtung;
        /* PSD_05.PSD_Pos_Fehler_Laengsrichtung                      */
    Coding_PSD_Pos_Fahrspur PSD_Pos_Fahrspur;
        /* PSD_05.PSD_Pos_Fahrspur                                   */
    Coding_PSD_Attribut_Segment_ID_05 PSD_Attribut_Segment_ID_05;
        /* PSD_05.PSD_Attribut_Segment_ID                            */
    Coding_PSD_Attribut_1_ID PSD_Attribut_1_ID;
        /* PSD_05.PSD_Attribut_1_ID_05                               */
    Coding_PSD_Attribut_1_Wert PSD_Attribut_1_Wert;
        /* PSD_05.PSD_Attribut_1_Wert_05                             */
    Coding_PSD_Attribut_1_Offset PSD_Attribut_1_Offset;
        /* PSD_05.PSD_Attribut_1_Offset_05                           */
    Coding_PSD_Attribut_2_ID PSD_Attribut_2_ID;
        /* PSD_05.PSD_Attribut_2_ID_05                               */
    Coding_PSD_Attribut_2_Wert PSD_Attribut_2_Wert;
        /* PSD_05.PSD_Attribut_2_Wert_05                             */
    Coding_PSD_Attribut_2_Offset PSD_Attribut_2_Offset;
        /* PSD_05.PSD_Attribut_2_Offset_05                           */
    Coding_PSD_Attribute_Komplett_05 PSD_Attribute_Komplett_05;
        /* PSD_05.PSD_Attribute_Komplett_05                          */
    UINT_GAP_16 PaddingGap16_1;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd5Message; 
#define Rte_TypeDef_Coding_PSD_Sys_Alter_Karte 
typedef uint8 Coding_PSD_Sys_Alter_Karte; 
# define Coding_PSD_Sys_Alter_Karte_LowerLimit (0U)
# define Coding_PSD_Sys_Alter_Karte_UpperLimit (7U)
# ifndef Cx0_kleiner_1_Jahr 
#  define Cx0_kleiner_1_Jahr (0U)
# endif 
# ifndef Cx1_1_Jahr 
#  define Cx1_1_Jahr (1U)
# endif 
# ifndef Cx2_2_Jahre 
#  define Cx2_2_Jahre (2U)
# endif 
# ifndef Cx3_3_Jahre 
#  define Cx3_3_Jahre (3U)
# endif 
# ifndef Cx4_4_Jahre 
#  define Cx4_4_Jahre (4U)
# endif 
# ifndef Cx5_5_Jahre 
#  define Cx5_5_Jahre (5U)
# endif 
# ifndef Cx6_6_Jahre 
#  define Cx6_6_Jahre (6U)
# endif 
# ifndef Cx7_groesser_7_Jahre 
#  define Cx7_groesser_7_Jahre (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Sys_Geometrieguete 
typedef uint8 Coding_PSD_Sys_Geometrieguete; 
# define Coding_PSD_Sys_Geometrieguete_LowerLimit (0U)
# define Coding_PSD_Sys_Geometrieguete_UpperLimit (3U)
# ifndef Cx0_Geringe_Guete 
#  define Cx0_Geringe_Guete (0U)
# endif 
# ifndef Cx1_tbd 
#  define Cx1_tbd (1U)
# endif 
# ifndef Cx2_tbd 
#  define Cx2_tbd (2U)
# endif 
# ifndef Cx3_Hohe_Guete 
#  define Cx3_Hohe_Guete (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Sys_Geometrieguete_erweitert 
typedef uint8 Coding_PSD_Sys_Geometrieguete_erweitert; 
# define Coding_PSD_Sys_Geometrieguete_erweitert_LowerLimit (0U)
# define Coding_PSD_Sys_Geometrieguete_erweitert_UpperLimit (255U)
# ifndef Cx00_Init 
#  define Cx00_Init (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Sys_Geschwindigkeit_Einheit 
typedef uint8 Coding_PSD_Sys_Geschwindigkeit_Einheit; 
# define Coding_PSD_Sys_Geschwindigkeit_Einheit_LowerLimit (0U)
# define Coding_PSD_Sys_Geschwindigkeit_Einheit_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Sys_Laendercode 
typedef uint8 Coding_PSD_Sys_Laendercode; 
# define Coding_PSD_Sys_Laendercode_LowerLimit (0U)
# define Coding_PSD_Sys_Laendercode_UpperLimit (255U)
#define Rte_TypeDef_Coding_PSD_Sys_Mapmatchingguete 
typedef uint8 Coding_PSD_Sys_Mapmatchingguete; 
# define Coding_PSD_Sys_Mapmatchingguete_LowerLimit (0U)
# define Coding_PSD_Sys_Mapmatchingguete_UpperLimit (3U)
# ifndef Cx0_geringe_Guete 
#  define Cx0_geringe_Guete (0U)
# endif 
# ifndef Cx1_res 
#  define Cx1_res (1U)
# endif 
# ifndef Cx2_res 
#  define Cx2_res (2U)
# endif 
# ifndef Cx3_hohe_Guete 
#  define Cx3_hohe_Guete (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Sys_Quali_Geometrien 
typedef uint8 Coding_PSD_Sys_Quali_Geometrien; 
# define Coding_PSD_Sys_Quali_Geometrien_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_Geometrien_UpperLimit (7U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_Ortsinfo 
typedef uint8 Coding_PSD_Sys_Quali_Ortsinfo; 
# define Coding_PSD_Sys_Quali_Ortsinfo_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_Ortsinfo_UpperLimit (3U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_sonstige_Attribute 
typedef uint8 Coding_PSD_Sys_Quali_sonstige_Attribute; 
# define Coding_PSD_Sys_Quali_sonstige_Attribute_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_sonstige_Attribute_UpperLimit (7U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_Steigungen 
typedef uint8 Coding_PSD_Sys_Quali_Steigungen; 
# define Coding_PSD_Sys_Quali_Steigungen_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_Steigungen_UpperLimit (7U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_Strassenkennz 
typedef uint8 Coding_PSD_Sys_Quali_Strassenkennz; 
# define Coding_PSD_Sys_Quali_Strassenkennz_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_Strassenkennz_UpperLimit (7U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_Tempolimits 
typedef uint8 Coding_PSD_Sys_Quali_Tempolimits; 
# define Coding_PSD_Sys_Quali_Tempolimits_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_Tempolimits_UpperLimit (7U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_verfuegbar 
typedef uint8 Coding_PSD_Sys_Quali_verfuegbar; 
# define Coding_PSD_Sys_Quali_verfuegbar_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_verfuegbar_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Sys_Quali_Vorfahrtsregelung 
typedef uint8 Coding_PSD_Sys_Quali_Vorfahrtsregelung; 
# define Coding_PSD_Sys_Quali_Vorfahrtsregelung_LowerLimit (0U)
# define Coding_PSD_Sys_Quali_Vorfahrtsregelung_UpperLimit (7U)
#define Rte_TypeDef_Coding_PSD_Sys_Segment_ID 
typedef uint8 Coding_PSD_Sys_Segment_ID; 
# define Coding_PSD_Sys_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Sys_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segmentinformationen_vorhanden 
#  define Cx00_keine_Segmentinformationen_vorhanden (0U)
# endif 
# ifndef Cx01_nicht_zulaessig 
#  define Cx01_nicht_zulaessig (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Sys_US_State 
typedef uint8 Coding_PSD_Sys_US_State; 
# define Coding_PSD_Sys_US_State_LowerLimit (0U)
# define Coding_PSD_Sys_US_State_UpperLimit (63U)
# ifndef Cx00_kein_US_State 
#  define Cx00_kein_US_State (0U)
# endif 
# ifndef Cx01_Alabama 
#  define Cx01_Alabama (1U)
# endif 
# ifndef Cx02_Alaska 
#  define Cx02_Alaska (2U)
# endif 
# ifndef Cx03_Arkansas 
#  define Cx03_Arkansas (3U)
# endif 
# ifndef Cx04_Arizona 
#  define Cx04_Arizona (4U)
# endif 
# ifndef Cx05_California 
#  define Cx05_California (5U)
# endif 
# ifndef Cx06_Colorado 
#  define Cx06_Colorado (6U)
# endif 
# ifndef Cx07_Conneticut 
#  define Cx07_Conneticut (7U)
# endif 
# ifndef Cx08_District_of_Columbia 
#  define Cx08_District_of_Columbia (8U)
# endif 
# ifndef Cx09_Delaware 
#  define Cx09_Delaware (9U)
# endif 
# ifndef Cx0A_Florida 
#  define Cx0A_Florida (10U)
# endif 
# ifndef Cx0B_Georgia 
#  define Cx0B_Georgia (11U)
# endif 
# ifndef Cx0C_Hawaii 
#  define Cx0C_Hawaii (12U)
# endif 
# ifndef Cx0D_Idaho 
#  define Cx0D_Idaho (13U)
# endif 
# ifndef Cx0E_Illinois 
#  define Cx0E_Illinois (14U)
# endif 
# ifndef Cx0F_Iowa 
#  define Cx0F_Iowa (15U)
# endif 
# ifndef Cx10_Indiana 
#  define Cx10_Indiana (16U)
# endif 
# ifndef Cx11_Kansas 
#  define Cx11_Kansas (17U)
# endif 
# ifndef Cx12_Kentucky 
#  define Cx12_Kentucky (18U)
# endif 
# ifndef Cx13_Louisiana 
#  define Cx13_Louisiana (19U)
# endif 
# ifndef Cx14_Massachusetts 
#  define Cx14_Massachusetts (20U)
# endif 
# ifndef Cx15_Maryland 
#  define Cx15_Maryland (21U)
# endif 
# ifndef Cx16_Maine 
#  define Cx16_Maine (22U)
# endif 
# ifndef Cx17_Michigan 
#  define Cx17_Michigan (23U)
# endif 
# ifndef Cx18_Minnesota 
#  define Cx18_Minnesota (24U)
# endif 
# ifndef Cx19_Missouri 
#  define Cx19_Missouri (25U)
# endif 
# ifndef Cx1A_Mississippi 
#  define Cx1A_Mississippi (26U)
# endif 
# ifndef Cx1B_Montana 
#  define Cx1B_Montana (27U)
# endif 
# ifndef Cx1C_North_Carolina 
#  define Cx1C_North_Carolina (28U)
# endif 
# ifndef Cx1D_North_Dakota 
#  define Cx1D_North_Dakota (29U)
# endif 
# ifndef Cx1E_Nebraska 
#  define Cx1E_Nebraska (30U)
# endif 
# ifndef Cx1F_Nevada 
#  define Cx1F_Nevada (31U)
# endif 
# ifndef Cx20_New_Hampshire 
#  define Cx20_New_Hampshire (32U)
# endif 
# ifndef Cx21_New_Jersey 
#  define Cx21_New_Jersey (33U)
# endif 
# ifndef Cx22_New_Mexico 
#  define Cx22_New_Mexico (34U)
# endif 
# ifndef Cx23_New_York 
#  define Cx23_New_York (35U)
# endif 
# ifndef Cx24_Ohio 
#  define Cx24_Ohio (36U)
# endif 
# ifndef Cx25_Oklahoma 
#  define Cx25_Oklahoma (37U)
# endif 
# ifndef Cx26_Oregon 
#  define Cx26_Oregon (38U)
# endif 
# ifndef Cx27_Pennsylvania 
#  define Cx27_Pennsylvania (39U)
# endif 
# ifndef Cx28_Puerto_Rico 
#  define Cx28_Puerto_Rico (40U)
# endif 
# ifndef Cx29_Rhode_Island 
#  define Cx29_Rhode_Island (41U)
# endif 
# ifndef Cx2A_South_Carolina 
#  define Cx2A_South_Carolina (42U)
# endif 
# ifndef Cx2B_South_Dakota 
#  define Cx2B_South_Dakota (43U)
# endif 
# ifndef Cx2C_Tennessee 
#  define Cx2C_Tennessee (44U)
# endif 
# ifndef Cx2D_Texas 
#  define Cx2D_Texas (45U)
# endif 
# ifndef Cx2E_Utah 
#  define Cx2E_Utah (46U)
# endif 
# ifndef Cx2F_Virginia 
#  define Cx2F_Virginia (47U)
# endif 
# ifndef Cx30_Virgin_Islands 
#  define Cx30_Virgin_Islands (48U)
# endif 
# ifndef Cx31_Vermont 
#  define Cx31_Vermont (49U)
# endif 
# ifndef Cx32_Washington 
#  define Cx32_Washington (50U)
# endif 
# ifndef Cx33_Wisconsin 
#  define Cx33_Wisconsin (51U)
# endif 
# ifndef Cx34_West_Virginia 
#  define Cx34_West_Virginia (52U)
# endif 
# ifndef Cx35_Wyoming 
#  define Cx35_Wyoming (53U)
# endif 
#define Rte_TypeDef_Coding_PSD_Sys_Verkehrsrichtung 
typedef uint8 Coding_PSD_Sys_Verkehrsrichtung; 
# define Coding_PSD_Sys_Verkehrsrichtung_LowerLimit (0U)
# define Coding_PSD_Sys_Verkehrsrichtung_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Sys_Zielfuehrung 
typedef uint8 Coding_PSD_Sys_Zielfuehrung; 
# define Coding_PSD_Sys_Zielfuehrung_LowerLimit (0U)
# define Coding_PSD_Sys_Zielfuehrung_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Sys_Zielfuehrung_geaendert 
typedef uint8 Coding_PSD_Sys_Zielfuehrung_geaendert; 
# define Coding_PSD_Sys_Zielfuehrung_geaendert_LowerLimit (0U)
# define Coding_PSD_Sys_Zielfuehrung_geaendert_UpperLimit (1U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd60Message 
typedef struct _Dt_RECORD_PsdEhr_Psd60Message
  {
    Coding_PSD_Sys_Alter_Karte PSD_Sys_Alter_Karte;
        /* PSD_06.PSD_Sys_Alter_Karte                                */
    Coding_PSD_Sys_Geometrieguete PSD_Sys_Geometrieguete;
        /* PSD_06.PSD_Sys_Geometrieguete                             */
    Coding_PSD_Sys_Geometrieguete_erweitert PSD_Sys_Geometrieguete_erweitert;
    Coding_PSD_Sys_Geschwindigkeit_Einheit PSD_Sys_Geschwindigkeit_Einheit;
        /* PSD_06.PSD_Sys_Geschwindigkeit_Einheit                    */
    Coding_PSD_Sys_Laendercode PSD_Sys_Laendercode;
        /* PSD_06.PSD_Sys_Laendercode                                */
    Coding_PSD_Sys_Mapmatchingguete PSD_Sys_Mapmatchingguete;
        /* PSD_06.PSD_Sys_Mapmatchingguete                           */
    Coding_PSD_Sys_Quali_Geometrien PSD_Sys_Quali_Geometrien;
    Coding_PSD_Sys_Quali_Ortsinfo PSD_Sys_Quali_Ortsinfo;
    Coding_PSD_Sys_Quali_sonstige_Attribute PSD_Sys_Quali_sonstige_Attribute;
    Coding_PSD_Sys_Quali_Steigungen PSD_Sys_Quali_Steigungen;
    Coding_PSD_Sys_Quali_Strassenkennz PSD_Sys_Quali_Strassenkennz;
    Coding_PSD_Sys_Quali_Tempolimits PSD_Sys_Quali_Tempolimits;
    Coding_PSD_Sys_Quali_verfuegbar PSD_Sys_Quali_verfuegbar;
    Coding_PSD_Sys_Quali_Vorfahrtsregelung PSD_Sys_Quali_Vorfahrtsregelung;
    Coding_PSD_Sys_Segment_ID PSD_Sys_Segment_ID;
        /* PSD_06.PSD_Sys_Segment_ID                                 */
    Coding_PSD_Sys_US_State PSD_Sys_US_State;
        /* PSD_06.PSD_Sys_US_State                                   */
    Coding_PSD_Sys_Verkehrsrichtung PSD_Sys_Verkehrsrichtung;
        /* PSD_06.PSD_Sys_Verkehrsrichtung                           */
    Coding_PSD_Sys_Zielfuehrung PSD_Sys_Zielfuehrung;
        /* PSD_06.PSD_Sys_Zielfuehrung                               */
    Coding_PSD_Sys_Zielfuehrung_geaendert PSD_Sys_Zielfuehrung_geaendert;
    UINT_GAP_8 PaddingGap8_1;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd60Message; 
#define Rte_TypeDef_Coding_PSD_Attribut_Segment_ID 
typedef uint8 Coding_PSD_Attribut_Segment_ID; 
# define Coding_PSD_Attribut_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Attribut_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segment_Information_vorhanden 
#  define Cx00_keine_Segment_Information_vorhanden (0U)
# endif 
# ifndef Cx01_Fehler 
#  define Cx01_Fehler (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_3_ID 
typedef uint8 Coding_PSD_Attribut_3_ID; 
# define Coding_PSD_Attribut_3_ID_LowerLimit (0U)
# define Coding_PSD_Attribut_3_ID_UpperLimit (31U)
# ifndef Cx00_keine_Information 
#  define Cx00_keine_Information (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_3_Wert 
typedef uint8 Coding_PSD_Attribut_3_Wert; 
# define Coding_PSD_Attribut_3_Wert_LowerLimit (0U)
# define Coding_PSD_Attribut_3_Wert_UpperLimit (15U)
#define Rte_TypeDef_Coding_PSD_Attribut_3_Offset 
typedef uint8 Coding_PSD_Attribut_3_Offset; 
# define Coding_PSD_Attribut_3_Offset_LowerLimit (0U)
# define Coding_PSD_Attribut_3_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Attribut_4_ID 
typedef uint8 Coding_PSD_Attribut_4_ID; 
# define Coding_PSD_Attribut_4_ID_LowerLimit (0U)
# define Coding_PSD_Attribut_4_ID_UpperLimit (31U)
# ifndef Cx00_keine_Information 
#  define Cx00_keine_Information (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_4_Wert 
typedef uint8 Coding_PSD_Attribut_4_Wert; 
# define Coding_PSD_Attribut_4_Wert_LowerLimit (0U)
# define Coding_PSD_Attribut_4_Wert_UpperLimit (15U)
#define Rte_TypeDef_Coding_PSD_Attribut_4_Offset 
typedef uint8 Coding_PSD_Attribut_4_Offset; 
# define Coding_PSD_Attribut_4_Offset_LowerLimit (0U)
# define Coding_PSD_Attribut_4_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Attribut_5_ID 
typedef uint8 Coding_PSD_Attribut_5_ID; 
# define Coding_PSD_Attribut_5_ID_LowerLimit (0U)
# define Coding_PSD_Attribut_5_ID_UpperLimit (31U)
# ifndef Cx00_keine_Information 
#  define Cx00_keine_Information (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Attribut_5_Wert 
typedef uint8 Coding_PSD_Attribut_5_Wert; 
# define Coding_PSD_Attribut_5_Wert_LowerLimit (0U)
# define Coding_PSD_Attribut_5_Wert_UpperLimit (15U)
#define Rte_TypeDef_Coding_PSD_Attribut_5_Offset 
typedef uint8 Coding_PSD_Attribut_5_Offset; 
# define Coding_PSD_Attribut_5_Offset_LowerLimit (0U)
# define Coding_PSD_Attribut_5_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Attribute_Komplett_06 
typedef uint8 Coding_PSD_Attribute_Komplett_06; 
# define Coding_PSD_Attribute_Komplett_06_LowerLimit (0U)
# define Coding_PSD_Attribute_Komplett_06_UpperLimit (1U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd61Message 
typedef struct _Dt_RECORD_PsdEhr_Psd61Message
  {
    Coding_PSD_Attribut_Segment_ID PSD_Attribut_Segment_ID;
        /* PSD_06.PSD_Attribut_Segment_ID                            */
    Coding_PSD_Attribut_3_ID PSD_Attribut_3_ID;
        /* PSD_06.PSD_Attribut_1_ID                                  */
    Coding_PSD_Attribut_3_Wert PSD_Attribut_3_Wert;
        /* PSD_06.PSD_Attribut_1_Wert                                */
    Coding_PSD_Attribut_3_Offset PSD_Attribut_3_Offset;
        /* PSD_06.PSD_Attribut_1_Offset                              */
    Coding_PSD_Attribut_4_ID PSD_Attribut_4_ID;
        /* PSD_06.PSD_Attribut_2_ID                                  */
    Coding_PSD_Attribut_4_Wert PSD_Attribut_4_Wert;
        /* PSD_06.PSD_Attribut_2_Wert                                */
    Coding_PSD_Attribut_4_Offset PSD_Attribut_4_Offset;
        /* PSD_06.PSD_Attribut_2_Offset                              */
    Coding_PSD_Attribut_5_ID PSD_Attribut_5_ID;
        /* PSD_06.PSD_Attribut_3_ID                                  */
    Coding_PSD_Attribut_5_Wert PSD_Attribut_5_Wert;
        /* PSD_06.PSD_Attribut_3_Wert                                */
    Coding_PSD_Attribut_5_Offset PSD_Attribut_5_Offset;
        /* PSD_06.PSD_Attribut_3_Offset                              */
    Coding_PSD_Attribute_Komplett_06 PSD_Attribute_Komplett_06;
        /* PSD_06.PSD_Attribute_Komplett_06                          */
    UINT_GAP_8 PaddingGap8_1;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd61Message; 
#define Rte_TypeDef_Coding_PSD_Ges_Segment_ID 
typedef uint8 Coding_PSD_Ges_Segment_ID; 
# define Coding_PSD_Ges_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Ges_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segmentinformationen_vorhanden 
#  define Cx00_keine_Segmentinformationen_vorhanden (0U)
# endif 
# ifndef Cx01_nicht_zulaessig 
#  define Cx01_nicht_zulaessig (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Offset 
typedef uint8 Coding_PSD_Ges_Offset; 
# define Coding_PSD_Ges_Offset_LowerLimit (0U)
# define Coding_PSD_Ges_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit; 
# define Coding_PSD_Ges_Geschwindigkeit_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_UpperLimit (31U)
# ifndef Cx00_Kein_Geschwindigkeitsgebot 
#  define Cx00_Kein_Geschwindigkeitsgebot (0U)
# endif 
# ifndef Cx01_0_km_h_v_max_5_km_h 
#  define Cx01_0_km_h_v_max_5_km_h (1U)
# endif 
# ifndef Cx02_5_km_h_v_max_10km_h 
#  define Cx02_5_km_h_v_max_10km_h (2U)
# endif 
# ifndef Cx03_10_km_h_v_max_15_km_h 
#  define Cx03_10_km_h_v_max_15_km_h (3U)
# endif 
# ifndef Cx04_15_km_h_v_max_20_km_h 
#  define Cx04_15_km_h_v_max_20_km_h (4U)
# endif 
# ifndef Cx05_20_km_h_v_max_25_km_h 
#  define Cx05_20_km_h_v_max_25_km_h (5U)
# endif 
# ifndef Cx06_25_km_h_v_max_30_km_h 
#  define Cx06_25_km_h_v_max_30_km_h (6U)
# endif 
# ifndef Cx07_30_km_h_v_max_35_km_h 
#  define Cx07_30_km_h_v_max_35_km_h (7U)
# endif 
# ifndef Cx08_35_km_h_v_max_40_km_h 
#  define Cx08_35_km_h_v_max_40_km_h (8U)
# endif 
# ifndef Cx09_40_km_h_v_max_45_km_h 
#  define Cx09_40_km_h_v_max_45_km_h (9U)
# endif 
# ifndef Cx0A_45_km_h_v_max_50_km_h 
#  define Cx0A_45_km_h_v_max_50_km_h (10U)
# endif 
# ifndef Cx0B_50_km_h_v_max_60_km_h 
#  define Cx0B_50_km_h_v_max_60_km_h (11U)
# endif 
# ifndef Cx0C_60_km_h_v_max_70_km_h 
#  define Cx0C_60_km_h_v_max_70_km_h (12U)
# endif 
# ifndef Cx0D_70_km_h_v_max_80_km_h 
#  define Cx0D_70_km_h_v_max_80_km_h (13U)
# endif 
# ifndef Cx0E_80_km_h_v_max_90_km_h 
#  define Cx0E_80_km_h_v_max_90_km_h (14U)
# endif 
# ifndef Cx0F_90_km_h_v_max_100_km_h 
#  define Cx0F_90_km_h_v_max_100_km_h (15U)
# endif 
# ifndef Cx10_100_km_h_v_max_110_km_h 
#  define Cx10_100_km_h_v_max_110_km_h (16U)
# endif 
# ifndef Cx11_110_km_h_v_max_120_km_h 
#  define Cx11_110_km_h_v_max_120_km_h (17U)
# endif 
# ifndef Cx12_120_km_h_v_max_130_km_h 
#  define Cx12_120_km_h_v_max_130_km_h (18U)
# endif 
# ifndef Cx13_130_km_h_v_max_140_km_h 
#  define Cx13_130_km_h_v_max_140_km_h (19U)
# endif 
# ifndef Cx14_140_km_h_v_max_150_km_h 
#  define Cx14_140_km_h_v_max_150_km_h (20U)
# endif 
# ifndef Cx15_150_km_h_v_max_160_km_h 
#  define Cx15_150_km_h_v_max_160_km_h (21U)
# endif 
# ifndef Cx16_160_km_h_v_max 
#  define Cx16_160_km_h_v_max (22U)
# endif 
# ifndef Cx17_Geschwindigkeitsgebot_aufgehoben 
#  define Cx17_Geschwindigkeitsgebot_aufgehoben (23U)
# endif 
# ifndef Cx18_0x1F_ungueltig 
#  define Cx18_0x1F_ungueltig (24U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Typ 
typedef uint8 Coding_PSD_Ges_Typ; 
# define Coding_PSD_Ges_Typ_LowerLimit (0U)
# define Coding_PSD_Ges_Typ_UpperLimit (3U)
# ifndef Cx0_Geschw_Klasse_des_Kartendatensuppliers 
#  define Cx0_Geschw_Klasse_des_Kartendatensuppliers (0U)
# endif 
# ifndef Cx1_Explizit_abgeleiteten_Begrenzung 
#  define Cx1_Explizit_abgeleiteten_Begrenzung (1U)
# endif 
# ifndef Cx2_Durch_Gesetzg_vorgeg_allgem_Gebot_fuer_uebertr_Rahmenbed 
#  define Cx2_Durch_Gesetzg_vorgeg_allgem_Gebot_fuer_uebertr_Rahmenbed (2U)
# endif 
# ifndef Cx3_Init 
#  define Cx3_Init (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Spur_Geschw_Begrenzung 
typedef uint8 Coding_PSD_Ges_Spur_Geschw_Begrenzung; 
# define Coding_PSD_Ges_Spur_Geschw_Begrenzung_LowerLimit (0U)
# define Coding_PSD_Ges_Spur_Geschw_Begrenzung_UpperLimit (63U)
# ifndef Cx00_Gebot_fuer_alle_spuren_gueltig 
#  define Cx00_Gebot_fuer_alle_spuren_gueltig (0U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit_Gespann 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit_Gespann; 
# define Coding_PSD_Ges_Geschwindigkeit_Gespann_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_Gespann_UpperLimit (3U)
# ifndef Cx0_alle_Fahrzeuge 
#  define Cx0_alle_Fahrzeuge (0U)
# endif 
# ifndef Cx1_PKW_mit_Gespann 
#  define Cx1_PKW_mit_Gespann (1U)
# endif 
# ifndef Cx2_LKW_Busse_etc_ 
#  define Cx2_LKW_Busse_etc_ (2U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit_Witter 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit_Witter; 
# define Coding_PSD_Ges_Geschwindigkeit_Witter_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_Witter_UpperLimit (3U)
# ifndef Cx0_Witterungsunabhaengig 
#  define Cx0_Witterungsunabhaengig (0U)
# endif 
# ifndef Cx1_Naesse_Regen_Niederschlag 
#  define Cx1_Naesse_Regen_Niederschlag (1U)
# endif 
# ifndef Cx2_Glaette 
#  define Cx2_Glaette (2U)
# endif 
# ifndef Cx3_Nebel 
#  define Cx3_Nebel (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit_Tag_Anf 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit_Tag_Anf; 
# define Coding_PSD_Ges_Geschwindigkeit_Tag_Anf_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_Tag_Anf_UpperLimit (7U)
# ifndef Cx0_kein_Beginn_definiert 
#  define Cx0_kein_Beginn_definiert (0U)
# endif 
# ifndef Cx1_Montag 
#  define Cx1_Montag (1U)
# endif 
# ifndef Cx2_Dienstag 
#  define Cx2_Dienstag (2U)
# endif 
# ifndef Cx3_Mittwoch 
#  define Cx3_Mittwoch (3U)
# endif 
# ifndef Cx4_Donnerstag 
#  define Cx4_Donnerstag (4U)
# endif 
# ifndef Cx5_Freitag 
#  define Cx5_Freitag (5U)
# endif 
# ifndef Cx6_Samstag 
#  define Cx6_Samstag (6U)
# endif 
# ifndef Cx7_Sonntag 
#  define Cx7_Sonntag (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit_Tag_Ende 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit_Tag_Ende; 
# define Coding_PSD_Ges_Geschwindigkeit_Tag_Ende_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_Tag_Ende_UpperLimit (7U)
# ifndef Cx0_kein_Ende_definiert 
#  define Cx0_kein_Ende_definiert (0U)
# endif 
# ifndef Cx1_Montag 
#  define Cx1_Montag (1U)
# endif 
# ifndef Cx2_Dienstag 
#  define Cx2_Dienstag (2U)
# endif 
# ifndef Cx3_Mittwoch 
#  define Cx3_Mittwoch (3U)
# endif 
# ifndef Cx4_Donnerstag 
#  define Cx4_Donnerstag (4U)
# endif 
# ifndef Cx5_Freitag 
#  define Cx5_Freitag (5U)
# endif 
# ifndef Cx6_Samstag 
#  define Cx6_Samstag (6U)
# endif 
# ifndef Cx7_Sonntag 
#  define Cx7_Sonntag (7U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit_Std_Anf 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit_Std_Anf; 
# define Coding_PSD_Ges_Geschwindigkeit_Std_Anf_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_Std_Anf_UpperLimit (31U)
# ifndef Cx19_kein_Beginn_fuer_stundenweise_Einschraenkungen 
#  define Cx19_kein_Beginn_fuer_stundenweise_Einschraenkungen (25U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Geschwindigkeit_Std_Ende 
typedef uint8 Coding_PSD_Ges_Geschwindigkeit_Std_Ende; 
# define Coding_PSD_Ges_Geschwindigkeit_Std_Ende_LowerLimit (0U)
# define Coding_PSD_Ges_Geschwindigkeit_Std_Ende_UpperLimit (31U)
# ifndef Cx19_kein_Ende_fuer_stundenweise_Einschraenkungen 
#  define Cx19_kein_Ende_fuer_stundenweise_Einschraenkungen (25U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Ueberholverbot 
typedef uint8 Coding_PSD_Ges_Ueberholverbot; 
# define Coding_PSD_Ges_Ueberholverbot_LowerLimit (0U)
# define Coding_PSD_Ges_Ueberholverbot_UpperLimit (3U)
# ifndef Cx0_kein_Ueberholverbot 
#  define Cx0_kein_Ueberholverbot (0U)
# endif 
# ifndef Cx1_alle_Fahrzeuge 
#  define Cx1_alle_Fahrzeuge (1U)
# endif 
# ifndef Cx2_Ueberholverbot_fuer_PKW_mit_Gespann 
#  define Cx2_Ueberholverbot_fuer_PKW_mit_Gespann (2U)
# endif 
# ifndef Cx3_Ueberholverbot_fuer_LKW_Busse_etc_ 
#  define Cx3_Ueberholverbot_fuer_LKW_Busse_etc_ (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Wechselverkehrszeichen 
typedef uint8 Coding_PSD_Ges_Wechselverkehrszeichen; 
# define Coding_PSD_Ges_Wechselverkehrszeichen_LowerLimit (0U)
# define Coding_PSD_Ges_Wechselverkehrszeichen_UpperLimit (7U)
# ifndef Cx0_Kein_Wechselverkehrszeichen 
#  define Cx0_Kein_Wechselverkehrszeichen (0U)
# endif 
# ifndef Cx1_Wechselverkehrszeichen_links 
#  define Cx1_Wechselverkehrszeichen_links (1U)
# endif 
# ifndef Cx2_Wechselverkehrszeichen_rechts 
#  define Cx2_Wechselverkehrszeichen_rechts (2U)
# endif 
# ifndef Cx3_Wechselverkehrszeichen_links_und_rechts 
#  define Cx3_Wechselverkehrszeichen_links_und_rechts (3U)
# endif 
# ifndef Cx4_Wechselverkerhszeichen_ueber_der_Fahrbahn 
#  define Cx4_Wechselverkerhszeichen_ueber_der_Fahrbahn (4U)
# endif 
#define Rte_TypeDef_Coding_PSD_Wechselverkehrszeichen_Typ 
typedef uint8 Coding_PSD_Wechselverkehrszeichen_Typ; 
# define Coding_PSD_Wechselverkehrszeichen_Typ_LowerLimit (0U)
# define Coding_PSD_Wechselverkehrszeichen_Typ_UpperLimit (3U)
# ifndef Cx0_kein_Wechselverkehrszeichen 
#  define Cx0_kein_Wechselverkehrszeichen (0U)
# endif 
# ifndef Cx1_LED_Wechselverkehrszeichen 
#  define Cx1_LED_Wechselverkehrszeichen (1U)
# endif 
# ifndef Cx2_nicht_LED_Wechselverkehrszeichen 
#  define Cx2_nicht_LED_Wechselverkehrszeichen (2U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Gesetzlich_Kategorie 
typedef uint8 Coding_PSD_Ges_Gesetzlich_Kategorie; 
# define Coding_PSD_Ges_Gesetzlich_Kategorie_LowerLimit (0U)
# define Coding_PSD_Ges_Gesetzlich_Kategorie_UpperLimit (7U)
# ifndef Cx0_kein_legales_Verbot 
#  define Cx0_kein_legales_Verbot (0U)
# endif 
# ifndef Cx1_innerorts 
#  define Cx1_innerorts (1U)
# endif 
# ifndef Cx2_ausserorts 
#  define Cx2_ausserorts (2U)
# endif 
# ifndef Cx3_Autobahn 
#  define Cx3_Autobahn (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Gesetzlich_Zusatz 
typedef uint8 Coding_PSD_Ges_Gesetzlich_Zusatz; 
# define Coding_PSD_Ges_Gesetzlich_Zusatz_LowerLimit (0U)
# define Coding_PSD_Ges_Gesetzlich_Zusatz_UpperLimit (3U)
# ifndef Cx0_kein_Zusatz_zu_legalem_Gebot 
#  define Cx0_kein_Zusatz_zu_legalem_Gebot (0U)
# endif 
# ifndef Cx1_Anhaenger_Klasse_1 
#  define Cx1_Anhaenger_Klasse_1 (1U)
# endif 
# ifndef Cx2_Anhaenger_Klasse_2 
#  define Cx2_Anhaenger_Klasse_2 (2U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Verkehrszeichen_Quelle 
typedef uint8 Coding_PSD_Ges_Verkehrszeichen_Quelle; 
# define Coding_PSD_Ges_Verkehrszeichen_Quelle_LowerLimit (0U)
# define Coding_PSD_Ges_Verkehrszeichen_Quelle_UpperLimit (3U)
# ifndef Cx0_VZA_kein_Onlinedienst 
#  define Cx0_VZA_kein_Onlinedienst (0U)
# endif 
# ifndef Cx1_nur_VZA 
#  define Cx1_nur_VZA (1U)
# endif 
# ifndef Cx2_nur_VZO 
#  define Cx2_nur_VZO (2U)
# endif 
# ifndef Cx3_VZA_und_VZO 
#  define Cx3_VZA_und_VZO (3U)
# endif 
#define Rte_TypeDef_Coding_PSD_Ges_Attribute_Komplett 
typedef uint8 Coding_PSD_Ges_Attribute_Komplett; 
# define Coding_PSD_Ges_Attribute_Komplett_LowerLimit (0U)
# define Coding_PSD_Ges_Attribute_Komplett_UpperLimit (1U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd62Message 
typedef struct _Dt_RECORD_PsdEhr_Psd62Message
  {
    Coding_PSD_Ges_Segment_ID PSD_Ges_Segment_ID;
        /* PSD_06.PSD_Ges_Segment_ID                                 */
    Coding_PSD_Ges_Offset PSD_Ges_Offset;
        /* PSD_06.PSD_Ges_Offset                                     */
    Coding_PSD_Ges_Geschwindigkeit PSD_Ges_Geschwindigkeit;
        /* PSD_06.PSD_Ges_Geschwindigkeit                            */
    Coding_PSD_Ges_Typ PSD_Ges_Typ;
        /* PSD_06.PSD_Ges_Typ                                        */
    Coding_PSD_Ges_Spur_Geschw_Begrenzung PSD_Ges_Spur_Geschw_Begrenzung;
        /* PSD_06.PSD_Ges_Spur_Geschw_Begrenzung                     */
    Coding_PSD_Ges_Geschwindigkeit_Gespann PSD_Ges_Geschwindigkeit_Gespann;
        /* PSD_06.PSD_Ges_Geschwindigkeit_Gespann                    */
    Coding_PSD_Ges_Geschwindigkeit_Witter PSD_Ges_Geschwindigkeit_Witter;
        /* PSD_06.PSD_Ges_Geschwindigkeit_Witter                     */
    Coding_PSD_Ges_Geschwindigkeit_Tag_Anf PSD_Ges_Geschwindigkeit_Tag_Anf;
        /* PSD_06.PSD_Ges_Geschwindigkeit_Tag_Anf                    */
    Coding_PSD_Ges_Geschwindigkeit_Tag_Ende PSD_Ges_Geschwindigkeit_Tag_Ende;
        /* PSD_06.PSD_Ges_Geschwindigkeit_Tag_Ende                   */
    Coding_PSD_Ges_Geschwindigkeit_Std_Anf PSD_Ges_Geschwindigkeit_Std_Anf;
        /* PSD_06.PSD_Ges_Geschwindigkeit_Std_Anf                    */
    Coding_PSD_Ges_Geschwindigkeit_Std_Ende PSD_Ges_Geschwindigkeit_Std_Ende;
        /* PSD_06.PSD_Ges_Geschwindigkeit_Std_Ende                   */
    Coding_PSD_Ges_Ueberholverbot PSD_Ges_Ueberholverbot;
        /* PSD_06.PSD_Ges_Ueberholtverbot                            */
    Coding_PSD_Ges_Wechselverkehrszeichen PSD_Ges_Wechselverkehrszeichen;
        /* PSD_06.PSD_Ges_Wechselverkehrszeichen                     */
    Coding_PSD_Wechselverkehrszeichen_Typ PSD_Wechselverkehrszeichen_Typ;
        /* PSD_06.PSD_Wechselverkehrszeichen_Typ                     */
    Coding_PSD_Ges_Gesetzlich_Kategorie PSD_Ges_Gesetzlich_Kategorie;
        /* PSD_06.PSD_Ges_Gesetzlich_Kategorie                       */
    Coding_PSD_Ges_Gesetzlich_Zusatz PSD_Ges_Gesetzlich_Zusatz;
        /* PSD_06.PSD_Ges_Gesetzlich_Zusatz                          */
    Coding_PSD_Ges_Verkehrszeichen_Quelle PSD_Ges_Verkehrszeichen_Quelle;
    Coding_PSD_Ges_Attribute_Komplett PSD_Ges_Attribute_Komplett;
        /* PSD_06.PSD_Ges_Attribute_Komplett                         */
    UINT_GAP_16 PaddingGap16_1;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd62Message; 
#define Rte_TypeDef_Coding_PSD_Baum_Laenge_VZ 
typedef uint8 Coding_PSD_Baum_Laenge_VZ; 
# define Coding_PSD_Baum_Laenge_VZ_LowerLimit (0U)
# define Coding_PSD_Baum_Laenge_VZ_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Baum_Laenge 
typedef uint32 Coding_PSD_Baum_Laenge; 
# define Coding_PSD_Baum_Laenge_LowerLimit (0U)
# define Coding_PSD_Baum_Laenge_UpperLimit (33554431U)
# ifndef Cx1FFFFFF_keine_GPS_Information 
#  define Cx1FFFFFF_keine_GPS_Information (33554431U)
# endif 
#define Rte_TypeDef_Coding_PSD_Baum_Breite_VZ 
typedef uint8 Coding_PSD_Baum_Breite_VZ; 
# define Coding_PSD_Baum_Breite_VZ_LowerLimit (0U)
# define Coding_PSD_Baum_Breite_VZ_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Baum_Breite 
typedef uint32 Coding_PSD_Baum_Breite; 
# define Coding_PSD_Baum_Breite_LowerLimit (0U)
# define Coding_PSD_Baum_Breite_UpperLimit (9000000U)
#define Rte_TypeDef_Coding_PSD_Baum_Ausrichtung 
typedef uint16 Coding_PSD_Baum_Ausrichtung; 
# define Coding_PSD_Baum_Ausrichtung_LowerLimit (0U)
# define Coding_PSD_Baum_Ausrichtung_UpperLimit (1023U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd63Message 
typedef struct _Dt_RECORD_PsdEhr_Psd63Message
  {
    Coding_PSD_Baum_Laenge_VZ PSD_Baum_Laenge_VZ;
        /* PSD_06.PSD_Ort_Laenge_VZ                                  */
    UINT_GAP_8 PaddingGap8_1;
    UINT_GAP_16 PaddingGap16_2;
    Coding_PSD_Baum_Laenge PSD_Baum_Laenge;
        /* PSD_06.PSD_Ort_Laenge                                     */
    Coding_PSD_Baum_Breite_VZ PSD_Baum_Breite_VZ;
        /* PSD_06.PSD_Ort_Breite_VZ                                  */
    UINT_GAP_8 PaddingGap8_3;
    UINT_GAP_16 PaddingGap16_4;
    Coding_PSD_Baum_Breite PSD_Baum_Breite;
        /* PSD_06.PSD_Ort_Breite                                     */
    Coding_PSD_Baum_Ausrichtung PSD_Baum_Ausrichtung;
        /* PSD_06.PSD_Ort_Ausrichtung                                */
    UINT_GAP_16 PaddingGap16_5;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd63Message; 
#define Rte_TypeDef_Coding_PSD_Steigung_1_Segment_ID 
typedef uint8 Coding_PSD_Steigung_1_Segment_ID; 
# define Coding_PSD_Steigung_1_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Steigung_1_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segment_Information_vorhanden 
#  define Cx00_keine_Segment_Information_vorhanden (0U)
# endif 
# ifndef Cx01_Fehler 
#  define Cx01_Fehler (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Steigung_1_A_Steigung 
typedef uint8 Coding_PSD_Steigung_1_A_Steigung; 
# define Coding_PSD_Steigung_1_A_Steigung_LowerLimit (0U)
# define Coding_PSD_Steigung_1_A_Steigung_UpperLimit (127U)
# ifndef Cx7E_mehr_als_15_Prozent 
#  define Cx7E_mehr_als_15_Prozent (126U)
# endif 
# ifndef Cx7F_Steigung_unbekannt 
#  define Cx7F_Steigung_unbekannt (127U)
# endif 
#define Rte_TypeDef_Coding_PSD_Steigung_1_A_Vorz 
typedef uint8 Coding_PSD_Steigung_1_A_Vorz; 
# define Coding_PSD_Steigung_1_A_Vorz_LowerLimit (0U)
# define Coding_PSD_Steigung_1_A_Vorz_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Steigung_1_A_Offset 
typedef uint8 Coding_PSD_Steigung_1_A_Offset; 
# define Coding_PSD_Steigung_1_A_Offset_LowerLimit (0U)
# define Coding_PSD_Steigung_1_A_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Steigung_1_B_Steigung 
typedef uint8 Coding_PSD_Steigung_1_B_Steigung; 
# define Coding_PSD_Steigung_1_B_Steigung_LowerLimit (0U)
# define Coding_PSD_Steigung_1_B_Steigung_UpperLimit (127U)
# ifndef Cx7E_mehr_als_15_Prozent 
#  define Cx7E_mehr_als_15_Prozent (126U)
# endif 
# ifndef Cx7F_Steigung_unbekannt 
#  define Cx7F_Steigung_unbekannt (127U)
# endif 
#define Rte_TypeDef_Coding_PSD_Steigung_1_B_Vorz 
typedef uint8 Coding_PSD_Steigung_1_B_Vorz; 
# define Coding_PSD_Steigung_1_B_Vorz_LowerLimit (0U)
# define Coding_PSD_Steigung_1_B_Vorz_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Steigung_1_B_Offset 
typedef uint8 Coding_PSD_Steigung_1_B_Offset; 
# define Coding_PSD_Steigung_1_B_Offset_LowerLimit (0U)
# define Coding_PSD_Steigung_1_B_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Steigung_1_Attribute_kompl 
typedef uint8 Coding_PSD_Steigung_1_Attribute_kompl; 
# define Coding_PSD_Steigung_1_Attribute_kompl_LowerLimit (0U)
# define Coding_PSD_Steigung_1_Attribute_kompl_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Steigung_2_Segment_ID 
typedef uint8 Coding_PSD_Steigung_2_Segment_ID; 
# define Coding_PSD_Steigung_2_Segment_ID_LowerLimit (0U)
# define Coding_PSD_Steigung_2_Segment_ID_UpperLimit (63U)
# ifndef Cx00_keine_Segment_Information_vorhanden 
#  define Cx00_keine_Segment_Information_vorhanden (0U)
# endif 
# ifndef Cx01_Fehler 
#  define Cx01_Fehler (1U)
# endif 
#define Rte_TypeDef_Coding_PSD_Steigung_2_Steigung 
typedef uint8 Coding_PSD_Steigung_2_Steigung; 
# define Coding_PSD_Steigung_2_Steigung_LowerLimit (0U)
# define Coding_PSD_Steigung_2_Steigung_UpperLimit (127U)
# ifndef Cx7E_mehr_als_15_Prozent 
#  define Cx7E_mehr_als_15_Prozent (126U)
# endif 
# ifndef Cx7F_Steigung_unbekannt 
#  define Cx7F_Steigung_unbekannt (127U)
# endif 
#define Rte_TypeDef_Coding_PSD_Steigung_2_Vorz 
typedef uint8 Coding_PSD_Steigung_2_Vorz; 
# define Coding_PSD_Steigung_2_Vorz_LowerLimit (0U)
# define Coding_PSD_Steigung_2_Vorz_UpperLimit (1U)
#define Rte_TypeDef_Coding_PSD_Steigung_2_Offset 
typedef uint8 Coding_PSD_Steigung_2_Offset; 
# define Coding_PSD_Steigung_2_Offset_LowerLimit (0U)
# define Coding_PSD_Steigung_2_Offset_UpperLimit (127U)
#define Rte_TypeDef_Coding_PSD_Steigung_2_Attribute_kompl 
typedef uint8 Coding_PSD_Steigung_2_Attribute_kompl; 
# define Coding_PSD_Steigung_2_Attribute_kompl_LowerLimit (0U)
# define Coding_PSD_Steigung_2_Attribute_kompl_UpperLimit (1U)
#define Rte_TypeDef_Dt_RECORD_PsdEhr_Psd64Message 
typedef struct _Dt_RECORD_PsdEhr_Psd64Message
  {
    Coding_PSD_Steigung_1_Segment_ID PSD_Steigung_1_Segment_ID;
        /* PSD_06.PSD_Steigung_1_Segment_ID                          */
    Coding_PSD_Steigung_1_A_Steigung PSD_Steigung_1_A_Steigung;
        /* PSD_06.PSD_Steigung_1_A_Steigung                          */
    Coding_PSD_Steigung_1_A_Vorz PSD_Steigung_1_A_Vorz;
        /* PSD_06.PSD_Steigung_1_A_Vorz                              */
    Coding_PSD_Steigung_1_A_Offset PSD_Steigung_1_A_Offset;
        /* PSD_06.PSD_Steigung_1_A_Offset                            */
    Coding_PSD_Steigung_1_B_Steigung PSD_Steigung_1_B_Steigung;
        /* PSD_06.PSD_Steigung_1_B_Steigung                          */
    Coding_PSD_Steigung_1_B_Vorz PSD_Steigung_1_B_Vorz;
        /* PSD_06.PSD_Steigung_1_B_Vorz                              */
    Coding_PSD_Steigung_1_B_Offset PSD_Steigung_1_B_Offset;
        /* PSD_06.PSD_Steigung_1_B_Offset                            */
    Coding_PSD_Steigung_1_Attribute_kompl PSD_Steigung_1_Attribute_kompl;
        /* PSD_06.PSD_Steigung_1_Attribute_komplett                  */
    Coding_PSD_Steigung_2_Segment_ID PSD_Steigung_2_Segment_ID;
        /* PSD_06.PSD_Steigung_2_Segment_ID                          */
    Coding_PSD_Steigung_2_Steigung PSD_Steigung_2_Steigung;
        /* PSD_06.PSD_Steigung_2_Steigung                            */
    Coding_PSD_Steigung_2_Vorz PSD_Steigung_2_Vorz;
        /* PSD_06.PSD_Steigung_2_Vorz                                */
    Coding_PSD_Steigung_2_Offset PSD_Steigung_2_Offset;
        /* PSD_06.PSD_Steigung_2_Offset                              */
    Coding_PSD_Steigung_2_Attribute_kompl PSD_Steigung_2_Attribute_kompl;
        /* PSD_06.PSD_Steigung_2_Attribute_komplett                  */
    UINT_GAP_8 PaddingGap8_1;
    UINT_GAP_16 PaddingGap16_2;
    Dt_RECORD_TimestampMid DeTimestamp;
  } Dt_RECORD_PsdEhr_Psd64Message; 

#endif
