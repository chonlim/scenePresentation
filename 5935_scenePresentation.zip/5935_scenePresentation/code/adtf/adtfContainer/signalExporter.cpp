#include "stdafx.h"
#include "signalExporter.h"
#include "control\controlTask\controlTask_adtfTools.h"
#include <stdio.h>

signalExporterFilter_T::signalExporterFilter_T(const tChar* __info)
	: baseFilter_T(__info)
{
	this->AddInputPin("controlHeap_in", pemControlHeap_header());
	this->AddOutputPin("Qt-String", MEDIA_TYPE_STRUCTURED_DATA, MEDIA_SUBTYPE_STRUCT_UINT8);
	this->AddOutputPin("controlHeap_out", pemControlHeap_header());
}


bool	signalExporterFilter_T::OnInitNormal(void)
{
	memset(&this->heap, 0, sizeof(this->heap));
	this->receive_counter = 0;
	this->transmit_counter = 0;
	//cKernelCyclicThread::Create();
	return true;
}


void	signalExporterFilter_T::OnShutdownNormal(void)
{
	/* Zyklischen Thread abbrechen */
	//cKernelCyclicThread::Release();
}


tResult	signalExporterFilter_T::CyclicFunc(void)
{
	this->transmit_counter++;
	this->heap.sysControlInfo.systemActive = (bool_T)true;
	this->Submit("controlHeap_out", &this->heap, sizeof(heap));
	//char string[] = "T\0";
	char string[25] = "";
	int a=sprintf_s(string,25, "T:%d R:%d", this->transmit_counter,this->receive_counter);
	this->Submit("Qt-String", &string, sizeof(string));
	RETURN_NOERROR;
}

void	signalExporterFilter_T::OnReceive(void)
{
	if (this->GetInputPin("controlHeap_in")->Unflag()) {
		this->receive_counter++;
		this->EnterMutex();
		this->heap = *(pemControlHeap_T*)this->GetInputPin("controlHeap_in")->GetDataPtr();
		this->LeaveMutex();
		char string[25] = "";
		int b = sprintf_s(string, 25, "T:%d R:%d", this->transmit_counter, this->receive_counter);
		this->Submit("Qt-String", &string, sizeof(string));
	}
}