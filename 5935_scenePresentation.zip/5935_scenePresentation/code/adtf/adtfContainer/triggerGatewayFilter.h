#ifndef guard_triggerGatewayFilter_h
#define guard_triggerGatewayFilter_h

#include "baseFilter.h"
#include "waveFile.h"

#include <set>

#define ADTF_FILTER_ID_triggerGatewayFilter		"IDII.triggerGatewayFilter"
#define ADTF_FILTER_NAME_triggerGatewayFilter	"IDII triggerGatewayFilter"


class triggerGatewayFilter_T
  : public baseFilter_T,
	public adtf::IKeyEventHandler
{
	ADTF_DECLARE_FILTER_VERSION(ADTF_FILTER_ID_triggerGatewayFilter, ADTF_FILTER_NAME_triggerGatewayFilter, OBJCAT_Generic, "IDII_Version", 2, 0, 0, __DATE__" - "__TIME__ );

private:
	bool_T			triggerActive;

	/* FIBEX-IDs der Signale und PDUs, die wir ben�tigen */
	struct {
		struct {
			std::set<tUInt32>	pdu;
			tUInt32				MFL_Tastencode_1;
			tUInt32				MFL_Tastencode_2;
		} MFL_Tasten_01;
	} id;

	cObjectPtr<adtf_devicetb::IFlexRayCoder>	flexrayCoder;

	bool_T			 flexrayTrigger;
	bool_T			 canTrigger;
	bool_T			 keyTrigger;

	bool_T			 flexrayToggle;
	bool_T			 canToggle;

	cAudioPin		 pinIn_audioIn;
	cAudioPin		 pinOut_audioOut;

	char_T			 commentFolder[1024];
	waveFile_T		 commentFile;
	uint32_T		 fileCount;

	bool_T			 flexrayUp;
	bool_T			 flexrayDown;

	bool_T			 canUp;
	bool_T			 canDown;

	tTimeStamp		 curveTime;
	int8_T			 curveValue;

	bool_T			 lastUp;
	bool_T			 lastDown;

	inputPin_T		*inputPin_flexray;
	inputPin_T		*inputPin_canInfotainment;

	IGlobalKeyEventManager*	keyEventManager;


public:
	triggerGatewayFilter_T(const tChar* __info);

	bool		OnInitFirst(void);
	bool		OnInitNormal(void);
	bool		OnGraphReady(void);
	bool		OnStart(void);
	bool		OnStop(void);
	void		OnShutdownNormal(void);

	void		OnReceive(void);
	void		OnRun(int32_T type, const void *data, size_t size);

	tResult		OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample);
	tResult		OnKeyEvent(tKeyEventCode eCode, tInt nParam1 = 0, tInt nParam2 = 0, tInt nFlags = 0, tVoid* pEventData = NULL);

private:
	void		OnTrigger(void);
};


#endif
