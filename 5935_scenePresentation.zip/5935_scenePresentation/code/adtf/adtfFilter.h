#ifndef __ADTFFILTER_H_
#define __ADTFFILTER_H_

#include <string>

#include "base.h"

class pinHeader_T {
public:
	virtual std::string		GetTypeName(void) const			= 0;
	virtual size_t			GetTypeSize(void) const			= 0;

	virtual std::string		GetMediaDescription(void) const	= 0;

	virtual void			ExploreMembers(void *data,	int32_T(callback(const void* thisPtr, const char *name, const char *description,	int32_T  value)), void *context, const char *baseName) const	= 0;
	virtual void			ExploreMembers(void *data,	real64_T(callback(const void* thisPtr, const char *name, const char *description,	real64_T value)), void *context, const char *baseName) const	= 0;
	virtual void			ExploreMembers(void *data,	bool_T(callback(const void* thisPtr, const char *name, const char *description,		bool_T   value)), void *context, const char *baseName) const	= 0;

	virtual pinHeader_T*	Duplicate(void) const	= 0;
};


#endif