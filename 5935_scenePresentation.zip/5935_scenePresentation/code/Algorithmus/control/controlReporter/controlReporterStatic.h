#ifndef guard_controlReporterStatic_h
#define guard_controlReporterStatic_h


static void		   crpErrorCallback(INOUT		void				*userData,
									IN	const	diagModule_T		 module,
									IN	const	uint32_T			 line
									);


static void			   crpPushError(INOUT		controlReport_T		*controlReport,
									IN	const	diagModule_T		 module,
									IN	const	uint32_T			 line
									);


static void			crpPopErrorCode(INOUT		controlReport_T		*controlReport,
									OUT			uint16_T			*coded
									);


static void				crpPushCode(INOUT		controlReport_T		*controlReport,
									IN	const	uint16_T			 errorCode
									);


#endif
