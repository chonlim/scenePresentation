#include "controlReporter.h"
#include "controlReporterStatic.h"

#include "control/controlReporter/controlReporter_private.h"
#include "common/platformInterface/pltfDiagTypes.h"
#include "common/strategyReporterCommon/srpTools.h"

#include "common/platformInterface/pltfDiag.h"


void		  controlReporterAttach(INOUT		controlReport_T		*controlReport,
									IN	const	strategyReport_T	*strategyReport)
{
	uint16_T index;
	uint32_T aliveCount;
	uint16_T errorCount;

	srpGetAliveCount(strategyReport, &aliveCount);
	srpGetErrorCount(strategyReport, &errorCount);

	for(index = 0; index < errorCount; index++) {
		uint16_T errorCode;

		srpGetErrorCode(strategyReport, index, &errorCode);
		crpPushCode(controlReport, errorCode);
	}

	controlReport->lastStrategyAlive = aliveCount;

	diagRegisterErrorCallback(crpErrorCallback, controlReport);
}


void		  controlReporterDetach(INOUT		controlReport_T		*controlReport,
									OUT			uint16_T			*controlCode)
{
	diagUnregisterErrorCallback();
	crpPopErrorCode(controlReport, controlCode);
}


static void			crpPopErrorCode(INOUT		controlReport_T		*controlReport,
									OUT			uint16_T			*coded)
{
	uint16_T value;
	uint16_T subtr;

	if (controlReport->first < (uint16_T)crpREPORTCOUNT)
	{
		value = controlReport->item[controlReport->first];
		subtr = controlReport->count > 0u ? (uint16_T)1 : (uint16_T)0;
	} else {
		value = 0u;
		subtr = 0u;
	}

	controlReport->count -= subtr;
	controlReport->first += subtr;
	controlReport->first %= (uint16_T)crpREPORTCOUNT;

	*coded = subtr > 0u ? value : 0u;
}


static void		   crpErrorCallback(INOUT		void				*userData,
									IN	const	diagModule_T		 module,
									IN	const	uint32_T			 line)
{
	/*Da der Callback auch mit strategyReport_T nutzbar sein muss, m�ssen wir hier den Pointer casten*/
	crpPushError((controlReport_T*)userData, module, line); /*lint !e9079 !e9087 (Note -- cast performed between a pointer to object type and a pointer to a different object type [MISRA 2012 Rule 11.3, required])*/
}


static void			   crpPushError(INOUT		controlReport_T		*controlReport,
									IN	const	diagModule_T		 module,
									IN	const	uint32_T			 line)
{
	uint16_T coded;
	uint16_T moduleCode;

	moduleCode = (module == diagModule_Info) ? 31U : ((uint16_T)module % 31u);
	coded = (moduleCode << 5u) | (((uint16_T)line % 30u) + 1u); /*lint !e734 (Info -- Loss of precision (assignment) (22 bits to 16 bits)*/

	crpPushCode(controlReport, coded);
}


static void				crpPushCode(INOUT		controlReport_T		*controlReport,
									IN	const	uint16_T			 errorCode)
{
	uint16_T index;

	index = (controlReport->first + controlReport->count) % (uint16_T)crpREPORTCOUNT;

	/* Laufzeitstabilit�t ist hier nicht relevant, da die Funktion nur auf dem Fehlerpfad aufgerufen wird */
	if(controlReport->count < (uint16_T)crpREPORTCOUNT) {
		controlReport->item[index] = errorCode;
		controlReport->count++;
	}
}
