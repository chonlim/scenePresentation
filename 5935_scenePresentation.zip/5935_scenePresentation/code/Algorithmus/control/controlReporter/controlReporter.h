#ifndef guard_controlReporter_h
#define guard_controlReporter_h


#include "control/control.h"

#include "common/platformInterface/pltfDiagTypes.h"
#include "common/strategyReporterCommon/strategyReporter_interface.h"
#include "control/controlReporter/controlReporter_interface.h"


void		  controlReporterAttach(INOUT		controlReport_T		*controlReport,
									IN	const	strategyReport_T	*strategyReport
									);


void		  controlReporterDetach(INOUT		controlReport_T		*controlReport,
									OUT			uint16_T			*controlCode
									);


#endif
