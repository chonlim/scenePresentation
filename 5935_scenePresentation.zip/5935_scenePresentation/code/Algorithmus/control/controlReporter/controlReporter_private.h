#ifndef guard_controlReporter_private_h
#define guard_controlReporter_private_h

#include "control/controlReporter/controlReporter_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define crpREPORTCOUNT 16



struct _controlReport {
	uint32_T lastStrategyAlive;          /**< Letzter bekannter Alive-Zähler vom Strategy-Task */
	uint16_T first;                      /**< Index des ersten Eintrags in der Meldungsliste */
	uint16_T count;                      /**< Anzahl gültiger Einträge in der Meldungsliste */
	uint16_T item[crpREPORTCOUNT];       /**< Codierte Meldungen für die Ausgabe über PACC02_Durchschnittsgeschw */
} ;                                      /**< Groesse der Struktur = 40 Bytes */


/*lint -restore */

#endif
