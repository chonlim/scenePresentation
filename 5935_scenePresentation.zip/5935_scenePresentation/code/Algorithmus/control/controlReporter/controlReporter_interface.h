#ifndef guard_controlReporter_interface_h
#define guard_controlReporter_interface_h

#include "base.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef struct _controlReport controlReport_T;



/*lint -restore */

#endif
