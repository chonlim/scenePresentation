#ifndef __ehrInterface_private_h_
#define __ehrInterface_private_h_

#include "control\ehrInterface\ehrInterface_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */






/*lint -restore */

#endif
