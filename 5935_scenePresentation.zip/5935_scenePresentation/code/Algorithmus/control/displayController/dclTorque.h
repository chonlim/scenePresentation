#ifndef guard_dclTorque_h
#define guard_dclTorque_h

#include "control/displayController/dclStep.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "common/longTorquePlannerCommon/lntqTools.h"

typedef	struct _dclTorque {
	bool_T				valid;
	displayConstraint_T	type;
	real32_T			velocity;
	real32_T			position;
	real32_T			acceleration;
	real32_T			limitAcceleration;
} dclTorque_T;

/**\brief Ermittelt Anzeigesignale zu L�ngsregelereignissen

L�ngsregelereignisse sind zu Kurven, Abzweigungen, Rampen und Kreisverkehre.
Zus�tzlich wird eine Fahrer�bernahmeaufforderung berechnet.

\spec SW_AS_Innodrive2_57

\ingroup displayController_step
*/
void			  dclStepTorque(INOUT		uint32_T			*torqueChangeTicks,
								INOUT		bool_T				*lastCurveTakeover,
								IN	const	parameterSetCtrl_T	*paramSet,
								IN	const	longTorque_T		*longTorque,
								IN	const	displayEvent_T		 lastEvent,
								IN	const	bool_T				 previewLock,
								IN	const	real32_T			 currentSetVelocity,
								IN	const	real32_T			 nextSetVelocity,
								IN	const	bool_T				 nextSetValid,
								IN	const	real32_T			 egoPosition,
								IN	const	real32_T			 egoVelocity,
								OUT			dclPreview_T		*torquePreview,
								OUT			bool_T				*curveTakeover
								);

#endif
