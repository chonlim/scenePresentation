#include "control/displayController/displayController.h"
#include "control/displayController/displayController_private.h"
#include "control/displayController/dclTools.h"


void		  dclGetPreviewVelocity(IN	const	displayControl_T	*displayControl,
									OUT			real32_T			*previewVelocity,
									OUT			bool_T				*previewValid,
									OUT			bool_T				*displayNextSetSpeed)
{
	*previewVelocity	= displayControl->previewVelocity;
	*previewValid		= displayControl->previewValid;
	*displayNextSetSpeed= displayControl->displayNextSetSpeed;
}


void			 dclGetDisplayEvent(IN	const	displayControl_T	*displayControl,
									OUT			displayEvent_T		*displayEvent)
{
	*displayEvent		= displayControl->displayEvent;
}


void			dclGetCurveTakeover(IN	const	displayControl_T	*displayControl,
									OUT			bool_T				*curveTakeover)
{
	*curveTakeover		= displayControl->curveTakeover;
}

