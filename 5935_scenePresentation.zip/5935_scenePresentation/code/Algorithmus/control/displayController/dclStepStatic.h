#ifndef guard_dclStepStatic_h
#define guard_dclStepStatic_h

#include "control/displayController/dclStep.h"
#include "control/parameterSet/parameterSetCtrl.h"


/**\brief Filtern und verstecken der Vorausschaugeschwindigkeit.

Wenn im letzten Zeitschritt eine g�ltige Anforderung f�r die Vorausschaugeschwindigkeit vorgelegen hat,
wird diese tiefpassgefiltert.
Die Vorausschau-Geschwindigkeit wird nur angezeigt, 
wenn sie sich signifikant von der Ego-Geschwindigkeit unterscheidet.

\spec SW_AS_Innodrive2_57
\spec SW_AS_Innodrive2_43

\ingroup displayController_step
*/
static void			   dclFilterPreview(INOUT		displayEvent_T		*eventFilter,
										INOUT		dclFilter_T			*previewFilter,
										INOUT		bool_T				*previewValidFilter,
										IN	const	real32_T			 egoVelocity,
										IN	const	bool_T				 displayNextSetSpeed,
										IN	const	dclPreview_T		*preview,
										IN	const	parameterSetCtrl_T	*paramSet,
										OUT			displayEvent_T		*targetEvent,
										OUT			bool_T				*targetValid,
										OUT			real32_T			*targetPreview
										);

/**\brief Die zuk�nftige Setzgeschwindigkeit wird nur angezeigt, wenn sie sich von der aktuellen Setzgeschwindigkeit unterscheidet.

\spec SW_AS_Innodrive2_645

\ingroup displayController_step
*/
static void	  dclGetDisplayNextSetSpeed(IN	const	real32_T			 currentSetVelocity,
										IN	const	real32_T			 nextSetVelocity,
										IN	const	bool_T				 nextSetValid,
										OUT			bool_T				*displayNextSetSpeed
										);
#endif
