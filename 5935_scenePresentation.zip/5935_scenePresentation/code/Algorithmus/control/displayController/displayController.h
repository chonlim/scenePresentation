#ifndef guard_displayController_h
#define guard_displayController_h

#include "control/control.h"
#include "control/displayController/displayController_interface.h"

#include "common/systemControllerCommon/systemController_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/longTorquePlannerCommon/longTorquePlanner_interface.h"


/**\brief Ermittelt Anzeigesignale
\ingroup displayController_step
*/
void				  displayController(MEMORY		displayMemory_T			*displayMemory,
										IN	const	systemControl_T			*systemControl,
										IN	const	vehicleState_T			*vehicleState,
										IN	const	longTorque_T			*longTorque,
										OUT			displayControl_T		*displayControl
										);


#endif
