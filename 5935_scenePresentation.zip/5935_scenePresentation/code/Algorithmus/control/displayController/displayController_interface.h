#ifndef guard_displayController_interface_h
#define guard_displayController_interface_h

#include "base.h"
#include "common/systemControllerCommon/systemController_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef enum _displayEvent {
	eventNone = 0,                       /**< Kein Vorausschauevent */
	eventSpeedLimit_5 = 1,               /**< Geschwindigkeitslimit 5 */
	eventSpeedLimit_10 = 2,              /**< Geschwindigkeitslimit 10 */
	eventSpeedLimit_15 = 3,              /**< Geschwindigkeitslimit 15 */
	eventSpeedLimit_20 = 4,              /**< Geschwindigkeitslimit 20 */
	eventSpeedLimit_25 = 5,              /**< Geschwindigkeitslimit 25 */
	eventSpeedLimit_30 = 6,              /**< Geschwindigkeitslimit 30 */
	eventSpeedLimit_35 = 7,              /**< Geschwindigkeitslimit 35 */
	eventSpeedLimit_40 = 8,              /**< Geschwindigkeitslimit 40 */
	eventSpeedLimit_45 = 9,              /**< Geschwindigkeitslimit 45 */
	eventSpeedLimit_50 = 10,             /**< Geschwindigkeitslimit 50 */
	eventSpeedLimit_55 = 11,             /**< Geschwindigkeitslimit 55 */
	eventSpeedLimit_60 = 12,             /**< Geschwindigkeitslimit 60 */
	eventSpeedLimit_65 = 13,             /**< Geschwindigkeitslimit 65 */
	eventSpeedLimit_70 = 14,             /**< Geschwindigkeitslimit 70 */
	eventSpeedLimit_75 = 15,             /**< Geschwindigkeitslimit 75 */
	eventSpeedLimit_80 = 16,             /**< Geschwindigkeitslimit 80 */
	eventSpeedLimit_90 = 17,             /**< Geschwindigkeitslimit 90 */
	eventSpeedLimit_100 = 18,            /**< Geschwindigkeitslimit 100 */
	eventSpeedLimit_110 = 19,            /**< Geschwindigkeitslimit 110 */
	eventSpeedLimit_120 = 20,            /**< Geschwindigkeitslimit 120 */
	eventSpeedLimit_130 = 21,            /**< Geschwindigkeitslimit 130 */
	eventSpeedLimit_140 = 22,            /**< Geschwindigkeitslimit 140 */
	eventSpeedLimit_150 = 23,            /**< Geschwindigkeitslimit 150 */
	eventSpeedLimit_160 = 24,            /**< Geschwindigkeitslimit 160 */
	eventSpeedLimitReleased = 25,        /**< Geschwindigkeitslimit unbegrenzt */
	eventCurveLeft = 26,                 /**< Linkskurve */
	eventCurveRight = 27,                /**< Rechtskurve */
	eventBranchLeft = 28,                /**< Linksabbiegung */
	eventBranchRight = 29,               /**< Rechtsabbiegung */
	eventRampLeft = 30,                  /**< Abfahrt links */
	eventRampRight = 31,                 /**< Abfahrt rechts */
	eventRoundabout = 32,                /**< Kreisverkehr */
	eventStop = 33,                      /**< Stoppstelle */
	eventYield = 34                      /**< Vorfahrt beachten */
} displayEvent_T;

typedef struct _displayControl displayControl_T;
typedef struct _displayMemory displayMemory_T;



/*lint -restore */

#endif
