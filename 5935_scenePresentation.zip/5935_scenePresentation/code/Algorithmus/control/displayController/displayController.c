#include "control/displayController/displayController.h"
#include "control/displayController/dclStep.h"


void				  displayController(MEMORY		displayMemory_T			*displayMemory,
										IN	const	systemControl_T			*systemControl,
										IN	const	vehicleState_T			*vehicleState,
										IN	const	longTorque_T			*longTorque,
										OUT			displayControl_T		*displayControl)
{
	dclStep(displayMemory,
			systemControl,
			vehicleState,
			longTorque,
			displayControl);
}
