#ifndef guard_dclStep_h
#define guard_dclStep_h

#include "control/displayController/displayController.h"

typedef struct _preview {
	displayEvent_T		event;
	bool_T				valid;
	real32_T			target;
} dclPreview_T;


/**\brief Ermittelt Anzeigesignale
\ingroup displayController_step
*/
void				dclStep(MEMORY		displayMemory_T			*displayMemory,
							IN	const	systemControl_T			*systemControl,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	longTorque_T			*longTorque,
							OUT			displayControl_T		*displayControl
							);

#endif
