#include "control/displayController/displayController.h"
#include "control/displayController/displayController_private.h"
#include "control/displayController/dclFilter.h"

#include "common/systemControllerCommon/sysTools.h"

#include "control/parameterSet/parameterSetCtrl.h"


void			   dclLowPassFilter(MEMORY		dclFilter_T				*filter,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 cutoffFreq,
									IN	const	real32_T				 input,
									INOUT		real32_T				*output)
{
	real32_T coeffA[2];
	real32_T coeffB[2];


	/* Berechnen der Koeffizienten */
	coeffA[0] = deltaTime+(1.0f/(cutoffFreq*defPIf));
	coeffA[1] = deltaTime-(1.0f/(cutoffFreq*defPIf));

	coeffB[0] = deltaTime;
	coeffB[1] = deltaTime;


	/* Update des Filters */
	filter->input[1]	= filter->input[0];
	filter->output[1]	= filter->output[0];
	
	filter->input[0]	= input;
	filter->output[0]	= 0.0f;

	filter->output[0]	+= (filter->input[0] * coeffB[0]);
	filter->output[0]	+= (filter->input[1] * coeffB[1]);

	filter->output[0]	-= (filter->output[1] * coeffA[1]);

	filter->output[0]	/= coeffA[0];


	/* Ausgabe */
	*output = filter->output[0];
}


void			 dclFilterSetMemory(MEMORY		dclFilter_T				*filter,
									IN	const	real32_T				 input)
{
	/* Update des Filters */
	filter->input[0]	= input;
	filter->output[0]	= input;

	filter->input[1]	= input;
	filter->output[1]	= input;
}
