#ifndef guard_dclTools_h
#define guard_dclTools_h

/**\brief Ausgabe der im Display anzuzeigenden Regelgeschwindigkeit 

Die Regelgeschwindigkeit ist die Geschwindigkeit, 
die vom System unter Ber�cksichtigung der Umgebungsbedingungen eingeregelt wird

\spec SW_AS_Innodrive2_57
\spec SW_AS_Innodrive2_645
\ingroup displayController_api
*/
void		  dclGetPreviewVelocity(IN	const	displayControl_T	*displayControl,
									OUT			real32_T			*previewVelocity,
									OUT			bool_T				*previewValid,
									OUT			bool_T				*displayNextSetSpeed
									);


/**\brief Ausgabe des im Display anzuzeigenden Events (Tempolimit / Kreisverkehr / Kurve / Stoppstelle)
\spec SW_AS_Innodrive2_43
\ingroup displayController_api
*/
void			 dclGetDisplayEvent(IN	const	displayControl_T	*displayControl,
									OUT			displayEvent_T		*displayEvent
									);


/**\brief Ausgabe der zuk�nftigen Regelgeschwindigkeit 
\ingroup displayController_api
*/
void			dclGetCurveTakeover(IN	const	displayControl_T	*displayControl,
									OUT			bool_T				*curveTakeover
									);

#endif
