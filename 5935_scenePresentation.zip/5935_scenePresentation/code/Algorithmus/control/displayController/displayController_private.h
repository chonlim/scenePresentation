#ifndef guard_displayController_private_h
#define guard_displayController_private_h

#include "control/displayController/displayController_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */




struct _displayControl {
	real32_T previewVelocity;            /**< Vorausschaugeschwindigkeit[m/s] */
	bool_T previewValid;                 /**< Gibt an, ob die Vorausschaugeschwindigkeit gültig ist */
	bool_T displayNextSetSpeed;          /**< Ob eine gültige nächste Setzgeschwindigkeit vorliegt, die sich von der aktuellen unterscheidet (und über previewVelocity ausgegeben wird)  */
	displayEvent_T displayEvent;
	bool_T curveTakeover;                /**< Übernahmeaufforderung wegen drohender Überschreitung von Kurvengeschwindigkeiten */
} ;                                      /**< Groesse der Struktur = 16 Bytes */

typedef struct _dclFilter {
	real32_T input[2];                   /**< Historie der Input-Samples des Filters */
	real32_T output[2];                  /**< Historie der Output-Samples des Filters */
} dclFilter_T;                           /**< Groesse der Struktur = 16 Bytes */

struct _displayMemory {
	displayEvent_T lastEvent;
	bool_T lastCurveTakeover;            /**< Gibt an, ob im letzten Zeitschritt eine Fahrerübernahmeaufforderung wegen drohender Überschreitung von Kurvengeschwindigkeiten gesetzt war */
	dclFilter_T previewFilter;
	bool_T lastPreviewValid;             /**< Gibt an, ob im letzten Zeitschritt eine gültige Anforderung für die Vorausschaugeschwindigkeit vorgelegen hat */
	uint32_T torqueChangeTicks;          /**< Anzahl der Zeitschritte, in denen durchgängig ein geändertes Torque-Event vorgelegen hat[20 ms] */
} ;                                      /**< Groesse der Struktur = 32 Bytes */


/*lint -restore */

#endif
