#ifndef guard_dclTorqueStatic_h
#define guard_dclTorqueStatic_h

#include "control/displayController/dclTorque.h"

/**\brief Abfrage von Vorausschau-Events beim longTorquePlanner

\spec SW_AS_Innodrive2_57

\ingroup displayController_step
*/
static void			   dclGetTorque(IN	const	longTorque_T		*longTorque,
									OUT			dclTorque_T			*torque
									);

/**\brief Abfragen der Geschwindigkeit, mit der die relevante Einschr�nkung lt. longTorquePlanner voraussichtlich erreicht wird.

\spec SW_AS_Innodrive2_57

\ingroup displayController_step
*/
static bool_T	 dclGetReachPreview(IN	const	longTorque_T		*longTorque,
									IN	const	dclTorque_T			*torque,
									OUT			bool_T				*valid,
									OUT			real32_T			*mergeVelocity,
									OUT			real32_T			*curveDelta
									);

/**\brief Ermitteln des anzuzeigenden L�ngsregelereignisses

Wenn ein Event bereits angezeigt wird, greift eine Hysterese f�r die Filterkriterien.
Neue Events werden nur getriggert, wenn der systemContoller keine Sperre angefordert hat.
Vorausschau-Events werden nur angezeigt, wenn sie die zul�ssige Beschleunigung signifikant einschr�nken.
Vorausschau-Events werden nur angezeigt, wenn sie die zul�ssige Beschleunigung gg�. der Setzgeschwindigkeit einschr�nken.
Vorausschau-Events werden nur angezeigt, wenn sich die Vorausschau-Geschwindigkeit signifikant von der Setzgeschwnidigkeit unterscheidet.
Neue Events werden nur getriggert, wenn sie eine voraussichtliche Mindest-Anzeigedauer erreichen.

\spec SW_AS_Innodrive2_57

\ingroup displayController_step
*/
static void		dclGetTorquePreview(INOUT		uint32_T			*torqueChangeTicks,
									IN	const	parameterSetCtrl_T	*paramSet,
									IN	const	displayEvent_T		 lastEvent,
									IN	const	bool_T				 previewLock,
									IN	const	real32_T			 currentSetVelocity,
									IN	const	real32_T			 nextSetVelocity,
									IN	const	bool_T				 nextSetValid,
									IN	const	real32_T			 egoPosition,
									IN	const	real32_T			 egoVelocity,
									IN	const	dclTorque_T			*torque,
									IN	const	bool_T				 reachValid,
									IN	const	real32_T			 mergeVelocity,
									OUT			dclPreview_T		*preview
									);

/**\brief Wechsel zwischen L�ngsregelereignissen entprellen.

Ein direkter Wechsel zwischen zwei torqueEvents ist nur zul�ssig, wenn 
sich f�r eine applizierbare Mindestzeit durchg�ngig 
das angeforderte vom angezeigten Event unterscheidet.

\spec SW_AS_Innodrive2_57

\ingroup displayController_step
*/
static void	   dclFilterTorqueEvent(INOUT		uint32_T			*torqueChangeTicks,
									INOUT		displayEvent_T		*eventTarget,
									IN	const	displayEvent_T		 lastEvent,
									IN	const	parameterSetCtrl_T	*paramSet
									);

/**\brief Pr�fung, ob ein Ereignis ein L�ngsregelereignis ist.

\spec SW_AS_Innodrive2_57

\ingroup displayController_step
*/
static void		   dclIsTorqueEvent(IN	const	displayEvent_T		 displayEvent,
									OUT			bool_T				*eventIsTorque
									);

/**\brief Ermittlung, ob eine �bernameaufforderung aufgrund eines L�ngsregelereignisses angezeigt wird.

Eine Fahrer�bernahmeaufforderung wird ausgel�st, wenn 
eine deutliche �berschreitung der zul�ssigen Geschwindigkeit aufgrund 
einer Kurve, Abfahrt oder eines Kreisverkehrs 
angek�ndigt wird.

\spec SW_AS_Innodrive2_49

\ingroup displayController_step
*/
static void	 dclFilterCurveTakeover(INOUT		bool_T				*lastCurveTakeover,
									IN	const	bool_T				 reachValid,
									IN	const	displayConstraint_T	 torqueType,
									IN	const	real32_T			 curveDelta,
									IN	const	parameterSetCtrl_T	*paramSet,
									OUT			bool_T				*takeover
									);

#endif
