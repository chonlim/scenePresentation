#ifndef guard_dclFilter_h
#define guard_dclFilter_h

/**\brief Update eines Tiefpassfilters
\ingroup displayController_filter
*/
void			   dclLowPassFilter(MEMORY		dclFilter_T				*filter,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 cutoffFreq,
									IN	const	real32_T				 input,
									OUT			real32_T				*output
									);

/**\brief Initialisierung eines Tiefpassfilters
\ingroup displayController_filter
*/
void			 dclFilterSetMemory(MEMORY		dclFilter_T				*filter,
									IN	const	real32_T				 input
									);

#endif
