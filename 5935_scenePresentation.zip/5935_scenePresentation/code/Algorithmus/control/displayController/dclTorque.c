#include "control/displayController/dclTorque.h"
#include "control/displayController/dclTorqueStatic.h"


void				  dclStepTorque(INOUT		uint32_T			*torqueChangeTicks,
									INOUT		bool_T				*lastCurveTakeover,
									IN	const	parameterSetCtrl_T	*paramSet,
									IN	const	longTorque_T		*longTorque,
									IN	const	displayEvent_T		 lastEvent,
									IN	const	bool_T				 previewLock,
									IN	const	real32_T			 currentSetVelocity,
									IN	const	real32_T			 nextSetVelocity,
									IN	const	bool_T				 nextSetValid,
									IN	const	real32_T			 egoPosition,
									IN	const	real32_T			 egoVelocity,
									OUT			dclPreview_T		*torquePreview,
									OUT			bool_T				*curveTakeover)
{
	dclTorque_T			torque;
	
	bool_T				reachValid;
	real32_T			mergeVelocity;
	real32_T			curveDelta;
	
	/*Abfragen vom longTorquePlanner*/
	dclGetTorque( longTorque, 
				 &torque);

	if (!dclGetReachPreview( longTorque,
							&torque,
							&reachValid,
							&mergeVelocity,
							&curveDelta)) {
		torque.valid = false;
	}

	/* Wenn der Event-Slot nicht bereits vom systemController belegt wird, k�nnen wir ggf. die relevante
	   L�ngsregeleinschr�nkung anzeigen */
	dclGetTorquePreview( torqueChangeTicks,
						 paramSet,
						 lastEvent,
						 previewLock,
						 currentSetVelocity,
						 nextSetVelocity,
						 nextSetValid,
						 egoPosition,
						 egoVelocity,
						&torque,
						 reachValid,
						 mergeVelocity,
						 torquePreview);

	dclFilterCurveTakeover(lastCurveTakeover,
						   reachValid,
						   torque.type,
						   curveDelta,
						   paramSet,
						   curveTakeover);
}


static void			   dclGetTorque(IN	const	longTorque_T		*longTorque,
									OUT			dclTorque_T			*torque)							
{
	bool_T				torqueValid;
	displayConstraint_T	torqueType;
	real32_T			torqueVelocity;
	real32_T			torquePosition;
	real32_T			torqueAcceleration;
	real32_T			torqueLimitAcceleration;

	/* Abfrage von Vorausschau-Events beim longTorquePlanner */
	lntqIsValid( longTorque,
				&torqueValid);

	if(torqueValid) {
		if(!lntqGetDisplayConstraint( longTorque,
									  &torqueType,
									  &torquePosition,
									  &torqueVelocity,
									  &torqueAcceleration)) {
			torqueValid	= false;

			torqueType			= constraintNone;
			torquePosition		= INVALID_VALUE;
			torqueVelocity		= 0.0f;
			torqueAcceleration	= INVALID_VALUE;
		}

		if(!lntqGetLimitAcceleration( longTorque,
									 &torqueLimitAcceleration)) { 
			torqueValid = false;

			torqueLimitAcceleration	= INVALID_VALUE;
		}
	}
	else {
		torqueType				= constraintNone;
		torquePosition			= INVALID_VALUE;
		torqueVelocity			= 0.0f;
		torqueAcceleration		= INVALID_VALUE;
		torqueLimitAcceleration	= INVALID_VALUE;
	}

	torque->valid				= torqueValid;
	torque->type				= torqueType;
	torque->position			= torquePosition;
	torque->velocity			= torqueVelocity;
	torque->acceleration		= torqueAcceleration;
	torque->limitAcceleration	= torqueLimitAcceleration;
}


static bool_T	 dclGetReachPreview(IN	const	longTorque_T		*longTorque,
									IN	const	dclTorque_T			*torque,
									OUT			bool_T				*valid,
									OUT			real32_T			*mergeVelocity,
									OUT			real32_T			*curveDelta)
{	
	real32_T			reachVelocity;
	real32_T			curveVelocity;
	bool_T				reachValid;
	bool_T				gotCurveReach = true;

	/* Abfragen der Geschwindigkeit, mit der die relevante Einschr�nkung lt. longTorquePlanner voraussichtlich erreicht wird. */
	if(torque->valid) {
		if(!lntqGetCurveReach( longTorque,
							  &reachValid,
							  &reachVelocity,
							  &curveVelocity)) {
			gotCurveReach = false;

			reachValid		= false;
			reachVelocity	= 0.0f;
			curveVelocity	= 0.0f;
		}
	}
	else {
		reachValid		= false;
		reachVelocity	= 0.0f;
		curveVelocity	= 0.0f;
	}

	*valid			= reachValid;
	*mergeVelocity	= max(reachVelocity, torque->velocity);
	*curveDelta		= reachVelocity - curveVelocity;

	return gotCurveReach;
}

static void		dclGetTorquePreview(INOUT		uint32_T			*torqueChangeTicks,
									IN	const	parameterSetCtrl_T	*paramSet,
									IN	const	displayEvent_T		 lastEvent,
									IN	const	bool_T				 previewLock,
									IN	const	real32_T			 currentSetVelocity,
									IN	const	real32_T			 nextSetVelocity,
									IN	const	bool_T				 nextSetValid,
									IN	const	real32_T			 egoPosition,
									IN	const	real32_T			 egoVelocity,
									IN	const	dclTorque_T			*torque,
									IN	const	bool_T				 reachValid,
									IN	const	real32_T			 mergeVelocity,
									OUT			dclPreview_T		*preview)
{
	displayEvent_T	candEvent;
	real32_T		torqueTTC;
	bool_T			alreadyDisplayed;
	bool_T			lockAllowed;
	bool_T			accelerationAllowed;
	bool_T			significanceAllowed;
	bool_T			velocityAllowed;
	bool_T			distanceAllowed;
	real32_T		relVelocity;
	real32_T		setTarget;

	/* Berechnen der TTC zum Vorausschauevent */
	torqueTTC	= (torque->position - egoPosition) / max(egoVelocity, 1.0f);
	setTarget	= nextSetValid ? nextSetVelocity : currentSetVelocity;

	/* Zuordnung von Einschr�nkungen zu Display-Events */
	candEvent = eventNone;
	if(torque->type == constraintCurveLeft)		{ candEvent = eventCurveLeft;  }
	if(torque->type == constraintCurveRight)	{ candEvent = eventCurveRight; }
	if(torque->type == constraintBranchLeft)	{ candEvent = eventBranchLeft;  }
	if(torque->type == constraintBranchRight)	{ candEvent = eventBranchRight; }
	if(torque->type == constraintRampLeft)		{ candEvent = eventRampLeft;  }
	if(torque->type == constraintRampRight)		{ candEvent = eventRampRight; }
	if(torque->type == constraintRoundabout)	{ candEvent = eventRoundabout; }

	/* Wenn ein Event bereits angezeigt wird, greift eine Hysterese f�r die Filterkriterien */
	alreadyDisplayed	= (candEvent == lastEvent) ? true : false;

	/* Neue Events werden nur getriggert, wenn der systemContoller keine Sperre angefordert hat */
	lockAllowed			= (alreadyDisplayed) ? true : !previewLock;

	/* Vorausschau-Events werden nur angezeigt, wenn sie die zul�ssige Beschleunigung signifikant einschr�nken */
	accelerationAllowed	= torque->acceleration < (alreadyDisplayed ? paramSet->displayController.accelerationThreshold.eventHold : paramSet->displayController.accelerationThreshold.eventFire);

	/* Vorausschau-Events werden nur angezeigt, wenn sie die zul�ssige Beschleunigung gg�. der Setzgeschwindigkeit einschr�nken */
	significanceAllowed	= (torque->acceleration - torque->limitAcceleration) < (alreadyDisplayed ? paramSet->displayController.significanceThreshold.eventHold : paramSet->displayController.significanceThreshold.eventFire);

	/* Vorausschau-Events werden nur angezeigt, wenn sich die Vorausschau-Geschwindigkeit signifikant von der Setzgeschwnidigkeit unterscheidet */
	velocityAllowed		= torque->velocity < setTarget - (alreadyDisplayed ? paramSet->displayController.velocityThreshold.eventHold : paramSet->displayController.velocityThreshold.eventFire);

	/* Neue Events werden nur getriggert, wenn sie eine voraussichtliche Mindest-Anzeigedauer erreichen */
	distanceAllowed		= (torqueTTC > paramSet->displayController.ttcThreshold) || alreadyDisplayed;

	/* Auswahl der relevanten Vorausschaugeschwindigkeit */
	relVelocity			= (reachValid) ? mergeVelocity : torque->velocity;

	/* Wenn die Kriterien erf�llt sind, werden die Ausgangsgr��en �berschrieben */
	if(lockAllowed && accelerationAllowed && significanceAllowed && velocityAllowed && distanceAllowed && torque->valid) {
		preview->event	= candEvent;
		preview->target	= relVelocity;
		preview->valid	= true;
	} else {
		preview->event	= eventNone;
		preview->target	= 0.0f;
		preview->valid	= false;
	}

	dclFilterTorqueEvent(torqueChangeTicks,
						 &preview->event,
						 lastEvent,
						 paramSet);
}



static void	   dclFilterTorqueEvent(INOUT		uint32_T			*torqueChangeTicks,
									INOUT		displayEvent_T		*eventTarget,
									IN	const	displayEvent_T		 lastEvent,
									IN	const	parameterSetCtrl_T	*paramSet)
{
	bool_T eventIsTorque;
	bool_T eventWasTorque;
	const displayEvent_T currentEvent = *eventTarget;

	/* Ein direkter Wechsel zwischen zwei torqueEvents ist nur zul�ssig, wenn sich die Anforderung f�r eine Mindestzeit durchg�ngig vom aktuell angezeigten Event unterscheidet. */
	dclIsTorqueEvent( currentEvent, 
					 &eventIsTorque);

	dclIsTorqueEvent( lastEvent, 
					 &eventWasTorque);

	if(eventIsTorque && eventWasTorque) {
		/* Wenn sich das aktuell geforderte Event vom letzten unterscheidet, wird ein Timeout-Z�hler erh�ht. Andernfalls wird er zur�ckgesetzt. */
		if(lastEvent == currentEvent) {
			*torqueChangeTicks = 0;
		}
		else {
			*torqueChangeTicks += 1u;
		}

		*eventTarget = (*torqueChangeTicks < paramSet->displayController.torqueHoldTicks) ? lastEvent : currentEvent;
	}
	else {
		*torqueChangeTicks = 0;
	}
}


static void		   dclIsTorqueEvent(IN	const	displayEvent_T		 displayEvent,
									OUT			bool_T				*eventIsTorque)
{
	*eventIsTorque	=	   (displayEvent == eventCurveLeft)
						|| (displayEvent == eventCurveRight)
						|| (displayEvent == eventBranchLeft)
						|| (displayEvent == eventBranchRight)
						|| (displayEvent == eventRampLeft)
						|| (displayEvent == eventRampRight)
						|| (displayEvent == eventRoundabout);
}


static void	 dclFilterCurveTakeover(INOUT		bool_T				*lastCurveTakeover,
									IN	const	bool_T				 reachValid,
									IN	const	displayConstraint_T	 torqueType,
									IN	const	real32_T			 curveDelta,
									IN	const	parameterSetCtrl_T	*paramSet,
									OUT			bool_T				*takeover)
{
	bool_T takeoverTarget;

	/* Eine Fahrer�bernahmeaufforderung wird ausgel�st, wenn eine deutliche �berschreitung der zul�ssigen Geschwindigkeit aufgrund einer Kurve, Abfahrt
	   oder eines Kreisverkehrs angek�ndigt wird. */
	if(   (reachValid)
	   && (   (torqueType == constraintCurveLeft)
	       || (torqueType == constraintCurveRight)
	       || (torqueType == constraintRampLeft)
	       || (torqueType == constraintRampRight)
	       || (torqueType == constraintRoundabout))) {
		bool_T	setAllowed;
		bool_T	holdAllowed;

		/* Reicht die Geschwindigkeits�berschreitung f�r ein Ausl�sen bzw. Halten einer �bernahmeaufforderung aus? */
		setAllowed	= curveDelta > paramSet->displayController.curveTakeover.thresholdSet;
		holdAllowed	= curveDelta > paramSet->displayController.curveTakeover.thresholdHold;

		if(setAllowed) {
			takeoverTarget	= true;
		}
		else if(holdAllowed) {
			takeoverTarget	= *lastCurveTakeover;
		}
		else {
			takeoverTarget	= false;
		}
	}
	else {
		takeoverTarget	= false;
	}

	*lastCurveTakeover	= takeoverTarget;
	*takeover = takeoverTarget;
}
