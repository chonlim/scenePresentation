#ifndef guard_dclSign_h
#define guard_dclSign_h

#include "control/displayController/dclStep.h"

/**\brief Ermittelt Anzeigesignale zu Verkehrsschildern

Es werden Tempolimits und Stoppstellen angezeigt.
Stoppstellen werden bevorzugt angezeigt.
Die Vorausschaugeschwindigkeit ist nur g�ltig, wenn auch ein Tempolimit existiert.

\spec SW_AS_Innodrive2_57
\spec SW_AS_Innodrive2_43
\spec SW_AS_Innodrive2_71
\spec SW_AS_Innodrive2_72

\ingroup displayController_step
*/
void				dclStepSign(IN	const	uint16_T			 previewLimit,
								IN	const	sysStopType_T		 stopInRange,
								IN	const	bool_T				 nextSetValid,
								IN	const	real32_T			 nextSetVelocity,
								OUT			dclPreview_T		*signPreview
								);

#endif
