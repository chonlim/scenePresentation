#include "control/displayController/displayController.h"
#include "control/displayController/displayController_private.h"
#include "control/displayController/dclStep.h"
#include "control/displayController/dclStepStatic.h"
#include "control/displayController/dclFilter.h"
#include "control/displayController/dclSign.h"
#include "control/displayController/dclTorque.h"

#include "common/systemControllerCommon/sysTools.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"

#include "control/parameterSet/parameterSetCtrl.h"
#include <math.h> /*lint -esym(9045, struct _exception)*/


void				dclStep(MEMORY		displayMemory_T			*displayMemory,
							IN	const	systemControl_T			*systemControl,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	longTorque_T			*longTorque,
							OUT			displayControl_T		*displayControl)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	uint16_T			previewLimit;
	bool_T				previewLock;

	real32_T			nextSetPosition;
	real32_T			nextSetVelocity;
	bool_T				nextSetValid;

	real32_T			currentSetPosition;
	real32_T			currentSetVelocity;

	sysStopType_T		stopInRange;

	real32_T			egoPosition;
	real32_T			egoVelocity;

	dclPreview_T		signPreview;
	dclPreview_T		torquePreview;
	dclPreview_T		preview;

	/* Abfrage von Vorausschau-Limits beim systemController */
	sysGetPreviewLimit(systemControl, &previewLimit, &previewLock);
	sysGetNextSetSpeed(systemControl, &nextSetPosition, &nextSetVelocity, &nextSetValid);
	sysGetCurrentSetSpeed(systemControl, &currentSetPosition, &currentSetVelocity);

	/*  Abfrage der Stoppstellen-Vorausschau vom systemController */
	sysGetStopOutput(systemControl, &stopInRange);

	/* Abfrage der Fahrzeuggeschwindigkeit im vehicleObserver */
	vobsGetVelocity(vehicleState, &egoVelocity);
	vobsGetPosition(vehicleState, &egoPosition);


	dclStepSign( previewLimit,
				 stopInRange,
				 nextSetValid, 
				 nextSetVelocity, 
				&signPreview);


	dclStepTorque(&displayMemory->torqueChangeTicks,
				  &displayMemory->lastCurveTakeover,
				   paramSet,
				   longTorque,
				   displayMemory->lastEvent,
				   previewLock,
				   currentSetVelocity,
				   nextSetVelocity,
				   nextSetValid,
				   egoPosition,
				   egoVelocity,
				  &torquePreview,
				  &displayControl->curveTakeover);

	if(eventNone != signPreview.event) {
		preview = signPreview;
	}
	else {
		preview = torquePreview;
	}
	
	dclGetDisplayNextSetSpeed( currentSetVelocity,
							   nextSetVelocity,
							   nextSetValid,
							  &displayControl->displayNextSetSpeed);

	dclFilterPreview(&displayMemory->lastEvent,
					 &displayMemory->previewFilter,
					 &displayMemory->lastPreviewValid,
					  egoVelocity,
					  displayControl->displayNextSetSpeed,
					 &preview,
					  paramSet,
					 &displayControl->displayEvent,
					 &displayControl->previewValid,
					 &displayControl->previewVelocity);

}

static void			   dclFilterPreview(INOUT		displayEvent_T		*eventFilter,
										INOUT		dclFilter_T			*previewFilter,
										INOUT		bool_T				*previewValidFilter,
										IN	const	real32_T			 egoVelocity,
										IN	const	bool_T				 displayNextSetSpeed,
										IN	const	dclPreview_T		*preview,
										IN	const	parameterSetCtrl_T	*paramSet,
										OUT			displayEvent_T		*targetEvent,
										OUT			bool_T				*targetValid,
										OUT			real32_T			*targetPreview)
{
	/* Wenn im letzten Zeitschritt eine g�ltige Anforderung f�r die Vorausschaugeschwindigkeit vorgelegen hat, ziehen wir sie
	   durch einen Tiefpassfilter, sofern au�erdem folgende Bedingungen erf�llt sind:
	    1) Das Vorausschauicon hat sich nicht ge�ndert 
	    2) Es wird kein vorausliegendes Geschwindigkeitslimit angek�ndigt */
	if(   (*previewValidFilter)
	   && (*eventFilter == preview->event)
	   && (!displayNextSetSpeed)) {
		dclLowPassFilter(previewFilter,
						  controlCYCLETIME,
						  paramSet->displayController.previewCutOff,
						 preview->target,
						 targetPreview);
	}
	else {
		dclFilterSetMemory(previewFilter,
						   preview->target);

		*targetPreview = preview->target;
	}

	/* Die Vorausschau-Geschwindigkeit wird nur angezeigt, wenn sie sich signifikant von der Ego-Geschwindigkeit unterscheidet */
	if(   (egoVelocity <= *targetPreview + paramSet->displayController.previewThreshold)
	   && (egoVelocity >= *targetPreview - paramSet->displayController.previewThreshold)) {
		*targetValid = false;
	}
	else {
		*targetValid = preview->valid;
	}
	*previewValidFilter = *targetValid;


	*targetEvent = preview->event;
	*eventFilter = *targetEvent;
}


static void	  dclGetDisplayNextSetSpeed(IN	const	real32_T			 currentSetVelocity,
										IN	const	real32_T			 nextSetVelocity,
										IN	const	bool_T				 nextSetValid,
										OUT			bool_T				*displayNextSetSpeed)
{
	real32_T			setDifference;

	setDifference		 = nextSetVelocity - currentSetVelocity;
	*displayNextSetSpeed = fabsf(setDifference) > ROUNDING_ERROR ? true : false;
	*displayNextSetSpeed = nextSetValid ? *displayNextSetSpeed : false;
}
