#include "control/displayController/dclSign.h"

void				dclStepSign(IN	const	uint16_T			 previewLimit,
								IN	const	sysStopType_T		 stopInRange,
								IN	const	bool_T				 nextSetValid,
								IN	const	real32_T			 nextSetVelocity,
								OUT			dclPreview_T		*signPreview)
{
	/* Im Zweifel gibt es erstmal kein Event */
	displayEvent_T eventTarget = eventNone;

	/* Wenn vom systemController ein k�nftiges Speed Limit gemeldet wird, wird es priorisiert angezeigt */
	if(previewLimit >   0u && previewLimit <=   5u)	{ eventTarget = eventSpeedLimit_5;   }
	if(previewLimit >   5u && previewLimit <=  10u)	{ eventTarget = eventSpeedLimit_10;  }
	if(previewLimit >  10u && previewLimit <=  15u)	{ eventTarget = eventSpeedLimit_15;  }
	if(previewLimit >  15u && previewLimit <=  20u)	{ eventTarget = eventSpeedLimit_20;  }
	if(previewLimit >  20u && previewLimit <=  25u)	{ eventTarget = eventSpeedLimit_25;  }
	if(previewLimit >  25u && previewLimit <=  30u)	{ eventTarget = eventSpeedLimit_30;  }
	if(previewLimit >  30u && previewLimit <=  35u)	{ eventTarget = eventSpeedLimit_35;  }
	if(previewLimit >  35u && previewLimit <=  40u)	{ eventTarget = eventSpeedLimit_40;  }
	if(previewLimit >  40u && previewLimit <=  45u)	{ eventTarget = eventSpeedLimit_45;  }
	if(previewLimit >  45u && previewLimit <=  50u)	{ eventTarget = eventSpeedLimit_50;  }
	if(previewLimit >  50u && previewLimit <=  55u)	{ eventTarget = eventSpeedLimit_55;  }
	if(previewLimit >  55u && previewLimit <=  60u)	{ eventTarget = eventSpeedLimit_60;  }
	if(previewLimit >  60u && previewLimit <=  65u)	{ eventTarget = eventSpeedLimit_65;  }
	if(previewLimit >  65u && previewLimit <=  70u)	{ eventTarget = eventSpeedLimit_70;  }
	if(previewLimit >  70u && previewLimit <=  75u)	{ eventTarget = eventSpeedLimit_75;  }
	if(previewLimit >  75u && previewLimit <=  80u)	{ eventTarget = eventSpeedLimit_80;  }
	if(previewLimit >  80u && previewLimit <=  90u)	{ eventTarget = eventSpeedLimit_90;  }
	if(previewLimit >  90u && previewLimit <= 100u)	{ eventTarget = eventSpeedLimit_100; }
	if(previewLimit > 100u && previewLimit <= 110u)	{ eventTarget = eventSpeedLimit_110; }
	if(previewLimit > 110u && previewLimit <= 120u)	{ eventTarget = eventSpeedLimit_120; }
	if(previewLimit > 120u && previewLimit <= 130u)	{ eventTarget = eventSpeedLimit_130; }
	if(previewLimit > 130u && previewLimit <= 140u)	{ eventTarget = eventSpeedLimit_140; }
	if(previewLimit > 140u && previewLimit <= 150u)	{ eventTarget = eventSpeedLimit_150; }
	if(previewLimit > 150u && previewLimit <= 160u)	{ eventTarget = eventSpeedLimit_160; }
	if(previewLimit == (uint16_T)rawLimitReleased)	{ eventTarget = eventSpeedLimitReleased; }
	
	/* Die Vorausschaugeschwindigkeit wird nur bei gesetzem Speed Limit-Event auf die Setzgeschwindigkeit gesetzt */
	signPreview->target	= nextSetValid ? nextSetVelocity : 0.0f;
	signPreview->valid	= ((eventTarget != eventNone) && nextSetValid) ? true : false;

	/* Wenn vom systemController eine Stoppstelle gemeldet wird, wird sie h�her priorisiert als Speed Limits */
	if(stopInRange == sysStopStop)					{ eventTarget = eventStop; }
	if(stopInRange == sysStopYield)					{ eventTarget = eventYield; }
	
	signPreview->event = eventTarget;
}
