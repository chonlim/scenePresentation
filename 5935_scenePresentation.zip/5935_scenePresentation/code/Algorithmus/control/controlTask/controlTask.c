#include "control/parameterSet/parameterSetCtrl.h"

#include "control/controlTask/controlTask.h"
#include "control/controlTask/controlTaskStatic.h"
#include "control/controlTask/controlTask_private.h"

#include "control/controlReporter/controlReporter.h"
#include "control/pathRouter/pathRouter.h"
#include "control/vehicleObserver/vehicleObserver.h"
#include "control/systemController/systemController.h"
#include "control/longController/longController.h"
#include "control/longStabTrigger/longStabTrigger.h"
#include "control/outputCodec/outputCodec.h"
#include "control/driverObserver/driverObserver.h"
#include "control/driverPredictor/driverPredictor.h"
#include "control/inputCodec/inputCodec.h"

#include "common/platformInterface/pltfTime.h"

#include <string.h>


ICC_API	void			  iccRunControl(INOUT		pemControlHeap_T		*heap,
										IN	const	vehicleModel_T			*vehicleModel,
										IN	const	pemPlanning_T			*pemPlanning,
										IN	const	flexrayInput_T			*flexrayInput,
										IN	const	emlInput_T				*emlInput,
										IN	const	laneInput_T				*laneInput,
										IN	const	vzeInput_T				*vzeInput,
										IN	const	obfInput_T				*obfInput,
										IN	const	lapInput_T				*lapInput,
										IN	const	codingInput_T			*codingInput,
										IN	const	fodInput_T				*fodInput,
										IN	const	controlRteInfo_T		*controlRteInfo,
										OUT			pemControlStack_T		*stack,
										OUT			pemControl_T			*pemControl,
										OUT			flexrayOutput_T			*flexrayOutput,
										OUT			fodOutput_T				*fodOutput,
										OUT			controlMeasurement_T	*controlMeasurement,
										OUT			checkState_T			*checkState)
{
	uint16_T	controlCode;
	real64_T	startTime;

	heap->valid  = true;
	stack->valid = true;

	controlReporterAttach(&heap->controlReport,
						  &pemPlanning->strategyReport);

	startTime = pltfGetHighPerfTime();
	pemControl->debug.times.start = (real32_T)(pltfGetHighPerfTime() - startTime);

	inputCodec( flexrayInput,
			    emlInput,
			    laneInput,
			    vzeInput,
			    obfInput,
			    lapInput,
			    codingInput,
			    fodInput,
			   &stack->vehicleInput);

	pemControl->debug.times.inputCodec = (real32_T)(pltfGetHighPerfTime() - startTime);

	vehicleObserver(&heap->vobsMemory,
					&stack->vehicleInput,
					 vehicleModel,
					&heap->mapPathInfo,
					&heap->longControlInfo,
					&pemControl->vehicleState,
					 checkState);

	pemControl->debug.times.vehicleObserver = (real32_T)(pltfGetHighPerfTime() - startTime);

	pathRouter(&pemControl->vehicleState,
			   &heap->pathRouterMemory,
			   &heap->mapPathInfo,
			   &pemControl->mapPath);

	pemControl->debug.times.pathRouter = (real32_T)(pltfGetHighPerfTime() - startTime);

	systemController(&stack->vehicleInput,
					 &pemControl->vehicleState,
					 &heap->pathRouterMemory,
					 &pemPlanning->roadModelInfo,
					 &heap->longControlStatus,
					 &heap->sysControlMemory,
					 &pemControl->systemControl,
					  fodOutput);

	pemControl->debug.times.systemController = (real32_T)(pltfGetHighPerfTime() - startTime);

	longController(&heap->longMemory,
				    vehicleModel,
				   &pemControl->vehicleState,
				   &pemControl->systemControl,
				   &pemPlanning->longTorque,
				   &stack->longControl,
				   &heap->longControlInfo,
				   &heap->longControlStatus);

	pemControl->debug.times.longController = (real32_T)(pltfGetHighPerfTime() - startTime);

	longStabTrigger(&heap->triggerMemory,
					&pemControl->vehicleState,
					&pemControl->mapPath,
					&pemControl->systemControl,
					&stack->longControl,
					&pemControl->longTrigger);

	pemControl->debug.times.longStabTrigger = (real32_T)(pltfGetHighPerfTime() - startTime);

	displayController(&heap->displayMemory,
					  &pemControl->systemControl,
					  &pemControl->vehicleState,
					  &pemPlanning->longTorque,
					  &stack->displayControl);

	pemControl->debug.times.displayController = (real32_T)(pltfGetHighPerfTime() - startTime);

	driverObserver( vehicleModel,
				   &pemControl->vehicleState,
				   &heap->pathRouterMemory,
				   &heap->driverState);

	pemControl->debug.times.driverObserver = (real32_T)(pltfGetHighPerfTime() - startTime);

	driverPredictor( vehicleModel,
					&stack->vehicleInput,
					&pemControl->vehicleState,
					&heap->driverState,
					&pemControl->mapPath,
					&heap->pathRouterMemory,
					&heap->driverPredictorMemory,
					&stack->driverPrediction);

	pemControl->debug.times.driverPredictor = (real32_T)(pltfGetHighPerfTime() - startTime);

	controlReporterDetach(&heap->controlReport,
						  &controlCode);

	outputCodec(&pemControl->systemControl,
				&stack->longControl,
				&stack->displayControl,
				&stack->driverPrediction,
				 controlCode,
				&heap->outputControlFilter,
				flexrayOutput);

	pemControl->debug.times.outputCodec = (real32_T)(pltfGetHighPerfTime() - startTime);

	/* Ausgabe von Debug-Daten */
	iccDebugUpdate(pemControl,
				   &heap->debugMemory,
				   &stack->vehicleInput,
				   &stack->displayControl,
				   &stack->longControl,
				   &heap->vobsMemory,
				   &heap->sysControlMemory,
				   &heap->mapPathInfo,
				   &heap->longMemory,
				   &heap->longControlInfo,
				   &heap->longControlStatus,
				   &heap->triggerMemory,
				   &heap->displayMemory,
				   &heap->controlReport,
				    controlRteInfo);

	/* Ausgabe von Messwerten */
	iccGetMeasurement(&pemControl->vehicleState,
					  &pemControl->systemControl,
					   controlCode,
					   controlMeasurement);

	pemControl->debug.times.end = (real32_T)(pltfGetHighPerfTime() - startTime);
}


static void				 iccDebugUpdate(INOUT		pemControl_T			*pemControl,
										INOUT		controlDebugMemory_T	*debugMemory,
										IN	const	vehicleInput_T			*vehicleInput,
										IN	const	displayControl_T		*displayControl,
										IN	const	longControl_T			*longControl,
										IN	const	vobsMemory_T			*vobsMemory,
										IN	const	systemControlMemory_T	*sysControlMemory,
										IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	longMemory_T			*longMemory,
										IN	const	longControlInfo_T		*longControlInfo,
										IN	const	longControlStatus_T		*longControlStatus,
										IN	const	triggerMemory_T			*triggerMemory,
										IN	const	displayMemory_T			*displayMemory,
										IN	const	controlReport_T			*controlReport,
										IN	const	controlRteInfo_T		*controlRteInfo)
{
	uint16_T		 size;
	const uint8_T	*basePtr;

	/* Wenn wir das letzte Datenpaket abgearbeitet haben, laden wir neue Daten */
	if(debugMemory->index >= debugMemory->count) {
		debugMemory->count	= (uint16_T)((((uint16_T)sizeof(debugMemory->data) - 1u) / comCONTROLBUFFERSIZE) + 1u);
		debugMemory->index	= 0u;
		debugMemory->data.vehicleInput			= *vehicleInput;
		debugMemory->data.displayControl		= *displayControl;
		debugMemory->data.longControl			= *longControl;
		debugMemory->data.vobsMemory			= *vobsMemory;
		debugMemory->data.sysControlMemory		= *sysControlMemory;
		debugMemory->data.mapPathInfo			= *mapPathInfo;
		debugMemory->data.longMemory			= *longMemory;
		debugMemory->data.longControlInfo		= *longControlInfo;
		debugMemory->data.longControlStatus		= *longControlStatus;
		debugMemory->data.triggerMemory			= *triggerMemory;
		debugMemory->data.displayMemory			= *displayMemory;
		debugMemory->data.vobsMemory			= *vobsMemory;
		debugMemory->data.controlRteInfo		= *controlRteInfo;
		debugMemory->data.controlReport			= *controlReport;
	}


	/* Aktuelles Datenpaket in die Ausgabestruktur �bertragen und unseren Index aktualisieren */
	size = (uint16_T)((uint16_T)sizeof(debugMemory->data) - (comCONTROLBUFFERSIZE * debugMemory->index));
	basePtr = (uint8_T*)&debugMemory->data;

	size = min(size, comCONTROLBUFFERSIZE);

	pemControl->debug.data.index	= debugMemory->index;
	pemControl->debug.data.count	= debugMemory->count;
	pemControl->debug.data.size	= size;
	memcpy(pemControl->debug.data.buffer, &basePtr[comCONTROLBUFFERSIZE * debugMemory->index], size);

	debugMemory->index++;
}


static void			  iccGetMeasurement(IN	const	vehicleState_T			*vehicleState,
										IN	const	systemControl_T			*systemControl,
										IN	const	uint16_T				 controlCode,
										OUT			controlMeasurement_T	*controlMeasurement)
{
	real32_T adjEngaged;
	real32_T adjDisengaged;

	adjEngaged		= vehicleState->deviation.engaged;
	adjEngaged		= min(adjEngaged,  1000.0f);
	adjEngaged		= max(adjEngaged, -1000.0f);
	adjEngaged		+= 1000.0f;

	adjDisengaged	= vehicleState->deviation.disengaged;
	adjDisengaged	= min(adjDisengaged,  1000.0f);
	adjDisengaged	= max(adjDisengaged, -1000.0f);
	adjDisengaged	+= 1000.0f;

	controlMeasurement->PID_Status_Code_Control					= (uint8_T)(controlCode & 0xFFu);
	controlMeasurement->PID_Reason_For_Degradation				= (uint8_T)(controlCode >> 8u);
	controlMeasurement->PID_Reason_For_Activation_Prohibition	= (uint8_T)systemControl->displayError;
	controlMeasurement->PID_Resistance_Deviation_engaged		= (uint16_T)adjEngaged;
	controlMeasurement->PID_Resistance_Deviation_disengaged		= (uint16_T)adjDisengaged;
}
