#ifndef guard_controlTask_interface_h
#define guard_controlTask_interface_h

#include "base.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "common/longTorquePlannerCommon/longTorquePlanner_private.h"
#include "common/longStabTriggerCommon/longStabTrigger_private.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/controlReporter/controlReporter_private.h"
#include "control/inputCodec/inputCodec_private.h"
#include "control/longController/longController_private.h"
#include "control/displayController/displayController_private.h"
#include "control/outputCodec/outputCodec_private.h"
#include "control/driverObserver/driverObserver_private.h"
#include "control/driverPredictor/driverPredictor_private.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef enum _portState {
	portStateInvalid = 0,
	portStateValid = 1,
	portStateNoUpdate = 2,
	portStateUnknown = 3
} portState_T;

typedef struct _controlDebugData controlDebugData_T;
typedef struct _controlDebugMemory controlDebugMemory_T;
typedef struct _driverPredictorDebugBuffer driverPredictorDebugBuffer_T;
typedef struct _pemControlHeap pemControlHeap_T;
typedef struct _pemControlStack pemControlStack_T;
typedef struct _controlMeasurement controlMeasurement_T;


typedef struct _controlRteInfo {
	struct _controlRteInfo_portStates {
		portState_T pemPlanning;
		portState_T flexrayInput;
		portState_T emlInput;
		portState_T laneInput;
		portState_T vzeInput;
		portState_T lapInput;
		portState_T fodInput;
	} portStates;
} controlRteInfo_T;                      /**< Groesse der Struktur = 28 Bytes */


/*lint -restore */

#endif
