#ifndef guard_iccExports_h
#define guard_iccExports_h

#if !defined(NOEXPORTS) && !defined(INNODRIVE_ZFAS_SWC_BUILD)
#if defined(ICC_EXPORTS)
#define ICC_API		__declspec(dllexport)
#else
#define ICC_API		__declspec(dllimport)
#endif
#else
#define ICC_API
#endif


#endif
