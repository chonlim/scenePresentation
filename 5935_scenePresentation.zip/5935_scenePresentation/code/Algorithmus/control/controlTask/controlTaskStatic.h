#ifndef guard_controlTaskStatic_h
#define guard_controlTaskStatic_h


static void				 iccDebugUpdate(INOUT		pemControl_T			*pemControl,
										INOUT		controlDebugMemory_T	*debugMemory,
										IN	const	vehicleInput_T			*vehicleInput,
										IN	const	displayControl_T		*displayControl,
										IN	const	longControl_T			*longControl,
										IN	const	vobsMemory_T			*vobsMemory,
										IN	const	systemControlMemory_T	*sysControlMemory,
										IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	longMemory_T			*longMemory,
										IN	const	longControlInfo_T		*longControlInfo,
										IN	const	longControlStatus_T		*longControlStatus,
										IN	const	triggerMemory_T			*triggerMemory,
										IN	const	displayMemory_T			*displayMemory,
										IN	const	controlReport_T			*controlReport,
										IN	const	controlRteInfo_T		*controlRteInfo
										);


static void			  iccGetMeasurement(IN	const	vehicleState_T			*vehicleState,
										IN	const	systemControl_T			*systemControl,
										IN	const	uint16_T				 controlCode,
										OUT			controlMeasurement_T	*controlMeasurement
										);


#endif
