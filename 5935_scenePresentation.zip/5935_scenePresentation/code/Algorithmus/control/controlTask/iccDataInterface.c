#include "control/controlTask/iccDataInterface.h"
#include "common/platformInterface/pltfDiag.h"
#include "common/platformInterface/pltfTime.h"

#if !defined INNODRIVE_ZFAS_SWC_BUILD
#include "control/parameterSet/SetTstParameterSetCtrl.h"
#endif

#if !defined INNODRIVE_ZFAS_SWC_BUILD

ICC_API	const parameterSetCtrl_T*	iccGetParameterSet(void)
{
	return prmGetParameterSetCtrl();
}

ICC_API	void					iccApplyParameterSet(IN const	parameterSetCtrl_T	*parameterSet)
{
	prmApplyParameterSetCtrl(parameterSet);
}

ICC_API	void					iccBusInitParameterSet(OUT	 parameterSetCtrl_T	*parameterSet)
{
#if !defined INNODRIVE_ZFAS_SWC_BUILD
	(void)setparameterSetCtrlDefaultData(parameterSet);
#endif
}

ICC_API	void	iccRegisterHighPerfCallback(real64_T	(*adtfGetHighPerfTime)(void))
{
	pltfRegisterGetHighPerfTimeCallback(adtfGetHighPerfTime);
}


ICC_API	void	iccRegisterLogCallbacks(void(*ptrLogInfo)(const char_T *cStr), void(*ptrLogWarning)(const char_T *cStr), void(*ptrLogError)(const char_T *cStr))
{
	diagRegisterLogCallbacks(ptrLogInfo, ptrLogWarning, ptrLogError);
}
#endif
