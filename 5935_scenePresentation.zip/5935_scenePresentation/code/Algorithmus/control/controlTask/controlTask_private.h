#ifndef guard_controlTask_private_h
#define guard_controlTask_private_h

#include "control/controlTask/controlTask_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define dprdTHINNEDTRAJECTORY_COUNT 11u



struct _controlDebugData {
	vehicleInput_T vehicleInput;
	displayControl_T displayControl;
	longControl_T longControl;
	vobsMemory_T vobsMemory;
	systemControlMemory_T sysControlMemory;
	mapPathInfo_T mapPathInfo;
	longMemory_T longMemory;
	longControlInfo_T longControlInfo;
	longControlStatus_T longControlStatus;
	triggerMemory_T triggerMemory;
	displayMemory_T displayMemory;
	controlRteInfo_T controlRteInfo;
	controlReport_T controlReport;
} ;                                      /**< Groesse der Struktur = 1168 Bytes */

struct _controlDebugMemory {
	uint16_T index;                      /**< Index des aktuellen Debug-Datenpakets */
	uint16_T count;                      /**< Anzahl der Pakete im Debug-Datensatz */
	controlDebugData_T data;
} ;                                      /**< Groesse der Struktur = 1172 Bytes */

struct _driverPredictorDebugBuffer {
	real32_T trajectoryVelocityOut[dprdTHINNEDTRAJECTORY_COUNT]; /**< Geschwindigkeitsstrajektorie mit weniger Elementen zur Visualisierung des driverPredictor im Fahrzeug */
	real32_T trajectoryLatAccelOut[dprdTHINNEDTRAJECTORY_COUNT]; /**< Querbeschleunigungstrajektorie mit weniger Elementen zur Visualisierung des driverPredictor im Fahrzeug */
	real32_T trajectoryLonAccelOut[dprdTHINNEDTRAJECTORY_COUNT]; /**< Längsbeschleunigungstrajektorie mit weniger Elementen zur Visualisierung des driverPredictor im Fahrzeug */
	real32_T trajectoryWhlPowerOut[dprdTHINNEDTRAJECTORY_COUNT]; /**< Radleistungstrajektorie mit weniger Elementen zur Visualisierung des driverPredictor im Fahrzeug */
	real32_T trajectoryPositionOut[dprdTHINNEDTRAJECTORY_COUNT]; /**< Positionen für die Trajektorien */
	uint8_T trajectoryMuxId;             /**< MuxID für die Trajektorien */
} ;                                      /**< Groesse der Struktur = 224 Bytes */

struct _pemControlHeap {
	bool_T valid;                        /**< Gültigkeitsflag */
	controlReport_T controlReport;
	vobsMemory_T vobsMemory;
	systemControlMemory_T sysControlMemory;
	mapPathInfo_T mapPathInfo;
	longMemory_T longMemory;
	longControlInfo_T longControlInfo;
	longControlStatus_T longControlStatus;
	triggerMemory_T triggerMemory;
	displayMemory_T displayMemory;
	outputControlFilter_T outputControlFilter;
	pathRouterMemory_T pathRouterMemory;
	driverState_T driverState;
	driverPredictorMemory_T driverPredictorMemory;
	driverPredictorDebugBuffer_T dprdDebugBuffer;
	controlDebugMemory_T debugMemory;
} ;                                      /**< Groesse der Struktur = 8392 Bytes */

struct _pemControlStack {
	bool_T valid;                        /**< Gültigkeitsflag */
	vehicleInput_T vehicleInput;
	longControl_T longControl;
	displayControl_T displayControl;
	driverPrediction_T driverPrediction;
} ;                                      /**< Groesse der Struktur = 452 Bytes */

struct _controlMeasurement {
	uint8_T PID_Status_Code_Control;     /**< InnoDrive: Statuscode Control */
	uint8_T PID_Reason_For_Activation_Prohibition; /**< n/a */
	uint16_T PID_Resistance_Deviation_engaged; /**< Zugkraftfehler (Triebstrang geschlossen) */
	uint16_T PID_Resistance_Deviation_disengaged; /**< Zugkraftfehler (Triebstrang geffnet) */
	uint8_T PID_Reason_For_Degradation;  /**< n/a */
} ;                                      /**< Groesse der Struktur = 8 Bytes */


/*lint -restore */

#endif
