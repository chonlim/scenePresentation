#ifndef guard_idControlContainer_h
#define guard_idControlContainer_h

#include "control/controlTask/iccExports.h"

#include "common/vehicleModel/vehicleModel_interface.h"
#include "common/swcCommunication/swcComm_private.h"

#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "control/outputCodec/outputCodec_interface.h"

#include "control/controlTask/controlTask_interface.h"


/*lint -esym(757,iccRunControl)*/
/** \callgraph 

	\spec SW_FE_Innodrive2_66
	\spec SW_FE_Innodrive2_21
	\spec SW_FE_Innodrive2_23
	\spec SwMS_Innodrive2_Input_399
	\spec SwMS_Innodrive2_Input_400
	\spec SwMS_Innodrive2_Input_398

	\ingroup idControlContainer */
ICC_API	void			  iccRunControl(INOUT		pemControlHeap_T		*heap,
										IN	const	vehicleModel_T			*vehicleModel,
										IN	const	pemPlanning_T			*pemPlanning,
										IN	const	flexrayInput_T			*flexrayInput,
										IN	const	emlInput_T				*emlInput,
										IN	const	laneInput_T				*laneInput,
										IN	const	vzeInput_T				*vzeInput,
										IN	const	obfInput_T				*obfInput,
										IN	const	lapInput_T				*lapInput,
										IN	const	codingInput_T			*codingInput,
										IN	const	fodInput_T				*fodInput,
										IN	const	controlRteInfo_T		*controlRteInfo,
										OUT			pemControlStack_T		*stack,
										OUT			pemControl_T			*pemControl,
										OUT			flexrayOutput_T			*flexrayOutput,
										OUT			fodOutput_T				*fodOutput,
										OUT			controlMeasurement_T	*controlMeasurement,
										OUT			checkState_T			*checkState);


#endif
