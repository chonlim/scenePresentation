#ifndef guard_iccDataInterface_h
#define guard_iccDataInterface_h

#include "control/parameterSet/parameterSetCtrl.h"

#include "control/controlTask/iccExports.h"
#include "control/controlTask/controlTask_interface.h"

/*lint -esym(757,iccGetParameterSet)*/
/** \ingroup iccDataInterface */
ICC_API	const parameterSetCtrl_T*	iccGetParameterSet(void);

/*lint -esym(757,iccApplyParameterSet)*/
/** \ingroup iccDataInterface */
ICC_API	void					iccApplyParameterSet(	IN const	parameterSetCtrl_T	*parameterSet);

/*lint -esym(757,iccBusInitParameterSet)*/
/** \ingroup iccDataInterface */
ICC_API	void					iccBusInitParameterSet(	OUT			parameterSetCtrl_T	*parameterSet);

/*lint -esym(757,iccRegisterHighPerfCallback)*/
/** \ingroup iccDataInterface */
ICC_API	void					iccRegisterHighPerfCallback(real64_T	(*adtfGetHighPerfTime)(void));

/*lint -esym(757,iccRegisterLogCallbacks)*/
/** \ingroup iccDataInterface */
ICC_API	void					iccRegisterLogCallbacks(void(*ptrLogInfo)(const char_T *cStr), void(*ptrLogWarning)(const char_T *cStr), void(*ptrLogError)(const char_T *cStr));

#endif
