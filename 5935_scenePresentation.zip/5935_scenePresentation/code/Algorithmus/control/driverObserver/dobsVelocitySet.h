#ifndef guard_dobsVelocitySet_h
#define guard_dobsVelocitySet_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "control/driverObserver/driverObserver_private.h"




/** \brief Aktualisiert das velocitySet mit den Tempolimits und der Wunschgeschwindigkeit.

Aktualisiert die Tempolimits in \ref dobsBufferSpeedLimits(). 
Wenn die aktuelle Online-Geschwindigkeit deutlich unter dem aktuellen Tempolimit liegt, wird dichter Verkehr erkannt.
Bei einem Tempolimit-Wechsel wird die Wunschgeschwindigkeit initialisiert \ref dobsInitDesiredSpeed().
Aktualisiert die Wunschgeschwindigkeit in \ref dobsUpdateDesiredSpeed().
Bei einem RampUp der Wunschgeschwindigkeit in der Pufferzone vor Tempolimitwechsel wird das n�chste Tempolimit vorgezogen
und die Wunschgeschwindigkeit initialisiert \ref dobsInitDesiredSpeed().

\spec SW_MS_Innodrive2_Forecast_100
\spec SW_MS_Innodrive2_Forecast_101

\ingroup dobsVelocitySet
*/
bool_T		dobsUpdateVelocitySet(		IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	currentValues_T		*currentValues,				/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										INOUT		velocitySet_T		*velocitySet				/**<Umgebungs�bergreifende Wunschgeschwindigekit und Tempolimits*/
										);						


/** \brief Setzt die Wunschgeschwindigkeit auf das aktuelle Tempolimit zuz�glich des gelernten Offsets

Falls das aktuelle Tempolimit "unbeschr�nkt" ist, wird auf die Richtgeschwindigkeit initialisiert.
Zus�tzlich wird die `waitTime`zur�ckgesetzt.

\spec SW_MS_Innodrive2_Forecast_100

\ingroup dobsVelocitySet
*/
void		dobsInitDesiredSpeed(		IN const	speedLimits_T		*speedLimits,				/**<Letztes, aktuelles und n�chstes Tempolimit*/
										IN const	dynamicSet_T		*dynamicSet,				/**<Umgebungsspezifischr Fahrdynamikparametersatz*/
										IN const	maxVelocity_T		*maxVelocity,				/**<Freifahrtgeschwindigkeit*/
										OUT			desiredSpeed_T		*desiredSpeed				/**<Aktuell angenommene Wunschgeschwindigkeit des Fahrers*/
										);


/** \brief W�hlt die L�nge der Pufferzone nach der H�he des Tempolimits aus.

\spec SW_MS_Innodrive2_Forecast_137

\ingroup dobsVelocitySet
*/
real32_T	 dobsGetBufferLength(		IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	prtSpeedLimit_T		*speedLimit					/**<Letztes, aktuelles und n�chstes Tempolimit*/
										);





#endif
