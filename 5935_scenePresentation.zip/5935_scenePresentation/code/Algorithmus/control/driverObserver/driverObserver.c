#include "control/driverObserver/driverObserver.h"
#include "control/driverObserver/driverObserverStatic.h"
#include "control/driverObserver/dobsVelocitySet.h"
#include "control/driverObserver/dobsDynamicSet.h"
#include "control/driverObserver/dobsDataInterface.h"

#include "control/driverObserver/driverObserver_private.h"

#include "control/pathRouter/prtTools.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/vehicleModel/vehicleModel.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_driverObserver)


void	driverObserver(					IN const	vehicleModel_T		*vehicleModel,
										IN const	vehicleState_T		*vehicleState,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										INOUT		driverState_T		*driverState)
{
	if(!driverState->isInitialized)
	{
		/*Initialisierung*/
		/*\spec SW_MS_Innodrive2_Forecast_83*/
		initDriverObserver(driverState);
	}
	else
	{
		/*Durchf�hren eines Rechenschritts und neuinitialisierung sowie Fehlermeldung bei unerwartetem Fehler*/	
		if(!stepDriverObserver(vehicleModel, vehicleState, pathRouterMemory, driverState))
		{
			/*\spec SW_MS_Innodrive2_Forecast_83*/
			initDriverObserver(driverState);
		}
	}

	return;
}


static void	initDriverObserver(			OUT			driverState_T		*driverState)
{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();

	memset(driverState, 0, sizeof(driverState_T));
	driverState->environmentState.dynEventPosition = (real32_T)INVALID_VALUE;
	dobsInitDynamicValues(parameterSet, &driverState->dynamicSetList);
	driverState->maxVelocity.value = parameterSet->driverObserver.maxVelocity.initialValues[driverState->dynamicSetList.country.level];
	driverState->isInitialized = true;
}


static bool_T	stepDriverObserver(		IN const	vehicleModel_T		*vehicleModel,
										IN const	vehicleState_T		*vehicleState,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										INOUT		driverState_T		*driverState)
{
	bool_T				vobsValid;
	currentValues_T		currentValues;
	desiredSpeed_T		initDesiredSpeed;
	dynamicSet_T		*pCurrentDynamicSet = NULL;
	parameterSetCtrl_T	const *parameterSet	= prmGetParameterSetCtrl();

	/*Ohne vehicleState geht nichts.*/
	vobsIsValid(vehicleState, &vobsValid);
	if (!vobsValid) {
		return false;
	}

	/*Aktuelle Werte holen und Tiefpassfiltern*/
	/*\spec SW_MS_Innodrive2_Forecast_87*/
	diagFF(dobsGetBaseValues(vehicleState, pathRouterMemory, driverState->lastValues.executionTime, &currentValues.baseValues));
	dobsFilterCurrentValues(parameterSet, vehicleState, currentValues.baseValues.deltaTime , &driverState->lastValues);
	diagFF(dobsGetCurrentValues(vehicleModel, pathRouterMemory, &driverState->lastValues, &currentValues.baseValues, &currentValues.currentDynamics));
		
	if (!currentValues.baseValues.isMapDataValid)
	{
		/*\spec SW_MS_Innodrive2_Forecast_114 (Der else-Fall wird nicht betreten und die umgebungsabh�ngigen Daten bleiben unver�ndert.)*/
		driverState->environmentState.environment = invalid;
	}
	else
	{
		bool_T valid = true;
		bool_T environmentChanged;

		diagFF(dobsUpdateVelocitySet(parameterSet, pathRouterMemory, &currentValues, &driverState->velocitySet));
	
		/*Umgebung erkennen.*/
		diagFF(dobsSetEnvironment(	parameterSet, 
									vehicleState, 
									pathRouterMemory, 
									&currentValues, 
									&driverState->velocitySet.speedLimits,
									&driverState->environmentState,
									&environmentChanged));
	
		/*Reinitialisierung des Land+Radar-dynamicSetList bei Verlust des Radar-Objekts.*/
		if (driverState->environmentState.radarState.radarObjectLost)
		{
			/*\spec SW_MS_Innodrive2_Forecast_90*/
			dobsInitDynamicValuesRadar(parameterSet, &driverState->dynamicSetList.countryRadar);
			driverState->environmentState.radarState.radarObjectLost = false;
		}
		else
		{
			dynamicSet_T dummySet;
			dobsInitDynamicValuesRadar(parameterSet, &dummySet);
			driverState->environmentState.radarState.radarObjectLost = driverState->environmentState.radarState.radarObjectLost;
		}

		/*Passendes dynamicSet zur Umgebung ausw�hlen.*/
		switch (driverState->environmentState.environment)
		{
			case country:		pCurrentDynamicSet = &driverState->dynamicSetList.country;		break;
			case countryRadar:	pCurrentDynamicSet = &driverState->dynamicSetList.countryRadar; break;
			case city:			pCurrentDynamicSet = &driverState->dynamicSetList.city;			break;
			case invalid:		valid = false;													break;
			default:			diagFUnreachable();
		} /*lint !e9077*/

		diagFF(valid);
			
		/*Wunschgeschwindigkeit mit aktuellem offset initialisieren*/
		dobsInitDesiredSpeed(&driverState->velocitySet.speedLimits, pCurrentDynamicSet, &driverState->maxVelocity, &initDesiredSpeed);
		if (!driverState->velocitySet.desiredSpeed.isInitialized)
		{
			driverState->velocitySet.desiredSpeed = initDesiredSpeed;
		}

		/*Im Stillstand werden die Werte der dynamicSets eingefroren*/
		if(currentValues.currentDynamics.velocity > parameterSet->driverObserver.environment.standStillVelocityTolerance)
		{
			/*Umgebungsspezifisches dynamicSet aktualisieren*/
			dobsUpdateDynamicSet(parameterSet, &currentValues, &driverState->velocitySet, environmentChanged, pCurrentDynamicSet);
		}

		/*Umgebungen mit h�herem Dynamiklevel haben mindestens die Parameterwerte der geringeren Klassen*/
		diagFF(dobsLimitOtherEnvironments(&driverState->environmentState, parameterSet, &driverState->dynamicSetList));

		/*Freifahrtgeschwindigkeit anpassen*/
		diagFF(dobsUpdateMaxVelocity(	parameterSet, 
										&currentValues.baseValues, 
										&driverState->velocitySet, 
										driverState->dynamicSetList.country.level, 
										&driverState->maxVelocity));

		/*Umgebung f�r n�chstes Limit bestimmen*/
		diagFF(dobsSetNextLimitInfo(	parameterSet, 
										pathRouterMemory, 
										&currentValues.baseValues, 
										&driverState->velocitySet.speedLimits, 
										&driverState->environmentState, 
										&driverState->nextLimitInfo));

		diagFF(driverState->dynamicSetList.city.longAcceleration.value >= parameterSet->driverObserver.escalation.longAccelerationLevels[driverState->dynamicSetList.city.longAcceleration.level]);
		diagFF(driverState->dynamicSetList.city.longDeceleration.value >= parameterSet->driverObserver.escalation.longDecelerationLevels[driverState->dynamicSetList.city.longDeceleration.level]);
		diagFF(driverState->dynamicSetList.city.latAcceleration.value >= parameterSet->driverObserver.escalation.latAccelerationLevels[driverState->dynamicSetList.city.latAcceleration.level]);
		diagFF(driverState->dynamicSetList.country.longAcceleration.value >= parameterSet->driverObserver.escalation.longAccelerationLevels[driverState->dynamicSetList.country.longAcceleration.level]);
		diagFF(driverState->dynamicSetList.country.longDeceleration.value >= parameterSet->driverObserver.escalation.longDecelerationLevels[driverState->dynamicSetList.country.longDeceleration.level]);
		diagFF(driverState->dynamicSetList.country.latAcceleration.value >= parameterSet->driverObserver.escalation.latAccelerationLevels[driverState->dynamicSetList.country.latAcceleration.level]);
		diagFF(driverState->dynamicSetList.countryRadar.longAcceleration.value >= parameterSet->driverObserver.escalation.longAccelerationLevels[driverState->dynamicSetList.countryRadar.longAcceleration.level]);
		diagFF(driverState->dynamicSetList.countryRadar.longDeceleration.value >= parameterSet->driverObserver.escalation.longDecelerationLevels[driverState->dynamicSetList.countryRadar.longDeceleration.level]);
		diagFF(driverState->dynamicSetList.countryRadar.latAcceleration.value >= parameterSet->driverObserver.escalation.latAccelerationLevels[driverState->dynamicSetList.countryRadar.latAcceleration.level]);
	}

	return true;
}


static bool_T	dobsGetBaseValues(		IN const	vehicleState_T		*vehicleState,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	real32_T			 lastExecutionTime,
										OUT			baseValues_T		*baseValues)
{
	real32_T time;

	vobsGetTime(vehicleState, &time);
	baseValues->deltaTime = time - lastExecutionTime;

	vobsGetPosition(vehicleState, &baseValues->vehiclePosition);
	baseValues->isMapDataValid = prtIsMemoryValid(pathRouterMemory);

	diagFF(baseValues->deltaTime > ROUNDING_ERROR);

	return true;
}


static void	dobsFilterCurrentValues(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	vehicleState_T		*vehicleState,
										IN const	real32_T			 deltaTime,
										INOUT		filteredValues_T	*filteredValues)
{
	real32_T longAcceleration, latAcceleration, velocity, accelerator, acceleratorNew;

	/*\spec SW_MS_Innodrive2_Forecast_87*/
	vobsGetUnfilteredState(vehicleState, &velocity, NULL, &longAcceleration, &latAcceleration, &accelerator);

	/*Eingangsgr��en tiefpassfiltern*/
	/*\spec SW_MS_Innodrive2_Forecast_87*/
	filteredValues->longAcceleration =	dobsLowPassFilter(	parameterSet->driverObserver.inputFilter.longAccelerationFilterTime,	
															deltaTime, 
															filteredValues->longAcceleration, 
															longAcceleration);
	filteredValues->latAcceleration =	dobsLowPassFilter(	parameterSet->driverObserver.inputFilter.latAccelerationFilterTime,	
															deltaTime, 
															filteredValues->latAcceleration,  
															latAcceleration);
	filteredValues->velocity =			dobsLowPassFilter(	parameterSet->driverObserver.inputFilter.velocityFilterTime,
															deltaTime, 
															filteredValues->velocity, 
															velocity);
	acceleratorNew =					dobsLowPassFilter(	parameterSet->driverObserver.inputFilter.acceleratorFilterTime,
															deltaTime,
															filteredValues->accelerator,
															accelerator);
	filteredValues->acceleratorGradient = (acceleratorNew - filteredValues->accelerator) / deltaTime;
	filteredValues->accelerator	= acceleratorNew;

	filteredValues->executionTime +=	deltaTime;
}


static bool_T	dobsGetCurrentValues(	IN const	vehicleModel_T		*vehicleModel,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	filteredValues_T	*filteredValues,
										IN const	baseValues_T		*baseValues,
										OUT			currentDynamics_T	*currentDynamics)
{
	real32_T curvature, slope;
	
	/*Kr�mmung und Steigung von Karte holen*/
	
	/*Gehe bei zu Kurzen mapPath von gerader, flacher Stra�e aus.*/
	if(prtGetCurvatureAtPosition(pathRouterMemory, baseValues->vehiclePosition, &curvature)){
		curvature = curvature;
	} else {
		curvature = 0.0f;
	}
	if(prtGetSlopeAtPosition(pathRouterMemory, baseValues->vehiclePosition, &slope)){
		slope = slope;
	} else {
		slope = 0.0f;
	}

	diagFF(vmdlGetWheelPower(	 vehicleModel,
								 fastfabsf(filteredValues->velocity),
								 filteredValues->longAcceleration,
								 fastfabsf(curvature),
								 slope,
								 0.0f,
								&currentDynamics->wheelPower));

	/*Richtungen der Gr��en ber�cksichtigen*/
	/*\spec SW_MS_Innodrive2_Forecast_108*/
	currentDynamics->longAcceleration	 = max(0.0f,  filteredValues->longAcceleration);
	/*\spec SW_MS_Innodrive2_Forecast_110*/
	currentDynamics->longDeceleration	 = max(-filteredValues->longAcceleration, 0.0f);
	/*\spec SW_MS_Innodrive2_Forecast_111*/
	currentDynamics->latAcceleration	 = fastfabsf( filteredValues->latAcceleration);
	currentDynamics->velocity			 = max(0.0f,  filteredValues->velocity);
	currentDynamics->wheelPower			 = max(0.0f,  currentDynamics->wheelPower);
	currentDynamics->acceleratorGradient = filteredValues->acceleratorGradient;

	return true;
}


static void		dobsUpdateRadarState(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	vehicleState_T		*vehicleState,
										IN const	currentValues_T		*currentValues,
										INOUT		dobsRadarState_T	*radarState)
{
	real32_T		projectedTimeGap, relativeVelocity, trafficDistance, trafficVelocity, trafficPosition;
	bool_T			newFollowingRadar, trafficPresent;
	const struct _parameterSetCtrl_driverObserver_environment *parameters = &parameterSet->driverObserver.environment;
	
	/*AccSensor liefert absolute trafficVelocity. Relativgeschwindigkeit ist negativ beim Auffahren auf das Vorderfahrzeug.*/
	/*\spec SW_MS_Innodrive2_Forecast_85*/
	/*\spec SW_MS_Innodrive2_Forecast_89*/
	vobsGetTrafficTarget(vehicleState, &trafficPresent, &trafficPosition, &trafficVelocity, NULL);
	relativeVelocity = trafficVelocity - currentValues->currentDynamics.velocity;
	trafficDistance = trafficPosition - currentValues->baseValues.vehiclePosition;
	projectedTimeGap = trafficDistance + relativeVelocity * parameters->radarPropagationTime;
	projectedTimeGap /= currentValues->currentDynamics.velocity;
	
	
	if (currentValues->currentDynamics.velocity == 0.0f) {
		/*Zustand Radarfolgefahrt beibehalten*/
		newFollowingRadar = radarState->followingRadar;
	} 
	else if (radarState->followingRadar)
	{
		/*Pr�fe Austauchen aus dem Sicherheitsabstand*/
		if ((projectedTimeGap > parameters->radarTimeGapOut  &&  relativeVelocity > parameters->radarRelativeVelocityOut)
			|| !trafficPresent)
		{
			/*Zustand Radarfolgefahrt wird verlassen*/
			/*\spec SW_MS_Innodrive2_Forecast_89*/
			newFollowingRadar = false;
		}
		else
		{
			/*Zustand Radarfolgefahrt wird beibehalten*/
			newFollowingRadar = true;
		}
	}
	else
	{
		/*Pr�fe Eintauchen in den Sicherheitsabstand*/
		if ((projectedTimeGap < parameters->radarTimeGapIn  &&  relativeVelocity < parameters->radarRelativeVelocityIn)
			&& trafficPresent)
		{
			/*\spec SW_MS_Innodrive2_Forecast_85*/
			/*Zustand Radarfolgefahrt wird neu angenommen*/
			newFollowingRadar = true;
		}
		else
		{
			newFollowingRadar = false;
		}
	}

	/*Entprellung. Ein ge�ndertes newFollowingRadar geht erst nach radarDebounceTime in den radarState*/
	if (newFollowingRadar && !radarState->followingRadar ||
		!newFollowingRadar && radarState->followingRadar)
	{
		if(radarState->waitTime < parameters->radarDebounceTime)
		{
			/*Entprellzeit abwarten*/
			radarState->followingRadar = radarState->followingRadar;
			radarState->radarObjectLost = false;
			radarState->waitTime += currentValues->baseValues.deltaTime;
		}
		else
		{
			/*Nach Entprellzeit Radarzustand �ndern.*/
			radarState->followingRadar = newFollowingRadar;
			radarState->radarObjectLost = !newFollowingRadar; /*newFollowingRadar hat sich auf "false" ge�ndert*/
			radarState->waitTime = 0.0f;
		}
	}
	else
	{
		/*radarState.followingRadar bleibt wie es ist*/
		radarState->followingRadar = radarState->followingRadar;
		radarState->radarObjectLost = false;
		radarState->waitTime = 0.0f;
	}
}


static bool_T	dobsUpdateDynamicEvent(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	currentValues_T		*currentValues,
										INOUT		real32_T			*dynEventPosition)
{
	real32_T currentDynEventPosition;
	real32_T debounceLengthAfterDynEvent = parameterSet->driverObserver.environment.highwayDebounceDynEventAfter;
	real32_T debounceLengthBeforeDynEvent = parameterSet->driverObserver.environment.highwayDebounceDynEventBefore;

	/*\spec SW_MS_Innodrive2_Forecast_91*/
	diagFF(prtGetNextDynamicEvent(pathRouterMemory, currentValues->baseValues.vehiclePosition - debounceLengthAfterDynEvent, &currentDynEventPosition));

	if (currentValues->baseValues.vehiclePosition + debounceLengthBeforeDynEvent >= currentDynEventPosition)
	{
		*dynEventPosition = currentDynEventPosition;
	}
	else if(	currentValues->baseValues.vehiclePosition - debounceLengthAfterDynEvent <= *dynEventPosition
			&&	currentValues->baseValues.vehiclePosition >= *dynEventPosition)
	{
		*dynEventPosition = *dynEventPosition;
	}
	else
	{
		/*\spec SW_MS_Innodrive2_Forecast_91*/
		*dynEventPosition = INVALID_VALUE;
	}

	return true;
}


static bool_T		dobsSetEnvironment(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	vehicleState_T		*vehicleState,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	currentValues_T		*currentValues,
										IN const	speedLimits_T		*speedLimits,
										INOUT		environmentState_T	*environmentState,
										OUT			bool_T				*environmentChanged)
{
	bool_T isBuiltUp;
	const dobsEnvironment_T oldEnvironment = environmentState->environment;
	
	prtSpeedLimit_T currentLimit;
	currentLimit.limit = speedLimits->currentLimit.limit;
	currentLimit.position = currentValues->baseValues.vehiclePosition;
	
	diagFF(currentValues->baseValues.isMapDataValid);

	/*Wenn die Karte "isBuiltUp" meldet UND das aktuelle Tempolimit <= 60 km/h ist, ist die Umgebung Innerorts.*/
	diagFF(prtIsLimitInBuiltUpArea(parameterSet, pathRouterMemory, &currentLimit, &isBuiltUp));

	/*Auf einer Autobahnauffahrt wird die Umgebung Land ohne Radar erzwungen.*/
	diagFF(dobsUpdateDynamicEvent(parameterSet, pathRouterMemory, currentValues, &environmentState->dynEventPosition));

	/*Erkenne Radar-Folgefahrt*/
	dobsUpdateRadarState(parameterSet, vehicleState, currentValues, &environmentState->radarState);
	
	/*Lege die Umgebung fest*/
	if (environmentState->dynEventPosition != INVALID_VALUE)
	{
		environmentState->radarState.followingRadar = false;
	}

	if (isBuiltUp)
	{
		/*\spec SW_MS_Innodrive2_Forecast_96*/
		environmentState->environment = city;
	} 
	else if (environmentState->radarState.followingRadar)
	{
		/*\spec SW_MS_Innodrive2_Forecast_96*/
		environmentState->environment = countryRadar;
	} 
	else
	{
		/*\spec SW_MS_Innodrive2_Forecast_96*/
		environmentState->environment = country;
	}

	*environmentChanged = (oldEnvironment != environmentState->environment) ? true : false;

	return true;
}


static bool_T	dobsSetNextLimitInfo(	IN const	parameterSetCtrl_T		*parameterSet,
										IN const	pathRouterMemory_T		*pathRouterMemory,
										IN const	baseValues_T			*baseValues,
										IN const	speedLimits_T			*speedLimits,
										IN const	environmentState_T		*environmentState,
										OUT			dobsNextLimitInfo_T		*nextLimitInfo)
{
	bool_T valid, isBuiltUp;
	real32_T debounceLengthAfterDynEvent = parameterSet->driverObserver.environment.highwayDebounceDynEventAfter;
	real32_T debounceLengthBeforeDynEvent = parameterSet->driverObserver.environment.highwayDebounceDynEventBefore;
	real32_T previewHorizon = parameterSet->driverObserver.desiredSpeed.maxDistanceNextLimit;
	real32_T relPosDynEvent;

	/*Wenn die Karte "isBuiltUp" meldet ODER das n�chste Tempolimit <= 60 km/h ist, ist die Umgebung Innerorts.*/
	valid = prtIsLimitInBuiltUpArea(parameterSet, pathRouterMemory, &speedLimits->nextLimit, &isBuiltUp);

	if (	baseValues->vehiclePosition <= speedLimits->nextLimit.position
		&&	baseValues->vehiclePosition + previewHorizon > speedLimits->nextLimit.position)
	{
		diagFF(valid);
		nextLimitInfo->limit	= speedLimits->nextLimit.limit;
		nextLimitInfo->position = speedLimits->nextLimit.position;
	} else {
		nextLimitInfo->limit	= INVALID_VALUE;
		nextLimitInfo->position = INVALID_VALUE;
	}

	/*Auf einer Autobahnauffahrt wird die Umgebung Land ohne Radar erzwungen.*/
	relPosDynEvent = environmentState->dynEventPosition - speedLimits->nextLimit.position;	
	relPosDynEvent = environmentState->dynEventPosition == INVALID_VALUE ? INVALID_VALUE : relPosDynEvent;
	relPosDynEvent = speedLimits->nextLimit.position  == 0.0f ? INVALID_VALUE : relPosDynEvent;

	/*Lege die Umgebung fest*/
	if (isBuiltUp)
	{
		nextLimitInfo->environment = city;
	} 
	else if (	-debounceLengthAfterDynEvent <= relPosDynEvent
			&&	debounceLengthBeforeDynEvent >= relPosDynEvent)
	{
		nextLimitInfo->environment = country;
	}
	else if (environmentState->radarState.followingRadar)
	{
		nextLimitInfo->environment = countryRadar;
	} 
	else if (nextLimitInfo->limit != INVALID_VALUE)
	{
		nextLimitInfo->environment = country;
	}
	else
	{
		nextLimitInfo->environment = invalid;
	}

	return true;
}



static bool_T	dobsLimitOtherEnvironments(		IN const	environmentState_T	*environment,
												IN const	parameterSetCtrl_T	*parameterSet,
												INOUT		dynamicSetList_T	*dynamicSetList)
{
	/*Die Reihenfolge Stadt <= Land+Radar <= Land+Ego muss eingehalten werden.*/
	switch (environment->environment)
	{
	case city:
		dobsSetMinimalValues(&dynamicSetList->city, parameterSet, &dynamicSetList->country);
		break;
	case countryRadar:
		dobsSetMinimalValues(&dynamicSetList->countryRadar, parameterSet, &dynamicSetList->country);
		dobsSetMaximalValues(&dynamicSetList->countryRadar, parameterSet, &dynamicSetList->city);
		break;
	case country:
		dobsSetMaximalValues(&dynamicSetList->country, parameterSet, &dynamicSetList->city);
		dobsSetMaximalValues(&dynamicSetList->country, parameterSet, &dynamicSetList->countryRadar);
		break;
	case invalid:
		/*Tue nichts*/
		break;
	default:
		diagFUnreachable();
	} /*lint !e9077*/

	/*Nur bei Radarverkehr wirkt sich die Stadt-Umgebung auf Land+Radar aus*/
	if (environment->radarState.followingRadar)
	{
		dobsSetMinimalValues(&dynamicSetList->city, parameterSet, &dynamicSetList->countryRadar);
	} else {
		dobsSetMinimalValues(&dynamicSetList->city, parameterSet, &dynamicSetList->country);
	}

	/*Die Timer der inaktiven Umgebungen werden genullt.*/
	if		(environment->environment != city) 
	{
		dynamicSetList->city.timer = 0.0f; 
	}
	if (environment->environment != countryRadar) 
	{ 
		dynamicSetList->countryRadar.timer = 0.0f; 
	}
	if (environment->environment != country) 
	{ 
		dynamicSetList->country.timer = 0.0f; 
	}
	
	return true;
}
