#ifndef guard_dobsDynamicSet_h
#define guard_dobsDynamicSet_h

#include "control/control.h"
#include "control/driverObserver/driverObserver_private.h"
#include "control/parameterSet/parameterSetCtrl.h"



/** \brief Initialisiert die dynamicValues auf Umgebungsabh�ngige Werte

\spec SW_MS_Innodrive2_Forecast_113

\ingroup dobsDynamicSet
*/
void	 dobsInitDynamicValues(			IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										OUT			dynamicSetList_T	*dynamicSetList			/**<Fahrdynamikparameters�tze f�r drei Umgebungen*/
										);

/** \brief Initialisiert die dynamicValues auf Umgebungsabh�ngige Werte

\ingroup dobsDynamicSet
*/
void	 dobsInitDynamicValuesRadar(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										OUT			dynamicSet_T		*countryRadarSet		/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
										);


/** \brief Aktualisiert die Beschleunigungspegel und Geschwindigkeiten im dynamicSet

Vermaxt die Beschleunigungen aus `currentValues` mit den gespeicherten Beschleunigungspegeln im `dynamicSet`.
Die Wunschgeschwindigkeit wird in \ref dobsUpdateDesiredSpeed() aktualisiert.
Die Freifahrtgeschwindigkeit wird in \ref dobsUpdateDesiredSpeed() aktualisiert.
In den Funktionen \ref dobsRampUpAccelerations() \ref dobsCheckDeescalation() werden die Stufen der Fahrdynamikparameter f�r die aktuelle Umgebung angepasst.
Die Radleistung soll nur die Stufengrenzwerte annehmen und wird daher hier nicht aktualisiert.

\spec SW_MS_Innodrive2_Forecast_81
\spec SW_MS_Innodrive2_Forecast_136
\spec SW_MS_Innodrive2_Forecast_138
\spec SW_MS_Innodrive2_Forecast_139

\ingroup dobsDynamicSet
*/
void		dobsUpdateDynamicSet(		IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	currentValues_T		*currentValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	velocitySet_T		*velocitySet,			/**<Umgebungs�bergreifende Wunschgeschwindigekit und Tempolimits*/
										IN const	bool_T				 environmentChanged,	/**<Die Umgebung hat sich in diesem Rechentakt ge�ndert.*/
										INOUT		dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
										);


/** \brief Stellt einen Tiefpassfilter erster Ordnung dar.

\spec SW_MS_Innodrive2_Forecast_87

\ingroup dobsDynamicSet
*/
real32_T	dobsLowPassFilter(			IN const	real32_T			timeConstant,			/**<Characteristische Zeitkonstante des Tiefpassfilters*/
										IN const	real32_T			deltaTime,				/**<Zeitinkrement*/
										IN const	real32_T			lastValue,				/**<Wert zu Beginn des Zeitinkrements*/
										IN const	real32_T			currentValue			/**<Aktueller Wert, d3er gefiltert wird*/
										);


/** \brief Aktualisiert die Freifahrtgeschwindigkeit auf unbeschr�nkten Strecken.

Eine kleinere Freifahrtgeschwindigkeit wird direkt Wunschgeschwindigkeit �bernommen.
Eine kleinere Freifahrtgeschwindigkeit wird nur auf unbeschr�nkten Strecken Tiefpassgefiltert
aus der Wunschgeschwindigkeit gelernt.
Sobald die Freifahrtgeschwindigkeit hier einmal gelernt wurde, darf sie nicht mehr mit Initialwerten
�berschrieben werden.

\spec SW_MS_Innodrive2_Forecast_104
\spec SW_MS_Innodrive2_Forecast_102
\spec SW_MS_Innodrive2_Forecast_103

\ingroup dobsDynamicSet
*/
bool_T		dobsUpdateMaxVelocity(		IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	baseValues_T		*baseValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	velocitySet_T		*velocitySet,			/**<Umgebungs�bergreifende Wunschgeschwindigekit und Tempolimits*/
										IN const	uint8_T				 initLevel,				/**<Level, auf die die Unbeobachtete Maximalgeschwindigkeit initialisiert wird.*/
										INOUT		maxVelocity_T		*maxVelocity			/**<Freifahrtgeschwindigkeit auf unbegrenzter Autobahn*/
										);


/** \brief Setze alle Values und Levels im higherSet auf mindestens die entsprechenden Werte im referenceSet
\ingroup dobsDynamicSet
*/
void		dobsSetMinimalValues(		IN const	dynamicSet_T		*referenceSet,			/**<Fahrdynamikparametersatz*/
										IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										INOUT		dynamicSet_T		*higherSet				/**<fahrdynamikparametersatz, der angepasst wird*/
										);


/** \brief Setze alle Values und Levels im lowerSet auf h�chstens die entsprechenden Werte im referenceSet
\spec SW_MS_Innodrive2_Forecast_141
\ingroup dobsDynamicSet
*/
void		dobsSetMaximalValues(		IN const	dynamicSet_T		*referenceSet,			/**<Fahrdynamikparametersatz*/
										IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										INOUT		dynamicSet_T		*lowerSet				/**<fahrdynamikparametersatz, der angepasst wird*/
										);






#endif
