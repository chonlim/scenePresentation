#ifndef guard_driverObserver_interface_h
#define guard_driverObserver_interface_h

#include "base.h"
#include "common/pathRouterCommon/pathRouter_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef enum _dobsEnvironment {
	country = 0,
	countryRadar = 1,
	city = 2,
	invalid = 3
} dobsEnvironment_T;

typedef struct _baseValues baseValues_T;
typedef struct _currentDynamics currentDynamics_T;
typedef struct _currentValues currentValues_T;
typedef struct _maxVelocity maxVelocity_T;
typedef struct _desiredSpeed desiredSpeed_T;
typedef struct _speedLimits speedLimits_T;
typedef struct _dobsRadarState dobsRadarState_T;
typedef struct _filteredValues filteredValues_T;
typedef struct _environmentState environmentState_T;
typedef struct _dynamicSetList dynamicSetList_T;
typedef struct _driverState driverState_T;


typedef struct _dynamicValue {
	real32_T value;
	uint8_T level;
} dynamicValue_T;                        /**< Groesse der Struktur = 8 Bytes */

typedef struct _dynamicSet {
	dynamicValue_T longAcceleration;
	dynamicValue_T longDeceleration;
	dynamicValue_T latAcceleration;
	dynamicValue_T offsetVelocity;
	real32_T wheelPower;
	real32_T maxJerk;
	real32_T minJerk;
	uint8_T level;
	real32_T timer;
	bool_T isQuenched;                   /**< Alle Beschleunigungswerte liegen auf iheren Stufengrenzwerten. */
} dynamicSet_T;                          /**< Groesse der Struktur = 56 Bytes */

typedef struct _dobsNextLimitInfo {
	real32_T limit;
	real32_T position;
	dobsEnvironment_T environment;
} dobsNextLimitInfo_T;                   /**< Groesse der Struktur = 12 Bytes */


/*lint -restore */

#endif
