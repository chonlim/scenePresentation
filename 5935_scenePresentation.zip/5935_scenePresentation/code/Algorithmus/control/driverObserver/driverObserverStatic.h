#ifndef guard_driverObserverStatic_h
#define guard_driverObserverStatic_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"

#include "control/driverObserver/driverObserver_interface.h"
#include "common/vehicleModel/vehicleModel.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"


/** 
\brief Gibt die tiefpassgefilterten aktuellen Daten vom vehicleObserver in der Struktur filteredValues aus.

Die L�ngsbeschleunigung ist die longAcceleration vom espSensor.
Die Querbeschleunigung ist die latAcceleration vom espSensor.
Die Geschwindigkeit ist die vehicleState->unfilteredState.velocity.
Die executionTime bestimmt sich aus der vobsBaseState.Time.

Es wird die Ausf�hrungszeit und nicht die Zyklenzahl gespeichert, um dem systematischen Fehler vorzubeugen,
der entsteht, wenn man tickCount (1) * controlCycleTime (0.02) rechnet, da 0.02 als Flie�kommazahl nicht exakt dargestellt
wird und daher immer ein zu kleiner Wert berechnet wird.

\spec SW_MS_Innodrive2_Forecast_87

\ingroup driverObserver_step
*/
static void	dobsFilterCurrentValues(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	vehicleState_T		*vehicleState,			/**<Fahrzeugzustand aus dem Modul vehicleObserver*/
										IN const	real32_T			 deltaTime,				/**<Zeitinkrement*/
										INOUT		filteredValues_T	*filteredValues			/**<Tiefpassgefilterte Daten*/
										);


/** \brief Bereitet die tiefpassgefilterten Rohdaten f�r diesen Rechentakt auf.

Die L�ngsbeschleunigung ist die tiefpassgefilterte longAcceleration, falls sie positiv ist
Die L�ngsverz�gerung ist der Betrag der tiefpassgefilterte longAcceleration, falls sie negativ ist.
Die Querbeschleunigung ist der Betrag der tiefpassgefilterten latAcceleration.
Die Geschwindigkeit ist die vehicleState->unfilteredState.velocity. Es wird nur die positive Flanke betrachtet.

Zeitinkrement und Fahrzeugposition werden aus dem vobsBaseState berechnet.

Die Radleistung wird aus Geschwindigkeit, Beschleunigung, Kurvenkr�mmung und Steigung berechnet.
Sie ist nur g�ltig, wenn die Kartendaten g�ltig sind: `currentValues.isMapDataValid`.
Es wird nur die positive Flanke betrachtet.

\spec SW_MS_Innodrive2_Forecast_108
\spec SW_MS_Innodrive2_Forecast_110
\spec SW_MS_Innodrive2_Forecast_111

\ingroup driverObserver_step
*/
static bool_T	dobsGetCurrentValues(	IN const	vehicleModel_T		*vehicleModel,			/**<Fahrzeugmodell*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	filteredValues_T	*filteredValues,		/**<Tiefpassgefilterte Daten*/
										IN const	baseValues_T		*baseValues,			/**<Position, Zeitinkrement, Kartenstatus*/
										OUT			currentDynamics_T	*currentDynamics		/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										);


/** \brief Stellt die Reihenfolge der Fahrdynamikparameter der Umgebungen City <= Land+Radar <= Land sicher.

Das Eingabeargument environment zeigt an, welches dynamicSet sich in diesem Rechenschritt ge�ndert hat.

Bei einer �nderung von "country" wird "city" nach oben begrenzt.
Bei einer �nderung von "countryRadar" wird "country nach unten begrenzt.
Bei einer �nderung von "city" wird "country" nach unten begrenzt.
Falls bei "city" Radarfolgefahrt erkannt wird, wird auch "countryRadar" nach unten begrenzt.

Die Timer der inaktiven Umgebungen werden genullt.

\spec SW_MS_Innodrive2_Forecast_140

\ingroup driverObserver_step
*/
static bool_T	dobsLimitOtherEnvironments(	IN const	environmentState_T	*environment,			/**<Umgebung (Land/Land+Radar/Stadt) und Zustandspeicher*/
											IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
											INOUT		dynamicSetList_T	*dynamicSetList			/**<Struktur mit einem dynamicSet pro Umgebung*/
											);


/** \brief Bestimmt aus Kartendaten und Acc-Sensorinformationen die aktuelle Umgebung (Land/Land+Radar/Stadt)

\spec SW_MS_Innodrive2_Forecast_76
\spec SW_MS_Innodrive2_Forecast_96

\ingroup driverObserver_step
*/
static bool_T	dobsSetEnvironment(		IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	vehicleState_T		*vehicleState,			/**<Fahrzeugzustand aus dem Moduls vehicleObserver*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	currentValues_T		*currentValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	speedLimits_T		*speedLimits,			/**<Letztes, aktuelles und n�chstes Tempolimit*/
										INOUT		environmentState_T	*environmentState,		/**<Umgebung (Land/Land+Radar/Stadt) und Zustandspeicher*/
										OUT			bool_T				*environmentChanged		/**<Die Umgebung ist eine andere als im vorherigen Takt*/
										);

/** \brief Ermittelt die am n�chsten Tempolimit g�ltige Umgebung (Land/Land+Radar/Stadt)
\ingroup driverObserver_step
*/
static bool_T	dobsSetNextLimitInfo(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	baseValues_T		*baseValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	speedLimits_T		*speedLimits,			/**<Letztes, aktuelles und n�chstes Tempolimit*/
										IN const	environmentState_T	*environmentState,		/**<Umgebung (Land/Land+Radar/Stadt) und Zustandspeicher*/
										OUT			dobsNextLimitInfo_T	*nextLimitInfo			/**<N�chstes Tempolimit, seine Position und dort g�ltige Umgebung*/
										);


/** \brief Zeigt die Position einer aktuellen Autobahnauffahrt an.

Autobahnauffahrten sind aktuell, wenn sie in einem parametrierbaren Bereich vor bzw. hinter der Egoposition liegen.
Falls keine aktuelle Autobahnauffahrt gefunden wird, ist der R�ckgabewert `rampUpPosition == INVALID_VALUE`.

\spec SW_MS_Innodrive2_Forecast_91

\ingroup driverObserver_step
*/
static bool_T	dobsUpdateDynamicEvent(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	currentValues_T		*currentValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										INOUT		real32_T			*dynEventPosition		/**<Position des n�chsten dynamischen Ergeinisses*/
										);


/** \brief Wechselt zwischen den Zust�nden Keine-Folgefahrt / Radar-Folgefahrt / Radar-Objekt-Verloren mit einer Hysterese.

\spec SW_MS_Innodrive2_Forecast_77
\spec SW_MS_Innodrive2_Forecast_85
\spec SW_MS_Innodrive2_Forecast_89

\ingroup driverObserver_step
*/
static void	dobsUpdateRadarState(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
									IN const	vehicleState_T		*vehicleState,			/**<Fahrzeugzustand aus dem Moduls vehicleObserver*/
									IN const	currentValues_T		*currentValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
									INOUT		dobsRadarState_T	*radarState				/**<Radar-Folgefahrt Ja/Nein/Objekt verloren*/
									);


/** \brief Initialisierung des `driverState`

\spec SW_MS_Innodrive2_Forecast_83
\spec SW_MS_Innodrive2_Forecast_102

\ingroup driverObserver_step
*/
static void	initDriverObserver(	OUT			driverState_T		*driverState			/**<Private Struktu des driverObserver*/
								);

/** \brief Speichert Fahrzeugposition und Zeitinkrement vom vehicleState und Status des mapPath in `baseValues`

\spec SW_MS_Innodrive2_Forecast_87

\ingroup dirverObserver_step
*/
static bool_T	dobsGetBaseValues(	IN const	vehicleState_T		*vehicleState,			/**<Fahrzeugzustand aus dem Modul vehicleObserver*/
									IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
									IN const	real32_T			 lastExecutionTime,		/**<Zeitpunkt der letzten Ausf�hrung des driverObserver*/
									OUT			baseValues_T		*baseValues				/**<Position, Zeitinkrement, Kartenstatus*/
									);


/**\brief Die Funktion `stepDriverObserver()` aktualisiert die beobachtete Sportlichkeit des Fahrers und gibt sie im `driverState` aus.

In der Funktion \ref dobsGetCurrentValues() werden die aktuellen Daten vom vehicleObserver eingelesen.
Falls das Fehrzeug in \ref dobsSetEnvironment() eine g�ltige Umgebung erkennt,
werden die Aktualisierungsfunktionen \ref dobsUpdateVelocitySet() und \ref dobsUpdateDynamicSet() nacheinander ausgef�hrt.
Anschlie�end wird die Reihenfolge der Fahrdynamikparameter der Umgebungen City <= Land+Radar <= Land sichergestellt (\ref dobsLimitOtherEnvironments())

Falls das Fahrzeug steht doer keine Kartendaten zur Verf�gung stehen, werden die gelernten Werte eingefroren.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers.

\spec SW_MS_Innodrive2_Forecast_60
\spec SW_MS_Innodrive2_Forecast_90

\ingroup driverObserver_step
*/
static bool_T	stepDriverObserver(		IN const	vehicleModel_T		*vehicleModel,			/**<Fahrzeugmodell*/
										IN const	vehicleState_T		*vehicleState,			/**<Fahrzeugzustand aus dem Modul vehicleObserver*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										INOUT		driverState_T		*driverState			/**<Private Struktur des driverObserver*/
										);
#endif
