#ifndef guard_dobsDynamicSetStatic_h
#define guard_dobsDynamicSetStatic_h

#include "control/control.h"
#include "control/driverObserver/driverObserver_private.h"
#include "control/parameterSet/parameterSetCtrl.h"


/** \brief Entscheidet, ob das Lernen von `offsetelocity` und `maxVelocity` aktiv ist.

Das Lernen ist INAKTIV, wenn dichter Verkehr erkannt ist (vgl. \ref dobsUpdateVelocitySet())
oder wenn das Fahrzeug sich in einer der Pufferzonen vor bzw. nach einem Tempolimitwechsel befindet.

\ingroup dobsDynamicSet
*/
static bool_T	isOffsetUpdateActive(		IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
											IN const	baseValues_T		*baseValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
											IN const	speedLimits_T		*speedLimits			/**<Letztes, aktuelles und n�chstes Tempolimit*/
											);

/** \brief Gibt das Level zur�ck, in dem der �bergebene Wert liegt.

Das Array `levelBorders` enth�lt die Unteren Levelgrenzen.
Die Ausgabevariable `currentLevel` wird auf das h�chste Level gesetzt, f�r das gilt: levelBorders[currentLevel] <= value.
\ingroup dobsDynamicSet
*/
static void	getCurrentLevel(	IN const	real32_T			 value,
								IN const	uint8_T				 levelCount,
								IN const	real32_T			*levelBorders,
								OUT			uint8_T				*currentLevel
								);


/** \brief Setzt die Pegelwerte im `dynamicSet` herab, wenn w�hrend der Deeskalationszeit der maximalen Stufe kein Wert seine aktuelle Stufe erreicht hat.

Der Timer des dynamicSets wird zur�ckgesetzt, wenn einer der currentValues gr��er/gleich seinem aktuellen Stufengrenzwert ist.
Falls der Timer des dynamicSets g��er ist als die Stufenabh�ngige Deeskalationszeit, werden die Pegelwerte wie folgt erniedrigt:
(Ein eskalierter Pegelwert ist ein Pegelwert mit zugeh�rigem Level >= 1)
 -	Falls mindestens ein eskalieretr Pegelwert gr��er als seine aktuelle Stufengrenze ist, werden alle Pegel auf ihre aktuelle Stufengrenze gesetzt.
 -	Falls kein eskalierter Pegelwert gr��er als seine aktuelle Stufengrenze ist, werden alle Stufen um eins erniedrigt und
										die Pegel werden auf das Maximum von currentValue und neuer Stufengrenze gesetzt.
 -	In beiden F�llen wird der Timer zur�ckgesetzt.

In dieser Funktion wird kein Level und kein Wert im dynamicSet erh�ht.
Am Ende der Funktion gilt:
 -	Kein Level verl�sst das Intervall [0 .. parameterSet->driverObservermaxLevelCount - 1].
 -  Kein Pegelwert kleiner als sein aktueller Stufengrenzwert
 -	Kein Pegelwert ist gr��er oder gleich seinem n�chsth�heren Stufengrenzwert.

\spec SW_MS_Innodrive2_Forecast_131
\spec SW_MS_Innodrive2_Forecast_132

\ingroup dobsDynamicSet
*/
static void	dobsCheckDeescalation(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
									IN const	currentDynamics_T	*currentDynamics,		/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
									IN const	tempLevels_T		*tempLevels,			/**<tempor�re Levels der aktuellen Werte*/
									IN const	real32_T			 deltaTime,				/**<Zykluszeit*/
									IN const	bool_T				 environmentChanged,	/**<Die Umgebung hat sich in diesem Rechentakt ge�ndert.*/
									INOUT		dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
									);



/** \brief Reduziert alle Stufen um eins und Setzt alle Werte auf das maximum aus aktuellem Wert und neuer Stufenuntergrenze.

Die Offsetgeschwindigkeit wird auf den Bereich [initialValue; upperBound] (jeweils Stufenabh�ngig) begrenzt.
Die Freifahrtgeschwindigkeit wird NICHT herabgesetzt.

\spec SW_MS_Innodrive2_Forecast_132

\ingroup dobsDynamicSet
*/
static void	dobsDeescalateLevels(		IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	currentDynamics_T	*currentDynamics,		/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										INOUT		dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
										);


/** \brief Aktualisiert die Beschleunigungspegel im dynamicSet

Aktualisiert die Beschleunigungspegel im dynamicSet.
Falls ein Pegel erh�ht wird, wird die Flag `isQuenched` des `dynamicSet`s auf `false` gesetzt.

\spec SW_MS_Innodrive2_Forecast_112
\spec SW_MS_Innodrive2_Forecast_115
\spec SW_MS_Innodrive2_Forecast_116

\ingroup dobsDynamicSet
*/
static void	dobsRampUpAccelerations(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	currentValues_T		*currentValues,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										INOUT		dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
										);


/** \brief Aktualisiert die Abweichung der Wunschgeschwindigkeit vom aktuellen Tempolimit.

Die Abweichung wird nicht auf unbegrenzten Strecken gelernt.
Die Abweichung wird tiefpassgefiltert und stufenabh�ngig begrenzt.

\spec SW_MS_Innodrive2_Forecast_134
\spec SW_MS_Innodrive2_Forecast_384

\ingroup dobsDynamicSet
*/
static void	dobsUpdateOffsetVelocity(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	real32_T			 deltaTime,				/**<Zeitinkrement*/
										IN const	velocitySet_T		*velocitySet,			/**<Umgebungs�bergreifende Wunschgeschwindigekit und Tempolimits*/
										INOUT		dynamicValue_T		*offsetVelocity			/**<Abweichung der Wunschgeschwindigkeit vom Tempolimit*/
										);



/** \brief Setzt alle Level auf das mindestens das `escalationLevel` und alle Werte auf mindestens die neue Leveluntergrenze.

\spec SW_MS_Innodrive2_Forecast_82
\spec SW_MS_Innodrive2_Forecast_129
\spec SW_MS_Innodrive2_Forecast_384

\ingroup dobsDynamicSet
*/
static void	dobsEscalateLevels(		IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/	
									IN const	tempLevels_T		*tempLevels,			/**<tempor�re Levels der aktuellen Werte*/
									INOUT		dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
									);

/** \brief Ordnet den aktuellen Werte im `dynamicSet` und den Eskalationstriggern Level zu.

Jedem Wert wirt das maximale Level zugeordnet, dessen Levelgrenzwert er �berschreitet.
Im Ausgabestrukt wird zus�tzlich das Maximum aller tempor�ren Level angegeben.

\spec SW_MS_Innodrive2_Forecast_118
\spec SW_MS_Innodrive2_Forecast_120
\spec SW_MS_Innodrive2_Forecast_121
\spec SW_MS_Innodrive2_Forecast_123
\spec SW_MS_Innodrive2_Forecast_125
\spec SW_MS_Innodrive2_Forecast_127

\ingroup dobsDynamicSet
*/
static void		dobsGetTempLevelsEsc(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	currentDynamics_T	*currentDynamics,		/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	dynamicSet_T		*dynamicSet,			/**<Satz von Fahrdynamikparametern*/
										OUT			tempLevels_T		*tempLevels				/**< Levels*/
										);


/** \brief Ordnet den aktuellen Fahrdynamikwerten und den Eskalationstriggern Level zu.

Jedem Wert wirt das maximale Level zugeordnet, dessen Levelgrenzwert er �berschreitet.
Im Ausgabestrukt wird zus�tzlich das Maximum aller tempor�ren Level angegeben.

\spec SW_MS_Innodrive2_Forecast_118
\spec SW_MS_Innodrive2_Forecast_120
\spec SW_MS_Innodrive2_Forecast_121
\spec SW_MS_Innodrive2_Forecast_123
\spec SW_MS_Innodrive2_Forecast_125
\spec SW_MS_Innodrive2_Forecast_127

\ingroup dobsDynamicSet
*/
static void		dobsGetTempLevelsDeesc(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	currentDynamics_T	*currentDynamics,		/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										OUT			tempLevels_T		*tempLevels 			/**< Levels*/
										);

/** \brief Setzt alle Pegel auf ihre Stufengrenzen herab.

\spec SW_MS_Innodrive2_Forecast_131

\ingroup dobsDynamicSet
*/
static void	dobsQuenchLevels(			IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										INOUT		dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
										);

#endif
