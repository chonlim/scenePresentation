#ifndef guard_dobsDataInterface_h
#define guard_dobsDataInterface_h

#include "control/driverObserver/driverObserver_interface.h"




/** \brief Gibt die aktuelle Umgebung (`country/countryRadar/city/invalid`) zur�ck.

Die Umgebungen `country`, `countryRadar` und `city` k�nnen verwendet werden, um das aktuelle dynamicSet mit \ref dobsGetDynamicSet() abzufragen.
Die Umgebung `invalid` wird ausgegeben, falls das Fahrzeug steht oder keine Kartendaten vom pathRouter verf�gbar sind uind zeigt an, 
dass der driverObserver die Werte NICHT aktualisiert hat. 

\spec SW_MS_Innodrive2_Forecast_63

\ingroup driverObserver_api
*/
dobsEnvironment_T	dobsGetEnvironment(	IN const		driverState_T		*driverState			/**<Private Struktur des driverObserver*/
										);


/** \brief Gibt die aktuelle Wunschgeschwindigkeit zur�ck

\spec SW_MS_Innodrive2_Forecast_65

\ingroup driverObserver_api
*/
real32_T			dobsGetDesiredSpeed(IN const		driverState_T		*driverState			/**<Private Struktur des driverObserver*/
										);

/** \brief Gibt die aktuelle Freifahrtgeschwindigkeit (auf unbegrenzter Autobahn) zur�ck.

\spec SW_MS_Innodrive2_Forecast_67

\ingroup driverObserver_api
*/
real32_T			dobsGetMaxVelocity(	IN const		driverState_T		*driverState			/**<Private Struktur des driverObserver*/
										);

/** \brief Gibt den aktuellen Zustand der Radarfolgefahrt als Wahrheitswert zur�ck.

\spec SW_MS_Innodrive2_Forecast_69

\ingroup driverObserver_api
*/
bool_T				dobsGetRadarState(	IN const		driverState_T		*driverState			/**<Private Struktur des driverObserver*/
										);

/** \brief Gibt das n�chste Tempolimit nach dem aktuellen zur�ck. Gibt Optional die dazugeh�rige Umgebung zur�ck

Falls kein g�ltiges n�chstes Tempolimit gefunden wurde, werden Positionund Wert als INVALID_VALUE zur�ckgegeben.

\spec SW_MS_Innodrive2_Forecast_70

\ingroup driverObserver_api
*/
dobsNextLimitInfo_T	dobsGetNextSpeedLimit(	IN const		driverState_T		*driverState		/**<Private Struktur des driverObserver*/
											);


/** \brief Gibt das `dynamicSet` zur angegebenen Umgebung zur�ck.

Die aktuelle Umgebung kann mir \ref dobsGetEnvironment() abgefragt werden.
Falls `environment == invalid` ist, ist der R�ckgabewert falsch und das ausgegebene dynamicSet enth�lt nur init-Werte.

\spec SW_MS_Innodrive2_Forecast_72

\ingroup driverObserver_api
*/
bool_T				dobsGetDynamicSet(	IN const		driverState_T		*driverState,			/**<Private Struktur des driverObserver*/
										IN const		dobsEnvironment_T	 environment,			/**<Umgebung (Land/Land+Radar/Stadt)*/
										OUT				dynamicSet_T		*dynamicSet				/**<Umgebungsspezifischr Fahrdynamikparametersatz*/
										);




#endif
