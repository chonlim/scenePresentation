#ifndef guard_dobsVelocitySetStatic_h
#define guard_dobsVelocitySetStatic_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "control/driverObserver/driverObserver_private.h"


/** \brief Verwaltet den Pufferspeicher des letzten, aktuellen und zuk�nftigen Tempolimits.

Die Tempolimits werden vom pathRouter gelesen und �rtlich entprellt in der Struktur `speedLimits` gespeichert.
Wenn ein `currentSpeedLimit` aktuell wird, wird das aktuelle Tempolimit als `lastSpeedLimit` gespeichert und die Flag `initializeDesiredSpeed gesetzt`.
Es werden keine Limits eingetragen, wenn der Wert gleich bleibt. Es soll immer gelten: last != current und current != next.
Ung�ltige Limits erhalten als Position und Wert 0.0f.

\spec SW_MS_Innodrive2_Forecast_93

\ingroup dobsVelocitySet
*/
static bool_T	dobsBufferSpeedLimits(	IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Ausged�nnte Kartendaten aus dem Modul pathRouter*/
										IN const	real32_T			 vehiclePosition,			/**<Fahrzeugposition*/
										INOUT		speedLimits_T		*speedLimits,				/**<Letztes, aktuelles und n�chstes Tempolimit*/
										OUT			bool_T				*initializeDesiredSpeed		/**<Flag wird gesetzt bei neuem aktuellen Tempolimit*/
										);	


/** \brief Akutalisiert die Wunschgeschwindigkeit
Die Aktualisierung der Wunschgeschwindigkeit findet getrennt in dobsRampUpDesiredSpeed() und dobsRampDownDesiredSpeed() statt.
Falls in einer Pufferzone vor dem Tempolimitwechsel ein rampUp stattfindet, wir die Flag `takeOverNextSpeedLimit` auf `true` gesetzt.
In einer Pufferzone nach dem Tempolimitwechsel wird die �nderung der Wunschgeschwindigkeit begrenzt \ref dobsLimitDesiredSpeed().

\spec SW_MS_Innodrive2_Forecast_78
\spec SW_MS_Innodrive2_Forecast_79

\ingroup dobsVelocitySet
*/
static void	dobsUpdateDesiredSpeed(		IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	currentValues_T		*currentValues,				/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	speedLimits_T		*speedLimits,				/**<Letztes, aktuelles und n�chstes Tempolimit*/
										INOUT		desiredSpeed_T		*desiredSpeed				/**<Aktuell angenommene Wunschgeschwindigkeit des Fahrers*/
										);


/**\brief Begrenzt die Wunschgeschwindigkeit in einer �rtlichen Pufferzone vor nach einem Tempolimitwechsel.

In einer Pufferzone nach einem Tempolimitwechsel abw�rts darf die Wunschgeschwindigkeit nicht wachsen.
In einer Pufferzone nach einem Tempolimitwechsel aufw�rts darf die Wunschgeschwindigkeit nicht sinken.

\spec SW_MS_Innodrive2_Forecast_97

\ingroup dobsVelocitySet
*/
static void	dobsLimitDesiredSpeed(		IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	speedLimits_T		*speedLimits,				/**<Letztes, aktuelles und n�chstes Tempolimit*/
										IN const	real32_T			 vehiclePosition,			/**<Fahrzeugposition (vobsBaseState.Position)*/
										IN const	real32_T			 newDesiredSpeed,			/**<Neue Wunschgeschwindigkeit*/
										INOUT		real32_T			*desiredSpeed				/**<Aktuell angenommene Wunschgeschwindigkeit des Fahrers*/
										);


/** \brief In Pufferzone vor dem Tempolimit bei relevalntem RampUp vorziehen des n�chsten Limits im Schieberegister.

\spec SW_MS_Innodrive2_Forecast_95

\ingroup dobsVelocitySet
*/
static void	dobsPushNextLimit(			IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Kartendaten*/
										IN const	currentValues_T		*currentValues,				/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										IN const	desiredSpeed_T		*desiredSpeed,				/**<Aktuell angenommene Wunschgeschwindigkeit des Fahrers*/
										INOUT		speedLimits_T		*speedLimits,				/**<Letztes, aktuelles und n�chstes Tempolimit*/
										OUT			bool_T				*pushNextLimitFlag			/**<Wurde das n�chste Tempolimit vorgezogen?*/
										);


/** \brief Setze das n�chste Tempolimit im Schieberegister.

\spec SW_MS_Innodrive2_Forecast_94

\ingroup dobsVelocitySet
*/
static void	dobsSetNextLimit(			IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Ausged�nnte Kartendaten aus dem Modul pathRouter*/
										IN const	real32_T			 vehiclePosition,			/**<Fahrzeugposition*/
										INOUT		speedLimits_T		*speedLimits				/**<Letztes, aktuelles und n�chstes Tempolimit*/
										);


/** \brief  Anpassung der Wunschgeschwindigkeit nach oben

Wenn vAktuell > vWunsch + Toleranz und aLong > Toleranz, 
dann wird vWunsch auf die mit der aktuellen Beschleunigung linear Extrapolierte aktuelle Geschwindigkeit gesetzt.
In diesem Fall wird die `rampUpFlag`auf `true`gesetzt.

\spec SW_MS_Innodrive2_Forecast_98

\ingroup dobsVelocitySet
*/
static void	dobsRampUpDesiredSpeed(		IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	currentDynamics_T	*currentDynamics,			/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										INOUT		desiredSpeed_T		*desiredSpeed				/**<Neue Wunschgeschwindigkeit*/
										);

/**\brief Anpassung der Wunschgeschwindigkeit nach unten

 Wenn vAktuell < vWunsch - Toleranz und die L�ngs und Querbeschleunigung seit einer Wartezeit nahe Null sind, 
dann wird vWunsch auf die aktuelle Geschwindigkeit gesetzt.

\spec SW_MS_Innodrive2_Forecast_99

\ingroup dobsVelocitySet
*/
static void	dobsRampDownDesiredSpeed(	IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	currentValues_T		*currentValues,				/**<Aktuelle Daten vom vehicleObserver f�r diesen Rechentakt*/
										INOUT		desiredSpeed_T		*desiredSpeed				/**<Neue Wunschgeschwindigkeit*/
										);

#endif
