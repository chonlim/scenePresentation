#include "control/driverObserver/dobsDynamicSet.h"
#include "control/driverObserver/dobsVelocitySet.h"
#include "control/driverObserver/dobsDynamicSetStatic.h"
#include "control/driverObserver/driverObserver_private.h"

#include "common/vehicleObserverCommon/vehicleObserver_interface.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dobsDynamicSet)


void		dobsInitDynamicValues(		IN const	parameterSetCtrl_T	*parameterSet,
										OUT			dynamicSetList_T	*dynamicSetList)
{
	const struct _parameterSetCtrl_driverObserver *parameters = &parameterSet->driverObserver;

	memset(dynamicSetList, 0, sizeof(dynamicSet_T));
	dynamicSetList->city.longAcceleration.value				= parameters->dynamicValues.cityInit.longAcceleration;
	dynamicSetList->city.longAcceleration.level				= parameters->dynamicValues.cityInit.level;
	dynamicSetList->city.longDeceleration.value				= parameters->dynamicValues.cityInit.longDeceleration;
	dynamicSetList->city.longDeceleration.level				= parameters->dynamicValues.cityInit.level;
	dynamicSetList->city.latAcceleration.value				= parameters->dynamicValues.cityInit.latAcceleration;
	dynamicSetList->city.latAcceleration.level				= parameters->dynamicValues.cityInit.level;
	dynamicSetList->city.offsetVelocity.value				= parameters->dynamicValues.cityInit.offsetVelocity;
	dynamicSetList->city.offsetVelocity.level				= parameters->dynamicValues.cityInit.level;
	dynamicSetList->city.level								= parameters->dynamicValues.cityInit.level;
	dynamicSetList->countryRadar.longAcceleration.value		= parameters->dynamicValues.countryRadarInit.longAcceleration;
	dynamicSetList->countryRadar.longAcceleration.level		= parameters->dynamicValues.countryRadarInit.level;
	dynamicSetList->countryRadar.longDeceleration.value		= parameters->dynamicValues.countryRadarInit.longDeceleration;
	dynamicSetList->countryRadar.longDeceleration.level		= parameters->dynamicValues.countryRadarInit.level;
	dynamicSetList->countryRadar.latAcceleration.value		= parameters->dynamicValues.countryRadarInit.latAcceleration;
	dynamicSetList->countryRadar.latAcceleration.level		= parameters->dynamicValues.countryRadarInit.level;
	dynamicSetList->countryRadar.offsetVelocity.value		= parameters->dynamicValues.countryRadarInit.offsetVelocity;
	dynamicSetList->countryRadar.offsetVelocity.level		= parameters->dynamicValues.countryRadarInit.level;
	dynamicSetList->countryRadar.level						= parameters->dynamicValues.countryRadarInit.level;
	dynamicSetList->country.longAcceleration.value			= parameters->dynamicValues.countryInit.longAcceleration;
	dynamicSetList->country.longAcceleration.level			= parameters->dynamicValues.countryInit.level;
	dynamicSetList->country.longDeceleration.value			= parameters->dynamicValues.countryInit.longDeceleration;
	dynamicSetList->country.longDeceleration.level			= parameters->dynamicValues.countryInit.level;
	dynamicSetList->country.latAcceleration.value			= parameters->dynamicValues.countryInit.latAcceleration;
	dynamicSetList->country.latAcceleration.level			= parameters->dynamicValues.countryInit.level;
	dynamicSetList->country.offsetVelocity.value			= parameters->dynamicValues.countryInit.offsetVelocity;
	dynamicSetList->country.offsetVelocity.level			= parameters->dynamicValues.countryInit.level;
	dynamicSetList->country.level							= parameters->dynamicValues.countryInit.level;

	/* Beschr�nken der Werte auf die unterste Levelgrenze */
	dynamicSetList->city.longAcceleration.value				= max(dynamicSetList->city.longAcceleration.value, parameters->escalation.longAccelerationLevels[dynamicSetList->city.level]);
	dynamicSetList->city.longDeceleration.value				= max(dynamicSetList->city.longDeceleration.value, parameters->escalation.longDecelerationLevels[dynamicSetList->city.level]);
	dynamicSetList->city.latAcceleration.value				= max(dynamicSetList->city.latAcceleration.value, parameters->escalation.latAccelerationLevels[dynamicSetList->city.level]);
	dynamicSetList->city.offsetVelocity.value				= max(dynamicSetList->city.offsetVelocity.value, parameters->offsetVelocity.initialValues[dynamicSetList->city.level]);
	dynamicSetList->city.wheelPower							= max(dynamicSetList->city.wheelPower, parameters->escalation.wheelPowerLevels[dynamicSetList->city.level]);
	dynamicSetList->city.maxJerk							= max(dynamicSetList->city.maxJerk, parameters->escalation.maxJerkLevels[dynamicSetList->city.level]);
	dynamicSetList->city.minJerk							= min(dynamicSetList->city.minJerk, parameters->escalation.minJerkLevels[dynamicSetList->city.level]);
	dynamicSetList->countryRadar.longAcceleration.value		= max(dynamicSetList->countryRadar.longAcceleration.value, parameters->escalation.longAccelerationLevels[dynamicSetList->countryRadar.level]);
	dynamicSetList->countryRadar.longDeceleration.value		= max(dynamicSetList->countryRadar.longDeceleration.value, parameters->escalation.longDecelerationLevels[dynamicSetList->countryRadar.level]);
	dynamicSetList->countryRadar.latAcceleration.value		= max(dynamicSetList->countryRadar.latAcceleration.value, parameters->escalation.latAccelerationLevels[dynamicSetList->countryRadar.level]);
	dynamicSetList->countryRadar.offsetVelocity.value		= max(dynamicSetList->countryRadar.offsetVelocity.value, parameters->offsetVelocity.initialValues[dynamicSetList->countryRadar.level]);
	dynamicSetList->countryRadar.wheelPower					= max(dynamicSetList->countryRadar.wheelPower, parameters->escalation.wheelPowerLevels[dynamicSetList->countryRadar.level]);
	dynamicSetList->countryRadar.maxJerk					= max(dynamicSetList->countryRadar.maxJerk, parameters->escalation.maxJerkLevels[dynamicSetList->countryRadar.level]);
	dynamicSetList->countryRadar.minJerk					= min(dynamicSetList->countryRadar.minJerk, parameters->escalation.minJerkLevels[dynamicSetList->countryRadar.level]);
	dynamicSetList->country.longAcceleration.value			= max(dynamicSetList->country.longAcceleration.value, parameters->escalation.longAccelerationLevels[dynamicSetList->country.level]);
	dynamicSetList->country.longDeceleration.value			= max(dynamicSetList->country.longDeceleration.value, parameters->escalation.longDecelerationLevels[dynamicSetList->country.level]);
	dynamicSetList->country.latAcceleration.value			= max(dynamicSetList->country.latAcceleration.value, parameters->escalation.latAccelerationLevels[dynamicSetList->country.level]);
	dynamicSetList->country.offsetVelocity.value			= max(dynamicSetList->country.offsetVelocity.value, parameters->offsetVelocity.initialValues[dynamicSetList->country.level]);
	dynamicSetList->country.wheelPower						= max(dynamicSetList->country.wheelPower, parameters->escalation.wheelPowerLevels[dynamicSetList->country.level]);
	dynamicSetList->country.maxJerk							= max(dynamicSetList->country.maxJerk, parameters->escalation.maxJerkLevels[dynamicSetList->country.level]);
	dynamicSetList->country.minJerk							= min(dynamicSetList->country.minJerk, parameters->escalation.minJerkLevels[dynamicSetList->country.level]);
}


void		dobsInitDynamicValuesRadar(	IN const	parameterSetCtrl_T	*parameterSet,
										OUT			dynamicSet_T		*countryRadarSet)
{
	const struct _parameterSetCtrl_driverObserver *parameters = &parameterSet->driverObserver;

	memset(countryRadarSet, 0, sizeof(dynamicSet_T));
	countryRadarSet->longAcceleration.value					= parameters->dynamicValues.countryRadarInit.longAcceleration;
	countryRadarSet->longAcceleration.level					= parameters->dynamicValues.countryRadarInit.level;
	countryRadarSet->longDeceleration.value					= parameters->dynamicValues.countryRadarInit.longDeceleration;
	countryRadarSet->longDeceleration.level					= parameters->dynamicValues.countryRadarInit.level;
	countryRadarSet->latAcceleration.value					= parameters->dynamicValues.countryRadarInit.latAcceleration;
	countryRadarSet->latAcceleration.level					= parameters->dynamicValues.countryRadarInit.level;
	countryRadarSet->offsetVelocity.value					= parameters->dynamicValues.countryRadarInit.offsetVelocity;
	countryRadarSet->level									= parameters->dynamicValues.countryRadarInit.level;

	/* Beschr�nken der Werte auf die unterste Levelgrenze */
	countryRadarSet->longAcceleration.value					= max(countryRadarSet->longAcceleration.value, parameters->escalation.longAccelerationLevels[countryRadarSet->level]);
	countryRadarSet->longDeceleration.value					= max(countryRadarSet->longDeceleration.value, parameters->escalation.longDecelerationLevels[countryRadarSet->level]);
	countryRadarSet->latAcceleration.value					= max(countryRadarSet->latAcceleration.value, parameters->escalation.latAccelerationLevels[countryRadarSet->level]);
	countryRadarSet->wheelPower								= max(countryRadarSet->wheelPower, parameters->escalation.wheelPowerLevels[countryRadarSet->level]);
	countryRadarSet->maxJerk								= max(countryRadarSet->maxJerk, parameters->escalation.maxJerkLevels[countryRadarSet->level]);
	countryRadarSet->minJerk								= min(countryRadarSet->minJerk, parameters->escalation.minJerkLevels[countryRadarSet->level]);

}


static void		dobsRampUpAccelerations(	IN const	parameterSetCtrl_T	*parameterSet,
											IN const	currentValues_T		*currentValues,
											INOUT		dynamicSet_T		*dynamicSet)
{
	real32_T filtered;

	/*L�ngsbeschleunigung*/
	filtered = dobsLowPassFilter(	parameterSet->driverObserver.dynamicValues.lowPassTimeConstant,
									currentValues->baseValues.deltaTime,
									dynamicSet->longAcceleration.value,
									currentValues->currentDynamics.longAcceleration);
	if (filtered > dynamicSet->longAcceleration.value)
	{
		/*\spec SW_MS_Innodrive2_Forecast_112*/
		dynamicSet->longAcceleration.value = filtered;
		dynamicSet->isQuenched = false;
	}

	/*L�ngsverz�gerung*/
	filtered = dobsLowPassFilter(	parameterSet->driverObserver.dynamicValues.lowPassTimeConstant,
									currentValues->baseValues.deltaTime,
									dynamicSet->longDeceleration.value,
									currentValues->currentDynamics.longDeceleration);
	if (filtered > dynamicSet->longDeceleration.value)
	{
		/*\spec SW_MS_Innodrive2_Forecast_115*/
		dynamicSet->longDeceleration.value = filtered;
		dynamicSet->isQuenched = false;
	}

	/*Querbeschleunigung*/
	filtered = dobsLowPassFilter(	parameterSet->driverObserver.dynamicValues.lowPassTimeConstant,
									currentValues->baseValues.deltaTime,
									dynamicSet->latAcceleration.value,
									currentValues->currentDynamics.latAcceleration);
	if (filtered > dynamicSet->latAcceleration.value)
	{
		/*\spec SW_MS_Innodrive2_Forecast_116*/
		dynamicSet->latAcceleration.value = filtered;
		dynamicSet->isQuenched = false;
	}
}



void		dobsUpdateDynamicSet(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	currentValues_T		*currentValues,
										IN const	velocitySet_T		*velocitySet,
										IN const	bool_T				 environmentChanged,
										INOUT		dynamicSet_T		*dynamicSet)
{
	/*lint -esym(438, offsetVelocity) (Last Value not used)*/
	tempLevels_T tempLevelsEsc, tempLevelsDeesc;
	dynamicValue_T offsetVelocity;

	/*Beschleunigungen*/
	dobsRampUpAccelerations(parameterSet, currentValues, dynamicSet);

	/*Offset-Geschwindigkeit*/
	offsetVelocity = dynamicSet->offsetVelocity;
	dobsUpdateOffsetVelocity(parameterSet, currentValues->baseValues.deltaTime, velocitySet, (dynamicValue_T*)&offsetVelocity);
	if(isOffsetUpdateActive(parameterSet, &currentValues->baseValues, &velocitySet->speedLimits))
	{
		dynamicSet->offsetVelocity = offsetVelocity;
	}

	/*Timer*/
	dynamicSet->timer += currentValues->baseValues.deltaTime;

	/*Deeskalation pr�fen und durchf�hren*/
	dobsGetTempLevelsDeesc(parameterSet, &currentValues->currentDynamics, &tempLevelsDeesc);
	dobsCheckDeescalation(parameterSet, &currentValues->currentDynamics, &tempLevelsDeesc, currentValues->baseValues.deltaTime, environmentChanged, dynamicSet);
	
	/*Eskalation pr�fen und durchf�hren*/
	dobsGetTempLevelsEsc(parameterSet, &currentValues->currentDynamics, dynamicSet, &tempLevelsEsc);
	dobsEscalateLevels(parameterSet, &tempLevelsEsc, dynamicSet);
	
	/*Radleistung und Ruck angeben*/
	/*\spec SW_MS_Innodrive2_Forecast_136*/
	dynamicSet->wheelPower	= parameterSet->driverObserver.escalation.wheelPowerLevels[dynamicSet->longAcceleration.level];
	/*\spec SW_MS_Innodrive2_Forecast_139*/
	dynamicSet->minJerk		= parameterSet->driverObserver.escalation.minJerkLevels[dynamicSet->longAcceleration.level];
	/*\spec SW_MS_Innodrive2_Forecast_138*/
	dynamicSet->maxJerk		= parameterSet->driverObserver.escalation.maxJerkLevels[dynamicSet->longAcceleration.level];
}


static bool_T	isOffsetUpdateActive(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	baseValues_T		*baseValues,
										IN const	speedLimits_T		*speedLimits)
{
	real32_T bufferLengthAfterLimit = dobsGetBufferLength(parameterSet, &speedLimits->currentLimit);

	/*Dichter Verkehr oder Fahrzeug in Pufferzone vor oder nach Tempolimitwechsel oder unbeschr�nkt?*/
	if (	speedLimits->isDenseTraffic
		||	speedLimits->currentLimit.raw == (uint16_T)rawLimitReleased
		||	(	speedLimits->nextLimit.position > 0.0f
			&&	baseValues->vehiclePosition >= speedLimits->nextLimit.position    - parameterSet->driverObserver.desiredSpeed.bufferLengthBeforeLimit)
		|| (	baseValues->vehiclePosition >= speedLimits->currentLimit.position
			&&	baseValues->vehiclePosition <  speedLimits->currentLimit.position + bufferLengthAfterLimit))
	{
		return false;
	} else {
		return true;
	}
}


real32_T	dobsLowPassFilter(			IN const	real32_T			timeConstant,
										IN const	real32_T			deltaTime,
										IN const	real32_T			lastValue,
										IN const	real32_T			currentValue)
{
	/*\spec SW_MS_Innodrive2_Forecast_87*/
	return lastValue + (deltaTime / (deltaTime + timeConstant)) * (currentValue - lastValue);
}


static void		dobsUpdateOffsetVelocity(	IN const	parameterSetCtrl_T	*parameterSet,
											IN const	real32_T			 deltaTime,
											IN const	velocitySet_T		*velocitySet,
											INOUT		dynamicValue_T		*offsetVelocity)
{
	real32_T value;
	/*Tiefpassfilterung*/
	/*\spec SW_MS_Innodrive2_Forecast_134*/
	value = dobsLowPassFilter(	parameterSet->driverObserver.offsetVelocity.lowPassTimeConstant, 
												deltaTime, 
												offsetVelocity->value,
												velocitySet->desiredSpeed.value - velocitySet->speedLimits.currentLimit.limit);

	offsetVelocity->value = value;
	/*Begrenzung findet in dobsEscalateLevels statt*/
}


bool_T		dobsUpdateMaxVelocity(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	baseValues_T		*baseValues,
										IN const	velocitySet_T		*velocitySet,
										IN const	uint8_T				 initLevel,
										INOUT		maxVelocity_T		*maxVelocity)
{
	real32_T desiredSpeed, adapdetMaxVelocity, lowPassTimeConstant;
	real32_T bufferLengthAfterLimit = dobsGetBufferLength(parameterSet, &velocitySet->speedLimits.currentLimit);

	/*Auswahl RampUp oder RampDown*/
	/*\spec SW_MS_Innodrive2_Forecast_103*/
	if(velocitySet->desiredSpeed.value > maxVelocity->value)
	{
		lowPassTimeConstant = parameterSet->driverObserver.maxVelocity.lowPassTimeConstantUp;
	} else {
		lowPassTimeConstant = parameterSet->driverObserver.maxVelocity.lowPassTimeConstantDown;
	}
	
	/*Tiefpassfilter*/
	/*\spec SW_MS_Innodrive2_Forecast_103*/
	desiredSpeed = max(velocitySet->desiredSpeed.value, parameterSet->driverObserver.maxVelocity.initialValues[0u]);
	adapdetMaxVelocity = dobsLowPassFilter(	lowPassTimeConstant, baseValues->deltaTime, maxVelocity->value, desiredSpeed);

	/*Kein RampDown nach Tempolimitwechsel aufw�rts*/
	if (	baseValues->vehiclePosition >= velocitySet->speedLimits.currentLimit.position
		&&	baseValues->vehiclePosition <  velocitySet->speedLimits.currentLimit.position + bufferLengthAfterLimit)
	{
		adapdetMaxVelocity = max(adapdetMaxVelocity, maxVelocity->value);
	} else {
		/*\spec SW_MS_Innodrive2_Forecast_103*/
		adapdetMaxVelocity = max(adapdetMaxVelocity, adapdetMaxVelocity);
	}
	
	/*Adaption nur auf unbeschr�nkter Strecke*/
	if (velocitySet->speedLimits.currentLimit.raw == (uint16_T)rawLimitReleased)
	{
		maxVelocity->isAdapted	= true;
	} else {
		adapdetMaxVelocity = maxVelocity->value;
	}
	
	/*Auswahl Adaption oder Initialisierung*/
	diagFF(initLevel < (uint8_T)dobsMAXLEVELCOUNT);
	/*\spec SW_MS_Innodrive2_Forecast_104*/
	maxVelocity->value = maxVelocity->isAdapted ? adapdetMaxVelocity : parameterSet->driverObserver.maxVelocity.initialValues[initLevel];

	return true;
}


static void		dobsGetTempLevelsEsc(		IN const	parameterSetCtrl_T	*parameterSet,
											IN const	currentDynamics_T	*currentDynamics,
											IN const	dynamicSet_T		*dynamicSet,
											OUT			tempLevels_T		*tempLevels)
{
	tempLevels->maxLevel = 0u;
	/*�berpr�fe ob longAcceleration in einer neuen Stufe ist und eskaliere ggf. das Level.*/
	/*\spec SW_MS_Innodrive2_Forecast_118*/
	getCurrentLevel( dynamicSet->longAcceleration.value,
					 parameterSet->driverObserver.escalation.levelCount, 
					 parameterSet->driverObserver.escalation.longAccelerationLevels,
					&tempLevels->longAcceleration);
	/*\spec SW_MS_Innodrive2_Forecast_125*/
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->longAcceleration);

	/*�berpr�fe ob longDeceleration in einer neuen Stufe ist und eskaliere ggf. das Level.*/
	/*\spec SW_MS_Innodrive2_Forecast_120*/
	getCurrentLevel( dynamicSet->longDeceleration.value,
					 parameterSet->driverObserver.escalation.levelCount, 
					 parameterSet->driverObserver.escalation.longDecelerationLevels,
					&tempLevels->longDeceleration);
	/*\spec SW_MS_Innodrive2_Forecast_125*/
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->longDeceleration);

	/*�berpr�fe ob latAcceleration in einem neuen Level ist und eskaliere ggf. das Level.*/
	/*\spec SW_MS_Innodrive2_Forecast_121*/
	getCurrentLevel( dynamicSet->latAcceleration.value,
					 parameterSet->driverObserver.escalation.levelCount, 
					 parameterSet->driverObserver.escalation.latAccelerationLevels,
					&tempLevels->latAcceleration);
	/*\spec SW_MS_Innodrive2_Forecast_125*/
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->latAcceleration);

	/*Radleistung*/
	/*\spec SW_MS_Innodrive2_Forecast_123*/
	getCurrentLevel( currentDynamics->wheelPower,
					 parameterSet->driverObserver.escalation.levelCount, 
					 parameterSet->driverObserver.escalation.wheelPowerLevels,
					&tempLevels->wheelPower);
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->wheelPower);

	/*Ausnahme: Das Level der L�ngsbeschleunigung wird durch die Radleistung nach unten begrenzt.*/
	tempLevels->longAcceleration = max(tempLevels->longAcceleration, tempLevels->wheelPower);

	/*Fahrpedalgradient*/
	/*\spec SW_MS_Innodrive2_Forecast_127*/
	getCurrentLevel( currentDynamics->acceleratorGradient,
					 parameterSet->driverObserver.escalation.levelCount,
					 parameterSet->driverObserver.escalation.acceleratorGradLevels,
					&tempLevels->acceleratorGrad);
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->acceleratorGrad);
}

/* Level vor der 2. Filterung bestimmen */
static void		dobsGetTempLevelsDeesc(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	currentDynamics_T	*currentDynamics,
										OUT			tempLevels_T		*tempLevels)
{
	tempLevels->maxLevel = 0u;
	/*�berpr�fe ob longAcceleration in einer neuen Stufe ist und eskaliere ggf. das Level.*/
	/*\spec SW_MS_Innodrive2_Forecast_118*/
	getCurrentLevel(currentDynamics->longAcceleration,
		parameterSet->driverObserver.escalation.levelCount,
		parameterSet->driverObserver.escalation.longAccelerationLevels,
		&tempLevels->longAcceleration);
	/*\spec SW_MS_Innodrive2_Forecast_125*/
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->longAcceleration);

	/*�berpr�fe ob longDeceleration in einer neuen Stufe ist und eskaliere ggf. das Level.*/
	/*\spec SW_MS_Innodrive2_Forecast_120*/
	getCurrentLevel(currentDynamics->longDeceleration,
		parameterSet->driverObserver.escalation.levelCount,
		parameterSet->driverObserver.escalation.longDecelerationLevels,
		&tempLevels->longDeceleration);
	/*\spec SW_MS_Innodrive2_Forecast_125*/
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->longDeceleration);

	/*�berpr�fe ob latAcceleration in einem neuen Level ist und eskaliere ggf. das Level.*/
	/*\spec SW_MS_Innodrive2_Forecast_121*/
	getCurrentLevel(currentDynamics->latAcceleration,
		parameterSet->driverObserver.escalation.levelCount,
		parameterSet->driverObserver.escalation.latAccelerationLevels,
		&tempLevels->latAcceleration);
	/*\spec SW_MS_Innodrive2_Forecast_125*/
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->latAcceleration);

	/*Radleistung*/
	/*\spec SW_MS_Innodrive2_Forecast_123*/
	getCurrentLevel(currentDynamics->wheelPower,
		parameterSet->driverObserver.escalation.levelCount,
		parameterSet->driverObserver.escalation.wheelPowerLevels,
		&tempLevels->wheelPower);
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->wheelPower);

	/*Ausnahme: Das Level der L�ngsbeschleunigung wird durch die Radleistung nach unten begrenzt.*/
	tempLevels->longAcceleration = max(tempLevels->longAcceleration, tempLevels->wheelPower);

	/*Fahrpedalgradient*/
	/*\spec SW_MS_Innodrive2_Forecast_127*/
	getCurrentLevel(currentDynamics->acceleratorGradient,
		parameterSet->driverObserver.escalation.levelCount,
					 parameterSet->driverObserver.escalation.acceleratorGradLevels,
					&tempLevels->acceleratorGrad);
	tempLevels->maxLevel = max(tempLevels->maxLevel, tempLevels->acceleratorGrad);
}
										

static void		getCurrentLevel(		IN const	real32_T			 value,
										IN const	uint8_T				 levelCount,
										IN const	real32_T			*levelBorders,
										OUT			uint8_T				*currentLevel)
{
	uint8_T i;

	/*Alle Stufen pr�fen*/
	*currentLevel = 0u;
	for (i = 0; i < (uint8_T)dobsMAXLEVELCOUNT; i++)
	{
		if (	value >= levelBorders[i]
			&&	i < levelCount)
		{
			*currentLevel = i;
		}
	}
}


static void		dobsEscalateLevels(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	tempLevels_T		*tempLevels,
										INOUT		dynamicSet_T		*dynamicSet)
{
	uint8_T escalationLevel;

	if (tempLevels->maxLevel > parameterSet->driverObserver.escalation.escalationOffset)
	{
		escalationLevel = tempLevels->maxLevel - parameterSet->driverObserver.escalation.escalationOffset;
	} else {
		escalationLevel = 0u;
	}
		
	/*Maximallevel und individuelle Level nachziehen*/
	dynamicSet->level					= max(dynamicSet->level, tempLevels->maxLevel);
	dynamicSet->longAcceleration.level	= max(dynamicSet->longAcceleration.level, tempLevels->longAcceleration);
	dynamicSet->longDeceleration.level	= max(dynamicSet->longDeceleration.level, tempLevels->longDeceleration);
	dynamicSet->latAcceleration.level	= max(dynamicSet->latAcceleration.level,  tempLevels->latAcceleration);
	
	/*Level auf das Eskalationslevel nachziehen*/
	dynamicSet->longAcceleration.level	= max(dynamicSet->longAcceleration.level, escalationLevel);
	dynamicSet->longDeceleration.level	= max(dynamicSet->longDeceleration.level, escalationLevel);
	dynamicSet->latAcceleration.level	= max(dynamicSet->latAcceleration.level,  escalationLevel);
	dynamicSet->offsetVelocity.level	= max(dynamicSet->offsetVelocity.level,  escalationLevel);

	/*Falls Level eskaliert wurden, m�ssen die entsprechenden Werte nachgezogen werden.*/
	dynamicSet->longAcceleration.value	= max(dynamicSet->longAcceleration.value, parameterSet->driverObserver.escalation.longAccelerationLevels[dynamicSet->longAcceleration.level]);
	dynamicSet->longDeceleration.value	= max(dynamicSet->longDeceleration.value, parameterSet->driverObserver.escalation.longDecelerationLevels[dynamicSet->longDeceleration.level]);
	dynamicSet->latAcceleration.value	= max(dynamicSet->latAcceleration.value,  parameterSet->driverObserver.escalation.latAccelerationLevels[dynamicSet->latAcceleration.level]);
	
	/*\spec SW_MS_Innodrive2_Forecast_384*/
	dynamicSet->offsetVelocity.value	= max(dynamicSet->offsetVelocity.value,	parameterSet->driverObserver.offsetVelocity.lowerBounds[dynamicSet->offsetVelocity.level]);
	dynamicSet->offsetVelocity.value	= min(dynamicSet->offsetVelocity.value,	parameterSet->driverObserver.offsetVelocity.upperBounds[dynamicSet->offsetVelocity.level]);
}


static void		dobsCheckDeescalation(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	currentDynamics_T	*currentDynamics,
										IN const	tempLevels_T		*tempLevels,
										IN const	real32_T			 deltaTime,
										IN const	bool_T				 environmentChanged,
										INOUT		dynamicSet_T		*dynamicSet)
{
	dynamicSet_T tmpDynamicSet = *dynamicSet;

	/*Wenn mindestens ein Pegelwert mit level >= 1 gr��er als der Stufengrenzwert ist.*/
	if (tmpDynamicSet.isQuenched)
	{
		/*Alle Pegelwerte liegen auf den Stufengrenzen. Stufen herabsetzen.*/
		/*\spec SW_MS_Innodrive2_Forecast_82*/
		/*\spec SW_MS_Innodrive2_Forecast_132*/
		dobsDeescalateLevels(parameterSet, currentDynamics, &tmpDynamicSet);
	}
	else
	{
		/*\spec SW_MS_Innodrive2_Forecast_131*/
		/*Pegel auf Stufengrenzen herabsetzen.*/
		dobsQuenchLevels(parameterSet, &tmpDynamicSet);
	}
	/*Timer-Reset*/
	tmpDynamicSet.timer = 0.0f;

	/*Erreicht ein tempor�res Dynamik-Level des Dynamikparameters das Level des
	entsprechenden Dynamikparameters im aktiven Set, wird der Timer zur�ckgesetzt.*/
	/*\spec SW_MS_Innodrive2_Forecast_82*/
	if(dynamicSet->longAcceleration.level > 0u  &&  tempLevels->longAcceleration >= dynamicSet->longAcceleration.level)
	{
		dynamicSet->timer = 0.0f;
	}
	if(dynamicSet->longDeceleration.level > 0u  &&  tempLevels->longDeceleration >= dynamicSet->longDeceleration.level)
	{
		dynamicSet->timer = 0.0f;
	}
	if(dynamicSet->latAcceleration.level > 0u  &&  tempLevels->latAcceleration >= dynamicSet->latAcceleration.level)
	{
		dynamicSet->timer = 0.0f;
	}

	/*Erreicht ein tempor�res Level eines Eskalationstriggers das Fahrdynamik-Level (beachte:
	Ausnahme Radleistung � Radleistung wird mit a_x-level verglichen) des aktiven Sets, wird
	der Timer zur�ckgesetzt*/
	if(dynamicSet->longAcceleration.level > 0u  &&  tempLevels->wheelPower >= dynamicSet->longAcceleration.level)
	{
		dynamicSet->timer = 0.0f;
	}
	if(dynamicSet->level > 0u  &&  tempLevels->acceleratorGrad >= dynamicSet->level)
	{
		dynamicSet->timer = 0.0f;
	}
	if(environmentChanged)
	{
		dynamicSet->timer = 0.0f;
	}

	/*Wenn der Timer abgelaufen ist - deltaTime wird ben�tigt, da Timer bereits inkrementiert wurde*/
	/*\spec SW_MS_Innodrive2_Forecast_131*/
	if (dynamicSet->timer > parameterSet->driverObserver.escalation.deescalationTimes[dynamicSet->level] + deltaTime - ROUNDING_ERROR)
	{
		*dynamicSet = tmpDynamicSet;
	}
}


static void		dobsQuenchLevels(		IN const		parameterSetCtrl_T	*parameterSet,
										INOUT			dynamicSet_T		*dynamicSet)
{
	real32_T longAcceleration_value = dynamicSet->longAcceleration.value;
	real32_T longDeceleration_value = dynamicSet->longDeceleration.value;
	real32_T latAcceleration_value	= dynamicSet->latAcceleration.value;
	real32_T offsetVelocity_value	= dynamicSet->offsetVelocity.value;

	/*Level bleiben wie sie sind*/
	/*Pegel auf Levelgrenzen setzen*/
	longAcceleration_value	= min(longAcceleration_value, parameterSet->driverObserver.escalation.longAccelerationLevels[dynamicSet->longAcceleration.level]);
	longDeceleration_value	= min(longDeceleration_value, parameterSet->driverObserver.escalation.longDecelerationLevels[dynamicSet->longDeceleration.level]);
	latAcceleration_value	= min(latAcceleration_value, parameterSet->driverObserver.escalation.latAccelerationLevels[dynamicSet->latAcceleration.level]);
	offsetVelocity_value	= max(offsetVelocity_value, parameterSet->driverObserver.offsetVelocity.lowerBounds[dynamicSet->offsetVelocity.level]);
	offsetVelocity_value	= min(offsetVelocity_value, parameterSet->driverObserver.offsetVelocity.upperBounds[dynamicSet->offsetVelocity.level]);
	dynamicSet->isQuenched = true;

	dynamicSet->longAcceleration.value = longAcceleration_value;
	dynamicSet->longDeceleration.value = longDeceleration_value;
	dynamicSet->latAcceleration.value	= latAcceleration_value;
	dynamicSet->offsetVelocity.value	= offsetVelocity_value;
}



static void		dobsDeescalateLevels(	IN const		parameterSetCtrl_T	*parameterSet,
										IN const		currentDynamics_T	*currentDynamics,
										INOUT			dynamicSet_T		*dynamicSet)
{
	real32_T offsetVelocity_value = dynamicSet->offsetVelocity.value;

	/*Level um eins reduzieren.*/
	int8_T tmpLevel					= max(0, (int8_T)dynamicSet->level - 1);
	int8_T tmpLongAccelerationLevel	= max(0, (int8_T)dynamicSet->longAcceleration.level - 1);
	int8_T tmpLongDecelerationLevel	= max(0, (int8_T)dynamicSet->longDeceleration.level - 1);
	int8_T tmpLatAccelerationLevel	= max(0, (int8_T)dynamicSet->latAcceleration.level  - 1);
	int8_T tmpoffsetVelocityLevel	= max(0, (int8_T)dynamicSet->offsetVelocity.level	- 1);
	/*Setzen*/
	dynamicSet->level					= (uint8_T)tmpLevel;
	dynamicSet->longAcceleration.level	= (uint8_T)tmpLongAccelerationLevel;
	dynamicSet->longDeceleration.level	= (uint8_T)tmpLongDecelerationLevel;
	dynamicSet->latAcceleration.level	= (uint8_T)tmpLatAccelerationLevel;
	dynamicSet->offsetVelocity.level	= (uint8_T)tmpoffsetVelocityLevel;
	/*Pegel auf aktuelle Werte setzen.*/
	dynamicSet->longAcceleration.value	= max(currentDynamics->longAcceleration,	parameterSet->driverObserver.escalation.longAccelerationLevels[dynamicSet->longAcceleration.level]);
	dynamicSet->longDeceleration.value	= max(currentDynamics->longDeceleration,	parameterSet->driverObserver.escalation.longDecelerationLevels[dynamicSet->longDeceleration.level]);
	dynamicSet->latAcceleration.value	= max(currentDynamics->latAcceleration,		parameterSet->driverObserver.escalation.latAccelerationLevels[dynamicSet->latAcceleration.level]);
	offsetVelocity_value				= max(offsetVelocity_value,		parameterSet->driverObserver.offsetVelocity.lowerBounds[dynamicSet->offsetVelocity.level]);
	offsetVelocity_value				= min(offsetVelocity_value,		parameterSet->driverObserver.offsetVelocity.upperBounds[dynamicSet->offsetVelocity.level]);

	dynamicSet->offsetVelocity.value = offsetVelocity_value;
}


void		dobsSetMinimalValues(		IN const	dynamicSet_T		*referenceSet,
										IN const	parameterSetCtrl_T	*parameterSet,
										INOUT		dynamicSet_T		*higherSet)
{
	higherSet->longAcceleration.value = max(higherSet->longAcceleration.value, referenceSet->longAcceleration.value);
	higherSet->longDeceleration.value = max(higherSet->longDeceleration.value, referenceSet->longDeceleration.value);
	higherSet->latAcceleration.value  = max(higherSet->latAcceleration.value,  referenceSet->latAcceleration.value);
	higherSet->offsetVelocity.value   = max(higherSet->offsetVelocity.value,   referenceSet->offsetVelocity.value);
	higherSet->wheelPower			  = max(higherSet->wheelPower,			   referenceSet->wheelPower);
	higherSet->maxJerk				  = max(higherSet->maxJerk,				   referenceSet->maxJerk);
	higherSet->minJerk				  = min(higherSet->minJerk,				   referenceSet->minJerk);
	
	higherSet->longAcceleration.level = max(higherSet->longAcceleration.level, referenceSet->longAcceleration.level);
	higherSet->longDeceleration.level = max(higherSet->longDeceleration.level, referenceSet->longDeceleration.level);
	higherSet->latAcceleration.level  = max(higherSet->latAcceleration.level,  referenceSet->latAcceleration.level);
	higherSet->offsetVelocity.level   = max(higherSet->offsetVelocity.level,   referenceSet->offsetVelocity.level);
	higherSet->level				  = max(higherSet->level,				   referenceSet->level);
	higherSet->isQuenched			  = !( higherSet->longAcceleration.value  > parameterSet->driverObserver.escalation.longAccelerationLevels[higherSet->longAcceleration.level]
										|| higherSet->longDeceleration.value  > parameterSet->driverObserver.escalation.longDecelerationLevels[higherSet->longDeceleration.level]
										|| higherSet->latAcceleration.value	  > parameterSet->driverObserver.escalation.latAccelerationLevels[higherSet->latAcceleration.level]);
}


void		dobsSetMaximalValues(		IN const	dynamicSet_T		*referenceSet,
										IN const	parameterSetCtrl_T	*parameterSet,
										INOUT		dynamicSet_T		*lowerSet)
{
	lowerSet->longAcceleration.value = min(lowerSet->longAcceleration.value, referenceSet->longAcceleration.value);
	lowerSet->longDeceleration.value = min(lowerSet->longDeceleration.value, referenceSet->longDeceleration.value);
	lowerSet->latAcceleration.value  = min(lowerSet->latAcceleration.value,  referenceSet->latAcceleration.value);
	lowerSet->offsetVelocity.value   = min(lowerSet->offsetVelocity.value,   referenceSet->offsetVelocity.value);
	lowerSet->wheelPower			 = min(lowerSet->wheelPower,			 referenceSet->wheelPower);
	lowerSet->maxJerk				 = min(lowerSet->maxJerk,				 referenceSet->maxJerk);
	lowerSet->minJerk				 = max(lowerSet->minJerk,				 referenceSet->minJerk);
	

	lowerSet->longAcceleration.level = min(lowerSet->longAcceleration.level, referenceSet->longAcceleration.level);
	lowerSet->longDeceleration.level = min(lowerSet->longDeceleration.level, referenceSet->longDeceleration.level);
	lowerSet->latAcceleration.level  = min(lowerSet->latAcceleration.level,  referenceSet->latAcceleration.level);
	lowerSet->offsetVelocity.level   = min(lowerSet->offsetVelocity.level,   referenceSet->offsetVelocity.level);
	lowerSet->level					 = min(lowerSet->level,					 referenceSet->level);
	lowerSet->isQuenched			 =	!( lowerSet->longAcceleration.value  > parameterSet->driverObserver.escalation.longAccelerationLevels[lowerSet->longAcceleration.level]
										|| lowerSet->longDeceleration.value  > parameterSet->driverObserver.escalation.longDecelerationLevels[lowerSet->longDeceleration.level]
										|| lowerSet->latAcceleration.value	 > parameterSet->driverObserver.escalation.latAccelerationLevels[lowerSet->latAcceleration.level]);
}
