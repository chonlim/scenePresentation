#ifndef guard_driverObserver_h
#define guard_driverObserver_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"

#include "control/driverObserver/driverObserver_interface.h"
#include "common/vehicleModel/vehicleModel.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"



/** \brief Wrapper um die Funktion \ref stepDriverObserver() zum Abfangen des Fehlerzustands.

\spec SW_MS_Innodrive2_Forecast_83
\spec SW_MS_Innodrive2_Forecast_114

\ingroup driverObserver_step
*/
void	driverObserver(					IN const	vehicleModel_T		*vehicleModel,			/**<Fahrzeugmodell*/
										IN const	vehicleState_T		*vehicleState,			/**<Fahrzeugzustand aus dem Modul vehicleObserver*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										INOUT		driverState_T		*driverState			/**<Private Struktur des driverObserver*/
										);





#endif
