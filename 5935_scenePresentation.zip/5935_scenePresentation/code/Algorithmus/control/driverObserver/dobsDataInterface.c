#include "control/control.h"
#include "control/driverObserver/dobsDataInterface.h"
#include "control/driverObserver/driverObserver_private.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dobsDataInterface)


dobsEnvironment_T	dobsGetEnvironment(	IN const		driverState_T		*driverState)
{
	/*\spec SW_MS_Innodrive2_Forecast_62*/
	return driverState->environmentState.environment;
}


real32_T			dobsGetDesiredSpeed(IN const		driverState_T		*driverState)
{
	/*\spec SW_MS_Innodrive2_Forecast_65*/
	return driverState->velocitySet.desiredSpeed.value;
}


real32_T			dobsGetMaxVelocity(	IN const		driverState_T		*driverState)
{
	/*\spec SW_MS_Innodrive2_Forecast_67*/
	return driverState->maxVelocity.value;
}


bool_T				dobsGetRadarState(	IN const		driverState_T		*driverState)
{
	/*\spec SW_MS_Innodrive2_Forecast_69*/
	return driverState->environmentState.radarState.followingRadar;
}


dobsNextLimitInfo_T	dobsGetNextSpeedLimit(	IN const	driverState_T		*driverState)
{
	/*\spec SW_MS_Innodrive2_Forecast_70*/
	return driverState->nextLimitInfo;
}


bool_T				dobsGetDynamicSet(	IN const		driverState_T		*driverState,
										IN const		dobsEnvironment_T	 environment,
										OUT				dynamicSet_T		*dynamicSet)
{
	/*\spec SW_MS_Innodrive2_Forecast_72*/
	bool_T valid = true;

	switch (environment)
	{
	case country:
		*dynamicSet = driverState->dynamicSetList.country;
		break;
	case countryRadar:
		*dynamicSet = driverState->dynamicSetList.countryRadar;
		break;
	case city:
		*dynamicSet = driverState->dynamicSetList.city;
		break;
	case invalid:
		memset(dynamicSet, 0, sizeof(dynamicSet_T));
		valid = false;
		break;
	default:
		diagFUnreachable();
	} /*lint !e9077*/

	return valid;
}
