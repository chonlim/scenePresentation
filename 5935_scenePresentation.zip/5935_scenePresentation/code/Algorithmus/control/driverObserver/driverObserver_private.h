#ifndef guard_driverObserver_private_h
#define guard_driverObserver_private_h

#include "control/driverObserver/driverObserver_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define dobsRECOMMENDED_SPEED 36.111111f /**< Kein Tempolimit */



struct _baseValues {
	real32_T vehiclePosition;
	real32_T deltaTime;
	bool_T isMapDataValid;
} ;                                      /**< Groesse der Struktur = 12 Bytes */

struct _currentDynamics {
	real32_T longAcceleration;
	real32_T longDeceleration;
	real32_T latAcceleration;
	real32_T wheelPower;
	real32_T acceleratorGradient;
	real32_T velocity;
} ;                                      /**< Groesse der Struktur = 24 Bytes */

struct _currentValues {
	baseValues_T baseValues;
	currentDynamics_T currentDynamics;
} ;                                      /**< Groesse der Struktur = 36 Bytes */

struct _maxVelocity {
	real32_T value;
	bool_T isAdapted;                    /**< Flag wird bei der ersten Beobachtung der Freifahrtgeschwindigkeit gesetzt. */
} ;                                      /**< Groesse der Struktur = 8 Bytes */

typedef struct _tempLevels {
	uint8_T longAcceleration;
	uint8_T longDeceleration;
	uint8_T latAcceleration;
	uint8_T wheelPower;
	uint8_T acceleratorGrad;
	uint8_T maxLevel;
} tempLevels_T;                          /**< Groesse der Struktur = 6 Bytes */

struct _desiredSpeed {
	bool_T isInitialized;
	real32_T value;
	real32_T waitTime;
} ;                                      /**< Groesse der Struktur = 12 Bytes */

struct _speedLimits {
	prtSpeedLimit_T lastLimit;
	prtSpeedLimit_T currentLimit;
	prtSpeedLimit_T nextLimit;
	bool_T isDenseTraffic;
} ;                                      /**< Groesse der Struktur = 64 Bytes */

typedef struct _velocitySet {
	speedLimits_T speedLimits;
	desiredSpeed_T desiredSpeed;
} velocitySet_T;                         /**< Groesse der Struktur = 76 Bytes */

struct _dobsRadarState {
	bool_T followingRadar;
	bool_T radarObjectLost;
	real32_T waitTime;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _filteredValues {
	real32_T longAcceleration;
	real32_T latAcceleration;
	real32_T velocity;
	real32_T accelerator;
	real32_T acceleratorGradient;
	real32_T executionTime;
} ;                                      /**< Groesse der Struktur = 24 Bytes */

struct _environmentState {
	real32_T dynEventPosition;
	dobsRadarState_T radarState;
	dobsEnvironment_T environment;
} ;                                      /**< Groesse der Struktur = 16 Bytes */

struct _dynamicSetList {
	dynamicSet_T country;
	dynamicSet_T countryRadar;
	dynamicSet_T city;
} ;                                      /**< Groesse der Struktur = 168 Bytes */

struct _driverState {
	bool_T isInitialized;
	velocitySet_T velocitySet;
	dynamicSetList_T dynamicSetList;
	maxVelocity_T maxVelocity;
	filteredValues_T lastValues;
	environmentState_T environmentState;
	dobsNextLimitInfo_T nextLimitInfo;
} ;                                      /**< Groesse der Struktur = 308 Bytes */


/*lint -restore */

#endif
