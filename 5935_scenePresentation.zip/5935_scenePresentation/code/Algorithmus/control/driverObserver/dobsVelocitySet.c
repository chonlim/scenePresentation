#include "control/driverObserver/dobsVelocitySet.h"
#include "control/driverObserver/dobsVelocitySetStatic.h"
#include "control/pathRouter/prtTools.h"

#include "common/vehicleObserverCommon/vehicleObserver_interface.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dobsVelocitySet)


bool_T		dobsUpdateVelocitySet(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	currentValues_T		*currentValues,
										INOUT		velocitySet_T		*velocitySet)
{
	prtSpeedLimit_T	onlineSpeed;
	bool_T newCurrentLimit, pushLimit; 
	
	/*Tempolimits aktualisieren*/
	diagFF(dobsBufferSpeedLimits(parameterSet, pathRouterMemory, currentValues->baseValues.vehiclePosition, &velocitySet->speedLimits, &newCurrentLimit));

	/*Dichten Verkehr erkennen*/
	/*\spec SW_MS_Innodrive2_Forecast_101*/
	if (	prtGetCurrentOnlineSpeed(pathRouterMemory, currentValues->baseValues.vehiclePosition, &onlineSpeed)
		&&	onlineSpeed.limit < velocitySet->speedLimits.currentLimit.limit - parameterSet->driverObserver.desiredSpeed.onlineSpeedTolerance)
	{
		velocitySet->speedLimits.isDenseTraffic = true;
	} else {
		velocitySet->speedLimits.isDenseTraffic = false;
	}

	/*N�chstes Tempolimit vorziehen*/
	dobsPushNextLimit(parameterSet, pathRouterMemory, currentValues, &velocitySet->desiredSpeed, &velocitySet->speedLimits, &pushLimit);

	/*Wunschegeschwindigkeit aktualisieren*/
	dobsUpdateDesiredSpeed(parameterSet, currentValues, &velocitySet->speedLimits, &velocitySet->desiredSpeed);

	/*Muss die Wunschgeschwindigkeit neu initialisiert werden?*/
	/*\spec SW_MS_Innodrive2_Forecast_100*/
	if((pushLimit || newCurrentLimit)  &&  !velocitySet->speedLimits.isDenseTraffic)
	{
		velocitySet->desiredSpeed.isInitialized = false;
	} else {
		velocitySet->desiredSpeed.isInitialized = true;
	}

	return true;
}


static bool_T	dobsBufferSpeedLimits(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	real32_T			 vehiclePosition,
										INOUT		speedLimits_T		*speedLimits,
										OUT			bool_T				*initializeDesiredSpeed)
{
	prtSpeedLimit_T mapLimit;
	volatile speedLimits_T	tmpLimits;

	/*Beachte: Die Tempolimit-Position im mapPath wird relativ zur Fahrzeugposition angegeben
	Im driver-Observer wird die vobsBaseState->Position dazuaddiert.*/
	
	/*Bei g�ltigen Kartendaten muss es ein aktuell g�ltiges Tempolimit geben.*/
	/*\spec SW_MS_Innodrive2_Forecast_93*/
	diagFF(prtGetCurrentSpeedLimit(pathRouterMemory, vehiclePosition, &mapLimit));
	
	tmpLimits = *speedLimits;

	/*Schiebe aktuelles Limit an die Speicherstelle "letztes Limit"*/
	tmpLimits.lastLimit				= tmpLimits.currentLimit;
	/*Speichere aktuelles Limit*/
	tmpLimits.currentLimit			= mapLimit;
	tmpLimits.currentLimit.position	= vehiclePosition;
	/*Markiere n�chstes Limit als ung�ltig.*/
	tmpLimits.nextLimit.limit		= 0.0f;
	tmpLimits.nextLimit.position	= 0.0f;
	tmpLimits.nextLimit.raw			= rawLimitInvalid;

	/*Wenn ein Limit vorgezogen wurde (dobsPushLimit) soll es nicht wieder vom mapLimit �berschrieben werden,
	darum nur �berschreiben, wenn die Farhezeugposition gr��er als die Limitposition ist.*/
	if (	fastfabsf(mapLimit.limit - speedLimits->currentLimit.limit) > ROUNDING_ERROR
		&&	vehiclePosition > speedLimits->currentLimit.position)
	{
		/*\spec SW_MS_Innodrive2_Forecast_93*/
		*speedLimits = tmpLimits;
		*initializeDesiredSpeed = true;
	}
	else
	{
		tmpLimits = *speedLimits;
		*initializeDesiredSpeed = false;
	}

	dobsSetNextLimit(parameterSet, pathRouterMemory, vehiclePosition, speedLimits);

	return true;
}


static void		dobsSetNextLimit(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	real32_T			 vehiclePosition,
										INOUT		speedLimits_T		*speedLimits)
{
	prtSpeedLimit_T mapLimit, nextLimit;
	bool_T valid;

	mapLimit.limit = INVALID_VALUE;
	mapLimit.position = INVALID_VALUE;
	mapLimit.raw = rawLimitInvalid;

	/*\spec SW_MS_Innodrive2_Forecast_94*/
	valid = prtGetNextSpeedLimit(pathRouterMemory, vehiclePosition, &mapLimit);

	/*N�chstes Limit: Nur Tempo�nderungen �bernehmen.*/
	if (	fastfabsf(mapLimit.limit - speedLimits->currentLimit.limit) > ROUNDING_ERROR
		&&	mapLimit.position - vehiclePosition < parameterSet->driverObserver.desiredSpeed.maxDistanceNextLimit)
	{
		/*\spec SW_MS_Innodrive2_Forecast_94*/
		nextLimit = mapLimit;
	}
	else
	{
		nextLimit = speedLimits->nextLimit;
	}
	
	if (valid)
	{
		/*\spec SW_MS_Innodrive2_Forecast_94*/
		speedLimits->nextLimit = nextLimit;
	}
	else
	{
		/*Kein n�chstes Limit erkannt. Markiere als ung�ltig.*/
		speedLimits->nextLimit.limit	= 0.0f;
		speedLimits->nextLimit.position = 0.0f;
		speedLimits->nextLimit.raw = rawLimitInvalid;
	}
}

void		dobsInitDesiredSpeed(		IN const	speedLimits_T		*speedLimits,
										IN const	dynamicSet_T		*dynamicSet,
										IN const	maxVelocity_T		*maxVelocity,
										OUT			desiredSpeed_T		*desiredSpeed)
{
	
	if (speedLimits->currentLimit.raw == (uint16_T)rawLimitReleased)
	{
		/*Ohne Tempolimit auf Richtgeschwindigkeit initialisieren*/
		desiredSpeed->value = maxVelocity->value;
	}
	else
	{
		/*Sonst auf aktuelles Tempolimit initialisieren*/
		desiredSpeed->value = speedLimits->currentLimit.limit + dynamicSet->offsetVelocity.value;
	}
	desiredSpeed->waitTime = 0.0f;
	desiredSpeed->isInitialized = true;
}


static void		dobsUpdateDesiredSpeed(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	currentValues_T		*currentValues,
										IN const	speedLimits_T		*speedLimits,
										INOUT		desiredSpeed_T		*desiredSpeed)
{
	desiredSpeed_T	newDesiredSpeed = *desiredSpeed;

	/*Hochrampen der Wunschgeschwindigkeit pr�fen und durchf�hren. rampUpFlag zeigt einen Hochrampvorgang an.*/
	dobsRampUpDesiredSpeed(parameterSet, &currentValues->currentDynamics, &newDesiredSpeed);

	/*Herunterrampen der Wunschgeschwindigkeit pr�fen und durchf�hren.*/
	dobsRampDownDesiredSpeed(parameterSet, currentValues, &newDesiredSpeed);
	
	/*�bertragen der neuen Wunschgeschwindigkeit*/
	if(currentValues->currentDynamics.velocity > parameterSet->driverObserver.environment.standStillVelocityTolerance) {
		desiredSpeed->waitTime = newDesiredSpeed.waitTime;
	} else {
		desiredSpeed->waitTime = desiredSpeed->waitTime;
	}

	dobsLimitDesiredSpeed(parameterSet, speedLimits, currentValues->baseValues.vehiclePosition, newDesiredSpeed.value, &desiredSpeed->value);
}


static void		dobsRampUpDesiredSpeed(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	currentDynamics_T	*currentDynamics,
										INOUT		desiredSpeed_T		*desiredSpeed)
{
	desiredSpeed_T tmpSpeed;

	/*Extrapolieren, um nicht zu oft zu aktualisieren.*/
	tmpSpeed.value = currentDynamics->velocity + currentDynamics->longAcceleration * parameterSet->driverObserver.desiredSpeed.extrapolationTime;
	tmpSpeed.waitTime = 0.0f;

	/*Wunschgeschwindigkeit, Ramp Up wenn Geschwindigkeit und Beschleunigung �ber Ausl�seschwelle*/
	if (	tmpSpeed.value > desiredSpeed->value + parameterSet->driverObserver.desiredSpeed.velocityToleranceLarge
		||(	tmpSpeed.value > desiredSpeed->value + parameterSet->driverObserver.desiredSpeed.velocityTolerance
		&&	currentDynamics->longAcceleration > parameterSet->driverObserver.desiredSpeed.longAccelerationToleranceUp))
	{
		/*\spec SW_MS_Innodrive2_Forecast_98*/
		*desiredSpeed = tmpSpeed;
	} else  {
		tmpSpeed = *desiredSpeed; /*lint -esym(438, tmpSpeed) (Last assigned value not used)*/
	}
}


static void		dobsRampDownDesiredSpeed(	IN const	parameterSetCtrl_T	*parameterSet,
											IN const	currentValues_T		*currentValues,
											INOUT		desiredSpeed_T		*desiredSpeed)
{
	desiredSpeed_T tmpSpeed;


	/*Wartezeit beachten*/
	if (desiredSpeed->waitTime >= parameterSet->driverObserver.desiredSpeed.rampDownTime)
	{
		tmpSpeed.value = currentValues->currentDynamics.velocity;
		tmpSpeed.waitTime = 0.0f;		
	} else {
		tmpSpeed.value = desiredSpeed->value; 
		tmpSpeed.waitTime = desiredSpeed->waitTime + currentValues->baseValues.deltaTime;	
	}

	/*Bei Langsamfahrt einfrieren (Z�hler pausieren und nicht herunterrampen.*/
	if (currentValues->currentDynamics.velocity <= parameterSet->driverObserver.desiredSpeed.minVelocityRampDown)
	{
		tmpSpeed = *desiredSpeed;
	} else {
		tmpSpeed = tmpSpeed;
	}

	/*Wunschgeschwindigkeit, Ramp Down bei Konstantfahrt �ber signifikanten Zeitraum.*/
	if (	currentValues->currentDynamics.velocity < desiredSpeed->value - parameterSet->driverObserver.desiredSpeed.velocityTolerance
		&&	currentValues->currentDynamics.longAcceleration < parameterSet->driverObserver.desiredSpeed.longAccelerationToleranceDown
		&&	currentValues->currentDynamics.longDeceleration < parameterSet->driverObserver.desiredSpeed.longDecelerationTolerance
		&&	currentValues->currentDynamics.latAcceleration  < parameterSet->driverObserver.desiredSpeed.latAccelerationTolerance)
	{
		/*Herunterrampen*/
		/*\spec SW_MS_Innodrive2_Forecast_99*/
		*desiredSpeed = tmpSpeed;
	}
	else
	{
		/*Wartezeit zur�cksetzen*/
		desiredSpeed->waitTime = 0.0f;
	}
}


static void		dobsLimitDesiredSpeed(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	speedLimits_T		*speedLimits,
										IN const	real32_T			 vehiclePosition,
										IN const	real32_T			 newDesiredSpeed,
										INOUT		real32_T			*desiredSpeed)
{
	real32_T tmpSpeed;
	real32_T bufferLength = dobsGetBufferLength(parameterSet, &speedLimits->currentLimit);

	/*\spec SW_MS_Innodrive2_Forecast_97*/
	if(speedLimits->currentLimit.limit > speedLimits->lastLimit.limit)
	{
		/*Bei Limitwechsel aufw�rts, keine �nderung der Wunschgeschwindigkeit abw�rts*/
		tmpSpeed = max(*desiredSpeed, newDesiredSpeed);
	} else {
		/*Bei Limitwechsel abw�rts, keine �nderung der Wunschgeschwindigkeit aufw�rts*/
		tmpSpeed = min(*desiredSpeed, newDesiredSpeed);
	}

	/*�bertragen der neuen Wunschgeschwindigkeit mit Limitierung in Pufferzone nach Tempolimitwechsel.*/
	if (	vehiclePosition > speedLimits->currentLimit.position
		&&	vehiclePosition < speedLimits->currentLimit.position + bufferLength)
	{
		*desiredSpeed = tmpSpeed;
	}
	else
	{
		*desiredSpeed = newDesiredSpeed;
	}
}


static void		dobsPushNextLimit(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	currentValues_T		*currentValues,
										IN const	desiredSpeed_T		*desiredSpeed,
										INOUT		speedLimits_T		*speedLimits,
										OUT			bool_T				*pushNextLimitFlag)
{
	speedLimits_T tmpSpeedLimits = *speedLimits;

	
	/*N�chstes Tempolimit vorziehen*/
	tmpSpeedLimits.lastLimit			= speedLimits->currentLimit;
	tmpSpeedLimits.currentLimit			= speedLimits->nextLimit;
	tmpSpeedLimits.nextLimit.limit		= 0.0f;
	tmpSpeedLimits.nextLimit.position	= 0.0f;
		
	/*N�chstes Tempolimit neu setzen*/
	dobsSetNextLimit(parameterSet, pathRouterMemory, tmpSpeedLimits.currentLimit.position + ROUNDING_ERROR, &tmpSpeedLimits);

	/*\spec SW_MS_Innodrive2_Forecast_95*/
	if(		currentValues->baseValues.vehiclePosition		>= speedLimits->nextLimit.position - parameterSet->driverObserver.desiredSpeed.bufferLengthBeforeLimit
		&&	currentValues->baseValues.vehiclePosition		<  speedLimits->nextLimit.position
		&&	speedLimits->nextLimit.limit					>  speedLimits->currentLimit.limit
		&&	currentValues->currentDynamics.velocity			>  desiredSpeed->value + parameterSet->driverObserver.desiredSpeed.velocityTolerance
		&&	currentValues->currentDynamics.longAcceleration >  parameterSet->driverObserver.desiredSpeed.longAccTolPushNextLimit)
	{
		*speedLimits = tmpSpeedLimits;
		*pushNextLimitFlag = true;
	}
	else
	{
		tmpSpeedLimits = *speedLimits; /*lint -esym(438, tmpSpeedLimits) (Last assigned value not used)*/
		*pushNextLimitFlag = false;
	}
}


real32_T	 dobsGetBufferLength(		IN const	parameterSetCtrl_T	*parameterSet,
										IN const	prtSpeedLimit_T		*speedLimit)
{
	/*\spec SW_MS_Innodrive2_Forecast_137*/
	if (speedLimit->raw == (uint16_T)rawLimitReleased)
	{
		return parameterSet->driverObserver.desiredSpeed.bufferTimeAfterLimit * dobsRECOMMENDED_SPEED;
	}
	else
	{
		return parameterSet->driverObserver.desiredSpeed.bufferTimeAfterLimit * speedLimit->limit;
	}
}
