#ifndef guard_dprdParameters_h
#define guard_dprdParameters_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_private.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"


/**\brief Kopiert die Fahrdynamikparameter f�r jede Umgebung aus dem driverObserver und berechnet zus�tzliche Parameter.

\ingroup driverPredictor_parameters
*/
bool_T	dprdInitDynamicParameters(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
									IN const	driverState_T		*driverState,			/**<Private Struktur des driverObserver*/
									OUT			dynamicParameters_T	*dynamicParameters		/**<Struktur mit allen dynamischen Parametern, die initialisiert werden soll.*/
									);

/**\brief Liefert einen Zeiger auf den konstanten Fahrdynamikparametersatz f�r die angefragte Umgebung zur�ck.

\ingroup driverPredictor_parameters
*/
const dynamicParameterSet_T	*dprdGetDynamicSetPtr(	IN const	dynamicParameters_T		*dynamicParameters,		/**<Struktur mit allen dynamischen Parametern*/
													IN const	dobsEnvironment_T		environment				/**<Angeforderte Umgebung*/
													);

/**\brief Erh�ht das dynamische Level der Parameter auf einen mindest Level aus dem control Parameter Set.

\ingroup driverPredictor_parameters
*/
bool_T dprdDynamicParameterSetLevel(IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
									IN const	dobsEnvironment_T	environment,				/**<Umgebung f�r die ein Dynamik-Level gesetzt wird.*/
									INOUT		dynamicParameters_T	*dynamicParameters			/**<Struktur mit allen dynamischen Parametern*/
									);
#endif
