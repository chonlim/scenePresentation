#ifndef guard_dprdEnvironment_h
#define guard_dprdEnvironment_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_private.h"
#include "control/driverObserver/dobsDataInterface.h"
#include "control/pathRouter/prtTools.h"
#include "common/pathRouterCommon/prtDataInterface.h"



/**\brief Erstellt eine Liste der wechselnden Umgebungen von der Fahrzeugposition bis zum Ende des Vorausschauhorizonts.

Die aktuelle Umgebung an der vehiclePosition wird vom driverObserver �bernommen.
Anschlie�end wird die Umgebung und die entsprechende Position aus der Vorschau des driverObservers (\ref dobsGetNextSpeedLimit()) eingef�gt.
Alle darauf folgenden Umgebungen ergebens sich aus den Umgebungswechseln aus dem mapPath.

\spec SW_MS_Innodrive2_Forecast_360
\spec SW_MS_Innodrive2_Forecast_361
\spec SW_MS_Innodrive2_Forecast_366

\ingroup driverPredictor_environment
*/
bool_T	dprdInitEnvironmentList(	IN const	driverState_T		*driverState,					/**<Private Struktur des driverObserver*/
									IN const	parameterSetCtrl_T	*parameterSet,					/**<Globale Parameter*/
									IN const	pathRouterMemory_T	*pathRouterMemory,				/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
									IN const	mapPath_T			*mapPath,						/**<Ausged�nnte Kartendaten aus dem Modul pathRouter*/
									OUT			real32_T			*dynamicEventPosition,				/**<Das Fahrdynamikevent wird nur betrachetet, wenn die Position ungleich INVALID_VALUE ist.*/
									OUT			environmentList_T	*environmentList				/**<Liste der Umgebungen*/
									);


/**\brief Sucht eine passende Umgebung zur Position `position` in der Liste `environmentList``.

R�ckgabewert ist `true`, wenn eine Umgebung zugeordnet werden konnte. Ansonsten `false` und `environment` wird wird auf `invalid` gesetzt.

\ingroup driverPredictor_environment
*/
bool_T	dprdGetEnvironmentFromPosition(	IN const	real32_T				position,				/**<Position zu der eine Umgebung bestimmt wird.*/
										IN const	environmentList_T		*environmentList,		/**<Liste der Umgebungen*/
										OUT			dobsEnvironment_T		*environment			/**<Passende Umgebung zu `position`*/
										);




#endif
