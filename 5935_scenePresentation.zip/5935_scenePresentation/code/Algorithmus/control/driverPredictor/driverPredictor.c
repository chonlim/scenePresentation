#include "control/driverPredictor/driverPredictor.h"
#include "control/driverPredictor/dprdStep.h"
#include "control/driverPredictor/driverpredictor_private.h"

#include <string.h>

void	driverPredictor(				IN const	vehicleModel_T		*vehicleModel,
										IN const	vehicleInput_T		*vehicleInput,
										IN const	vehicleState_T		*vehicleState,
										IN const	driverState_T		*driverState,
										IN const	mapPath_T			*mapPath,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										INOUT		driverPredictorMemory_T *driverPredictorMemory,
										OUT			driverPrediction_T	*driverPrediction)
{
	bool_T oldToggleBitState = driverPredictorMemory->toggleBit;

	/*Durchf�hren eines Rechenschritts und neuinitialisierung sowie Fehlermeldung bei unerwartetem Fehler*/
	if (!stepDriverPredictor(vehicleModel, 
							 vehicleInput, 
							 vehicleState, 
							 driverState, 
							 mapPath, 
							 pathRouterMemory, 
							 driverPredictorMemory, 
							 driverPrediction))
	{
		/*Der driverPredictor befindet sich im Fehlerfall, weshalb die Ausgangsdaten als ung�ltig marktiert werden.*/
		driverPredictorMemory->hasValidPrediction = false;

		/*der driverPredictor befindet sich im Fehlerfall und wird zur�ck gesetzt.*/
		driverPredictorMemory->state = dprdStateCalcEnvironment;
		memset(driverPrediction, 0, sizeof(driverPrediction_T));
		driverPrediction->toggleBit = oldToggleBitState;
	}
	return;
}
