#include "control/driverPredictor/dprdConstraints.h"
#include "control/driverPredictor/dprdParameters.h"
#include "control/driverPredictor/dprdTrajectory.h"
#include "control/driverPredictor/dprdTrajectoryStatic.h"
#include "control/driverPredictor/driverpredictor_private.h"

#include "control/driverObserver/dobsDataInterface.h"

#include "common/vehicleModel/vmdlTools.h"
#include "control/pathRouter/prtTools.h"
#include "control/parameterSet/ParameterSetCtrl.h"

/*lint -esym(9045, struct _exception*/
#include <math.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdTrajectory)

/* Quelle: www.codeproject.com/Articles/69941/Best-Square-Root-Method-Algorithm-Function-Precisi */
#define SQRT_MAGIC_F 0x5f3759df 
static real32_T  fastsqrt(const real32_T x);
static real32_T  fastsqrt(const real32_T x)
{
	const real32_T xhalf = 0.5f*x;

	union
	{
		real32_T x;
		int32_T i;
	} u;  /*lint !e9018 (Note -- declaration of symbol 'u' with union based type 'union {...}' [MISRA 2012 Rule 19.2, advisory])*/

	u.x = x;
	u.i = (SQRT_MAGIC_F - (u.i >> 1));		/* gives initial guess y0*//*lint !e702 !e9027 (Note -- Unpermitted operand to operator '>>' [MISRA 2012 Rule 10.1, required]) �bernahme Algorithmus aus Literatur*/
	return x*u.x*(1.5f - xhalf*u.x*u.x);	/* Newton step, repeating increases accuracy */
}


static bool_T	dprdAppendVector(	IN const	predictionState_T	*vector,
									INOUT		trajectory_T		*trajectory)
{
	/*Schutz vor Schreiben out of bounds*/
	diagFF(trajectory->count < (uint8_T)dprdCONSTRAINT_COUNT);

	/*Schreiben*/
	if (vector->longAcceleration	!= INVALID_VALUE &&
		vector->latAcceleration		!= INVALID_VALUE &&
		vector->position			!= INVALID_VALUE &&
		vector->velocity			!= INVALID_VALUE &&
		vector->streetClass			!= prtStreetClassInit)
	{
		trajectory->vector[trajectory->count] = *vector;
		trajectory->count++;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		trajectory->vector[0] = trajectory->vector[0];
		trajectory->count = trajectory->count;
	}

	return true;
}

static bool_T	dprdCalcTimestep(	IN const	vehicleModel_T		*vehicleModel,
									IN const	pathRouterMemory_T	*pathRouterMemory,
									IN const	dynamicParameters_T	*dynamicParameters,
									IN const	parameterSetCtrl_T	*parameterSet,
									IN const	constraintSet_T		*constraintSet,
									IN const	environmentList_T	*environmentList,
									IN const	predictionState_T	*currentVector,
									OUT			predictionState_T	*nextVector
									)
{
	real32_T slope				= INVALID_VALUE;
	real32_T curvature			= INVALID_VALUE;
	real32_T maxAcceleration	= INVALID_VALUE;
	bool_T	 valid, validWheelPower;
	real32_T deltaT				= parameterSet->driverPredictor.deltaTime;
	uint8_T	 envIndex;
	
	valid = dprdEvalConstraints(dynamicParameters, parameterSet, constraintSet, currentVector, vehicleModel, pathRouterMemory, &maxAcceleration);

	/*\spec SW_MS_Innodrive2_Forecast_340*/
	/*\spec SW_MS_Innodrive2_Forecast_342*/
	nextVector->velocity = currentVector->velocity + 0.5f * (currentVector->longAcceleration + maxAcceleration) * deltaT; /*\spec SW_MS_Innodrive2_Forecast_388*/
	nextVector->velocity = max(nextVector->velocity, 0.0f);
	nextVector->position = currentVector->position + currentVector->velocity * deltaT + (currentVector->longAcceleration / 3.0f + maxAcceleration / 6.0f) * deltaT * deltaT;
	/*\spec SW_MS_Innodrive2_Forecast_340*/
	nextVector->longAcceleration = maxAcceleration;
	/*\spec SW_MS_Innodrive2_Forecast_389*/
	nextVector->longAcceleration = max(nextVector->longAcceleration, parameterSet->driverPredictor.minAcceleration);
	
	/* berechne Radleistung */
	validWheelPower = prtGetSlopeAtPosition(pathRouterMemory, nextVector->position, &slope) && valid; /*\spec SW_MS_Innodrive2_Forecast_345*/
	validWheelPower = prtGetCurvatureAtPosition(pathRouterMemory, nextVector->position, &curvature) && validWheelPower; /*\spec SW_MS_Innodrive2_Forecast_344*/

	/*\spec SW_MS_Innodrive2_Forecast_340*/
	/*\spec SW_MS_Innodrive2_Forecast_345*/
	validWheelPower = vmdlGetWheelPower(vehicleModel, nextVector->velocity, nextVector->longAcceleration, curvature, slope, 0.0f, &nextVector->wheelPower) && validWheelPower;

	if (!validWheelPower)
	{ 
		nextVector->wheelPower = INVALID_VALUE;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		nextVector->wheelPower = nextVector->wheelPower;
	}
	
	/*\spec SW_MS_Innodrive2_Forecast_386*/
	nextVector->streetClass = prtStreetClassInit;
	valid = prtGetStreetClassAtPosition(pathRouterMemory, nextVector->position, &nextVector->streetClass) && valid; /*\spec SW_MS_Innodrive2_Forecast_386*/

	envIndex = dprdENVIRONMENT_COUNT - 1;
	while (   (   nextVector->position < environmentList->environment[envIndex].begin 
		       || environmentList->environment[envIndex].environment == invalid)
		   && envIndex > 0u)
	{
		envIndex--;
	}

	if (   (environmentList->environment[envIndex].environment == city)
		&& (   (nextVector->streetClass == prtStreetClassLocal)
			|| (nextVector->streetClass == prtStreetClassDistrict)
			|| (nextVector->streetClass == prtStreetClassCountry)
			|| (nextVector->streetClass == prtStreetClassFederal)
			)
		)
	{
		nextVector->streetClass = prtStreetClassLocal;
	}

	if (curvature != INVALID_VALUE)
	{
		nextVector->latAcceleration = INVALID_VALUE;
		/*\spec SW_MS_Innodrive2_Forecast_340*/
		/*\spec SW_MS_Innodrive2_Forecast_344*/
		nextVector->latAcceleration = nextVector->velocity * nextVector->velocity * curvature;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		nextVector->latAcceleration = nextVector->velocity * nextVector->velocity * curvature;
		nextVector->latAcceleration = INVALID_VALUE;
	}
	
	return valid;
}


static bool_T setMinVelocity(	IN const	dynamicParameters_T				*dynamicParameters,
								IN const	dobsEnvironment_T				environment,
								IN const	real32_T						sqLandingVelocity,
								IN const	uint8_T							constraintIndex,
								INOUT		constraintVelocityContainer_T	*velocityContainer,
								INOUT		dprdLandingProfile_T			*landingProfile)
{
	const dynamicParameterSet_T	*dynamicParametersSet;
	bool_T isValid = false;
	dprdLandingProfile_T profile = profileConstant;

	if (*landingProfile != profileInvalid && environment != invalid)
	{
		profile = *landingProfile;
		velocityContainer->environmentArray[profile] = environment;
		isValid = true;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		profile = profileConstant;
		velocityContainer->environmentArray[profile] = velocityContainer->environmentArray[profile];
		isValid = false;
	}

	dynamicParametersSet = dprdGetDynamicSetPtr(dynamicParameters, velocityContainer->environmentArray[profile]);
	if (isValid && sqLandingVelocity < velocityContainer->sqVLandArray[(uint8_T)profile] && profile != profileConstant)
	{
		diagFF(NULL != dynamicParametersSet);
		velocityContainer->sqVLandArray[(uint8_T)profile] = sqLandingVelocity;
		velocityContainer->environmentArray[(uint8_T)profile] = environment;
		velocityContainer->accelerationArray[(uint8_T)profile] = dynamicParametersSet->minLongAcceleration; /*\spec SW_MS_Innodrive2_Forecast_390*/
		velocityContainer->constraintIndexArray[(uint8_T)profile] = constraintIndex;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		velocityContainer->sqVLandArray[(uint8_T)profile] = velocityContainer->sqVLandArray[(uint8_T)profile];
		velocityContainer->environmentArray[(uint8_T)profile] = velocityContainer->environmentArray[(uint8_T)profile];
		velocityContainer->accelerationArray[(uint8_T)profile] = velocityContainer->accelerationArray[(uint8_T)profile];
		velocityContainer->constraintIndexArray[(uint8_T)profile] = velocityContainer->constraintIndexArray[(uint8_T)profile];
	}

	if (isValid && sqLandingVelocity < velocityContainer->sqVLandArray[(uint8_T)profile] && profile == profileConstant)
	{
		/*\spec SW_MS_Innodrive2_Forecast_394*/
		velocityContainer->sqVLandArray[(uint8_T)profile] = sqLandingVelocity;
		velocityContainer->environmentArray[(uint8_T)profile] = environment;
		velocityContainer->accelerationArray[(uint8_T)profile] = 0.0f;
		velocityContainer->constraintIndexArray[(uint8_T)profile] = constraintIndex;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		velocityContainer->sqVLandArray[(uint8_T)profile] = velocityContainer->sqVLandArray[(uint8_T)profile];
		velocityContainer->environmentArray[(uint8_T)profile] = velocityContainer->environmentArray[(uint8_T)profile];
		velocityContainer->accelerationArray[(uint8_T)profile] = velocityContainer->accelerationArray[(uint8_T)profile];
		velocityContainer->constraintIndexArray[(uint8_T)profile] = velocityContainer->constraintIndexArray[(uint8_T)profile];
	}

	*landingProfile = isValid? profile : profileInvalid;

	return true;
}

static bool_T getMinVelocities(	IN const	uint8_T							count,
								IN const	uint16_T						evalCount,
								IN const	uint8_T							offset,
								IN const	dynamicParameters_T				*dynamicParameters,
								IN const	constraintSet_T					*constraintSet,
								IN const	predictionState_T				*currentVector,
								IN const	real32_T						deltaT,
								INOUT		constraintVelocityContainer_T	*velocityContainer
								)
{
	uint8_T i;
	uint8_T startIndex = offset + count;
	dprdLandingProfile_T	landingProfile = profileInvalid;
	real32_T				sqLandingVelocity = INVALID_VALUE;
	dobsEnvironment_T		tmpEnvironment = invalid;


	for (i = 0; i < count; i++)
	{
		const uint8_T index = i + offset;
		if (index < (uint8_T)dprdCONSTRAINT_COUNT && currentVector->position < constraintSet->constraintList.constraint[index].end)
		{
			startIndex = index;
			break;
		}
	}

	for (i = 0; i < evalCount; i++)
	{
		const uint8_T index = i + startIndex;
		landingProfile = profileInvalid;
		if (index < (uint8_T)dprdCONSTRAINT_COUNT && index < offset + count)
		{
			diagFF(dprdCalcLanding(	dynamicParameters,
									currentVector,
									&constraintSet->constraintList.constraint[index],
									deltaT,
									&tmpEnvironment,
									&sqLandingVelocity,
									&landingProfile));
		}
		else
		{ /*konstante Laufzeit realisieren*/
			diagFF(dprdCalcLanding(	dynamicParameters,
									currentVector,
									&constraintSet->constraintList.constraint[constraintSet->offset.speedLimit],
									deltaT,
									&tmpEnvironment,
									&sqLandingVelocity,
									&landingProfile));
			landingProfile = profileInvalid;
		}

		diagFF(setMinVelocity(dynamicParameters, tmpEnvironment, sqLandingVelocity, index, velocityContainer, &landingProfile));
	}

	return true;
}


static bool_T	dprdEvalConstraints(IN const	dynamicParameters_T	*dynamicParameters,
									IN const	parameterSetCtrl_T	*parameterSet,
									IN const	constraintSet_T		*constraintSet,
									IN const	predictionState_T	*currentVector,
									IN const	vehicleModel_T		*vehicleModel,
									IN const	pathRouterMemory_T	*pathRouterMemory,
									OUT			real32_T			*maxAcceleration)
{
	uint8_T					i, velConstraintIndex;
	const real32_T			deltaT = parameterSet->driverPredictor.deltaTime;
	dobsEnvironment_T		tmpEnvironment;
	real32_T				maxAccelerationJerk;
	const dynamicParameterSet_T	*dynamicParametersSet = NULL;
	constraintVelocityContainer_T velocityContainer;
	bool_T					valid = true;
	real32_T				slope = INVALID_VALUE;
	real32_T				curvature = INVALID_VALUE;
	predictionState_T nextVector;
	real32_T wheelPower = INVALID_VALUE;
	real32_T tmpMaxAccel;
	bool_T validMaxWheelPower = true;
		
	/* Der nachfolgende Quelltext funktioniert nur korrekt wenn profileInvalid == 4 ist */
	BUILD_BUG_ON((uint8_T)profileInvalid != 4u);
	BUILD_BUG_ON((uint8_T)classInvalid != 3u);

	/* setze standard Werte */
	for (i = 0; i < (uint8_T)profileInvalid; i++)
	{
		velocityContainer.sqVLandArray[i] = INVALID_VALUE;
		velocityContainer.accelerationArray[i] = 0.0f;
		velocityContainer.environmentArray[i] = invalid;
		velocityContainer.constraintIndexArray[i] = dprdCONSTRAINT_COUNT;
	}

	/*\spec SW_MS_Innodrive2_Forecast_357*/
	diagFF(getMinVelocities(constraintSet->count.onlineLimit,
							parameterSet->driverPredictor.evalCount.onlineLimit,
							constraintSet->offset.onlineLimit,
							dynamicParameters,
							constraintSet,
							currentVector,
							deltaT,
							&velocityContainer));

	diagFF(getMinVelocities(constraintSet->count.curvatureLimit,
							parameterSet->driverPredictor.evalCount.curvature,
							constraintSet->offset.curvatureLimit,
							dynamicParameters,
							constraintSet,
							currentVector,
							deltaT,
							&velocityContainer));

	diagFF(getMinVelocities(constraintSet->count.speedLimit,
							parameterSet->driverPredictor.evalCount.speedLimit,
							constraintSet->offset.speedLimit,
							dynamicParameters,
							constraintSet,
							currentVector,
							deltaT,
							&velocityContainer));

	/* aus quadratisch berechneten Geschwindigkeit die Wurzel ziehen, damit die Einheiten stimmen */
	for (i = 0; i < (uint8_T)profileInvalid; i++)
	{
		if (velocityContainer.sqVLandArray[i] != INVALID_VALUE)
		{
			velocityContainer.sqVLandArray[i] = fastsqrt(velocityContainer.sqVLandArray[i]);
			velocityContainer.sqVLandArray[i] = velocityContainer.sqVLandArray[i];
		}
		else
		{ /*konstante Laufzeit realisieren*/
			velocityContainer.sqVLandArray[i] = fastsqrt(velocityContainer.sqVLandArray[i]);
			velocityContainer.sqVLandArray[i] = INVALID_VALUE;
		}
	}
/* bestimme die maximale erlaubte Beschleunigung, die durch dprdFlareAcceleration(...) berechnet wird */
	diagFF(dprdFlareAcceleration(&velocityContainer, dynamicParameters, currentVector, deltaT, maxAcceleration, &tmpEnvironment, &velConstraintIndex));
	if (tmpEnvironment != invalid)
	{
		dynamicParametersSet = dprdGetDynamicSetPtr(dynamicParameters, tmpEnvironment); /*\spec SW_MS_Innodrive2_Forecast_351*/
		valid = valid;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		dynamicParametersSet = dprdGetDynamicSetPtr(dynamicParameters, country);
		valid = false;
	}

	/* begrenze die Maximale Beschleunigung unter ber�cksichtigung des maximalen Rucks */
	diagFF(dynamicParametersSet);
	maxAccelerationJerk = dynamicParametersSet->maxLongJerk*deltaT + currentVector->longAcceleration;
	*maxAcceleration = min(maxAccelerationJerk, *maxAcceleration);

	/*\spec SW_MS_Innodrive2_Forecast_354*/
	if (*maxAcceleration > dynamicParametersSet->maxLongAcceleration)
	{
		*maxAcceleration = dynamicParametersSet->maxLongAcceleration;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		*maxAcceleration = *maxAcceleration;
	}

	/*\spec SW_MS_Innodrive2_Forecast_354*/
	if (*maxAcceleration < dynamicParametersSet->minLongAcceleration)
	{
		if (velConstraintIndex >= constraintSet->offset.curvatureLimit && velConstraintIndex < constraintSet->offset.curvatureLimit + constraintSet->count.curvatureLimit)
		{
			*maxAcceleration = max(*maxAcceleration, dynamicParametersSet->criticalMinAcceleration);
		}
		else
		{
			*maxAcceleration = dynamicParametersSet->minLongAcceleration;
		}
	}
	else
	{ /*konstante Laufzeit realisieren*/
		*maxAcceleration = *maxAcceleration;
	}


	/*\spec SW_MS_Innodrive2_Forecast_356*/
	nextVector.velocity = currentVector->velocity + 0.5f * (currentVector->longAcceleration + *maxAcceleration) * deltaT;
	nextVector.velocity = max(nextVector.velocity, 0.0f);
	nextVector.position = currentVector->position + currentVector->velocity * deltaT + (currentVector->longAcceleration / 3.0f + *maxAcceleration / 6.0f) * deltaT * deltaT;

	/* berechne Radleistung an der gesch�tzten zuk�nftlichen Position */
	validMaxWheelPower = prtGetSlopeAtPosition(pathRouterMemory, nextVector.position, &slope) && validMaxWheelPower;
	validMaxWheelPower = prtGetCurvatureAtPosition(pathRouterMemory, nextVector.position, &curvature) && validMaxWheelPower;

	tmpMaxAccel = *maxAcceleration;
	validMaxWheelPower = vmdlGetWheelPower(vehicleModel, nextVector.velocity, *maxAcceleration, curvature, slope, 0.0f, &wheelPower) && validMaxWheelPower;
	validMaxWheelPower = vmdlGetMaxAccelerationForWheelPower(	vehicleModel,
																dynamicParametersSet->maxWheelPower,
																curvature,
																slope,
																0.0f,
																currentVector->velocity,
																currentVector->longAcceleration,
																deltaT,
																&tmpMaxAccel) && validMaxWheelPower;
	if (dynamicParametersSet->maxWheelPower < wheelPower && wheelPower < INVALID_VALUE && validMaxWheelPower)
	{
		*maxAcceleration = tmpMaxAccel;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		*maxAcceleration = *maxAcceleration;
	}

	return valid;
}


static bool_T	dprdCalcLanding(	IN const	dynamicParameters_T		*dynamicParameters,
									IN const	predictionState_T		*currentVector,
									IN const	constraint_T			*constraint,
									IN const	real32_T				 deltaT,
									OUT			dobsEnvironment_T		*environment,
									OUT			real32_T				*sqLandingVelocity,
									OUT			dprdLandingProfile_T	*landingProfile)
{
	real32_T s_jerk;
	real32_T t_jerk;
	real32_T sqVelocity = constraint->velocity*constraint->velocity;
	real32_T v_delta;

	const dynamicParameterSet_T *tmpDynamicParameterSet;
	
	if (constraint->environment != invalid)
	{
		*environment = constraint->environment;
	}
	else
	{ /*Erzwinge einer g�ltige Umgebung damit die konstante Laufzeit realisiert werden kann*/
		*environment = city;
	}

	tmpDynamicParameterSet = dprdGetDynamicSetPtr(dynamicParameters, *environment);
	diagFF(tmpDynamicParameterSet != NULL);

	/* Zwischenergebnisse f�r den Fall, wenn sich das Fahrzeug vor dem Beginn des G�ltigkeitsbereich s_limit */
	/* Wenn die Berechnungen hier ausgef�hrt werden kann die konsante Laufzeit besser gew�hrt werden */
	/* s_jerk ist der Ruckunsch�rfebereich. s_land ist die Strecke bis zu dessen Anfang.*/
	diagFF(tmpDynamicParameterSet->maxLongJerk != 0.0f);

	t_jerk = (-tmpDynamicParameterSet->minLongAcceleration) / (tmpDynamicParameterSet->maxLongJerk);
	v_delta = -tmpDynamicParameterSet->minLongAcceleration * deltaT + 0.5f * t_jerk * t_jerk * tmpDynamicParameterSet->maxLongJerk;
	s_jerk = t_jerk * (constraint->velocity + v_delta * 0.5f);
	/*Berechnungsvorschrift f�r den Ruckunsch�rfebereich sollte in jedem Funktionsaufruf durchgef�hrt, damit die konstate Laufzeit gew�hrleistet ist*/
	*sqLandingVelocity = (constraint->velocity + v_delta) * (constraint->velocity + v_delta) - 2.0f * ((constraint->begin - s_jerk) - currentVector->position) *  tmpDynamicParameterSet->minLongAcceleration;

	switch (*environment)
	{
		case country:		*landingProfile = profileLandingCountry;		break;
		case countryRadar:	*landingProfile = profileLandingCountryRadar;	break;
		case city:			*landingProfile = profileLandingCity;			break;
		case invalid:		*landingProfile = profileInvalid;				break;
		default:			diagFUnreachable();
	} /*lint !e9077*/

	diagFF(*landingProfile != profileInvalid);

	if (currentVector->position > constraint->begin - s_jerk)
	{/* Das Farhrzeug befindet sich im Ruckunsch�rfebereich oder nach dem Anfang des G�ltigkeitsbereich */
		*landingProfile = profileConstant;
		*sqLandingVelocity = sqVelocity;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		*landingProfile = *landingProfile;
		*sqLandingVelocity = *sqLandingVelocity;
	}
	
	/*Es ist m�glich, dass eine Umgebung zum berechnen erzwungen wurde, dies wird hier wieder r�ckg�ngig gemacht*/
	if (constraint->environment == invalid)
	{
		*sqLandingVelocity = INVALID_VALUE;
		*environment = constraint->environment;
		*landingProfile = profileInvalid;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		*sqLandingVelocity = *sqLandingVelocity;
		*environment = *environment;
		*landingProfile = *landingProfile;
	}

	return true;
}


static bool_T	dprdFlareAcceleration(	IN	const	constraintVelocityContainer_T	*velocityContainer,
										IN	const	dynamicParameters_T				*dynamicParameters,
										IN	const	predictionState_T				*currentVector,
										IN	const	real32_T						deltaT,
										OUT			real32_T						*acceleration,
										OUT			dobsEnvironment_T				*maxAcclerationEnvironment,
										OUT			uint8_T							*velConstraintIndex)
{
	real32_T	deltaV;
	real32_T	deltaA;
	real32_T	tCont;
	real32_T	tFloor;
	real32_T	jerk;
	real32_T	contTimeSq;
	real32_T	deltaVeff;
	real32_T	jerk_x_deltaT;
	real32_T	tmpAcceleration;
	uint8_T		i;
	const dynamicParameterSet_T *dynamicParameterSet = NULL;

	*acceleration = INVALID_VALUE;
	*maxAcclerationEnvironment = invalid;
	*velConstraintIndex = dprdCONSTRAINT_COUNT;

	for (i = 0; i < (uint8_T)profileInvalid; i++)
	{
		real32_T maxLongJerk = INVALID_VALUE;
		real32_T minLongJerk = INVALID_VALUE;
		dynamicParameterSet = dprdGetDynamicSetPtr(dynamicParameters, velocityContainer->environmentArray[i]);
		if (NULL != dynamicParameterSet)
		{
			maxLongJerk = dynamicParameterSet->maxLongJerk;
			minLongJerk = dynamicParameterSet->minLongJerk;
		}
		else
		{
			maxLongJerk = INVALID_VALUE;
			minLongJerk = INVALID_VALUE;
		}

		/* Berechnung Abweichung Ist-Zustand und Wunschzustand */
		deltaV = velocityContainer->sqVLandArray[i] - currentVector->velocity;
		deltaA = velocityContainer->accelerationArray[i] - currentVector->longAcceleration;

		/* Bestimmung einer effektiven Geschwindigkeitsdifferenz */
		deltaVeff = (deltaA * deltaT) + (2.0f * deltaV);

		/* Bestimmung der relevanten Ruck-Parameter */
		jerk = (deltaVeff < 0.0f ? maxLongJerk : minLongJerk); /*\spec SW_MS_Innodrive2_Forecast_355*/
		jerk_x_deltaT = jerk * deltaT;

		/* Quadrat der Zeit, in der bei kontinuierlicher Rechnung das Limit erreich wird. */
		diagFF(jerk_x_deltaT * deltaT != 0.0f);
		contTimeSq = max(0.25f - (deltaVeff / (jerk_x_deltaT * deltaT)), 0.0f);

		/* Berechnen der Zeit, die im kontinuierlichen Fall f�r das Erreichen der Limits notwendig ist. */
		tCont = fastsqrt(contTimeSq) - 0.5f;

		tFloor = floorf(tCont) * deltaT;
		tFloor = max(0.0f, tFloor);

		diagFF((tFloor + deltaT) != 0.0f);
		tmpAcceleration = velocityContainer->accelerationArray[i] + 0.5f * ((deltaVeff) / (tFloor + deltaT) - (jerk * tFloor));
		/* speichere minimale Beschleuning */

		if (dynamicParameterSet && tmpAcceleration < *acceleration)
		{
			*acceleration = tmpAcceleration;
			*maxAcclerationEnvironment = velocityContainer->environmentArray[i];
			*velConstraintIndex = velocityContainer->constraintIndexArray[i];
		}
		else
		{ /*konstante Laufzeit realisieren*/
			*acceleration = *acceleration;
			*maxAcclerationEnvironment = *maxAcclerationEnvironment;
			*velConstraintIndex = *velConstraintIndex;
		}
	}


	return true;
}


bool_T		dprdGetTrajectory(	IN const	vehicleModel_T		*vehicleModel,
								IN const	pathRouterMemory_T	*pathRouterMemory,
								IN const	parameterSetCtrl_T	*parameterSet,
								IN const	real32_T			dynamicEventPosition,
								IN const	dprdWindowIndex_T	dprdWindowIndex,
								IN const	constraintSet_T		*constraintSet,
								IN const	vmState_T			*startVector,
								IN const	environmentList_T	*environmentList,
								INOUT		dynamicParameters_T	*dynamicParameters,
								OUT			trajectory_T		*trajectory)
{
	/*Berechne nacheinander die Zeitschritte (calcTimestep) und H�nge sie an die Trajektorie an.*/
	uint8_T				i;
	predictionState_T	nextVector;
	predictionState_T	currentVector;
	bool_T				processedDynamicEvent = false;
	bool_T				validStep = false;

	/* �berpr�fen der Parameter auf g�ltige Wertebereiche */
	diagFF(parameterSet->driverPredictor.timestepCount <= (uint8_T)dprdTRAJECTORY_COUNT);

	currentVector.velocity = INVALID_VALUE;
	currentVector.position = INVALID_VALUE;
	currentVector.longAcceleration = INVALID_VALUE;

	if (dprdWindowIndex == shortTermWindow)
	{ /*\spec SW_MS_Innodrive2_Forecast_341*/
		currentVector.velocity			= startVector->velocity;
		currentVector.position			= startVector->position;
		currentVector.longAcceleration	= startVector->acceleration;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		currentVector.velocity = currentVector.velocity;
		currentVector.position = currentVector.position;
		currentVector.longAcceleration = currentVector.longAcceleration;
	}

	if (dprdWindowIndex > shortTermWindow &&
		dprdWindowIndex <= longTermWindow &&
		trajectory->count == parameterSet->driverPredictor.windowStart[dprdWindowIndex])
	{
		diagFF(trajectory->count > 0u);
		currentVector.velocity = trajectory->vector[trajectory->count - 1u].velocity;
		currentVector.position = trajectory->vector[trajectory->count - 1u].position;
		currentVector.longAcceleration = trajectory->vector[trajectory->count - 1u].longAcceleration;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		currentVector.velocity = currentVector.velocity;
		currentVector.position = currentVector.position;
		currentVector.longAcceleration = currentVector.longAcceleration;
	}

	currentVector.latAcceleration	= INVALID_VALUE;
	currentVector.wheelPower		= INVALID_VALUE;

	diagFF(dprdWindowIndex >= shortTermWindow && dprdWindowIndex < invalidWindowIndex);

	/*\spec SW_MS_Innodrive2_Forecast_388*/
	for (i = parameterSet->driverPredictor.windowStart[dprdWindowIndex]; i < parameterSet->driverPredictor.windowEnd[dprdWindowIndex]; i++)
	{
		if (currentVector.position >= dynamicEventPosition && !processedDynamicEvent)
		{ /* Erfolgt im mapPath ein Fahrdynamikevent (wird durch getEnvironmentFromLimits(...) erkannt), wird eine Mindestgrenze f�r das 
			 Fahrdynamiklevel und die Dynamikparameter gesetzt. */
			/*\spec SW_MS_Innodrive2_Forecast_367*/
			diagFF(dprdDynamicParameterSetLevel(parameterSet, city, dynamicParameters));
			diagFF(dprdDynamicParameterSetLevel(parameterSet, country, dynamicParameters));
			diagFF(dprdDynamicParameterSetLevel(parameterSet, countryRadar, dynamicParameters));
			processedDynamicEvent = true;
		}
		
		validStep = dprdCalcTimestep(vehicleModel, pathRouterMemory, dynamicParameters, parameterSet, constraintSet, environmentList, &currentVector, &nextVector);
		
		if (i < parameterSet->driverPredictor.timestepCount && validStep)
		{
			nextVector.velocity = nextVector.velocity;
			diagFF(dprdAppendVector(&nextVector, trajectory));

			currentVector.velocity			= nextVector.velocity;
			currentVector.position			= nextVector.position;
			currentVector.longAcceleration	= nextVector.longAcceleration;
			currentVector.latAcceleration	= nextVector.latAcceleration;
			currentVector.wheelPower		= nextVector.wheelPower;
		}
		else
		{ /*damit die konstante Laufzeit umgesetzt werden kann muss einer der Werte auf INVALID_VALUE gesetzt werden*/
			nextVector.velocity = INVALID_VALUE;
			diagFF(dprdAppendVector(&nextVector, trajectory));

			currentVector.velocity			= INVALID_VALUE;
			currentVector.position			= INVALID_VALUE;
			currentVector.longAcceleration	= INVALID_VALUE;
			currentVector.latAcceleration	= INVALID_VALUE;
			currentVector.wheelPower		= INVALID_VALUE;
		}
	}

	return true;
}


#ifndef INNODRIVE_ZFAS_SWC_BUILD
#include "control/driverPredictor/dprdDebug.h"

#pragma warning(disable: 4047)
ICC_API void dprdDebugGet_dprdCalcTimestep(dprdCalcTimestepFuncPtr_T *FunctionPtr)
{
	*FunctionPtr = dprdCalcTimestep;
}

ICC_API void dprdDebugGet_dprdEvalConstraints(dprdEvalConstraintsFuncPtr_T *FunctionPtr)
{
	*FunctionPtr = dprdEvalConstraints;
}

ICC_API void dprdDebugGet_setMinVelocity(setMinVelocityFuncPtr_T *FunctionPtr)
{
	*FunctionPtr = setMinVelocity;
}
#endif
