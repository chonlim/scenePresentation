#ifndef guard_dprdDebug_h
#define guard_dprdDebug_h

#include "control/driverPredictor/driverpredictor_private.h"
#include "common/vehicleModel/vehicleModel_interface.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"


#include "control/controlTask/iccExports.h"

typedef bool_T	(*dprdCalcTimestepFuncPtr_T)(	IN const	vehicleModel_T		*vehicleModel,
												IN const	pathRouterMemory_T	*pathRouterMemory,
												IN const	dynamicParameters_T	*dynamicParameters,
												IN const	parameterSetCtrl_T	*parameterSet,
												IN const	constraintSet_T		*constraintSet,
												IN const	environmentList_T   *environmentList,
												IN const	predictionState_T	*currentVector,
												OUT			predictionState_T	*nextVector);

ICC_API void dprdDebugGet_dprdCalcTimestep(dprdCalcTimestepFuncPtr_T *FunctionPtr);


typedef bool_T	(*dprdEvalConstraintsFuncPtr_T)(IN const	dynamicParameters_T	*dynamicParameters,	
												IN const	parameterSetCtrl_T	*parameterSet,		
												IN const	constraintSet_T		*constraintSet,		
												IN const	predictionState_T	*currentVector,		
												IN const	vehicleModel_T		*vehicleModel,		
												IN const	pathRouterMemory_T	*pathRouterMemory,	
												OUT			real32_T			*maxAcceleration);

ICC_API void dprdDebugGet_dprdEvalConstraints(dprdEvalConstraintsFuncPtr_T *FunctionPtr);


typedef struct _constraintVelocityContainer constraintVelocityContainer_T;
typedef bool_T (*setMinVelocityFuncPtr_T)(	IN const	dynamicParameters_T				*dynamicParameters,
											IN const	dobsEnvironment_T				environment,
											IN const	real32_T						sqLandingVelocity,
											IN const	uint8_T							constraintIndex,
											INOUT		constraintVelocityContainer_T	*velocityContainer,
											INOUT		dprdLandingProfile_T			*landingProfile);

ICC_API void dprdDebugGet_setMinVelocity(setMinVelocityFuncPtr_T *FunctionPtr);
#endif /*guard_dprdDebug_h*/
