#ifndef guard_driverpredictor_interface_h
#define guard_driverpredictor_interface_h

#include "base.h"
#include "control/driverObserver/driverObserver_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/parameterSet/parameterSetCtrl_private.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define dprdBIN_COUNT 9




typedef enum _dprdState {
	dprdStateCalcEnvironment = 0,
	dprdStateCalcTrajectory = 1,
	dprdStateInvalid = 2
} dprdState_T;

typedef enum _dprdWindowIndex {
	shortTermWindow = 0,
	midTermWindow = 1,
	longTermWindow = 2,
	invalidWindowIndex = 3
} dprdWindowIndex_T;

typedef struct _driverPredictionWindow driverPredictionWindow_T;
typedef struct _debugDriverPrediction debugDriverPrediction_T;
typedef struct _driverPrediction driverPrediction_T;
typedef struct _driverPredictorMemory driverPredictorMemory_T;


typedef struct _dynamicParameterSet {
	real32_T maxLongAcceleration;        /**< maximale Beschleunigung (positiv)[m/s^2] */
	real32_T minLongAcceleration;        /**< minimale Beschleunigung (negativ)[m/s^2] */
	real32_T criticalMinAcceleration;    /**< Minimale Beschleunigung (negativ) für kritische Einschränkungen (Kurven)[m/s^2] */
	real32_T maxLatAcceleration;         /**< maximale Querbeschleunigung (positiv)[m/s^2] */
	real32_T maxLongJerk;                /**< Maximaler Beschleunigungsruck (positiv)[m/s^3] */
	real32_T minLongJerk;                /**< Minimaler Bremsruck (negativ)[m/s^3] */
	real32_T maxWheelPower;              /**< Maximale Radleistung[W] */
	real32_T maxVelocity;                /**< maximale Geschwindigkeit (Freifahrtgeschwindigkeit)[m/s] */
	real32_T offsetVelocity;             /**< Geschwindigkeitsoffset (positiv oder negativ)[m/s] */
} dynamicParameterSet_T;                 /**< Groesse der Struktur = 36 Bytes */


/*lint -restore */

#endif
