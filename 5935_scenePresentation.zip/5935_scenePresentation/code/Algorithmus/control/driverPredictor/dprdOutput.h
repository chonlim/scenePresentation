#ifndef guard_dprdOutput_h
#define guard_dprdOutput_h

#include "control/control.h"
#include "control/parameterSet/ParameterSetCtrl_interface.h"
#include "driverPredictor_private.h"



/**\brief Berechnet aus der �bergebenen Trajektorie die Auftrittswahrscheinlichkeiten f�r L�ng- und Querbeschleunigung, Radleistung sowie die Geschwindikeit.

\spec SW_MS_Innodrive2_Forecast_150
\spec SW_MS_Innodrive2_Forecast_339
\spec SW_MS_Innodrive2_Forecast_338
\spec SW_MS_Innodrive2_Forecast_387

\ingroup driverPredictor_output
*/
bool_T	dprdGetOutputContainer(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
								IN const	trajectory_T		*trajectory,			/**<Berechnete Trajektoriere*/
								IN const	dprdWindowIndex_T	dprdWindowIndex,		/**<Gibt an welches Zeitfenster berechnet werden soll (siehe dprdWindowIndex_T).*/
								OUT			driverPrediction_T	*driverPrediction		/**<Ausgangsstruktur des driverPredictors*/
								);




#endif
