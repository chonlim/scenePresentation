#ifndef guard_dprdConstraintsStatic_h
#define guard_dprdConstraintsStatic_h

#include "control/control.h"
#include "control/driverPredictor/driverpredictor_private.h"
#include "control/parameterSet/ParameterSetCtrl_interface.h"

#define dprdMAX_REPLACE_CURVATURES 4
#define dprdMAX_CURVATURES (dprdMAXBCURVATURE_COUNT + dprdMAX_REPLACE_CURVATURES*dprdMAXBRANCHANGLE_COUNT)

typedef struct _dprdPosCurv
{
	real32_T	position;
	real32_T	curvature;
}dprdPosCurv_T;

typedef struct _dprdReplaceCurvature
{
	real32_T	position;
	real32_T	curvature;
	real32_T	curvatureOffset;
}dprdReplaceCurvature_T;


typedef struct _dprdReplaceCurvatures
{
	dprdReplaceCurvature_T	curvatures[dprdMAXBRANCHANGLE_COUNT][dprdMAX_REPLACE_CURVATURES];
	uint8_T					nextIndex[dprdMAXBRANCHANGLE_COUNT];
	uint8_T					count;
}dprdReplaceCurvatures_T;

typedef struct _dprdCurvaturesStorage
{
	dprdPosCurv_T curvatures[dprdMAX_CURVATURES];
	uint8_T count;
}dprdCurvaturesStorage_T;



/**\brief Setzt die Anfangspositionen der Geschwindigkeitsbegrenzungen.

\spec SW_MS_Innodrive2_Forecast_371
\spec SW_MS_Innodrive2_Forecast_373

\ingroup driverPredictor_constraints
*/
static bool_T dprdGetSpeedLimitBegin(	IN const	parameterSetCtrl_T	*parameterSet,		/**<Globale Parameter*/
										IN const	mapPath_T			*mapPath,			/**<Kartendaten*/
										IN const	driverState_T		*driverState,		/**<Private Struktur des driverObserver*/
										INOUT		constraintList_T	*constraintList		/**<Enth�lt alle Geschwindigkeitseinschr�nkungen und den Vorausschauhorizont.*/
										);

/**\brief Setzt die Endpositionen der Geschwindigkeitsbegrenzungen.

\spec SW_MS_Innodrive2_Forecast_359
\spec SW_MS_Innodrive2_Forecast_347
\spec SW_MS_Innodrive2_Forecast_373

\ingroup driverPredictor_constraints
*/
static bool_T dprdGetSpeedLimitEnd(	IN const	uint8_T				initialListCount,		/**<Wiederspiegel die Anfangsgr��e von constraintList->count bevor Geschwindigkeitsbegrenzungen in die Liste eingetragen werden.*/
									IN const	environmentList_T	*environmentList,		/**<Liste der Umgebungen*/
									IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
									IN const	dynamicParameters_T	*dynamicParameters,		/**<Entsprechende Fahrparameter zur Umgebung.*/
									INOUT		constraintList_T	*constraintList			/**<Enth�lt alle Geschwindigkeitseinschr�nkungen und den Vorausschauhorizont.*/
									);

/**\brief Setzt die Anfangspositionen der Kurvenconstraints.

\spec SW_MS_Innodrive2_Forecast_377

\ingroup driverPredictor_constraints
*/
static bool_T getCurvatureBegins(	IN const	mapPath_T				*mapPath,				/**<Kartendaten*/
									IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten.*/
									INOUT		dprdReplaceCurvatures_T	*replaceCurvatures,		/**<Liste mit den Kurvenst�tzstellen.*/
									OUT 		dprdCurvaturesStorage_T	*curvatures				/**<Liste mit mapPath-Kurven und den approximierten St�tzstellen, die nach aufsteigenden Position angeordnet w�ren.*/
									);

/**\brief Berechnet die Positionen der St�tzstellen und Offsets, die einen Abzweigwinkel approximieren.

\spec SW_MS_Innodrive2_Forecast_378
\spec SW_MS_Innodrive2_Forecast_382
\spec SW_MS_Innodrive2_Forecast_380

\ingroup driverPredictor_constraints
*/
static bool_T dprdCalcApproxBranch(	IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
									IN const	mapPath_T				*mapPath,					/**<Kartendaten*/
									IN const	parameterSetCtrl_T		*parameterSet,				/**<Globale Parameter*/
									IN const	real32_T				branchAnglePosition,		/**<Abzweigwinkel Position*/
									IN const	real32_T				angle,						/**<Abzweigwinkelwert in Grad*/
									IN const	bool_T					valid,						/**<F�r einen g�ltigen Abzweigwinkel auf true setzen, ansonsten auf false damit die konstante Laufzeit realisiert werden kann.*/
									INOUT		dprdReplaceCurvatures_T	*replaceCurvatures			/**<Berechnete Liste mit Kurvenst�tzstellen, die einen Abzweigwinkel approximieren*/
									);

/**\brief Addiert die zuvor berechneten St�tzstellenoffsets auf die Kurvenwerte in der `curvatures` Liste.

\spec SW_MS_Innodrive2_Forecast_381

\ingroup driverPredictor_constraints
*/
static bool_T addCurvatureOffset(	IN const	parameterSetCtrl_T		*parameterSet,				/**<Globale Parameter*/
									IN const	dprdReplaceCurvatures_T	*replaceCurvatures,			/**<Berechnete St�tzstellen mit Positions- und Offset-Werten.*/
									INOUT 		dprdCurvaturesStorage_T	*curvatures					/**<Liste mit allen mapPath-Kurven und St�tzstellen*/
									);

/**\brief F�gt die mapPath- und St�tzstellenkurven in die Constraint Liste ein.

\spec SW_MS_Innodrive2_Forecast_383

\ingroup driverPredictor_constraints
*/
static bool_T insertCurvatures(	IN const	dprdCurvaturesStorage_T *curvatures,			/**<Liste mit allen mapPath-Kurven und St�tzstellen*/
								IN const	environmentList_T		*environmentList,		/**<Liste der Umgebungen*/
								IN const	dynamicParameters_T		*dynamicParameters,		/**<Entsprechende Fahrparameter zur Umgebung*/
								INOUT		constraintList_T		*constraintList,		/**<Constraintliste in welche die Kurven aus dem mapPath und die St�tzstellen eingef�gt werden*/
								OUT			real32_T				*horizonEnd				/**<Ende des Vorausschauhorizonts*/
								);


/**\brief H�ngt eine Einschr�nkung an die Liste an. 

R�ckgabewert ist `false` wenn Au�erhalb der Arraygrenzen geschrieben wird oder eine g�ltige Einschr�nkung �berschrieben wird.

\ingroup driverPredictor_constraints
*/
static bool_T	dprdAppendConstraint(	IN const	constraint_T		*constraint,		/**<Eine konstante Geschwindigkeitseinschr�nkung*/
										INOUT		constraintList_T	*constraintList		/**<Liste der Geschwindigkeitseinschr�nkungen*/
										);


/**\brief Stellt die Liste der statischen Einschr�nkungen durch Kurvenkr�mmungen auf dem Vorausschauhorizont zusammen.

R�ckgabewert ist `true` wenn die Liste mit den Kurvernkr�mmungen erstellen werden konnte, ansonsten `false`.

\spec SW_MS_Innodrive2_Forecast_378

\ingroup driverPredictor_constraints
*/
static bool_T	dprdGetCurvatureList(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	mapPath_T			*mapPath,				/**<Kartendaten*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	environmentList_T	*environmentList,		/**<Liste der Umgebungen*/
										IN const	dynamicParameters_T	*dynamicParameters,		/**<Entsprechende Fahrparameter zur Umgebung*/
										INOUT		constraintList_T	*constraintList,		/**<Liste der Geschwindigkeitseinschr�nkungen*/
										OUT			real32_T			*horizonEnd				/**<Ende des Vorausschauhorizonts*/
										);


/**\brief Stellt die Liste der statischen Einschr�nkungen durch Onlinelimits auf dem Vorausschauhorizont zusammen.

\spec SW_MS_Innodrive2_Forecast_348
\spec SW_MS_Innodrive2_Forecast_374

\ingroup driverPredictor_constraints
*/
static bool_T	dprdGetOnlineLimitList(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	vmState_T			*currentVMSate,			/**<aktueller Bewegungszustand*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	environmentList_T	*environmentList,		/**<Liste der Umgebungen*/
										INOUT		constraintList_T	*constraintList			/**<Liste der Geschwindigkeitseinschr�nkungen*/
										);


/**\brief Stellt die Liste der statischen Einschr�nkungen durch Tempolimits auf dem Vorausschauhorizont zusammen.

R�ckgabewert ist `true` wenn die Liste mit den Geschwindigkeitsbegrenzungen erstellt werden konnte, ansonsten `false`.

\spec SW_MS_Innodrive2_Forecast_369

\ingroup driverPredictor_constraints
*/
static bool_T	dprdGetSpeedLimitList(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
										IN const	driverState_T		*driverState,			/**<Private Struktur des driverObserver*/
										IN const	mapPath_T			*mapPath,				/**<Kartendaten*/
										IN const	environmentList_T	*environmentList,		/**< Liste der Umgebungen*/
										IN const	dynamicParameters_T	*dynamicParameters,		/**<Entsprechende Fahrparameter zur Umgebung*/
										IN const	real32_T			 vehiclePosition,		/**<Fahrzeugposition*/
										INOUT		constraintList_T	*constraintList,		/**<Liste der Geschwindigkeitseinschr�nkungen*/
										OUT			real32_T			*horizonEnd				/**<Ende des Vorausschauhorizonts*/
										);
#endif
