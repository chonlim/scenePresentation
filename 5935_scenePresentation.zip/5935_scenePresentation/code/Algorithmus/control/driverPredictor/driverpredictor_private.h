#ifndef guard_driverpredictor_private_h
#define guard_driverpredictor_private_h

#include "control/driverPredictor/driverpredictor_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define dprdENVIRONMENT_COUNT 8
#define dprdMAXBRANCHANGLE_COUNT 4
#define dprdMAXBCURVATURE_COUNT 25
#define dprdSPEEDLIMITCOUNT 10           /**< Maximale Anzahl der Geschwindigkeitsbegrenzungen, die verarbeitet werden können */
#define dprdBUILTUPAREACOUNT 16          /**< Maximale Anzahl der Umgebungen, die verarbeitet werden können */
#define dprdDYNAMICEVENTCOUNT 10         /**< Maximale Azahl von dynamischen Events, die verarbeitet werden können */
#define dprdONLINELIMITCOUNT 10          /**< Maximale Azahl von Onlineverkehrsbeschärnkungen, die verarbeitet werden können */

typedef enum _dprdConstraintClass {
	classSpeedLimit = 0,
	classOnlineLimit = 1,
	classCurvatureLimit = 2,
	classInvalid = 3
} dprdConstraintClass_T;

typedef enum _dprdBinCategory {
	binCategoryVelocity = 0,
	binCategoryLongAcceleration = 1,
	binCategoryLatAcceleration = 2,
	binCategoryWheelPower = 3,
	binCategoryStreetClass = 4,
	binCategoryInvalid = 5
} dprdBinCategory_T;

typedef enum _dprdLandingProfile {
	profileConstant = 0,
	profileLandingCity = 1,
	profileLandingCountryRadar = 2,
	profileLandingCountry = 3,
	profileInvalid = 4
} dprdLandingProfile_T;



typedef struct _environment {
	real32_T begin;                      /**< Anfang der Umgebung[m] */
	dobsEnvironment_T environment;       /**< Art der Umgebung */
} environment_T;                         /**< Groesse der Struktur = 8 Bytes */

typedef struct _environmentList {
	environment_T environment[dprdENVIRONMENT_COUNT]; /**< Einzelne Umgebungen. */
	uint8_T count;                       /**< Anzahl der gespeicherten Umgebungen */
	real32_T horizon;                    /**< Letzte Position, die nicht in die Liste eingefügt werden konnte.[m] */
} environmentList_T;                     /**< Liste der Geschwindigkeitseinschränkungen, Groesse der Struktur = 72 Bytes */

typedef struct _dynamicParameters {
	dynamicParameterSet_T city;          /**< für  Umgebung Stadt */
	dynamicParameterSet_T countryRadar;  /**< für  Umgebung Land+Radar */
	dynamicParameterSet_T country;       /**< für  Umgebung Land */
} dynamicParameters_T;                   /**< Groesse der Struktur = 108 Bytes */

typedef struct _constraintOffset {
	uint8_T speedLimit;
	uint8_T onlineLimit;
	uint8_T curvatureLimit;
} constraintOffset_T;                    /**< Groesse der Struktur = 3 Bytes */

typedef struct _constraint {
	dprdConstraintClass_T type;          /**< Art der Einschränkung (Tempolimit, Onlinelimit, Kurvenlimit) */
	dobsEnvironment_T environment;       /**< Anhand dieser Umgebung wird der gültige Fahrdynamikparametersatz ausgewählt */
	real32_T begin;                      /**< Anfangsposition der Einschränkung[m] */
	real32_T end;                        /**< Ende der Einschränkung[m] */
	real32_T velocity;                   /**< Geschwindigkeitsobergrenze der Einschränkung[m/s] */
} constraint_T;                          /**< Eine konstante Geschwindigkeitseinschränkung, Groesse der Struktur = 20 Bytes */

typedef struct _constraintList {
	constraint_T constraint[dprdCONSTRAINT_COUNT]; /**< Einzelne Einschränkung. Klasse wird durch constraint.class angegeben */
	uint8_T count;                       /**< Anzahl der gespeicherten Einschränkungen */
} constraintList_T;                      /**< Liste der Geschwindigkeitseinschränkungen, Groesse der Struktur = 4 Bytes */

typedef struct _constraintSet {
	constraintList_T constraintList;     /**< Liste der Geschwindigkeitseinschränkungen */
	constraintOffset_T offset;           /**< Anfangsindizes der Constraints für jede Klasse */
	constraintOffset_T count;            /**< Anzahlen der Constraints für jede Klasse */
	real32_T horizonEnd;                 /**< Ende des Vorausschauhorizonts aufgrund beschränkung der Constraint-Anzahl. */
} constraintSet_T;                       /**< Alle Geschwindigkeitseinschränkungen und der Vorausschauhorizont, Groesse der Struktur = 16 Bytes */

typedef struct _predictionState {
	real32_T position;                   /**< Position[m] */
	real32_T velocity;                   /**< Geschwindigkeit[m/s] */
	real32_T wheelPower;                 /**< Radleistung[W] */
	real32_T longAcceleration;           /**< Längsbeschleunigung[m/(s^2)] */
	real32_T latAcceleration;            /**< Querbeschleunigung[m/(s^2)] */
	prtStreetClassValues_T streetClass;  /**< Straßenklasse */
} predictionState_T;                     /**< Beinhaltet alle berechneten Daten in einem berechneten Zeitschritt, Groesse der Struktur = 24 Bytes */

typedef struct _trajectory {
	predictionState_T vector[dprdTRAJECTORY_COUNT]; /**< Trajectorie aus (Position, Geschwindigkeit, Beschleunigung)-Vektoren */
	uint8_T count;
} trajectory_T;                          /**< Groesse der Struktur = 4 Bytes */

struct _driverPredictionWindow {
	uint8_T velocity[dprdBIN_COUNT];     /**< Geschwindigkeit[m/s] */
	uint8_T longAcceleration[dprdBIN_COUNT]; /**< Längsbeschleunigung[m/s^2] */
	uint8_T absLatAcceleration[dprdBIN_COUNT]; /**< Betrag der Querbeschleunigung[m/s^2] */
	uint8_T wheelPower[dprdBIN_COUNT];   /**< Radleistung[W] */
	uint8_T streetClass[dprdBIN_COUNT];  /**< Straßenklasse[W] */
	bool_T isValid;                      /**< Gibt an ob das Zeitfenster gültig ist */
} ;                                      /**< Ausgabe des driverPredictors, Groesse der Struktur = 46 Bytes */

struct _debugDriverPrediction {
	environmentList_T environmentList;   /**< Liste der Geschwindigkeitseinschränkungen */
	trajectory_T trajectory;             /**< Liste der Geschwindigkeitseinschränkungen */
} ;                                      /**< Debug Ausgabe des driverPredictors, Groesse der Struktur = 76 Bytes */

struct _driverPrediction {
	driverPredictionWindow_T shortTermWindow; /**< ShortTerm Zeitfenster */
	driverPredictionWindow_T midTermWindow; /**< MidTerm Zeitfenster */
	driverPredictionWindow_T longTermWindow; /**< LongTerm Zeitfenster */
	bool_T toggleBit;                    /**< Bei Veränderung von einem zum nächsten Rechentakt signalisiert dieses Bit, dass dem driverPredictor ausreichend Daten vorliegen um die benötigten Berechnungen durchzuführen. */
	bool_T isValidPrediction;            /**< True wenn die berechnete Prediktion gültig ist, ansonsten false. */
} ;                                      /**< Ausgabe des driverPredictors, Groesse der Struktur = 140 Bytes */

struct _driverPredictorMemory {
	real32_T dynamicEventPosition;       /**< Position eines dynamischen Events[m] */
	constraintSet_T constraintSet;       /**< Constraint Liste */
	driverPrediction_T lastValidDriverPrediction; /**< Temporäre Struktur zum speichern der driverPredictor Ausgaben über mehrere Zeitschritte */
	driverPrediction_T tempDriverPrediction; /**< Temporäre Struktur zum speichern der driverPredictor Ausgaben über mehrere Zeitschritte */
	dynamicParameters_T dynamicParameters; /**< Struktur mit den dynamischen Parametern */
	trajectory_T trajectory;             /**< Berechnete Trajektoriere über mehrere Zeitschritte */
	vmState_T startVector;               /**< Anfangszustand zum berechnen des nächsten Trajektorienwertes */
	dprdState_T state;                   /**< Zustand des driverPredictors */
	dprdWindowIndex_T dprdWindowIndex;   /**< Speichert welches Zeitfenster als nächstes Berechnet werden soll */
	bool_T toggleBit;                    /**< Bei Veränderung von einem zum nächsten Rechentakt signalisiert dieses Bit, dass dem driverPredictor ausreichend Daten vorliegen um die benötigten Berechnungen durchzuführen. */
	bool_T hasValidPrediction;           /**< true wenn der driverPredictor gültige Ausgangsdaten bereistellen kann, anonsten false */
	debugDriverPrediction_T debugDriverPrediction; /**< Debug Signale des driverPredictors */
} ;                                      /**< Groesse der Struktur = 512 Bytes */


/*lint -restore */

#endif
