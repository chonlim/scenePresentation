#include "control/driverPredictor/dprdOutput.h"
#include "control/driverPredictor/dprdParameters.h"
#include "control/driverPredictor/dprdOutputStatic.h"
#include "control/driverPredictor/driverpredictor_private.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdOutput)


static bool_T countContainerBin(IN const	real32_T			containerRanges[dprdBIN_COUNT],
								IN const	real32_T			value,
								IN const	bool_T				valid,
								OUT			uint8_T				binCount[dprdBIN_COUNT])
{
	uint8_T i;
	uint8_T binIndex = dprdBIN_COUNT;

	/* suche passenden Container */
	for (i = 1; i < (uint8_T)dprdMAXRANGECOUNT; i++)
	{
		/*\spec SW_MS_Innodrive2_Forecast_146*/
		/*\spec SW_MS_Innodrive2_Forecast_147*/
		/*\spec SW_MS_Innodrive2_Forecast_148*/
		/*\spec SW_MS_Innodrive2_Forecast_149*/
		/*\spec SW_MS_Innodrive2_Forecast_385*/
		if (containerRanges[i - 1u] <= value && value < containerRanges[i])
		{
			binIndex = i;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			binIndex = binIndex;
		}
	}
	
	if (binIndex == (uint8_T)dprdBIN_COUNT && value < containerRanges[0])
	{
		/*\spec SW_MS_Innodrive2_Forecast_146*/
		/*\spec SW_MS_Innodrive2_Forecast_147*/
		/*\spec SW_MS_Innodrive2_Forecast_148*/
		/*\spec SW_MS_Innodrive2_Forecast_149*/
		/*\spec SW_MS_Innodrive2_Forecast_385*/
		binIndex = 0;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		binIndex = binIndex;
	}

	if (binIndex == (uint8_T)dprdBIN_COUNT)
	{
		diagFF(value >= containerRanges[(uint8_T)dprdMAXRANGECOUNT - 1u]);

		/*\spec SW_MS_Innodrive2_Forecast_146*/
		/*\spec SW_MS_Innodrive2_Forecast_147*/
		/*\spec SW_MS_Innodrive2_Forecast_148*/
		/*\spec SW_MS_Innodrive2_Forecast_149*/
		/*\spec SW_MS_Innodrive2_Forecast_385*/
		binIndex = (uint8_T)(dprdBIN_COUNT - 1);
	}
	else
	{ /*konstante Laufzeit realisieren*/
		binIndex = binIndex;
	}

	/* �berpr�fe Containergrenzen */
	diagFF(binIndex != (uint8_T)dprdBIN_COUNT);


	if (value != INVALID_VALUE)
	{
		diagFF(valid);
		binCount[binIndex]++;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		binCount[0] = binCount[0];
	}

	return true;
}

static bool_T countContainerBinStreetClass(	IN const	prtStreetClassValues_T		value,
											IN const	bool_T						valid,
											OUT			uint8_T						binCount[dprdBIN_COUNT])
{
	BUILD_BUG_ON((uint8_T)prtStreetClassMisc != (uint8_T)0);
	BUILD_BUG_ON((uint8_T)prtStreetClassLocal != (uint8_T)1);
	BUILD_BUG_ON((uint8_T)prtStreetClassDistrict != (uint8_T)2);
	BUILD_BUG_ON((uint8_T)prtStreetClassCountry != (uint8_T)3);
	BUILD_BUG_ON((uint8_T)prtStreetClassFederal != (uint8_T)4);
	BUILD_BUG_ON((uint8_T)prtStreetClassHighway != (uint8_T)5);

	/*SW_MS_Innodrive2_Forecast_385*/
	if (value <= prtStreetClassHighway)
	{
		diagFF(valid);
		binCount[value]++;
	}
	else
	{
		binCount[0] = binCount[0];
	}

	return true;
}


bool_T dprdGetOutputContainer(	IN const	parameterSetCtrl_T	*parameterSet,
								IN const	trajectory_T		*trajectory,
								IN const	dprdWindowIndex_T	dprdWindowIndex,
								OUT			driverPrediction_T	*driverPrediction
)
{
	uint8_T i;
	uint8_T binCount[5][dprdBIN_COUNT];
	bool_T valid = true;

	const uint8_T minVal = parameterSet->driverPredictor.windowStart[dprdWindowIndex];
	const uint8_T maxVal = parameterSet->driverPredictor.windowEnd[dprdWindowIndex];
	const real32_T invWindowLength = 1.0f/((real32_T)maxVal - (real32_T)minVal);
	const uint8_T windowLength = maxVal - minVal;
	driverPredictionWindow_T *window = &driverPrediction->shortTermWindow; 

	switch (dprdWindowIndex)
	{
		case longTermWindow:		window = &driverPrediction->longTermWindow;	 valid = true; 	break;
		case midTermWindow:			window = &driverPrediction->midTermWindow;	 valid = true; 	break;
		case shortTermWindow:		window = &driverPrediction->shortTermWindow; valid = true; 	break;
		case invalidWindowIndex:	window = &driverPrediction->shortTermWindow; valid = false; break;
			
		default: diagFUnreachable();
	}/*lint !e9077*/

	/*Fehlerf�lle vermeiden*/
	diagFF(minVal < maxVal);
	diagFF(valid);

	memset(binCount, 0, sizeof(binCount));

	/* Einordnen der Werte in die entsprechenden Bins */
	for (i = 0; i < windowLength; i++)
	{
		const uint8_T index = minVal + i;

		if (index < trajectory->count && index < (uint8_T)dprdTRAJECTORY_COUNT)
		{
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.latAcceleration, trajectory->vector[index].latAcceleration, true, binCount[0]));
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.longAcceleration, trajectory->vector[index].longAcceleration, true, binCount[1]));
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.velocity, trajectory->vector[index].velocity, true, binCount[2]));
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.wheelPower, trajectory->vector[index].wheelPower, true, binCount[3]));
			diagFF(countContainerBinStreetClass(trajectory->vector[index].streetClass, true, binCount[4]));
		}
		else
		{ /*konstante Laufzeit realisieren*/
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.latAcceleration, INVALID_VALUE, false, binCount[0]));
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.longAcceleration, INVALID_VALUE, false, binCount[1]));
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.velocity, INVALID_VALUE, false, binCount[2]));
			diagFF(countContainerBin(parameterSet->driverPredictor.containerRange.wheelPower, INVALID_VALUE, false, binCount[3]));
			diagFF(countContainerBinStreetClass(prtStreetClassInit, false, binCount[4]));
		}
	}

	for (i = 0; i < (uint8_T)dprdBIN_COUNT; i++)
	{
		real32_T tmp;

		/*\spec SW_MS_Innodrive2_Forecast_338*/
		tmp= min(2.0f * ((real32_T)binCount[0][i]) * invWindowLength, 1.0f) * 3.0f + 0.5f;
		window->absLatAcceleration[i]	= (uint8_T)tmp;
		
		tmp = min(2.0f * ((real32_T)binCount[1][i]) * invWindowLength, 1.0f) * 3.0f + 0.5f;
		window->longAcceleration[i]		= (uint8_T)tmp;	
		
		tmp = min(2.0f * ((real32_T)binCount[2][i]) * invWindowLength, 1.0f) * 3.0f + 0.5f;
		window->velocity[i]				= (uint8_T)tmp;
		
		tmp = min(2.0f * ((real32_T)binCount[3][i]) * invWindowLength, 1.0f) * 3.0f + 0.5f;
		window->wheelPower[i]			= (uint8_T)tmp;

		/*\spec SW_MS_Innodrive2_Forecast_387*/
		if (binCount[4][i] == 0u)
		{
			window->streetClass[i] = 0;
		}

		if (0u < binCount[4][i] && binCount[4][i] < windowLength)
		{
			window->streetClass[i] = 1;
		}

		if (binCount[4][i] == windowLength)
		{
			window->streetClass[i] = 2;
		}
	}

	/*\spec SW_MS_Innodrive2_Forecast_150*/
	/*\spec SW_MS_Innodrive2_Forecast_339*/
	driverPrediction->shortTermWindow.isValid	= parameterSet->driverPredictor.windowEnd[shortTermWindow]	<= trajectory->count ? true : false;
	driverPrediction->midTermWindow.isValid		= parameterSet->driverPredictor.windowEnd[midTermWindow]	<= trajectory->count ? true : false;
	driverPrediction->longTermWindow.isValid	= parameterSet->driverPredictor.windowEnd[longTermWindow]	<= trajectory->count ? true : false;

	return valid;
}
