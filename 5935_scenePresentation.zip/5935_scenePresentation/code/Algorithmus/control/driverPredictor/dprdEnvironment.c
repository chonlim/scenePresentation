#include "control/driverPredictor/dprdEnvironment.h"
#include "control/driverPredictor/dprdParameters.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "control/pathRouter/prtTools.h"
#include "control/driverPredictor/driverpredictor_private.h"
#include "control/driverPredictor/dprdEnvironmentStatic.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "control/driverPredictor/dprdConstraints.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdEnvironment)


static bool_T getLimitIndices(	IN const	real32_T			position,
								IN const	pathRouterMemory_T	*pathRouterMemory,
								IN const	mapPath_T			*mapPath,
								INOUT		limitState_T		*limitState
								)
{
	/* suche nach die n�chsten Begrenzungen von Landschaft, Geschwindigkeit und Events */
	while (limitState->builtUpAreaCount < (uint16_T)dprdBUILTUPAREACOUNT && limitState->builtUpArea.position - position <= ROUNDING_ERROR)
	{
		(void)prtGetBuiltUpArea(pathRouterMemory, limitState->builtUpAreaCount, &limitState->builtUpArea);
		limitState->builtUpAreaCount++;
	}
	while (limitState->speedLimitCount < (uint16_T)dprdSPEEDLIMITCOUNT && limitState->speedLimit.position - position <= ROUNDING_ERROR)
	{
		(void)prtGetSpeedLimit(mapPath, limitState->speedLimitCount, &limitState->speedLimit);
		limitState->speedLimitCount++;
	}
	while (limitState->dynamicEventCount < (uint16_T)dprdDYNAMICEVENTCOUNT && limitState->dynamicEvent.position - position <= ROUNDING_ERROR)
	{
		(void)prtGetDynamicEvent(pathRouterMemory, limitState->dynamicEventCount, &limitState->dynamicEvent);
		limitState->dynamicEventCount++;
	}
	while (limitState->onlineLimitCount < (uint16_T)dprdONLINELIMITCOUNT && limitState->onlineLimit.position - position <= ROUNDING_ERROR)
	{
		(void)prtGetOnlineSpeed(pathRouterMemory, limitState->onlineLimitCount, &limitState->onlineLimit);
		limitState->onlineLimitCount++;
	}

	return true;
}


static bool_T getEnvironmentFromLimits(	IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	parameterSetCtrl_T	*parameterSet,
										IN const	limitCategory_T		limitCategory,
										IN const	environment_T		*lastValidEnvironment,
										IN const	limitState_T		*limitState,
										INOUT		bool_T				*isRadar,
										INOUT		real32_T			*dynamicEventPosition,
										OUT			environment_T		*environment
										)
{
	environment_T	tmpEnvironment;
	bool_T isBuiltUpArea = false;
	prtSpeedLimit_T maxSpeedAtPosition;
	bool_T validSpeedAtPosition;

	tmpEnvironment.begin		= INVALID_VALUE;
	tmpEnvironment.environment	= invalid;
	

	switch (limitCategory)
	{
		case limitBuiltUpArea:
			validSpeedAtPosition = prtIsBuiltUpAreaInLowLimit(parameterSet, pathRouterMemory, &limitState->builtUpArea, &isBuiltUpArea);

			if (validSpeedAtPosition) {
				tmpEnvironment.environment = isBuiltUpArea ? city : country;
				tmpEnvironment.begin = limitState->builtUpArea.position;
			} else {
				tmpEnvironment.begin = INVALID_VALUE;
				tmpEnvironment.environment = invalid;
			}
			
			/*konstante Laufzeit realisieren*/
			*isRadar = *isRadar;
			*dynamicEventPosition = *dynamicEventPosition;
		break;

		case limitSpeedLimit:
			diagFF(prtIsLimitInBuiltUpArea(parameterSet, pathRouterMemory, &limitState->speedLimit, &isBuiltUpArea));

			tmpEnvironment.environment = *isRadar ? countryRadar : country;
			tmpEnvironment.environment = isBuiltUpArea ? city : tmpEnvironment.environment;
			tmpEnvironment.begin = limitState->speedLimit.position;

			/*konstante Laufzeit realisieren*/
			*isRadar = *isRadar;
			*dynamicEventPosition = *dynamicEventPosition;
		break;

		case limitDynamicEvent:
			/*\spec SW_MS_Innodrive2_Forecast_364*/
			tmpEnvironment.environment = lastValidEnvironment->environment == countryRadar ? country : lastValidEnvironment->environment;
			tmpEnvironment.begin = limitState->dynamicEvent.position;
			
			/* Erfolgt im mapPath ein Fahrdynamikevent, wird eine Mindestgrenze f�r das Fahrdynamiklevel und die Dynamikparameter gesetzt (siehe dprdGetTrajectory(...). */
			*isRadar = false; /*\spec SW_MS_Innodrive2_Forecast_366*/
			*dynamicEventPosition = limitState->dynamicEvent.position;
		break;

		case limitOnlineLimit:
			/*Tritt eine g�ltige Einschr�nkung durch Onlineverkehr auf (siehe Ableitung statischer Einschr�nkungen) und die Umgebung ist Land, erfolgt ein Wechsel auf Land+Radar.*/
			validSpeedAtPosition = prtGetCurrentSpeedLimit(pathRouterMemory, limitState->onlineLimit.position, &maxSpeedAtPosition);

			if (isValidOnlineLimit(&maxSpeedAtPosition, parameterSet, &limitState->onlineLimit) && lastValidEnvironment->environment == country && validSpeedAtPosition)
			{ /*\spec SW_MS_Innodrive2_Forecast_363*/
				tmpEnvironment.begin = limitState->onlineLimit.position;
				tmpEnvironment.environment = countryRadar;
			}
			else
			{
				tmpEnvironment.begin = INVALID_VALUE;
				tmpEnvironment.environment = invalid;
			}

			if (!isValidOnlineLimit(&maxSpeedAtPosition, parameterSet, &limitState->onlineLimit) && lastValidEnvironment->environment == countryRadar && validSpeedAtPosition)
			{ /*\spec SW_MS_Innodrive2_Forecast_363*/
				tmpEnvironment.begin = limitState->onlineLimit.position;
				tmpEnvironment.environment = country;
			}
			else
			{ /*konstante Laufzeit realisieren*/
				tmpEnvironment.begin = tmpEnvironment.begin;
				tmpEnvironment.environment = tmpEnvironment.environment;
			}
		break;

		case limitInvalid:
			environment->begin = INVALID_VALUE;
			environment->environment = invalid;
		break;

		default:
			diagFUnreachable();
	}/*lint !e9077*/


	/*Umgebungswechsel bestimmen*/
	if (lastValidEnvironment->environment == city && tmpEnvironment.environment == country && (*isRadar))
	{ /*\spec SW_MS_Innodrive2_Forecast_362*/
		/*Ist die Umgebung Stadt und es erfolgt nach s_limit_next im mapPath ein Wechsel auf �nicht - Stadt�(Au�erorts) und Radarverkehr --> Land+Radar*/
		tmpEnvironment.environment = countryRadar;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		tmpEnvironment.environment = tmpEnvironment.environment;
	}

	if (tmpEnvironment.begin == INVALID_VALUE)
	{
		tmpEnvironment.environment = invalid;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		tmpEnvironment.environment = tmpEnvironment.environment;
	}

	*environment = tmpEnvironment;
	
	return true;
}


static real32_T getMinPos(	IN const	limitState_T		*limitState,
							IN const	real32_T			position,
							OUT			limitCategory_T		*limitCategory)
{
	real32_T minPos = 0.0f;

	if (limitState->builtUpArea.position < limitState->speedLimit.position)
	{
		minPos = limitState->builtUpArea.position;
		*limitCategory = limitBuiltUpArea;
	}
	else
	{
		minPos = limitState->speedLimit.position;
		*limitCategory = limitSpeedLimit;
	}

	if (limitState->dynamicEvent.position < minPos)
	{
		minPos = limitState->dynamicEvent.position;
		*limitCategory = limitDynamicEvent;
	}
	else
	{
		minPos = minPos;
		*limitCategory = *limitCategory;
	}

	if (limitState->onlineLimit.position < minPos)
	{
		minPos = limitState->onlineLimit.position;
		*limitCategory = limitOnlineLimit;
	}
	else
	{
		minPos = minPos;
		*limitCategory = *limitCategory;
	}

	if (minPos > position)
	{
		*limitCategory = *limitCategory;
		return minPos;
	}
	else
	{
		*limitCategory = limitInvalid;
		return INVALID_VALUE;
	}
}


static bool_T dprdAppendEnvironment(	IN const	real32_T			begin,
										IN const	dobsEnvironment_T	environment,
										INOUT		environmentList_T	*environmentList,
										OUT			environment_T		*lastValidEnvironment)
{
	bool_T valid = false;

	/* setze Anfang und Umgebung */
	if (environmentList->count < (uint8_T)dprdENVIRONMENT_COUNT)
	{
		valid = true;
		environmentList->environment[environmentList->count].begin		 = begin;
		environmentList->environment[environmentList->count].environment = environment;
	}
	else
	{
		valid = false;
		environmentList->environment[0].begin		= environmentList->environment[0].begin;
		environmentList->environment[0].environment = environmentList->environment[0].environment;
	}

	/* �berpr�fe ob Anfang bzw. Umgebung g�ltig sind und trage nur �nderungen in der environmentList ein */
	if (valid																							&&
		environmentList->environment[environmentList->count].begin < INVALID_VALUE						&&
		environmentList->environment[environmentList->count].environment != invalid	&&
		((begin > lastValidEnvironment->begin && environment != lastValidEnvironment->environment) || environmentList->count == 0u))
	{ /*Ist s_limit_next ein g�ltiger Wert, wechselt die Umgebung auf U_next an der Stelle s_limit_next.*/
		environmentList->count++;
		lastValidEnvironment->begin		  = begin;
		lastValidEnvironment->environment = environment;
	}
	else
	{ /* konstante Laufzeit */
		environmentList->count			  = environmentList->count;
		lastValidEnvironment->begin		  = lastValidEnvironment->begin;
		lastValidEnvironment->environment = lastValidEnvironment->environment;
	}

	return valid;
}

bool_T		dprdInitEnvironmentList(	IN const	driverState_T		*driverState,
										IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	mapPath_T			*mapPath,
										OUT			real32_T			*dynamicEventPosition,
										OUT			environmentList_T	*environmentList)
{
	environment_T		tmpEnvironment;
	environment_T		oldEnvironment;
	limitCategory_T		limitCategory;
	uint16_T			i;
	real32_T			curPos;
	bool_T				isRadar;
	bool_T				isBuiltUpArea		= false;
	limitState_T		limitState;
	limitState.builtUpAreaCount		= 0;
	limitState.dynamicEventCount	= 0;
	limitState.speedLimitCount		= 0;
	limitState.onlineLimitCount		= 0;

	*dynamicEventPosition = INVALID_VALUE;
	
	/* initialisiere alle lokalen Variablen */
	memset(&oldEnvironment, 0, sizeof(oldEnvironment));
	
	tmpEnvironment.begin		= INVALID_VALUE;
	tmpEnvironment.environment	= invalid;
		
	limitState.builtUpArea.position		= 0.0f;
	limitState.builtUpArea.type			= false;
	limitState.speedLimit.position		= 0.0f;
	limitState.speedLimit.limit			= INVALID_VALUE;
	limitState.dynamicEvent.position	= 0.0f;
	limitState.dynamicEvent.type		= prtDynamicEventNone;
	limitState.onlineLimit.limit		= INVALID_VALUE;
	limitState.onlineLimit.position		= 0.0f;

	environmentList->count	= 0;
	
	/* setze aktuelle Umgebung */
	/*\spec SW_MS_Innodrive2_Forecast_360*/
	diagFF(dprdAppendEnvironment(0.0f,
								 dobsGetEnvironment(driverState),
								 environmentList,
								 &oldEnvironment));

	/* setze n�chste Umgebung vom DriverObserver */
	/* Falls die n�chste Umgebung Invalid ist, erfolgt kein Eintrag in die Liste */
	/*\spec SW_MS_Innodrive2_Forecast_361*/
	(void)dprdAppendEnvironment(dobsGetNextSpeedLimit(driverState).position,
								dobsGetNextSpeedLimit(driverState).environment,
								environmentList,
								&oldEnvironment);

	/* hole erste Umgebungsbegrenzung mit Geschwindigkeit und dynamischen Event */
	curPos = oldEnvironment.begin;
	
	if (prtGetBuiltUpArea(pathRouterMemory, limitState.builtUpAreaCount, &limitState.builtUpArea))
	{
		limitState.builtUpAreaCount++;
	}
	else
	{
		limitState.builtUpAreaCount = 0;
	}
	
	(void)prtGetSpeedLimit(mapPath, limitState.speedLimitCount, &limitState.speedLimit);
	if (prtIsLimitInBuiltUpArea(parameterSet, pathRouterMemory, &limitState.speedLimit, &isBuiltUpArea))
	{
		limitState.speedLimitCount++;
	}
	else
	{
		limitState.speedLimitCount = 0;
	}
	
	/*\spec SW_MS_Innodrive2_Forecast_366*/
	if (prtGetDynamicEvent(pathRouterMemory, limitState.dynamicEventCount, &limitState.dynamicEvent))
	{ 
		limitState.dynamicEventCount++;
	}
	else
	{
		limitState.dynamicEventCount = 0;
	}

	if (prtGetOnlineSpeed(pathRouterMemory, limitState.onlineLimitCount, &limitState.onlineLimit))
	{
		limitState.onlineLimitCount++;
	}
	else
	{
		limitState.onlineLimitCount = 0;
	}
	
	/*\spec SW_MS_Innodrive2_Forecast_366*/
	isRadar = dobsGetRadarState(driverState);

	for (i = 0; i < parameterSet->driverPredictor.prepCount.environment; i++)
	{
		diagFF(getLimitIndices(curPos, pathRouterMemory, mapPath, &limitState));
		/* nutze erste Begrenzung */
		curPos = getMinPos(&limitState, curPos, &limitCategory);

		/* bearbeite Begrenzungen */
		diagFF(getEnvironmentFromLimits(pathRouterMemory,
										parameterSet,
										limitCategory,
										&oldEnvironment,
										&limitState,
										&isRadar,
										dynamicEventPosition,
										&tmpEnvironment));

		if (!dprdAppendEnvironment(tmpEnvironment.begin, tmpEnvironment.environment, environmentList, &oldEnvironment) &&
			environmentList->horizon == INVALID_VALUE)
		{ /* setze horizont auf den Anfang der ersten Begrenzung, wenn die Liste bereits dprdENVIRONMENT_COUNT Elemente enth�lt */
			diagFF(environmentList->count >= (uint8_T)dprdENVIRONMENT_COUNT);
			environmentList->horizon = tmpEnvironment.begin;
		}
		else
		{ /* konstante Laufzeit */
			environmentList->horizon = environmentList->horizon;
		}
	}

	/* um eine konstante Laufzeit zu realisieren m�ssen alle Z�hlvariablen von limitState bis zu ihren Grenzen hochgez�hlt werdne */
	diagFF(getLimitIndices(INVALID_VALUE, pathRouterMemory, mapPath, &limitState));

	if (environmentList->count == 0u)
	{
		return false;
	}
	else
	{
		return true;
	}	
}


bool_T dprdGetEnvironmentFromPosition(	IN	const	real32_T				position,
										IN	const	environmentList_T		*environmentList,
										OUT			dobsEnvironment_T		*environment
										)
{
	uint8_T i;
	uint8_T environmentIndex = (uint8_T)dprdENVIRONMENT_COUNT;

	diagFF(environmentList->count > 0u);
	diagFF(environmentList->count <= (uint8_T)dprdENVIRONMENT_COUNT)

	/* suche zur Position passende Umgebung */
	for (i = 0; i < (uint8_T)dprdENVIRONMENT_COUNT - 1u; i++)
	{
		if (position < environmentList->environment[i + 1u].begin && position >= environmentList->environment[i].begin)
		{
			environmentIndex = i;
		}
		else
		{ /* konstante Laufzeit */
			environmentIndex = environmentIndex;
		}
	}

	if (position >= environmentList->environment[environmentList->count -1u].begin)
	{
		environmentIndex = environmentList->count - 1u;
	}
	else
	{ /* konstante Laufzeit */
		environmentIndex = environmentIndex;
	}

	if (position <= environmentList->environment[0].begin)
	{
		environmentIndex = 0;
	}
	else
	{ /* konstante Laufzeit */
		environmentIndex = environmentIndex;
	}

	/* Es wird immer eine passende Umgebung zu dieser Position gefunden */
	diagFF(environmentIndex < (uint8_T)dprdENVIRONMENT_COUNT);
	
	*environment = environmentList->environment[environmentIndex].environment;
	return true;
}
