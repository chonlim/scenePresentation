#ifndef guard_dprdDataInterface_h
#define guard_dprdDataInterface_h

#include "control/driverPredictor/driverPredictor_interface.h"




/** \brief	Gibt die angeforderte berechnete Wahrscheinlichkeit des entsprechenden Fensters und Bins der Geschwindigkeit zur�ck.
			Das Array `probability` wird bei einem ung�ltigen Fenster mit 0 initialisiert.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.

\spec SW_MS_Innodrive2_Forecast_146

\ingroup driverPredictor_api
*/
bool_T	dprdGetVelocity(IN const	driverPrediction_T	*driverPrediction,				/**<Ausgangsstruktur des driverPredictors*/
						IN const	dprdWindowIndex_T	windowIndex,					/**<Index des Zeitfensters (short/mid/long -Term)*/
						OUT			uint8_T				probability[dprdBIN_COUNT]		/**<Zur�ck gegebene Wahrscheinlichkeit*/
						);


/** \brief	Gibt die angeforderte berechnete Wahrscheinlichkeit des entsprechenden Fensters und Bins der L�ngsbeschleunigung zur�ck.
			Das Array `probability` wird bei einem ung�ltigen Fenster mit 0 initialisiert.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.

\spec SW_MS_Innodrive2_Forecast_147

\ingroup driverPredictor_api
*/
bool_T	dprdGetLongAcceleration(IN const	driverPrediction_T	*driverPrediction,				/**<Ausgangsstruktur des driverPredictors*/
								IN const	dprdWindowIndex_T	windowIndex,					/**<Index des Zeitfensters (short/mid/long -Term)*/
								OUT			uint8_T				probability[dprdBIN_COUNT]		/**<Zur�ck gegebene Wahrscheinlichkeit*/
								);

/** \brief	Gibt die angeforderte berechnete Wahrscheinlichkeit des entsprechenden Fensters und Bins der Querbeschleunigung zur�ck.
			Das Array `probability` wird bei einem ung�ltigen Fenster mit 0 initialisiert.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.

\spec SW_MS_Innodrive2_Forecast_148

\ingroup driverPredictor_api
*/
bool_T	dprdGetLatAcceleration(	IN const	driverPrediction_T	*driverPrediction,				/**<Ausgangsstruktur des driverPredictors*/
								IN const	dprdWindowIndex_T	windowIndex,					/**<Index des Zeitfensters (short/mid/long -Term)*/
								OUT			uint8_T				probability[dprdBIN_COUNT]		/**<Zur�ck gegebene Wahrscheinlichkeit*/
								);


/** \brief	Gibt die angeforderte berechnete Wahrscheinlichkeit des entsprechenden Fensters und Bins der Radleistung zur�ck.
			Das Array `probability` wird bei einem ung�ltigen Fenster mit 0 initialisiert.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.

\spec SW_MS_Innodrive2_Forecast_149

\ingroup driverPredictor_api
*/
bool_T	dprdGetWheelPower(	IN const	driverPrediction_T	*driverPrediction,				/**<Ausgangsstruktur des driverPredictors*/
							IN const	dprdWindowIndex_T	windowIndex,					/**<Index des Zeitfensters (short/mid/long -Term)*/
							OUT			uint8_T				probability[dprdBIN_COUNT]		/**<Zur�ck gegebene Wahrscheinlichkeit*/
							);

/** \brief	Gibt die angeforderte berechnete Wahrscheinlichkeit des entsprechenden Fensters und Bins der Stra�enklasse zur�ck.
Das Array `probability` wird bei einem ung�ltigen Fenster mit 0 initialisiert.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.

\spec SW_MS_Innodrive2_Forecast_385

\ingroup driverPredictor_api
*/
bool_T	dprdGetStreetClass(	IN const	driverPrediction_T	*driverPrediction,				/**<Ausgangsstruktur des driverPredictors*/
							IN const	dprdWindowIndex_T	windowIndex,					/**<Index des Zeitfensters (short/mid/long -Term)*/
							OUT			uint8_T				probability[dprdBIN_COUNT]		/**<Zur�ck gegebene Wahrscheinlichkeit*/
							);


/** \brief �berpr�ft ob ein angefordertes Fenster g�ltig ist.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.

\spec SW_MS_Innodrive2_Forecast_150

\ingroup driverPredictor_api
*/
bool_T	dprdIsWindowValid(	IN const	driverPrediction_T	*driverPrediction,		/**<Ausgangsstruktur des driverPredictors*/
							IN const	dprdWindowIndex_T	windowIndex,			/**<Index des Zeitfensters (short/mid/long -Term)*/
							OUT			bool_T				*valid					/**<true, wenn ein Fenster g�ltig ist, ansonsten false.*/
							);

/** \brief Liefert den Status des driverPredictor Toggle Bits zur�ck.

\spec SW_MS_Innodrive2_Forecast_152

\ingroup driverPredictor_api
*/
void	dprdGetToggleBitState(	IN const	driverPrediction_T	*driverPrediction,		/**<Ausgangsstruktur des driverPredictors*/
								OUT			bool_T				*toggleBit				/**<Status des Toggle Bits.*/
								);

/** \brief �berpr�ft ob ein angefordertes Fenster g�ltig ist.

Der R�ckgabewert ist `true` wenn die Prediktionsdaten g�ltig sind, anosten `false`.

\spec SW_MS_Innodrive2_Forecast_154

\ingroup driverPredictor_api
*/
bool_T	dprdIsValidPrediction(	IN const	driverPrediction_T	*driverPrediction		/**<Ausgangsstruktur des driverPredictors*/
								);





#endif
