#ifndef guard_dprdDataInterfaceStatic_h
#define guard_dprdDataInterfaceStatic_h


/** \brief Liefert die angeforderte berechnete Wahrscheinlichkeit des entsprechenden Fensters und Bins zur�ck.

Der R�ckgabewert ist `false` im Fall eines unvorhergesehenen Fehlers, ansonsten immer `true`.
\ingroup driverPredictor_api
*/
static bool_T	getProbability(	IN const	driverPrediction_T			*driverPrediction,		/**<Ausgangsstruktur des driverPredictors*/
								IN const	dprdWindowIndex_T			windowIndex,			/**<Fenster Index*/
								IN const	dprdBinCategory_T			binCategory,			/**<Angefordertes Bin Array*/
								OUT			uint8_T						*probability			/**<INVALID_UINT8 wenn das angeforderte Fenster ung�ltig ist, ansonsten die berechnete Wahrscheinlichkeit vom driverPredictor.*/
								);

#endif
