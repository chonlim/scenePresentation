#include "control/driverPredictor/dprdParameters.h"
#include "control/driverPredictor/dprdParametersStatic.h"
#include "control/driverObserver/dobsDataInterface.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdParameters)


static bool_T	dprdInitDynamicParameterSet(IN const	parameterSetCtrl_T		*parameterSet,
											IN const	dynamicSet_T			*dobsDynamicSet,
											IN const	real32_T				 maxVelocity,
											OUT			dynamicParameterSet_T	*dynamicParameterSet)
{
	dynamicParameterSet->maxVelocity				= maxVelocity;
	dynamicParameterSet->offsetVelocity				= dobsDynamicSet->offsetVelocity.value;

	dynamicParameterSet->maxLongAcceleration		= dobsDynamicSet->longAcceleration.value;
	dynamicParameterSet->maxLatAcceleration			= dobsDynamicSet->latAcceleration.value;
	/*	Die gelernten Werte aus dem driverObserver werden mit weiteren Werten verrechnet, was zu ungewollten Ergebnissen f�hren kann.
		Deshalb wird dynamicParameterSet->minLongAcceleration und dynamicParameterSet->criticalMinAcceleration
		mindestens auf parameterSet->driverPredictor.minAcceleration aus dem ParameterSet gesetzt.*/
	dynamicParameterSet->minLongAcceleration		= max(	dobsDynamicSet->longDeceleration.value * -1.0f,
															parameterSet->driverPredictor.minAcceleration); /*\spec SW_MS_Innodrive2_Forecast_390*/
	dynamicParameterSet->criticalMinAcceleration	= max(	parameterSet->driverPredictor.minAccelerationFactor * dynamicParameterSet->minLongAcceleration,
															parameterSet->driverPredictor.minAcceleration);

	dynamicParameterSet->maxWheelPower				= dobsDynamicSet->wheelPower;
	dynamicParameterSet->maxLongJerk				= dobsDynamicSet->maxJerk;
	dynamicParameterSet->minLongJerk				= dobsDynamicSet->minJerk;

	return true;
}


bool_T	dprdInitDynamicParameters(	IN	const	parameterSetCtrl_T		*parameterSet,
									IN	const	driverState_T			*driverState,
									OUT			dynamicParameters_T		*dynamicParameters)
{
	dynamicSet_T dobsDynamicSet;
	real32_T maxVelocity;
	
	maxVelocity = dobsGetMaxVelocity(driverState);

	diagFF(dobsGetDynamicSet(driverState, city, &dobsDynamicSet));
	diagFF(dprdInitDynamicParameterSet(parameterSet, &dobsDynamicSet, maxVelocity, &dynamicParameters->city));

	diagFF(dobsGetDynamicSet(driverState, countryRadar, &dobsDynamicSet));
	diagFF(dprdInitDynamicParameterSet(parameterSet, &dobsDynamicSet, maxVelocity, &dynamicParameters->countryRadar));

	diagFF(dobsGetDynamicSet(driverState, country, &dobsDynamicSet));
	diagFF(dprdInitDynamicParameterSet(parameterSet, &dobsDynamicSet, maxVelocity, &dynamicParameters->country));

	return true;
}


const dynamicParameterSet_T	*dprdGetDynamicSetPtr(	IN	const	dynamicParameters_T		*dynamicParameters,
													IN	const	dobsEnvironment_T		environment)
{
	const dynamicParameterSet_T *dynamicParameterSet = NULL;

 	switch (environment)
	{
	case city:			dynamicParameterSet = &dynamicParameters->city;			break;
	case countryRadar:	dynamicParameterSet = &dynamicParameters->countryRadar;	break;
	case country:		dynamicParameterSet = &dynamicParameters->country;		break;
	case invalid:		dynamicParameterSet = NULL;								break;
	default:			dynamicParameterSet = NULL;								break;
	}

	return dynamicParameterSet;
}


bool_T dprdDynamicParameterSetLevel(IN	const	parameterSetCtrl_T		*parameterSet,
									IN	const	dobsEnvironment_T		environment,
									INOUT		dynamicParameters_T		*dynamicParameters)
{
	dynamicParameterSet_T *dynamicParameterSet = NULL;
	const uint8_T	overrideLevel = parameterSet->driverPredictor.minDynamicLevel;
	diagFF(overrideLevel < (uint8_T)dobsMAXLEVELCOUNT);

	switch (environment)
	{
	case city:			dynamicParameterSet = &dynamicParameters->city;			break;
	case countryRadar:	dynamicParameterSet = &dynamicParameters->countryRadar;	break;
	case country:		dynamicParameterSet = &dynamicParameters->country;		break;
	case invalid:		dynamicParameterSet = NULL;								break;
	default:								diagFUnreachable();
	}/*lint !e9077*/
	diagFF(dynamicParameterSet != NULL);

	dynamicParameterSet->maxVelocity				= max(dynamicParameterSet->maxVelocity,		parameterSet->driverObserver.maxVelocity.initialValues[overrideLevel]);
	dynamicParameterSet->offsetVelocity				= max(dynamicParameterSet->offsetVelocity,	parameterSet->driverObserver.offsetVelocity.lowerBounds[overrideLevel]);
	dynamicParameterSet->offsetVelocity				= max(dynamicParameterSet->offsetVelocity,	parameterSet->driverObserver.offsetVelocity.upperBounds[overrideLevel]);
	
	dynamicParameterSet->maxLongAcceleration		= max(dynamicParameterSet->maxLongAcceleration,	parameterSet->driverObserver.escalation.longAccelerationLevels[overrideLevel]);
	dynamicParameterSet->maxLatAcceleration			= max(dynamicParameterSet->maxLatAcceleration,	parameterSet->driverObserver.escalation.latAccelerationLevels[overrideLevel]);
	dynamicParameterSet->minLongAcceleration		= min(dynamicParameterSet->minLongAcceleration, -parameterSet->driverObserver.escalation.longDecelerationLevels[overrideLevel]);


	dynamicParameterSet->maxWheelPower				= max(dynamicParameterSet->maxWheelPower,	parameterSet->driverObserver.escalation.wheelPowerLevels[overrideLevel]);
	dynamicParameterSet->maxLongJerk				= max(dynamicParameterSet->maxLongJerk,		parameterSet->driverObserver.escalation.maxJerkLevels[overrideLevel]);
	dynamicParameterSet->minLongJerk				= min(dynamicParameterSet->minLongJerk,		parameterSet->driverObserver.escalation.minJerkLevels[overrideLevel]);

	/*unver�nderte Werte*/
	dynamicParameterSet->criticalMinAcceleration	= max(dynamicParameterSet->criticalMinAcceleration, dynamicParameterSet->criticalMinAcceleration);

	return true;
}
