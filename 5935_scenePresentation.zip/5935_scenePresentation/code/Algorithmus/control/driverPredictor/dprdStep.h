#ifndef guard_dprdStep_h
#define guard_dprdStep_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_private.h"
#include "common/vehicleModel/vehicleModel.h"
#include "control/inputCodec/inputCodec_interface.h"




/**\brief	Die ganze Berechnung des driverPredictor Moduls ist sehr aufwendig, weshalb sie auf mehrere Zeitschritte verteilt ist. Weshalb diese Funktion mehrfach aufgerufen 
			werden muss damit die komplette Berechnung der Trajektorie und der Ausgangschnittstelle zur Verf�gung steht.

\spec SW_MS_Innodrive2_Forecast_145
\spec SW_MS_Innodrive2_Forecast_154
\spec SW_MS_Innodrive2_Forecast_152
\spec SW_MS_Innodrive2_Forecast_339
\spec SW_MS_Innodrive2_Forecast_341
\spec SW_AS_PIF_679

\ingroup driverObserver_step
*/
bool_T	stepDriverPredictor(	IN const	vehicleModel_T			*vehicleModel,				/**<Eingangs-Struktur vehicleModel*/
								IN const	vehicleInput_T			*vehicleInput,				/**<Eingangssignale (hier f�r Kodierflag `ignoreCountry`)*/
								IN const	vehicleState_T			*vehicleState,				/**<Fahrzeugzustand*/
								IN const	driverState_T			*driverState,				/**<Private Struktur des driverObserver*/
								IN const	mapPath_T				*mapPath,					/**<Kartendaten*/
								IN const	pathRouterMemory_T		*pathRouterMemory,			/**<Struktur der linearisierten Streckendaten*/
								INOUT		driverPredictorMemory_T *driverPredictorMemory,		/**<Private Struktur des driverPredictors*/
								OUT			driverPrediction_T		*driverPrediction			/**<Ausgangsstruktur des driverPredictors*/
								);





#endif
