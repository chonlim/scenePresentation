#ifndef guard_dprdOutputStatic_h
#define guard_dprdOutputStatic_h

#include "control/driverPredictor/driverpredictor_private.h"


/**\brief Ordnet value einem Bin-Wert zu und inkrementiert den entsprechenden Index.

\spec SW_MS_Innodrive2_Forecast_146
\spec SW_MS_Innodrive2_Forecast_147
\spec SW_MS_Innodrive2_Forecast_148
\spec SW_MS_Innodrive2_Forecast_149
\spec SW_MS_Innodrive2_Forecast_385

\ingroup driverPredictor_output

*/
static bool_T	countContainerBin(	IN const	real32_T			containerRanges[dprdBIN_COUNT],		/**<Bin-Wertgrenzen-Array.*/
									IN const	real32_T			value,								/**<Einzuordnender Wert.*/
									IN const	bool_T				valid,								/**<Flag welches bestimmt ob die Eingangsparameter g�ltig sind. Wird genutzt die konstante Laufzeit zu realisieren.*/
									OUT			uint8_T				binCount[dprdBIN_COUNT]				/**<Ausgangsarray welches die Auftrittsh�ufigkeiten speichert.*/
									);

/**\brief Ordnet die Stra�enklasse einem Bin-Wert zu und inkrementiert den entsprechenden Index.

\spec SW_MS_Innodrive2_Forecast_387

\ingroup driverPredictor_output

*/
static bool_T countContainerBinStreetClass(	IN const	prtStreetClassValues_T		value,
											IN const	bool_T						valid,
											OUT			uint8_T						binCount[dprdBIN_COUNT]
											);

#endif /*_dprdOutputStatic_H_*/
