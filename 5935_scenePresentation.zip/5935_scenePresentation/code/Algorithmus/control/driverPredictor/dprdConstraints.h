#ifndef guard_dprdConstraints_h
#define guard_dprdConstraints_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_private.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"


/**\brief Initialisiert das constraintSet.

\ingroup driverPredictor_constraints
*/
void dprdInitConstraintSet(	OUT constraintSet_T *constraintSet		/**<Liste der Einschr�nkungen*/
							);


/**\brief Stellt die Liste der statischen Einschr�nkungen auf dem Vorausschauhorizont zusammen.

R�ckgabewert ist `true` wenn die Liste erfolgreich erstellt werden konnte, ansonsten `false`.

\spec SW_MS_Innodrive2_Forecast_343
\spec SW_MS_Innodrive2_Forecast_370
\spec SW_MS_Innodrive2_Forecast_379

\ingroup driverPredictor_constraints
*/
bool_T	dprdGetConstraintList(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globale Parameter*/
								IN const	vmState_T			*currentVMSate,			/**<aktueller Bewegungszustand*/
								IN const	driverState_T		*driverState,			/**<Private Struktur des driverObserver*/
								IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
								IN const	mapPath_T			*mapPath,				/**<Kartendaten*/
								IN const	environmentList_T	*environmentList,		/**<Liste der Umgebungen*/
								IN const	dynamicParameters_T	*dynamicParameters,		/**<Entsprechende Fahrparameter zur Umgebung*/
								IN const	real32_T			 vehiclePosition,		/**<Fahrzeugposition*/
								OUT			constraintSet_T		*constraintSet			/**<Alle Geschwindigkeitseinschr�nkungen und der Vorausschauhorizont*/
								);


/**\brief �berpr�ft ob das �bergebene OnlineLimit die folgenden Bedingungen erf�llt:
unbeschr�nkte Abschnitte: Wenn die Flie�geschwindigkeit einen applizierbaren Wert unterschreitet, wird die Einschr�nkung durch Onlineverkehr ber�cksichtigt.
beschr�nkte Abschnitte: Wenn die Flie�geschwindigkeit kleiner als ein applizierbarer Faktor mal dem g�ltigen Speedlimit, oder kleiner als das Speedlimit abz�glich eines.

R�ckgabewert ist `true` wenn eine der Bedingungen erf�llt ist, ansonsten `false`.

\spec SW_MS_Innodrive2_Forecast_376

\ingroup driverPredictor_constraints
*/
bool_T	isValidOnlineLimit(	IN const	prtSpeedLimit_T		*maxSpeedAtPosition,		/**<Maximale erlaubte Geschwindigkeit mit Position*/
							IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
							IN const	prtSpeedLimit_T		*onlineSpeedLimit			/**<OnlineLimit, welches auf G�ltigkeit �berpr�ft wird.*/
									);




#endif
