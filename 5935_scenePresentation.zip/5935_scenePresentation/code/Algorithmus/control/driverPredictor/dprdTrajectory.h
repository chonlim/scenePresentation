#ifndef guard_dprdTrajectory_h
#define guard_dprdTrajectory_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_private.h"
#include "common/vehicleModel/vehicleModel_interface.h"
#include "control/parameterSet/ParameterSetCtrl_interface.h"




/** \brief Berechnet ausgehend von `startVector` die Vorausschautrajektorie, deren Grundlage das constraintSet ist.

\spec SW_MS_Innodrive2_Forecast_388
\spec SW_MS_Innodrive2_Forecast_341
\spec SW_MS_Innodrive2_Forecast_367
\spec SW_MS_Innodrive2_Forecast_358
\spec SW_MS_Innodrive2_Forecast_393

\ingroup driverPredictor_trajectory
*/
bool_T	dprdGetTrajectory(	IN const	vehicleModel_T		*vehicleModel,				/**<Fahrzeugmodell*/
							IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
							IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
							IN const	real32_T			dynamicEventPosition,		/**<Das Fahrdynamikevent wird nur betrachetet, wenn die Position ungleich INVALID_VALUE ist.*/
							IN const	dprdWindowIndex_T	dprdWindowIndex,			/**<Gibt an welches Zeitfenster berechnet werden soll (siehe dprdWindowIndex_T).*/
							IN const	constraintSet_T		*constraintSet,				/**<Enth�lt alle zuvor berechneten Geschwindigkeitseinschr�nkungen und den Vorausschauhorizont.*/
							IN const	vmState_T			*startVector,				/**<Anfangsvektor mit Position, Geschwindigkeit und Beschleunigung*/
							IN const	environmentList_T	*environmentList,			/**<Liste der Umgebungen*/
							INOUT		dynamicParameters_T	*dynamicParameters,			/**<Dynamische Fahrparameter*/
							OUT			trajectory_T		*trajectory					/**<Berechnete Trajektorie*/
							);




#endif
