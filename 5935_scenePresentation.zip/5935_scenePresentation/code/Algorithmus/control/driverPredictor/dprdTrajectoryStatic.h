#ifndef guard_dprdTrajectoryStatic_h
#define guard_dprdTrajectoryStatic_h

#include "control/control.h"
#include "control/driverPredictor/driverPredictor_private.h"
#include "control/parameterSet/ParameterSetCtrl_interface.h"
#include "common/vehicleModel/vehicleModel_interface.h"


typedef struct _constraintVelocityContainer
{
	real32_T			accelerationArray[(dprdLandingProfile_T)profileInvalid];
	real32_T			sqVLandArray[(dprdLandingProfile_T)profileInvalid];
	dobsEnvironment_T	environmentArray[(dprdLandingProfile_T)profileInvalid];
	uint8_T				constraintIndexArray[(dprdLandingProfile_T)profileInvalid];
}constraintVelocityContainer_T;


/** \brief H�ngt einen Zustandsvektor an die Trajektorie an.

\ingroup driverPredictor_trajectory
*/
static bool_T	dprdAppendVector(	IN const	predictionState_T	*vector,		/**<Zustandsvektor, dass zur Trajektorienstruktur eingef�gt wird.*/
									INOUT		trajectory_T		*trajectory		/**<Trajektorienstrutkur in die ein neuer Zustandsvektor angeh�ngt werden.*/
									);

/**\brief Berechnet ausgehend vom `currentVector` den n�chsten Zeitschritt.

\spec SW_MS_Innodrive2_Forecast_388
\spec SW_MS_Innodrive2_Forecast_340
\spec SW_MS_Innodrive2_Forecast_342
\spec SW_MS_Innodrive2_Forecast_344
\spec SW_MS_Innodrive2_Forecast_345
\spec SW_MS_Innodrive2_Forecast_386
\spec SW_MS_Innodrive2_Forecast_389

\ingroup driverPredictor_trajectory
*/
static bool_T	dprdCalcTimestep(	IN const	vehicleModel_T		*vehicleModel,				/**<Fahrzeugmodell*/
									IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
									IN const	dynamicParameters_T	*dynamicParameters,			/**<Entsprechende Fahrparameter zur Umgebung.*/
									IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
									IN const	constraintSet_T		*constraintSet,				/**<Enth�lt alle Geschwindigkeitseinschr�nkungen und den Vorausschauhorizont.*/
									IN const	environmentList_T	*environmentList,			/**<Liste der Umgebungen*/
									IN const	predictionState_T	*currentVector,				/**<Aktueller Systemzustand im Zustandsraum der Geschwindigkeitsplanung.*/
									OUT			predictionState_T	*nextVector				/**<Ergebnis der Trajektorienberechnung.*/
									);

/**\brief Berechnet f�r jede Einschr�nkung eine Maximalbeschleunigung abh�ngig vom Fahrzeugzustand und den der Einschr�nkung zugeordneten Reaktionsparametern.

\spec SW_MS_Innodrive2_Forecast_357
\spec SW_MS_Innodrive2_Forecast_351
\spec SW_MS_Innodrive2_Forecast_354
\spec SW_MS_Innodrive2_Forecast_356

\ingroup driverPredictor_trajectory
*/
static bool_T	dprdEvalConstraints(IN const	dynamicParameters_T	*dynamicParameters,			/**<Entsprechende Fahrparameter zur Umgebung.*/
									IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
									IN const	constraintSet_T		*constraintSet,				/**<Enth�lt alle Geschwindigkeitseinschr�nkungen und den Vorausschauhorizont.*/
									IN const	predictionState_T	*currentVector,				/**<Aktueller Systemzustand im Zustandsraum der Geschwindigkeitsplanung*/
									IN const	vehicleModel_T		*vehicleModel,				/**<Fahrzeugmodell*/
									IN const	pathRouterMemory_T	*pathRouterMemory,			/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
									OUT			real32_T			*maxAcceleration			/**<Maximal berechnete Beschleunigung.*/
									);

/**\brief Berechnet die Landegeschwindigkeit zu den entsprechenden Constraints.

\ingroup driverPredictor_trajectory
*/
static bool_T	dprdCalcLanding(	IN const	dynamicParameters_T		*dynamicParameters,		/**<Entsprechende Fahrparameter zur Umgebung.*/
									IN const	predictionState_T		*currentVector,			/**<Aktueller Systemzustand im Zustandsraum der Geschwindigkeitsplanung*/
									IN const	constraint_T			*constraint,			/**<Beschr�nkung*/
									IN const	real32_T				 deltaT,				/**<Zeitschrittweite [s]*/
									OUT			dobsEnvironment_T		*environment,			/**<Umgebung*/
									OUT			real32_T				*sqLandingVelocity,		/**<quadratische Landegeschwindigkeit*/
									OUT			dprdLandingProfile_T	*landingProfile			/**<Landeprofil*/
									);

/**\brief Berechnet die maximale Beschleunigung und Geschwindigkeit, die sich unter Ber�cksichtigung von Ruckgrenzen und zeitlicher Diskretisierung ergibt.

\spec SW_MS_Innodrive2_Forecast_355
\spec SW_MS_Innodrive2_Forecast_394
\spec SW_MS_Innodrive2_Forecast_395

\ingroup driverPredictor_trajectory
*/
static bool_T	dprdFlareAcceleration(	IN	const	constraintVelocityContainer_T	*velocityContainer,				/**<Struktur zum speichern von Zwischenergebnissen bei der Trajektorienberechnung.*/
										IN	const	dynamicParameters_T				*dynamicParameters,				/**<Entsprechende Fahrparameter zur Umgebung*/
										IN	const	predictionState_T				*currentVector,					/**<Aktueller Systemzustand im Zustandsraum der Geschwindigkeitsplanung*/
										IN	const	real32_T						deltaT,							/**<Zeitschrittweite [s]*/
										OUT			real32_T						*acceleration,					/**<Maximale Beschleunigung*/
										OUT			dobsEnvironment_T				*maxAcclerationEnvironment,		/**<Umgebung in der sich die berechnete Beschleunigung befindet*/
										OUT			uint8_T							*velConstraintIndex				/**<Index der relevanten Constraint*/
										);

/**\brief �bernimmt die minimal m�gliche Geschwindigkeit und die entsprechende Umgebung.

\spec SW_MS_Innodrive2_Forecast_390

\ingroup driverPredictor_trajectory
*/
static bool_T	setMinVelocity(	IN const	dynamicParameters_T				*dynamicParameters,			/**<Entsprechende Fahrparameter zur Umgebung*/
								IN const	dobsEnvironment_T				environment,				/**<Umgebung siehe dobsEnvironment_T*/
								IN const	real32_T						sqLandingVelocity,			/**<Zu �bernehmende Landegeschwindigkeit*/
								IN const	uint8_T							constraintIndex,			/**<Index des Constraint aufgrunddessen die Landegeschwindigkeit �bernommen wird.*/
								INOUT		constraintVelocityContainer_T	*velocityContainer,			/**<Struktur zum speichern von Zwischenergebnissen bei der Trajektorienberechnung.*/
								INOUT		dprdLandingProfile_T			*landingProfile				/**<Landeprofil*/
								);

/**\brief Liefert die minimale Geschwindigkeit zur�ck, die sich unter der Ber�ckstigung aller Constraints ergibt.

\ingroup driverPredictor_trajectory
*/
static bool_T	getMinVelocities(	IN const	uint8_T				count,								/**<Vorhandene Constraints.*/
									IN const	uint16_T			evalCount,							/**<Anzahl der Constraints, die ausgewertet werden.*/
									IN const	uint8_T				offset,								/**<Offset an dem die Constraints der entsprechenden Kategorie beginnen.*/
									IN const	dynamicParameters_T	*dynamicParameters,					/**<Entsprechende Fahrparameter zur Umgebung*/
									IN const	constraintSet_T		*constraintSet,						/**<Enth�lt alle Geschwindigkeitseinschr�nkungen und den Vorausschauhorizont.*/
									IN const	predictionState_T	*currentVector,						/**<Aktueller Systemzustand im Zustandsraum der Geschwindigkeitsplanung*/
									IN const	real32_T			deltaT,								/**<Zeitschrittweite [s]*/
									INOUT		constraintVelocityContainer_T	*velocityContainer		/**<Struktur zum speichern von Zwischenergebnissen bei der Trajektorienberechnung.*/
									);

#endif
