#include "control/control.h"
#include "control/driverPredictor/dprdDataInterface.h"
#include "control/driverPredictor/driverPredictor_private.h"
#include "control/driverPredictor/dprdDataInterfaceStatic.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdDataInterface)


static bool_T	getProbability(	IN const	driverPrediction_T			*driverPrediction,
								IN const	dprdWindowIndex_T			windowIndex,
								IN const	dprdBinCategory_T			binCategory,
								OUT			uint8_T						probability[dprdBIN_COUNT]
								)
{
	const uint8_T *container = NULL;
	const driverPredictionWindow_T *window = NULL;

	diagFF(windowIndex != invalidWindowIndex);
	diagFF(binCategory != binCategoryInvalid);

	switch (windowIndex)
	{
	case shortTermWindow:		window = &driverPrediction->shortTermWindow;	break;
	case midTermWindow:			window = &driverPrediction->midTermWindow;		break;
	case longTermWindow:		window = &driverPrediction->longTermWindow;		break;

	default: diagFUnreachable();
	}/*lint !e9077 !e788 Wert invalidWindowIndex nicht m�glich */

	switch (binCategory)
	{
	case binCategoryVelocity:			container = window->velocity;			break;
	case binCategoryLongAcceleration:	container = window->longAcceleration;	break;
	case binCategoryLatAcceleration:	container = window->absLatAcceleration;	break;
	case binCategoryWheelPower:			container = window->wheelPower;			break;
	case binCategoryStreetClass:		container = window->streetClass;		break;

	default: diagFUnreachable();
	}/*lint !e9077 !e788 Wert binCategoryInvalid nicht m�glich */

	if (window->isValid)
	{
		memset(probability, 0, sizeof(uint8_T)*(size_t)dprdBIN_COUNT);
		memcpy(probability, container, sizeof(uint8_T)*(size_t)dprdBIN_COUNT);
	}
	else
	{ /*konstante Laufzeit realisieren*/
		memcpy(probability, container, sizeof(uint8_T)*(size_t)dprdBIN_COUNT);
		memset(probability, 0, sizeof(uint8_T)*(size_t)dprdBIN_COUNT);
	}
	
	return true;
}


bool_T	dprdGetVelocity(IN const	driverPrediction_T	*driverPrediction,
						IN const	dprdWindowIndex_T	windowIndex,
						OUT			uint8_T				probability[dprdBIN_COUNT]
						)
{
	/*\spec SW_MS_Innodrive2_Forecast_146*/
	return getProbability(driverPrediction, windowIndex, binCategoryVelocity, probability);
}


bool_T	dprdGetLongAcceleration(IN const	driverPrediction_T	*driverPrediction,
								IN const	dprdWindowIndex_T	windowIndex,
								OUT			uint8_T				probability[dprdBIN_COUNT]
								)
{
	/*\spec SW_MS_Innodrive2_Forecast_147*/
	return getProbability(driverPrediction, windowIndex, binCategoryLongAcceleration, probability);
}


bool_T	dprdGetLatAcceleration(	IN const	driverPrediction_T	*driverPrediction,
								IN const	dprdWindowIndex_T	windowIndex,
								OUT			uint8_T				probability[dprdBIN_COUNT]
								)
{
	/*\spec SW_MS_Innodrive2_Forecast_148*/
	return getProbability(driverPrediction, windowIndex, binCategoryLatAcceleration, probability);
}


bool_T	dprdGetWheelPower(	IN const	driverPrediction_T	*driverPrediction,
							IN const	dprdWindowIndex_T	windowIndex,
							OUT			uint8_T				probability[dprdBIN_COUNT]
							)
{
	/*\spec SW_MS_Innodrive2_Forecast_149*/
	return getProbability(driverPrediction, windowIndex, binCategoryWheelPower, probability);
}

bool_T	dprdGetStreetClass(	IN const	driverPrediction_T	*driverPrediction,
							IN const	dprdWindowIndex_T	windowIndex,
							OUT			uint8_T				probability[dprdBIN_COUNT]
							)
{
	/*\spec SW_MS_Innodrive2_Forecast_385*/
	return getProbability(driverPrediction, windowIndex, binCategoryStreetClass, probability);
}


bool_T	dprdIsWindowValid(	IN const	driverPrediction_T	*driverPrediction,		/**<Ausgangsstruktur des driverPredictors*/
							IN const	dprdWindowIndex_T	windowIndex,			/**<Ausgangsstruktur des driverPredictors*/
							OUT			bool_T				*valid					/**<true, wenn ein Fenster g�ltig ist, ansonsten false.*/
							)
{
	const driverPredictionWindow_T *window = NULL;

	switch (windowIndex)
	{
	case shortTermWindow:		window = &driverPrediction->shortTermWindow;	break;
	case midTermWindow:			window = &driverPrediction->midTermWindow;		break;
	case longTermWindow:		window = &driverPrediction->longTermWindow;		break;
	case invalidWindowIndex:	window = NULL;									break;

	
	default: diagFUnreachable();
	}/*lint !e9077*/

	diagFF(window != NULL);

	if (window->isValid)
	{
		/*\spec SW_MS_Innodrive2_Forecast_150*/
		*valid = true;
	}
	else
	{
		*valid = false;
	}

	return true;
}


void	dprdGetToggleBitState(	IN const	driverPrediction_T	*driverPrediction,
								OUT			bool_T				*toggleBit			
								)
{
	/*\spec SW_MS_Innodrive2_Forecast_152*/
	*toggleBit = driverPrediction->toggleBit;
}


bool_T	dprdIsValidPrediction(	IN const	driverPrediction_T	*driverPrediction
								)
{
	/*\spec SW_MS_Innodrive2_Forecast_154*/
	return driverPrediction->isValidPrediction;
}
