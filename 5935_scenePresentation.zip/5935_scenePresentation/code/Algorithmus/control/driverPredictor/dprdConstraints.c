#include "control/driverPredictor/dprdConstraints.h"
#include "control/driverPredictor/driverPredictor_private.h"

#include "control/driverObserver/dobsDataInterface.h"

#include "control/driverPredictor/dprdParameters.h"
#include "control/driverPredictor/dprdEnvironment.h"
#include "control/driverPredictor/dprdConstraintsStatic.h"

#include <string.h>

/*lint -esym(9045, struct _exception)*/
#include <math.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdConstraints)



static bool_T	dprdGetSpeedLimitBegin(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	mapPath_T			*mapPath,
										IN const	driverState_T		*driverState,
										INOUT		constraintList_T	*constraintList)
{
	uint16_T			i;
	real32_T			tmpPos			= 0.0f;
	constraint_T		constraint;
	prtSpeedLimit_T		speedLimit;
	const uint16_T		speedLimitCount = prtGetSpeedLimitCount(mapPath);
	/*\spec SW_MS_Innodrive2_Forecast_371*/
	dobsNextLimitInfo_T	nextSpeedLimit	= dobsGetNextSpeedLimit(driverState);

	/* hinzuf�gen von vLimitNext */
	constraint.begin	= nextSpeedLimit.position;
	constraint.velocity = nextSpeedLimit.limit;
	constraint.type		= classSpeedLimit;

	/* letzte g�ltige Position war entweder vehiclePosition oder nextSpeedLimit.position */
	diagFF(dprdAppendConstraint(&constraint, constraintList));
	diagFF(constraintList->count < (uint8_T)dprdCONSTRAINT_COUNT);
	if (constraintList->count > 0u)
	{
		tmpPos = constraintList->constraint[constraintList->count - 1u].begin;
	}
	else
	{
		tmpPos = 0.0f;
	}

	/* suche n�chstes relevantes Geschwindigkeitslimit nach vLimitNext oder vWunsch */
	/*\spec SW_MS_Innodrive2_Forecast_373*/
	for (i = 0; i < parameterSet->driverPredictor.prepCount.speedLimit; i++)
	{
		(void)prtGetSpeedLimit(mapPath, i, &speedLimit);
		if (speedLimit.position > tmpPos && i < speedLimitCount)
		{
			constraint.begin = speedLimit.position;
			constraint.velocity = speedLimit.limit;
			diagFF(dprdAppendConstraint(&constraint, constraintList));
			tmpPos = speedLimit.position;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			constraint.begin	= INVALID_VALUE;
			constraint.velocity = INVALID_VALUE;
			diagFF(dprdAppendConstraint(&constraint, constraintList));
			tmpPos = tmpPos;
		}
	}

	return true;
}


static bool_T	dprdGetSpeedLimitEnd(	IN const	uint8_T				initialListCount,
										IN const	environmentList_T	*environmentList,
										IN const	parameterSetCtrl_T	*parameterSet,
										IN const	dynamicParameters_T	*dynamicParameters,
										INOUT		constraintList_T	*constraintList)
{
	uint8_T						i;
	dobsEnvironment_T			tmpEnvironment = invalid;
	const dynamicParameterSet_T *dynamicParamterSet = NULL;

	diagFF(parameterSet->driverPredictor.prepCount.speedLimit <= (uint8_T)dprdCONSTRAINT_COUNT);

	diagFF(constraintList->count != 0u);
	diagFF(constraintList->count <= (uint8_T)dprdCONSTRAINT_COUNT);

	/* bestimme Umgebung der Geschwindigkeitslimits und f�ge sie zu der Liste hinzu */	
	for (i = 0; i < parameterSet->driverPredictor.prepCount.speedLimit; i++)
	{
		real32_T velocity = INVALID_VALUE;
		real32_T begin = 0.0f;

		if (initialListCount <= i && i < constraintList->count - 1u)
		{
			begin = constraintList->constraint[i].begin;
			velocity = constraintList->constraint[i].velocity;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			begin = 0.0f;
			velocity = INVALID_VALUE;
		}

		diagFF(dprdGetEnvironmentFromPosition(begin, environmentList, &tmpEnvironment));
		dynamicParamterSet = dprdGetDynamicSetPtr(dynamicParameters, tmpEnvironment);
		diagFF(dynamicParamterSet != NULL);

		if (i > initialListCount)
		{
			/*\spec SW_MS_Innodrive2_Forecast_371*/
			/*\spec SW_MS_Innodrive2_Forecast_373*/
			velocity += dynamicParamterSet->offsetVelocity;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			velocity = velocity;
		}

		/*\spec SW_MS_Innodrive2_Forecast_371*/
		/*\spec SW_MS_Innodrive2_Forecast_359*/
		/*\spec SW_MS_Innodrive2_Forecast_373*/
		velocity = min(velocity, dynamicParamterSet->maxVelocity);
		velocity = max(0.0f, velocity);

		if (initialListCount <= i && i < constraintList->count - 1u)
		{
			constraintList->constraint[i].velocity = velocity;
			constraintList->constraint[i].end = constraintList->constraint[i + 1u].begin; /*\spec SW_MS_Innodrive2_Forecast_347*/
			constraintList->constraint[i].environment = tmpEnvironment;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			constraintList->constraint[0].velocity = constraintList->constraint[0].velocity;
			constraintList->constraint[0].end = constraintList->constraint[0].end;
			constraintList->constraint[0].environment = constraintList->constraint[0].environment;
		}
	}

	diagFF(dprdGetEnvironmentFromPosition(constraintList->constraint[constraintList->count - 1u].begin, environmentList, &tmpEnvironment));
	dynamicParamterSet = dprdGetDynamicSetPtr(dynamicParameters, tmpEnvironment);
	diagFF(dynamicParamterSet != NULL);

	constraintList->constraint[constraintList->count - 1u].end = INVALID_VALUE;
	if (constraintList->count > initialListCount + 1u)
	{
		/*\spec SW_MS_Innodrive2_Forecast_373*/
		constraintList->constraint[constraintList->count - 1u].velocity = min(constraintList->constraint[constraintList->count - 1u].velocity + dynamicParamterSet->offsetVelocity, dynamicParamterSet->maxVelocity);
		constraintList->constraint[constraintList->count - 1u].velocity = max(0.0f, constraintList->constraint[constraintList->count - 1u].velocity);
	}
	else
	{ /*Falls nur ein Geschwindigkeitslimit vorhanden ist, darf nicht dynamicParamterSet->offsetVelocity addiert werden, da diese Beschr�nkung immer die Setzgeschwindigkeit ist.*/
		constraintList->constraint[constraintList->count - 1u].velocity = min(constraintList->constraint[constraintList->count - 1u].velocity, dynamicParamterSet->maxVelocity);
		constraintList->constraint[constraintList->count - 1u].velocity = max(0.0f, constraintList->constraint[constraintList->count - 1u].velocity);
	}
	constraintList->constraint[constraintList->count - 1u].environment = tmpEnvironment;

	return true;
}


static bool_T	dprdCalcApproxBranch(	IN const	pathRouterMemory_T		*pathRouterMemory,
										IN const	mapPath_T				*mapPath,
										IN const	parameterSetCtrl_T		*parameterSet,
										IN const	real32_T				branchAnglePosition,
										IN const	real32_T				angle,
										IN const	bool_T					valid,
										INOUT		dprdReplaceCurvatures_T	*replaceCurvatures)
{
	real32_T	horizon = prtGetDistance(mapPath);
	real32_T	adjPosition = 0.0f;

	real32_T	before;
	real32_T	after;

	real32_T	curDiv;

	diagFF(replaceCurvatures->count < (uint8_T)dprdMAXBRANCHANGLE_COUNT);

	before	= 0.5f * parameterSet->driverPredictor.branch.length * parameterSet->driverPredictor.branch.factorIn;
	after	= 0.5f * parameterSet->driverPredictor.branch.length * parameterSet->driverPredictor.branch.factorOut;


	/* Berechnen des Umrechnungsfaktors von Abbiegewinkel auf Kr�mmungsoffset */
	curDiv		= parameterSet->driverPredictor.branch.length - 0.5f * (before + after);

	/*\spec SW_MS_Innodrive2_Forecast_382*/
	/*\spec SW_MS_Innodrive2_Forecast_380*/
	replaceCurvatures->curvatures[replaceCurvatures->count][0].curvatureOffset = 0.0f;
	replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset = angle / curDiv;
	replaceCurvatures->curvatures[replaceCurvatures->count][2].curvatureOffset = replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset;
	replaceCurvatures->curvatures[replaceCurvatures->count][3].curvatureOffset = 0.0f;

	if(branchAnglePosition > horizon)
	{
		adjPosition = horizon;
		replaceCurvatures->curvatures[replaceCurvatures->count][0].curvatureOffset = 0.0f;
		replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset = 0.0f;
		replaceCurvatures->curvatures[replaceCurvatures->count][2].curvatureOffset = 0.0f;
		replaceCurvatures->curvatures[replaceCurvatures->count][3].curvatureOffset = 0.0f;
	}
	else
	{
		adjPosition = branchAnglePosition;
	}

	diagFNaN(replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset);

	/*\spec \spec SW_MS_Innodrive2_Forecast_378*/
	replaceCurvatures->curvatures[replaceCurvatures->count][0].position = adjPosition - 0.5f * parameterSet->driverPredictor.branch.length;
	replaceCurvatures->curvatures[replaceCurvatures->count][1].position = replaceCurvatures->curvatures[replaceCurvatures->count][0].position + before;
	replaceCurvatures->curvatures[replaceCurvatures->count][3].position = adjPosition + 0.5f * parameterSet->driverPredictor.branch.length;
	replaceCurvatures->curvatures[replaceCurvatures->count][2].position = replaceCurvatures->curvatures[replaceCurvatures->count][3].position - after;

	if (!prtGetCurvatureAtPosition(	pathRouterMemory,
									replaceCurvatures->curvatures[replaceCurvatures->count][0].position,
								   &replaceCurvatures->curvatures[replaceCurvatures->count][0].curvature)) { 
		replaceCurvatures->curvatures[replaceCurvatures->count][0].curvature = 0.0f; 
	}
	if (!prtGetCurvatureAtPosition(	pathRouterMemory,
									replaceCurvatures->curvatures[replaceCurvatures->count][1].position,
								   &replaceCurvatures->curvatures[replaceCurvatures->count][1].curvature)) {
		replaceCurvatures->curvatures[replaceCurvatures->count][1].curvature = 0.0f; 
	}
	if (!prtGetCurvatureAtPosition( pathRouterMemory,
									replaceCurvatures->curvatures[replaceCurvatures->count][2].position, 
								   &replaceCurvatures->curvatures[replaceCurvatures->count][2].curvature)) {
		replaceCurvatures->curvatures[replaceCurvatures->count][1].curvature = 0.0f; 
	}
	if (!prtGetCurvatureAtPosition( pathRouterMemory, 
									replaceCurvatures->curvatures[replaceCurvatures->count][3].position, 
								   &replaceCurvatures->curvatures[replaceCurvatures->count][3].curvature)) {
		replaceCurvatures->curvatures[replaceCurvatures->count][1].curvature = 0.0f; 
	}

	if (!valid)
	{
		replaceCurvatures->curvatures[replaceCurvatures->count][0].position = INVALID_VALUE;
		replaceCurvatures->curvatures[replaceCurvatures->count][1].position = INVALID_VALUE;
		replaceCurvatures->curvatures[replaceCurvatures->count][2].position = INVALID_VALUE;
		replaceCurvatures->curvatures[replaceCurvatures->count][3].position = INVALID_VALUE;
		replaceCurvatures->curvatures[replaceCurvatures->count][0].curvatureOffset = 0.0f;
		replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset = 0.0f;
		replaceCurvatures->curvatures[replaceCurvatures->count][2].curvatureOffset = 0.0f;
		replaceCurvatures->curvatures[replaceCurvatures->count][3].curvatureOffset = 0.0f;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		replaceCurvatures->curvatures[replaceCurvatures->count][0].position = replaceCurvatures->curvatures[replaceCurvatures->count][0].position;
		replaceCurvatures->curvatures[replaceCurvatures->count][1].position = replaceCurvatures->curvatures[replaceCurvatures->count][1].position;
		replaceCurvatures->curvatures[replaceCurvatures->count][2].position = replaceCurvatures->curvatures[replaceCurvatures->count][2].position;
		replaceCurvatures->curvatures[replaceCurvatures->count][3].position = replaceCurvatures->curvatures[replaceCurvatures->count][3].position;
		replaceCurvatures->curvatures[replaceCurvatures->count][0].curvatureOffset = replaceCurvatures->curvatures[replaceCurvatures->count][0].curvatureOffset;
		replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset = replaceCurvatures->curvatures[replaceCurvatures->count][1].curvatureOffset;
		replaceCurvatures->curvatures[replaceCurvatures->count][2].curvatureOffset = replaceCurvatures->curvatures[replaceCurvatures->count][2].curvatureOffset;
		replaceCurvatures->curvatures[replaceCurvatures->count][3].curvatureOffset = replaceCurvatures->curvatures[replaceCurvatures->count][3].curvatureOffset;

		replaceCurvatures->count++;
	}
	
	return true;
}

static bool_T	insertCurvatures(	IN const	dprdCurvaturesStorage_T *curvatures,
									IN const	environmentList_T		*environmentList,
									IN const	dynamicParameters_T		*dynamicParameters,
									INOUT		constraintList_T		*constraintList,
									OUT			real32_T				*horizonEnd)
{
	uint8_T j = 0;
	uint8_T i;
	real32_T finalCurvature = INVALID_VALUE;
	const uint8_T initialConstraintCount = constraintList->count;
	const dynamicParameterSet_T *dynamicParamterSet = NULL;

	/*Berechnen aller Geschwindigkeiten und setzen der Endpositionen*/
	for (i = 0; i < (uint8_T)dprdCONSTRAINT_COUNT - 1u; i++)
	{
		real32_T	curvatureBegin = curvatures->curvatures[j].curvature;
		real32_T	curvatureEnd = INVALID_VALUE;
		uint8_T		nextElement = 1;
		constraint_T constraint;
		constraint.begin		= INVALID_VALUE;
		constraint.end			= INVALID_VALUE;
		constraint.type			= classCurvatureLimit;
		constraint.velocity		= INVALID_VALUE;
		constraint.environment	= invalid;

		/* setze Kurvenanfangsposition und Kurvenwert */
		if (initialConstraintCount <= i && j < curvatures->count)
		{
			diagFF(j < (uint8_T)dprdMAX_CURVATURES);
			constraint.begin	= curvatures->curvatures[j].position;  /* polyspace +1 RTE:OBAI "Pr�fung ob j < dprdMAX_CURVATURES" */
			curvatureBegin		= curvatures->curvatures[j].curvature;
		}
		else
		{
			constraint.begin	= 0.0f;
			curvatureBegin		= INVALID_VALUE;
		}

		/* setze Kurvenendposition und Kurvenwert */
		if (initialConstraintCount <= i && j + nextElement < curvatures->count)
		{
			diagFF(j + nextElement < (uint8_T)dprdMAX_CURVATURES);
			constraint.begin	= curvatures->curvatures[j].position; /*\spec SW_MS_Innodrive2_Forecast_383*/
			curvatureBegin		= curvatures->curvatures[j].curvature;
			constraint.end		= curvatures->curvatures[j + nextElement].position;
			curvatureEnd		= curvatures->curvatures[j + nextElement].curvature; /*\spec SW_MS_Innodrive2_Forecast_383*/
		}
		else
		{
			constraint.end	= INVALID_VALUE;
			curvatureEnd	= 0.0f;
		}

		if (fastfabsf(constraint.begin - constraint.end) <= ROUNDING_ERROR && j + 2u < curvatures->count)
		{ /* Es wurde eine doppelte Kurve gefunden, weshalb gepr�ft werden muss welche Betragsm��ig den gr��eren Kurvenwert hat */
			diagFF(initialConstraintCount <= i);
			nextElement = 2;
			diagFF(j + nextElement < (uint8_T)dprdMAX_CURVATURES);
			finalCurvature = max(fastfabsf(curvatureBegin), fastfabsf(curvatureEnd));
			curvatureEnd = curvatures->curvatures[j + nextElement].curvature;
			finalCurvature = max(fastfabsf(finalCurvature), fastfabsf(curvatureEnd));
			constraint.end = curvatures->curvatures[j + nextElement].position;
		}
		else
		{
			finalCurvature = max(fastfabsf(curvatureBegin), fastfabsf(curvatureEnd));
		}

		diagFF(dprdGetEnvironmentFromPosition(	constraint.begin,
												environmentList,
												&constraint.environment));
		dynamicParamterSet = dprdGetDynamicSetPtr(dynamicParameters, constraint.environment);
		diagFF(dynamicParamterSet != NULL);

		/*\spec SW_MS_Innodrive2_Forecast_383*/
		if (finalCurvature > 0.0f)
		{
			real32_T velSq = dynamicParamterSet->maxLatAcceleration / finalCurvature;
			diagFF(velSq >= 0.0f);
			constraint.velocity	= sqrtf(velSq);
		}
		else
		{
			real32_T velSq = dynamicParamterSet->maxLatAcceleration / 1.0f;
			diagFF(sqrtf(velSq) >= 0.0f);
			constraint.velocity	= INVALID_VALUE;
		}

		if (initialConstraintCount <= i && j < curvatures->count)
		{
			constraintList->constraint[i].begin			= constraint.begin;
			constraintList->constraint[i].end			= constraint.end;
			constraintList->constraint[i].type			= classCurvatureLimit;
			constraintList->constraint[i].velocity		= constraint.velocity;
			constraintList->constraint[i].environment	= constraint.environment;
			*horizonEnd = constraintList->constraint[constraintList->count].end;
			constraintList->count++;
			
			/* die Positionen waren gleich und d�rfen nicht in die Constraint Liste eingrtragen werden */
			j += nextElement;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			*horizonEnd = *horizonEnd;
			constraintList->count						= constraintList->count;
			constraintList->constraint[i].begin			= constraintList->constraint[i].begin;
			constraintList->constraint[i].end			= constraintList->constraint[i].end;
			constraintList->constraint[i].type			= constraintList->constraint[i].type;
			constraintList->constraint[i].velocity		= constraintList->constraint[i].velocity;
			constraintList->constraint[i].environment	= constraintList->constraint[i].environment;

			j = j;
		}		
	}

	return true;
}

static bool_T	getCurvatureBegins(	IN const	mapPath_T				*mapPath,
									IN const	pathRouterMemory_T		*pathRouterMemory,
									INOUT		dprdReplaceCurvatures_T	*replaceCurvatures,
									OUT 		dprdCurvaturesStorage_T	*curvatures)
{
	int16_T minIndex = -1;
	uint16_T i;
	uint8_T j = 0;
	bool_T valid = false;
	dprdPosCurv_T mapPathCurvature;
	curvatureIterator_T iter;
	dprdPosCurv_T minPosCurvature;
	diagFF(prtGetCurvatureIterator(mapPath, &iter));

	memset(&mapPathCurvature, 0, sizeof(dprdPosCurv_T));
	mapPathCurvature.curvature = 0.0f;
	mapPathCurvature.position = INVALID_VALUE;

	/*\spec SW_MS_Innodrive2_Forecast_377*/
	diagFF(prtGetNextCurvature(&iter, &valid, &mapPathCurvature.position, &mapPathCurvature.curvature));
	minPosCurvature = mapPathCurvature;
	/*f�ge alle St�tzstellen- und mapPath-Kurven in die curvatures Liste ein*/
	for (i = 0; i < (uint8_T)dprdMAX_CURVATURES; i++)
	{
		/* Suche kleinste Position */
		for (j = 0; j < (uint8_T)dprdMAXBRANCHANGLE_COUNT; j++)
		{
			if (j < replaceCurvatures->count && 
				replaceCurvatures->nextIndex[j] < (uint8_T)dprdMAX_REPLACE_CURVATURES &&
				replaceCurvatures->curvatures[j][replaceCurvatures->nextIndex[j]].position < minPosCurvature.position)
			{
				minIndex = (int16_T)j;
				minPosCurvature.position = replaceCurvatures->curvatures[j][replaceCurvatures->nextIndex[j]].position;
				minPosCurvature.curvature = replaceCurvatures->curvatures[j][replaceCurvatures->nextIndex[j]].curvature;
			}
			else
			{ /*konstante Laufzeit realisieren*/
				minIndex = minIndex;
				minPosCurvature.position = minPosCurvature.position;
				minPosCurvature.curvature = minPosCurvature.curvature;
			}
		}

		if ((valid || minIndex > -1) && curvatures->count < (uint8_T)dprdMAX_CURVATURES)
		{
			curvatures->curvatures[curvatures->count].position = minPosCurvature.position;
			curvatures->curvatures[curvatures->count].curvature = minPosCurvature.curvature;
			if (minIndex > -1)
			{
				/*\spec SW_MS_Innodrive2_Forecast_377*/
				if (prtGetCurvatureAtPosition(pathRouterMemory, curvatures->curvatures[curvatures->count].position, &curvatures->curvatures[curvatures->count].curvature))
				{/*g�ltige Kurvenst�tzstelle in die curvatures Liste eintragen*/
					curvatures->count++;
				}
			}
			else
			{
				curvatures->count++;
			}
		}

		if (minIndex <= -1)
		{ /*wenn keine Kurve mehr verf�gbar ist, wird die n�chste aus dem mapPath geholt*/
			/*\spec SW_MS_Innodrive2_Forecast_377*/
			diagFF(prtGetNextCurvature(&iter, &valid, &mapPathCurvature.position, &mapPathCurvature.curvature));

			if (valid && curvatures->count < (uint8_T)dprdMAX_CURVATURES)
			{
				minPosCurvature.position  = mapPathCurvature.position;
				minPosCurvature.curvature = mapPathCurvature.curvature;
			}
			else
			{
				minPosCurvature.position = INVALID_VALUE;
				minPosCurvature.curvature = 0.0f;
			}
		}
		else
		{
			if (minIndex < (int16_T)dprdMAX_REPLACE_CURVATURES && curvatures->count < (uint8_T)dprdMAX_CURVATURES)
			{		
				replaceCurvatures->nextIndex[minIndex]++;
				minIndex = -1;

				if (valid)
				{ /*speichere n�chste Position einer Kurve, die in die curvatures Liste eingetraten werden soll*/
					minPosCurvature.position = mapPathCurvature.position;
					minPosCurvature.curvature = mapPathCurvature.curvature;
				}
			}
			else
			{ /*konstante Laufzeit realisieren*/
				replaceCurvatures->nextIndex[0] = replaceCurvatures->nextIndex[0];
				minIndex = -1;
			}
		}
	}

	return true;
}

static bool_T	addCurvatureOffset(	IN const	parameterSetCtrl_T		*parameterSet,
									IN const	dprdReplaceCurvatures_T	*replaceCurvatures,
									INOUT 		dprdCurvaturesStorage_T	*curvatures)
{
	uint8_T i;
	uint8_T j = 0;
	real32_T slopeLeft;
	real32_T slopeRight;

	slopeLeft = 1.0f / (0.5f * parameterSet->driverPredictor.branch.length * parameterSet->driverPredictor.branch.factorIn);
	slopeRight = 1.0f / (0.5f * parameterSet->driverPredictor.branch.length * parameterSet->driverPredictor.branch.factorOut);

	for (i = 0; i < (uint8_T)dprdMAXBRANCHANGLE_COUNT; i++)
	{
		for (j = 0; j < (uint8_T)dprdMAX_CURVATURES; j++)
		{
			real32_T factor = 0.0f;
			real32_T position = curvatures->curvatures[j].position;
			if (replaceCurvatures->curvatures[i][0].position <= position && position < replaceCurvatures->curvatures[i][1].position)
			{
				factor = (position - replaceCurvatures->curvatures[i][0].position) * slopeLeft;
			}

			if (replaceCurvatures->curvatures[i][1].position <= position && position < replaceCurvatures->curvatures[i][2].position)
			{
				factor = 1.0f;
			}

			if (replaceCurvatures->curvatures[i][2].position <= position && position < replaceCurvatures->curvatures[i][3].position)
			{
				factor = 1.0f + (position - replaceCurvatures->curvatures[i][2].position) * slopeRight;
			}

			factor = max(factor, 0.0f);
			factor = min(factor, 1.0f);

			if (j < curvatures->count && i < replaceCurvatures->count)
			{
				/*\spec SW_MS_Innodrive2_Forecast_382*/
				/*\spec SW_MS_Innodrive2_Forecast_380*/
				/*\spec SW_MS_Innodrive2_Forecast_381*/
				curvatures->curvatures[j].curvature += factor*replaceCurvatures->curvatures[i][1].curvatureOffset;
			}
			else
			{ /*konstante Laufzeit realisieren*/
				curvatures->curvatures[j].curvature = curvatures->curvatures[j].curvature;
			}
		}
	}

	return true;
}


void dprdInitConstraintSet(OUT constraintSet_T *constraintSet)
{
	uint8_T i;
	memset(constraintSet, 0, sizeof(constraintSet_T));
	for (i = (uint8_T)0; i < (uint8_T)dprdCONSTRAINT_COUNT; i++)
	{
		constraintSet->constraintList.constraint[i].type = classInvalid;
		constraintSet->constraintList.constraint[i].environment = invalid;
	}
}


static bool_T	dprdAppendConstraint(	IN const	constraint_T		*constraint,
										INOUT		constraintList_T	*constraintList)
{
	/*Schutz vor Schreiben out of bounds*/
	diagFF(constraintList->count < (uint8_T)dprdCONSTRAINT_COUNT);
	diagFF(constraintList->constraint[constraintList->count].type == classInvalid);

	/*Schreiben*/
	if (constraint->begin != INVALID_VALUE)
	{
		constraintList->constraint[constraintList->count] = *constraint;
		constraintList->count++;
	}
	else
	{
		constraintList->constraint[constraintList->count] = constraintList->constraint[constraintList->count];
		constraintList->count = constraintList->count;
	}

	return true;
}


bool_T		dprdGetConstraintList(	IN const	parameterSetCtrl_T	*parameterSet,
									IN const	vmState_T			*currentVMSate,
									IN const	driverState_T		*driverState,
									IN const	pathRouterMemory_T	*pathRouterMemory,
									IN const	mapPath_T			*mapPath,
									IN const	environmentList_T	*environmentList,
									IN const	dynamicParameters_T	*dynamicParameters,
									IN const	real32_T			 vehiclePosition,
									OUT			constraintSet_T		*constraintSet)
{
	real32_T horizonEnd = INVALID_VALUE;

	/*Initialisierung*/
	dprdInitConstraintSet(constraintSet);

	constraintSet->horizonEnd = prtGetDistance(mapPath);

	constraintSet->offset.speedLimit = 0u;
	/*Tempolimits*/
	diagFF(dprdGetSpeedLimitList(	parameterSet,
									driverState, 
									mapPath, 
									environmentList, 
									dynamicParameters,
									vehiclePosition,
									&constraintSet->constraintList,
									&horizonEnd));

	constraintSet->count.speedLimit = constraintSet->constraintList.count;
	constraintSet->offset.onlineLimit = constraintSet->constraintList.count;

	constraintSet->horizonEnd = min(constraintSet->horizonEnd, horizonEnd);
	

	/*Onlinelimits*/
	diagFF(dprdGetOnlineLimitList(	parameterSet,
									currentVMSate,
									pathRouterMemory,
									environmentList,
									&constraintSet->constraintList));
	
	constraintSet->count.onlineLimit = constraintSet->constraintList.count - constraintSet->count.speedLimit;
	constraintSet->offset.curvatureLimit = constraintSet->constraintList.count;

	/*\spec SW_MS_Innodrive2_Forecast_370*/
	constraintSet->horizonEnd = min(constraintSet->horizonEnd, horizonEnd);


	/*Kr�mmungslimits*/
	diagFF(dprdGetCurvatureList(	parameterSet,
									mapPath,
									pathRouterMemory,
									environmentList, 
									dynamicParameters,
									&constraintSet->constraintList,
									&horizonEnd));

	constraintSet->count.curvatureLimit = (constraintSet->constraintList.count - constraintSet->count.onlineLimit) - constraintSet->count.speedLimit;

	/*\spec SW_MS_Innodrive2_Forecast_379*/
	constraintSet->horizonEnd = min(constraintSet->horizonEnd, horizonEnd);
	
	return true;
}


static bool_T	dprdGetSpeedLimitList(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	driverState_T		*driverState,
										IN const	mapPath_T			*mapPath,
										IN const	environmentList_T	*environmentList,
										IN const	dynamicParameters_T	*dynamicParameters,
										IN const	real32_T			 vehiclePosition,
										INOUT		constraintList_T	*constraintList,
										OUT			real32_T			*horizonEnd)
{
	constraint_T	constraint;
	const uint8_T	initialListCount = constraintList->count;
	dobsEnvironment_T dobsEnvironment = dobsGetEnvironment(driverState);
	const dynamicParameterSet_T *dynamicParameterSet = dprdGetDynamicSetPtr(dynamicParameters, dobsEnvironment);
	/*\spec SW_MS_Innodrive2_Forecast_369*/
	real32_T dobsDesiredSpeed = dobsGetDesiredSpeed(driverState);
	
	diagFF(dynamicParameterSet);
	
	/* setze constraint lokal zu classSpeedLimit */
	constraint.type			= classSpeedLimit;
	constraint.environment	= invalid;

	/* hinzuf�gen der Geschwindigkeit vWunsch */
	/*\spec SW_MS_Innodrive2_Forecast_369*/
	constraint.begin = vehiclePosition;
	constraint.velocity = min(dynamicParameterSet->maxVelocity, dobsDesiredSpeed); /*\spec SW_MS_Innodrive2_Forecast_359*/

	diagFF(dprdAppendConstraint(&constraint, constraintList));

	diagFF(dprdGetSpeedLimitBegin(parameterSet, mapPath, driverState, constraintList));
	diagFF(dprdGetSpeedLimitEnd(initialListCount, environmentList, parameterSet, dynamicParameters, constraintList));
	
	/* das Ende des letzten Geschwindigkeitslimits ist zum Zeitpunkt des verlassens der Funktion nicht bekannt und wird deshalb auf INVALID_VALUE gesetzt */
	*horizonEnd = INVALID_VALUE;

	return true;
}


static bool_T		dprdGetOnlineLimitList(	IN const	parameterSetCtrl_T	*parameterSet,
											IN const	vmState_T			*currentVMSate,
											IN const	pathRouterMemory_T	*pathRouterMemory,
											IN const	environmentList_T	*environmentList,
											INOUT		constraintList_T	*constraintList)
{
	uint16_T i;


	prtSpeedLimit_T onlineSpeedLimit;
	const uint8_T initialConstraintCount = constraintList->count;
	uint16_T maxOnlineLimits = prtGetOnlineSpeedCount(pathRouterMemory);
	dobsEnvironment_T environment = invalid;
	constraint_T constraint;
	prtSpeedLimit_T maxSpeedAtPosition;
	bool_T valid = false;
	bool_T lastValid = false;
	
	
	constraint.type = classOnlineLimit;

	for (i = 0; i < (uint8_T)dprdSPEEDLIMITCOUNT; i++)
	{
		if (i < maxOnlineLimits && i < parameterSet->driverPredictor.prepCount.onlineLimit)
		{
			diagFF(prtGetOnlineSpeed(pathRouterMemory, i, &onlineSpeedLimit));
			/*\spec SW_MS_Innodrive2_Forecast_374*/
			onlineSpeedLimit.limit = onlineSpeedLimit.limit;
			onlineSpeedLimit.position = currentVMSate->position > onlineSpeedLimit.position ? currentVMSate->position : onlineSpeedLimit.position;
			
			diagFF(dprdGetEnvironmentFromPosition(onlineSpeedLimit.position, environmentList, &environment));
			environment = environment;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			(void)prtGetOnlineSpeed(pathRouterMemory, (uint16_T)0, &onlineSpeedLimit);
			onlineSpeedLimit.limit = INVALID_VALUE;
			onlineSpeedLimit.position = currentVMSate->position > onlineSpeedLimit.position ? INVALID_VALUE : INVALID_VALUE;
			
			(void)dprdGetEnvironmentFromPosition(onlineSpeedLimit.position, environmentList, &environment);
			environment = invalid;
		}

		valid = prtGetCurrentSpeedLimit(pathRouterMemory, onlineSpeedLimit.position, &maxSpeedAtPosition);
		valid = isValidOnlineLimit(&maxSpeedAtPosition, parameterSet, &onlineSpeedLimit) && valid;

		if (lastValid) {
			/* Bedingung kann nur erf�llt sein, wenn bereits mindestens ein Online-Limit in die Liste eingef�gt wurde - daher Zugriff immer auf ein Online-Limit */
			constraintList->constraint[constraintList->count - 1u].end = onlineSpeedLimit.position;
		}
		else { /*konstante Laufzeit realisieren*/
			constraintList->constraint[0u].end = constraintList->constraint[0u].end;
		}

		if (!valid)
		{
			onlineSpeedLimit.limit = INVALID_VALUE;
			onlineSpeedLimit.position = INVALID_VALUE;
		}
		else
		{ /*konstante Laufzeit realisieren*/
			onlineSpeedLimit.limit = onlineSpeedLimit.limit;
			onlineSpeedLimit.position = onlineSpeedLimit.position;
		}

		constraint.environment = environment;
		constraint.velocity = onlineSpeedLimit.limit;
		/*Beschr�nkungen durch Onlineverkehr werden nur au�erhalb der Umgebung Stadt ber�cksichtigt.*/
		constraint.begin = environment == city ? INVALID_VALUE : onlineSpeedLimit.position;
		/*\spec SW_MS_Innodrive2_Forecast_374*/
		constraint.begin = valid ? onlineSpeedLimit.position : INVALID_VALUE;

		diagFF(dprdAppendConstraint(&constraint, constraintList));

		lastValid = valid;
	}

	diagFF(constraintList->count <= (uint8_T)dprdCONSTRAINT_COUNT);
	
	if (initialConstraintCount < constraintList->count && valid)
	{ /*Bei der letzten Online-Limit-Beschr�nkung wird das Ende immer als unendlich angenommen (INVALID_VALUE), solange es nicht bereits durch ein nicht-relevantes Online-Limit festgelegt wurde. */
		constraintList->constraint[constraintList->count - 1u].end = INVALID_VALUE;
	}
	else
	{ /*konstante Laufzeit realisieren*/
		constraintList->constraint[0].end = constraintList->constraint[0].end;
	}

	return true;
}


static bool_T	dprdGetCurvatureList(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	mapPath_T			*mapPath,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	environmentList_T	*environmentList,
										IN const	dynamicParameters_T	*dynamicParameters,
										INOUT		constraintList_T	*constraintList,
										OUT			real32_T			*horizonEnd)
{
	uint16_T i;
	dprdCurvaturesStorage_T	curvatures;
	prtBranchAngle_T		branchAngles[dprdMAXBRANCHANGLE_COUNT];
	dprdReplaceCurvatures_T	replaceCurvatures;
	uint16_T				branchAngleCount = prtGetBranchAngleCount(mapPath);

	memset(&curvatures, 0, sizeof(dprdCurvaturesStorage_T));
	memset(&replaceCurvatures, 0, sizeof(dprdReplaceCurvatures_T));

	/*Abfragen und speichern aller Abzweigwinkel*/
	for (i = 0; i < (uint8_T)dprdMAXBRANCHANGLE_COUNT; i++)
	{
		branchAngles[i].angle = 0.0f;
		if (i < branchAngleCount)
		{
			diagFF(prtGetBranchAngle(mapPath, i, &branchAngles[i])); /*\spec SW_MS_Innodrive2_Forecast_378*/
			/*Umrechnen in Radian*/
			branchAngles[i].angle *= -defPIf / 180.0f;
		}
		else
		{	/*Realisierung der konstanten Laufzeit*/
			branchAngles[i].angle *= -defPIf / 180.0f;
			(void)prtGetBranchAngle(mapPath, i, &branchAngles[i]);
		}
	}

	/*Berechnung der St�tzstellen bei Abzweigwinkeln*/
	for (i = 0; i < (uint8_T)dprdMAXBRANCHANGLE_COUNT; i++)
	{
		const uint16_T iOffset = (uint16_T)i * (uint16_T)dprdMAX_REPLACE_CURVATURES; /*lint !e734 (Info -- Loss of precision (initialization) (18 bits to 16 bits))*/
		diagFF(iOffset < (uint16_T)dprdMAXBRANCHANGLE_COUNT*4u);

		if (i < branchAngleCount)
		{
			diagFF(dprdCalcApproxBranch(pathRouterMemory, mapPath, parameterSet, branchAngles[i].position, branchAngles[i].angle, true, &replaceCurvatures));
		}
		else
		{	/*Realisierung der konstanten Laufzeit*/
			(void)dprdCalcApproxBranch(pathRouterMemory, mapPath, parameterSet, branchAngles[i].position, branchAngles[i].angle, false, &replaceCurvatures);
			replaceCurvatures.curvatures[i][0].curvature = INVALID_VALUE;
			replaceCurvatures.curvatures[i][1].curvature = INVALID_VALUE;
			replaceCurvatures.curvatures[i][2].curvature = INVALID_VALUE;
			replaceCurvatures.curvatures[i][3].curvature = INVALID_VALUE;
			
			replaceCurvatures.curvatures[i][0].position = INVALID_VALUE;
			replaceCurvatures.curvatures[i][1].position = INVALID_VALUE;
			replaceCurvatures.curvatures[i][2].position = INVALID_VALUE;
			replaceCurvatures.curvatures[i][3].position = INVALID_VALUE;
		}
	}

	diagFF(getCurvatureBegins(mapPath, pathRouterMemory, &replaceCurvatures, &curvatures));
	diagFF(addCurvatureOffset(parameterSet, &replaceCurvatures, &curvatures));
	
	diagFF(curvatures.count <= (uint8_T)dprdMAX_CURVATURES);
	
	diagFF(insertCurvatures(&curvatures, environmentList, dynamicParameters, constraintList, horizonEnd));

	return true;
}


bool_T	isValidOnlineLimit(	IN const	prtSpeedLimit_T		*maxSpeedAtPosition,
							IN const	parameterSetCtrl_T	*parameterSet,
							IN const	prtSpeedLimit_T		*onlineSpeedLimit)
{
	bool_T valid = false;

	if (maxSpeedAtPosition->raw == (uint16_T)rawLimitReleased)
	{ /*unbeschr�nkte Abschnitte*/
		/*	Wenn die Flie�geschwindigkeit einen applizierbaren Wert unterschreitet, wird die Einschr�nkung durch Onlineverkehr ber�cksichtigt*/
		valid = onlineSpeedLimit->limit < parameterSet->driverPredictor.onlineLimit.maxSpeedLimit ? true : false;
	}
	else
	{ /*beschr�nkte Abschnitte*/
		/*	Wenn die Flie�geschwindigkeit kleiner als ein applizierbarer Faktor mal dem g�ltigen Speedlimit, oder kleiner als das Speedlimit abz�glich eines
		applizierbaren Werts ist, wird die Einschr�nkung durch Onlineverkehr ber�cksichtigt */
		valid =	onlineSpeedLimit->limit < maxSpeedAtPosition->limit - parameterSet->driverPredictor.onlineLimit.offset ||
				onlineSpeedLimit->limit < maxSpeedAtPosition->limit * parameterSet->driverPredictor.onlineLimit.factor ?
					true : false;
	}

	valid = valid && (maxSpeedAtPosition->limit == INVALID_VALUE || maxSpeedAtPosition->position == INVALID_VALUE ? false : true);

	return valid;
}
