#ifndef guard_dprdParametersStatic_h
#define guard_dprdParametersStatic_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_private.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"


/**\brief Kopiert die Fahrdynamikparameter f�r eine Umgebung.

\spec SW_MS_Innodrive2_Forecast_390

\ingroup driverPredictor_parameters
*/
static bool_T	dprdInitDynamicParameterSet(IN const	parameterSetCtrl_T		*parameterSet,				/**<Globale Parameter*/
											IN const	dynamicSet_T			*dobsDynamicSet,			/**<Umgebungsspezifischer Fahrdynamikparametersatz*/
											IN const	real32_T				maxVelocity,				/**<Maximal zul�ssige Geschwindigkeit.*/
											OUT			dynamicParameterSet_T	*dynamicParameterSet		/**<Zeiger auf eine dynamische Parameter Struktur, die initialisiert werden soll.*/
											);
#endif
