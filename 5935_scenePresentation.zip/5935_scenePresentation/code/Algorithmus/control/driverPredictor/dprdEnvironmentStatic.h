#ifndef guard_dprdEnvironmentStatic_h
#define guard_dprdEnvironmentStatic_h

#include "control/control.h"
#include "control/driverPredictor/driverpredictor_private.h"
#include "control/parameterSet/ParameterSetCtrl_interface.h"

typedef enum
{
	limitInvalid		= -1,
	limitSpeedLimit		=  0,
	limitDynamicEvent	=  1,
	limitBuiltUpArea	=  2,
	limitOnlineLimit	=  3
}limitCategory_T;

typedef struct _limitState
{
	uint16_T			builtUpAreaCount;		/**<Z�hlvariable f�r builtUpAreas*/
	uint16_T			speedLimitCount;		/**<Z�hlvariable f�r Geschwindigkeitsbeschr�nkungen*/
	uint16_T			dynamicEventCount;		/**<Z�hlvariable f�r dynamische Events*/
	uint16_T			onlineLimitCount;		/**<Z�hlvariable f�r Onlineverkehr*/
	prtBuiltUpArea_T	builtUpArea;			/**<Au�er- oder Innortsposition*/
	prtSpeedLimit_T		speedLimit;				/**<Tempolimit an Zielposition*/
	prtDynamicEvent_T	dynamicEvent;			/**<Dynamikevent*/
	prtSpeedLimit_T		onlineLimit;			/**<OnlineLimit*/
}limitState_T;




/**\brief Bildet das Minimum aus den Positionen builtUpArea, speedLimit und dynamicEvent.

\ingroup driverPredictor_environment
*/
static real32_T getMinPos(	IN const	limitState_T		*limitState,		/**<Enth�lt alle verf�gbaren Beschr�nkungen wie speedLimit, builtUpArea, onlineLimit und dynamicEvents*/
							IN const	real32_T			position,			/**<Aktuelle Position*/
							OUT			limitCategory_T		*limitCategory		/**<Kategorie des gefundenen Minimums*/
							);

/**\brief  Erh�ht die Z�hlvariablen in limitState enstprechend zu `position`.

\ingroup driverPredictor_environment
*/
static bool_T getLimitIndices(	IN const	real32_T			position,				/**<Aktuelle Position*/
								IN const	pathRouterMemory_T	*pathRouterMemory,		/**<persistente Daten des pathRouter*/
								IN const	mapPath_T			*mapPath,				/**<Ausged�nnte Kartendaten aus dem Modul pathRouter*/
								INOUT		limitState_T		*limitState				/**<Zustandsstruktur zum bestimmen der Begrenzungen*/
								);

/**\brief Bestimmt eine Umgebung anhand der �bergebenen Eingangsparameter.

\spec SW_MS_Innodrive2_Forecast_366
\spec SW_MS_Innodrive2_Forecast_362
\spec SW_MS_Innodrive2_Forecast_363
\spec SW_MS_Innodrive2_Forecast_364

\ingroup driverPredictor_environment
*/
static bool_T getEnvironmentFromLimits(	IN const	pathRouterMemory_T	*pathRouterMemory,			/**<persistente Daten des pathRouter*/
										IN const	parameterSetCtrl_T	*parameterSet,				/**<Globale Parameter*/
										IN const	limitCategory_T		limitCategory,				/**<Bestimmt welche Grenze (Inner- bzw. Au�erorts, Geschwindigkeitsbegrenzung oder dynamisches Event genutzt werden soll um eine Umgebung zu bestimmen*/
										IN const	environment_T		*lastValidEnvironment,		/**<Letzte g�ltige Umgebung mit Position*/
										IN const	limitState_T		*limitState,				/**<Zustandsstruktur zum bestimmen der Begrenzungen*/
										INOUT		bool_T				*isRadar,					/**<Gibt an ob sich das Fahrzeug im Radarzustand befindet*/
										INOUT		real32_T			*dynamicEventPosition,		/**<Sobald diese Variable ungleich INVALID_VALUE, ist ein Fahrdynamikevent aufgetreten*/
										OUT			environment_T		*environment				/**<Umgebung siehe dobsEnvironment_T*/
										);

/**\brief F�gt eine neue g�ltige Umgebung in die Liste ein.

\ingroup driverPredictor_environment
*/
static bool_T dprdAppendEnvironment(	IN const	real32_T			begin,						/**<Anfangsposition der Umgebung*/
										IN const	dobsEnvironment_T	environment,				/**<Umgebung siehe dobsEnvironment_T*/
										INOUT		environmentList_T	*environmentList,			/**<Liste der Umgebungen mit Positionen*/
										OUT			environment_T		*lastValidEnvironment		/**<Letzte g�ltige Umgebung mit Position*/
										);



#endif
