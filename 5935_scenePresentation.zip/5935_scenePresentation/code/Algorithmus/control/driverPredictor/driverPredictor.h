#ifndef guard_driverPredictor_h
#define guard_driverPredictor_h

#include "control/control.h"

#include "control/driverPredictor/driverPredictor_interface.h"
#include "control/driverObserver/driverObserver_interface.h"
#include "control/inputCodec/inputCodec_interface.h"
#include "common/vehicleModel/vehicleModel.h"



/** \brief Die Hauptaufgabe dieser Funktion ist es den Fehlerzustand von \ref stepDriverPredictor() abzufangen.

	\spec SW_MS_Innodrive2_Forecast_152

\ingroup driverPredictor
*/
void	driverPredictor(	IN const	vehicleModel_T			*vehicleModel,				/**<Fahrzeugmodell*/
							IN const	vehicleInput_T			*vehicleInput,				/**<Eingangssignale (hier f�r Kodierflag `ignoreCountry`)*/
							IN const	vehicleState_T			*vehicleState,				/**<Fahrzeugzustand aus dem Modul vehicleObserver*/
							IN const	driverState_T			*driverState,				/**<Private Struktur des driverObserver*/
							IN const	mapPath_T				*mapPath,					/**<Ausged�nnte Kartendaten aus dem Modul pathRouter*/
							IN const	pathRouterMemory_T		*pathRouterMemory,			/**<Persistente Daten des pathRouter, die nur im Control-Task zur Verf�gung stehen.*/
							INOUT		driverPredictorMemory_T	*driverPredictorMemory,		/**<Private Struktur des driverPredictor*/
							OUT			driverPrediction_T		*driverPrediction			/**<Ausgangsstruktur des driverPredictors*/
							);




#endif
