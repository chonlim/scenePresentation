#include "control/driverPredictor/dprdStep.h"
#include "control/driverPredictor/dprdParameters.h"
#include "control/driverPredictor/dprdConstraints.h"
#include "control/driverPredictor/dprdEnvironment.h"
#include "control/parameterSet/ParameterSetCtrl.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "control/driverPredictor/driverpredictor_private.h"
#include "control/driverPredictor/dprdTrajectory.h"
#include "control/driverPredictor/dprdOutput.h"
#include "control/systemController/sysCountryCode.h"

#include "control/inputCodec/inputCodec_private.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_dprdStep)


bool_T	stepDriverPredictor(			IN const	vehicleModel_T		*vehicleModel,
										IN const	vehicleInput_T		*vehicleInput,
										IN const	vehicleState_T		*vehicleState,
										IN const	driverState_T		*driverState,
										IN const	mapPath_T			*mapPath,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										INOUT		driverPredictorMemory_T *driverPredictorMemory,
										OUT			driverPrediction_T	*driverPrediction)
{
	uint8_T						i = 0;
	environmentList_T			environmentList;
	const parameterSetCtrl_T	*parameterSet = prmGetParameterSetCtrl(); /*\spec SW_MS_Innodrive2_Forecast_145*/
	const uint8_T				countryCode = prtGetCountryCode(pathRouterMemory);

	bool_T valid;
	vobsIsValid(vehicleState, &valid);

	valid = prtGetStatus(mapPath) && valid;
	valid = prtIsMemoryValid(pathRouterMemory) && valid;	/*\spec SW_MS_Innodrive2_Forecast_145*/
															/*\spec SW_MS_Innodrive2_Forecast_152*/
	
	valid = sysIsCountryOk(countryCode, vehicleInput->driver.ignoreCountry) && valid; /*\spec SW_AS_PIF_679*/

	if (!valid)
	{
		/*Wenn mehr als ein Takt die Kartendaten ung�ltig sind, werden die Ausgangsdaten als ung�ltig markiert.*/
		if (driverPredictorMemory->state == dprdStateCalcEnvironment)
		{
			driverPredictorMemory->hasValidPrediction = false;
		}
		
		/*keine g�ltigen Kartendaten vorhanden, weshalb die Berechnung unterbrochen wird und wieder auf den Anfang gesetzt wird*/
		driverPredictorMemory->state = dprdStateCalcEnvironment;

		memset(driverPrediction, 0, sizeof(driverPrediction_T));

		/*toggleBit so lassen, wie es ist.*/
		driverPrediction->toggleBit = driverPredictorMemory->toggleBit;

		return true;
	}

	switch (driverPredictorMemory->state)
	{
		case dprdStateCalcEnvironment:
			driverPredictorMemory->state = dprdStateCalcTrajectory;
			driverPredictorMemory->dprdWindowIndex = shortTermWindow;

			memset(&driverPredictorMemory->trajectory, 0, sizeof(trajectory_T));
			memset(&environmentList, 0, sizeof(environmentList_T));
			for (i = 0; i < (uint8_T)dprdENVIRONMENT_COUNT; i++)
			{
				environmentList.environment[i].environment = invalid;
			}
			environmentList.horizon = INVALID_VALUE;
			dprdInitConstraintSet(&driverPredictorMemory->constraintSet);
			memset(&driverPredictorMemory->tempDriverPrediction, 0, sizeof(driverPrediction_T));
	
			/*\spec SW_MS_Innodrive2_Forecast_145*/
			/*\spec SW_MS_Innodrive2_Forecast_341*/
			vobsGetVMState(vehicleState, &driverPredictorMemory->startVector);

			diagFF(dprdInitDynamicParameters(parameterSet, driverState, &driverPredictorMemory->dynamicParameters));

			diagFF(dprdInitEnvironmentList(	driverState,
											parameterSet,
											pathRouterMemory,
											mapPath,
											&driverPredictorMemory->dynamicEventPosition,
											&environmentList));

			diagFF(dprdGetConstraintList(	parameterSet,
											&driverPredictorMemory->startVector,
											driverState,
											pathRouterMemory,
											mapPath,
											&environmentList,
											&driverPredictorMemory->dynamicParameters,
											driverPredictorMemory->startVector.position,
											&driverPredictorMemory->constraintSet));

			{/* Debug Ausgaben speichern */
				driverPredictorMemory->debugDriverPrediction.environmentList = environmentList;
			}/* Debug Ausgaben speichern */
		break;

		case dprdStateCalcTrajectory:
			driverPredictorMemory->tempDriverPrediction.isValidPrediction = false; /*\spec SW_MS_Innodrive2_Forecast_339*/

			if (driverPredictorMemory->dprdWindowIndex == shortTermWindow)
			{
				memset(&driverPredictorMemory->trajectory, 0, sizeof(trajectory_T));
			}
	
			/* berechne Trajektorie */
			diagFF(dprdGetTrajectory(	vehicleModel,
										pathRouterMemory,
										parameterSet,
										driverPredictorMemory->dynamicEventPosition,
										driverPredictorMemory->dprdWindowIndex,
										&driverPredictorMemory->constraintSet,
										&driverPredictorMemory->startVector,
										&driverPredictorMemory->debugDriverPrediction.environmentList,
										&driverPredictorMemory->dynamicParameters,
 										&driverPredictorMemory->trajectory));

			/* Ausgangscontainer mit Daten bef�llen */
			diagFF(dprdGetOutputContainer(	parameterSet,
											&driverPredictorMemory->trajectory,
											driverPredictorMemory->dprdWindowIndex,
											&driverPredictorMemory->tempDriverPrediction));

			switch(driverPredictorMemory->dprdWindowIndex)
			{
			case shortTermWindow:	 driverPredictorMemory->dprdWindowIndex = midTermWindow;		break;
			case midTermWindow:		 driverPredictorMemory->dprdWindowIndex = longTermWindow;		break;
			case longTermWindow:	 driverPredictorMemory->dprdWindowIndex = invalidWindowIndex;	break;
			case invalidWindowIndex: valid = false;													break;
			default: diagFUnreachable();
			}/*lint !e9077*/

			if (driverPredictorMemory->dprdWindowIndex >= invalidWindowIndex)
			{
				driverPredictorMemory->hasValidPrediction = true;
				driverPredictorMemory->state = dprdStateCalcEnvironment;
				
				driverPredictorMemory->tempDriverPrediction.isValidPrediction = true; /*\spec SW_MS_Innodrive2_Forecast_154*/
				driverPredictorMemory->lastValidDriverPrediction = driverPredictorMemory->tempDriverPrediction;

				{/* Debug Ausgaben speichern */
					driverPredictorMemory->debugDriverPrediction.trajectory = driverPredictorMemory->trajectory;
				}/* Debug Ausgaben speichern */
			}
		break;

		case dprdStateInvalid:
			valid = false;
			break;

		default: diagFUnreachable();
	}/*lint !e9077*/

	diagFF(valid);

	if (driverPredictorMemory->hasValidPrediction)
	{
		memset(driverPrediction, 0, sizeof(driverPrediction_T));
		*driverPrediction = driverPredictorMemory->lastValidDriverPrediction;
	}
	else
	{
		/*konstante Laufzeit realisieren*/
		*driverPrediction = driverPredictorMemory->lastValidDriverPrediction;
		memset(driverPrediction, 0, sizeof(driverPrediction_T));
	}

	/*Toggle Bit ver�ndern, wenn g�ltige Daten vorhanden sind*/
	driverPredictorMemory->toggleBit	= !driverPredictorMemory->toggleBit; /*\spec SW_MS_Innodrive2_Forecast_152*/
	driverPrediction->toggleBit			= driverPredictorMemory->toggleBit;

	return true;
}
