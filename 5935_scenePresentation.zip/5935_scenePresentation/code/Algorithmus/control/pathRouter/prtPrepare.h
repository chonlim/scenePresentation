#ifndef guard_prtPrepare_h
#define guard_prtPrepare_h

#include "control/pathRouter/pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"

#include "control/parameterSet/parameterSetCtrl_interface.h"

/** \brief Initialisiert die persistenten Pfaddaten mit geeigneten Standard Werten.

\ingroup pathRouter_caching
*/
void prtInit_mapPathMemory_T(	OUT mapPathMemory_T	*mapPathMemory		/**<persistente Pfaddaten*/
							);


/** \brief Baut die `mapPathMemory` weiter.
	
Den `mapPathMemory->segmentRing` mit der `mapRoute` abgleichen. �berfahrene Segmente vorne l�schen. Herausgefallene Segemnte am Ende l�schen (\ref prtCropMapPath()).
Ein eventuell vorhandenes unvollst�ndiges Segment zun�chst vervollst�ndigen (\ref prtCopyAttributes() \ref prtCopySpeedLimits()).
Neue Segmente aus Psd-Baum �bertragen (\ref prtGetPathFromRoute()). Aus Laufzeitgr�nden werden pro Zyklus eine maximale Anzahl von Tempolimits und Attributen �bertragen.
Wenn das letzte mapRoute-Segment vollst�ndig �bertragen ist, Flag `mapPathIsComplete = true` setzen.
um im n�chsten Takt zu idlen, falls der Baum und Fahrzeugstatus bis dahin unver�ndert bleiben.
GPS-Position auf dem feritgen mapPath setzen (\ref prtSetGpsPosition()).
*/
bool_T		prtContinueMapPath(	IN const	parameterSetCtrl_T		*parameterSet,				/**<globale Parameter*/
								IN const	mapRawVehiclePosition_T	*psdPosition,				/**<Fahrzeugposition*/
								IN const	mapRoute_T				*mapRoute,					/**<Liste der voraussichtlich befahrenen Segmente*/
								IN const	uint8_T					 nSegmentCalls,				/**<Z�hler f�r Api-Aufrufe*/
								INOUT		mapPathMemory_T			*mapPathMemory,				/**<persistente Pfaddaten*/
								INOUT		uint8_T					*nSpeedLimitCalls,			/**<Z�hler f�r Api-Aufrufe*/
								INOUT		uint8_T					*nAttributeCalls,			/**<Z�hler f�r Api-Aufrufe*/
								OUT			bool_T					*mapPathIsComplete			/**<Wird im Fall eines komplettierten Pfades auf `true` gesetzt*/
								);


/** \brief Sucht die segmentId auf dem Pfad und Gibt die Distanz der rawPosition vom Anfang des mapPath zur�ck.

Im `segmentRing` wird das Segment mit der `rawPosition->segmentId` gesucht.
Der Offset auf dem Segment Ergibt sich aus Segmentl�nge minus `rawPosition->remainingLength`.
Die `rawPosition->inhibitTime` bezeichnet das Alter der Positionsinformation in den PSD-Daten. Multipliziert mit der 
`velocity` ergibt sich eine zus�tzlicher Inhibit-Distanz.

Die `distance` ist schlie�lich die Summe aus Startdistanz des Segments, Offset und Inhibit-Distanz.
Der R�ckgabewert ist `true` wenn die `rawPosition` auf dem `segmentRing`zugeordnet werden konnte, sonst `false`.

\ingroup pathRouter_caching
*/
bool_T	prtFindDistanceOnPath(	IN const	mapSegmentRing_T		*segmentRing,				/**<ringspeicher der Segmentdaten*/
								IN const	mapRawVehiclePosition_T	*rawPosition,				/**<Position ausgedr�ckt als Segment-Id und Restl�nge auf dem Segment*/
								IN const	real32_T				 velocity,					/**<Fahrzeuggeschwindigkeit*/
								OUT			uint16_T				*distance					/**<Distanz vom Pfadanfang in Meter*/
								);


/** \brief Kopiert persistente Daten nach `mapPath->info`. Aktualisiert Position- und Heading-Filter.

Der `positionFilter` wird in \ref prtUpdatePosition() aktualisiert.
Die Attribute und die GPS-Position werden in \ref prtBuildPathRouterInfo() in den `mapPath` �bertragen.
	
Es wird `mapPath->valid = true` gesetzt, wenn 
- \ref prtBuildPathRouterInfo() keinen Fehler meldet,
- die gefilterte Fahrzeugposition auf dem `mapPath` hinter der GPS-Position und hinter dem ersten Tempolimit zugeordnet werden kann
- und mindestens 15m (parametrierbar) an Pr�diziertem Pfad vor dem Fahrzeug liegen.
	
Der `headingFilter`wird in \ref prtFilterHeadingCorrection() aktualisiert.

Die `positionZero = longPosition - positionFilter->vehicleDistance` wird berechnet und auch in den `mapPath` �bertragen,
Um einen Abgleich zwischen den Koordinatensystemen der PSD und des \ref vehicleObserver zu erm�glichen.

\spec SwMS_Innodrive2_PSD_155

\ingroup pathRouter_caching
*/
bool_T				 prtFinalizeMapPath(IN const	parameterSetCtrl_T		*parameterSet,				/**<Globale Parameter*/
										IN const	mapRawVehiclePosition_T	*psdPosition,				/**<Fahrzeugposition auf dem Psd-Baum*/
										IN const	real32_T				 longPosition,				/**<L�ngsposition laut vehicleOberver*/
										IN const	real32_T				 velocity,					/**<Fahrzeuggeschwindigkeit*/
										IN const	real32_T				 vobsHeading,				/**<Heading laut vehicleOberver*/
										IN const	uint8_T					 rerouteCount,				/**<Z�hler der Reroutings der mapRoute*/
										IN const 	mapPathMemory_T			*mapPathMemory,				/**<persistente Pfaddaten*/
										INOUT		mapHeadingFilter_T		*headingFilter,				/**<Zur Heading-Korrektur*/
										INOUT		mapPositionFilter_T		*positionFilter,			/**<Fahrzeugposition auf dem PSD-Baum*/
										OUT			mapPath_T				*mapPath  					/**<fl�chtige Pfaddaten*/
										);
	

/** \brief �bertrage den 'RootTreeState'.

Um zu verhindern, dass die Regelung z.B. wegen fehlender Tempolimits oder Steigungen abf�llt, besorgen wir uns die letztg�ltigen Daten vor dem Root-Segment.
Die Attribute werden positionell dem Anfang des Root-Segments zugeordnet (position == 0).
Zus�tzlich werden die Attribute, die ohne zus�tzlich Api-Aufrufe im `rootSegment` zur verf�gung stehen, kopiert.
Das Segment wird als unvollst�ndig gekennzeichnet, um im folgenden Takt, die Tempolimits und Attribute auf dem eigentlichen Segment zu �bertragen.
Die Flag `success = true` gibt an, ob das Modul \ref psdWrapper g�ltige Daten liefert und der `mapPathMemory` somit initialisiert werden konnte.
	
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_152
\spec SwMS_Innodrive2_PSD_177
\ingroup pathRouter_caching
*/
bool_T			   prtCopyRootTreeState(IN const	parameterSetCtrl_T		*parameterSet,				/**<Applikationsparameter*/
										IN const	mapRoute_T				*mapRoute,					/**<Das Wurzelsegment des Psd-Baums. Es hat kein Eltern-Segment*/
										OUT			mapPathMemory_T			*mapPathMemory,				/**<Persistente Pfaddaten*/
										OUT			bool_T					*success					/**<Wahr, wenn der Pfad erfolgreich initialisiert wurde*/
										);

	
/**\brief Gibt die Systemattribute an der Fahrzeugposition zur�ck
Wenn L�ndercode oder Verkehrsrichtung an der Fahrzeugposition ung�ltig ist, wird ein g�ltiger Wert, 
der bereits in den systemAttributes steht, gehalten.
\ingroup pathRouter_caching
*/
bool_T		   prtGetSystemAttributes(IN const	mapPathMemory_T				*mapPathMemory,				/**<Speicherring*/
										IN const	real32_T					 longPosition,				/**<Fahrzeugposition vom vehicleObserver*/
										INOUT		mapSystemAttributes_T		*systemAttributes			/**<An der Fahrzeugposition g�ltige Systemattribute*/
										);


/**\brief Gibt die Tempolimiteinheit an der Fahrzeugposition zur�ck
\ingroup pathRouter_caching
*/
bool_T			prtGetCurrentSpeedLimitUnit(IN const	mapPathMemory_T				*mapPathMemory,			/**<Speicherring*/
											IN const	real32_T					 position,	   			/**<Fahrzeugposition vom vehicleObserver*/
											OUT			psdSpeedLimitUnit_T			*speedLimitUnit			/**<An der Fahrzeugposition g�ltige  Tempolimiteinheit */
											);

#endif
