#include "pathRouter.h"
#include <common/pathRouterCommon/pathRouter_private.h>
#include "prtHold.h"

#include <control/parameterSet/parameterSetCtrl.h>
/*lint -esym(9045, struct _exception)*/
#include <math.h>


void		  prtUpdateHold(INOUT		mapHoldFilter_T		*holdFilter,
							IN	const	bool_T				 pathValid,
							IN	const	real32_T			 pathHeading,
							IN	const	real32_T			 egoVelocity,
							IN	const	real32_T			 egoHeading,
							IN	const	bool_T				 headValid,
							OUT			bool_T				*holdValid)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	/* Aktualisieren der Z�hler */
	holdFilter->holdDistance			+= egoVelocity * controlCYCLETIME;
	holdFilter->holdTicks++;

	if(headValid) {
		real32_T headingDiff = egoHeading - pathHeading;
		holdFilter->holdHeadDeviation	+= fabsf(headingDiff) * egoVelocity * controlCYCLETIME;
	}


	/* Bei g�ltigem mapPath werden die Z�hler zur�ckgesetzt */
	if(pathValid) {
		holdFilter->holdDistance		= 0.0f;
		holdFilter->holdHeadDeviation	= 0.0f;
		holdFilter->holdTicks			= 0;
	}


	/* Ausgabe */
	if(   (holdFilter->holdDistance			> paramSet->pathRouter.holdFilter.holdDistance)
	   || (holdFilter->holdHeadDeviation	> paramSet->pathRouter.holdFilter.holdHeadDeviaton)
	   || (holdFilter->holdTicks			> paramSet->pathRouter.holdFilter.holdTicks)) {
		*holdValid = false;
	}
	else {
		*holdValid = true;
	}
}
