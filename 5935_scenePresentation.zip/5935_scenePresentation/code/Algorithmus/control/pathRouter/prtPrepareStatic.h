#ifndef guard_prtPrepareStatic_h
#define guard_prtPrepareStatic_h

#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"

	
	/** \brief MapRoute und segmentRing abgleichen.

	Die Segmente im MapPath, die nicht mehr in der mapRoute sind, werden freigegeben.
		- Überfahrene Segmente am mapRoute-Anfang werden in \ref prtFreeAtBegin() freigegeben (Anpassen des `mapPathMemory->segmentRing.start` und `mapPathMemory->segmentRing.count`).
		- Ungültige Segmente am mapRoute-Ende werden in \ref prtDiscardAtEnd() freigegeben (Anpassen des `mapPathMemory->segmentRing.count`).
	Das erste mapRoute-Segment, das noch nicht im mapPath ist, wird in `firstNewRouteSegment` zurückgegeben.
	
	\ingroup pathRouter_caching
	*/
	static bool_T				 prtCropMapPath(IN const	mapRoute_T					*mapRoute,					/**<Liste der zu befahrenden Segmente*/
												INOUT		mapPathMemory_T				*mapPathMemory,				/**<persistente Pfaddaten*/
												OUT			uint8_T						*firstNewRouteSegment	  	/**<Erstes Segment auf der mapRoute, das noch nicht im mapPath liegt.*/
												);


	/** \brief Gibt den Speicher aller Segmente, die im segmentRing vor `newFirstRingId` liegen, frei.

	Der Speicher wird sowhl im segmentRing, als auch in den Attribut-Ringen freigegeben (Durch Manipulieren der Ring-Zähler).
	Das jeweils letzte Element von Streckenattribute: streetClass, streetSituation, builtUp, laneSituation, slope, speedLimit und onlineLimit wird beibehalten, um ein Abfallen der Regelung wegen
	fehlender Daten zu verhindern (vergleiche \ref prtCopyRootTreeState).
	Die mapPath->distance und die segment->startDistances werden für die bleibenden Segmente neu aufsummiert.
	
	\ingroup pathRouter_caching
	*/
	static bool_T				 prtFreeAtBegin(IN const	ringId_T					 newFirstRingId,		/**<Erstes Segment im segmentRing, das weiterhin gültig bleibt*/
												INOUT		mapPathMemory_T				*mapPathMemory  		/**<das Pfadobjekt*/
												);

	
	/** \brief Setze die GPS-Position auf dem Pfad.

	Ordne die `psdGpsPosition` dem `psdGpsPosition->referenceSegment` zu und kopiere die Daten in \ref prtCopyGps() in den `gpsRing`.
	Falls `psdGpsPosition->referenceSegment == psdPosition->id`, benutze die Fahrzeugposition laut Karte als Referenzposition.
	Für alle auf das Referenzsegment folgenden Segmente wird dieser Eintrag als GPS-Position über das Attribut `segment.gpsRingEnd` zugeordnet.

	\spec SwMS_Innodrive2_PSD_119
	
	\ingroup pathRouter_caching
	*/
	static bool_T			  prtSetGpsPosition(IN const	mapRawVehiclePosition_T		*psdPosition,				/**<Fahrzeugposition auf dem Psd-Baum*/
												INOUT		mapSegmentRing_T			*segmentRing,				/**<ringspeicher der Segmentdaten*/
												INOUT		mapGpsRing_T				*gpsRing					/**<Ringspeicher der Gps-Daten*/
												);


/** \brief Verwirft alle Segmente im segementRing ab `firstDeletedRingId` (einschließlich)
`segmentRing.count` wird angepasst, Die `attributeRing.counts` werden angepasst, die mapPath.distance wird angepasst.

\ingroup pathRouter_caching
*/
static bool_T	prtDiscardAtEnd(	IN const	ringId_T					 firstDeletedRingId,/**<Erstes ungültiges Segment im segmentRing*/
									INOUT		mapPathMemory_T				*mapPathMemory  	/**<Das Pfadobjekt*/
									);


/** \brief Gibt den Speicher aller Attribute, die im segmentRing vor `newStart` liegen, frei.
\ingroup pathRouter_caching
*/
static bool_T	prtFreeRingAtBegin(	IN const	ringId_T					 maxCount,			/**<Größe des Speicherrings*/
									IN const	ringId_T					 newStart,			/**<Neues Attribut*/
									INOUT		ringId_T					*startRingId,		/**<Zeiger auf das erste Segment im RIngspeicher*/
									INOUT		ringId_T					*attributeCount		/**<Anzahl der gespeicherten Attribute*/
									);

/** \brief Gibt den Speicher aller Attribute, die im segmentRing vor `newStartPlusOne - 1` liegen, frei.
Das letztgültige Attribut vor dem neuen Pfadanfang wird beibehalten.
Anschließend müssen vom Aufrufenden noch segmentRingId und offset des neuen Startattributs gesetzt werden.
\ingroup pathRouter_caching
*/
static bool_T	prtKeepFirstAttribute(	IN const	ringId_T				 maxCount,			/**<Größe des Speicherrings*/
										IN const	ringId_T				 newStartPlusOne,	/**<Index nach dem neuen ersten Attribut*/
										INOUT		ringId_T				*startRingId,		/**<Zeiger auf das erste Segment im Ringspeicher*/
										INOUT		ringId_T				*attributeCount		/**<Anzahl der gespeicherten Attribute*/
										);

/** \brief Gibt den Speicher aller Attribute, die im segmentRing ab `firstDeletedRingId` liegen, frei.
\ingroup pathRouter_caching
*/		
static void			prtDiscardFromRing(	IN const	ringId_T				 maxCount,			/**<Größe des Speicherrings*/
										IN const	ringId_T				 start,				/**<Erstes Attribut*/
										IN const	ringId_T				 startSegmentRingId,/**<Pfadsegment, auf dem das erste Attribut liegt*/
										IN const	ringId_T				 firstDeletedRingId,/**<Erstes gelöschtes Pfadsegment*/
										IN const	ringId_T				 newEnd,			/**<Neuer Zeiger hinter das letzte Attribut*/
										INOUT		ringId_T				*attributeCount		/**<Anzahl der gespeicherten Attribute*/
										);


/**\brief Gibt die Verkehrsrichtung an der Fahrzeugposition zurück
	\ingroup pathRouter_caching
	*/
static bool_T prtGetCurrentTrafficDirection(IN const	mapPathMemory_T			*mapPathMemory,				/**<Speicherring*/
											IN const	real32_T				 position,					/**<Fahrzeugposition vom vehicleObserver*/
											OUT			vobsTrafficDir_T		*trafficDirection			/**<An der Fahrzeugposition gültige Verkehrsrichtung*/
											);
	
/**\brief Gibt den Ländercode an der Fahrzeugposition zurück
\ingroup pathRouter_caching
*/
static bool_T	   prtGetCurrentCountryCode(IN const	mapPathMemory_T				*mapPathMemory,			/**<Speicherring*/
											IN const	real32_T					 position,				/**<Fahrzeugposition vom vehicleObserver*/
											OUT			psdCountryCode_T			*countryCode			/**<An der Fahrzeugposition gültiger Ländercode */
											);

	/**\brief Gibt die Geometriequalität an der Fahrzeugposition zurück
	\ingroup pathRouter_caching
	*/
static bool_T  prtGetCurrentQualityGeometry(IN const	mapPathMemory_T				*mapPathMemory,			/**<Speicherring*/
											IN const	real32_T					 position,	   			/**<Fahrzeugposition vom vehicleObserver*/
											OUT			uint8_T						*qualityGeometry		/**<An der Fahrzeugposition gültige Geometriequalität*/
											);


#endif
