#include "control/pathRouter/prtPositionFilter.h"
#include "control/pathRouter/prtPrepare.h"
#include "common/pathRouterCommon/pathRouter_private.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtPositionFilter)


static bool_T		prtPositionCorrection(	IN const	parameterSetCtrl_T		*parameterSet,
											IN const	mapPositionFilter_T		*positionFilter,
											IN const	mapSegmentRing_T		*segmentRing,
											IN const	mapRawVehiclePosition_T	*rawPosition,
											IN const	real32_T				 longPosition,
											IN const	real32_T				 newDistance,
											OUT			real32_T				*correction,
											OUT			real32_T				*distance,
											OUT			bool_T					*reset)
{
	ringId_T	i;
	real32_T	deltaCorr;

	/*Kopieren der Werte aus dem letzten Zeitschritt*/
	*distance = positionFilter->vehicleDistance;
	*correction = positionFilter->vehDistCorrection;

	/*Vorschieben der vehicleDistance*/
	*distance += (longPosition - positionFilter->longPosition);

	/*Eventuell weggefallenes Wurzelsegment abziehen.*/
	for (i = positionFilter->rootSegment.segmentId; i != segmentRing->start; i = i + 1u >= (ringId_T)mapMAXROUTELENGTH ? 0u : i + 1u)
	{
		diagFF(i < (ringId_T)mapMAXROUTELENGTH);
		*distance -= (real32_T)segmentRing->segment[i].length;
	}

	/*Einschleifen der Korrektur*/
	deltaCorr = parameterSet->pathRouter.positionFilter.correctionFactor * *correction;
	*distance	+= deltaCorr;
	*correction	-= deltaCorr;

	/*Bei neuer Kartenposition Korrektur lernen.*/
	if (	positionFilter->rawPosition.segmentId != rawPosition->segmentId
		||	positionFilter->rawPosition.remainingLength != rawPosition->remainingLength)
	{
		*correction += newDistance - *distance;
	}
		
	/*Limitieren der Korrektur*/
	if (fastfabsf(*correction) > parameterSet->pathRouter.positionFilter.positionTolerance)
	{
		*reset = true;
	} else {
		*reset = false;
	}

	return true;
}


bool_T		prtUpdatePosition(	IN const	parameterSetCtrl_T		*parameterSet,
								IN const	mapSegmentRing_T		*segmentRing,
								IN const	mapRawVehiclePosition_T	*rawPosition,
								IN const	real32_T				 longPosition,
								IN const	uint16_T				 newDistance,
								INOUT		mapPositionFilter_T		*positionFilter)
{
	bool_T		resetFlag;
	real32_T	distance, correction;

	/*Update der positionFilter->vehicleDistance und positionFIlter->vehDistCorrection 
	 Falls der Filter nicht initialisiert ist oder die Position nicht auf dem Pfad ist wird hier nur Zeit verdummt*/
	diagFF(prtPositionCorrection(parameterSet, positionFilter, segmentRing, rawPosition, longPosition, (real32_T)newDistance, &correction, &distance, &resetFlag));

	if(positionFilter->isInitialized && !resetFlag)
	{
		/*Daten sind G�ltig.*/
		positionFilter->vehDistCorrection			= correction;
		positionFilter->vehicleDistance				= distance;

		/*�brige Daten aktualisieren bzw. initialisieren*/
		diagFF(segmentRing->start < (ringId_T)mapMAXROUTELENGTH);
		positionFilter->rootSegment.remainingLength	= segmentRing->segment[segmentRing->start].length;
		positionFilter->rootSegment.segmentId		= segmentRing->start;
		positionFilter->rawPosition.remainingLength	= rawPosition->remainingLength;
		positionFilter->rawPosition.segmentId		= rawPosition->segmentId;
		positionFilter->rawPosition.inhibitTime		= rawPosition->inhibitTime;
		positionFilter->longPosition				= longPosition;
		positionFilter->isInitialized				= true;
	} else {
		/*Keine g�ltigen Daten. Filter zur�cksetzen.*/
		diagFF(prtResetPosition(segmentRing, rawPosition, longPosition, newDistance, positionFilter));
	}

	return true;
}


bool_T		prtResetPosition(	IN const	mapSegmentRing_T		*segmentRing,
								IN const	mapRawVehiclePosition_T	*rawPosition,
								IN const	real32_T				 longPosition,
								IN const	uint16_T				 newDistance,
								INOUT		mapPositionFilter_T		*positionFilter)
{
	/*Keine g�ltigen Daten. Filter initialisieren.*/
	positionFilter->vehDistCorrection			= 0.0f;
	positionFilter->vehicleDistance				= (real32_T)newDistance;
	positionFilter->resetCount++;

	/*�brige Daten initialisieren*/
	diagFF(segmentRing->start < (ringId_T)mapMAXROUTELENGTH);
	positionFilter->rootSegment.remainingLength	= segmentRing->segment[segmentRing->start].length;
	positionFilter->rootSegment.segmentId		= segmentRing->start;
	positionFilter->rawPosition					= *rawPosition;
	positionFilter->longPosition				= longPosition;
	positionFilter->isInitialized				= true;

	return true;
}
