#include "control/pathRouter/prtRouteFilter.h"
#include "control/pathRouter/prtRouteFilterStatic.h"
#include "common/pathROuterCommon/pathRouter_private.h"

#include "control/psdWrapper/psdWrapper.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtRouteFilter)


static void	prtInit_mapRouteMemory_T(OUT	mapRouteMemory_T	*mapRouteMemory)
{
	uint8_T rerouteCount = mapRouteMemory->mapRoute.rerouteCount;
	memset(mapRouteMemory, 0, sizeof(mapRouteMemory_T));
	mapRouteMemory->lastTurnSignal = turnSignalNone;
	mapRouteMemory->mapRoute.rerouteCount = rerouteCount;
}


bool_T					 prtRouteUpdate(INOUT		mapInitFlag_T				*initFlag,
										INOUT		mapRouteMemory_T			*mapRouteMemory,
										INOUT		uint8_T						*nSegmentCalls,
										IN	const	mapRawVehiclePosition_T		*psdPosition,
										IN  const	real32_T					 positionZero,
										IN	const	turnSignal_T				 turnSignal,
										IN	const	bool_T						 turnSignalConfident,
										IN  const	real32_T					 turnPosition,
										OUT			bool_T						*ageReset)
{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();

	bool_T				mapRouteInitialized;
	mapChangeFlag_T		changeFlag;

	*ageReset = false;

	/* Suchen des Zielsegments abh�ngig von Blinker-Informationen und bestimmen der mapRoute
	Falls nicht der mapPath initialisiert werden muss (mapPathInvalid)
	*/
	switch(*initFlag)
	{
	case mapRouteInvalid:
		/*	Auslesen der Fahrzeugposition und das zugeh�rige Segment.
			Aufbauen der mapRoute von der Wurzel des Baums bis zur Fahrzeugposition.
			Definition initFlag: "newMapRoute" falls die mapRoute initialisiert werden konnte
			"mapRouteInvalid" bleibt weiterhin, falls nicht alle Segmente bis zur Position komplett sind.
			*/
		diagFF(prtInitializeMapRoute( parameterSet->pathRouter.maxSegmentsPerCycle,
									  psdPosition,
									  nSegmentCalls,
									  mapRouteMemory,
									 &mapRouteInitialized));

		*initFlag = mapRouteInitialized ? newMapRoute : mapRouteInvalid;

		/* Wenn aktuell kein Baum zur Verf�gung steht, setzen wir den Altersz�hler f�r die Karte zur�ck */
		*ageReset = !mapRouteInitialized;
		break;

	case newMapRoute:
		diagFUnreachable();

	case mapPathInvalid: /*lint !e9090 (Note -- unconditional break missing from switch case [MISRA 2012 Rule 16.3, required])*/
		/*In diesem Takt nur Pfad initialisieren (siehe n�chstes `switch`)*/
		break;

	case mapPathInitialized:
	case mapPathComplete:

		/*	Auslesen der Fahrzeugposition und des changeCount des Psd-Baums.
			Falls nicht `mapPathComplete` oder sich Baum, Blinker oder Position ge�ndert haben:
			Baue die mapRoute weiter(und verwerfe ggf. Teile)
			Setze initFlag auf `mapPathInitialized` oder "newMapRoute"(falls komplett initialisiert)
			Sonst tue nichts und die initFlag bleibt auf mapPathComplete
			*/
		diagFF(prtContinueMapRoute((parameterSet->pathRouter.enableTurnSignal) ? turnSignal : turnSignalNone,
								    turnSignalConfident,
									turnPosition,
								    parameterSet->pathRouter.maxSegmentsPerCycle,
								    psdPosition,
									positionZero,
								    nSegmentCalls,
								   &mapRouteMemory->lastChangeCount,
								    mapRouteMemory,
								   &changeFlag));

		switch (changeFlag)
		{
		case noChange:
			break;
		case changeMapRouteNew:
			*initFlag = newMapRoute;
			mapRouteMemory->mapRoute.rerouteCount++;
			break;
		case changeMapRouteInvalid:
			*initFlag = mapRouteInvalid;
			break;
		case changeMapRouteUpdated:
			*initFlag = mapPathInitialized;
			break;
		case changeMapRouteRerouted:
			*initFlag = mapPathInitialized;
			mapRouteMemory->mapRoute.rerouteCount++;
			break;
		default:
			diagFUnreachable();
		} /*lint !e9077 (Note -- missing unconditional break from final switch case [MISRA 2012 Rule 16.1, required], [MISRA 2012 Rule 16.3, required])*/
		break;

	default:
		diagFUnreachable();
	}/*lint !e9077 (Note -- missing unconditional break from final switch case [MISRA 2012 Rule 16.1, required], [MISRA 2012 Rule 16.3, required])*/


	return true;
}


bool_T				prtIsSegmentOnRoute(IN	const	mapRoute_T					*mapRoute,
										IN	const	psdSegmentId_T				 segmentId,
										OUT OPT		uint8_T						*segmentOffset)
{
	uint8_T i;
	uint8_T offset = INVALID_UINT8;
	for (i = 0; i < (ringId_T)mapMAXROUTELENGTH; i++)
	{
		if (	mapRoute->segment[(mapRoute->segmentStart + i) % (ringId_T)mapMAXROUTELENGTH].id == segmentId
			&&	offset == (uint8_T)INVALID_UINT8)
		{
			offset = i;
		}
	}
	if (offset < mapRoute->segmentCount)
	{
		if (NULL != segmentOffset) { *segmentOffset = offset; }
		return true;
	}
	else
	{
		if (NULL != segmentOffset) { *segmentOffset = (uint8_T)INVALID_UINT8; }
		return false;
	}
}


static bool_T	  prtInitializeMapRoute(IN	const	uint8_T						 maxSegmentCalls,
										IN  const	mapRawVehiclePosition_T		*psdPosition,
										INOUT		uint8_T						*nSegmentCalls,
										OUT			mapRouteMemory_T			*mapRouteMemory,
										OUT			bool_T						*mapRouteInitialized)
{
	bool_T valid;
	*mapRouteInitialized = false;


	/*Pr�fen, ob der psd-Baum g�ltig ist.*/
	if (!psdPosition->valid)
	{
		prtInit_mapRouteMemory_T(mapRouteMemory);
		*mapRouteInitialized = false;
	}
	else
	{
		/*Baue die mapRoute von der Wurzel des Baums bis zur Fahrzeugposition*/
		diagFF(prtGetRouteFromRoot(psdPosition->segmentId, maxSegmentCalls, nSegmentCalls, mapRouteMemory, &valid));

		if (valid)
		{
			*mapRouteInitialized = true;
		}
	}

	return true;
}


static bool_T		prtContinueMapRoute(IN	const	turnSignal_T				 turnSignal,
										IN	const	bool_T						 turnSignalConfident,
										IN  const	real32_T					 turnPosition,
										IN	const	uint8_T						 maxSegmentCalls,
										IN  const	mapRawVehiclePosition_T		*psdPosition,
										IN  const	real32_T					 positionZero,
										INOUT		uint8_T						*nSegmentCalls,
										INOUT		psdChangeCount_T			*lastChangeCount,
										INOUT		mapRouteMemory_T			*mapRouteMemory,
										OUT			mapChangeFlag_T				*changeFlag)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	psdGpsPosition_T	psdGpsPosition;
	psdChangeCount_T	psdChangeCount;
	psdSystemData_T		systemData;
	bool_T				positionOnRoute;
	bool_T				mapRouteRerouted;
	bool_T				mapRouteUpdated;
	bool_T				mapRouteValid;
	bool_T				useRouting;

	*changeFlag = noChange;

	/*Fahrzeugposition und ChangeCount holen*/
	if(!psdwGetGpsData(&psdGpsPosition) || psdGpsPosition.longitude == PSD_EHR_LONGITUDE_VALUE_NO_GPS)	{ *changeFlag = changeMapRouteInvalid; }
	if(!psdPosition->valid)																				{ *changeFlag = changeMapRouteInvalid; }
	if(!psdwGetSystemData(&systemData))																	{ *changeFlag = changeMapRouteInvalid; }
	if(!psdwGetTreeChangeCount(&psdChangeCount))														{ *changeFlag = changeMapRouteInvalid; }

	/* Wir folgem dem MPP anstelle des SP, wenn die Zielf�hrung aktiv und der entsprechende Parameter gesetzt ist */
	useRouting = (systemData.isRoutingActive && paramSet->pathRouter.routeFilter.followRouting) || paramSet->pathRouter.routeFilter.preferMPP;

	if (*changeFlag == changeMapRouteInvalid)
	{
		return true;
	}
	
	/*Den Anfang der mapRoute bis zum root-Segment vorschieben.*/
	diagFF(prtCheckRootSegment(	&mapRouteMemory->mapRoute,
								&mapRouteUpdated));
	if (mapRouteUpdated)
	{
		*changeFlag = changeMapRouteUpdated;
	}


	/*Falls sich der Blinker oder die Routing ge�ndert hat, werden alle Segmente ab dem Verlassen des Straightest Path verworfen.*/
	diagFF(prtHandleConditionChange(&mapRouteMemory->mapRoute,
									 turnSignal,
									 mapRouteMemory->lastTurnSignal,
									 turnSignalConfident,
									 mapRouteMemory->lastConfident,
									 turnPosition,
									 positionZero,
									 useRouting,
									 mapRouteMemory->lastUseRouting,
									&mapRouteRerouted));

	if (mapRouteRerouted) {
		*changeFlag = changeMapRouteRerouted;
		mapRouteMemory->completed = false;
	}

	mapRouteMemory->lastTurnSignal = turnSignal;
	mapRouteMemory->lastConfident  = turnSignalConfident;
	mapRouteMemory->lastUseRouting = useRouting;


	/*Falls die positionId noch auf der Route ist, ist die Route OK.
	Falls Nicht, pr�fe ob das parentSegment der positionId noch auf der Route ist und h�nge die positionId an.
	Sonst initialisiere die mapRoute neu.
	*/
	diagFF(prtCheckPositionOnRoute( psdPosition->segmentId, 
									nSegmentCalls, 
									&mapRouteMemory->mapRoute,
									&positionOnRoute,
									&mapRouteRerouted));
	if (mapRouteRerouted)
	{
			*changeFlag = changeMapRouteRerouted;
			mapRouteMemory->completed = false;
	}

	if (! positionOnRoute)
	{
		/*Baue eine neue mapRoute vom RootSegment bis zum tailSegment*/
		diagFF(prtGetRouteFromRoot(	 psdPosition->segmentId, 
									 maxSegmentCalls,
									 nSegmentCalls,
									 mapRouteMemory,
									&mapRouteValid));
		
		if (mapRouteValid)
		{
			*changeFlag = changeMapRouteNew;
		} else {
			*changeFlag = changeMapRouteInvalid;
		}
		mapRouteMemory->completed = false;
	}
	else if (! mapRouteMemory->completed)		/*Route nicht komplett*/
	{

		/*Baue die mapRoute von tailSegment aus weiter*/
		diagFF(prtGetMapRoute( turnPosition,
							   positionZero,
							   turnSignal,
							   turnSignalConfident,
							   useRouting,
							   maxSegmentCalls,
							   nSegmentCalls,
							   mapRouteMemory,
							  &mapRouteUpdated));

		if (	*changeFlag == noChange
			&&	mapRouteUpdated)
		{
			*changeFlag = changeMapRouteUpdated;
		}
	}
	else if (		psdChangeCount != *lastChangeCount
				||				 0u != mapRouteMemory->checkBranchesIndex)
	{
		/*Nur beim Eintritt in die �berpr�fung soll der *lastChangeCount gesetzt werden.
		Dadurch werden auch �nderungen bemerkt, die w�hrend der �berpr�fung auftreten.
		Dann wird die �berpr�fung wieder von vorne beginnen.*/
		if (0u == mapRouteMemory->checkBranchesIndex)
		{
			*lastChangeCount = psdChangeCount;
		}

		/*�berpr�fe die vollst�ndige mapRoute auf neu hinzugef�gte Abzweigungen*/
		diagFF(prtCheckBranches(&mapRouteMemory->mapRoute,
								&mapRouteMemory->checkBranchesIndex,
								 nSegmentCalls,
								 psdPosition->segmentId,
								 turnPosition,
								 positionZero,
								 turnSignal,
								 turnSignalConfident,
								 useRouting,
								 maxSegmentCalls,
								&mapRouteRerouted,
								&mapRouteMemory->completed));

		if (mapRouteRerouted)
		{
			*changeFlag = changeMapRouteRerouted;
		} else {
			*changeFlag = changeMapRouteUpdated;
		}

	}
	else
	{
		/*Position auf Route UND mapRoute completed UND psdChangeCount unver�ndert. Keine Aktion.*/
	}

	return true;
}


static bool_T			 prtGetMapRoute(IN	const	real32_T					 turnPosition,
										IN  const	real32_T					 positionZero,
										IN	const	turnSignal_T				 turnSignal,
										IN	const	bool_T						 turnSignalConfident,
										IN	const	bool_T						 useRouting,
										IN	const	uint8_T						 maxSegmentCalls,
										INOUT		uint8_T						*nSegmentCalls,
										INOUT		mapRouteMemory_T			*mapRouteMemory,
										OUT			bool_T						*mapRouteUpdated)
{
	psdSegment_T currentSegment;
	psdSegmentId_T tailSegmentId;
	*mapRouteUpdated = false;

	/*Hole das letzte g�ltige Segment der Route*/
	tailSegmentId = mapRouteMemory->mapRoute.segment[(mapRouteMemory->mapRoute.segmentStart + mapRouteMemory->mapRoute.segmentCount - 1u) % (uint8_T)mapMAXROUTELENGTH].id;
	diagFF(psdwGetSegmentData(tailSegmentId, &currentSegment));
	*nSegmentCalls += 1u;
	mapRouteMemory->mapRoute.segment[(mapRouteMemory->mapRoute.segmentStart + mapRouteMemory->mapRoute.segmentCount - 1u) % (uint8_T)mapMAXROUTELENGTH] = currentSegment;

	/*Routing abh�ngig von Blinkerzustand ab dem currentSegment*/
	while (		currentSegment.childCount > 0u												/*das Segment hat Kinder*/
		   &&	mapRouteMemory->mapRoute.segmentCount < (uint8_T)mapMAXROUTELENGTH)			/*Die mapRoute hat noch Speicherplatz*/
	{
		psdSegment_T children[psdMAXCHILDRENCOUNT];
		bool_T childrenComplete;

		/*Zun�chst alle Kinder lokal speichern*/
		diagFF(prtCopyChildSegments(&currentSegment,
									 maxSegmentCalls,
									 nSegmentCalls,
									 children,
									&childrenComplete));

		if (!childrenComplete)
		{
			/*Wir m�ssen hier im n�chsten Rechentakt weitermachen.*/
			mapRouteMemory->completed = false;
			break;
		}
		else
		{
			branchOptions_T branches;
			uint8_T smallestAngle;
			
			/*W�hle das voraussichtlich befahrene Kind aus.*/
			diagFF(prtFindBestChild( turnPosition,
									 positionZero,
									 turnSignal,
									 turnSignalConfident,
									 useRouting,
									 currentSegment.childCount,
									 children,
									&mapRouteMemory->mapRoute,
									&smallestAngle,
									&branches,
									&currentSegment));
			mapRouteMemory->mapRoute.branch[(mapRouteMemory->mapRoute.segmentStart + mapRouteMemory->mapRoute.segmentCount - 1u) % (uint8_T)mapMAXROUTELENGTH] = branches;
			mapRouteMemory->mapRoute.smallestAngles[(mapRouteMemory->mapRoute.segmentStart + mapRouteMemory->mapRoute.segmentCount) % (uint8_T)mapMAXROUTELENGTH] = smallestAngle;

			/*H�nge das beste Kind an die mapRoute an.*/
			mapRouteMemory->mapRoute.segment[(mapRouteMemory->mapRoute.segmentStart + mapRouteMemory->mapRoute.segmentCount) % (uint8_T)mapMAXROUTELENGTH] = currentSegment;
			mapRouteMemory->mapRoute.segmentCount++;

			*mapRouteUpdated = true;

			/*Ist die mapRoute fertig oder muss sie im n�chsten Takt weitergebaut werden?*/
			if (	mapRouteMemory->mapRoute.segmentCount == (uint8_T)mapMAXROUTELENGTH	/*Die Maximall�nge ist erreicht*/
				||	currentSegment.childCount == 0u)								/*das letzte Segment hat keine Kinder*/
			{
				mapRouteMemory->completed = true;
			} else {
				mapRouteMemory->completed = false;
			}
		}
	}

	mapRouteMemory->checkBranchesIndex = 0;
	return true;
}


static bool_T		   prtCheckBranches(INOUT		mapRoute_T					*mapRoute,
										INOUT		uint8_T						*checkBranchesIndex,
										INOUT		uint8_T						*nSegmentCalls,
										IN	const	uint8_T						 positionId,
										IN	const	real32_T					 turnPosition,
										IN	const	real32_T					 positionZero,
										IN	const	turnSignal_T				 turnSignal,
										IN	const	bool_T						 turnSignalConfident,
										IN	const	bool_T						 useRouting,
										IN	const	uint8_T						 maxSegmentCalls,
										OUT			bool_T						*changed,
										OUT			bool_T						*completed)
{
	uint8_T positionOffset;
	uint8_T checkSegment;

	diagFF(mapRoute->segmentCount <= (uint8_T)mapMAXROUTELENGTH);
	diagFF(prtIsSegmentOnRoute(mapRoute, positionId, &positionOffset));

	checkSegment	= *checkBranchesIndex;
	*changed		= false;


	/* Route durchgehen bis alle Segmente abgearbeitet sind oder keine API-Aufrufe mehr zur Verf�gung stehen */
	while(   (checkSegment < mapRoute->segmentCount)
		  && (*nSegmentCalls < maxSegmentCalls))
	{
		psdSegment_T	currentSegment;

		bool_T	positionPassed;
		bool_T	childrenChanged;
		bool_T	routingChanged;
		bool_T	routingLost, routingStarted;

		uint8_T index = (mapRoute->segmentStart + checkSegment) % (uint8_T)mapMAXROUTELENGTH;

		diagFF(psdwGetSegmentData( mapRoute->segment[index].id, &currentSegment));
		*nSegmentCalls += 1u;

		/* Routing-�nderungen k�nnen erst ab der aktuellen Fahrzeugposition vorgenommen werden */
		positionPassed	= (checkSegment >= positionOffset) ? true : false;

		/* Die Kinderzahl dieses Segments hat sich ge�ndert. Dies schlie�t den Fall ein, dass am Pfadende ein Segment angeh�ngt wird. */
		childrenChanged	= (mapRoute->segment[index].childCount != currentSegment.childCount) ? true : false;

		/* Das MPP-Attribut dieses Segments hat sich ge�ndert. */
		routingStarted	= (!mapRoute->segment[index].attributes.isMostProbablePath && currentSegment.attributes.isMostProbablePath) ? true : false;
		routingLost		= (mapRoute->segment[index].attributes.isMostProbablePath && !currentSegment.attributes.isMostProbablePath) ? true : false;
		routingChanged	= routingLost || routingStarted;

		if(positionPassed && routingLost) {
			/* Das aktuelle Segment hat sein MPP-Attribut verloren. Lt. PSD-Spec (MIB-2_RQ_NAV_PSD_1390,MIB-2_RQ_NAV_PSD_1388 und MIB-2_RQ_NAV_PSD_561) ist
			   dies nur zu erwarten, wenn sich die Zielf�hrung durch Fahrereingaben oder Traffic-Informationen �ndert. In diesem Fall bauen wir die Route
			   vom letzten g�ltigen Segment aus wieder auf. */
			mapRoute->segmentCount = checkSegment;
			*completed	= false;
			*changed	= true;
		}
		else if(positionPassed && (childrenChanged || routingChanged)) {
			/*Das Segment hatte vorher keine Kinder. Es liegt am Pfadende*/
			if(   (mapRoute->segmentCount == checkSegment + 1u)) {
				diagFF(mapRoute->segment[index].childCount == 0u);
				*completed = false;
			} 
			else {
				psdSegment_T children[psdMAXCHILDRENCOUNT];
				bool_T childrenComplete;

				/*Es ist ein Abzweig mitten auf der Route hinzugekommen*/
				diagFF(checkSegment + 1u < mapRoute->segmentCount);

				/*Zun�chst alle Kinder lokal speichern*/
				diagFF(prtCopyChildSegments(&currentSegment,
											 maxSegmentCalls,
											 nSegmentCalls,
											 children,
											&childrenComplete));

				if(!childrenComplete) {
					/*Im n�chsten Rechentakt nochmal versuchen*/
					break; /*GOTO END_WHILE*/
				}
				else {
					psdSegmentId_T count;
					uint8_T smallestAngle;
					branchOptions_T branches;
					psdSegment_T bestChild;

					/*W�hle das voraussichtlich befahrene Kind aus.*/
					count = mapRoute->segmentCount;

					mapRoute->segmentCount = max(positionOffset, checkSegment) + 1u;

					diagFF(prtFindBestChild( turnPosition,
											 positionZero,
											 turnSignal,
											 turnSignalConfident,
											 useRouting,
											 currentSegment.childCount,
											 children,
											 mapRoute,
											&smallestAngle,
											&branches,
											&bestChild));

					if ((bestChild.id == mapRoute->segment[(index + 1u) % (uint8_T)mapMAXROUTELENGTH].id)) {
						/*mapRoute bleibt wie sie ist.*/
						mapRoute->branch[index] = branches;
						mapRoute->smallestAngles[index] = smallestAngle;
						mapRoute->segmentCount = count;
						*completed = true;
					}
					else {
						/*mapRoute bleibt an dieser Stelle abgeschnitten. Wird im n�chsten Takt von dort weitergebaut.*/
						mapRoute->segmentCount = checkSegment + 1u;
						*completed = false;
						*changed = true;
					}
				}
			}

			/*Hochz�hlen des Segmentindex*/
			checkSegment++;
		}
		else {
			/*Hochz�hlen des Segmentindex*/
			checkSegment++;
		}

		/*Kinderzahl und -Array des betrachteten Segments korrigieren.*/
		memcpy(&mapRoute->segment[index], &currentSegment, (size_t)sizeof(currentSegment));
	}
	/*END_WHILE*/

	/*R�cksetzen des Segmentindex*/
	diagFF(mapRoute->segmentCount <= (uint8_T)mapMAXROUTELENGTH);
	diagFF(checkSegment <= mapRoute->segmentCount);

	checkSegment = (checkSegment == mapRoute->segmentCount) ? (uint8_T)0 : checkSegment;
	*checkBranchesIndex = checkSegment;

	return true;
}


static bool_T	prtCheckPositionOnRoute(IN	const	uint8_T						 positionId,
										INOUT		uint8_T						*nSegmentCalls,
										INOUT		mapRoute_T					*mapRoute,
										OUT			bool_T						*positionOnRoute,
										OUT			bool_T						*mapRouteRerouted)
{
	psdSegment_T		positionSegment;
	uint8_T				routeOffset;


	if (!prtIsSegmentOnRoute(mapRoute, positionId, &routeOffset))
	{
		diagFF(psdwGetSegmentData(positionId, &positionSegment));
		*nSegmentCalls += 1u;
		if (!prtIsSegmentOnRoute(mapRoute, positionSegment.parentId, &routeOffset)
			|| positionSegment.parentId == (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INIT)
		{
			*positionOnRoute = false;
		}
		else
		{
			/*Dass Parent-Segment ist das letzte g�ltige Segment. Fahrzeugposition daran anf�gen.
			Abzweigeinformationen sind jetzt �berholt*/
			prtKillBranchFlags((uint8_T)0, routeOffset, mapRoute);
			mapRoute->segmentCount = routeOffset + 1u;
			mapRoute->segment[(mapRoute->segmentStart + mapRoute->segmentCount) % (uint8_T)mapMAXROUTELENGTH] = positionSegment;
			mapRoute->segmentCount++;
			*positionOnRoute = true;
		}
		*mapRouteRerouted = true;
	}
	else
	{
		*positionOnRoute  = true;
		*mapRouteRerouted = false;
	}

	return true;
}


static bool_T		prtCheckRootSegment(INOUT		mapRoute_T					*mapRoute,
										OUT			bool_T						*mapRouteUpdated)
{
	psdSegmentId_T		rootId;
	uint8_T				routeOffset;
	
	diagFF(psdwGetRootSegment(&rootId));
	if(		prtIsSegmentOnRoute(mapRoute, rootId, &routeOffset)
		&&	routeOffset > 0u)
	{
		mapRoute->segmentStart = (mapRoute->segmentStart + routeOffset) % (uint8_T)mapMAXROUTELENGTH;
		mapRoute->segmentCount -= routeOffset;
		*mapRouteUpdated = true;
	} else {
		*mapRouteUpdated = false;
	}

	return true;
}


static void			 prtKillBranchFlags(IN	const	uint8_T						 firstIndex,
										IN	const	uint8_T						 lastIndex,
										OUT			mapRoute_T					*mapRoute)
{
	uint8_T i;
	for (i = firstIndex; i < (uint8_T)mapMAXROUTELENGTH; i++)
	{
		if (i <= lastIndex)
		{
			mapRoute->branch[(mapRoute->segmentStart + i) % (uint8_T)mapMAXROUTELENGTH] = branchOptionNone;
		}
	}
	return;
}


static bool_T  prtHandleConditionChange(INOUT		mapRoute_T					*mapRoute,
										IN	const	turnSignal_T				 turnSignal,
										IN	const	turnSignal_T				 lastTurnSignal,
										IN	const	bool_T						 turnSignalConfident,
										IN	const	bool_T						 lastConfident,
										IN  const   real32_T					 turnPosition,
										IN  const   real32_T					 positionZero,
										IN	const	bool_T						 useRouting,
										IN	const	bool_T						 lastUseRouting,
										OUT			bool_T						*changed)
{
	uint8_T	segment;
	bool_T	confChanged;
	bool_T	leftChanged;
	bool_T	rightChanged;
	bool_T	routeChanged;
	uint8_T	countBefore;

	real32_T turnLength;
	real32_T totalLength = 0.0f;

	/*lint -save */
	/*lint -e731 (Info -- Boolean argument to equal/not equal)*/
	/*lint -e697 (Warning -- Quasi-boolean values should be equality-compared only with 0) */

	/* Hat sich das Konfidenz-Flag ge�ndert? */
	confChanged = (turnSignalConfident != lastConfident);

	/* Was Linkabbiegen bisher gesetzt war und jetzt nicht mehr oder es bisher gesperrt war und das jetzt nicht
	   mehr der Fall ist oder Linksabbiegen gesetzt oder gesperrt ist und sich die Konfidenz ge�ndert hat, 
	   hat sich bzgl. Linksabbiegen etwas ge�ndert und wir m�ssen die Route pr�fen. */
	leftChanged  =    ((turnSignalLeft == lastTurnSignal || turnSignalLeftOnly == lastTurnSignal)
				    != (turnSignalLeft == turnSignal     || turnSignalLeftOnly == turnSignal))
				   || ((turnSignalLockLeft == lastTurnSignal || turnSignalRightOnly == lastTurnSignal || turnSignalLockBoth == lastTurnSignal)
				    != (turnSignalLockLeft == turnSignal     || turnSignalRightOnly == turnSignal     || turnSignalLockBoth == turnSignal))
				   || (((turnSignalLeft == lastTurnSignal || turnSignalLeftOnly == lastTurnSignal)
				     || (turnSignalLockLeft == turnSignal     || turnSignalRightOnly == turnSignal     || turnSignalLockBoth == turnSignal))
				    && confChanged);


	/* Was Linkabbiegen bisher gesetzt war und jetzt nicht mehr oder es bisher gesperrt war und das jetzt nicht
	   mehr der Fall ist, hat sich bzgl. Linksabbiegen etwas ge�ndert und wir m�ssen die Route pr�fen. */
	rightChanged =    ((turnSignalRight == lastTurnSignal || turnSignalRightOnly == lastTurnSignal)
				    != (turnSignalRight == turnSignal     || turnSignalRightOnly == turnSignal))
				  || ((turnSignalLockRight == lastTurnSignal || turnSignalLeftOnly == lastTurnSignal || turnSignalLockBoth == lastTurnSignal)
				   != (turnSignalLockRight == turnSignal     || turnSignalLeftOnly == turnSignal     || turnSignalLockBoth == turnSignal))
				  || (((turnSignalRight == turnSignal     || turnSignalRightOnly == turnSignal)
				    || (turnSignalLockRight == lastTurnSignal || turnSignalLeftOnly == lastTurnSignal || turnSignalLockBoth == lastTurnSignal))
				   && confChanged);
	/*lint -restore*/

	/* Hat sich die Vorgabe bzgl. der Verfolgung des MPP ge�ndert? */
	routeChanged = ((!useRouting && lastUseRouting)  ||  (useRouting && !lastUseRouting));

	countBefore	= mapRoute->segmentCount;
	turnLength = turnPosition - positionZero;

	for (segment = 0; segment < (uint8_T)mapMAXROUTELENGTH; segment++) {
		uint8_T	index = (mapRoute->segmentStart + segment) % (ringId_T)mapMAXROUTELENGTH;

		/*lint -save */
		/*lint -e835 (Info -- A zero has been given as right argument to operator '+') */
		totalLength += (real32_T)mapRoute->segment[index].geometry.length * (real32_T)PSD_EHR_LENGTH_FACTOR + (real32_T)PSD_EHR_LENGTH_OFFSET;
		/*lint -restore */

		/* Falls sich "Links-" oder "Rechtabbiegen" bzw. die Vorgabe bzgl. der Verfolgung des MPP ge�ndert haben,
		werden alle Segmente ab der ersten entsprechenden Abbiegem�glichkeit verworfen */
		if (   (totalLength > turnLength) /* Die Blinker�nderung wird erst ab der turnPosition ausgewertet */
			&& (   (0u != ((uint8_T)mapRoute->branch[index] & (uint8_T)branchOptionLeft) && leftChanged)
				|| (0u != ((uint8_T)mapRoute->branch[index] & (uint8_T)branchOptionRight) && rightChanged)
				|| (0u != ((uint8_T)mapRoute->branch[index] & (uint8_T)branchOptionRoute) && routeChanged)
				)
			)
		{
			mapRoute->segmentCount = min(mapRoute->segmentCount, (uint8_T)(segment + 1u));
		}
		else
		{
			mapRoute->segmentCount = mapRoute->segmentCount;
		}
	}

	/* Ausgabe */
	*changed = (countBefore == mapRoute->segmentCount) ? false : true;


	return true;
}


static bool_T		prtGetRouteFromRoot(IN	const	psdSegmentId_T				 positionId,
										IN	const	uint8_T						 maxSegmentCalls,
										INOUT		uint8_T						*nSegmentCalls,
										OUT			mapRouteMemory_T			*mapRouteMemory,
										OUT			bool_T						*mapRouteValid)
{
	psdSegment_T currentSegment;
	mapRoute_T *mapRoute = &mapRouteMemory->mapRoute;

	prtInit_mapRouteMemory_T(mapRouteMemory);
	*mapRouteValid = false;

	mapRoute->segmentStart = (uint8_T)mapMAXROUTELENGTH;

	/*Hole das positionSegment*/
	diagFF(psdwGetSegmentData(positionId, &currentSegment));
	*nSegmentCalls += 1u;

	/*Vom positionSegment anhand der parentId die Segmente bis zur Wurzel des Psd-Baums einsammeln
	Und am ENDE der mapRoute ablegen (LIFO-Stack). Dabei die maximal erlaubten SegmentCalls ber�cksichtigen*/
	for (;;)
	{
		if (currentSegment.completeFlags == (psdCompleteFlag_T)PSD_EHR_COMPLETE_FLAGS_COMPLETE)
		{
			/*Die Segmente werden am Ende des Arrays gespeichert.*/
			diagFF(mapRoute->segmentStart > (uint8_T)0u);
			mapRoute->segmentStart--;
			mapRoute->segment[mapRoute->segmentStart] = currentSegment;
		}
		else
		{
			/*Kein einziges Segment in die mapRoute, da nicht alle Segment vollst�ndig sind!*/
			mapRoute->segmentStart = (uint8_T)mapMAXROUTELENGTH;
			break;
		}

		if (currentSegment.parentId == (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INIT)
		{
			/*Root Segment erreicht, damit ist die mapRoute vollst�ndig*/
			*mapRouteValid = true;
			break; /*lint !e9011 (Note -- more than one 'break' terminates loop [MISRA 2012 Rule 15.4, advisory])*/
		}

		diagFF(*nSegmentCalls <= maxSegmentCalls); /*Fehler, falls die Schleife wegen des Erreichen der maximalen ApiCalls verlassen wird.*/
		diagFF(psdwGetSegmentData(currentSegment.parentId, &currentSegment));
		*nSegmentCalls += 1u;
	}

	/*Segmente an den Anfang des Arrays kopieren, sodass Wurzel-Segment den Index 0 erh�lt.*/
	mapRoute->segmentCount = 0;
	while (mapRoute->segmentStart < (uint8_T)mapMAXROUTELENGTH)
	{
		mapRoute->segment[mapRoute->segmentCount] = mapRoute->segment[mapRoute->segmentStart];
		mapRoute->segmentStart++;
		mapRoute->segmentCount++;
	}
	mapRoute->segmentStart = 0u;

	return true;
}


static bool_T	   prtCopyChildSegments(IN	const	psdSegment_T				*currentSegment,
										IN	const	uint8_T						 maxSegmentCalls,
										INOUT		uint8_T						*nSegmentCalls,
										OUT			psdSegment_T				 children[psdMAXCHILDRENCOUNT],
										OUT			bool_T						*childrenComplete)
{
	uint8_T childIndex;

	diagFF(currentSegment->childCount <= (uint8_T)psdMAXCHILDRENCOUNT);
	if (maxSegmentCalls - *nSegmentCalls < currentSegment->childCount)
	{
		/*Es sind nicht genug Api-Calls erlaubt aus Laufzeitgr�nden*/
		*childrenComplete = false;
	}
	else
	{
		*childrenComplete = true;
		for (childIndex = 0u; childIndex < currentSegment->childCount; childIndex++)
		{
			/*N�chstes Kind kopieren*/
			diagFF(currentSegment->childSegments[childIndex] != (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INIT);		/*Es gibt ein weiteres Kind*/
			diagFF(psdwGetSegmentData(currentSegment->childSegments[childIndex], &children[childIndex]));
			*nSegmentCalls += 1u;

			/*Nur vollst�ndige Segmente �bernehmen*/
			if(children[childIndex].completeFlags == (psdCompleteFlag_T)PSD_EHR_COMPLETE_FLAGS_COMPLETE) {
				*childrenComplete = *childrenComplete;
			} else {
				*childrenComplete = false;
			}
		}
	}

	return true;
}


static bool_T		   prtFindBestChild(IN	const	real32_T					 turnPosition,
										IN  const	real32_T					 positionZero,
										IN	const	turnSignal_T				 turnSignal,
										IN	const	bool_T						 turnSignalConfident,
										IN	const	bool_T						 useRouting,
										IN	const	uint8_T						 childCount,
										IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],
										IN	const	mapRoute_T					*mapRoute,
										OUT			uint8_T						*smallestAngle,
										OUT			branchOptions_T				*branchOptions,
										OUT			psdSegment_T				*bestChild)
{
	uint8_T		indexLeft;
	uint8_T		indexRight;
	uint8_T		indexStraight;
	uint8_T		indexProbable;
	uint8_T		indexSmallestAngle;
	uint8_T		indexNoSignal;

	bool_T		lockLeft;
	bool_T		lockRight;

	branchCategory_T categories[psdMAXCHILDRENCOUNT];


	/* Relevante Child-Segmente heraussuchen */
	diagFF(prtPathPruneStraight( childCount,
								 children,
								 smallestAngle,
								&indexStraight,
								&indexProbable,
								&indexSmallestAngle));

	diagFF(prtPathPruneBranches( childCount,
								 children,
								 indexSmallestAngle < childCount ? indexSmallestAngle : indexStraight,
								&indexLeft,
								&indexRight,
								 categories));


	/* Haben wir bereits Abbiegem�glichkeiten "im R�cken"? */
	diagFF(prtPathGetBranchLock( turnPosition,
								 positionZero,
								 mapRoute,
								 turnSignalConfident,
								&lockLeft,
								&lockRight));


	diagFF(prtPathGetIndexNoSignal( turnSignal,
								    useRouting,
								    indexStraight,
								    indexProbable,
								    categories,
								   &indexNoSignal));


	/* Auswahl des  */
	diagFF(prtPathFollowChild( children,
							   turnSignal,
							   indexNoSignal,
							   indexLeft,
							   indexRight,
							   lockLeft,
							   lockRight,
							   bestChild));

	diagFF(prtPathGetBranchOptions(childCount,
								   indexLeft,
								   indexRight,
								   indexStraight,
								   indexProbable,
								   branchOptions));

	return true;
}


static bool_T	   prtPathPruneStraight(IN	const	uint8_T						 childCount,
										IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],
										OUT			uint8_T						*smallestAngle,
										OUT			uint8_T						*indexStraight,
										OUT			uint8_T						*indexProbable,
										OUT			uint8_T						*indexSmallestAngle)
{
	uint8_T		bestAngle;
	uint8_T		bestStraight;
	uint8_T		bestProbable;
	uint8_T		absMin;

	uint8_T		index;


	/* childCount plausibilisieren */
	diagFF(childCount >  0u);
	diagFF(childCount <= (uint8_T)psdMAXCHILDRENCOUNT);


	/* Init-Werte */
	bestAngle		= INVALID_UINT8;
	bestStraight	= 0u;
	bestProbable	= INVALID_UINT8;
	absMin			= 180u;


	/* Wir gehen alle Kindsegmente durch und suchen das beste nach links, rechts und geradeaus */
	for(index = 0; index < (ringId_T)psdMAXCHILDRENCOUNT; index++) {
		uint8_T		adjIndex	= index % childCount;
		psdAngle_T	angleNow	= children[adjIndex].geometry.branchAngle;
		real32_T	floatAngle	= (real32_T)angleNow * (real32_T)PSD_EHR_BRANCHANGLE_FACTOR + (real32_T)PSD_EHR_BRANCHANGLE_OFFSET + 0.5f;
		uint8_T		absAngle; 
		bool_T		acceptable;
		
		floatAngle	= fabsf(floatAngle);
		floatAngle	= min(floatAngle, 180.0f);

		absAngle	= (uint8_T)floatAngle;
		acceptable	= (children[adjIndex].attributes.lanes > 0u) 
					  && (   (children[adjIndex].attributes.streetClass > 0u) 
					      || (children[adjIndex].attributes.ramp == (uint8_T)PSD_EHR_RAMP_DOWN_ONE_WAY));

		/* Wir suchen das Segment mit dem kleinsten Abzweigwinkel unabh�ngig von der Rampenklasse
		PSD-Dockumentation SP: 
		Exclude all Segments which
			1) are one way roads in opposite direction
			2) have streetclass == 0 (misc) "Sackgasse"
			3) have ramp == 1 (rampUp) or ramp == 2 (rampDown)
			4) smallest angle...
		*/
		if ((absAngle < absMin)  &&  acceptable) {
			bestAngle = adjIndex;
		}

		/*Wir suchen das Segment mit den SP-Attribut*/
		if(children[adjIndex].attributes.isStraightestPath) {
			bestStraight = adjIndex;
		}

		/* Wir suchen das Segment mit den MPP-Attribut*/
		if(children[adjIndex].attributes.isMostProbablePath && acceptable) {
			bestProbable = adjIndex;
		}

		absMin	= min(absMin, absAngle);
	}


	/* F�r den Fall, dass an diesem Branch kein MPP gefunden wurde, fallen wir auf den SP zur�ck */
	bestProbable = (bestProbable < INVALID_UINT8) ? bestProbable : bestStraight;


	/* Ausgabe */
	*smallestAngle	= absMin;
	*indexStraight	= bestStraight;
	*indexProbable	= bestProbable;
	*indexSmallestAngle = bestAngle;


	return true;
}


static bool_T	   prtPathPruneBranches(IN	const	uint8_T						 childCount,
										IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],
										IN	const	uint8_T						 indexStraight,
										OUT			uint8_T						*indexLeft,
										OUT			uint8_T						*indexRight,
										OUT			branchCategory_T			 categories[psdMAXCHILDRENCOUNT])
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	uint8_T		index;

	real32_T	curStraightBegin;
	real32_T	curStraightEnd;
	real32_T	curvatureStraight;
	real32_T	branchStraight;

	real32_T	angleLeft;
	real32_T	angleRight;
	real32_T	curLeft;
	real32_T	curRight;

	uint8_T		bestLeft;
	uint8_T		bestRight;


	/* childCount plausibilisieren */
	diagFF(childCount >  0u);
	diagFF(childCount <= (uint8_T)psdMAXCHILDRENCOUNT);
	diagFF(indexStraight < childCount);


	/* Kr�mmung und Abbiegewinkel des geraden Segments */
	curStraightBegin	= ((real32_T)children[indexStraight].geometry.curvatureStart * (real32_T)PSD_EHR_CURVATURE_FACTOR   + (real32_T)PSD_EHR_CURVATURE_OFFSET);
	curStraightEnd		= ((real32_T)children[indexStraight].geometry.curvatureEnd   * (real32_T)PSD_EHR_CURVATURE_FACTOR   + (real32_T)PSD_EHR_CURVATURE_OFFSET);
	branchStraight		= ((real32_T)children[indexStraight].geometry.branchAngle    * (real32_T)PSD_EHR_BRANCHANGLE_FACTOR + (real32_T)PSD_EHR_BRANCHANGLE_OFFSET);
	curvatureStraight	= 0.5f * (curStraightBegin + curStraightEnd);


	/* Init-Werte */
	bestLeft	=  INVALID_UINT8;
	bestRight	=  INVALID_UINT8;
	angleLeft	= (paramSet->pathRouter.routeFilter.turnStraightest) ? -INVALID_VALUE :  INVALID_VALUE;
	angleRight	= (paramSet->pathRouter.routeFilter.turnStraightest) ?  INVALID_VALUE : -INVALID_VALUE;
	curLeft		= (paramSet->pathRouter.routeFilter.turnStraightest) ? -INVALID_VALUE :  INVALID_VALUE;
	curRight	= (paramSet->pathRouter.routeFilter.turnStraightest) ?  INVALID_VALUE : -INVALID_VALUE;


	/* Wir gehen alle Kindsegmente durch und suchen das beste nach links, rechts und geradeaus */
	for(index = 0; index < (ringId_T)psdMAXCHILDRENCOUNT; index++) {
		uint8_T		adjIndex		= index % childCount;
		real32_T	curvatureStart	= ((real32_T)children[adjIndex].geometry.curvatureStart * (real32_T)PSD_EHR_CURVATURE_FACTOR   + (real32_T)PSD_EHR_CURVATURE_OFFSET);
		real32_T	curvatureEnd	= ((real32_T)children[adjIndex].geometry.curvatureEnd   * (real32_T)PSD_EHR_CURVATURE_FACTOR   + (real32_T)PSD_EHR_CURVATURE_OFFSET);
		real32_T	branchAngle		= ((real32_T)children[adjIndex].geometry.branchAngle    * (real32_T)PSD_EHR_BRANCHANGLE_FACTOR + (real32_T)PSD_EHR_BRANCHANGLE_OFFSET);
		real32_T	absAngle		= fabsf(branchAngle);
		real32_T	curvatureMean	= 0.5f * (curvatureStart + curvatureEnd);
		bool_T		acceptable		=    (children[adjIndex].attributes.lanes > 0u) 
									  && ((children[adjIndex].attributes.streetClass > 0u) || (children[adjIndex].attributes.ramp == (uint8_T)PSD_EHR_RAMP_DOWN_ONE_WAY))
									  && (absAngle < paramSet->pathRouter.routeFilter.maxBranchAngle);


		/*lint -save -e777 (Info -- Testing floats for equality)*/
		/* Wir haben den Geradeaus-Branch */
		if(indexStraight == adjIndex) {
			categories[index] = branchCategoryStraight;
		}

		/* Es geht nach links: Branch-Angle hat Priorit�t vor Kr�mmung */
		else if(   ((curvatureMean > curvatureStraight) && (branchAngle == branchStraight) && paramSet->pathRouter.routeFilter.useCurvature)
				|| (branchAngle < branchStraight)) {
			categories[index] = branchCategoryLeft;

			/* Wenn dieser Branch weniger stark nach links "brancht" als der aktuelle Links-Kandidat, wird er �bernommen */
			if(   ((((paramSet->pathRouter.routeFilter.turnStraightest) ? (curvatureMean < curLeft) : (curvatureMean > curLeft)) && (branchAngle == angleLeft) && paramSet->pathRouter.routeFilter.useCurvature)
			     || ((paramSet->pathRouter.routeFilter.turnStraightest) ? (branchAngle > angleLeft) : (branchAngle < angleLeft)))
				&& (acceptable)) {
				bestLeft	= adjIndex;
				angleLeft	= branchAngle;
				curLeft		= curvatureMean;
			}
			else {
				bestLeft	= bestLeft;
				angleLeft	= angleLeft;
				curLeft		= curLeft;
			}
		}

		/* ...ansonsten kann es nur noch nach rechts gehen */
		else if(   ((curvatureMean < curvatureStraight) && (branchAngle == branchStraight) && paramSet->pathRouter.routeFilter.useCurvature)
				|| (branchAngle > branchStraight)) {
			categories[index] = branchCategoryRight;

			/* Wenn dieser Branch weniger stark nach links "brancht" als der aktuelle Links-Kandidat, wird er �bernommen */
			if(   ((((paramSet->pathRouter.routeFilter.turnStraightest) ? (curvatureMean > curRight) : (curvatureMean < curRight)) && (branchAngle == angleRight) && paramSet->pathRouter.routeFilter.useCurvature)
			     || ((paramSet->pathRouter.routeFilter.turnStraightest) ? (branchAngle < angleRight) : (branchAngle > angleRight)))
				&& (acceptable)) {
				bestRight	= adjIndex;
				angleRight	= branchAngle;
				curRight	= curvatureMean;
			}
			else {
				bestRight	= bestRight;
				angleRight	= angleRight;
				curRight	= curRight;
			}
		}
		else
		{
			categories[index] = branchCategoryStraight;
		}
		/*lint -restore*/
	}


	/* Ausgabe */
	*indexLeft	= bestLeft;
	*indexRight	= bestRight;


	return true;
}


static bool_T	   prtPathGetBranchLock(IN	const	real32_T					 turnPosition,
										IN	const	real32_T					 positionZero,
										IN	const	mapRoute_T					*mapRoute,
										IN	const	bool_T						 turnSignalConfident,
										OUT			bool_T						*lockLeft,
										OUT			bool_T						*lockRight)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	bool_T		foundLeft;
	bool_T		foundRight;

	uint8_T		segment;
	
	real32_T	turnLength;
	real32_T	totalLength = 0.0f;

	foundLeft  = false;
	foundRight = false;

	turnLength = turnPosition - positionZero;

	for(segment = 0; segment < (ringId_T)mapMAXROUTELENGTH; segment++) {
		uint8_T	index = (mapRoute->segmentStart + segment) % (ringId_T)mapMAXROUTELENGTH;
		volatile bool_T leftBranch, rightBranch;

		/*lint -save */
		/*lint -e835 (Info -- A zero has been given as right argument to operator '+') */
		totalLength += (real32_T)mapRoute->segment[index].geometry.length * (real32_T)PSD_EHR_LENGTH_FACTOR + (real32_T)PSD_EHR_LENGTH_OFFSET;
		/*lint -restore */
		
		leftBranch = (((uint8_T)mapRoute->branch[index] & (uint8_T)branchOptionLeft) != 0u);
		rightBranch = (((uint8_T)mapRoute->branch[index] & (uint8_T)branchOptionRight) != 0u);

		/*Liegt eine Branchm�glichkeit vor dem letzten Routensegment, aber nach der Blinkerposition? Dann Sprren wir Abbiegen in dessen Richtung*/
		if(		(segment + 1u <  mapRoute->segmentCount)
			&&	(totalLength > turnLength))
		{
			foundLeft = leftBranch || foundLeft;
			foundRight = rightBranch || foundRight;
		} else {
			/*Laufzeit*/
			leftBranch = leftBranch || foundLeft;
			rightBranch = rightBranch || foundRight;
		}

		/*Liegt das letzte Routensegment vor der Blinkerposition? Dann Sperren wir Abbiegen in beide Richtungen.*/
		if (	(segment + 1u == mapRoute->segmentCount)
			&&	(totalLength <= turnLength))
		{
			foundLeft = true;
			foundRight = true;
		} else {
			/*Laufzeit*/
			leftBranch = false;	
			rightBranch = false;
		}
	} /*lint !e438 (Las Last value assigned to variable 'rightBranch/leftBranch' (defined at line 1119) not used [MISRA 2012 Rule 2.2, required])*/

	/* Soll das Abfahren von mehrspurigen Stra�en gesperrt werden? */
	if(   (paramSet->pathRouter.routeFilter.reluctantOnMultipleLanes)
	   && (!turnSignalConfident)
	   && (mapRoute->segment[(mapRoute->segmentStart + mapRoute->segmentCount - 1u) % (ringId_T)mapMAXROUTELENGTH].attributes.lanes > 1u)) {
		foundLeft	= true;
		foundRight	= true;
	}

	/* Soll das Abfahren von mehrspurigen Stra�en gesperrt werden? */
	if(   (paramSet->pathRouter.routeFilter.lockOnMultipleLanes)
	   && (mapRoute->segment[(mapRoute->segmentStart + mapRoute->segmentCount - 1u) % (ringId_T)mapMAXROUTELENGTH].attributes.lanes > 1u)) {
		foundLeft	= true;
		foundRight	= true;
	}

	/* Soll das Abfahren von baulich getrennten Richtungsfahrbahnen gesperrt werden? */
	if(   (paramSet->pathRouter.routeFilter.lockOnRampOneWay)
	   && (mapRoute->segment[(mapRoute->segmentStart + mapRoute->segmentCount - 1u) % (ringId_T)mapMAXROUTELENGTH].attributes.ramp == (uint8_T)PSD_EHR_RAMP_ONE_WAY)) {
		foundLeft	= true;
		foundRight	= true;
	}

	/* Ausgabe */
	*lockLeft	= foundLeft;
	*lockRight	= foundRight;

	return true;
}


static bool_T		 prtPathFollowChild(IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],
										IN	const	turnSignal_T				 turnSignal,
										IN	const	uint8_T						 indexNone,
										IN	const	uint8_T						 indexLeft,
										IN	const	uint8_T						 indexRight,
										IN	const	bool_T						 lockLeft,
										IN	const	bool_T						 lockRight,
										OUT			psdSegment_T				*bestChild)
{
	uint8_T		indexFollow;

	/* Falls kein explizites turnSignal gesetzt ist, folgen wir der (SP/MPP)-Vorgabe, andernfalls gewinnt die
	   "beblinkte" Richtung, sofern sie nicht durch einen Branch hinter dem aktuellen Segment wahrgenommen wurde */
	if((   (turnSignalLeft     == turnSignal)
		|| (turnSignalLeftOnly == turnSignal))
	   && !lockLeft) {
		indexFollow = (indexLeft < (uint8_T)psdMAXCHILDRENCOUNT)  ? indexLeft  : indexNone;
	}
	else if((   (turnSignalRight     == turnSignal)
			 || (turnSignalRightOnly == turnSignal))
			&& !lockRight) {
		indexFollow = (indexRight < (uint8_T)psdMAXCHILDRENCOUNT) ? indexRight : indexNone;
	}
	else {
		indexFollow = indexNone;
	}


	
	/* Relevanten Eintrag in die Ausgabe kopieren */
	*bestChild = children[indexFollow];


	return true;
}


static bool_T		prtPathGetIndexNoSignal(
										IN	const	turnSignal_T				 turnSignal,
										IN	const	bool_T						 useRouting,
										IN	const	uint8_T						 indexStraight,
										IN	const	uint8_T						 indexProbable,
										IN	const	branchCategory_T			 categories[psdMAXCHILDRENCOUNT],
										OUT			uint8_T						*indexNoSignal)
{
	uint8_T		indexNone;

	/* Indizes auf Plausbilit�t pr�fen */
	diagFF(indexStraight	< (uint8_T)psdMAXCHILDRENCOUNT);


	/* Welches Child w�hlen wir aus, falls kein explizites turnSignal gesetzt ist? */
	indexNone	= (indexProbable < (uint8_T)psdMAXCHILDRENCOUNT && useRouting) ? indexProbable : indexStraight;


	/* Fall die Richtung, die durch das Routing vorgegeben wird, durch den vehicleObserver gesperrt ist,
	   fallen wir auf den SP-Branch zur�ck */
	if(branchCategoryLeft  == categories[indexNone] && (turnSignalLockLeft == turnSignal || turnSignalRightOnly == turnSignal || turnSignalLockBoth == turnSignal)) {
		indexNone = indexStraight;
	}

	if(branchCategoryRight == categories[indexNone] && (turnSignalLockRight == turnSignal || turnSignalLeftOnly == turnSignal || turnSignalLockBoth == turnSignal)) {
		indexNone = indexStraight;
	}

	/*Ausgabe*/
	*indexNoSignal = indexNone;

	return true;
}



/* Gibt es eine Abbiegem�glichkeit nach links bzw. rechts oder unterscheiden sich SP und MPP? */
static bool_T	prtPathGetBranchOptions(IN	const	uint8_T						 childCount,
										IN	const	uint8_T						 indexLeft,
										IN	const	uint8_T						 indexRight,
										IN	const	uint8_T						 indexStraight,
										IN	const	uint8_T						 indexProbable,
										OUT			branchOptions_T				*branchOptions)
{
	uint8_T	options = 0u;
	
	/* childCount plausibilisieren */
	diagFF(childCount >  0u);
	diagFF(childCount <= (uint8_T)psdMAXCHILDRENCOUNT);
	diagFF(indexStraight < childCount);

	options |= (indexLeft  < (uint8_T)psdMAXCHILDRENCOUNT) ? (uint8_T)branchOptionLeft  : (uint8_T)branchOptionNone;
	options |= (indexRight < (uint8_T)psdMAXCHILDRENCOUNT) ? (uint8_T)branchOptionRight : (uint8_T)branchOptionNone;
	options |= ((indexStraight != indexProbable)	&& (indexProbable < (uint8_T)psdMAXCHILDRENCOUNT)) ? (uint8_T)branchOptionRoute : (uint8_T)branchOptionNone;

	*branchOptions = (branchOptions_T)options; /*lint !e9030 !e9034: (Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required])*/

	return true;
}
