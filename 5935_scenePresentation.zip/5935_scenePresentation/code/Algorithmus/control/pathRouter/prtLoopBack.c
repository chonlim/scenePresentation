#include "pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"

#include "prtLoopBack.h"
#include "prtLoopBackStatic.h"
#include "prtTools.h"
#include "prtPrepare.h"
#include "prtAge.h"

#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/pathRouterCommon/prtDataInterface.h"


void				  prtGetMapPathInfo(IN	const	mapPath_T				*mapPath,
										IN	const	mapHeadingFilter_T		*headingFilter,
										IN	const	mapAgeFilter_T			*ageFilter,
										IN	const	real32_T				 position,
										OUT			mapPathInfo_T			*mapPathInfo)
{
	prtSpeedLimitUnit_T	limitUnit;
	vobsSignUnit_T		signUnit;
	vobsTrafficDir_T	trafficDirection;
	real32_T			curvature;
	real32_T			roundaboutTail;
	uint32_T			ageTicks;


	/* Abfragen der g�ltigen Einheit f�r Geschwindigkeitslimits */
	limitUnit = prtGetSpeedLimitUnit(mapPath);

	if(prtSpeedLimitUnitKMH == limitUnit) {
		signUnit = signUnitKMH;
	}
	else if(prtSpeedLimitUnitMPH == limitUnit) {
		signUnit = signUnitMPH;
	}
	else {
		signUnit = signUnitUnknown;
	}


	/*Verkehrsrichtung*/
	if(!prtGetTrafficDirection(mapPath, &trafficDirection)) {
		trafficDirection = trafficDirUnknown;
	}

	/* Kr�mmung an der Fahrzeugposition abfragen */
	if (!prtInterpolateCurvature( mapPath,
							 position,
								&curvature))
	{
		curvature = INVALID_VALUE;
	}


	/* Im Kreisverkehr zur�ckgelegte Fahrtstrecke abfragen */
	prtGetRoundaboutTail( mapPath,
						  position,
						 &roundaboutTail);


	/* Kartenalter abfragen */
	prtGetAgeTicks( ageFilter,
				   &ageTicks);
	/* Daten an den vehicleObserver r�ckmelden */
	vobsSetMapPathInfo(	headingFilter->isInitialized,
						signUnit,
						trafficDirection,
						curvature,
						roundaboutTail,
						ageTicks,
						mapPathInfo);


	/* Bekannte Speed Limits an die mapPathInfo-Struktur anh�ngen */
	prtAttachInfoLimits( mapPathInfo,
						 mapPath);


	/* Bekannte Steigungsattribute an die mapPathInfo-Struktur anh�ngen */
	prtAttachInfoSlopes( mapPathInfo,
						 mapPath);


	return;
}


static void		   prtGetRoundaboutTail(IN	const	mapPath_T				*mapPath,
										IN	const	real32_T				 position,
										OUT			real32_T				*roundaboutTail)
{
	roundaboutIterator_T	iterator;
	bool_T					roundabout;
	real32_T				tail;


	/* Abfragen, ob sich an der Fahrzeugposition ein Kreisverkehr befindet */
	if(prtGetStatus(mapPath))
	{
		if (prtGetRoundaboutIterator( mapPath, &iterator))
		{
			if(!prtIsRoundaboutAt(&iterator,
							position,
							true,
							&roundabout,
								  &tail)) {
				/* Hier wird ein potentieller diagFF-Fehler abgefangen, um im (unwahrscheinlichen)
				   Fehlerfall die Bedienung des Loopback-Kanals gew�hrleisten zu k�nnen. */
				roundabout	= false;
				tail		= 0.0f;
			}

			if(!roundabout) {
				tail = 0.0f;
			}
		}
		else
		{
			tail = 0.0f;
		}
	}
	else 
	{
		tail = 0.0f;
	}


	/* Ausgabe */
	*roundaboutTail = tail;
}


static void			prtAttachInfoLimits(INOUT		mapPathInfo_T			*mapPathInfo,
										IN	const	mapPath_T				*mapPath)
{
	uint16_T			index;

	/* Alle bekannten Limits an die mapPathInfo-Struktur anh�ngen */
	for(index = 0; index < (uint16_T)vobsINFOLIMITCOUNT; index++) {
		bool_T			valid;
		prtSpeedLimit_T	limit;

		valid = prtGetSpeedLimit( mapPath,
								  index,
								 &limit);

		vobsAddMapPathLimit(mapPathInfo,
							valid,
							limit.position,
							limit.limit);
	}
}


static void			prtAttachInfoSlopes(INOUT		mapPathInfo_T			*mapPathInfo,
										IN	const	mapPath_T				*mapPath)
{
	uint16_T			index;

	/* Alle bekannten Limits an die mapPathInfo-Struktur anh�ngen */
	for(index = 0; index < (uint16_T)vobsINFOSLOPECOUNT; index++) {
		bool_T		valid;
		prtSlope_T	slope;

		valid = prtGetSlope( mapPath,
							 index,
							&slope);

		vobsAddMapPathSlope(mapPathInfo,
							valid,
							slope.position,
							slope.slope);
	}
}
