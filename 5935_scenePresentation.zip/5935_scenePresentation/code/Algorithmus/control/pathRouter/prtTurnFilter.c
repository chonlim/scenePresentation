#include "pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/pathRouter/prtTurnFilterStatic.h"
#include "control/pathRouter/prtTurnFilter.h"
#include "control/pathRouter/prtRouteFilter.h"
#include "control/pathRouter/prtAttributes.h"

#include "control/psdWrapper/psdWrapper.h"

#include "control/parameterSet/parameterSetCtrl.h"
/*lint -esym(9045, struct _exception)*/
#include <math.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtTurnFilter)


bool_T		  prtUpdateTurnFilter(	INOUT		mapTurnFilter_T		*turnFilter,
									IN	const	mapRoute_T			*mapRoute,
									IN	const	real32_T			 pathHeading,
									IN	const	real32_T			 egoVelocity,
									IN	const	real32_T			 egoHeading,
									IN	const	bool_T				 headValid,
									IN	const	bool_T				 extendHold)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();
	psdSegment_T dummySegment;
	mapTurnFilter_T initFilter;
	bool_T psdOnRoute, timeout, segmentInvalid;

	/*PSD-Position holen*/
	diagFF(prtInitTurnFilter(	&initFilter,
								 paramSet));
	psdOnRoute = prtIsSegmentOnRoute(mapRoute, initFilter.virtualPosition.segmentId, NULL);

	/*Z�hler inkrementieren und ggf. Position auf n�chstes Segment vorschieben*/
	diagFF(prtIncrementTurnFilter(	turnFilter,
									mapRoute,
									pathHeading,
									egoVelocity,
									egoHeading,
									headValid));

	
	/*Virtuelle Position in PSD-Baum g�ltig?*/
	segmentInvalid = !psdwGetSegmentData(turnFilter->virtualPosition.segmentId, &dummySegment);

	/*Der Filter wird zur�ckgesetzt (virtualPosition = rawPosition), wenn eine dieser Gr��en einen Maximalwert �berschreitet.*/
	if (extendHold)
	{
		timeout = turnFilter->holdDistance		> paramSet->pathRouter.turnFilter.extendedDistance;
		timeout = turnFilter->holdHeadDeviation	> paramSet->pathRouter.turnFilter.extendedHeadDeviaton	|| timeout;
		timeout = turnFilter->holdTicks			> paramSet->pathRouter.turnFilter.extendedTicks			|| timeout;
	} else {
		timeout = turnFilter->holdDistance		> paramSet->pathRouter.turnFilter.normalDistance;
		timeout = turnFilter->holdHeadDeviation	> paramSet->pathRouter.turnFilter.normalHeadDeviaton	|| timeout;
		timeout = turnFilter->holdTicks			> paramSet->pathRouter.turnFilter.normalTicks			|| timeout;
	}

	/*Ausgabe*/
	if(psdOnRoute || timeout || segmentInvalid || !turnFilter->virtualPosition.valid) 
	{
		*turnFilter = initFilter;
	} else {
		*turnFilter = *turnFilter;
	}

	return true;
}

static bool_T		prtCheckPsdPosition(IN	const	psdPosition_T				*psdPosition)
{
	bool_T valid;
	valid = psdPosition->id					>= (PsdEhr_SegmentId_t)PSD_EHR_SEGMENT_ID_MIN;
	valid = psdPosition->id					<= (PsdEhr_SegmentId_t)PSD_EHR_SEGMENT_ID_MAX							&& valid;
	valid = psdPosition->length				>= (PsdEhr_Length_t)PSD_EHR_LENGTH_VALUE_MIN							&& valid;/*lint !e568 !e685*/
	valid = psdPosition->length				<= (PsdEhr_Length_t)PSD_EHR_LENGTH_VALUE_MAX							&& valid;
	valid = psdPosition->lane				>= (PsdEhr_PositionLane_t)PSD_EHR_POS_LANE_VALUE_MIN					&& valid;/*lint !e568 !e685*/
	valid = psdPosition->lane				<= (PsdEhr_PositionLane_t)PSD_EHR_POS_LANE_VALUE_MAX					&& valid;
	valid = psdPosition->inhibitTime		>= (PsdEhr_InhibitTime_t)PSD_EHR_INHIBITTIME_VALUE_MIN					&& valid;/*lint !e568 !e685*/
	valid = psdPosition->inhibitTime		<= (PsdEhr_InhibitTime_t)PSD_EHR_INHIBITTIME_VALUE_MAX					&& valid;
	valid = psdPosition->longitudinalError	>= (PsdEhr_LongitudinalError_t)PSD_EHR_POS_LONGITUDINAL_ERROR_VALUE_MIN	&& valid;/*lint !e568 !e685*/
	valid = psdPosition->longitudinalError	<= (PsdEhr_LongitudinalError_t)PSD_EHR_POS_LONGITUDINAL_ERROR_VALUE_MAX	&& valid;

	return valid ? true : false;
}


static bool_T	prtInitTurnFilter(	OUT			mapTurnFilter_T			*turnFilter,
									IN const	parameterSetCtrl_T		*parameterSet)
{
	bool_T valid;
	psdStatus_T psdStatus;
	psdPosition_T psdPosition;

	/*PSD-Position und -Status holen*/
	valid = psdwGetQuality(&psdStatus);
	valid = psdStatus == (psdStatus_T)PSD_EHR_STATUS_VALID	&& valid;
	valid = psdwGetPositionData(&psdPosition)				&& valid;
	valid = prtCheckPsdPosition(&psdPosition)				&& valid;

	/*Filter Position initialisieren*/
	turnFilter->virtualPosition.valid = valid;
	turnFilter->virtualPosition.segmentId = psdPosition.id;
	turnFilter->virtualPosition.inhibitTime = (real32_T)PSD_EHR_INHIBITTIME_OFFSET + (real32_T)PSD_EHR_INHIBITTIME_FACTOR * (real32_T)psdPosition.inhibitTime; /*lint !e835 (plus zero)*/
	turnFilter->virtualPosition.inhibitTime *= parameterSet->pathRouter.positionFilter.inhibitTimeFactor;
	turnFilter->virtualPosition.inhibitTime += parameterSet->pathRouter.positionFilter.inhibitTimeOffset;
	diagFF(prtOffsetToUint8(psdPosition.length, &turnFilter->virtualPosition.remainingLength));

	/*Filter Z�hler initialisieren*/
	turnFilter->holdDistance		= 0.0f;
	turnFilter->holdHeadDeviation	= 0.0f;
	turnFilter->holdTicks			= 0u;
	turnFilter->segmentStartRef		= 0.0f;

	return true;
}


bool_T			prtIncrementTurnFilter(	INOUT		mapTurnFilter_T		*turnFilter,
										IN	const	mapRoute_T			*mapRoute,
										IN	const	real32_T			 pathHeading,
										IN	const	real32_T			 egoVelocity,
										IN	const	real32_T			 egoHeading,
										IN	const	bool_T				 headValid)
{
	real32_T headingDiff;
	uint8_T routeOffset;
	bool_T routeValid;
	mapRawVehiclePosition_T virtualPosition;
	const psdSegment_T *nextSegment;

	/* Aktualisieren der Z�hler */
	turnFilter->holdDistance			+= egoVelocity * controlCYCLETIME;
	turnFilter->holdTicks++;

	headingDiff = headValid ? egoHeading - pathHeading : 0.0f;
	turnFilter->holdHeadDeviation	+= fabsf(headingDiff) * egoVelocity * controlCYCLETIME;
	
	/*Vorschieben der Position*/
	routeValid = prtIsSegmentOnRoute(mapRoute, turnFilter->virtualPosition.segmentId, &routeOffset);
	nextSegment = &mapRoute->segment[(mapRoute->segmentStart + routeOffset + 1u) % (uint8_T)mapMAXROUTELENGTH];
	
	virtualPosition.inhibitTime	= turnFilter->virtualPosition.inhibitTime;
	virtualPosition.segmentId	= nextSegment->id;
	virtualPosition.valid = routeValid;
	diagFF(prtOffsetToUint8(nextSegment->geometry.length, &virtualPosition.remainingLength));
	
	/*Ausgabe*/
	if (turnFilter->holdDistance - turnFilter->segmentStartRef >= (real32_T)turnFilter->virtualPosition.remainingLength)
	{
		turnFilter->segmentStartRef += (real32_T)turnFilter->virtualPosition.remainingLength; /*holdDistance == segmentStartRef + "kleine Strecke, die schon auf neuem Segment gefahren wurde."*/
		turnFilter->virtualPosition = virtualPosition;
	} else {
		turnFilter->segmentStartRef += 0.0f; /*lint !e835 (Info: plus zero zur Zeitverdummung)*/
		turnFilter->virtualPosition = turnFilter->virtualPosition;
	}

	turnFilter->virtualPosition.valid = routeValid;
	return true;
}
