#ifndef guard_prtInfo_h
#define guard_prtInfo_h

#include "pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"

#ifdef __cplusplus
extern "C" {
#endif

/** \brief Kopiert die persistenten mapPath-Daten in die ausged�nnte Struktur `mapInfo` zur �bergabe an den strategy-Task.
Falls nicht alle Kr�mmungen, BranchAngles oder Steigungen kopiert werden k�nnen, wird die `mapInfo->distance` entsprechend gek�rzt.

Die Daten aus den Ringspeichern werden in den Unterfunktionen \ref prtBuildInfoGps(), \ref prtBuildInfoSpeedLimits(), \ref prtBuildInfoRightOfWay(), 
\ref prtBuildInfoCurvatures(), \ref prtBuildInfoBranchAngles() und \ref prtBuildInfoSlopes() �bertragen.

Es werden alle Kr�mmungen der Segmentanf�nge �bertragen.
Falls die Kr�mmung am Segmentende gleich dem anschlie�enden Segmentanfang ist (Stetiger �bergang), wird sie nicht �bertragen.
Falls die Kr�mmung eines konstanten Segments vom anschlie�enden Segmentanfang abweicht, wird sie nicht �bertragen und es wird die Flag `endOfConstantSegmentMissing` gesetzt.
Falls die Kr�mmung eines nicht-konstanten Segments vom anschlie�enden Segmentanfang abweicht, wird sie �bertragen. Nur in diesem Fall liegen zwei Kr�mmungen an einer Position vor.
Falls mehr Kr�mmungen vorliegen als �bertragen werden k�nnen, wird die `mapInfo->distance` auf die Position der letzten Kr�mmung gek�rzt.

Es werden die ersten 15(parametrierbar) Slopes komplett �bertragen. Die folgenden Slopes werden mit einem maximalen Spacing von 2(parametrierbar)
so �bertragen, dass das Horizontende erreicht wird. Falls mehr Slopes vorliegen als �bertragen werden konnten, wird die `mapInfo->distance` 
auf die Position der letzten Slope gek�rzt.

Falls mehr branchAngles vorliegen als �bertragen werden konnten, wird die `mapInfo->distance` auf die Position des letzten branchAngle gek�rzt.

Die �bringen Attribute werden ohne Modifikation �bertragen, solange der Speicherplatz in `mapInfo` ausreicht. Auch die `mapInfo->distance` wird bei diesen Attributen nicht modifiziert.

Die Flag `infoValid` ist `false` wenn die Anzahl eines der folgenden Attribute Null betr�gt: gpsInfo, speedLimit, streetClass, laneSituation, curvature, slope.

\spec SwMS_Innodrive2_PSD_174
\spec SwMS_Innodrive2_PSD_176

\ingroup pathRouter_caching
*/
bool_T				 prtBuildPathRouterInfo(IN	const	mapPathMemory_T				*mapPathMemory,		/**<persistente Pfaddaten*/
											OUT			mapInfo_T					*mapInfo,			/**<�bergabestruktur*/
											OUT			bool_T						*infoValid			/**<G�ltigkeits-Flag*/
											);


/** \brief Berechnet aus `segmentRingId`und dem ganzzahligen offset auf dem Segment die `position`[Einheit: m] relativ zur Fahrzeugposition.
\ingroup pathRouter_api
*/
bool_T				prtPositionToUint16(	IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	ringId_T					 segmentRingId,		/**<Segmentnummer*/
											IN const	uint8_T						 offset,  			/**<Position relativ zum Segmentanfang*/
											OUT			uint16_T					*position			/**<Distanz in Metern*/
											);


#ifdef __cplusplus
}
#endif

#endif
