#ifndef guard_prtHold_h
#define guard_prtHold_h


void		  prtUpdateHold(INOUT		mapHoldFilter_T		*holdFilter,
							IN	const	bool_T				 pathValid,
							IN	const	real32_T			 pathHeading,
							IN	const	real32_T			 egoVelocity,
							IN	const	real32_T			 egoHeading,
							IN	const	bool_T				 headValid,
							OUT			bool_T				*holdValid
							);


#endif
