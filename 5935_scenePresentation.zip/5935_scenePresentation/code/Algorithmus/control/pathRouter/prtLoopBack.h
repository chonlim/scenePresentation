#ifndef guard_prtLoopBack_h
#define guard_prtLoopBack_h


/**	\brief		Feedback die Tempolimit-Einheit und der anhand der Karte korrigierten Fahrzeug-Heading an das Modul \ref vehicleObserver.
\spec SwMS_Innodrive2_PSD_163
\spec SwMS_Innodrive2_PSD_184
\spec SwMS_Innodrive2_PSD_185
*/
void				  prtGetMapPathInfo(IN	const	mapPath_T				*mapPath,
										IN	const	mapHeadingFilter_T		*headingFilter,
										IN	const	mapAgeFilter_T			*ageFilter,
										IN	const	real32_T				 position,
										OUT			mapPathInfo_T			*mapPathInfo
										);


#endif
