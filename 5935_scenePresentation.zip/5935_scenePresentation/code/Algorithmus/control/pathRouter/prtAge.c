#include "pathRouter.h"
#include <common/pathRouterCommon/pathRouter_private.h>
#include "prtAge.h"


void		   prtUpdateAge(INOUT		mapAgeFilter_T		*ageFilter,
							IN	const	bool_T				 pathValid,
							IN	const	bool_T				 ageReset)
{
	/* Aktualisieren der Z�hler */
	if(pathValid) {
		ageFilter->ageTicks++;
	}

	/* Wenn in diesem Zyklus kein g�ltiger Baum aufgebaut werden konnte, wird der Altersz�hler zur�ckgesetzt */
	if(ageReset) {
		ageFilter->ageTicks = 0;
	}
}


void		 prtGetAgeTicks(IN	const	mapAgeFilter_T		*ageFilter,
							OUT			uint32_T			*ageTicks)
{
	*ageTicks = ageFilter->ageTicks;
}
