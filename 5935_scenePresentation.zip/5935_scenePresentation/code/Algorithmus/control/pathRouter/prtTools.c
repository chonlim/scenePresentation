#include "control/pathRouter/prtTools.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/pathRouter/prtToolsStatic.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "common/pathRouterCommon/prtTypeMapping.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtTools)


static real32_T scalePosition(	IN const real32_T			positionZero,
								IN const uint16_T			position)
{
	return (real32_T)position + positionZero;
}


static bool_T	prtConvertPosition(	IN const	mapPathMemory_T		*mapPathMemory,
									IN const	ringId_T			 segmentRingId,
									IN const	uint8_T				 offset,
									OUT			real32_T			*position)
{
	diagFF(segmentRingId < (ringId_T)mapMAXROUTELENGTH);
	*position = scalePosition(mapPathMemory->positionZero, (uint16_T)(mapPathMemory->segmentRing.segment[segmentRingId].startDistance + offset));
	return true;
}


bool_T		prtIsMemoryValid(			IN const	pathRouterMemory_T			*pathRouterMemory)
{
	return pathRouterMemory->valid;
}


uint8_T		prtGetCountryCode(			IN const	pathRouterMemory_T			*pathRouterMemory)
{
	return (uint8_T)pathRouterMemory->mapPathMemory.systemAttributes.countryCode;
}


uint16_T	prtGetOnlineSpeedCount(		IN const	pathRouterMemory_T			*pathRouterMemory)
{
	return pathRouterMemory->mapPathMemory.onlineSpeedRing.count;
}

bool_T		prtGetBuiltUpArea(			IN const	pathRouterMemory_T			*pathRouterMemory,	
										IN const	uint16_T					 index,				
										OUT			prtBuiltUpArea_T			*builtUpArea)
{
	diagFF(pathRouterMemory->mapPathMemory.builtUpRing.count <= (ringId_T)mapPATHBUILTUPAREACOUNT);
	if (index >= pathRouterMemory->mapPathMemory.builtUpRing.count)	{
		builtUpArea->type = false;
		builtUpArea->position = INVALID_VALUE;
		return false;
	}
	else
	{
		ringId_T ringId = (pathRouterMemory->mapPathMemory.builtUpRing.start + (ringId_T)index) % (ringId_T)mapPATHBUILTUPAREACOUNT;
		builtUpArea->type = pathRouterMemory->mapPathMemory.builtUpRing.builtUpArea[ringId].type;
		diagFF(prtConvertPosition(	&pathRouterMemory->mapPathMemory,
													pathRouterMemory->mapPathMemory.builtUpRing.builtUpArea[ringId].segmentRingId,
									pathRouterMemory->mapPathMemory.builtUpRing.builtUpArea[ringId].offset,
									&builtUpArea->position));
		return true;
	}
}

bool_T		prtGetDynamicEvent(			IN const	pathRouterMemory_T			*pathRouterMemory,	
										IN const	uint16_T					 index,				
										OUT			prtDynamicEvent_T			*dynamicEvent)
{
	diagFF(pathRouterMemory->mapPathMemory.dynamicEventRing.count <= (ringId_T)mapPATHDYNAMICEVENTCOUNT);
	if (index >= pathRouterMemory->mapPathMemory.dynamicEventRing.count)	{
		dynamicEvent->type = prtDynamicEventNone;
		dynamicEvent->position = INVALID_VALUE;
		return false;
	}
	else
	{
		ringId_T ringId = (pathRouterMemory->mapPathMemory.dynamicEventRing.start + (ringId_T)index) % (ringId_T)mapPATHDYNAMICEVENTCOUNT;
		dynamicEvent->type = pathRouterMemory->mapPathMemory.dynamicEventRing.dynamicEvent[ringId].type;
		diagFF(prtConvertPosition(	&pathRouterMemory->mapPathMemory,
													pathRouterMemory->mapPathMemory.dynamicEventRing.dynamicEvent[ringId].segmentRingId,
									pathRouterMemory->mapPathMemory.dynamicEventRing.dynamicEvent[ringId].offset,
									&dynamicEvent->position));
		return true;
	}
}


bool_T		prtGetOnlineSpeed(			IN const	pathRouterMemory_T			*pathRouterMemory,	
										IN const	uint16_T					 index,				
										OUT			prtSpeedLimit_T				*onlineSpeed)
{
	onlineSpeed->constraintFog		= false;
	onlineSpeed->constraintTrailer	= false;
	onlineSpeed->constraintWet		= false;
	onlineSpeed->variableSign		= false;
	onlineSpeed->constraintLane		= false;
	onlineSpeed->constraintTime		= false;
	
	diagFF(pathRouterMemory->mapPathMemory.onlineSpeedRing.count <= (ringId_T)mapPATHONLINESPEEDCOUNT);
	if (index >= pathRouterMemory->mapPathMemory.onlineSpeedRing.count)	{
		onlineSpeed->limit				= INVALID_VALUE;
		onlineSpeed->position			= INVALID_VALUE;
		onlineSpeed->raw				= rawLimitInvalid;
		return false;
	}
	else
	{
		ringId_T ringId = (pathRouterMemory->mapPathMemory.onlineSpeedRing.start + (ringId_T)index) % (ringId_T)mapPATHONLINESPEEDCOUNT;
		onlineSpeed->raw = pathRouterMemory->mapPathMemory.onlineSpeedRing.speedLimit[ringId].value;

		if(pathRouterMemory->mapPathMemory.onlineSpeedRing.speedLimit[ringId].unit == (psdSpeedLimitUnit_T)prtSpeedLimitUnitKMH) 
		{
			onlineSpeed->limit = (real32_T)onlineSpeed->raw * KPH_TO_MPS;
		} else {
			onlineSpeed->limit = (real32_T)onlineSpeed->raw * MPH_TO_MPS;
		}

		diagFF(prtConvertPosition(	&pathRouterMemory->mapPathMemory,
									 pathRouterMemory->mapPathMemory.onlineSpeedRing.speedLimit[ringId].segmentRingId,
									 pathRouterMemory->mapPathMemory.onlineSpeedRing.speedLimit[ringId].offset,
									&onlineSpeed->position));
		return true;
	}
}


static bool_T prtGetBuiltUpAtPosition(	IN const	pathRouterMemory_T			*pathRouterMemory,	
										IN const	real32_T					 position,				
										OUT			bool_T						*isBuiltUp)
{
	uint16_T index;
	prtBuiltUpArea_T currentBuiltUpArea;
	
	bool_T valid = false;
	*isBuiltUp = false;
		
	for (index = 0; index < (ringId_T)mapPATHBUILTUPAREACOUNT; index++)
	{
		if(		prtGetBuiltUpArea(pathRouterMemory, index, &currentBuiltUpArea)
			&&  currentBuiltUpArea.position <= position)
		{
			*isBuiltUp = currentBuiltUpArea.type;
			valid = true;
		}
	}

	if (valid) { 
		return true; 
	} else { 
		return false; 
	}
}


bool_T		prtIsLimitInBuiltUpArea(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	prtSpeedLimit_T		*speedLimit,
										OUT			bool_T				*isBuiltUpArea)
{
	bool_T valid, builtUp, lowLimit;

	/*Bebauungsinformation*/
	valid = prtGetBuiltUpAtPosition(pathRouterMemory, speedLimit->position, &builtUp);

	/*Limit*/
	if (	speedLimit->limit > 0.0f
		&&	speedLimit->limit <= parameterSet->driverObserver.environment.builtUpSpeedLimit + ROUNDING_ERROR)
	{
		lowLimit = true;
	} else {
		lowLimit = false;
	}

	/*Ausgabe*/
	*isBuiltUpArea = valid && builtUp && lowLimit;

	return valid ? true: false;
}



bool_T		prtIsBuiltUpAreaInLowLimit(	IN const	parameterSetCtrl_T	*parameterSet,
										IN const	pathRouterMemory_T	*pathRouterMemory,
										IN const	prtBuiltUpArea_T	*builtUpArea,
										OUT			bool_T				*isBuiltUpArea)
{
	bool_T valid, builtUp, lowLimit;
	prtSpeedLimit_T speedLimit;
	
	/*Bebauungsinformation*/
	builtUp = builtUpArea->type;

	/*Limit*/
	valid = prtGetCurrentSpeedLimit(pathRouterMemory, builtUpArea->position, &speedLimit);

	diagFF(speedLimit.limit > 0.0f);
	if(speedLimit.limit <= parameterSet->driverObserver.environment.builtUpSpeedLimit + ROUNDING_ERROR)
	{
		lowLimit = true;
	} else {
		lowLimit = false;
	}

	/*Ausgabe*/
	*isBuiltUpArea = valid && builtUp && lowLimit;

	return valid ? true: false;
}



bool_T		prtGetNextDynamicEvent(		IN const	pathRouterMemory_T			*pathRouterMemory,
										IN const	real32_T					 position,				
										OUT			real32_T					*eventPosition)
{
	uint16_T index;
	prtDynamicEvent_T currentEvent;
	
	*eventPosition = INVALID_VALUE;

	for(index = 0; index < (ringId_T)mapPATHDYNAMICEVENTCOUNT; index++)
	{
		if(		prtGetDynamicEvent(pathRouterMemory, index, &currentEvent)
			&&	currentEvent.position >= position
			&&	*eventPosition == INVALID_VALUE)
		{
			*eventPosition = currentEvent.position;
		}
	}

	return true;
}


bool_T		prtGetCurrentOnlineSpeed(		IN const	pathRouterMemory_T		*pathRouterMemory,
											IN const	real32_T				 position,	
											OUT			prtSpeedLimit_T			*onlineSpeed)
{
	prtSpeedLimit_T currentOnlineSpeed, nextOnlineSpeed;
	real32_T posFirstOnlineSpeed, distance;
	uint16_T index;

	onlineSpeed->limit = INVALID_VALUE;
	onlineSpeed->position = INVALID_VALUE;

	(void)prtGetOnlineSpeed(pathRouterMemory, (uint16_T)0u, &currentOnlineSpeed);
	posFirstOnlineSpeed = currentOnlineSpeed.position;
	distance = scalePosition(pathRouterMemory->mapPathMemory.positionZero , pathRouterMemory->mapPathMemory.distance);

	for (index = 1u; index < (ringId_T)mapPATHONLINESPEEDCOUNT; index++)
	{
		(void)prtGetOnlineSpeed(pathRouterMemory, index, &nextOnlineSpeed);
		if (currentOnlineSpeed.position <= position  &&  position < nextOnlineSpeed.position)
		{
			/*Position zwischen zwei OnlineSpeed-Attributen. Aktuell G�ltig ist das erste*/
			*onlineSpeed = currentOnlineSpeed;
		}
		currentOnlineSpeed = nextOnlineSpeed;
	}
	if (position > currentOnlineSpeed.position)
	{
		/*Letzter OnlineSpeed ist aktuell*/
		*onlineSpeed = currentOnlineSpeed;
	}

	if (prtGetOnlineSpeedCount(pathRouterMemory) == 0u)
	{	
		onlineSpeed->limit = INVALID_VALUE;
		onlineSpeed->position = INVALID_VALUE;

		return false;
	}
	else if (position > distance || position < posFirstOnlineSpeed)
	{
		onlineSpeed->limit = INVALID_VALUE;
		onlineSpeed->position = INVALID_VALUE;
		
		return false; /* statusOUTOFRANGE */
	}
	else
	{
		diagFF(onlineSpeed->limit != INVALID_VALUE);
		return true;
	}
}


bool_T			  prtGetCurvatureAtPosition(IN	const	pathRouterMemory_T		*pathRouterMemory,
											IN	const	real32_T				 position,
											OUT			real32_T				*curvature)
{
	return prtInterpolateCurvature(&pathRouterMemory->lastMapPath,
								    position,
								    curvature);
}


bool_T				prtInterpolateCurvature(IN	const	mapPath_T				*mapPath,
											IN	const	real32_T				 position,
											OUT			real32_T				*curvature)
{
	int16_T lo, mid, hi;
	infoCurvature_T curvLo, curvHi;
	real32_T curvOut, pos;
	const infoCurvatureRing_T * curvList = &mapPath->info.curvatureRing;

	pos = position - mapPath->positionZero;

	/*Bin�re Suche nach der Fahrezugposition in der Kr�mmungs-Liste.
	Wenn die Arrayl�nge mapINFOSLOPECOUNT eine Zweierpotenz ist, wird die while Schliefe genau log_2(mapINFOSLOPECOUNT) mal durchlaufen*/
	lo = 0;
	hi = mapINFOCURVATURECOUNT;
	while (hi - lo > 1)
	{
		mid = (lo + hi) / 2;
		if (	(real32_T)curvList->curvature[mid].position <= pos
			&&	mid < (int16_T)curvList->count)
		{
			lo = mid;
		} else {
			hi = mid;
		}
	}

	/*Kr�mmung vor Fahrzeug-Position*/
	curvLo = curvList->curvature[lo];

	/*Kr�mmung nach Fahrzeug-Position*/
	curvHi = curvList->curvature[hi % mapINFOCURVATURECOUNT];
	curvHi.curvature = curvHi.endOfConstantSegmentMissing ? curvLo.curvature : curvHi.curvature;
	
	/*Interpolieren*/
	curvOut  = (pos - (real32_T)curvLo.position);
	curvOut /= (real32_T)curvHi.position - (real32_T)curvLo.position;
	curvOut *= (real32_T)curvHi.curvature - (real32_T)curvLo.curvature;
	/*Pr�fe auf NaN*/
	if (curvHi.position == curvLo.position) 
	{
		curvOut = (real32_T)curvLo.curvature;
	} else {
		curvOut += (real32_T)curvLo.curvature;
	}
	curvOut  = (real32_T)PSD_EHR_CURVATURE_OFFSET + (real32_T)PSD_EHR_CURVATURE_FACTOR * curvOut;
	
	diagFF(curvList->count <= (ringId_T)mapINFOCURVATURECOUNT);
	if (curvList->count == 0u || pos > (real32_T)curvList->curvature[curvList->count - 1u].position || pos < 0.0f)
	{
		*curvature = INVALID_VALUE;
		return false;
	} else {
		*curvature =  curvOut;
		diagFNaN(*curvature);
		return true;
	}
}


bool_T		prtGetSlopeAtPosition(			IN	const	pathRouterMemory_T		*pathRouterMemory,
											IN	const	real32_T				 position,
											OUT			real32_T				*slope)
{
	int16_T lo, mid, hi;
	infoSlope_T slopeLo, slopeHi;
	real32_T slopeOut, pos;
	const mapPath_T *mapPath = &pathRouterMemory->lastMapPath;
	const infoSlopeRing_T *slopeList = &mapPath->info.slopeRing;

	pos = position - mapPath->positionZero;

	/*Bin�re Suche nach der Fahrezugposition in der Steigungs-Liste.
	Wenn die Arrayl�nge mapINFOSLOPECOUNT eine Zweierpotenz ist, wird die while Schliefe genau log_2(mapINFOSLOPECOUNT) mal durchlaufen*/
	lo = 0;
	hi = mapINFOSLOPECOUNT;
	while (hi - lo > 1)
	{
		mid = (lo + hi) / 2;
		if (	(real32_T)slopeList->slope[mid].position <= pos
			&&	mid < (int16_T)slopeList->count)
		{
			lo = mid;
		} else {
			hi = mid;
		}
	}

	/*Steigung vor Fahrzeug-Position*/
	slopeLo = slopeList->slope[lo];

	/*Steigung nach Fahrzeug-Position*/
	slopeHi = slopeList->slope[hi % mapINFOSLOPECOUNT];

	/*Interpolieren*/
	slopeOut  = (real32_T)slopeHi.slope - (real32_T)slopeLo.slope;
	slopeOut *= (pos - (real32_T)slopeLo.position);
	slopeOut /= (real32_T)slopeHi.position - (real32_T)slopeLo.position;
	/*Pr�fe auf NaN*/
	if (slopeHi.position == slopeLo.position) 
	{
		slopeOut = (real32_T)slopeLo.slope;
	} else {
		slopeOut += (real32_T)slopeLo.slope;
	}
	slopeOut  = ((real32_T)PSD_EHR_SLOPE_OFFSET + (real32_T)PSD_EHR_SLOPE_FACTOR * slopeOut) / 100.0f;

	diagFF(slopeList->count <= (ringId_T)mapINFOSLOPECOUNT);
	if (	slopeLo.slope == (psdSlope_T)PSD_EHR_SLOPE_VALUE_UNKNOWN  || slopeHi.slope == (psdSlope_T)PSD_EHR_SLOPE_VALUE_UNKNOWN
		||	slopeList->count == 0u || pos > (real32_T)slopeList->slope[slopeList->count - 1u].position || pos < 0.0f)
	{
		*slope = INVALID_VALUE;
		return false; /*mapPath-Grenzen �berschritten*/
	} else {
		*slope = slopeOut;
		diagFNaN(*slope);
		return true;
	}
}


bool_T		prtGetStreetClassAtPosition(IN const	pathRouterMemory_T			*pathRouterMemory,
										IN const	real32_T					 position,
										OUT			prtStreetClassValues_T		*streetClass)
{
	uint16_T index;
	prtStreetClass_T currentStreetClass;
	const mapPath_T *mapPath = &pathRouterMemory->lastMapPath;

	*streetClass = prtStreetClassInit;
	for (index = 0u; index < (ringId_T)mapPATHSTREETCLASSCOUNT; index++)
	{
		(void)prtGetStreetClass(mapPath, index, &currentStreetClass);
		if (currentStreetClass.position <= position)
		{
			*streetClass = currentStreetClass.type;
		} else {
			currentStreetClass.type = *streetClass;
		}
	}

	return *streetClass == prtStreetClassInit ? false : true;
}


bool_T		prtGetCurrentSpeedLimit(	IN const	pathRouterMemory_T		*pathRouterMemory,
										IN const	real32_T				 position,
										OUT			prtSpeedLimit_T			*speedLimit)
{
	prtSpeedLimit_T currentSpeedLimit, nextSpeedLimit;
	real32_T posFirstSpeedLimit;
	uint16_T index;
	const mapPath_T *mapPath = &pathRouterMemory->lastMapPath;

	speedLimit->limit = INVALID_VALUE;
	speedLimit->position = INVALID_VALUE;
	speedLimit->raw = rawLimitInvalid;

	diagFF(prtGetSpeedLimit(mapPath, (uint16_T)0u, &currentSpeedLimit));
	posFirstSpeedLimit = currentSpeedLimit.position;

	for (index = 1u; index < (ringId_T)mapINFOSPEEDLIMITCOUNT; index++)
	{
		(void)prtGetSpeedLimit(mapPath, index, &nextSpeedLimit);
		if (currentSpeedLimit.position <= position  &&  position < nextSpeedLimit.position)
		{
			/*Position zwischen zwei Tempolimitschildern. Aktuell G�ltig ist das erste*/
			*speedLimit = currentSpeedLimit;
		}
		currentSpeedLimit = nextSpeedLimit;
	}
	if (position > currentSpeedLimit.position)
	{
		/*Letztes Tempolimit ist aktuell*/
		*speedLimit = currentSpeedLimit;
	}

	if (position > prtGetDistance(mapPath) || position < posFirstSpeedLimit)
	{
		speedLimit->limit = INVALID_VALUE;
		speedLimit->position = INVALID_VALUE;
		speedLimit->raw = rawLimitInvalid;

		return false; /* statusOUTOFRANGE */
	}
	else
	{
		diagFF(speedLimit->limit != INVALID_VALUE);
		return true;
	}

}


bool_T		prtGetNextSpeedLimit(		IN const	pathRouterMemory_T		*pathRouterMemory,
										IN const	real32_T				 position,
										OUT			prtSpeedLimit_T			*speedLimit)
{
	prtSpeedLimit_T currentSpeedLimit, nextSpeedLimit;
	uint16_T index;
	const mapPath_T *mapPath = &pathRouterMemory->lastMapPath;

	speedLimit->limit = INVALID_VALUE;
	speedLimit->position = INVALID_VALUE;

	diagFF(prtGetSpeedLimit(mapPath, (uint16_T)0u, &currentSpeedLimit));

	if (position < currentSpeedLimit.position)
	{
		/*Erstes Tempolimit ist das n�chstfolgende*/
		*speedLimit = currentSpeedLimit;
	}
	for (index = 1u; index < (ringId_T)mapPATHSPEEDLIMITCOUNT; index++)
	{
		(void)prtGetSpeedLimit(mapPath, index, &nextSpeedLimit);
		if (currentSpeedLimit.position <= position  &&  position < nextSpeedLimit.position)
		{
			/*Position zwischen zwei Tempolimitschildern. Das n�chste Tempolimit speichern*/
			*speedLimit = nextSpeedLimit;
		}
		currentSpeedLimit = nextSpeedLimit;
	}
	
	if (position > prtGetDistance(mapPath) || position < mapPath->positionZero)
	{
		speedLimit->limit = INVALID_VALUE;
		speedLimit->position = INVALID_VALUE;
		speedLimit->raw = rawLimitInvalid;

		return false; /* statusOUTOFRANGE */
	} 
	else if (speedLimit->limit == INVALID_VALUE)
	{
		return false;
	} 
	else 
	{
		return true;
	}

}
