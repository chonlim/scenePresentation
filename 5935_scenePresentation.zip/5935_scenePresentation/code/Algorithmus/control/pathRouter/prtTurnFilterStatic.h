#ifndef guard_prtTurnFilterStatic_h
#define guard_prtTurnFilterStatic_h


/**\brief Gibt `true` zur�ck, wenn alle Werte der `psdPosition` in den vom PsdEhr definierten Grenzen liegen.
\ingroup pathRouter_routing
*/
static bool_T	prtCheckPsdPosition(	IN	const	psdPosition_T		*psdPosition
										);

/**\brief Initialisiert den turnFilter.
Fragt den Status und die Fahrzeugposition vom PSD-Baum ab und initialisiert damit die turnFilter.virtualPosition.
Initialisiert die Entprellz�hler auf Null.
\ingroup pathRouter_routing
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_134
*/
static bool_T	prtInitTurnFilter(		OUT			mapTurnFilter_T		*turnFilter,
										IN const	parameterSetCtrl_T	*parameterSet
										);


#endif
