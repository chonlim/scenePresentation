#include "prtAttributes.h"
#include "prtAttributesStatic.h"

#include "common/platformInterface/pltfDiag.h"
#include "control/pathRouter/prtPrepare.h"

diagDeclareModule(diagModule_prtAttributes)


bool_T				   prtOffsetToUint8(IN const	psdLength_T					 offset,
										OUT			uint8_T						*position)
{
	diagFF(offset <= (psdLength_T)PSD_EHR_LENGTH_VALUE_MAX);
	*position = (uint8_T)(offset / (uint8_T)METER_TO_PSDDISTANCE);
	return true;
}


bool_T				prtGetPathFromRoute(IN	const	mapRoute_T					*mapRoute,
										IN	const	parameterSetCtrl_T			*parameterSet,
										IN	const	uint8_T						 firstNewRouteSegment,
										IN	const	uint8_T						 nSegmentCalls,
										INOUT		mapPathMemory_T				*mapPathMemory,
										INOUT		uint8_T						*nSpeedLimitCalls,
										INOUT		uint8_T						*nAttributeCalls)
{
	uint8_T routeSegment;

	/*Alle Segmente auf der mapRoute durchlaufen (bis zur H�chstzahl aus Laufzeitgr�nden)*/
	for (routeSegment = firstNewRouteSegment;
			routeSegment < mapRoute->segmentCount
		 && *nAttributeCalls  < parameterSet->pathRouter.maxAttributesPerCycle
		 && *nSpeedLimitCalls < parameterSet->pathRouter.maxSpeedLimitsPerCycle
		 && nSegmentCalls + *nSpeedLimitCalls + *nAttributeCalls < parameterSet->pathRouter.maxApiCallsPerCycle;
		 routeSegment++)
	{
		/*Segment im Ringspeicher anlegen. wegen h�chstgr��e mapMAXROUTELENGTH kann es keinen �berlauf geben*/
		const psdSegment_T  *currentSegment = &mapRoute->segment[(mapRoute->segmentStart + routeSegment) % (uint8_T)mapMAXROUTELENGTH];
		const ringId_T segmentRingId = (mapPathMemory->segmentRing.start + mapPathMemory->segmentRing.count) % (ringId_T)mapMAXROUTELENGTH;

		/*Attribute des Segments kopieren.
		Das Segment im segmentRing speichert den count bzw. den letzten Index + 1 jedes Attributs,
		um den Speicher freigeben zu k�nnen, wenn das Segment �berfahren worden ist.*/
		if (!prtCopySegmentAttributes(	parameterSet,
										mapRoute,
										segmentRingId,
										routeSegment,
										mapPathMemory))
		{
			diagReportInfo(diagInfo_prtCopySegment);
			return true;
		}

		/* LinkedLists f�r Tempolimits und generische Attribute durchlaufen.
			Dabei kann es sein, dass Segmente unvollst�ndig bleiben (Flag: unfinishedSegment).
		*/
		mapPathMemory->unfinishedSegment = (ringId_T)INVALID_UINT8;

		diagFF(prtCopyAttributes(	&mapPathMemory->treeConfig,
									currentSegment->attributeIndex,
									segmentRingId, 
									min(parameterSet->pathRouter.maxAttributesPerCycle, (uint8_T)((parameterSet->pathRouter.maxApiCallsPerCycle - *nSpeedLimitCalls) - nSegmentCalls)),
									&mapPathMemory->segmentRing,
									&mapPathMemory->onlineSpeedRing,
									&mapPathMemory->laneSituationRing,
									&mapPathMemory->slopeRing,
									&mapPathMemory->rightOfWayRing,
									&mapPathMemory->streetSituationRing,
									&mapPathMemory->trafficDirectionRing,
									&mapPathMemory->countryCodeRing,
									&mapPathMemory->speedLimitUnitRing,
									&mapPathMemory->qualityGeometryRing,
									&mapPathMemory->unfinishedSegment,
									nAttributeCalls,
									&mapPathMemory->nextAttribute));


		diagFF(prtCopySpeedLimits(  parameterSet,
									mapPathMemory,
									currentSegment->speedLimitIndex,
									segmentRingId,
									min(parameterSet->pathRouter.maxSpeedLimitsPerCycle, (uint8_T)((parameterSet->pathRouter.maxApiCallsPerCycle - *nAttributeCalls) - nSegmentCalls)),
									&mapPathMemory->speedLimitRing,
									nSpeedLimitCalls,
									&mapPathMemory->segmentRing.segment[segmentRingId].speedLimitEnd,
									&mapPathMemory->unfinishedSegment,
									&mapPathMemory->nextSpeedLimit));

		if (mapPathMemory->unfinishedSegment == (ringId_T)INVALID_UINT8)
		{
			uint8_T length;

			/* Das Segment ist vollst�ndig. Die mapPathMemory->distance reicht bis zur letzten curvature.*/
			diagFF(prtOffsetToUint8(currentSegment->geometry.length, &length));
			mapPathMemory->distance += (uint16_T)length;
			mapPathMemory->segmentRing.count = (mapPathMemory->segmentRing.count + 1u);
		}
	}

	return true;
}


static void		prtOutputBufferWarning(	INOUT		bool_T						*debugMsgLock)
{
	if (!(*debugMsgLock)) 
	{
		diagReportInfo(diagInfo_prtOutputBuffer);
	}
	*debugMsgLock = true;
}


bool_T				 prtCopySpeedLimits(IN	const	parameterSetCtrl_T			*parameterSet,
										IN	const	mapPathMemory_T				*mapPathMemory,
										IN	const	psdSpeedLimitId_T			 firstSpeedLimitId,
										IN	const	ringId_T					 segmentRingId,
										IN	const	uint8_T						 maxSpeedLimitCalls,
										INOUT		mapSpeedLimitRing_T			*speedLimitRing,
										INOUT		uint8_T						*nSpeedLimitCalls,
										OUT			ringId_T					*endRingId,
										INOUT		ringId_T					*unfinishedSegment,
										OUT			psdSpeedLimitId_T			*nextSpeedLimit)
{
	psdSpeedLimitId_T speedLimitId = firstSpeedLimitId;
	psdSpeedLimitUnit_T speedLimitUnit;

	if (*unfinishedSegment != (ringId_T)INVALID_UINT8) 
	{
		/*Wenn noch nicht alle Attribute des Segments eingelesen sind, ist es m�glich, dass eines davon die SpeedLimitUnit �ndert.
		Darum warten, bis alle Attribute eingelesen sind.*/
		*nextSpeedLimit = firstSpeedLimitId;
		return true;
	}

	diagFF(prtGetCurrentSpeedLimitUnit( mapPathMemory, 
									    mapPathMemory->positionZero + (real32_T)mapPathMemory->distance, 
									   &speedLimitUnit));

	*endRingId = (speedLimitRing->start + speedLimitRing->count) % (ringId_T)mapPATHSPEEDLIMITCOUNT;
	while (		speedLimitId < (psdSpeedLimitId_T)mapPathMemory->treeConfig.maxSpeedLimits
		   &&	*nSpeedLimitCalls < maxSpeedLimitCalls)
	{
		psdSpeedLimit_T currentSpeedLimit;
		
		diagFF(psdwGetSpeedLimitData(speedLimitId, speedLimitUnit, speedLimitUnit, &currentSpeedLimit));
		*nSpeedLimitCalls += 1u;

		/* Folgende Speed Limit-Eintr�ge werden aussortiert:
			- ung�ltige Speed Limits (LEGAL, INIT, INVALID, NO_INFO)
			- Limits, die nur f�r LKW gelten 
			- "VZO only"-Limits (parameterabh�ngig) */
		if (   (currentSpeedLimit.type						== (psdSpeedLimitValue_T)PSD_EHR_SPEED_LIMIT_TYPE_LEGAL)
			|| (currentSpeedLimit.type						== (psdSpeedLimitValue_T)PSD_EHR_SPEED_LIMIT_TYPE_INIT)
			|| (currentSpeedLimit.speedLimitLower			== (psdSpeedLimitValue_T)PSD_EHR_SPEED_LIMIT_VALUE_VALUE_INVALID)
			|| (currentSpeedLimit.speedLimitLower			== (psdSpeedLimitValue_T)PSD_EHR_SPEED_LIMIT_VALUE_VALUE_NO_LIMIT)
			|| (currentSpeedLimit.constraintTrailer			== (psdSpeedLimitConstraintTrailer_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_TRAILER_TRUCK)
			|| (currentSpeedLimit.source					== (psdSpeedLimitSource_T)PSD_EHR_SPEED_LIMIT_SOURCE_VZO_ONLY && parameterSet->pathRouter.killVZOOnlyLimits))
		{
			/*Ignoriere das Tempolimit*/
		} 
		else if (speedLimitRing->count >= (ringId_T)mapPATHSPEEDLIMITCOUNT) {
			prtOutputBufferWarning(&speedLimitRing->debugMsgLock);
			break;
		}
		else
		{
			speedLimitRing->debugMsgLock = false;

			speedLimitRing->speedLimit[*endRingId].segmentRingId = segmentRingId;
			diagFF(prtOffsetToUint8(currentSpeedLimit.offset, &speedLimitRing->speedLimit[*endRingId].offset));

			speedLimitRing->speedLimit[*endRingId].constraintFog		= (currentSpeedLimit.constraintWeather			== (psdSpeedLimitConstraintWeather_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_WEATHER_FOGGY);

			speedLimitRing->speedLimit[*endRingId].constraintWet		= (   (currentSpeedLimit.constraintWeather		== (psdSpeedLimitConstraintWeather_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_WEATHER_WET_CONDITIONS)
																		   || (currentSpeedLimit.constraintWeather		== (psdSpeedLimitConstraintWeather_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_WEATHER_SLICKNESS));

			speedLimitRing->speedLimit[*endRingId].constraintTrailer	= (currentSpeedLimit.constraintTrailer			== (psdSpeedLimitConstraintTrailer_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_TRAILER_TRAILER);

			speedLimitRing->speedLimit[*endRingId].constraintTime		= (    (currentSpeedLimit.constraintHourStart	!= (psdSpeedLimitConstraintHour_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_HOUR_NOT_DEFINED)
																		   || (currentSpeedLimit.constraintHourEnd		!= (psdSpeedLimitConstraintHour_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_HOUR_NOT_DEFINED)
																		   || (currentSpeedLimit.constraintWeekDayStart	!= (psdSpeedLimitConstraintWeekDay_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_WEEKDAY_NOT_DEFINED));

			speedLimitRing->speedLimit[*endRingId].constraintLane		= (currentSpeedLimit.constraintLane				!= (psdSpeedLimitConstraintLane_T)PSD_EHR_SPEED_LIMIT_CONSTRAINT_LANE_ALL);
						
			speedLimitRing->speedLimit[*endRingId].variableSign			= (currentSpeedLimit.variableMessageSign		!= (psdVariableMessageSign_T)PSD_EHR_VARIABLE_MESSAGE_SIGN_NONE);
			 
			if (currentSpeedLimit.speedLimitLower == (psdSpeedLimitValue_T)PSD_EHR_SPEED_LIMIT_VALUE_VALUE_RELEASED) {
				speedLimitRing->speedLimit[*endRingId].value	= (psdSpeedLimitValue_T)rawLimitReleased;
				speedLimitRing->speedLimit[*endRingId].unit		= (psdSpeedLimitUnit_T)prtSpeedLimitUnitKMH;
			} else {
				speedLimitRing->speedLimit[*endRingId].value	= currentSpeedLimit.speedLimitLower;
				speedLimitRing->speedLimit[*endRingId].unit		= (psdSpeedLimitUnit_T)speedLimitUnit;
			}

			*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHSPEEDLIMITCOUNT;
			speedLimitRing->count++;
		}
		speedLimitId = currentSpeedLimit.nextSpeedLimit;
	}

	if (speedLimitId < (psdSpeedLimitId_T)mapPathMemory->treeConfig.maxSpeedLimits)
	{
		/*Tempolimits wurden nicht komplett gelesen, Segment ist unvollst�ndig*/
		*nextSpeedLimit = speedLimitId;
		*unfinishedSegment = segmentRingId;
	}
	else
	{
		*nextSpeedLimit = (psdSpeedLimitId_T)mapPathMemory->treeConfig.maxSpeedLimits;
	}

	return true;
}


bool_T				   prtCopySegmentAttributes(IN	const	parameterSetCtrl_T		*parameterSet,
												IN	const	mapRoute_T				*mapRoute,
												IN	const	ringId_T				 segmentRingId,
												IN	const	uint8_T					 routeSegment,
												INOUT		mapPathMemory_T			*mapPathMemory)
{
	bool_T flagLaneAccretion;
	const psdSegment_T  *currentSegment = &mapRoute->segment[(mapRoute->segmentStart + routeSegment) % (ringId_T)mapMAXROUTELENGTH];


	/*Keine Aktion wenn nicht f�r jedes Attribut speicherplatz verf�gbar ist.*/
	if (	mapPathMemory->rightOfWayRing.count + 1u	>= (ringId_T)mapPATHRIGHTOFWAYCOUNT
		||	mapPathMemory->branchAngleRing.count + 1u	>= (ringId_T)mapPATHBRANCHANGLECOUNT
		||	mapPathMemory->builtUpRing.count + 1u		>= (ringId_T)mapPATHBUILTUPAREACOUNT
		||	mapPathMemory->curvatureRing.count + 2u		>= (ringId_T)mapPATHCURVATURECOUNT
		||	mapPathMemory->laneSituationRing.count + 1u	>= (ringId_T)mapPATHLANESITUATIONCOUNT
		||	mapPathMemory->dynamicEventRing.count + 1u	>= (ringId_T)mapPATHDYNAMICEVENTCOUNT
		||	mapPathMemory->streetClassRing.count + 1u	>= (ringId_T)mapPATHSTREETCLASSCOUNT
		||	mapPathMemory->rampRing.count + 1u			>= (ringId_T)mapPATHRAMPCOUNT)
	{
		return false;
	}

	/*Segment anlegen.*/
	mapPathMemory->segmentRing.segment[segmentRingId].segmentId = currentSegment->id;
	mapPathMemory->segmentRing.segment[segmentRingId].startDistance = mapPathMemory->distance;
	mapPathMemory->segmentRing.segment[segmentRingId].rampValue = (psdRampValue_T)currentSegment->attributes.ramp;
	diagFF(prtOffsetToUint8(currentSegment->geometry.length, &mapPathMemory->segmentRing.segment[segmentRingId].length));

	/*Nicht f�r jedes Segment wird sp�ter eine gps-Positioneingetragen.*/
	mapPathMemory->segmentRing.segment[segmentRingId].gpsRingEnd = (ringId_T)INVALID_UINT8;

	/*Attribute Kopieren*/
	if (	routeSegment > 0u
		&&	(uint8_T)mapRoute->branch[(mapRoute->segmentStart + routeSegment - 1u) % (ringId_T)mapMAXROUTELENGTH] != (uint8_T)turnSignalNone)
	{
		diagFF(prtCopyIntersection(	parameterSet->pathRouter.angleTolerance,
									mapRoute->smallestAngles[(mapRoute->segmentStart + routeSegment) % (ringId_T)mapMAXROUTELENGTH],
									segmentRingId, 
									&mapPathMemory->rightOfWayRing, 
									&mapPathMemory->segmentRing.segment[segmentRingId].rightOfWayEnd));
	}

	diagFF(prtCopyBranchAngle(	currentSegment,
								segmentRingId,
								&mapPathMemory->branchAngleRing,
								&mapPathMemory->segmentRing.segment[segmentRingId].branchAngleEnd));

	diagFF(prtCopyBuiltUp(	currentSegment,
							segmentRingId,
							&mapPathMemory->builtUpRing,
							&mapPathMemory->segmentRing.segment[segmentRingId].builtUpAreaEnd));

	diagFF(prtCopyCurvature(currentSegment,
							segmentRingId,
							&mapPathMemory->curvatureRing,
							&mapPathMemory->segmentRing.segment[segmentRingId].curvatureEnd));

	diagFF(prtCopyForwardLanes(	currentSegment,
								segmentRingId,
								&mapPathMemory->laneSituationRing,
								&flagLaneAccretion,
								&mapPathMemory->segmentRing.segment[segmentRingId].laneSituationEnd));

	if (mapPathMemory->segmentRing.count > 0u) {
		diagFF(prtCopyDynamicEvents(currentSegment,
									segmentRingId,
									&mapPathMemory->segmentRing,
									flagLaneAccretion,
									&mapPathMemory->dynamicEventRing,
									&mapPathMemory->segmentRing.segment[segmentRingId].dynamicEventEnd));	
	}
		
	diagFF(prtCopyStreetClass(	currentSegment,
								segmentRingId,
								&mapPathMemory->streetClassRing,
								&mapPathMemory->segmentRing.segment[segmentRingId].streetClassEnd));
		
	diagFF(prtCopyRamp(	currentSegment,
						segmentRingId,
						&mapPathMemory->rampRing,
						&mapPathMemory->segmentRing.segment[segmentRingId].rampEnd));
	
	return true;
}


bool_T				  prtCopyAttributes(IN	const	psdTreeConfiguration_T		*treeConfig,
										IN	const	psdAttributeIndex_T			 firstAttributeId,
										IN	const	ringId_T					 segmentRingId,
										IN	const	uint8_T						 maxAttributeCalls,
										INOUT		mapSegmentRing_T			*segmentRing,
										INOUT		mapSpeedLimitRing_T			*onlineSpeedRing,
										INOUT		mapLaneSituationRing_T		*laneSituationRing,
										INOUT		mapSlopeRing_T				*slopeRing,
										INOUT		mapRightOfWayRing_T			*rightOfWayRing,
										INOUT		mapStreetSituationRing_T	*streetSituationRing,
										INOUT		mapTrafficDirectionRing_T	*trafficDirectionRing,
										INOUT		mapCountryCodeRing_T		*countryCodeRing,
										INOUT		mapSpeedLimitUnitRing_T		*speedLimitUnitRing,
										INOUT		mapQualityGeometryRing_T	*qualityGeometryRing,
										INOUT		ringId_T					*unfinishedSegment,
										INOUT		uint8_T						*nAttributeCalls,
										OUT			psdAttributeIndex_T			*nextAttribute)
{
	psdAttributeIndex_T attributeId = firstAttributeId;
	diagFF(segmentRingId < (ringId_T)mapMAXROUTELENGTH);

	/*Falls kein Attribut f�r dieses Segment gelesen wird, muss trotzdem der Endindex gesetzt werden.*/
	segmentRing->segment[segmentRingId].laneSituationEnd	= (laneSituationRing->start		+ laneSituationRing->count)		% (ringId_T)mapPATHLANESITUATIONCOUNT;
	segmentRing->segment[segmentRingId].slopeEnd			= (slopeRing->start				+ slopeRing->count)				% (ringId_T)mapPATHSLOPECOUNT;
	segmentRing->segment[segmentRingId].rightOfWayEnd		= (rightOfWayRing->start		+ rightOfWayRing->count)		% (ringId_T)mapPATHRIGHTOFWAYCOUNT;
	segmentRing->segment[segmentRingId].onlineSpeedEnd		= (onlineSpeedRing->start		+ onlineSpeedRing->count)		% (ringId_T)mapPATHONLINESPEEDCOUNT;
	segmentRing->segment[segmentRingId].streetSituationEnd	= (streetSituationRing->start	+ streetSituationRing->count)	% (ringId_T)mapPATHSTREETSITUATIONCOUNT;
	segmentRing->segment[segmentRingId].countryCodeEnd		= (countryCodeRing->start		+ countryCodeRing->count)		% (ringId_T)mapPATHCOUNTRYCODECOUNT;
	segmentRing->segment[segmentRingId].speedLimitUnitEnd	= (speedLimitUnitRing->start	+ speedLimitUnitRing->count)	% (ringId_T)mapPATHSPEEDLIMITUNITCOUNT;
	segmentRing->segment[segmentRingId].qualityGeometryEnd	= (qualityGeometryRing->start	+ qualityGeometryRing->count)	% (ringId_T)mapPATHQUALITYGEOMETRYCOUNT;
	segmentRing->segment[segmentRingId].trafficDirectionEnd	= (trafficDirectionRing->start	+ trafficDirectionRing->count)	% (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT;

	while (   attributeId < (psdAttributeIndex_T)treeConfig->maxAttributes
		   && *nAttributeCalls < maxAttributeCalls)
	{
		psdAttribute_T currentAttribute;
		bool_T success;

		diagFF(psdwGetAttributeData(attributeId, &currentAttribute));
		*nAttributeCalls += 1u;

		switch (currentAttribute.type)
		{
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_LANES_OPPOSITE:
			success = prtCopyOppositeLanes(&currentAttribute, segmentRingId, laneSituationRing, &segmentRing->segment[segmentRingId].laneSituationEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_TURNING_LANE:
			success = prtCopyTurningLanes(&currentAttribute, segmentRingId, laneSituationRing, &segmentRing->segment[segmentRingId].laneSituationEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_EHR_SLOPE:
			success = prtCopySlope(&currentAttribute, segmentRingId, slopeRing, &segmentRing->segment[segmentRingId].slopeEnd);
			break;

		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_RIGHT_OF_WAY_CONTROL:
			success = prtCopyRightOfWayControl(&currentAttribute,
												segmentRingId,
												rightOfWayRing,
											   &segmentRing->segment[segmentRingId].rightOfWayEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_TRAFFIC_LIGHT:
			success = prtCopyTrafficLight(&currentAttribute,
										   segmentRingId,
										   rightOfWayRing,
										   &segmentRing->segment[segmentRingId].rightOfWayEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA:
			success = prtCopyOnlineSpeed(&currentAttribute, 
										  segmentRingId, 
										  onlineSpeedRing, 
										 &segmentRing->segment[segmentRingId].onlineSpeedEnd);
			break;

		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_STREET_SITUATION:
			success = prtCopyStreetSituation(&currentAttribute,
											  segmentRingId,
											  streetSituationRing,
										     &segmentRing->segment[segmentRingId].streetSituationEnd);
			break;


		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_UNIT_SPEED:
			success = prtCopySpeedLimitUnit(&currentAttribute,
										     segmentRingId,
										     speedLimitUnitRing,
										    &segmentRing->segment[segmentRingId].speedLimitUnitEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_COUNTRY_CODE:
			success = prtCopyCountryCode( &currentAttribute,
										   segmentRingId,
										   countryCodeRing,
										  &segmentRing->segment[segmentRingId].countryCodeEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_QUALITY_GEOMETRY:
			success = prtCopyQualityGeometry(&currentAttribute,
										     segmentRingId,
										     qualityGeometryRing,
										    &segmentRing->segment[segmentRingId].qualityGeometryEnd);
			break;
		case (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_TRAFFIC_DIRECTION:
			success = prtCopyTrafficDirection( &currentAttribute,
												segmentRingId,
												trafficDirectionRing,
											   &segmentRing->segment[segmentRingId].trafficDirectionEnd);
			break;
		default:
			/*Ungenutztes Attribut*/
			success = true;
			break;
		}

		if (success) {
			attributeId = currentAttribute.nextAttribute;
		} else {
			break; /*while*/
		}
	}

	if (attributeId < (psdAttributeIndex_T)treeConfig->maxAttributes)
	{
		/*Attribute wurden nicht komplett gelesen, Segment ist unvollst�ndig*/
		*nextAttribute = attributeId;
		*unfinishedSegment = segmentRingId;
	}
	else
	{
		/*Alle Attribute dieses Segments gelesen. unfinished Segment-Information bleibt wie sie ist.*/
		*nextAttribute = (psdAttributeIndex_T)treeConfig->maxAttributes;
	}

	return true;
}


static bool_T		 prtCopyBranchAngle(IN	const	psdSegment_T				*segment,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapBranchAngleRing_T		*branchAngleRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (branchAngleRing->start + branchAngleRing->count) % (ringId_T)mapPATHBRANCHANGLECOUNT;

	if (segment->geometry.branchAngle != (psdAngle_T)PSD_EHR_BRANCHANGLE_VALUE_ZERO)
	{
		if (branchAngleRing->count >= (ringId_T)mapPATHBRANCHANGLECOUNT) 
		{	
			prtOutputBufferWarning(&branchAngleRing->debugMsgLock);
			return false;
		}
		branchAngleRing->debugMsgLock = false;

		branchAngleRing->branchAngle[*endRingId].segmentRingId = segmentRingId;
		branchAngleRing->branchAngle[*endRingId].offset = 0u;
		branchAngleRing->branchAngle[*endRingId].angle = segment->geometry.branchAngle;

		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHBRANCHANGLECOUNT;
		branchAngleRing->count++;
	}
	return true;
}


bool_T						 prtCopyGps(IN	const	psdGpsPosition_T			*psdGpsPosition,
										IN	const	ringId_T					 segmentRingId,
										IN	const	uint8_T						 offset,
										INOUT		mapGpsRing_T				*gpsRing,
										OUT			ringId_T					*endRingId)
{
	ringId_T i, replaceId;

	*endRingId = (gpsRing->start + gpsRing->count) % (ringId_T)mapPATHGPSCOUNT;

	/*Gibt es die segmentRingId schoneinmal im gpsRing?*/
	replaceId = *endRingId;
	for (i = 0; i < (ringId_T)mapPATHGPSCOUNT; i++)
	{
		if (	gpsRing->gpsInfo[(gpsRing->start + i) % (ringId_T)mapPATHGPSCOUNT].segmentRingId == segmentRingId
			&&	i < gpsRing->count)
		{
			replaceId = (gpsRing->start + i) % (ringId_T)mapPATHGPSCOUNT;
		}
	}

	/*Kann eine weitere�gpsInfo im Ring gespeichert werden?*/
	if (	replaceId == *endRingId
		&&	gpsRing->count >= (ringId_T)mapPATHGPSCOUNT)
		{
			prtOutputBufferWarning(&gpsRing->debugMsgLock);
			return false;
		}

	gpsRing->debugMsgLock = false;
	gpsRing->count+= replaceId == *endRingId ? (ringId_T)1 : (ringId_T)0;

	/*Daten kopieren, Ringende zur�ckgeben.*/
	gpsRing->gpsInfo[replaceId].segmentRingId	= segmentRingId;
	gpsRing->gpsInfo[replaceId].offset			= offset;
	gpsRing->gpsInfo[replaceId].altitude		= psdGpsPosition->altitude;
	gpsRing->gpsInfo[replaceId].heading			= psdGpsPosition->heading;
	gpsRing->gpsInfo[replaceId].latitude		= psdGpsPosition->latitude;
	gpsRing->gpsInfo[replaceId].longitude		= psdGpsPosition->longitude;
	*endRingId = (replaceId + 1u) % (ringId_T)mapPATHGPSCOUNT;

	return true;
}


static bool_T			 prtCopyBuiltUp(IN	const	psdSegment_T				*segment,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapBuiltUpRing_T			*builtUpRing,
										OUT			ringId_T					*endRingId)
{
	bool_T lastBuiltUp;

	*endRingId = (builtUpRing->start + builtUpRing->count) % (ringId_T)mapPATHBUILTUPAREACOUNT;
	lastBuiltUp = builtUpRing->builtUpArea[*endRingId == 0u ? (ringId_T)mapPATHBUILTUPAREACOUNT - 1u : *endRingId - 1u].type;

	if ((builtUpRing->count == 0u) || 
		(segment->attributes.isBuiltUpArea && !lastBuiltUp) ||
		(!segment->attributes.isBuiltUpArea && lastBuiltUp))
	{
		if (builtUpRing->count >= (ringId_T)mapPATHBUILTUPAREACOUNT)
		{
			prtOutputBufferWarning(&builtUpRing->debugMsgLock);
			return false;
		}
		else
		{
			builtUpRing->debugMsgLock = false;
			builtUpRing->builtUpArea[*endRingId].segmentRingId = segmentRingId;
			builtUpRing->builtUpArea[*endRingId].offset = 0u;
			builtUpRing->builtUpArea[*endRingId].type = segment->attributes.isBuiltUpArea;
			*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHBUILTUPAREACOUNT;
			builtUpRing->count++;
		}
	}
	return true;
}



static bool_T	prtCopyCurvature(		IN const	psdSegment_T				*segment,			
										IN const	ringId_T					 segmentRingId,		
										INOUT		mapCurvatureRing_T			*curvatureRing,		
										OUT			ringId_T					*endRingId)			
{
	*endRingId = (curvatureRing->start + curvatureRing->count) % (ringId_T)mapPATHCURVATURECOUNT;

	if (curvatureRing->count>= (ringId_T)mapPATHCURVATURECOUNT - 1u)
	{
		prtOutputBufferWarning(&curvatureRing->debugMsgLock);
		return false;
	}

	curvatureRing->debugMsgLock = false;

	curvatureRing->curvature[*endRingId].segmentRingId = segmentRingId;
	curvatureRing->curvature[*endRingId].offset = 0u;
	curvatureRing->curvature[*endRingId].curvature = segment->geometry.curvatureStart;
	*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHCURVATURECOUNT;
	curvatureRing->curvature[*endRingId].segmentRingId = segmentRingId;
	diagFF(prtOffsetToUint8(segment->geometry.length, &curvatureRing->curvature[*endRingId].offset));
	curvatureRing->curvature[*endRingId].curvature = segment->geometry.curvatureEnd;

	*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHCURVATURECOUNT;
	curvatureRing->count += 2u;
	return true;
}


static bool_T		prtCopyForwardLanes(IN	const	psdSegment_T				*segment,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapLaneSituationRing_T		*laneSituationRing,
										OUT			bool_T						*flagLaneAccretion,
										OUT			ringId_T					*endRingId)
{
	
	bool_T segmentIsBranch;
	psdSegmentId_T childId;
	ringId_T lastElementId;

	childId = segment->childSegments[1];
	if (childId == (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INIT || childId == (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INVALID)
	{
		segmentIsBranch = false;
	} else {
		segmentIsBranch = true;
	}

	*endRingId = (laneSituationRing->start + laneSituationRing->count) % (ringId_T)mapPATHLANESITUATIONCOUNT;
	lastElementId = (laneSituationRing->start + laneSituationRing->count - 1u) % (ringId_T)mapPATHLANESITUATIONCOUNT;
	
	/*F�r die Funktion CopyDynamicEvents wird eine Flag zur Information �ber Spuraufweitungen bereitgestellt.*/
	if (	laneSituationRing->count > (ringId_T)0u
		&&  laneSituationRing->laneSituation[lastElementId].forwardLanes > (uint8_T)0
		&&  segment->attributes.lanes > laneSituationRing->laneSituation[lastElementId].forwardLanes)
	{
		*flagLaneAccretion = true;
	} else {
		*flagLaneAccretion = false;
	}

	if (	laneSituationRing->count == (ringId_T)0u
		||	segment->attributes.lanes != laneSituationRing->laneSituation[lastElementId].forwardLanes
		||	segmentIsBranch)
	{

		if (laneSituationRing->count >= (ringId_T)mapPATHLANESITUATIONCOUNT) {
			prtOutputBufferWarning(&laneSituationRing->debugMsgLock);
			return false;
		}

		laneSituationRing->debugMsgLock = false;

		/*Unterscheide folgende Situationen zum Umgang mit anderen Spuren (Abbiege und Gegenverkehr):
		Erste laneSitation: andere Spuren nullen.
		Gleiche Position wie letzte laneSituation: Vorw�rtsspuren letzter laneSituation �berschreiben
		Sonst: andere Spuren von letzter laneSitation �bernehmen
		*/
		if (laneSituationRing->count ==(ringId_T)0u)
		{
			laneSituationRing->laneSituation[*endRingId].turnLanesLeft = 0u;
			laneSituationRing->laneSituation[*endRingId].turnLanesRight = 0u;
			laneSituationRing->laneSituation[*endRingId].oppositeLanes = 0u;
		}
		else if (laneSituationRing->laneSituation[lastElementId].segmentRingId == segmentRingId && laneSituationRing->laneSituation[lastElementId].offset == (uint8_T)0u)
		{
			*endRingId = lastElementId;
			laneSituationRing->count--;
		}
		else
		{
			laneSituationRing->laneSituation[*endRingId] = laneSituationRing->laneSituation[lastElementId];
		}

		/* Die Anzahl der Abbiegespuren wird bei jedem Branch zur�ckgesetzt. Updates der Abbiegespuren finden bei den generischen Attributen statt.*/
		if (segmentIsBranch)
		{
			laneSituationRing->laneSituation[*endRingId].turnLanesLeft = 0u;
			laneSituationRing->laneSituation[*endRingId].turnLanesRight = 0u;
		}

		laneSituationRing->laneSituation[*endRingId].segmentRingId = segmentRingId;
		laneSituationRing->laneSituation[*endRingId].offset = 0u;
		laneSituationRing->laneSituation[*endRingId].forwardLanes = segment->attributes.lanes;
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHLANESITUATIONCOUNT;
		laneSituationRing->count++;
	}
	return true;
}


static bool_T	   prtCopyDynamicEvents(IN	const	psdSegment_T				*segment,
										IN	const	ringId_T					 segmentRingId,
										IN	const	mapSegmentRing_T			*segmentRing,
										IN	const	bool_T						 flagLaneAccretion,
										INOUT		mapDynamicEventRing_T		*dynamicEventRing,
										OUT			ringId_T					*endRingId)
{
	psdRampValue_T previousRampValue = (psdRampValue_T)PSD_EHR_RAMP_TWO_WAY_TRAFFIC;
	if (segmentRing->count > 0u) {
		previousRampValue = segmentRing->segment[(segmentRing->start + segmentRing->count - 1u) % (ringId_T)mapMAXROUTELENGTH].rampValue;
	}
	*endRingId = (dynamicEventRing->start + dynamicEventRing->count) % (ringId_T)mapPATHDYNAMICEVENTCOUNT;

	if (dynamicEventRing->count >= (ringId_T)mapPATHDYNAMICEVENTCOUNT) {
		prtOutputBufferWarning(&dynamicEventRing->debugMsgLock);
		return false;
	}
	dynamicEventRing->debugMsgLock = false;

	/*Autobahnauffahrt hat Priorit�t �ber Spuraufweitung (ist dort implizit enthalten)*/
	if (	segment->attributes.streetClass	== (psdStreetClass_T)PSD_EHR_STREET_CLASS_HIGHWAY
		&&  segment->attributes.ramp		== (psdRampValue_T)PSD_EHR_RAMP_ONE_WAY
		&&	previousRampValue == (psdRampValue_T)PSD_EHR_RAMP_UP_ONE_WAY)
	{
		dynamicEventRing->dynamicEvent[*endRingId].segmentRingId = segmentRingId;
		dynamicEventRing->dynamicEvent[*endRingId].offset = 0u;
		dynamicEventRing->dynamicEvent[*endRingId].type = prtDynamicEventHighwayRampUp;
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHDYNAMICEVENTCOUNT;
		dynamicEventRing->count += 1u;
	}
	/*Sonst �berpr�fe Spuraufweitung:*/
	else if (flagLaneAccretion)
	{
		dynamicEventRing->dynamicEvent[*endRingId].segmentRingId = segmentRingId;
		dynamicEventRing->dynamicEvent[*endRingId].offset = 0u;
		dynamicEventRing->dynamicEvent[*endRingId].type = prtDynamicEventLaneAccretion;
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHDYNAMICEVENTCOUNT;
		dynamicEventRing->count += 1u;
	}
	else
	{
		/*kein Dynamikevent*/
	}

	return true;
}


static bool_T		 prtCopyStreetClass(IN	const	psdSegment_T				*segment,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapStreetClassRing_T		*streetClassRing,
										OUT			ringId_T					*endRingId)			
{
	prtStreetClassValues_T streetClass = (prtStreetClassValues_T)segment->attributes.streetClass; /*lint !e9030 !e9034*/
	*endRingId = (streetClassRing->start + streetClassRing->count) % (ringId_T)mapPATHSTREETCLASSCOUNT;

	if (	(streetClassRing->count == 0u)
		||	(streetClass != streetClassRing->streetClass[*endRingId == 0u ? (ringId_T)mapPATHSTREETCLASSCOUNT - 1u : *endRingId - 1u].type))
	{
		if (streetClassRing->count >= (ringId_T)mapPATHSTREETCLASSCOUNT)
		{
			prtOutputBufferWarning(&streetClassRing->debugMsgLock);
			return false;
		}
		streetClassRing->debugMsgLock = false;
		streetClassRing->streetClass[*endRingId].segmentRingId = segmentRingId;
		streetClassRing->streetClass[*endRingId].offset = 0u;
		streetClassRing->streetClass[*endRingId].type = streetClass;
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHSTREETCLASSCOUNT;
		streetClassRing->count++;
	}
	return true;
}


static bool_T				prtCopyRamp(IN	const	psdSegment_T				*segment,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapRampRing_T				*rampRing,
										OUT			ringId_T					*endRingId)			
{
	prtRampValues_T ramp = (prtRampValues_T)segment->attributes.ramp; /*lint !e9030 !e9034*/
	*endRingId = (rampRing->start + rampRing->count) % (ringId_T)mapPATHRAMPCOUNT;

	if (	(rampRing->count == 0u)
		||	(ramp != rampRing->ramp[*endRingId == 0u ? (ringId_T)mapPATHRAMPCOUNT - 1u : *endRingId - 1u].type))
	{
		if (rampRing->count >= (ringId_T)mapPATHRAMPCOUNT) {
			prtOutputBufferWarning(&rampRing->debugMsgLock);
			return false;
		}

		rampRing->debugMsgLock = false;
		rampRing->ramp[*endRingId].segmentRingId = segmentRingId;
		rampRing->ramp[*endRingId].offset = 0u;
		rampRing->ramp[*endRingId].type = ramp;
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHRAMPCOUNT;
		rampRing->count++;
	}
	return true;
}

bool_T			   prtCopyOppositeLanes(IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapLaneSituationRing_T		*laneSituationRing,
										OUT			ringId_T					*endRingId)
{
	ringId_T lastElementId = (laneSituationRing->start + laneSituationRing->count - 1u) % (ringId_T)mapPATHLANESITUATIONCOUNT;
	*endRingId = (laneSituationRing->start + laneSituationRing->count) % (ringId_T)mapPATHLANESITUATIONCOUNT;

	if (laneSituationRing->count >= (ringId_T)mapPATHLANESITUATIONCOUNT) {
		prtOutputBufferWarning(&laneSituationRing->debugMsgLock);
		return false;
	}
	else
	{
		uint8_T offset;
		diagFF(prtOffsetToUint8(attribute->offset, &offset));

		laneSituationRing->debugMsgLock = false;

		/*Unterscheide folgende Situationen zum Umgang mit anderen Spuren (Abbiege und Vorw�rts):
		Erste laneSitation: andere Spuren nullen.
		Gleiche Position wie letzte laneSituation: Vorw�rtsspuren letzter laneSituation �berschreiben
		Sonst: andere Spuren von letzter laneSitation �bernehmen
		*/
		if (laneSituationRing->count == (ringId_T)0u)
		{
				laneSituationRing->laneSituation[*endRingId].turnLanesLeft = 0u;
				laneSituationRing->laneSituation[*endRingId].turnLanesRight = 0u;
				laneSituationRing->laneSituation[*endRingId].forwardLanes = 0u;
		}
		else if (laneSituationRing->laneSituation[lastElementId].segmentRingId == segmentRingId && laneSituationRing->laneSituation[lastElementId].offset == offset)
		{
				*endRingId = lastElementId;
				laneSituationRing->count--;
		}
		else
		{
				laneSituationRing->laneSituation[*endRingId] = laneSituationRing->laneSituation[lastElementId];
		}
		laneSituationRing->laneSituation[*endRingId].segmentRingId = segmentRingId;
		laneSituationRing->laneSituation[*endRingId].offset = offset;
		laneSituationRing->laneSituation[*endRingId].oppositeLanes = attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_LANES_OPPOSITE_NO_INFO ? (uint8_T)0u : (uint8_T)attribute->value;
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHLANESITUATIONCOUNT;
		laneSituationRing->count++;
	}
	return true;
}


static bool_T		prtCopyTurningLanes(IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapLaneSituationRing_T		*laneSituationRing,
										OUT			ringId_T					*endRingId)
{
	ringId_T lastElementId = (laneSituationRing->start + laneSituationRing->count - 1u) % (ringId_T)mapPATHLANESITUATIONCOUNT;
	*endRingId = (laneSituationRing->start + laneSituationRing->count) % (ringId_T)mapPATHLANESITUATIONCOUNT;

	if (attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_NO_INFO)
	{
		;
	}
	else if (laneSituationRing->count >= (ringId_T)mapPATHLANESITUATIONCOUNT) {
		prtOutputBufferWarning(&laneSituationRing->debugMsgLock);
		return false;
	}
	else
	{
		laneSituationRing->debugMsgLock = false;

		/*Alles kopieren au�er den Abbiegespuren*/
		diagFF(laneSituationRing->count > 0u); /*Zumindest currentSegment.attributes.lanes sollte vorhanen sein.*/
		laneSituationRing->laneSituation[*endRingId] = laneSituationRing->laneSituation[lastElementId];

		if (	(psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_ONE_RIGHT <= attribute->value
			&&  attribute->value <= (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_SEVEN_RIGHT)
		{
			laneSituationRing->laneSituation[*endRingId].turnLanesRight = (uint8_T)(1u + attribute->value - (uint8_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_ONE_RIGHT);
		}
		else if (	(psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_ONE_LEFT <= attribute->value  
				 && attribute->value <= (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_SEVER_LEFT) /*(sic!)*/
		{
			laneSituationRing->laneSituation[*endRingId].turnLanesLeft = (uint8_T)(1u + attribute->value - (uint8_T)PSD_EHR_ATTRIBUTE_TURNING_LANE_ONE_LEFT);
		}
		else
		{
			laneSituationRing->laneSituation[*endRingId].turnLanesRight = 0u;
			laneSituationRing->laneSituation[*endRingId].turnLanesLeft = 0u;
		}
		laneSituationRing->laneSituation[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &laneSituationRing->laneSituation[*endRingId].offset));
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHLANESITUATIONCOUNT;
		laneSituationRing->count++;
	}
	return true;
}


bool_T					   prtCopySlope(IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapSlopeRing_T				*slopeRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (slopeRing->start + slopeRing->count) % (ringId_T)mapPATHSLOPECOUNT;

	if (slopeRing->count >= (ringId_T)mapPATHSLOPECOUNT) {
		prtOutputBufferWarning(&slopeRing->debugMsgLock);
		return false;
	}
	else
	{
		slopeRing->debugMsgLock = false;

		slopeRing->slope[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &slopeRing->slope[*endRingId].offset));
		
		switch (attribute->value)
		{
		case (psdAttributeValue_T)PSD_EHR_SLOPE_VALUE_EXCEEDMIN: slopeRing->slope[*endRingId].slope = (psdSlope_T)PSD_EHR_SLOPE_VALUE_MIN; break;
		case (psdAttributeValue_T)PSD_EHR_SLOPE_VALUE_EXCEEDMAX: slopeRing->slope[*endRingId].slope = (psdSlope_T)PSD_EHR_SLOPE_VALUE_MAX; break;
		default:												 slopeRing->slope[*endRingId].slope = attribute->value; break;
		}

		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHSLOPECOUNT;
		slopeRing->count++;
	}

	return true;
}


static bool_T  prtCopyRightOfWayControl(IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapRightOfWayRing_T			*rightOfWayRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (rightOfWayRing->start + rightOfWayRing->count) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;

	if (	attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_RIGHT_OF_WAY_CONTROL_NO_INFO)
	{
		;
	}
	else if (rightOfWayRing->count >= (ringId_T)mapPATHRIGHTOFWAYCOUNT)
	{
		prtOutputBufferWarning(&rightOfWayRing->debugMsgLock);
		return false;
	}
	else
	{
		rightOfWayRing->debugMsgLock = false;

		rightOfWayRing->rightOfWayControl[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &rightOfWayRing->rightOfWayControl[*endRingId].offset));
		rightOfWayRing->rightOfWayControl[*endRingId].type = (prtRightOfWayControlValues_T)attribute->value; /*lint !e9030 !e9034*/
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;
		rightOfWayRing->count++;
	}

	return true;
}



static bool_T  prtCopyTrafficLight(		IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapRightOfWayRing_T			*rightOfWayRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (rightOfWayRing->start + rightOfWayRing->count) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;

	if (	attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_LIGHT_NO
		||	attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_LIGHT_NO_INFO)
	{
		;
	}
	else if (rightOfWayRing->count >= (ringId_T)mapPATHRIGHTOFWAYCOUNT)
	{
		prtOutputBufferWarning(&rightOfWayRing->debugMsgLock);
		return false;
	}
	else
	{
		rightOfWayRing->debugMsgLock = false;

		rightOfWayRing->rightOfWayControl[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &rightOfWayRing->rightOfWayControl[*endRingId].offset));
		
		if (attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_LIGHT_YES)
		{
			rightOfWayRing->rightOfWayControl[*endRingId].type = prtRowcTrafficLight;		
		} 
		else if (attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_LIGHT_WITH_GREEN_ARROW)
		{
			rightOfWayRing->rightOfWayControl[*endRingId].type = prtRowcTrafficLightWithGreenArrow;	
		}
		else
		{
			diagFUnreachable();
		}
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;
		rightOfWayRing->count++;
	}

	return true;
}


bool_T				 prtCopyOnlineSpeed(IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapSpeedLimitRing_T			*onlineSpeedRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (onlineSpeedRing->start + onlineSpeedRing->count) % (ringId_T)mapPATHONLINESPEEDCOUNT;
	
	if (onlineSpeedRing->count >= (ringId_T)mapPATHONLINESPEEDCOUNT) {
		prtOutputBufferWarning(&onlineSpeedRing->debugMsgLock);
		return false;
	}
	else
	{
		onlineSpeedRing->debugMsgLock = false;

		onlineSpeedRing->speedLimit[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &onlineSpeedRing->speedLimit[*endRingId].offset));
		onlineSpeedRing->speedLimit[*endRingId].unit = (psdSpeedLimitUnit_T)prtSpeedLimitUnitKMH;
		onlineSpeedRing->speedLimit[*endRingId].constraintFog = false;
		onlineSpeedRing->speedLimit[*endRingId].constraintLane = false;
		onlineSpeedRing->speedLimit[*endRingId].constraintTime = false;
		onlineSpeedRing->speedLimit[*endRingId].constraintTrailer = false;
		onlineSpeedRing->speedLimit[*endRingId].constraintWet = false;
		onlineSpeedRing->speedLimit[*endRingId].variableSign = false;

		switch (attribute->value)
		{
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_0_LT_10:		onlineSpeedRing->speedLimit[*endRingId].value= 10u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_10_LT_30:		onlineSpeedRing->speedLimit[*endRingId].value= 30u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_30_LT_50:		onlineSpeedRing->speedLimit[*endRingId].value= 50u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_50_LT_60:		onlineSpeedRing->speedLimit[*endRingId].value= 60u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_60_LT_70:		onlineSpeedRing->speedLimit[*endRingId].value= 70u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_70_LT_80:		onlineSpeedRing->speedLimit[*endRingId].value= 80u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_80_LT_90:		onlineSpeedRing->speedLimit[*endRingId].value= 90u;		break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_90_LT_100:		onlineSpeedRing->speedLimit[*endRingId].value= 100u;	break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_100_LT_110:		onlineSpeedRing->speedLimit[*endRingId].value= 110u;	break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_110_LT_120:		onlineSpeedRing->speedLimit[*endRingId].value= 120u;	break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_120_LT_130:		onlineSpeedRing->speedLimit[*endRingId].value= 130u;	break;
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_SPEED_GTE_130:			
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_NO_CONGESTION:			
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_NO_TRAFFIC_DATA:			
		case (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA_NO_INFORMATION:			onlineSpeedRing->speedLimit[*endRingId].value= rawLimitReleased; break;
		default:
			diagFUnreachable();
		} /*lint !e9077*/
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHONLINESPEEDCOUNT;
		onlineSpeedRing->count++;
	}

	return true;
}


bool_T			 prtCopyStreetSituation(IN	const	psdAttribute_T				*attribute,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapStreetSituationRing_T	*streetSituationRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (streetSituationRing->start + streetSituationRing->count) % (ringId_T)mapPATHSTREETSITUATIONCOUNT;

	if (attribute->value == (psdAttributeValue_T)PSD_EHR_ATTRIBUTE_STREET_SITUATION_NO_INFO) {
		;
	}
	else if (streetSituationRing->count >= (ringId_T)mapPATHSTREETSITUATIONCOUNT) {
		prtOutputBufferWarning(&streetSituationRing->debugMsgLock);
		return false;
	}
	else {
		streetSituationRing->debugMsgLock = false;

		streetSituationRing->streetSituation[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &streetSituationRing->streetSituation[*endRingId].offset));
		streetSituationRing->streetSituation[*endRingId].type = (prtStreetSituationValues_T)attribute->value; /*lint !e9030 !e9034*/
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHSTREETSITUATIONCOUNT;
		streetSituationRing->count++;
	}

	return true;
}


bool_T	prtCopyTrafficDirection(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
								IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
								INOUT		mapTrafficDirectionRing_T	*trafficDirectionRing,	/**<Ringspeicher f�r Werte*/
								OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im trafficDirectionRing */
								)
{
	*endRingId = (trafficDirectionRing->start + trafficDirectionRing->count) % (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT;

	if (trafficDirectionRing->count >= (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT) {
		prtOutputBufferWarning(&trafficDirectionRing->debugMsgLock);
		return false;
	}
	else {
		trafficDirectionRing->debugMsgLock = false;

		trafficDirectionRing->trafficDirection[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &trafficDirectionRing->trafficDirection[*endRingId].offset));
		if (attribute->value == (uint8_T)PSD_EHR_ATTRIBUTE_SYSTEM_TRAFFIC_DIRECTION_RIGHT_HANDED) {
			trafficDirectionRing->trafficDirection[*endRingId].trafficDirection = trafficDirRight;
		} else if (attribute->value == (uint8_T)PSD_EHR_ATTRIBUTE_SYSTEM_TRAFFIC_DIRECTION_LEFT_HANDED) {
			trafficDirectionRing->trafficDirection[*endRingId].trafficDirection = trafficDirLeft;
		} else {
			trafficDirectionRing->trafficDirection[*endRingId].trafficDirection = trafficDirUnknown;
		}
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT;
		trafficDirectionRing->count++;
	}

	return true;
}


bool_T	  prtCopySpeedLimitUnit(IN	const	psdAttribute_T				*attribute,
								IN	const	ringId_T					 segmentRingId,
								INOUT		mapSpeedLimitUnitRing_T		*speedLimitUnitRing,
								OUT			ringId_T					*endRingId)
{
	*endRingId = (speedLimitUnitRing->start + speedLimitUnitRing->count) % (ringId_T)mapPATHSPEEDLIMITUNITCOUNT;

	if (speedLimitUnitRing->count >= (ringId_T)mapPATHSPEEDLIMITUNITCOUNT) {
		prtOutputBufferWarning(&speedLimitUnitRing->debugMsgLock);
		return false;
	}
	else {
		speedLimitUnitRing->debugMsgLock = false;

		speedLimitUnitRing->speedLimitUnit[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &speedLimitUnitRing->speedLimitUnit[*endRingId].offset));
		speedLimitUnitRing->speedLimitUnit[*endRingId].speedLimitUnit = (psdSpeedLimitUnit_T)attribute->value;
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHSPEEDLIMITUNITCOUNT;
		speedLimitUnitRing->count++;
	}
	
	return true;
}


bool_T	  prtCopyQualityGeometry(IN	const	psdAttribute_T				*attribute,
								IN	const	ringId_T					 segmentRingId,
								INOUT		mapQualityGeometryRing_T	*qualityGeometryRing,
								OUT			ringId_T					*endRingId)
{
	uint8_T lastQuality;
	*endRingId = (qualityGeometryRing->start + qualityGeometryRing->count) % (ringId_T)mapPATHQUALITYGEOMETRYCOUNT;
	lastQuality= qualityGeometryRing->qualityGeometry[*endRingId == 0u ? (ringId_T)mapPATHQUALITYGEOMETRYCOUNT - 1u : *endRingId - 1u].qualityGeometry;

	if ((qualityGeometryRing->count == 0u) || (attribute->value != lastQuality))
	{
		if (qualityGeometryRing->count >= (ringId_T)mapPATHQUALITYGEOMETRYCOUNT) {
			prtOutputBufferWarning(&qualityGeometryRing->debugMsgLock);
			return false;
		}
		else {
			qualityGeometryRing->debugMsgLock = false;

			qualityGeometryRing->qualityGeometry[*endRingId].segmentRingId = segmentRingId;
			diagFF(prtOffsetToUint8(attribute->offset, &qualityGeometryRing->qualityGeometry[*endRingId].offset));
			qualityGeometryRing->qualityGeometry[*endRingId].qualityGeometry = (uint8_T)attribute->value;
		
			*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHQUALITYGEOMETRYCOUNT;
			qualityGeometryRing->count++;
		}
	}
	
	return true;
}


bool_T		 prtCopyCountryCode(IN	const	psdAttribute_T				*attribute,
								IN	const	ringId_T					 segmentRingId,
								INOUT		mapCountryCodeRing_T		*countryCodeRing,
								OUT			ringId_T					*endRingId)
{
	*endRingId = (countryCodeRing->start + countryCodeRing->count) % (ringId_T)mapPATHCOUNTRYCODECOUNT;

	if (countryCodeRing->count >= (ringId_T)mapPATHCOUNTRYCODECOUNT) {
		prtOutputBufferWarning(&countryCodeRing->debugMsgLock);
		return false;
	}
	else {
		countryCodeRing->debugMsgLock = false;

		countryCodeRing->countryCode[*endRingId].segmentRingId = segmentRingId;
		diagFF(prtOffsetToUint8(attribute->offset, &countryCodeRing->countryCode[*endRingId].offset));
		countryCodeRing->countryCode[*endRingId].countryCode = attribute->value;
		
		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHCOUNTRYCODECOUNT;
		countryCodeRing->count++;
	}
	
	return true;
}


static bool_T		prtCopyIntersection(IN	const	uint8_T						 angleTolerance,
										IN	const	uint8_T						 smallestAngle,
										IN	const	ringId_T					 segmentRingId,
										INOUT		mapRightOfWayRing_T			*rightOfWayRing,
										OUT			ringId_T					*endRingId)
{
	*endRingId = (rightOfWayRing->start + rightOfWayRing->count) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;

	if (rightOfWayRing->count >= (ringId_T)mapPATHRIGHTOFWAYCOUNT) {
		prtOutputBufferWarning(&rightOfWayRing->debugMsgLock);
		return false;
	}
	else
	{
		rightOfWayRing->debugMsgLock = false;

		rightOfWayRing->rightOfWayControl[*endRingId].segmentRingId = segmentRingId;
		rightOfWayRing->rightOfWayControl[*endRingId].offset = 0u;
		
		if (smallestAngle > angleTolerance) {
			rightOfWayRing->rightOfWayControl[*endRingId].type = prtRowcIntersectionNoStraightPath;
		} 
		else {
			rightOfWayRing->rightOfWayControl[*endRingId].type = prtRowcIntersectionWithStraightPath;
		}

		*endRingId = (*endRingId + 1u) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;
		rightOfWayRing->count++;
	}

	return true;
}
