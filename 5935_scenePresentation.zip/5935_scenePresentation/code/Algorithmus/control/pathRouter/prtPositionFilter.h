#ifndef guard_prtPositionFilter_h
#define guard_prtPositionFilter_h

#include "pathRouter.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"

/** \brief Aktualisiert den positionFilter.

Die `positionFilter->vehicleDistance` und die `positionFilter->vehDistCorrection` werden in \ref prtPositionCorrection() aktualisiert.

Falls der Filter nicht initialisiert ist, oder die Funtkion \ref prtPositionCorrection() `resetFlag == true` meldet, wird er initialisiert.
Sonst (im Normalfall) werden die aktualisierten Werte �bernommen.

\spec SwMS_Innodrive2_PSD_156
\spec SwMS_Innodrive2_PSD_154

\ingroup pathRouter_caching
*/
bool_T		prtUpdatePosition(		IN const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
									IN const	mapSegmentRing_T		*segmentRing,		/**<Speicher der Pfad-Segmente*/
									IN const	mapRawVehiclePosition_T	*rawPosition,		/**<Segment-Id und Offset*/
									IN const	real32_T				 longPosition,		/**<Monoton Steigende Position vom vehicleObserver*/
									IN const	uint16_T				 newDistance,		/**<Abstand der `rawPosition` vom Pfadanfang*/
									INOUT		mapPositionFilter_T		*positionFilter		/**<Filter der Fahrzeugposition*/
									);


/** \brief Reset des Positionsfilters auf die psdPosition und hochz�hlen des `positionFilter->resetCount`

\spec SwMS_Innodrive2_PSD_154
\spec SwMS_Innodrive2_PSD_166
\ingroup pathRouter_caching
*/
bool_T		prtResetPosition(		IN const	mapSegmentRing_T		*segmentRing,		/**<Speicher der Pfad-Segmente*/
									IN const	mapRawVehiclePosition_T	*rawPosition,		/**<Segment-Id und Offset*/
									IN const	real32_T				 longPosition,		/**<Monoton Steigende Position vom vehicleObserver*/
									IN const	uint16_T				 newDistance,		/**<Abstand der `rawPosition` vom Pfadanfang*/
									INOUT		mapPositionFilter_T		*positionFilter		/**<Filter der Fahrzeugposition*/
									);
#endif
