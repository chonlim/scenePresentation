#include "prtInfo.h"
#include "prtInfoStatic.h"

#include "control/pathRouter/prtPrepare.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtInfo)


bool_T				 prtBuildPathRouterInfo(IN	const	mapPathMemory_T				*mapPathMemory,
											OUT			mapInfo_T					*mapInfo,
											OUT			bool_T						*infoValid)
{
	bool_T valid;

	/*Einzelattribute �bertragen*/
	diagFF(mapPathMemory->trafficDirectionRing.count > 0u);
	diagFF(mapPathMemory->countryCodeRing.count > 0u);
	diagFF(mapPathMemory->speedLimitUnitRing.count > 0u);
	diagFF(mapPathMemory->qualityGeometryRing.count > 0u);
	
	mapInfo->distance = mapPathMemory->distance;

	/*Attributlisten �bertragen*/
	diagFF(				prtBuildInfoGps(&mapPathMemory->segmentRing,
										&mapPathMemory->gpsRing,
										&mapInfo->gpsInfo));
	valid = mapPathMemory->gpsRing.count > 0u;

	diagFF(		prtBuildInfoSpeedLimits(&mapPathMemory->segmentRing,
										&mapPathMemory->speedLimitRing,
										&mapInfo->speedLimitRing));
	valid = valid && mapInfo->speedLimitRing.count > 0u;

	diagFF(		prtBuildInfoStreetClass(&mapPathMemory->segmentRing,
										&mapPathMemory->streetClassRing,
										&mapInfo->streetClassRing));
	valid = valid && mapInfo->streetClassRing.count > 0u;

	diagFF(		prtBuildInfoBuiltUpArea(&mapPathMemory->segmentRing,
										&mapPathMemory->builtUpRing,
										&mapInfo->builtUpRing));
	valid = valid && mapInfo->builtUpRing.count > 0u;

	diagFF(			   prtBuildInfoRamp(&mapPathMemory->segmentRing,
										&mapPathMemory->rampRing,
										&mapInfo->rampRing));
	valid = valid && mapInfo->rampRing.count > 0u;

	diagFF(		 prtBuildInfoRightOfWay(&mapPathMemory->segmentRing,
										&mapPathMemory->rightOfWayRing,
										&mapInfo->rightOfWayRing));
	/*Anzahl ROWC darf Null sein*/

	diagFF(		 prtBuildInfoRoundabout(&mapPathMemory->segmentRing,
										&mapPathMemory->streetSituationRing,
										&mapInfo->roundaboutRing));
	/*Anzahl Kreisel darf Null sein*/

	diagFF(   prtBuildInfoLaneSituation(&mapPathMemory->segmentRing,
										&mapPathMemory->laneSituationRing,
										&mapInfo->laneSituationRing));
	valid = valid && mapInfo->laneSituationRing.count > 0u;

	diagFF(		 prtBuildInfoCurvatures(&mapPathMemory->segmentRing,
										&mapPathMemory->curvatureRing,
										&mapInfo->distance,
										&mapInfo->curvatureRing));
	valid = valid && mapInfo->curvatureRing.count > 0u;

	diagFF(	   prtBuildInfoBranchAngles(&mapPathMemory->segmentRing,
										&mapPathMemory->branchAngleRing,
										&mapInfo->distance,
										&mapInfo->branchAngleRing));
	/*Anzahl Branchangles darf Null sein*/

	diagFF(			 prtBuildInfoSlopes(&mapPathMemory->segmentRing,
										&mapPathMemory->slopeRing,
										&mapInfo->distance,
										&mapInfo->slopeRing));
	valid = valid && mapInfo->slopeRing.count > 0u;

	*infoValid = valid ? true : false;
	return true;
}



bool_T			 prtPositionToUint16(		IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	ringId_T					 segmentRingId,
											IN	const	uint8_T						 offset,
											OUT			uint16_T					*position)
{
	diagFF(segmentRingId < (ringId_T)mapMAXROUTELENGTH);
	*position = segmentRing->segment[segmentRingId].startDistance + (uint16_T)offset;
	return true;
}


static bool_T				prtBuildInfoGps(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapGpsRing_T				*gpsRing,
											OUT			infoGpsInfo_T				*gpsInfo)
{
	ringId_T ringId = (gpsRing->start + gpsRing->count - 1u) % (ringId_T)mapPATHGPSCOUNT;
	
	gpsInfo->latitude = gpsRing->gpsInfo[ringId].latitude;
	gpsInfo->longitude = gpsRing->gpsInfo[ringId].longitude;
	gpsInfo->heading = gpsRing->gpsInfo[ringId].heading;
	gpsInfo->altitude = gpsRing->gpsInfo[ringId].altitude;
	diagFF(prtPositionToUint16(	 segmentRing, 
								 gpsRing->gpsInfo[ringId].segmentRingId, 
								 gpsRing->gpsInfo[ringId].offset, 
								&gpsInfo->position));

	return true;
}


static bool_T		prtBuildInfoSpeedLimits(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapSpeedLimitRing_T			*speedLimitRing,
											OUT			infoSpeedLimitRing_T		*infoSpeedLimits)
{
	ringId_T index, ringId;

	for (index = 0; index < (ringId_T)mapINFOSPEEDLIMITCOUNT; index++) {
		ringId = (speedLimitRing->start + index) % (ringId_T)mapPATHSPEEDLIMITCOUNT;
		infoSpeedLimits->speedLimit[index].value	= speedLimitRing->speedLimit[ringId].value;

		diagFF(prtEncodeLimitInfo( speedLimitRing->speedLimit[ringId].unit,
								   speedLimitRing->speedLimit[ringId].constraintTrailer,
								   speedLimitRing->speedLimit[ringId].constraintWet,
								   speedLimitRing->speedLimit[ringId].constraintFog,
								   speedLimitRing->speedLimit[ringId].constraintTime,
								   speedLimitRing->speedLimit[ringId].constraintLane,
								   speedLimitRing->speedLimit[ringId].variableSign,
								  &infoSpeedLimits->speedLimit[index].codedInfo));

		diagFF(prtPositionToUint16(	 segmentRing,
									 speedLimitRing->speedLimit[ringId].segmentRingId,
									 speedLimitRing->speedLimit[ringId].offset,
									&infoSpeedLimits->speedLimit[index].position));

		diagFF(index == 0u ||  index >= speedLimitRing->count || infoSpeedLimits->speedLimit[index-1u].position <= infoSpeedLimits->speedLimit[index].position)
	}

	infoSpeedLimits->count = min((ringId_T)mapINFOSPEEDLIMITCOUNT, speedLimitRing->count);

	return true;
}


static bool_T		prtBuildInfoBuiltUpArea(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapBuiltUpRing_T			*builtUpRing,
											OUT			infoBuiltUpRing_T			*infoBuiltUpAreas)
{
	ringId_T index, ringId;

	for (index = 0; index < (ringId_T)mapINFOBUILTUPAREACOUNT; index++) {
		ringId = (builtUpRing->start + index) % (ringId_T)mapPATHBUILTUPAREACOUNT;
		/*Cast zu uint8_T um traffic zu sparen. Der R�ckcast findet im prtDataInterface statt.*/
		infoBuiltUpAreas->builtUp[index].builtUp = builtUpRing->builtUpArea[ringId].type;
		diagFF(prtPositionToUint16(	 segmentRing,
									 builtUpRing->builtUpArea[ringId].segmentRingId,
									 builtUpRing->builtUpArea[ringId].offset,
									&infoBuiltUpAreas->builtUp[index].position));
	
		diagFF(index == 0u ||  index >= builtUpRing->count || infoBuiltUpAreas->builtUp[index-1u].position <= infoBuiltUpAreas->builtUp[index].position)
	}

	infoBuiltUpAreas->count = min((ringId_T)mapINFOBUILTUPAREACOUNT, builtUpRing->count);

	return true;
}


static bool_T		prtBuildInfoStreetClass(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapStreetClassRing_T		*streetClassRing,
											OUT			infoStreetClassRing_T		*infoStreetClasses)
{
	ringId_T index, ringId;

	for (index = 0; index < (ringId_T)mapINFOSTREETCLASSCOUNT; index++) {
		ringId = (streetClassRing->start + index) % (ringId_T)mapPATHSTREETCLASSCOUNT;
		/*Cast zu uint8_T um traffic zu sparen. Der R�ckcast findet im prtDataInterface statt.*/
		infoStreetClasses->streetClass[index].type = (uint8_T)streetClassRing->streetClass[ringId].type;
		diagFF(prtPositionToUint16(	 segmentRing,
									 streetClassRing->streetClass[ringId].segmentRingId,
									 streetClassRing->streetClass[ringId].offset,
									&infoStreetClasses->streetClass[index].position));
	
		diagFF(index == 0u ||  index >= streetClassRing->count || infoStreetClasses->streetClass[index-1u].position <= infoStreetClasses->streetClass[index].position)
	}
	infoStreetClasses->count = min((ringId_T)mapINFOSTREETCLASSCOUNT, streetClassRing->count);

	return true;
}


static bool_T			   prtBuildInfoRamp(IN	const	mapSegmentRing_T	*segmentRing,
											IN	const	mapRampRing_T		*rampRing,
											OUT			infoRampRing_T		*infoRamps)
{
	ringId_T index, ringId;

	for (index = 0; index < (ringId_T)mapINFORAMPCOUNT; index++) {
		ringId = (rampRing->start + index) % (ringId_T)mapPATHRAMPCOUNT;
		/*Cast zu uint8_T um traffic zu sparen. Der R�ckcast findet im prtDataInterface statt.*/
		infoRamps->ramp[index].type = (uint8_T)rampRing->ramp[ringId].type;
		diagFF(prtPositionToUint16(	 segmentRing,
									 rampRing->ramp[ringId].segmentRingId,
									 rampRing->ramp[ringId].offset,
									&infoRamps->ramp[index].position));
	
		diagFF(index == 0u ||  index >= rampRing->count || infoRamps->ramp[index-1u].position <= infoRamps->ramp[index].position)
	}
	infoRamps->count = min((ringId_T)mapINFORAMPCOUNT, rampRing->count);

	return true;
}


static bool_T		 prtBuildInfoRightOfWay(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapRightOfWayRing_T			*rightOfWayRing,
											OUT			infoRightOfWayRing_T		*infoRightOfWays)
{
	ringId_T index;
	ringId_T count = 0u;

	for(index = 0u; index < (ringId_T)mapPATHRIGHTOFWAYCOUNT; index++)
	{
		uint16_T pos;
		volatile uint8_T type;
		volatile uint16_T position;
		ringId_T ringId = (rightOfWayRing->start + index) % (ringId_T)mapPATHRIGHTOFWAYCOUNT;

		/*Cast zu uint8_T um traffic zu sparen. Der R�ckcast findet im prtDataInterface statt.*/
		type = (uint8_T)rightOfWayRing->rightOfWayControl[ringId].type;
		diagFF(prtPositionToUint16(	segmentRing,
									rightOfWayRing->rightOfWayControl[ringId].segmentRingId,
									rightOfWayRing->rightOfWayControl[ringId].offset,
									&pos));

		diagFF(count == 0u || index >= rightOfWayRing->count || infoRightOfWays->rightOfWayControl[count-1u].position <= pos);
		position = pos;

		if (	rightOfWayRing->rightOfWayControl[ringId].type != prtRowcNone
			&&	rightOfWayRing->rightOfWayControl[ringId].type != prtRowcIntersectionNoStraightPath
			&&	rightOfWayRing->rightOfWayControl[ringId].type != prtRowcIntersectionWithStraightPath
			&&	index < rightOfWayRing->count
			&&	count < (ringId_T)mapINFORIGHTOFWAYCOUNT)
		{
			/*Nur Schilder und Ampeln �bertragen*/
			infoRightOfWays->rightOfWayControl[count].type = type;
			infoRightOfWays->rightOfWayControl[count].position = position;
			count++;
		} else {
			/*Sonst Zeit verdummen*/
			type = infoRightOfWays->rightOfWayControl[0u].type;
			position = infoRightOfWays->rightOfWayControl[0u].position;
			count = count;
		}

	}
	infoRightOfWays->count = count;

	return true;
}


static bool_T		 prtBuildInfoRoundabout(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapStreetSituationRing_T	*streetSituationRing,
											OUT			infoRoundaboutRing_T		*infoRoundabout)
{
	ringId_T	index;
	ringId_T	ringId;

	for (index = 0; index < (ringId_T)mapINFOROUNDABOUTCOUNT; index++) {
		ringId = (streetSituationRing->start + index) % (ringId_T)mapPATHSTREETSITUATIONCOUNT;

		/* Ableiten der Kreisverkehrs-Info aus der PSD-Street Situation */
		infoRoundabout->roundabout[index].roundabout = (streetSituationRing->streetSituation[ringId].type == prtStreetSituationRoundabout ? true : false);

		diagFF(prtPositionToUint16( segmentRing,
								   streetSituationRing->streetSituation[ringId].segmentRingId,
								   streetSituationRing->streetSituation[ringId].offset,
								  &infoRoundabout->roundabout[index].position));
	
		diagFF(index == 0u ||  index >= streetSituationRing->count || infoRoundabout->roundabout[index-1u].position <= infoRoundabout->roundabout[index].position)
	}

	infoRoundabout->count = min((ringId_T)mapINFOROUNDABOUTCOUNT, streetSituationRing->count);

	return true;
}



static bool_T	  prtBuildInfoLaneSituation(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapLaneSituationRing_T		*laneSituationRing,
											OUT			infoLaneSituationRing_T		*infoLaneSituations)
{
	ringId_T index, ringId;

	for(index = 0; index < (ringId_T)mapINFOLANESITUATIONCOUNT; index++){
		ringId = (laneSituationRing->start + index) % (ringId_T)mapPATHLANESITUATIONCOUNT;
		infoLaneSituations->laneSituation[index].forwardLanes = laneSituationRing->laneSituation[ringId].forwardLanes;
		infoLaneSituations->laneSituation[index].oppositeLanes = laneSituationRing->laneSituation[ringId].oppositeLanes;
		infoLaneSituations->laneSituation[index].turnLanesLeft = laneSituationRing->laneSituation[ringId].turnLanesLeft;
		infoLaneSituations->laneSituation[index].turnLanesRight = laneSituationRing->laneSituation[ringId].turnLanesRight;
		diagFF(prtPositionToUint16(	segmentRing,
									laneSituationRing->laneSituation[ringId].segmentRingId,
									laneSituationRing->laneSituation[ringId].offset,
									&infoLaneSituations->laneSituation[index].position));
	
		diagFF(index == 0u ||  index >= laneSituationRing->count || infoLaneSituations->laneSituation[index-1u].position <= infoLaneSituations->laneSituation[index].position)
	}
	infoLaneSituations->count = min((ringId_T)mapINFOLANESITUATIONCOUNT, laneSituationRing->count);

	return true;
}


static bool_T		 prtBuildInfoCurvatures(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapCurvatureRing_T			*curvatureRing,
											INOUT		uint16_T					*infoDistance,
											OUT			infoCurvatureRing_T			*infoCurvatures)
{
	ringId_T index, memoryIndex, ringId;

	infoCurvatures->count = (ringId_T)mapINFOCURVATURECOUNT;
	index = 0;
	infoCurvatures->curvature[0u].endOfConstantSegmentMissing = false;

	for (memoryIndex = 0; memoryIndex < (ringId_T)mapPATHCURVATURECOUNT && index < (ringId_T)mapINFOCURVATURECOUNT; memoryIndex++)
	{

		ringId = (curvatureRing->start + memoryIndex) % (ringId_T)mapPATHCURVATURECOUNT;

		if (curvatureRing->curvature[ringId].offset == (psdLength_T)0)
		{
			/*Segmentanfang immer �bertragen*/
			infoCurvatures->curvature[index].curvature = curvatureRing->curvature[ringId].curvature;
			diagFF(prtPositionToUint16(	 segmentRing,
										 curvatureRing->curvature[ringId].segmentRingId,
										 curvatureRing->curvature[ringId].offset,
										&infoCurvatures->curvature[index].position));
			infoCurvatures->curvature[index].segmentId = segmentRing->segment[curvatureRing->curvature[ringId].segmentRingId].segmentId;
			index++;
		}
		else
		{
			/*Segmentende*/
			diagFF(index > 0u); /*Erste Kr�mmung kann nicht an einem Segmentende liegen.*/
			if (	memoryIndex + 1u == curvatureRing->count
				||	index + 1u == (ringId_T)mapINFOCURVATURECOUNT
				||	(	curvatureRing->curvature[ringId].curvature != infoCurvatures->curvature[index - 1u].curvature
					&&	curvatureRing->curvature[(ringId + 1u) % (ringId_T)mapPATHCURVATURECOUNT].curvature != curvatureRing->curvature[ringId].curvature))
			{
				/*Unstetigkeit ohne vorausgehendes konstantes Segment -> Kr�mmung �bertragen.*/
				infoCurvatures->curvature[index].curvature = curvatureRing->curvature[ringId].curvature;
				diagFF(prtPositionToUint16(	 segmentRing,
											 curvatureRing->curvature[ringId].segmentRingId,
											 curvatureRing->curvature[ringId].offset,
											&infoCurvatures->curvature[index].position));
				infoCurvatures->curvature[index].segmentId = segmentRing->segment[curvatureRing->curvature[ringId].segmentRingId].segmentId;
				infoCurvatures->curvature[index].endOfConstantSegmentMissing = false;
				diagFF(index >= (ringId_T)mapINFOCURVATURECOUNT || index >= curvatureRing->count || infoCurvatures->curvature[index-1u].position <= infoCurvatures->curvature[index].position);
				index++;
			}
			else if (curvatureRing->curvature[(ringId + 1u) % (ringId_T)mapPATHCURVATURECOUNT].curvature != curvatureRing->curvature[ringId].curvature) {
				/*Unstetigkeit mit vorausgehendem konstanten Segment -> Kr�mmung nicht �bertragen.*/
				infoCurvatures->curvature[index].endOfConstantSegmentMissing = true;
			}
			else {
				/*Stetiger �bergang*/
				infoCurvatures->curvature[index].endOfConstantSegmentMissing = false;
			}
		}
		if (memoryIndex + 1u == curvatureRing->count)
		{
			/*Ende des Pfades (letzte Curvature) erreicht*/
			infoCurvatures->count = index;
		}
	}

	infoCurvatures->count = min(infoCurvatures->count, curvatureRing->count);

	if (infoCurvatures->count > 0u) {
		*infoDistance = min(*infoDistance, infoCurvatures->curvature[infoCurvatures->count - 1u].position);
	}
	else {
		*infoDistance = 0u;
	}
	return true;
}


static bool_T	   prtBuildInfoBranchAngles(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapBranchAngleRing_T		*branchAngleRing,
											OUT			uint16_T					*infoDistance,
											OUT			infoBranchAngleRing_T		*infoBranchAngles)
{
	ringId_T index, ringId;

	for (index = 0u; index < (ringId_T)mapINFOBRANCHANGLECOUNT; index++) {
		ringId = (branchAngleRing->start + index) % (ringId_T)mapPATHBRANCHANGLECOUNT;
		infoBranchAngles->branchAngle[index].angle = branchAngleRing->branchAngle[ringId].angle;
		diagFF(prtPositionToUint16(	 segmentRing,
									 branchAngleRing->branchAngle[ringId].segmentRingId,
									 branchAngleRing->branchAngle[ringId].offset,
									&infoBranchAngles->branchAngle[index].position));
	
		diagFF(index == 0u ||  index >= branchAngleRing->count || infoBranchAngles->branchAngle[index-1u].position <= infoBranchAngles->branchAngle[index].position)
	}
	/*Gegebenenfalls den Horizont auf den ersten nicht �bertragenen BranchAngle k�rzen.*/
	infoBranchAngles->count = min((ringId_T)mapINFOBRANCHANGLECOUNT, branchAngleRing->count);
	if (branchAngleRing->count > (ringId_T)mapINFOBRANCHANGLECOUNT)
	{
		uint16_T endDistance;

		ringId = (branchAngleRing->start + (ringId_T)mapINFOBRANCHANGLECOUNT) % (ringId_T)mapPATHBRANCHANGLECOUNT;
		diagFF(prtPositionToUint16(	 segmentRing,
									 branchAngleRing->branchAngle[ringId].segmentRingId,
									 branchAngleRing->branchAngle[ringId].offset,
									&endDistance));
		*infoDistance = min(*infoDistance, endDistance);
	}

	return true;
}


static bool_T			 prtBuildInfoSlopes(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapSlopeRing_T				*slopeRing,
											OUT			uint16_T					*infoDistance,
											OUT			infoSlopeRing_T				*infoSlopes)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	ringId_T index, memoryIndex, ringId;

	uint8_T const minInvariantSlope	 = paramSet->pathRouter.minInvariantInfoSlopes;
	uint8_T const slopeSpacing		 = paramSet->pathRouter.slopeSpacing;
	
	int16_T surplusSlopes, maxSpacedSlopes, spacedSlopes, cutoff;

	surplusSlopes = (int16_T)slopeRing->count - (int16_T)mapINFOSLOPECOUNT;
	maxSpacedSlopes = (int16_T)mapINFOSLOPECOUNT - (int16_T)minInvariantSlope;
	if (slopeSpacing > 1u) {
		spacedSlopes = min(surplusSlopes / ((int16_T)slopeSpacing - (int16_T)1), maxSpacedSlopes);
	} else {
		spacedSlopes = 0;
	}
	cutoff = (int16_T)mapINFOSLOPECOUNT - spacedSlopes;
	diagFF(cutoff > 0);
	
	index = 0;
	memoryIndex = 0;

	while(index < (ringId_T)mapINFOSLOPECOUNT) {
		diagFF(memoryIndex <= (ringId_T)mapPATHSLOPECOUNT);
		ringId = (slopeRing->start + memoryIndex) % (ringId_T)mapPATHSLOPECOUNT;
		infoSlopes->slope[index].slope = slopeRing->slope[ringId].slope;
		diagFF(prtPositionToUint16(	 segmentRing,
									 slopeRing->slope[ringId].segmentRingId,
									 slopeRing->slope[ringId].offset,
									&infoSlopes->slope[index].position));
		diagFF(index == 0u || index >= slopeRing->count || infoSlopes->slope[index-1u].position <= infoSlopes->slope[index].position)
		index++;
		if (index < minInvariantSlope) {
			/*Alle Steigungen bis zum parametrierten Wert �bertragen*/
			memoryIndex += 1u; }
		else if (index < (ringId_T)cutoff) {
			/*Solange jede Steigung �bertragen, bis in mapPAthMemory doppelt so viele Steigungen �brig sind, wie in mapInfoturnSignal hineinpassen*/
			memoryIndex += 1u; }
		else { 
			/*Steigungen mit spacing �bertragen*/
			memoryIndex += slopeSpacing; }
	}
	/*Gegebenenfalls den Horizont auf die Position der letzten �bertragenen Steigung k�rzen.*/
	infoSlopes->count = min((ringId_T)mapINFOSLOPECOUNT, slopeRing->count);
	if (slopeRing->count > minInvariantSlope + slopeSpacing * ((ringId_T)mapINFOSLOPECOUNT - minInvariantSlope))
	{
		*infoDistance = min(*infoDistance, infoSlopes->slope[infoSlopes->count - 1u].position);
	}

	return true;
}
