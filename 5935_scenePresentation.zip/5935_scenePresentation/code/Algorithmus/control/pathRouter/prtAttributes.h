#ifndef guard_prtAttributes_h
#define guard_prtAttributes_h

#include "pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"
#include "control/psdWrapper/psdWrapper.h"


#ifdef __cplusplus
extern "C" {
#endif


/**\brief Umrechnung vom PSD-Datentyp psdOffset[cm] nach uint8_T [m]

Hierbei wird immer abgerundet. Ein Genauigkeitsverlust entsteht nicht, da de facto die Attribute vom psd-Modul immer mit einer Genauigkeit von
einem Meter �bergeben werden. Die letzten beiden Dezimalstellen lauten stets "00".

\ingroup pathRouter_caching
*/
bool_T			   prtOffsetToUint8(IN	const	psdLength_T					 offset,					/**<Offset in cm*/				
									OUT			uint8_T						*position					/**<Offset in m*/
									);


/** \brief	Die Daten der `mapRoute`-Segmente werden in den mapPath �bertragen und mit einer fortlaufenden Position versehen.

Es wird angenommen, dass der mapPath Initialisiert ist (\ref prtCopyRootTreeState()) und dass die mapRoute g�ltig ist.
Die Daten, die in der Datenstruktur PsdEhr_Segment_T selbst abgelegt sind, werden in jedem Fall �bertragen (\ref prtCopySegmentAttributes).
Weitere Attribute (\ref prtCopyAttributes()) und Tempolimits (\ref prtCopySpeedLimits()) werden solange �bertragen, bis die Maximalzahl der erlaubten Api-Aufrufe erreicht ist.
Wenn nach der �bertragung eines Segments die Maximalzahl der erlaubten Api-Aufrufe noch nicht erreicht ist, wird das n�chste Segment �bertragen.

Jedes Segment im Ringspeicher `mapPathMemory->segmentRing` speichert den `count` bzw. den "letzten Index + 1" jedes Attribut-Ringspeichers als `...EndRingId`,
um den Speicher freigeben zu k�nnen, wenn das Segment �berfahren worden ist.

Falls in diesem Takt das letzte kopierte Segment bzgl. Attributen oder Tempolimits nicht vervollst�ndigt werden kann,
wird das `mapPathMemory->unfinishedSegment` auf dessen Index im `mapPathMemory->segmentRing` gesetzt.
Falls es kein unfertiges Segment gibt, wird `mapPathMemory->unfinishedSegment = INVALID_UINT8` gesetzt.

\spec SwMS_Innodrive2_PSD_178
\spec SwMS_Innodrive2_PSD_152
\spec SwMS_Innodrive2_PSD_177
\spec SwMS_Innodrive2_PSD_178
\ingroup pathRouter_caching
*/
bool_T			prtGetPathFromRoute(IN	const	mapRoute_T					*mapRoute,					/**<Liste der zu befahrenden Segmente*/
									IN	const	parameterSetCtrl_T			*parameterSet,				/**<globale Parameter*/
									IN	const	uint8_T						 firstNewRouteSegment,		/**<Erstes Segment auf der mapRoute, das noch nicht im mapPath liegt.*/
									IN	const	uint8_T						 nSegmentCalls,				/**<Zahl der Api-Aufrufe*/
									INOUT		mapPathMemory_T				*mapPathMemory,				/**<persistente Pfaddaten*/
									INOUT		uint8_T						*nSpeedLimitCalls,			/**<Zahl der Api-Aufrufe*/
									INOUT		uint8_T						*nAttributeCalls  			/**<Zahl der Api-Aufrufe*/
									); 


/** \brief �bertragen von Segmentattributen
\spec SwMS_Innodrive2_PSD_177
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
bool_T				   prtCopySegmentAttributes(IN	const	parameterSetCtrl_T		*parameterSet,		/**<globale Parameter*/
												IN	const	mapRoute_T				*mapRoute,			/**<Liste der zu befahrenden Segmente*/
												IN	const	ringId_T				 segmentRingId,		/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
												IN	const	uint8_T					 routeSegment,		/**<Zu kopierendes Segment auf der mapRoute*/
												INOUT		mapPathMemory_T			*mapPathMemory		/**<persistente Pfaddaten*/
												);


/** \brief �bertragen von Speed Limits eines Segments

Die verlinkte Liste der Tempolimits wird beginnend bei `firstSpeedLimitId` durchlaufen und die Tempolimits werden im Ringspeicher `speedLimitRing` gespeichert.
Beim erreichen der maximal erlaubten Api-Aufrufe, wird die Funktion unterbrochen und im n�chsten Takt weitergelesen.

Falls in diesem Takt das letzte kopierte Segment bzgl. Tempolimits nicht vervollst�ndigt werden kann,
wird das `unfinishedSegment` auf die `segmentRingId` gesetzt und der n�chste Index in der verlinkten Liste in `nextSpeedLimit` ausgegeben.

Es werden alle Tempolimits vom Typ `PSD_EHR_SPEED_LIMIT_TYPE_EXPLICIT` gespeichert.
Falls ein unbegrenzter Abschnitt durch den Wert `PSD_EHR_SPEED_LIMIT_VALUE_VALUE_RELEASED`signalisiert wird,
wird ein Eintrag mit dem Wert `rawLimitReleased`(vgl. Modul \ref vehicleObserver) angelegt.

Folgende Speed Limit-Eintr�ge werden aussortiert:
			- ung�ltige Speed Limits (LEGAL, INIT, INVALID, NO_INFO)
			- Limits, die nur f�r LKW gelten 
			- "VZO only"-Limits (parameterabh�ngig: pathRouter.killVZOOnlyLimits)

Folgende Attribute werden f�r jedes Tempolimit aus dem PSD-Baum �bernommen:
WeatherConstraints, LaneConstraints, Zeit-Constraints, Trailer-Constraints, Wechselverkehrszeichen

\note Es k�nnen mehrere gesetzliche Limits an einer Stelle abgelegt sein. Die Analyse, welches Limit g�ltig ist, muss in dieser Funktion
durchgef�hrt werden.

\spec SwMS_Innodrive2_PSD_177
\spec SwMS_Innodrive2_PSD_108
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_152

\ingroup pathRouter_caching
*/
bool_T			 prtCopySpeedLimits(IN	const	parameterSetCtrl_T		*parameterSet,		/**<globale Parameter*/
									IN	const	mapPathMemory_T				*mapPathMemory,				/**<mapPath Speicher*/
									IN	const	psdSpeedLimitId_T			 firstSpeedLimitId,			/**<Kopf der verlinkten Liste der Tempolimts f�r dieses Segment*/
									IN	const	ringId_T					 segmentRingId,				/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									IN	const	uint8_T						 maxSpeedLimitCalls,		/**<Maximal erlaubte Api-Aufrufe*/
									INOUT		mapSpeedLimitRing_T			*speedLimitRing,			/**<Ringspeicher f�r Speedlimits*/
									INOUT		uint8_T						*nSpeedLimitCalls,			/**<Z�hler f�r Aufrufe der PSD-Api*/
									OUT			ringId_T					*endRingId,					/**<R�ckgabe des Endindexes im speedLimitRing*/
									INOUT		ringId_T					*unfinishedSegment,			/**<Eventuelles unvollst�ndiges Segment*/
									OUT			psdSpeedLimitId_T			*nextSpeedLimit  			/**<N�chstes Tempolimit, falls Segment unvollst�ndig*/
									);


/** \brief Durchlaufen und �bertragen der Attributliste eines Segments

Die verlinkte Liste der Attribute wird beginnend bei `firstAttributeId` durchlaufen und die Attribute werden im entsprechenden Ringspeicher gespeichert.
Beim erreichen der maximal erlaubten Api-Aufrufe, wird die Funktion unterbrochen und im n�chsten Takt weitergelesen.
Folgende Attribut-Typen werden �bertragen:
- Verkehrsflussinformationen (Online-Limits)
- zus�tzliche Spuranzahl-Attribute (Abbiegespuren und Gegenverkehrsspuren)
- Steigung
- Traffic Lights
- andere Vorfahrtsregelungen (Stop, Vorfahrt achten, Vorfahrtsstra�e, Spielstra�e, rechts vor links, Kreisverkehr)
- Systemattribute: Geometriequalit�t, L�ndercode und Tempolimiteinheit.
- Stra�ensituationen (Kreisverkehr/kein Kreisverkehr)
- Verkehrsrichtung (Rechtsverkehr / Linksverkehr)
- L�ndercodes

Falls in diesem Takt das letzte kopierte Segment bzgl. Attributen nicht vervollst�ndigt werden kann,
wird das `unfinishedSegment` auf die `segmentRingId` gesetzt und der n�chste Index in der verlinkten Liste in `nextSpeedLimit` ausgegeben.

\spec SwMS_Innodrive2_PSD_177
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_152

\ingroup pathRouter_caching
*/
bool_T			  prtCopyAttributes(IN	const	psdTreeConfiguration_T		*treeConfig,				/**<Skalierung des PSD-Baums */
									IN	const	psdAttributeIndex_T			 firstAttributeId,			/**<Kopf der verlinkten Attributliste f�r dieses Segment*/
									IN	const	ringId_T					 segmentRingId,				/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									IN	const	uint8_T						 maxAttributeCalls,			/**<Maximal pro Zyklus erlaubte Api-Aufrufe*/
									INOUT		mapSegmentRing_T			*segmentRing,				/**<Ringspeicher der Segmente*/
									INOUT		mapSpeedLimitRing_T			*onlineSpeedRing,			/**<Ringspeicher der OnlineSpeeds*/
									INOUT		mapLaneSituationRing_T		*laneSituationRing,			/**<Ringspeicher der Spuranzahlen*/
									INOUT		mapSlopeRing_T				*slopeRing,					/**<Ringspeicher der Steigungen*/
									INOUT		mapRightOfWayRing_T			*rightOfWayRing,			/**<Ringspeicher der Vorfahrtsregelungen*/
									INOUT		mapStreetSituationRing_T	*streetSituationRing,		/**<Ringspeicher der Stra�ensituationen (Kreisverkehr/kein Kreisverkehr)*/
									INOUT		mapTrafficDirectionRing_T	*trafficDirectionRing,		/**<Ringspeicher der Verkehrsrichtungen (Rechtsverkehr / Linksverkehr)*/
									INOUT		mapCountryCodeRing_T		*countryCodeRing,			/**<Ringspeicher der L�ndercodes (Rechtsverkehr / Linksverkehr)*/
									INOUT		mapSpeedLimitUnitRing_T		*speedLimitUnitRing,		/**<Ringspeicher der Tempolimiteinheiten*/
									INOUT		mapQualityGeometryRing_T	*qualityGeometryRing,		/**<Ringspeicher der Geometrieg�te*/
									INOUT		ringId_T					*unfinishedSegment,			/**<Wegen Attributen unvollst�ndig gebliebenes Segment*/
									INOUT		uint8_T						*nAttributeCalls,  			/**<Z�hler der Api-Aufrufe*/
									OUT			psdAttributeIndex_T			*nextAttribute				/**<n�chstes Attribut in der verlinkten Liste*/
									);


/** \brief �bertragen von GPS-Information
	
Die `psdGpsPosition` wird im `gpsRing` gespeichert und dem Segment mit der `segmentRingId` zugeordnet.
Falls bereits eine GPS-Information f�r diese `segmentRingId` abgelegt ist, wird diese �berschrieben.

\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
bool_T					 prtCopyGps(IN	const	psdGpsPosition_T			*psdGpsPosition,		/**<Segment, dessen Werte �bertragen werden*/
									IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									IN	const	uint8_T						 offset,				/**<Abstand vom Segmentanfang*/
									INOUT		mapGpsRing_T				*gpsRing,				/**<Ringspeicher f�r Werte*/
									OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im gpsRing*/
									);


/** \brief Gegenverkehrsspuren �bertragen

Wenn an der Position des `attributes` bereits eine `laneSituation`im `laneSituationRing` eingetragen ist, wird diese durch die
Gegenverkehrs-Spuranzahl in `attribute->value` vervollst�ndigt. Sonst wird ein neuer Eintrag im `laneSituationRing` angelegt,
wobei die �brigen Spuranzahlen vom vorausgehenden Eintrag �bernommen werden.

\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
bool_T		   prtCopyOppositeLanes(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									INOUT		mapLaneSituationRing_T		*laneSituationRing,		/**<Ringspeicher f�r Werte*/
									OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
									);


/** \brief Steigungen �bertragen

Beim �bertragen in den `slopeRing` wird die Steigung `attribute->value` auf den Bereich [PSD_EHR_SLOPE_VALUE_EXCEEDMIN; PSD_EHR_SLOPE_VALUE_EXCEEDMAX] begrenzt.

\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
bool_T				   prtCopySlope(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									INOUT		mapSlopeRing_T				*slopeRing,				/**<Ringspeicher f�r Werte*/
									OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
									);


/**	\brief		Stra�ensituation (Kreisverkehr/kein Kreisverkehr) �bertragen 
\spec SwMS_Innodrive2_PSD_152
\ingroup	pathRouter_caching */
bool_T		 prtCopyStreetSituation(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									INOUT		mapStreetSituationRing_T	*streetSituationRing,	/**<Ringspeicher f�r Werte*/
									OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im streetSituationRing */
									);


/**	\brief		Verkehrsrichtung (Rechtsverkehr/Linksverkehr) �bertragen 
\spec SwMS_Innodrive2_PSD_152
\ingroup	pathRouter_caching */
bool_T		 prtCopyTrafficDirection(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									 IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									 INOUT		mapTrafficDirectionRing_T	*trafficDirectionRing,	/**<Ringspeicher f�r Werte*/
									 OUT		ringId_T					*endRingId				/**<R�ckgabe des Endindexes im trafficDirectionRing */
									 );


/**	\brief		L�ndercode �bertragen 
\spec SwMS_Innodrive2_PSD_152
\ingroup	pathRouter_caching */
bool_T			  prtCopyCountryCode(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									 IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									 INOUT		mapCountryCodeRing_T		*countryCodeRing,	/**<Ringspeicher f�r Werte*/
									 OUT		ringId_T					*endRingId				/**<R�ckgabe des Endindexes im countryCodeRing */
									 );


/**	\brief		Tempolimiteinheit �bertragen 
\spec SwMS_Innodrive2_PSD_152
\ingroup	pathRouter_caching */
bool_T		   prtCopySpeedLimitUnit(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									 IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									 INOUT		mapSpeedLimitUnitRing_T		*speedLimitUnitRing,	/**<Ringspeicher f�r Werte*/
									 OUT		ringId_T					*endRingId				/**<R�ckgabe des Endindexes im speedLimitUnitRing */
									 );

/**	\brief		Geometriequalit�t �bertragen 
\spec SwMS_Innodrive2_PSD_152
\ingroup	pathRouter_caching */
bool_T		  prtCopyQualityGeometry(IN	const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									 IN	const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									 INOUT		mapQualityGeometryRing_T	*qualityGeometryRing,	/**<Ringspeicher f�r Werte*/
									 OUT		ringId_T					*endRingId				/**<R�ckgabe des Endindexes im qualityGeometryRing */
									 );



/** \brief Verkehrsflussinformationen �bertragen

�bertragen werden die Untergrenzen der Geschwindigkeitsbereiche des PSD-Ehr-Attributs TRAFFIC_FLOW_DATA_SPEED.

\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
bool_T			 prtCopyOnlineSpeed(IN const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
									IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
									INOUT		mapSpeedLimitRing_T			*onlineSpeedRing,		/**<Ringspeicher f�r Werte*/
									OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im speedLimitRing*/
									);

#ifdef __cplusplus
}
#endif


#endif
