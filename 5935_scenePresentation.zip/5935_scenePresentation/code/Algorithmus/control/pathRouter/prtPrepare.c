#include "control/pathRouter/prtPrepare.h"
#include "control/pathRouter/prtPrepareStatic.h"
#include "control/pathRouter/prtRouteFilter.h"
#include "control/pathRouter/prtPositionFilter.h"
#include "control/pathRouter/prtHeading.h"
#include "control/pathRouter/prtInfo.h"
#include "control/pathRouter/prtAttributes.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "common/pathRouterCommon/prtTypeMapping.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtPrepare)


bool_T prtContinueMapPath(IN const	parameterSetCtrl_T		*parameterSet,
						  IN const	mapRawVehiclePosition_T	*psdPosition,
						  IN const	mapRoute_T				*mapRoute,
						  IN const	uint8_T					 nSegmentCalls,
						  INOUT		mapPathMemory_T			*mapPathMemory,
						  INOUT		uint8_T					*nSpeedLimitCalls,
						  INOUT		uint8_T					*nAttributeCalls,
						  OUT		bool_T					*mapPathIsComplete
						  )
{
	uint8_T				firstNewRouteSegment = 0u;
	
	/* mapPath und mapRoute abgleichen*/
	diagFF(prtCropMapPath(mapRoute, mapPathMemory,	&firstNewRouteSegment));

	/*Ein eventuell vorhandenes unvollst�ndiges Segment wird zun�chst vervollst�ndigt.*/
	if (mapPathMemory->unfinishedSegment < (ringId_T)mapMAXROUTELENGTH)
	{
		ringId_T const unfinishedSegment = mapPathMemory->unfinishedSegment;
		mapPathMemory->unfinishedSegment = (ringId_T)INVALID_UINT8;

		diagFF(prtIsSegmentOnRoute(mapRoute, mapPathMemory->segmentRing.segment[unfinishedSegment].segmentId, NULL));
		
		/* Falls Attribute oder Tempolimits nicht vollst�ndig gelesen werden k�nnen, 
		wird dies �ber mapPathMemory->unfinishedSegment kommuniziert 
		*/
		diagFF(prtCopyAttributes(	&mapPathMemory->treeConfig,
									mapPathMemory->nextAttribute,
									unfinishedSegment,
									min(parameterSet->pathRouter.maxAttributesPerCycle, (uint8_T)(parameterSet->pathRouter.maxApiCallsPerCycle - nSegmentCalls)),
									&mapPathMemory->segmentRing,
									&mapPathMemory->onlineSpeedRing,
									&mapPathMemory->laneSituationRing,
									&mapPathMemory->slopeRing,
									&mapPathMemory->rightOfWayRing,
									&mapPathMemory->streetSituationRing,
									&mapPathMemory->trafficDirectionRing,
									&mapPathMemory->countryCodeRing,
									&mapPathMemory->speedLimitUnitRing,
									&mapPathMemory->qualityGeometryRing,
									&mapPathMemory->unfinishedSegment,
									nAttributeCalls,
									&mapPathMemory->nextAttribute));
		
		diagFF(prtCopySpeedLimits(  parameterSet,
									mapPathMemory,
									mapPathMemory->nextSpeedLimit,
									unfinishedSegment,
									min(parameterSet->pathRouter.maxSpeedLimitsPerCycle, (uint8_T)(parameterSet->pathRouter.maxApiCallsPerCycle - nSegmentCalls)),
									&mapPathMemory->speedLimitRing,
									nSpeedLimitCalls,
									&mapPathMemory->segmentRing.segment[unfinishedSegment].speedLimitEnd,
									&mapPathMemory->unfinishedSegment,
									&mapPathMemory->nextSpeedLimit));

		if (mapPathMemory->unfinishedSegment == (ringId_T)INVALID_UINT8)
		{
			/* Das Segment ist vollst�ndig. Die mapPathMemory->distance reicht bis zur letzten curvature.*/
			mapPathMemory->distance += mapPathMemory->segmentRing.segment[unfinishedSegment].length;
			mapPathMemory->segmentRing.count = (mapPathMemory->segmentRing.count + 1u);
		}
	}

	if (mapPathMemory->unfinishedSegment == (ringId_T)INVALID_UINT8)
	{
		/*neue Segmente aus Psd-Baum �bertragen. Aus Laufzeitgr�nden werden pro Zyklus eine maximale Anzahl von Attributen �bertragen.*/
		diagFF(prtGetPathFromRoute(	mapRoute,
									parameterSet,
									firstNewRouteSegment,
									nSegmentCalls,
									mapPathMemory,
									nSpeedLimitCalls,
									nAttributeCalls));
	}

	/*Complete-Flag, um im n�chsten Takt zu idlen, falls der Baum und Fahrzeugstatus bis dahin unver�ndert bleiben.*/
	if (	mapPathMemory->segmentRing.count == (ringId_T)mapRoute->segmentCount
		&&	mapPathMemory->unfinishedSegment == (ringId_T)INVALID_UINT8)
	{
		*mapPathIsComplete = true;
	} else {
		*mapPathIsComplete = false;
	}

	/*Gps-Position setzen*/
	diagFF(prtSetGpsPosition(psdPosition, &mapPathMemory->segmentRing, &mapPathMemory->gpsRing));

	return true;
}


static bool_T		prtCropMapPath(		IN const	mapRoute_T					*mapRoute,
										INOUT		mapPathMemory_T				*mapPathMemory,
										OUT			uint8_T						*firstNewRouteSegment)
{
	psdSegmentId_T firstRouteId;
	ringId_T currentSegment;
	ringId_T foundSegment = (ringId_T)INVALID_UINT8;

	/* Startsegment abgleichen (segmentRing durchlaufen, bis das Startsegment der mapRoute gefunden ist).*/
	diagFF(mapRoute->segmentStart < (ringId_T)mapMAXROUTELENGTH);
	firstRouteId = mapRoute->segment[mapRoute->segmentStart].id;
	for (currentSegment = 0; currentSegment < (ringId_T)mapMAXROUTELENGTH; currentSegment++)
	{
		if (	mapPathMemory->segmentRing.segment[(mapPathMemory->segmentRing.start + currentSegment) % (ringId_T)mapMAXROUTELENGTH].segmentId == firstRouteId
			&&	currentSegment < mapPathMemory->segmentRing.count
			&&	foundSegment == (ringId_T)INVALID_UINT8)
		{
			foundSegment = currentSegment;
		}
	}
	if (foundSegment >= mapPathMemory->segmentRing.count  &&  mapPathMemory->segmentRing.count > (ringId_T)0)
	{	
		/*Komplett neue Route*/
		diagFF(prtFreeAtBegin((ringId_T)((mapPathMemory->segmentRing.start + mapPathMemory->segmentRing.count) % (ringId_T)mapMAXROUTELENGTH), mapPathMemory));
		return true;
	}
	else if (foundSegment > 0u && foundSegment < mapPathMemory->segmentRing.count)
	{
		/*Neues Startsegment im segmentRing*/
		diagFF(prtFreeAtBegin((ringId_T)((mapPathMemory->segmentRing.start + foundSegment) % (ringId_T)mapMAXROUTELENGTH), mapPathMemory));
	}
	else 
	{
		/*Startsegment ist bereits gleich*/
	}

	/* End-Segment abgleichen: Beide Segmentlisten parallel bis zum ersten Unterschied durchlaufen.
	Voraussetzung: Startsegment ist jetzt in beiden Segmentlisten gleich.
	*/
	diagFF(mapPathMemory->segmentRing.start < (ringId_T)mapMAXROUTELENGTH);
	diagFF(mapPathMemory->segmentRing.segment[mapPathMemory->segmentRing.start].segmentId == firstRouteId);
	foundSegment = (ringId_T)INVALID_UINT8;
	for (currentSegment = 0;
		currentSegment < (ringId_T)mapMAXROUTELENGTH;
		currentSegment++)
	{
		if((	mapPathMemory->segmentRing.segment[(mapPathMemory->segmentRing.start + currentSegment) % (ringId_T)mapMAXROUTELENGTH].segmentId !=
				mapRoute->segment[(mapRoute->segmentStart + currentSegment) % (ringId_T)mapMAXROUTELENGTH].id
			||	currentSegment == mapRoute->segmentCount)
			&&	foundSegment == (ringId_T)INVALID_UINT8)
		{
			foundSegment = currentSegment;
		}
	}
	if (	foundSegment < mapPathMemory->segmentRing.count
		||	(mapPathMemory->segmentRing.start + foundSegment) % (ringId_T)mapMAXROUTELENGTH == mapPathMemory->unfinishedSegment)
	{
		/*Die letzen Ringsegemente inklusive eines m�glicherweise unvollst�ndigen Segments sind ung�ltig*/
		diagFF(prtDiscardAtEnd((ringId_T)((mapPathMemory->segmentRing.start + foundSegment) % (ringId_T)mapMAXROUTELENGTH), mapPathMemory));
		mapPathMemory->unfinishedSegment = (ringId_T)INVALID_UINT8;
	}
	else
	{
		foundSegment = mapPathMemory->segmentRing.count;
	}

	/*Unfertige Segmente sollen nicht zweimal gelesen werden.*/
	if ((mapPathMemory->segmentRing.start + foundSegment) % (ringId_T)mapMAXROUTELENGTH == mapPathMemory->unfinishedSegment)
	{
		foundSegment++;
	}

	/*Nur die �brigen mapRoute-Segmente sind neu.*/
	*firstNewRouteSegment = foundSegment;
	return true;
}


bool_T		prtFindDistanceOnPath(	IN const	mapSegmentRing_T		*segmentRing,
									IN const	mapRawVehiclePosition_T	*rawPosition,
									IN const	real32_T				 velocity,
									OUT			uint16_T				*distance)
{
	bool_T		isPositionOnPath, continueLoop;
	ringId_T	currentSegment;
	const struct _mapSegmentRing_segment *segment;

	isPositionOnPath	= false;
	*distance = INVALID_UINT16;

	/*Die Laufzeitkonstanz wird zugunsten einer schnelleren Laufzeit aufgegeben. Wenn die abgefragte Position gleich der Fahrzeugposition ist,
	wird dennoch eine relativ konstante Laufzeit erreicht, da die Fahrzeugposition nie weit vom Pfadanfang entfernt ist.*/
	continueLoop = true;
	for (currentSegment = 0; currentSegment < (ringId_T)mapMAXROUTELENGTH  &&  continueLoop; currentSegment++)
	{
		segment = &segmentRing->segment[(segmentRing->start + currentSegment) % (ringId_T)mapMAXROUTELENGTH];

		/*Eintragen der EgoPosition, falls das Referenz-Segment das aktuelle Segment ist.*/
		if (segment->segmentId == rawPosition->segmentId  &&  currentSegment < segmentRing->count)
		{
			real32_T inhibitDistance = velocity * rawPosition->inhibitTime;
			isPositionOnPath = true;
			diagFF(inhibitDistance >= 0.0f);
			diagFF(inhibitDistance < 256.0f);
			diagFF(segment->length >= rawPosition->remainingLength);
			*distance = segment->startDistance + ((uint16_T)segment->length - (uint16_T)rawPosition->remainingLength) + (uint16_T)inhibitDistance; /*lint !e734 (Info -- Loss of precision)*/
			continueLoop = false;
		}
	}

	return isPositionOnPath;
}




bool_T		prtFinalizeMapPath(	IN const	parameterSetCtrl_T		*parameterSet,
								IN const	mapRawVehiclePosition_T	*psdPosition,
								IN const	real32_T				 longPosition,
								IN const	real32_T				 velocity,
								IN const	real32_T				 vobsHeading,
								IN const	uint8_T					 rerouteCount,
								IN const	mapPathMemory_T			*mapPathMemory,
								INOUT		mapHeadingFilter_T		*headingFilter,
								INOUT		mapPositionFilter_T		*positionFilter,
								OUT			mapPath_T				*mapPath)
{
	bool_T		isPositionOnPath, isMapInfoValid;
	uint16_T	newVehicleDistance;

	isPositionOnPath = prtFindDistanceOnPath(&mapPathMemory->segmentRing, psdPosition, velocity, &newVehicleDistance);

	if (!isPositionOnPath)
	{
		/*MapPath ist noch zu kurz.*/
		mapPath->valid = false;
	}
	else if (mapPathMemory->gpsRing.count == (ringId_T)0)
	{
		/*Keine GPS-Info auf dem Pfad*/
		mapPath->valid = false;
	}
	else
	{
		/*Aktualisieren des positionFilters.*/
		diagFF(prtUpdatePosition(parameterSet, &mapPathMemory->segmentRing, psdPosition, longPosition, newVehicleDistance, positionFilter));

		/*Kopieren der persistenten Daten in den fl�chtigen Speicher zur �bergabe an den strategy-Task.*/
		diagFF(prtBuildPathRouterInfo( mapPathMemory,
									  &mapPath->info, 
									  &isMapInfoValid));
		
		/*�berpr�fen, ob auch die gefilterte Position auf dem mapPath liegt.*/
		if (	!isMapInfoValid
			||	positionFilter->vehicleDistance + parameterSet->pathRouter.positionFilter.minKnownDistanceAhead > (real32_T)mapPath->info.distance
			||	positionFilter->vehicleDistance < (real32_T)mapPath->info.gpsInfo.position
			||	positionFilter->vehicleDistance < (real32_T)mapPath->info.speedLimitRing.speedLimit[0].position)
		{
			mapPath->valid = false;
		}
		else
		{
			mapPath->valid = true;
			mapPath->positionZero = longPosition - (real32_T)positionFilter->vehicleDistance;

			/*Heading-Korrektur berechnen.*/
			diagFF(prtFilterHeadingCorrection(parameterSet, mapPath, &mapPathMemory->segmentRing, psdPosition, newVehicleDistance, velocity,  headingFilter));
			mapPath->headingCorrection = headingFilter->correction;

			if(		vobsHeading != INVALID_VALUE 
				&&	fastfabsf(headingFilter->reference - vobsHeading) > parameterSet->pathRouter.positionFilter.headingTolerance)
			{
				diagFF(prtResetPosition(&mapPathMemory->segmentRing, psdPosition, longPosition, newVehicleDistance, positionFilter));
				mapPath->positionZero = longPosition - (real32_T)positionFilter->vehicleDistance;
				
				/*Ist die Fahrzeugposition immer noch auf dem mapPath mit allen ben�tigten Informationen?*/
				diagFF(positionFilter->vehicleDistance >= (real32_T)mapPath->info.gpsInfo.position);
				if (	positionFilter->vehicleDistance + parameterSet->pathRouter.positionFilter.minKnownDistanceAhead > (real32_T)mapPath->info.distance
					||	positionFilter->vehicleDistance < (real32_T)mapPath->info.speedLimitRing.speedLimit[0].position)
				{
					mapPath->valid = false;
				}
			}
			mapPath->positionResetCount = positionFilter->resetCount;
			mapPath->rerouteCount = rerouteCount;
		}
	}

	return true;
}


static bool_T		prtSetGpsPosition(	IN const	mapRawVehiclePosition_T	*psdPosition,
										INOUT		mapSegmentRing_T		*segmentRing,
										INOUT		mapGpsRing_T			*gpsRing)
{
	psdGpsPosition_T psdGpsPosition;
	ringId_T currentSegment;
	ringId_T currentGps, gpsRingEnd;
	


	diagFF(psdwGetGpsData(&psdGpsPosition));
	diagFF(psdGpsPosition.longitude != PSD_EHR_LONGITUDE_VALUE_NO_GPS);


	/*Eintragen der GpsPosition. Bedingung ist h�chstens einmal f�r die mapRoute wahr.*/
	gpsRingEnd = INVALID_UINT8;
	currentGps = 0;
	for (currentSegment = 0; currentSegment < (ringId_T)mapMAXROUTELENGTH; currentSegment++)
	{
		ringId_T ringId = (segmentRing->start + currentSegment) % (ringId_T)mapMAXROUTELENGTH;
		
			/*Eintragen der GpsPosition auf dem psdPosition-Segment, falls sie sich auf den kompletten Baum bezieht.*/
		if ((psdSegmentId_T)PSD_EHR_SEGMENT_ID_COMPLETE_TREE == psdGpsPosition.referenceSegment)
		{
			if (currentSegment < segmentRing->count && segmentRing->segment[ringId].segmentId == psdPosition->segmentId)
			{
				diagFF(segmentRing->segment[ringId].length >= psdPosition->remainingLength);
				diagFF(prtCopyGps( &psdGpsPosition,
									 ringId,
									 (uint8_T)(segmentRing->segment[ringId].length - psdPosition->remainingLength),
									 gpsRing,
									&segmentRing->segment[ringId].gpsRingEnd));
			}
		}
		
			/*Eintragen der GpsPosition, falls das Referenz-Segment das aktuelle Segment ist.*/
		if (segmentRing->segment[ringId].segmentId == psdGpsPosition.referenceSegment)
		{
			/*Eintragen der GpsPosition, falls das Referenz-Segment das aktuelle Segment ist.*/
			if (currentSegment < segmentRing->count)
			{
				diagFF(prtCopyGps(&psdGpsPosition,
									ringId,
									(uint8_T)0u,
								    gpsRing,
								   &segmentRing->segment[ringId].gpsRingEnd));
			}
		}

		/*Sicherstellen der g�ltigen Zuordnung von GPS-Informationen und Segmenten*/
		if (ringId == gpsRing->gpsInfo[(gpsRing->start + currentGps) % (ringId_T)mapPATHGPSCOUNT].segmentRingId)
		{
			if (currentGps < gpsRing->count)
			{
				currentGps++;
				gpsRingEnd = (gpsRing->start + currentGps) % (ringId_T)mapPATHGPSCOUNT;
			}
		}
		if (currentSegment < segmentRing->count)
		{
			segmentRing->segment[ringId].gpsRingEnd = gpsRingEnd;
		}
	}

	return true;
}


void prtInit_mapPathMemory_T(OUT mapPathMemory_T	*mapPathMemory)
{
	uint8_T i;
	mapSystemAttributes_T systemAttributes = mapPathMemory->systemAttributes;
	memset(mapPathMemory, 0, sizeof(mapPathMemory_T));
	mapPathMemory->systemAttributes = systemAttributes;

	for (i = 0; i < (uint8_T)mapPATHSTREETCLASSCOUNT; i++)
	{
		mapPathMemory->rampRing.ramp[i].type = prtRampInit;
	}

	for (i = 0; i < (uint8_T)mapPATHRAMPCOUNT; i++)
	{
		mapPathMemory->streetClassRing.streetClass[i].type = prtStreetClassInit;
	}

	mapPathMemory->unfinishedSegment = (ringId_T)INVALID_UINT8;
}


bool_T	prtCopyRootTreeState(	IN const	parameterSetCtrl_T			*parameterSet,
								IN const	mapRoute_T					*mapRoute,
								OUT			mapPathMemory_T				*mapPathMemory,
								OUT			bool_T						*success)
{
	psdStatus_T psdStatus;
	psdSpeedLimitId_T rootSpeedLimitId;
	psdAttribute_T	rootAttribute;
	ringId_T segmentRingId;
	uint8_T dummySpeedLimitCalls = 0;
	bool_T valid;

	/*Der Path wird neu Aufgebaut. Alle Z�hler und Startpositionen zu Null setzen.*/
	prtInit_mapPathMemory_T(mapPathMemory);	

	/*Nur auf g�ltigem Baum arbeiten*/
	valid = psdwGetQuality(&psdStatus);
	valid = psdStatus == (psdStatus_T)PSD_EHR_STATUS_VALID	&& valid;

	if (!valid)
	{
		*success = false;
	}
	else
	{
		const psdSegment_T *rootSegment = &mapRoute->segment[0u];
		
		diagFF(rootSegment->parentId == (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INIT);

		/* Skalierung des EHR abfragen */
		diagFF(psdwGetTreeConfiguration(&mapPathMemory->treeConfig));

		/*Die Attribute werden dem Anfang des mapPaths zugeordnet.*/
		rootAttribute.offset = 0;
		rootAttribute.nextAttribute = (psdAttributeIndex_T)mapPathMemory->treeConfig.maxAttributes;
		
		/*Geometriequalit�t*/
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_QUALITY_GEOMETRY, &rootAttribute.value));
		mapPathMemory->systemAttributes.qualityGeometry = (uint8_T)rootAttribute.value;

		/*Segment im Ringspeicher anlegen. wegen h�chstgr��e mapMAXROUTELENGTH kann es keinen �berlauf geben*/
		segmentRingId = (mapPathMemory->segmentRing.start + mapPathMemory->segmentRing.count) % (ringId_T)mapMAXROUTELENGTH;

		if (! prtCopySegmentAttributes(	parameterSet,
										mapRoute,
										segmentRingId, 
										0u, 
										mapPathMemory))
		{
			diagReportInfo(diagInfo_prtCopySegment);
			*success = false;
			return true;
		}

		/*Verkehrsrichtung*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_TRAFFIC_DIRECTION;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_TRAFFIC_DIRECTION, &rootAttribute.value));
		diagFF(prtCopyTrafficDirection(	&rootAttribute,
										segmentRingId,
										&mapPathMemory->trafficDirectionRing,
										&mapPathMemory->segmentRing.segment[segmentRingId].trafficDirectionEnd));
		
		/*L�ndercode*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_COUNTRY_CODE;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_COUNTRY_CODE, &rootAttribute.value));
		diagFF(prtCopyCountryCode(	&rootAttribute,
									segmentRingId,
									&mapPathMemory->countryCodeRing,
									&mapPathMemory->segmentRing.segment[segmentRingId].countryCodeEnd));
		
		/*Tempolimiteinheit*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_UNIT_SPEED;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_UNIT_SPEED, &rootAttribute.value));
		diagFF(prtCopySpeedLimitUnit(&rootAttribute,
									  segmentRingId,
									 &mapPathMemory->speedLimitUnitRing,
									 &mapPathMemory->segmentRing.segment[segmentRingId].speedLimitUnitEnd));
		
		/*Geometriequalit�t*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_QUALITY_GEOMETRY;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_SYSTEM_QUALITY_GEOMETRY, &rootAttribute.value));
		diagFF(prtCopyQualityGeometry(&rootAttribute,
									  segmentRingId,
									 &mapPathMemory->qualityGeometryRing,
									 &mapPathMemory->segmentRing.segment[segmentRingId].qualityGeometryEnd));

		/*Steigung*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_EHR_SLOPE;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_EHR_SLOPE, &rootAttribute.value));
		diagFF(prtCopySlope(	&rootAttribute, 
								segmentRingId,
								&mapPathMemory->slopeRing,
								&mapPathMemory->segmentRing.segment[segmentRingId].slopeEnd));

		/*Lane Situation Opposite*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_LANES_OPPOSITE;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_LANES_OPPOSITE, &rootAttribute.value));
		diagFF(prtCopyOppositeLanes(	&rootAttribute,
										segmentRingId,
										&mapPathMemory->laneSituationRing,
										&mapPathMemory->segmentRing.segment[segmentRingId].laneSituationEnd));

		/*Spezielle Stra�ensituationen (f�r uns nur Kreisverkehre)*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_STREET_SITUATION;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_STREET_SITUATION, &rootAttribute.value));
		diagFF(prtCopyStreetSituation(	&rootAttribute,
										segmentRingId,
										&mapPathMemory->streetSituationRing,
										&mapPathMemory->segmentRing.segment[segmentRingId].streetSituationEnd));

		/*Verkehrsfluss ("Online-Limit")*/
		rootAttribute.type = (psdAttributeType_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA;
		diagFF(psdwGetRootTreeStateAttributeValue((psdAttributeType_T)PSD_EHR_ATTRIBUTE_TRAFFIC_FLOW_DATA, &rootAttribute.value));
		diagFF(prtCopyOnlineSpeed(		&rootAttribute,
										segmentRingId,
										&mapPathMemory->onlineSpeedRing,
										&mapPathMemory->segmentRing.segment[segmentRingId].onlineSpeedEnd));

		/*Tempolimit, es wird genau ein Tempolimit �bertragen.*/
		diagFF(psdwGetRootTreeStateSpeedLimitIndex(	(psdSpeedLimitScope_T)PSD_EHR_SPEED_LIMIT_SCOPE_LOCAL, 
													(psdSpeedLimitOrigin_T)PSD_EHR_SPEED_LIMIT_ORIGIN_ANY, 
													&rootSpeedLimitId));

		diagFF(prtCopySpeedLimits(	parameterSet,
									mapPathMemory,
									rootSpeedLimitId,
									segmentRingId,
									(uint8_T)1, /*maxSpeedLimitCalls == 1*/
									&mapPathMemory->speedLimitRing,
									&dummySpeedLimitCalls,
									&mapPathMemory->segmentRing.segment[segmentRingId].speedLimitEnd,
									&mapPathMemory->unfinishedSegment,
									&mapPathMemory->nextSpeedLimit));
		/*Der Offset des Tempolimits Attribute kann ungleich 0 sein. Es soll aber dem Anfang des Baums zugeordnet sein. 
		Darum wird der Offset hier auf Null gesetzt. 
		Wegen dem prtResetMapPathMemory ist das Tempolimit an die Stelle 0 im Ringspeicher geschrieben worden.*/
		mapPathMemory->speedLimitRing.speedLimit[0u].offset = 0u;
		mapPathMemory->unfinishedSegment = segmentRingId;
		mapPathMemory->nextAttribute = rootSegment->attributeIndex;
		if (mapPathMemory->nextSpeedLimit >= mapPathMemory->treeConfig.maxSpeedLimits) {
			mapPathMemory->nextSpeedLimit = rootSegment->speedLimitIndex;
		} else {
			mapPathMemory->nextSpeedLimit = mapPathMemory->nextSpeedLimit;
		}
		
		*success = true;
	}

	return true;
}


static bool_T	prtFreeRingAtBegin(		IN const	ringId_T					 maxCount,
										IN const	ringId_T					 newStart,
										INOUT		ringId_T					*startRingId,
										INOUT		ringId_T					*attributeCount)
{
	ringId_T countDeleted, start, count;

	start = *startRingId;
	count = *attributeCount;

	countDeleted = (newStart + maxCount - start) % maxCount;
	diagFF(countDeleted <= count);
	start = newStart;
	count -= countDeleted;

	*startRingId = start;
	*attributeCount = count;

	return true;
}


static bool_T	prtKeepFirstAttribute(	IN const	ringId_T					 maxCount,
										IN const	ringId_T					 newStartPlusOne,
										INOUT		ringId_T					*startRingId,
										INOUT		ringId_T					*attributeCount)
{
	ringId_T countDeleted, start, count;

	start = *startRingId;
	count = *attributeCount;

	diagFF(count > 0u);
	countDeleted = ((newStartPlusOne - 1u) + maxCount - start) % maxCount;
	diagFF(countDeleted < count);
	start = (newStartPlusOne == 0u) ? (maxCount - 1u) : newStartPlusOne - 1u;
	count -= countDeleted;

	diagFF(start < maxCount);
	diagFF(count <= maxCount);
	*startRingId = start;
	*attributeCount = count;

	return true;
}


static bool_T	prtFreeAtBegin(			IN const	ringId_T					 newFirstRingId,
										INOUT		mapPathMemory_T				*mapPathMemory)
{
	ringId_T index, ringId, countDeleted;
	uint16_T distance = 0u;
	const struct _mapSegmentRing_segment *lastSegment = &mapPathMemory->segmentRing.segment[newFirstRingId == 0u ? (ringId_T)mapMAXROUTELENGTH - 1u : newFirstRingId - 1u];

	/*Speicher in den Attribut-Ringen freigeben*/
	
	if (lastSegment->gpsRingEnd != (ringId_T)INVALID_UINT8)
	{
		countDeleted = (lastSegment->gpsRingEnd + (ringId_T)mapPATHGPSCOUNT - mapPathMemory->gpsRing.start) % (ringId_T)mapPATHGPSCOUNT;
		diagFF(countDeleted <= mapPathMemory->gpsRing.count);
		mapPathMemory->gpsRing.start = lastSegment->gpsRingEnd;
		mapPathMemory->gpsRing.count -= countDeleted;
	}

	diagFF(prtFreeRingAtBegin( (ringId_T)mapPATHBRANCHANGLECOUNT,
							   lastSegment->branchAngleEnd,
							  &mapPathMemory->branchAngleRing.start,
							  &mapPathMemory->branchAngleRing.count));

	diagFF(prtFreeRingAtBegin( (ringId_T)mapPATHCURVATURECOUNT,
							   lastSegment->curvatureEnd,
							  &mapPathMemory->curvatureRing.start,
							  &mapPathMemory->curvatureRing.count));

	diagFF(prtFreeRingAtBegin( (ringId_T)mapPATHDYNAMICEVENTCOUNT,
							   lastSegment->dynamicEventEnd,
							  &mapPathMemory->dynamicEventRing.start,
							  &mapPathMemory->dynamicEventRing.count));

	diagFF(prtFreeRingAtBegin( (ringId_T)mapPATHRIGHTOFWAYCOUNT,
							   lastSegment->rightOfWayEnd,
							  &mapPathMemory->rightOfWayRing.start,
							  &mapPathMemory->rightOfWayRing.count));

	/* F�r Streckenattribute: streetClass, streetSituation, trafficDirection, countryCode, speedLimitUnit, qualityGeometry, ramp, builtUp, laneSituation, slope, speedLimit und onlineLimit das letztg�ltige Element beibehalten 
		und dem Segmentanfang des neuen ersten Segments zuordnen. 
		Anmerkung: Von diesen Attributen muss es immer mindestens eins geben!
	*/
	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHSTREETCLASSCOUNT, 
								  lastSegment->streetClassEnd,
								 &mapPathMemory->streetClassRing.start,
								 &mapPathMemory->streetClassRing.count));
	mapPathMemory->streetClassRing.streetClass[mapPathMemory->streetClassRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->streetClassRing.streetClass[mapPathMemory->streetClassRing.start].offset = 0u;


	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHRAMPCOUNT, 
								  lastSegment->rampEnd,
								 &mapPathMemory->rampRing.start,
								 &mapPathMemory->rampRing.count));
	mapPathMemory->rampRing.ramp[mapPathMemory->rampRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->rampRing.ramp[mapPathMemory->rampRing.start].offset = 0u;

	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHSTREETSITUATIONCOUNT, 
								  lastSegment->streetSituationEnd,
								 &mapPathMemory->streetSituationRing.start,
								 &mapPathMemory->streetSituationRing.count));
	mapPathMemory->streetSituationRing.streetSituation[mapPathMemory->streetSituationRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->streetSituationRing.streetSituation[mapPathMemory->streetSituationRing.start].offset = 0u;

	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT, 
								  lastSegment->trafficDirectionEnd,
								 &mapPathMemory->trafficDirectionRing.start,
								 &mapPathMemory->trafficDirectionRing.count));
	mapPathMemory->trafficDirectionRing.trafficDirection[mapPathMemory->trafficDirectionRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->trafficDirectionRing.trafficDirection[mapPathMemory->trafficDirectionRing.start].offset = 0u;
	
	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHCOUNTRYCODECOUNT, 
								  lastSegment->countryCodeEnd,
								 &mapPathMemory->countryCodeRing.start,
								 &mapPathMemory->countryCodeRing.count));
	mapPathMemory->countryCodeRing.countryCode[mapPathMemory->countryCodeRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->countryCodeRing.countryCode[mapPathMemory->countryCodeRing.start].offset = 0u;
	
	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHSPEEDLIMITUNITCOUNT, 
								  lastSegment->speedLimitUnitEnd,
								 &mapPathMemory->speedLimitUnitRing.start,
								 &mapPathMemory->speedLimitUnitRing.count));
	mapPathMemory->speedLimitUnitRing.speedLimitUnit[mapPathMemory->speedLimitUnitRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->speedLimitUnitRing.speedLimitUnit[mapPathMemory->speedLimitUnitRing.start].offset = 0u;
	
	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHQUALITYGEOMETRYCOUNT, 
								  lastSegment->qualityGeometryEnd,
								 &mapPathMemory->qualityGeometryRing.start,
								 &mapPathMemory->qualityGeometryRing.count));
	mapPathMemory->qualityGeometryRing.qualityGeometry[mapPathMemory->qualityGeometryRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->qualityGeometryRing.qualityGeometry[mapPathMemory->qualityGeometryRing.start].offset = 0u;

	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHBUILTUPAREACOUNT, 
								  lastSegment->builtUpAreaEnd,
								 &mapPathMemory->builtUpRing.start,
								 &mapPathMemory->builtUpRing.count));
	mapPathMemory->builtUpRing.builtUpArea[mapPathMemory->builtUpRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->builtUpRing.builtUpArea[mapPathMemory->builtUpRing.start].offset = 0u;

	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHLANESITUATIONCOUNT, 
								  lastSegment->laneSituationEnd,
								 &mapPathMemory->laneSituationRing.start,
								 &mapPathMemory->laneSituationRing.count));
	mapPathMemory->laneSituationRing.laneSituation[mapPathMemory->laneSituationRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->laneSituationRing.laneSituation[mapPathMemory->laneSituationRing.start].offset = 0u;

	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHSLOPECOUNT, 
								  lastSegment->slopeEnd,
								 &mapPathMemory->slopeRing.start,
								 &mapPathMemory->slopeRing.count));
	mapPathMemory->slopeRing.slope[mapPathMemory->slopeRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->slopeRing.slope[mapPathMemory->slopeRing.start].offset = 0u;

	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHSPEEDLIMITCOUNT, 
								  lastSegment->speedLimitEnd,
								 &mapPathMemory->speedLimitRing.start,
								 &mapPathMemory->speedLimitRing.count));
	mapPathMemory->speedLimitRing.speedLimit[mapPathMemory->speedLimitRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->speedLimitRing.speedLimit[mapPathMemory->speedLimitRing.start].offset = 0u;
	
	diagFF(prtKeepFirstAttribute( (ringId_T)mapPATHONLINESPEEDCOUNT, 
									lastSegment->onlineSpeedEnd,
									&mapPathMemory->onlineSpeedRing.start,
									&mapPathMemory->onlineSpeedRing.count));
	mapPathMemory->onlineSpeedRing.speedLimit[mapPathMemory->onlineSpeedRing.start].segmentRingId = newFirstRingId;
	mapPathMemory->onlineSpeedRing.speedLimit[mapPathMemory->onlineSpeedRing.start].offset = 0u;
	
	/*Speicher im segmentRing Freigeben*/
	countDeleted = (newFirstRingId + (ringId_T)mapMAXROUTELENGTH - mapPathMemory->segmentRing.start) % (ringId_T)mapMAXROUTELENGTH;
	diagFF(countDeleted <= mapPathMemory->segmentRing.count);
	mapPathMemory->segmentRing.start = newFirstRingId;
	mapPathMemory->segmentRing.count -= countDeleted;

	/*Distanzen neu aufsummieren*/
	for (index = 0; index < (ringId_T)mapMAXROUTELENGTH; index++)
	{
		ringId = (mapPathMemory->segmentRing.start + index) % (ringId_T)mapMAXROUTELENGTH;
		mapPathMemory->segmentRing.segment[ringId].startDistance = distance;
		distance += (uint16_T)mapPathMemory->segmentRing.segment[ringId].length;
	}
	if (mapPathMemory->segmentRing.count == (ringId_T)mapMAXROUTELENGTH)
	{
		mapPathMemory->distance = distance;
	} else {
		mapPathMemory->distance = mapPathMemory->segmentRing.segment[(mapPathMemory->segmentRing.start + mapPathMemory->segmentRing.count) % (ringId_T)mapMAXROUTELENGTH].startDistance;
	}

	return true;
}


static void			prtDiscardFromRing(	IN const	ringId_T					 maxCount,
										IN const	ringId_T					 start,
										IN const	ringId_T					 startSegmentRingId,
										IN const	ringId_T					 firstDeletedRingId,
										IN const	ringId_T					 newEnd,
										INOUT		ringId_T					*attributeCount)
{
	const ringId_T newCount = (newEnd + maxCount - start) % maxCount;
	
	if ((newEnd == maxCount || newEnd == start)  &&  startSegmentRingId != firstDeletedRingId  &&  *attributeCount == maxCount)
	{
		*attributeCount = maxCount;
	} else {
		*attributeCount = newCount;
	}	
}


static bool_T	prtDiscardAtEnd(IN const	ringId_T					 firstDeletedRingId,
								INOUT		mapPathMemory_T				*mapPathMemory)
{
	const struct _mapSegmentRing_segment *lastSegment = &mapPathMemory->segmentRing.segment[firstDeletedRingId == 0u ? (ringId_T)mapMAXROUTELENGTH - 1u : firstDeletedRingId - 1u];

	/*Die Funktion soll nicht aufgerufen werden, wenn die komplette Route sich ge�ndert hat.*/
	diagFF(firstDeletedRingId != mapPathMemory->segmentRing.start);

	mapPathMemory->segmentRing.count = (firstDeletedRingId + (ringId_T)mapMAXROUTELENGTH - mapPathMemory->segmentRing.start) % (ringId_T)mapMAXROUTELENGTH;


	if (lastSegment->gpsRingEnd != (ringId_T)INVALID_UINT8)
	{
		diagFF(mapPathMemory->gpsRing.start < (ringId_T)mapPATHGPSCOUNT);
		mapPathMemory->gpsRing.count			= (lastSegment->gpsRingEnd		+ (ringId_T)mapPATHGPSCOUNT			- mapPathMemory->gpsRing.start)				% (ringId_T)mapPATHGPSCOUNT;
		prtDiscardFromRing(	(ringId_T)mapPATHGPSCOUNT, 
						mapPathMemory->gpsRing.start, 
						mapPathMemory->gpsRing.gpsInfo[mapPathMemory->gpsRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->gpsRingEnd,
						&mapPathMemory->gpsRing.count);
	} else {
		memset(&mapPathMemory->gpsRing, 0, sizeof(mapGpsRing_T));
	}
	
	diagFF(mapPathMemory->branchAngleRing.start < (ringId_T)mapPATHBRANCHANGLECOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHBRANCHANGLECOUNT, 
						mapPathMemory->branchAngleRing.start, 
						mapPathMemory->branchAngleRing.branchAngle[mapPathMemory->branchAngleRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->branchAngleEnd,
						&mapPathMemory->branchAngleRing.count);
	
	diagFF(mapPathMemory->builtUpRing.start < (ringId_T)mapPATHBUILTUPAREACOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHBUILTUPAREACOUNT, 
						mapPathMemory->builtUpRing.start, 
						mapPathMemory->builtUpRing.builtUpArea[mapPathMemory->builtUpRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->builtUpAreaEnd,
						&mapPathMemory->builtUpRing.count);
	diagFF(mapPathMemory->builtUpRing.count > 0u);

	diagFF(mapPathMemory->curvatureRing.start < (ringId_T)mapPATHCURVATURECOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHCURVATURECOUNT, 
						mapPathMemory->curvatureRing.start, 
						mapPathMemory->curvatureRing.curvature[mapPathMemory->curvatureRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->curvatureEnd,
						&mapPathMemory->curvatureRing.count);
	diagFF(mapPathMemory->curvatureRing.count > 0u);

	diagFF(mapPathMemory->laneSituationRing.start < (ringId_T)mapPATHLANESITUATIONCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHLANESITUATIONCOUNT, 
						mapPathMemory->laneSituationRing.start, 
						mapPathMemory->laneSituationRing.laneSituation[mapPathMemory->laneSituationRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->laneSituationEnd,
						&mapPathMemory->laneSituationRing.count);
	diagFF(mapPathMemory->laneSituationRing.count > 0u);

	diagFF(mapPathMemory->dynamicEventRing.start <(ringId_T) mapPATHDYNAMICEVENTCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHDYNAMICEVENTCOUNT, 
						mapPathMemory->dynamicEventRing.start, 
						mapPathMemory->dynamicEventRing.dynamicEvent[mapPathMemory->dynamicEventRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->dynamicEventEnd,
						&mapPathMemory->dynamicEventRing.count);

	diagFF(mapPathMemory->slopeRing.start < (ringId_T)mapPATHSLOPECOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHSLOPECOUNT, 
						mapPathMemory->slopeRing.start, 
						mapPathMemory->slopeRing.slope[mapPathMemory->slopeRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->slopeEnd,
						&mapPathMemory->slopeRing.count);


	diagFF(mapPathMemory->speedLimitRing.start < (ringId_T)mapPATHSPEEDLIMITCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHSPEEDLIMITCOUNT, 
						mapPathMemory->speedLimitRing.start, 
						mapPathMemory->speedLimitRing.speedLimit[mapPathMemory->speedLimitRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->speedLimitEnd,
						&mapPathMemory->speedLimitRing.count);
	diagFF(mapPathMemory->speedLimitRing.count > 0u);
	
	diagFF(mapPathMemory->onlineSpeedRing.start < (ringId_T)mapPATHONLINESPEEDCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHONLINESPEEDCOUNT, 
						mapPathMemory->onlineSpeedRing.start, 
						mapPathMemory->onlineSpeedRing.speedLimit[mapPathMemory->onlineSpeedRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->onlineSpeedEnd,
						&mapPathMemory->onlineSpeedRing.count);
	diagFF(mapPathMemory->onlineSpeedRing.count > 0u);

	diagFF(mapPathMemory->streetClassRing.start < (ringId_T)mapPATHSTREETCLASSCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHSTREETCLASSCOUNT, 
						mapPathMemory->streetClassRing.start, 
						mapPathMemory->streetClassRing.streetClass[mapPathMemory->streetClassRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->streetClassEnd,
						&mapPathMemory->streetClassRing.count);
	diagFF(mapPathMemory->streetClassRing.count > 0u);

	diagFF(mapPathMemory->rampRing.start < (ringId_T)mapPATHRAMPCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHRAMPCOUNT, 
						mapPathMemory->rampRing.start, 
						mapPathMemory->rampRing.ramp[mapPathMemory->rampRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->rampEnd,
						&mapPathMemory->rampRing.count);
	diagFF(mapPathMemory->rampRing.count > 0u);
	
	diagFF(mapPathMemory->rightOfWayRing.start < (ringId_T)mapPATHRIGHTOFWAYCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHRIGHTOFWAYCOUNT, 
						mapPathMemory->rightOfWayRing.start, 
						mapPathMemory->rightOfWayRing.rightOfWayControl[mapPathMemory->rightOfWayRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->rightOfWayEnd,
						&mapPathMemory->rightOfWayRing.count);

	diagFF(mapPathMemory->streetSituationRing.start < (ringId_T)mapPATHSTREETSITUATIONCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHSTREETSITUATIONCOUNT, 
						mapPathMemory->streetSituationRing.start, 
						mapPathMemory->streetSituationRing.streetSituation[mapPathMemory->streetSituationRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->streetSituationEnd,
						&mapPathMemory->streetSituationRing.count);
	diagFF(mapPathMemory->streetSituationRing.count > 0u);
	
	diagFF(mapPathMemory->trafficDirectionRing.start < (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHTRAFFICDIRECTIONCOUNT, 
						mapPathMemory->trafficDirectionRing.start, 
						mapPathMemory->trafficDirectionRing.trafficDirection[mapPathMemory->trafficDirectionRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->trafficDirectionEnd,
						&mapPathMemory->trafficDirectionRing.count);
	diagFF(mapPathMemory->trafficDirectionRing.count > 0u);

	diagFF(mapPathMemory->countryCodeRing.start < (ringId_T)mapPATHCOUNTRYCODECOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHCOUNTRYCODECOUNT, 
						mapPathMemory->countryCodeRing.start, 
						mapPathMemory->countryCodeRing.countryCode[mapPathMemory->countryCodeRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->countryCodeEnd,
						&mapPathMemory->countryCodeRing.count);
	diagFF(mapPathMemory->countryCodeRing.count > 0u);

	diagFF(mapPathMemory->speedLimitUnitRing.start < (ringId_T)mapPATHSPEEDLIMITUNITCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHSPEEDLIMITUNITCOUNT, 
						mapPathMemory->speedLimitUnitRing.start, 
						mapPathMemory->speedLimitUnitRing.speedLimitUnit[mapPathMemory->speedLimitUnitRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->speedLimitUnitEnd,
						&mapPathMemory->speedLimitUnitRing.count);
	diagFF(mapPathMemory->speedLimitUnitRing.count > 0u);
	
	diagFF(mapPathMemory->qualityGeometryRing.start < (ringId_T)mapPATHQUALITYGEOMETRYCOUNT);
	prtDiscardFromRing(	(ringId_T)mapPATHQUALITYGEOMETRYCOUNT, 
						mapPathMemory->qualityGeometryRing.start, 
						mapPathMemory->qualityGeometryRing.qualityGeometry[mapPathMemory->qualityGeometryRing.start].segmentRingId,
						firstDeletedRingId,
						lastSegment->qualityGeometryEnd,
						&mapPathMemory->qualityGeometryRing.count);
	diagFF(mapPathMemory->qualityGeometryRing.count > 0u);

	diagFF(firstDeletedRingId < (ringId_T)mapMAXROUTELENGTH);
	mapPathMemory->distance = mapPathMemory->segmentRing.segment[firstDeletedRingId].startDistance;

	return true;
}


static bool_T prtGetCurrentTrafficDirection(IN const	mapPathMemory_T				*mapPathMemory,
											IN const	real32_T					 position,
											OUT			vobsTrafficDir_T			*trafficDirection)
{
	uint8_T index;
	uint16_T currentPosition;
	trafficDirection_T currentDirection;

	*trafficDirection = trafficDirUnknown;
	for (index = 0u; index < (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT; index++)
	{
		ringId_T ringId = (mapPathMemory->trafficDirectionRing.start + index) % (ringId_T)mapPATHTRAFFICDIRECTIONCOUNT;
		currentDirection = mapPathMemory->trafficDirectionRing.trafficDirection[ringId];
		diagFF(prtPositionToUint16(&mapPathMemory->segmentRing, currentDirection.segmentRingId, currentDirection.offset, &currentPosition));
		if (	position >= mapPathMemory->positionZero + (real32_T)currentPosition
			&&	index < mapPathMemory->trafficDirectionRing.count)
		{
			*trafficDirection = currentDirection.trafficDirection;
		} else {
			currentDirection.trafficDirection = *trafficDirection;
		}
	}

	return true;
}


static bool_T	   prtGetCurrentCountryCode(IN const	mapPathMemory_T				*mapPathMemory,
											IN const	real32_T					 position,
											OUT			psdCountryCode_T			*countryCode)
{
	uint8_T index;
	uint16_T currentPosition;
	countryCode_T currentCode;

	*countryCode = 0u;
	for (index = 0u; index < (ringId_T)mapPATHCOUNTRYCODECOUNT; index++)
	{
		ringId_T ringId = (mapPathMemory->countryCodeRing.start + index) % (ringId_T)mapPATHCOUNTRYCODECOUNT;
		currentCode = mapPathMemory->countryCodeRing.countryCode[ringId];
		diagFF(prtPositionToUint16(&mapPathMemory->segmentRing, currentCode.segmentRingId, currentCode.offset, &currentPosition));
		if (	position >= mapPathMemory->positionZero + (real32_T)currentPosition
			&&	index < mapPathMemory->countryCodeRing.count)
		{
			*countryCode = currentCode.countryCode;
		} else {
			currentCode.countryCode = *countryCode;
		}
	}

	return true;
}



bool_T			prtGetCurrentSpeedLimitUnit(IN const	mapPathMemory_T				*mapPathMemory,
											IN const	real32_T					 position,
											OUT			psdSpeedLimitUnit_T			*speedLimitUnit)
{
	uint8_T index;
	uint16_T currentPosition;
	speedLimitUnit_T currentUnit;
	
	*speedLimitUnit = (psdSpeedLimitUnit_T)prtSpeedLimitUnitKMH;
	for (index = 0u; index < (ringId_T)mapPATHSPEEDLIMITUNITCOUNT; index++)
	{
		ringId_T ringId = (mapPathMemory->speedLimitUnitRing.start + index) % (ringId_T)mapPATHSPEEDLIMITUNITCOUNT;
		currentUnit = mapPathMemory->speedLimitUnitRing.speedLimitUnit[ringId];
		diagFF(prtPositionToUint16(&mapPathMemory->segmentRing, currentUnit.segmentRingId, currentUnit.offset, &currentPosition));
		if (	position >= mapPathMemory->positionZero + (real32_T)currentPosition
			&&	index < mapPathMemory->speedLimitUnitRing.count)
		{
			*speedLimitUnit = currentUnit.speedLimitUnit;
		} else {
			currentUnit.speedLimitUnit = *speedLimitUnit;
		}
	}

	return true;
}


static bool_T  prtGetCurrentQualityGeometry(IN const	mapPathMemory_T				*mapPathMemory,
											IN const	real32_T					 position,
											OUT			uint8_T						*qualityGeometry)
{
	uint8_T index;
	uint16_T currentPosition;
	qualityGeometry_T currentQuality;

	*qualityGeometry = 0u;
	for (index = 0u; index < (ringId_T)mapPATHQUALITYGEOMETRYCOUNT; index++)
	{
		ringId_T ringId = (mapPathMemory->qualityGeometryRing.start + index) % (ringId_T)mapPATHQUALITYGEOMETRYCOUNT;
		currentQuality = mapPathMemory->qualityGeometryRing.qualityGeometry[ringId];
		diagFF(prtPositionToUint16(&mapPathMemory->segmentRing, currentQuality.segmentRingId, currentQuality.offset, &currentPosition));
		if (	position >= mapPathMemory->positionZero + (real32_T)currentPosition
			&&	index < mapPathMemory->qualityGeometryRing.count)
		{
			*qualityGeometry = currentQuality.qualityGeometry;
		} else {
			currentQuality.qualityGeometry = *qualityGeometry;
		}
	}

	return true;
}


bool_T		   prtGetSystemAttributes(IN const	mapPathMemory_T				*mapPathMemory,
									  IN const	real32_T					 longPosition,
									  INOUT		mapSystemAttributes_T		*systemAttributes)
{
	psdCountryCode_T countryCode;
	psdSpeedLimitUnit_T speedLimitUnit;
	uint8_T qualityGeometry;
	vobsTrafficDir_T trafficDirection;
			
	diagFF(prtGetCurrentCountryCode( mapPathMemory,
									 longPosition,
									&countryCode));
	if (countryCode != (psdCountryCode_T)PSD_EHR_ATTRIBUTE_SYSTEM_COUNTRY_CODE_NO_INFORMATION)
	{
		systemAttributes->countryCode = countryCode;
	}

	diagFF(prtGetCurrentSpeedLimitUnit( mapPathMemory,
										longPosition,
										&speedLimitUnit));
	systemAttributes->speedLimitUnit = speedLimitUnit;
		
	diagFF(prtGetCurrentQualityGeometry( mapPathMemory,
										    longPosition,
										&qualityGeometry));
	systemAttributes->qualityGeometry = qualityGeometry;


	diagFF(prtGetCurrentTrafficDirection( mapPathMemory,
										  longPosition,
										 &trafficDirection));
	if (trafficDirection != trafficDirUnknown)
	{
		systemAttributes->trafficDirection = (uint8_T)trafficDirection;
	}

	return true;	
}
