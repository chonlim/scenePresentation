#ifndef guard_prtPositionFilter_h
#define guard_prtPositionFilter_h

#include "pathRouter.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"

/** \brief Filtern von ahrzeugposition und Korrektur

Auf die `positionFilter->vehicleDistance` vom Anfang des `mapPath` wird die �nderung von 
`longPosition` gegen�ber dem vorherigen Zeitschritt (positionFilter->longPosition) vorgeschoben.
Es wird ein parametrierbarer Bruchteil der `correction` dazuaddiert. Die `correction`wird um den gleichen Betrag verringert.
Die `correction` wird bei einer aktualisierten Kartenposition `rawPosition` neu initialisiert auf die Differenz `newDistance - distance`.
�berschreitet die Korrektur eine parametrierbare Toleranz, wird die Flag `reset = true` gesetzt.
Es gilt `positionZero + vehicleDistance == longPosition`

\spec SwMS_Innodrive2_PSD_157

\ingroup pathRouter_caching
*/
static bool_T		prtPositionCorrection(	IN const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
											IN const	mapPositionFilter_T		*positionFilter,	/**<Filter der Fahrzeugposition*/
											IN const	mapSegmentRing_T		*segmentRing,		/**<Speicher der Pfad-Segmente*/
											IN const	mapRawVehiclePosition_T	*rawPosition,		/**<Segment-Id und Offset*/
											IN const	real32_T				 longPosition,		/**<Monoton Steigende Position vom vehicleObserver*/
											IN const	real32_T				 newDistance,		/**<Abstand der `rawPosition` vom Pfadanfang*/
											OUT			real32_T				*correction,		/**<Update der positionFilter->vehDistCorrection*/
											OUT			real32_T				*distance,			/**<Update der positionFilter->vehicleDistance*/
											OUT			bool_T					*reset				/**<Falg: positionFilter muss zur�ckgesetzt werden.*/
											);
#endif
