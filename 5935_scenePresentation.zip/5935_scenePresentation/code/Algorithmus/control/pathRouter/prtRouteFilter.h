#ifndef guard_prtPathFilter_h
#define guard_prtPathFilter_h

#include "pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"

bool_T				 prtRouteUpdate(INOUT		mapInitFlag_T				*initFlag,
									INOUT		mapRouteMemory_T			*mapRouteMemory,
									INOUT		uint8_T						*nSegmentCalls,
									IN	const	mapRawVehiclePosition_T		*psdPosition,
									IN	const	real32_T					 positionZero,
									IN	const	turnSignal_T				 turnSignal,
									IN	const	bool_T						 turnSignalConfident,
									IN  const	real32_T					 turnPosition,
									OUT			bool_T						*ageReset
											);


/** \brief Gibt `true` zur�ck, wenn das Segment mit dem Index `segmentId` auf der mapRoute liegt.
Die Optionale Ausgabevariable `segmentOffset` wird so gew�hlt, dass
`mapRoute->segment[(mapRoute->segmentStart + i) % mapMAXROUTELENGTH].id == segmentId`
gilt.
\ingroup pathRouter_routing
*/
bool_T			prtIsSegmentOnRoute(IN const	mapRoute_T					*mapRoute,			/**<Array der zu befahrenden Segmente*/
									IN const	psdSegmentId_T				 segmentId, 		/**<Index des Segments im PSD-Baum*/
									OUT OPT		uint8_T						*segmentOffset  	/**<Index des Segments in der mapRoute gez�hlt von mapRoute->segmentStart*/
										);


#endif
