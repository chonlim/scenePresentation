#ifndef guard_prtTurnFilter_h
#define guard_prtTurnFilter_h

/**\brief Im pathRouter soll die (virtuelle) Position des Fahrzeugs entlang der berechneten mapRoute bewegt werden

Wenn die von PSD gemeldete Position die mapRoute verlassen hat, wird die virtuelle Position auf der aktuellen mapRoute weiterbewegt um die Wegstrecke egoVelocity * controlCycleTime

Wenn sich die von PSD gemeldete Position (rawPosition) auf der mapRoute befindet (Segment-ID), wird der Filter kontinuierlich zur�ckgesetzt (turnFilter.psdPosition = rawPosition).

Wenn sich die virtualPosition nicht mehr auf einem g�ltigen PSD-Segment befindet, wird der Filter zur�ckgesetzt.

Wenn (virtualPosition != rawPosition) werden eine holdDistance, holdHeadDeviation und holdTicks berechnet. 
Abh�ngig von vehicleObserver.turnSignal.extendHold gelten hier entweder controlSet.pathRouter.turnFilter.normalDistance [50 m], �normalHeadDeviation [250 m�] und �normalTicks [3 s] oder 
�extendedDistance [200 m], �extendedHeadDeviation [1000 m�] oder �extendedTicks [10 s].
Der Filter wird zur�ckgesetzt (virtualPosition = rawPosition), wenn eine dieser Gr��en einen Maximalwert �berschreitet. 

\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_132

\ingroup pathRouter_routing
*/
bool_T		  prtUpdateTurnFilter(	INOUT		mapTurnFilter_T		*turnFilter,	/**<Filterstruktur*/
									IN	const	mapRoute_T			*mapRoute,		/**<Pr�dizierte Route auf dem PSD-Baum*/
									IN	const	real32_T			 pathHeading,	/**<Ausrichtung des Pfades an der Fahrzeugposition*/
									IN	const	real32_T			 egoVelocity,	/**<Fahrzeuggeschwindigkeit*/
									IN	const	real32_T			 egoHeading,	/**<Ausrichtung des Fahrzeugs*/
									IN	const	bool_T				 headValid,		/**<G�ltigkeit der pathHeading*/
									IN	const	bool_T				 extendHold		/**<Blinkeraktion im vehicleObserver w�hrend der letzten x Rechentakte*/
									);


/**\brief Schiebt die `turnFilter.virtualPosition` auf der `mapRoute`nach vorne.

Inkrementiert die Entprellz�hler (holdHeadingDeviation, holdDistance, holdTicks)
Wenn das n�chste Segment auf der `mapRoute` erreicht ist: `holdDistance - segmentStartRef` >= `virtualPosition.remainingLength`
setzt die Funktion die `virtualPosition` auf das n�chste Segment in der mapRoute und z�hlt die `remainingLength`auf dem alten Segment
zur `segmentStartRef` hinzu.
\spec SwMS_Innodrive2_PSD_134
\ingroup pathRouter_routing
*/
bool_T			prtIncrementTurnFilter(	INOUT		mapTurnFilter_T		*turnFilter,
										IN	const	mapRoute_T			*mapRoute,
										IN	const	real32_T			 pathHeading,
										IN	const	real32_T			 egoVelocity,
										IN	const	real32_T			 egoHeading,
										IN	const	bool_T				 headValid
										);

#endif
