#include "control/pathRouter/pathRouter.h"
#include "control/pathRouter/pathRouterStatic.h"
#include "control/pathRouter/prtTurnFilter.h"
#include "control/pathRouter/prtRouteFilter.h"
#include "control/pathRouter/prtPrepare.h"
#include "control/pathRouter/prtHold.h"
#include "control/pathRouter/prtHeading.h"
#include "control/pathRouter/prtAge.h"
#include "control/pathRouter/prtLoopBack.h"

#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "control/psdWrapper/psdWrapper.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_pathRouter)


void				 pathRouter(IN	const	vehicleState_T		*vehicleState,
								INOUT		pathRouterMemory_T	*pathRouterMemory,
								OUT			mapPathInfo_T		*vobsMapPathInfo,
								OUT			mapPath_T			*mapPath)
{
	if (!prtStep(vehicleState, pathRouterMemory, vobsMapPathInfo, mapPath))
	{
		memset(pathRouterMemory, 0, sizeof(pathRouterMemory_T));
		memset(mapPath, 0, sizeof(mapPath_T));
		vobsSetMapPathInfo(false, signUnitUnknown, trafficDirUnknown, 0.0f, 0.0f, 0, vobsMapPathInfo);
	}
}




static bool_T				 prtStep(	IN	const	vehicleState_T		*vehicleState,
										INOUT		pathRouterMemory_T	*pathRouterMemory,
										OUT			mapPathInfo_T		*vobsMapPathInfo,
										OUT			mapPath_T			*mapPath)
{
	bool_T					turnSignalConfident, turnSignalExtendHold;
	real32_T				longPosition, turnPosition, velocity, vobsHeading;
	bool_T					mapPathIsComplete, vobsHeadValid, pathIsInitialized;

	bool_T					 lowExecutionTime		= false;
	turnSignal_T			 turnSignal				= turnSignalNone;
	uint8_T					 nAttributeCalls		= 0u;
	uint8_T					 nSpeedLimitCalls		= 0u;
	uint8_T					 nSegmentCalls			= 0u;
	mapRouteMemory_T		*mapRouteMemory			= &pathRouterMemory->mapRouteMemory;
	mapPathMemory_T			*mapPathMemory			= &pathRouterMemory->mapPathMemory;
	const parameterSetCtrl_T	*parameterSet		= prmGetParameterSetCtrl();
	
	real32_T				 pathHeading;
	bool_T					 pathHeadValid;
	bool_T					 holdValid;

	bool_T					 ageReset				= true;
	bool_T					 mutex					= false;

	memset(mapPath, 0, sizeof(mapPath_T));

	/* Datenabfrage vom vehicleObserver */
	vobsGetTurnSignal( vehicleState,
					  &turnSignal,
					  &turnSignalConfident,
					  &turnSignalExtendHold);

	vobsGetTurnSignalPosition( vehicleState,
							  &turnPosition);

	vobsGetPosition(vehicleState, &longPosition);
	vobsGetVelocity(vehicleState, &velocity);

	vobsGetHeading(vehicleState,
				   &vobsHeadValid,
				   &vobsHeading);

	diagFF(psdwGetRgDatabaseMutex(&mutex));

	if (!vobsHeadValid) {
		vobsHeading = INVALID_VALUE; 
	}


	/* Ermitteln der laut mapPath erwarteten Fahrtrichtung an der aktuellen Position */
	if(pathRouterMemory->lastMapPath.valid) {
		pathHeadValid	= prtGetHeadingAtPosition(&pathRouterMemory->lastMapPath, longPosition, &pathHeading);
	}
	else {
		pathHeading		= INVALID_VALUE;
		pathHeadValid	= false;
	}

	if (mutex)
	{
		diagFF(prtUpdateTurnFilter( &pathRouterMemory->turnFilter,
									&pathRouterMemory->mapRouteMemory.mapRoute,
									pathHeading,
									velocity,
									vobsHeading,
									pathHeadValid,
									turnSignalExtendHold));
	} else {
		diagFF(prtIncrementTurnFilter(&pathRouterMemory->turnFilter,
									  &pathRouterMemory->mapRouteMemory.mapRoute,
									   pathHeading,
									   velocity,
									   vobsHeading,
									   pathHeadValid));
	}

	if (mutex) {
		/* Aktualisieren der mapRoute */
		diagFF(prtRouteUpdate(&pathRouterMemory->initFlag,
							   mapRouteMemory,
							  &nSegmentCalls,
							  &pathRouterMemory->turnFilter.virtualPosition,
							   pathRouterMemory->mapPathMemory.positionZero,
							   turnSignal,
							   turnSignalConfident,
							   turnPosition,
							  &ageReset));
	}


	/*Initialisieren, bzw. weiterbauen des mapPath anhand der mapRoute*/
	switch (pathRouterMemory->initFlag)
	{
	case mapRouteInvalid:
		/*mapRoute konnte noch nicht initialisiert werden*/
		mapPath->valid = false;
		break;
	case newMapRoute:
		/*Aus Laufzeitgr�nden findet die initialisierung des mapPath erst im n�chsten Takt statt.*/
		prtInit_mapPathMemory_T(mapPathMemory);
		mapPath->valid = false;
		pathRouterMemory->initFlag = mapPathInvalid;
		break;

	case mapPathInvalid:
		/*	Die `mapPathMemory` wurde zur�ckgesetzt
			Der Psd-Baum speichert die letztg�ltigen System- und Streckenattribute, vor dem Root-Segment. Diese werden hier kopiert. 
			Der mapPath kann aber noch nicht benutz werden. --> Anzeige statusINIT
			Falls die Initialisierung nicht gelingt, weil der Psd-Baum noch nicht g�ltig ist, 
			muss der gesamte Zyklus von vorn begonnen werden, da auch die mapRoute wieder ung�ltig sein kann.
		*/
		if (mutex) {
			diagFF(prtCopyRootTreeState( parameterSet,
										&mapRouteMemory->mapRoute,
										 mapPathMemory, 
										&pathIsInitialized));
			pathRouterMemory->initFlag = pathIsInitialized ? mapPathInitialized : mapRouteInvalid;
		} else {
			pathRouterMemory->initFlag = mapPathInvalid;
		}
		mapPath->valid = false;
		break;

	case mapPathInitialized:
		/* Den mapPath mit der mapRoute abgleichen. Unvollst�ndiges Segment vervollst�ndigen.
			Neue Segmente aus Psd-Baum �bertragen.
			Wenn das letzte mapRoute-Segment vollst�ndig �bertragen ist, initFlag aud `mapPathComplete`setzen.
			Gps-Position und Fahrzeugposition auf dem feritgen mapPath setzen. Kopiere persistente Daten nach `mapPath->memory`.
			Setze mapPath.valid == true falls Fahrzeugposition auf dem Pfad, sonst false.
		*/
		mapPathIsComplete = false;
		if (mutex) {
			diagFF(prtContinueMapPath(	parameterSet,
									   &pathRouterMemory->turnFilter.virtualPosition,
									   &mapRouteMemory->mapRoute,
										nSegmentCalls,
										mapPathMemory,
									   &nSpeedLimitCalls,
									   &nAttributeCalls,
										&mapPathIsComplete)); /*lint !e645 Symbol psdPosition wurde in prtContinueMapRoute initialisiert*/
		
			/* Dummy-Funktion um eine m�glichst konstante Laufzeit zu gew�hrleisten (konstant maximale Api-Aufrufe nutzen)*/
			prtDummyApiCalls(parameterSet, &nSegmentCalls, &nSpeedLimitCalls, &nAttributeCalls);
		}		
		
		/*Kopiere persistente Daten nach `mapPath->memory`. Setze Fahrzeugposition und (statusInit/statusOK) auf dem fertigen mapPath.*/
		diagFF(prtFinalizeMapPath(	 parameterSet, 
									&pathRouterMemory->turnFilter.virtualPosition, 
									 longPosition, 
									 velocity,
									 vobsHeading, 
									 mapRouteMemory->mapRoute.rerouteCount,
									 mapPathMemory, 
									&pathRouterMemory->headingFilter, 
									&pathRouterMemory->positionFilter, 
									 mapPath));
		
		if (mapPathIsComplete  &&  parameterSet->pathRouter.enableLowExecutionTime) {
			pathRouterMemory->initFlag = mapPathComplete;
		} else {
			pathRouterMemory->initFlag = mapPathInitialized;
		}

		break;

	case  mapPathComplete:
		/*Kopiere persistente Daten nach `mapPath->memory`. Setze Fahrzeugposition und die valid-Flag auf dem fertigen mapPath.*/
		diagFF(prtFinalizeMapPath(	 parameterSet, 
									&pathRouterMemory->turnFilter.virtualPosition, 
									 longPosition, 
									 velocity,
									 vobsHeading,
									 mapRouteMemory->mapRoute.rerouteCount,
									 mapPathMemory, 
									&pathRouterMemory->headingFilter, 
									&pathRouterMemory->positionFilter,
									 mapPath));

		/*In diesem Zyklus musste der pathRoter sehr wenig rechnen.*/
		lowExecutionTime = true;
		break;

	default:
		diagFUnreachable();
	} /*lint !e9077*/

	
	/*Falls mapPath ung�ltig: gespeicherte Ersatzwerte schreiben.*/
	/*\spec SwMS_Innodrive2_PSD_175*/
	if (mapPath->valid)
	{
		pathRouterMemory->lastMapPath = *mapPath;
		pathRouterMemory->valid = true;
	} else {
		*mapPath = pathRouterMemory->lastMapPath;
		pathRouterMemory->valid = false;
		if (longPosition - mapPath->positionZero > (real32_T)mapPath->info.distance) 
		{
			mapPath->valid = false; 
		}
	}

	/*Nullposition und Scheduling-Flag*/
	pathRouterMemory->mapPathMemory.positionZero = pathRouterMemory->lastMapPath.positionZero;
	mapPath->lowExecutionTime = lowExecutionTime;
	
	/*Systemattribute*/
	diagFF(prtGetSystemAttributes( mapPathMemory,
								   longPosition,
								  &mapPathMemory->systemAttributes));
	mapPath->info.systemAttributes = mapPathMemory->systemAttributes;


	/* Ermitteln der laut mapPath erwarteten Fahrtrichtung an der aktuellen Position */
	if(mapPath->valid) {
		pathHeadValid	= prtGetHeadingAtPosition( mapPath, longPosition, &pathHeading);
	}
	else {
		pathHeading		= INVALID_VALUE;
		pathHeadValid	= false;
	}


	/* Ist ein Halten des alten mapPath zul�ssig? */
	prtUpdateHold(&pathRouterMemory->holdFilter,
				   pathRouterMemory->valid,
				   pathHeading,
				   velocity,
				   vobsHeading,
				   vobsHeadValid && pathHeadValid,
				  &holdValid);


	/* Ggf. wird der Ausgabe-mapPath als ung�ltig markiert */
	mapPath->valid = mapPath->valid && (pathRouterMemory->valid || holdValid);


	/* Aktualisieren des Altersz�hlers */
	prtUpdateAge(&pathRouterMemory->ageFilter,
				  pathRouterMemory->valid,
				  ageReset);


	/*Feedback an den vehicleObserver senden*/
	prtGetMapPathInfo( mapPath,
					  &pathRouterMemory->headingFilter,
					  &pathRouterMemory->ageFilter,
					   longPosition,
					   vobsMapPathInfo);

	if (mutex) {
		diagFF(psdwReleaseRgDatabaseMutex(&mutex));
	}

	return true;
}


static void prtDummyApiCalls(	IN const	parameterSetCtrl_T	*parameterSet,
						INOUT		uint8_T			*nSegmentCalls,
						INOUT		uint8_T			*nSpeedLimitCalls,
						INOUT		uint8_T			*nAttributeCalls)
{
	psdSegment_T		dummySegment;
	psdSpeedLimit_T		dummySpeedLimit;
	psdAttribute_T		dummyAttribute;

	while (		*nSegmentCalls < parameterSet->pathRouter.maxSegmentsPerCycle
			&&	*nSegmentCalls + *nSpeedLimitCalls + *nAttributeCalls < parameterSet->pathRouter.maxApiCallsPerCycle)
	{
		(void)psdwGetSegmentData((psdSegmentId_T)PSD_EHR_SEGMENT_ID_MIN, &dummySegment);
		*nSegmentCalls += 1u;
	}
	while (		*nSpeedLimitCalls < parameterSet->pathRouter.maxSpeedLimitsPerCycle
			&&	*nSegmentCalls + *nSpeedLimitCalls + *nAttributeCalls < parameterSet->pathRouter.maxApiCallsPerCycle)
	{
		(void)psdwGetSpeedLimitData((psdSpeedLimitId_T)PSD_EHR_SPEED_LIMIT_LIST_MIN, (uint8_T)0, (uint8_T)0, &dummySpeedLimit);
		*nSpeedLimitCalls += 1u;
	}
	while (		*nAttributeCalls < parameterSet->pathRouter.maxAttributesPerCycle
			&&	*nSegmentCalls + *nSpeedLimitCalls + *nAttributeCalls < parameterSet->pathRouter.maxApiCallsPerCycle)
	{
		(void)psdwGetAttributeData((psdAttributeIndex_T)PSD_EHR_ATTRIBUTE_LIST_MIN, &dummyAttribute);
		*nAttributeCalls += 1u;
	}
}
