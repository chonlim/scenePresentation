#ifndef guard_prtInfoStatic_h
#define guard_prtInfoStatic_h

/** \brief GPS-Information in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoGps(			IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapGpsRing_T				*gpsRing,			/**<persistente Memory-DatenStruktur*/
											OUT			infoGpsInfo_T				*gpsInfo			/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Tempolimits in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoSpeedLimits(	IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapSpeedLimitRing_T			*speedLimitRing,	/**<persistente Memory-DatenStruktur*/
											OUT			infoSpeedLimitRing_T		*infoSpeedLimits	/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Bebauung in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T		prtBuildInfoBuiltUpArea(IN	const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN	const	mapBuiltUpRing_T			*builtUpRing,		/**<persistente Memory-DatenStruktur*/
											OUT			infoBuiltUpRing_T			*infoBuiltUpAreas	/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Stra�enklassen in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoStreetClass(	IN const	mapSegmentRing_T		*segmentRing,			/**<Segmentspeicher*/
											IN const	mapStreetClassRing_T	*streetClassRing,		/**<persistente Memory-DatenStruktur*/
											OUT			infoStreetClassRing_T	*infoStreetClasses		/**<Ausged�nnte Info-Datenstruktur*/
											);

	
/** \brief Rampen in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoRamp(			IN	const	mapSegmentRing_T	*segmentRing,				/**<Segmentspeicher*/
											IN	const	mapRampRing_T		*rampRing,					/**<persistente Memory-DatenStruktur*/
											OUT			infoRampRing_T		*infoRamps					/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Vorfahrtsregelungen in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoRightOfWay(		IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapRightOfWayRing_T			*rightOfWayRing,	/**<persistente Memory-DatenStruktur*/
											OUT			infoRightOfWayRing_T		*infoRightOfWays	/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Information Kreisverkehr/kein Kreisverkehr in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T		 prtBuildInfoRoundabout(IN	const	mapSegmentRing_T			*segmentRing,
											IN	const	mapStreetSituationRing_T	*streetSituationRing,
											OUT			infoRoundaboutRing_T		*infoRoundabout
											);


/** \brief Spuranzahlen in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoLaneSituation(	IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapLaneSituationRing_T		*laneSituationRing,	/**<persistente Memory-DatenStruktur*/
											OUT			infoLaneSituationRing_T		*infoLaneSituations	/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Kr�mmungen in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoCurvatures(		IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapCurvatureRing_T			*curvatureRing,		/**<persistente Memory-DatenStruktur*/
											INOUT		uint16_T					*infoDistance,		/**<Pfadl�nge der Info-Datenstruktur*/
											OUT			infoCurvatureRing_T			*infoCurvatures		/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief BranchAngles in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoBranchAngles(	IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapBranchAngleRing_T		*branchAngleRing,	/**<persistente Memory-DatenStruktur*/
											OUT			uint16_T					*infoDistance,		/**<Pfadl�nge der Info-Datenstruktur*/
											OUT			infoBranchAngleRing_T		*infoBranchAngles	/**<Ausged�nnte Info-Datenstruktur*/
											);


/** \brief Steigungen in die info-Struktur �bertragen
\spec SwMS_Innodrive2_PSD_176
*/
static bool_T	prtBuildInfoSlopes(			IN const	mapSegmentRing_T			*segmentRing,		/**<Segmentspeicher*/
											IN const	mapSlopeRing_T				*slopeRing,			/**<persistente Memory-DatenStruktur*/
											OUT			uint16_T					*infoDistance,		/**<Pfadl�nge der Info-Datenstruktur*/
											OUT			infoSlopeRing_T				*infoSlopes			/**<Ausged�nnte Info-Datenstruktur*/
											);


#endif
