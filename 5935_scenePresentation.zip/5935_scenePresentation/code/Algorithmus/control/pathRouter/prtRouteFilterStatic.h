#ifndef guard_prtRouteFilterStatic_h
#define guard_prtRouteFilterStatic_h


typedef enum branchCategory_tag {
	branchCategoryStraight,
	branchCategoryLeft,
	branchCategoryRight
} branchCategory_T;


/**	\brief		Erstellt eine Liste 'mapRoute' der vorraussichtlich zu befahrenen SegmentIds aus dem PSD-Baum.

	Die mapRoute beginnt mit dem Root-Segment (index 0) und wird inkrementell vorw�rts aufgebaut.

	Falls der Blinkerzustand 'turnSignal' sich ge�ndert hat, werden in \ref prtHandleConditionChange()
	alle Segmente ab dem ersten Verlassen des Straightest Path verworfen, um die mapRoute von dort ab neu aufzubauen.
	In \ref prtCheckPositionOnRoute() wird �berpr�ft, ob das Fahrzeug noch auf der mapRoute ist. Wenn nicht, wird die mapRoute neu initialisiert (\ref prtGetRouteFromRoot()).

	Wenn die Fahrzeug-Position 'positionID' noch auf der MapRoute ist, werden wiederholt in \ref prtCopyChildSegments() alle Kinder des letzten mapRoute-Segments gelesen
	und aus ihnen das vorraussichtlich befahrene Segment in \ref prtFindBestChild() gesucht. Dieses wird an die mapRoute angeh�ngt.
	Wenn das letzte Segment auf der `mapRoute` keine Kind-Segmente hat, wird die Flag 'mapRoute->completed = true' gesetzt.

	Die \ref ::psdwGetSegmentData() - Aufrufe werden gez�hlt; wenn sie die 'maxSegmentCalls' erreichen , wird die Funktion wieder verlassen.
	Die 'changeFlag' gibt an, ob die 'mapRoute' ge�ndert wurde und falls ja, ob sie komplett neu initialisiert, umgeleited (rerouted) oder lediglich aktualisiert wurde.
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_135
\ingroup	pathRouter_routing 
	*/
static bool_T			 prtGetMapRoute(IN	const	real32_T					 turnPosition,					/**< Position ab der Abzweigung m�glich ist. */
										IN	const	real32_T					 positionZero,					/**< Position des Ausgangspunkts des Pfades */
										IN	const	turnSignal_T				 turnSignal,					/**< Blinker links oder rechts*/
										IN	const	bool_T						 turnSignalConfident,			/**< Ist das turnSignal verl�sslich? */
										IN	const	bool_T						 useRouting,					/**< Gibt an, ob der MPP anstelle des SP f�r die Generierung der Route verwendet werden soll */
										IN	const	uint8_T						 maxSegmentCalls,				/**< Maximal erlaubte Api-Aufrufe*/
										INOUT		uint8_T						*nSegmentCalls,					/**< Z�hler f�r Api-Aufrufe*/
										INOUT		mapRouteMemory_T			*mapRouteMemory,				/**< Liste der zu befahrenden Segmente*/
										OUT			bool_T						*mapRouteUpdated				/**< Zeigt ein Update der mapRoute an*/
										);


/**	\brief		Pr�ft alle Segmente auf neu hinzugef�gte Abzweigungen und passt die 'mapRoute' entsprechend an.

	Vorbedingung ist eine g�ltige und komplettierte mapRoute ('mapRouteMemory->completed == true').

	Jedes Segment auf der mapRoute wird neu aus dem Modul 'psdWrapper' geladen. Sein Attribut 'childCount' wird mit dem des in der 'mapRoute' gespeicherten 
	Segments verglichen. Falls der 'childCount' abweicht, wird die Flag 'mapRouteMemry->completed = false' gesetzt
	Dies schlie�t den Fall ein, dass am Pfadende ein neues Segment angeh�ngt wird. 
	Falls das ge�nderte Segment in der Pfadmitte liegt, werden die Kindsegmente in \ref prtCopyChildSegments() kopiert 
	und das vorraussichtlich befahrene Segment in \ref prtFindBestChild() gesucht.
	Falls das "best child" von der gespeicherten 'mapRoute' abweicht, wird sie an dieser Stelle abgeschnitten (indem der 'mapRoute->segmentCount'
	zur�ckegesetzt wird) und die Flag 'mapRouteMemory->completed == false' wird gesetzt.
	Sonst werden lediglich die Informationen in 'mapRoute->branch' und 'mapRoute->smallestAngles' aktualisiert.

	Die \ref ::psdwGetSegmentData() - Aufrufe werden gez�hlt; wenn sie die 'maxSegmentCalls' erreichen , wird die Funktion wieder verlassen.
	In 'mapRouteMemory->checkBranchesIndex' wird das letzte �berpr�fte Segment gespeichert, um im n�chsten Rechentakt die �berpr�fung fortsetzen zu k�nnen.
	Wenn alle Segmente der mapRoute �berpr�ft worden sind, wird der 'mapRouteMemory->checkBranchesIndex = 0' gesetzt.
	Die 'changeFlag' gibt an, ob die 'mapRoute' ge�ndert wurde und falls ja, ob sie komplett neu initialisiert, umgeleited (rerouted) oder lediglich aktualisiert wurde.
	
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_135
\ingroup	pathRouter_routing
	*/
static bool_T		   prtCheckBranches(INOUT		mapRoute_T					*mapRoute,							/**< Liste der zu befahrenden Segmente*/
										INOUT		uint8_T						*checkBranchesIndex,				/**< Index des n�chsten zu pr�fenden Segments */
										INOUT		uint8_T						*nSegmentCalls,						/**< Z�hler f�r Api-Aufrufe*/
										IN	const	uint8_T						 positionId,						/**< SegmentId der Fahrzeugposition*/
										IN	const	real32_T					 turnPosition,						/**< Position ab der Abzweigung m�glich ist. */
										IN	const	real32_T					 positionZero,						/**< Position des Ausgangspunkts des Pfades */
										IN	const	turnSignal_T				 turnSignal,						/**< Blinker links oder rechts*/
										IN	const	bool_T						 turnSignalConfident,				/**< Ist das turnSignal verl�sslich? */
										IN	const	bool_T						 useRouting,						/**< Gibt an, ob der MPP anstelle des SP f�r die Generierung der Route verwendet werden soll */
										IN	const	uint8_T						 maxSegmentCalls,					/**< Maximal erlaubte Api-Aufrufe*/
										OUT			bool_T						*changed,							/**< Zeigt eine �nderung der mapRoute an */
										OUT			bool_T						*completed							/**< Zeigt ein Rerouting der mapRoute an*/
										);


/**	\brief		Kopiert alle Kindsegmente des Segments `currentSegment` in das Array `children`.

	Die \ref ::psdwGetSegmentData() - Aufrufe werden gez�hlt; wenn sie die `maxSegmentCalls` erreichen , wird die Funktion wieder verlassen und
	die Flag `childrenComplete = false` gesetzt.
	Es werden nur komplettierte Kindsegmente �bertragen. Wenn ein Kind nicht die "complete-Flag" gesetzt hat, wird die Flag `childrenComplete = false` gesetzt.
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_147
\ingroup	pathRouter_routing
	*/
static bool_T	   prtCopyChildSegments(IN	const	psdSegment_T				*currentSegment,					/**< Segment, dessen Kinder kopiert werden*/
										IN	const	uint8_T						 maxSegmentCalls,					/**< Maximal erlaubte Api-Aufrufe*/
										INOUT		uint8_T						*nSegmentCalls,						/**< Z�hler f�r Api-Aufrufe*/
										OUT			psdSegment_T				 children[psdMAXCHILDRENCOUNT],		/**< Kindsegmente von `currentSegment`*/
										OUT			bool_T						*childrenComplete					/**< Wahr, wenn alle Kinder im Array `children` alle Complete-Flags gesetzt haben*/
										);


/**	\brief		Routing abh�ngig von Blinkerzustand ab dem positionSegment

	Es werden die BranchAngles aller Kinder des 'parentSegment' verglichen.
	Ein Segment hat die 'isStraightestPath'-Flag und wird standardm��ig zur�ckgegeben.
	Wenn es mehr als ein Kind gibt, ist jenes mit dem kleinsten BranchAngle eine Linksabzweigung und
	jenes mit dem gr��ten BranchAngle eine Rechtsabzweigung. Vorliegende Abzweigungen werden in der Ausgabeflag 'branches' angezeigt.
	Der Betragsm��ig kleinste branchAngle aller Kindsegmente wird als 'smallestAngle' zur�ckgegeben.

	Wenn eine Abzweigung auf der 'mapRoute' in die Richtung eines gesetzten Blinkers vorliegt und sie zudem die Erste Abzweigung auf der 'mapRoute'
	in diese Richtung ist, wird dieser Abzweigung gefolgt, d.h. das zur�ckgegebene 'bestChild' zweigt vom StraightestPath ab.
	NICHT gefolgt wird Abzweigungen von Autobahn�hnlich ausgebauten Stra�en mit baulich getrennten Richtungsfahrbahnen ('ramp == oneWayRoad  &&  lanes > 1')
\spec SwMS_Innodrive2_PSD_140
\spec SwMS_Innodrive2_PSD_180
\spec SwMS_Innodrive2_PSD_141
\spec SwMS_Innodrive2_PSD_183
\ingroup pathRouter_routing
	*/
static bool_T		   prtFindBestChild(IN	const	real32_T					 turnPosition,						/**< Position ab der Abzweigung m�glich ist. */
										IN	const	real32_T					 positionZero,						/**< Position des Ausgangspunkts des Pfades */
										IN	const	turnSignal_T				 turnSignal,						/**< Abbiegewunsch, der aktuell vom vehicleObserver gemeldet wird */
										IN	const	bool_T						 turnSignalConfident,				/**< Ist das turnSignal verl�sslich? */
										IN	const	bool_T						 useRouting,						/**< Gibt an, ob der MPP anstelle des SP f�r die Suche zu verwenden ist */
										IN	const	uint8_T						 childCount,						/**< Anzahl der Child-Segmente */
										IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],		/**< Daten der Child-Segmente */
										IN	const	mapRoute_T					*mapRoute,							/**< Liste der relvanten Segmente bis zur aktuellen Position */
										OUT			uint8_T						*smallestAngle,						/**< Betragsm��ig kleinster Abbiegewinkel, der vom Parent-Segment ausgeht */
										OUT			branchOptions_T				*branchOptions,						/**< Branchm�glichkeiten ausgehend vom aktuellen Segment */
										OUT			psdSegment_T				*bestChild							/**< Daten des ausgew�hlten Child-Segments */
										);


/**	\brief		Initialisiere die mapRoute.

	Hole die Fahrzeugposition und das zugeh�rige Segment vom Modul \ref psdWrapper.
	Baue die mapRoute von der Wurzel des Baums bis zur Fahrzeugposition mit der Funktion \ref prtGetRouteFromRoot().
	Falls die Kartendaten vom Modul \ref psdWrapper g�ltig sind, setze die Flag `mapRouteInitialized = true`, sonst `false`.
\ingroup	pathRouter_routing
	*/
static bool_T	  prtInitializeMapRoute(IN	const	uint8_T						 maxSegmentCalls,					/**< Maximal erlaubte Api-Aufrufe*/
										IN	const	mapRawVehiclePosition_T		*psdPosition,						/**< Fahrzeugposition auf PSD-Baum*/
										INOUT		uint8_T						*nSegmentCalls,						/**< Z�hler f�r Api-Aufrufe*/
										OUT			mapRouteMemory_T			*mapRouteMemory,					/**< persistene Routendaten*/
										OUT			bool_T						*mapRouteInitialized				/**< Erfolgs-Flag*/
										);



/**	\brief		Weiterbauen der mapRoute, falls `initFlag==mapPathInitialized` oder Baum/Blinker/position ge�ndert.

	Hole die Fahrzeugposition und den changeCount des PSD-Baums vom Modul \ref psdWrapper
	Falls der mapPath unvollst�ndig (`mapRoute->completed = false`) ist oder der Blinker oder die Fahrzeugposition sich ge�ndert hat, baue die mapRoute weiter in Funktion \ref prtGetMapRoute().
	Sonst, falls sich der der PSD-Baum ge�ndert hat, �berpr�fe die `mapRoute` auf neu hinzugef�gte Abzweigungen in Funktion \ref prtCheckBranches().
	Sonst tue nichts.

	Die `changeFlag` gibt an, ob die `mapRoute� ge�ndert wurde und falls ja, ob sie komplett neu initialisiert, umgeleited (rerouted) oder lediglich aktualisiert wurde.
	
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_132
\ingroup	pathRouter_routing
	*/
static bool_T	    prtContinueMapRoute(IN	const	turnSignal_T				 turnSignal,						/**< Aktueller Blinker */
										IN	const	bool_T						 turnSignalConfident,				/**< Ist das turnSignal verl�sslich? */
										IN  const   real32_T					 turnPosition,						/**< Position ab der Abzweigung m�glich ist. */
										IN	const	uint8_T						 maxSegmentCalls,					/**< Maximal erlaubte Api-Aufrufe*/
										IN  const	mapRawVehiclePosition_T		*psdPosition,						/**< Fahrzeugposition auf PSD-Baum */
										IN  const	real32_T					 positionZero,						/**< Position des Ausgangspunkts des Pfades */
										INOUT		uint8_T						*nSegmentCalls,						/**< Z�hler f�r Api-Aufrufe */
										INOUT		psdChangeCount_T			*lastChangeCount,					/**< Letzter PSD-TreeChangeCount.*/
										INOUT		mapRouteMemory_T			*mapRouteMemory,					/**< Persistente Routendaten */
										OUT			mapChangeFlag_T				*changeFlag							/**< Zeigt weitergebaute bzw. neuinitialisierte mapRoute an.*/
										);

/** \brief		Fahrzeugposition auf der `mapRoute` �berpr�fen.

	�berpr�fe, ob die Fahrzeugposition `positionID` weiterhin auf der mapRoute ist (das ist der Normalfall).
	Alle Segmente vor dem aktuellen root-Segment werden dann verworfen.
	Falls das Fahrzeug an einer Abzweigung anders abgebogen ist als pr�zediert, wird das neue Positions-Segment an sein Eltern-Segment angeh�ngt.
	Falls auch das Eltern-Segment nicht mehr auf der `mapRoute` ist, wird die mapRoute vom Root-Segment zur Fahrzeugposition neu gebaut (\ref prtGetRouteFromRoot()).
	In diesem Fall wird auch die initFlag auf `newMapRoute` gesetzt.
	Das ausgegebene `tailSegment` ist in jedem Fall das letzte g�ltige Segment der `mapRoute`.
	
\spec SwMS_Innodrive2_PSD_119
\ingroup	pathRouter_routing
	*/
static bool_T	prtCheckPositionOnRoute(IN	const	uint8_T						 positionId,						/**< SegmentId der Fahrzeugposition*/
										INOUT		uint8_T						*nSegmentCalls,						/**< Z�hler f�r Api-Aufrufe*/
										INOUT		mapRoute_T					*mapRoute,							/**< Liste der zu befahrenden Segmente*/
										OUT			bool_T						*positionOnRoute,					/**< Bei false muss neu initialisiert werden*/
										OUT			bool_T						*mapRouteRerouted					/**< Bei einer Neupositionierung ohne Wechsel des Wurzelsegments*/
										);


/**	\brief		Den Anfang der mapRoute bis zum root-Segment vorschieben.
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_133
	\ingroup	pathRouter_routing
	*/
static bool_T		prtCheckRootSegment(INOUT		mapRoute_T					*mapRoute,							/**< Liste der zu befahrenden Segmente*/
										OUT			bool_T						*mapRouteUpdated					/**< Zeigt ein Update der mapRoute an*/
										);

/** \brief		L�scht alle branch-Flags auf der mapRoute im Bereich [firstIndex, lastIndex] (inklusive) 
	\ingroup	pathRouter_routing
	*/
static void			 prtKillBranchFlags(IN const	uint8_T						 firstIndex,						/**< Erster Index an dem gel�scht wird*/
										IN const	uint8_T						 lastIndex,							/**< Lezter Index an dem gel�scht wird*/
										OUT			mapRoute_T					*mapRoute							/**< Liste der zu befahrenden Segment inkl. branch-Flags*/
										);


/**	\brief		Es werden auf der `mapRoute` alle Segmente ab dem ersten Verlassen des Straightest Path verworfen, indem der `mapRoute->segmentCount` entsprechend angepasst wird.

	Alle Segmente bis einschlie�lich der Fahrzeugposition bleiben in jedem Fall erhalten.
	Falls der Blinker links  gesetzt war oder neu gesetzt wird, werden alle Segmente nach der Ersten Abzweigung links verworfen.
	Falls der Blinker rechts gesetzt war oder neu gesetzt wird, werden alle Segmente nach der ersten Abzweigung rechts verworfen.

	Wenn die Fahrzeugposition nicht auf der Route liegt, muss die Funktion die `mapRoute` unver�ndert lassen und `mapRouteRerouted == false` ausgeben.
	\ingroup pathRouter_routing
	*/
static bool_T  prtHandleConditionChange(INOUT		mapRoute_T					*mapRoute,							/**< Liste der zu befahrenden Segmente*/
										IN const	turnSignal_T				 turnSignal,						/**< Blinker links oder rechts*/
										IN const	turnSignal_T				 lastTurnSignal,					/**< Letzter Blinker links oder rechts*/
										IN	const	bool_T						 turnSignalConfident,				/**< Ist das turnSignal verl�sslich? */
										IN	const	bool_T						 lastConfident,						/**< War das turnSignal verl�sslich? */
										IN  const   real32_T					 turnPosition,						/**< Position ab der Abzweigung m�glich ist. */
										IN  const   real32_T					 positionZero,						/**< Position des Ausgangspunkts des Pfades */
										IN	const	bool_T						 useRouting,						/**< Soll der MPP anstelle des SP verfolgt werden? */
										IN	const	bool_T						 lastUseRouting,					/**< Sollte im letzten Schritt der MPP verfolgt werden? */
										OUT			bool_T						*changed							/**< Zeigt ein Rerouting der mapRoute an*/
										);


/**	\brief		Baue die mapRoute vom RootSegment bis zum positionSegment.

	Die ausgegebene `mapRoute` beginnt beim root-Segment des PSD-Baums (Index 0) und endet beim �bergebenen `positionSegment` (index `segmentCount - 1`).
	\ingroup pathRouter_routing
\spec SwMS_Innodrive2_PSD_119
\spec SwMS_Innodrive2_PSD_147
\spec SwMS_Innodrive2_PSD_133
\ingroup	pathRouter_routing
	*/
static bool_T		prtGetRouteFromRoot(IN	const	psdSegmentId_T				 positionId,						/**< Segment der Fahrzeugposition*/
										IN	const	uint8_T						 maxSegmentCalls,					/**< Maximal erlaubte Api-Aufrufe*/
										INOUT		uint8_T						*nSegmentCalls,						/**< Z�hler f�r Api-Aufrufe*/
										OUT			mapRouteMemory_T			*mapRouteMemory,  					/**< persistene Routendaten*/
										OUT			bool_T						*mapRouteValid						/**< Wahr, wenn der Aufbau der Route Erfolgreich war*/
										);


/**	\brief		Ermittelt die Indizes der Child-Segmente mit dem SP bzw. MPP-Attribut und dem betragsm��ig kleinsten Abzweigwinkel
	\ingroup	pathRouter_routing

	Wenn kein Child-Segment das MPP-Attribut tr�gt, wird der Index INVALID_UINT8 ausgegeben. Segmente ohne ausgewiesene Fahrspuren in Fahrtrichtung
	werden nicht ber�cksichtigt. Segmente mit Stra�enkategorie 0 werden nur in Betracht gezogen, wenn es sich um Abfahrten handelt.
	
\spec SwMS_Innodrive2_PSD_140
\spec SwMS_Innodrive2_PSD_180
\ingroup	pathRouter_routing
	*/
static bool_T	   prtPathPruneStraight(IN	const	uint8_T						 childCount,						/**< Anzahl g�ltiger Child-Segmente */
										IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],		/**< Daten der Child-Segmente */
										OUT			uint8_T						*smallestAngle,						/**< Kleinster Abbiegewinkel, der vom aktuellen Segment ausgeht */
										OUT			uint8_T						*indexStraight,						/**< Index des Child-Segments mit dem SP-Attribut */
										OUT			uint8_T						*indexProbable,						/**< Index des Child-Segments mit dem MPP-Attribut (Default: MPP) */
										OUT			uint8_T						*indexSmallestAngle					/**< Index des Child-Segments mit dem kleinsten Abzweigwinkel */
										);


/**	\brief		Ermittelt die Indizes der Child-Segmente, die f�r explizites Links- bzw. Rechtsabbiegen infrage kommen

	Alle Child-Segmente werden bzgl. ihrer Abbiegerichtung (links oder rechts vom SP) kategorisiert. Parameterabh�ngig werden die Indizies der Links/Rechtsabbiegung
	mit dem gr��ten oder kleinsten Abbiegewinkel ausgegeben. Segmente ohne ausgewiesene Fahrspuren in Fahrtrichtung werden nicht ber�cksichtigt. Segmente mit
	Stra�enkategorie 0 werden nur in Betracht gezogen, wenn es sich um Abfahrten handelt.
	
\spec SwMS_Innodrive2_PSD_141
\ingroup	pathRouter_routing
	*/
static bool_T	   prtPathPruneBranches(IN	const	uint8_T						 childCount,						/**< Anzahl g�ltiger Child-Segmente */
										IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],		/**< Daten der Child-Segmente */
										IN	const	uint8_T						 indexStraight,						/**< Index des Child-Segments mit dem SP-Attribut */
										OUT			uint8_T						*indexLeft,							/**< Index des besten linksabbiegenden Child-Segments*/
										OUT			uint8_T						*indexRight,						/**< Index des besten linksabbiegenden Child-Segments*/
										OUT			branchCategory_T			 categories[psdMAXCHILDRENCOUNT]	/**< Kategorisierung der Child-Segmente */
										);


/**	\brief		Ermittelt, ob auf der mapRoute hinter dem aktuellen Segment bereits eine M�glichkeit f�r Links- bzw. Rechtsabbiegen vorgelegen hat
\spec SwMS_Innodrive2_PSD_183
	\ingroup	pathRouter_routing
*/
static bool_T	   prtPathGetBranchLock(IN	const	real32_T					 turnPosition,						/**< Position ab der Abzweigung m�glich ist. */
										IN	const	real32_T					 positionZero,						/**< Position des Ausgangspunkts des Pfades */
										IN	const	mapRoute_T					*mapRoute,							/**< Liste der zu befahrenden Segmente */
										IN	const	bool_T						 turnSignalConfident,				/**< Ist das turnSignal verl�sslich? */
										OUT			bool_T						*lockLeft,							/**< Gibt an, ob bereits eine M�glichkeit zum Linksabiegen vorgelegen hat */
										OUT			bool_T						*lockRight							/**< Gibt an, ob bereits eine M�glichkeit zum Rechtsabbiegen vorgelegen hat */
										);


/**	\brief		Gibt die Daten des ausgew�hlten Child-Segments sowie die Branchm�glichkeiten vom aktuellen Segment aus

	Wenn keine explizite Abbiegeintention gesetzt ist, wird abh�ngig von 'useRouting' entweder das SP oder das MPP ausgew�hlt. Wenn die Abbiegerichtung des
	MPP-Segments vom turnSignal gesperrt wird, f�llt die Auswahl auf das SP-Segment zur�ck. Bei expliziter Abbiegeintention wird das entsprechende 
	Child-Segment ausgew�hlt, sofern die Abbiegung nicht bereits ausgewertet wurde ('lockLeft'/'lockRight').

	Zus�tzlich werden die vom SP/MPP abweichenden Abbiegem�glichkeiten ausgegeben.
\ingroup pathRouter_routing
	*/
static bool_T		 prtPathFollowChild(IN	const	psdSegment_T				 children[psdMAXCHILDRENCOUNT],		/**< Daten der Child-Segmente */
										IN	const	turnSignal_T				 turnSignal,						/**< Blinker links oder rechts*/
										IN	const	uint8_T						 indexNone,							/**< Index des besten Child-Segments ohne Blinker*/
										IN	const	uint8_T						 indexLeft,							/**< Index des besten linksabbiegenden Child-Segments*/
										IN	const	uint8_T						 indexRight,						/**< Index des besten linksabbiegenden Child-Segments*/
										IN	const	bool_T						 lockLeft,							/**< Gibt an, ob bereits eine M�glichkeit zum Linksabiegen vorgelegen hat */
										IN	const	bool_T						 lockRight,							/**< Gibt an, ob bereits eine M�glichkeit zum Rechtsabbiegen vorgelegen hat */
										OUT			psdSegment_T				*bestChild							/**< Daten des ausgew�hlten Child-Segments */
										);

/**\brief Initialisiert die Struktur mapRouteMemory_T mit geeigneten Standard Werten.

\spec SwMS_Innodrive2_PSD_140
\spec SwMS_Innodrive2_PSD_180
\ingroup pathRouter_routing
*/
static void	prtInit_mapRouteMemory_T(	OUT	mapRouteMemory_T					*mapRouteMemory						/**< persistene Routendaten*/
										);


/**\brief Gibt den Index aus, dem ohne Blinkersignal gefolgt werden soll.
\spec SwMS_Innodrive2_PSD_140
\spec SwMS_Innodrive2_PSD_180
\ingroup pathRouter_routing
*/
static bool_T	prtPathGetIndexNoSignal(IN	const	turnSignal_T				 turnSignal,						/**< Blinker links oder rechts*/
										IN	const	bool_T						 useRouting,						/**< Soll der MPP anstelle des SP verfolgt werden? */
										IN	const	uint8_T						 indexStraight,						/**< Index des Child-Segments mit dem SP-Attribut */
										IN	const	uint8_T						 indexProbable,						/**< Index der Child-Segments mit dem MPP-Attribut (Default: MPP) */
										IN	const	branchCategory_T			 categories[psdMAXCHILDRENCOUNT],	/**< Kategorisierung der Child-Segmente */
										OUT			uint8_T						*indexNoSignal						/**< Index des besten Child-Segments ohne Blinker*/
										);

/**\brief Gibt die Branchm�glichkeiten ausgehend vom aktuellen Segment aus
\spec SwMS_Innodrive2_PSD_141
\ingroup pathRouter_routing
*/
static bool_T	prtPathGetBranchOptions(IN	const	uint8_T						 childCount,						/**< Anzahl g�ltiger Child-Segmente */
										IN	const	uint8_T						 indexLeft,							/**< Index des besten linksabbiegenden Child-Segments*/
										IN	const	uint8_T						 indexRight,						/**< Index des besten rechtsabbiegenden Child-Segments*/
										IN	const	uint8_T						 indexStraight,						/**< Index des Child-Segments mit dem SP-Attribut */
										IN	const	uint8_T						 indexProbable,						/**< Index der Child-Segments mit dem MPP-Attribut (Default: MPP) */
										OUT			branchOptions_T				*branchOptions						/**< Branchm�glichkeiten ausgehend vom aktuellen Segment */
										);


#endif
