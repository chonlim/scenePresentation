#ifndef guard_prtLoopBackStatic_h
#define guard_prtLoopBackStatic_h


static void		   prtGetRoundaboutTail(IN	const	mapPath_T				*mapPath,
										IN	const	real32_T				 position,
										OUT			real32_T				*roundaboutTail
										);


static void			prtAttachInfoLimits(INOUT		mapPathInfo_T			*mapPathInfo,
										IN	const	mapPath_T				*mapPath
										);


static void			prtAttachInfoSlopes(INOUT		mapPathInfo_T			*mapPathInfo,
										IN	const	mapPath_T				*mapPath
										);


#endif
