#ifndef guard_prtAttributesStatic_h
#define guard_prtAttributesStatic_h

#include "pathRouter.h"
#include "common/pathRouterCommon/pathRouter_private.h"

/* \brief Ausgeben der Warning: "OutputBuffer voll."
\ingroup pathRouter_caching
*/
static void		prtOutputBufferWarning(	INOUT		bool_T						*debugMsgLock);


/** \brief �bertragen von Branch angles, nur wenn der Winkel ungleich Null ist
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyBranchAngle(			IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapBranchAngleRing_T		*branchAngleRing,		/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);

/** \brief �bertagen von Built-Up Area, nur an Ortsanf�ngen und Ortsausg�ngen
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyBuiltUp(				IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapBuiltUpRing_T			*builtUpRing,			/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);

/** \brief �bertragen der Kurvenkr�mmungen (zwei pro Segment)
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyCurvature(			IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapCurvatureRing_T			*curvatureRing,			/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);

/** \brief �bertragen von Informationen �ber die Spuranzahl 
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyForwardLanes(		IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapLaneSituationRing_T		*laneSituationRing,		/**<Ringspeicher f�r Werte*/
											OUT			bool_T						*flagLaneAccretion,		/**<Findet eine Spuraufweitung statt?*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);

/** \brief �bertragen von Informationen �ber die Stellen steigender Dynamik (Autobahnauffahrt, Spuranzahlerh�hung)
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyDynamicEvents(		IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des aktuellen Segments im lokalen Ringspeicher mapPath->segmentRing*/
											IN const	mapSegmentRing_T			*segmentRing,			/**<RampValue des Vorg�ngersegments*/
											IN const	bool_T						 flagLaneAccretion,		/**<Fand eine Spuraufweitung statt?*/
											INOUT		mapDynamicEventRing_T		*dynamicEventRing,		/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);

/** \brief �bertragen von Informationen �ber die Stra�enklasse
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyStreetClass(			IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapStreetClassRing_T		*streetClassRing,		/**<Ringspeicher f�r Werte*/	
											OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im streetClassRing*/
											);

/** \brief �bertragen von Informationen �ber die Rampe (mit Gegenverkehr, Auffahrt, Abfahrt, Autobahn�hnlich)
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyRamp(				IN const	psdSegment_T				*segment,				/**<Segment, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapRampRing_T				*rampRing,				/**<Ringspeicher f�r Werte*/	
											OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im streetClassRing*/	
											);

/** \brief Abbiegespuren �bertragen
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/

static bool_T	prtCopyTurningLanes(		IN const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapLaneSituationRing_T		*laneSituationRing,		/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);


/** \brief Vorfahrtseinrichtungen (au�er Ampeln) �bertragen
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyRightOfWayControl(	IN const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapRightOfWayRing_T			*rightOfWayRing,		/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);

/** \brief Vorfahrtseinrichtungen (au�er Ampeln) �bertragen
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyTrafficLight(		IN const	psdAttribute_T				*attribute,				/**<Attribut, dessen Werte �bertragen werden*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapRightOfWayRing_T			*rightOfWayRing,		/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId  			/**<R�ckgabe des Endindexes im speedLimitRing*/
											);



/** \brief T-Kreuzungen �bertragen
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_caching
*/
static bool_T	prtCopyIntersection(		IN const	uint8_T						 angleTolerance,		/**<Parameter bis zu welchem Wert ein Abzweig als geradeaus gewertet wird*/
											IN const	uint8_T						 smallestAngle,			/**<Kleinster Abzweigewinkel unter den Kindern des aktuellen Segments*/
											IN const	ringId_T					 segmentRingId,			/**<Position des Segments im lokalen Ringspeicher mapPath->segmentRing*/
											INOUT		mapRightOfWayRing_T			*rightOfWayRing,		/**<Ringspeicher f�r Werte*/
											OUT			ringId_T					*endRingId				/**<R�ckgabe des Endindexes im speedLimitRing*/
											);



#endif
