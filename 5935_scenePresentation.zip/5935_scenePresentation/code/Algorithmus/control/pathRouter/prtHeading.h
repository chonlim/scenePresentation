#ifndef guard_prtHeading_h
#define guard_prtHeading_h

#include "control/pathRouter/pathRouter.h"


#ifdef __cplusplus
extern "C" {
#endif

		
/** \brief Heading-Korrektur als Abweichung zwischen interpolierter und gespeicherter Heading berechnen.

In jedem Zeitschritt wird das Heading, das vom aktuellen�mapPath f�r die Referenzposition `headingFilter->rawPosition` im letzten Zeitschritt ausgegeben wird 
mit dem Referenzwert `headingFilter->reference` verglichen, der im letzten Zeitschritt f�r die gleiche Position berechnet wurde. 
Besteht zwischen beiden Werten eine Differenz, wird der Korrekturwert `headingFilter->correction` um diese Differenz erh�ht.
Der Korrekturwert wird mit einem parametrierbaren `correctionGradient` pro Zeitschritt wieder in Richtung 0 gef�hrt.
Die Heading an der aktuellen `newPosition` wird als neue Referenz im `headingFilter->reference` gespeichert.
Der Korrekturwert liegt immer im Intervall [-180, 180] Grad.

\spec SwMS_Innodrive2_PSD_164
\spec SwMS_Innodrive2_PSD_165
\ingroup pathRouter_caching
*/
bool_T	prtFilterHeadingCorrection(	IN const	parameterSetCtrl_T			*parameterSet,			/**<Grad pro Control-Zyklus*/
									IN const	mapPath_T					*mapPath,				/**<Struktur der linearisierten Streckendaten*/
									IN const	mapSegmentRing_T			*segmentRing,			/**<Speicher der Segmente-Ids auf dem Pfad*/
									IN const	mapRawVehiclePosition_T		*rawPosition,			/**<Fahrzeugposition vom psd-Baum*/
									IN const	uint16_T					 newPosition,			/**<Aktuelle Position auf dem mapPath*/
									IN const	real32_T					 velocity,				/**<Fahrzeuggeschwindigkeit*/
									INOUT		mapHeadingFilter_T			*headingFilter			/**<Korrektur, Referenzwert und Referenzposition aus dem letzten Takt*/
									);


/** \brief Extrapoliert die GPS-Heading auf dem `mapPath` anhand der Curvatures und BranchAngles von der baseGPS.position zur �bergebenen `position` 

\spec SwMS_Innodrive2_PSD_164
\ingroup pathRouter_api
*/
bool_T	prtGetHeadingAtPosition(	IN const	mapPath_T					*mapPath,				/**<Struktur der linearisierten Streckendaten*/
									IN const	real32_T					 Position,				/**<Zielposition*/
									OUT			real32_T					*gpsHeading 			/**<extrapolierte Ausrichtung liegt zwischen 0� und 360�*/
									);

	
#ifdef __cplusplus
}
#endif

#endif
