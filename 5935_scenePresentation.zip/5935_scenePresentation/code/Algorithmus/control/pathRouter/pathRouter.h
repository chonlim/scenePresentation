#ifndef guard_pathRouter_h
#define guard_pathRouter_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"
#include "common/pathRouterCommon/pathRouter_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/pathRouterCommon/prtTypeMapping.h"

/** \brief Wrapper um \ref prtStep(). Initiailisieren der Speicher- und Ausgabestrukturen bei unerwartetem Fehler.
\spec SwMS_Innodrive2_PSD_53
\ingroup pathRouter_step
*/
void	pathRouter(				IN	const	vehicleState_T		*vehicleState,			/**<Ausgabe des vehicleObserver*/
								INOUT		pathRouterMemory_T	*pathRouterMemory,		/**<persistente Daten des pathRouter*/
								OUT			mapPathInfo_T		*vobsMapPathInfo,		/**<Struktur des vehicleObserver f�r Feedback vom pathRouter*/
								OUT			mapPath_T			*mapPath  				/**<Ausgabe des pathRouter*/
								);
#endif
