#ifndef guard_prtTools_h
#define guard_prtTools_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"
#include "common/pathRouterCommon/pathRouter_interface.h"





/**Gibt `true` zur�ck, wenn die Daten im `pathRouterMemory` g�ltig sind.
\spec SwMS_Innodrive2_PSD_71
\ingroup pathRouter_api
*/
bool_T		prtIsMemoryValid(			IN const	pathRouterMemory_T			*pathRouterMemory		/**<Struktur der linearisierten Streckendaten*/
										);


/** \brief Gibt den L�ndercode zur�ck.
\spec SwMS_Innodrive2_PSD_82
\ingroup pathRouter_api
*/
uint8_T		prtGetCountryCode(		IN const	pathRouterMemory_T			*pathRouterMemory		/**<Struktur der linearisierten Streckendaten*/
										);


/** \brief Gibt die Zahl der gespeicherten OnlineSpeed-Attribute zur�ck
\spec SwMS_Innodrive2_PSD_95
\ingroup pathRouter_api
*/
uint16_T	prtGetOnlineSpeedCount(		IN const	pathRouterMemory_T			*pathRouterMemory		/**<Struktur der linearisierten Streckendaten*/
										);


/** \brief Gibt Position und Wert der Ortsgrenze mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Ortsanf�nge haben den Wert true. Ortsenden haben den Wert false.
Eine Innerorts-Situation wird erkannt, wenn auf der Karte die isBuiltUp-Flag gesetzt ist.
	
\spec SwMS_Innodrive2_PSD_117
\ingroup pathRouter_tools
*/
bool_T		prtGetBuiltUpArea(			IN const	pathRouterMemory_T			*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	uint16_T					 index,					/**<Array-Index*/
										OUT			prtBuiltUpArea_T			*builtUpArea		  	/**<builtUpArea am angegeben index*/
										);
	
/** \brief Gibt Position und Wert des Dynamikevents mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Dynamikevents sind Autobahnauffahrten oder Spuranzahlerh�hungen.

\spec SwMS_Innodrive2_PSD_87
\ingroup pathRouter_tools
*/
bool_T		prtGetDynamicEvent(			IN const	pathRouterMemory_T			*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	uint16_T					 index,					/**<Listenindex*/
										OUT			prtDynamicEvent_T			*dynamicEvent			/**<Dynamikevent*/
										);


/** \brief Gibt Position und Wert des OnlineSpeed-Attributs mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
\spec SwMS_Innodrive2_PSD_94
\ingroup pathRouter_tools
*/
bool_T		prtGetOnlineSpeed(			IN const	pathRouterMemory_T			*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	uint16_T					 index,					/**<Listenindex*/
										OUT			prtSpeedLimit_T				*onlineSpeed			/**<Online-Geschwindigkeitsinformation */
										);


/** \brief Wenn die aktuelle Position auf einem "isBuiltUp"-Segment liegt  ODER das aktuelle Tempolimit kleiner als ein Applikationsparameter ist, ist die Umgebung Innerorts.
\spec SwMS_Innodrive2_PSD_179
\ingroup pathRouter_tools
*/
bool_T		prtIsLimitInBuiltUpArea(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globaler Parametersatz*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	prtSpeedLimit_T		*speedLimit,			/**<Tempolimit*/
										OUT			bool_T				*isBuiltUpArea			/**<R�ckgabewert: Ortschaft ja oder nein.*/
										);


/** \brief Wenn die aktuelle Position auf einem "isBuiltUp"-Segment liegt  UND das aktuelle Tempolimit kleiner als ein Applikationsparameter ist, ist die Umgebung Innerorts.

\spec SwMS_Innodrive2_PSD_179
*/
bool_T		prtIsBuiltUpAreaInLowLimit(	IN const	parameterSetCtrl_T	*parameterSet,			/**<Globaler Parametersatz*/
										IN const	pathRouterMemory_T	*pathRouterMemory,		/**<Persistente Daten des pathRouter, die nur im Control-Task verf�gbar sind.*/
										IN const	prtBuiltUpArea_T	*builtUpArea,			/**<Bebauungsinformation*/
										OUT			bool_T				*isBuiltUpArea			/**<R�ckgabewert: Ortschaft ja oder nein.*/
										);


/** \brief Gibt die Position der n�chsten Autobahnauffahrt ab der �bergebenen `position` zur�ck.

Falls es keine Autobahnauffahrt im Horizont gibt, wird `rampUpPosition = INVALID_VALUE` zur�ckgegeben.
Die Position der Autobahnauffahrt ist die Stelle, an der die Rampe in die Autobahn einm�ndet.
\spec SwMS_Innodrive2_PSD_89
\ingroup pathRouter_tools
*/
bool_T		prtGetNextDynamicEvent(		IN const	pathRouterMemory_T			*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	real32_T					 position,				/**<Startpositin der Suche*/
										OUT			real32_T					*eventPosition			/**<Position der Autobahnauffahrt*/
										);


/** \brief Ermittelt den aktuell g�ltigen Online-Speed am Punkt `position` auf dem `pathRouterMemory->lastMapPath`.
\spec SwMS_Innodrive2_PSD_96
\ingroup pathRouter_tools
*/
bool_T		prtGetCurrentOnlineSpeed(		IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
											IN const	real32_T				 position,				/**<Zielposition*/
											OUT			prtSpeedLimit_T			*onlineSpeed			/**<Tempolimit an Zielposition*/
											);


/** \brief Ermittelt die Kr�mmung am Punkt `Position` auf `pathRouterMemory->lastMapPath` 
\spec SwMS_Innodrive2_PSD_85
\ingroup pathRouter_api
*/
bool_T		prtGetCurvatureAtPosition(		IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
											IN const	real32_T				 position,				/**<Zielposition*/
											OUT			real32_T				*curvature  			/**<Kr�mmung an Zielposition*/
											);


/** \brief		Ermittelt die Kr�mmung an der angegebenen Position auf dem mapPath
	\ingroup	pathRouter_api */
bool_T				prtInterpolateCurvature(IN	const	mapPath_T				*mapPath,				/**< Interne Datenstruktur des mapPath */
											IN	const	real32_T				 position,				/**< Abgefragte Position */
											OUT			real32_T				*curvature				/**< Kr�mmung an der abgefragten Position */
											);


/** \brief Ermittelt die Steigung am Punkt `Position` auf dem `pathRouterMemory->lastMapPath`.
	
Unbekannte Steigungen (vgl. \ref prtGetSlope()) werden durch St�tzstellen mit Steigung 0.0 ersetzt.
\spec SwMS_Innodrive2_PSD_107
\ingroup pathRouter_api
*/
bool_T		prtGetSlopeAtPosition(			IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
											IN const	real32_T				 position,				/**<Zielposition*/
											OUT			real32_T				*slope  				/**<Steigung an Zielposition*/
											);

	
/** \brief Ermittelt die Stra�eklasse am Punkt `Position` auf dem `pathRouterMemory->lastMapPath`.
	
Falls keine Stra�enklasse gefunden wird, ist der R�ckgabewert `false`

Falls die Stra�enklasse an einer Position hinter dem Ende des eingelesenen mapPaths abgefragt wird,
wird die letzte bekannte Stra�enklasse auf dem mapPath ausgegeben. Grund ist die relativ schnelle Abschaltung des Systems Innodrive2
bei zu niedriger Stra�enklasse.
Die Alternative, die Abschaltung nur bei bekannter Stra�enklasse "Feldweg/Misc" durchzuf�hren, wurde verworfen, damit die Abschaltung auch bei
einem nur kurzen Pfadst�ck auf einem Feldweg sicher erfolgt.

\spec SwMS_Innodrive2_PSD_115
\ingroup pathRouter_api
*/
bool_T		prtGetStreetClassAtPosition(	IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
											IN const	real32_T				 position,				/**<Zielposition*/
											OUT			prtStreetClassValues_T	*streetClass			/**<Stra�enklasse an Zielposition*/
											);

/** \brief Ermittelt das aktuell g�ltige Tempolimit am Punkt `position` auf dem `pathRouterMemory->lastpathRouterMemory->lastMapPath`.
	
\spec SwMS_Innodrive2_PSD_110
\ingroup pathRouter_api
*/
bool_T		prtGetCurrentSpeedLimit(		IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
											IN const	real32_T				 position,				/**<Zielposition*/
											OUT			prtSpeedLimit_T			*speedLimit				/**<Tempolimit an Zielposition*/
											);

/** \brief Ermittelt das n�chste zuk�nftige Tempolimit ab dem Punkt `position` auf dem `pathRouterMemory->lastMapPath`.
\spec SwMS_Innodrive2_PSD_111
\ingroup pathRouter_api
*/
bool_T		prtGetNextSpeedLimit(			IN const	pathRouterMemory_T		*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
											IN const	real32_T				 position,				/**<Zielposition*/
											OUT			prtSpeedLimit_T			*speedLimit				/**<Tempolimit an Zielposition*/
											);



#endif
