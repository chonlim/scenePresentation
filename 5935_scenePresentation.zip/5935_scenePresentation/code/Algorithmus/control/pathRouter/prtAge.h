#ifndef guard_prtAge_h
#define guard_prtAge_h


void		   prtUpdateAge(INOUT		mapAgeFilter_T		*ageFilter,
							IN	const	bool_T				 pathValid,
							IN	const	bool_T				 ageReset
							);


void		 prtGetAgeTicks(IN	const	mapAgeFilter_T		*ageFilter,
							OUT			uint32_T			*ageTicks);


#endif
