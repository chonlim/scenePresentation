#ifndef guard_pathRouterStatic_h
#define guard_pathRouterStatic_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/pathRouterCommon/prtTypeMapping.h"


/** \brief Pr�ft die G�ltigkeit des PSD-Baums, holt Fahrzeugpositions- und GPS-Informationen. 

F�hrt je nach Wert der `mapPathMemory->initFlag` einen der drei folgenden Schritte durch:
- `mapRouteInvalid:   `Initialisiert die Fahrtroute `mapRoute` (\ref prtInitializeMapRoute())
- `mapPathInvalid:    `Initialisiert den Pfad `mapPath`(\ref prtCopyRootTreeState())
- `mapPathInitialized:`�berpr�ft, ob die Fahrzeugposition noch auf der mapRoute liegt und falls ja,
	f�hrt die Fahrtroute fort (\ref prtContinueMapRoute()), �bertr�gt die Attribute in den Pfad \ref prtContinueMapPath() und �bertr�gt die Daten aus den Ringspeichern in die Ausgabestruktur `mapPath_T` \ref prtFinalizeMapPath().
- `mapPathComplete:   `�berpr�ft, ob PSD-Baum, Segment-Id der Fahrzeugposition und Blinker seit dem letzten Zyklus gleich geblieben sind
	und beh�lt in diesem Fall den Pfad bei und setzt die Flag `lowExecutionTime`. 
	�bertr�gt die Daten aus den Ringspeichern in die Ausgabestruktur `mapPath_T` \ref prtFinalizeMapPath().
	
Zum vollst�ndigen Hochlauf, d.h. bis zum `mapPath->valid == true` werden demnach mindestens drei control-Zyklen ben�tigt.
In der Funktion \ref prtFinalizeMapPath() werden die Daten in jedem auf die ausged�nnte Kommunikationsstruktur `mapPath_T` �bertragen.
	
Ein g�ltiger `mapPath` wird in `pathRouterMemory->lastMapPath` gespeichert. Dann ist auch `pathRouterMemory->valid == true`.
Ein ung�ltiger `mapPath` wird durch einen gespeicherten `pathRouterMemory->lastMapPath` ersetzt. Dann ist `pathRouterMemory->valid == false`
und der `mapPath` ist so lange g�ltig (`mapPath->valid == true`), wie die Fahrzeugposition auf dem `mapPath` bleibt.
Anmerkung: Die Entscheidung, ob dieser gehaltene `mapPath` zur L�ngsregelung verwendet wird, f�llt im Modul systemController - \ref systemController_status.

In \ref prtGetMapPathInfo() wird Feedback an den \ref vehicleObserver gesendet.

	Der Kontrollfluss ist im folgenden Diagramm verdeutlicht. Der Fehlerfall wird auch bei einem unerwarteten Fehler (diagFF) durchlaufen.
\dot
digraph pathrouter{
	graph	[ranksep=0.3, rankdir	= "TD", splines="true", fontname=Calibri, fontsize=9];
	node	[shape=box, fontname=Calibri, fontsize=9];
	edge	[color=dodgerblue4,  fontname=Helvetica, fontsize=7];

	start					[label="Start\n->initFlag",												shape="ellipse"];
	end						[label="Ende\ninitFlag->\nmapPath.valid->\nlowExecutionTime->",				shape="ellipse"];

	psd_check				[label="PSD Daten OK?",												shape="diamond"];
	switch1					[label="switch initFlag",												shape="diamond"];
	position_check			[label="Position auf Route?",										shape="diamond"];
	treeChange_check		[label="Baum/Position/Blinker\nge�ndert?",	fontsize=8				shape="diamond"];
	complete_check			[label="Pfad vollst�ndig?",											shape="diamond"];

	initRoute				[label="Route initialisieren\ninitFlag= mapPathInvalid\nmapPath.valid= false"];
	initPath				[label="Pfad initialisieren\ninitFlag= mapPathInitialized\nmapPath.valid= false"];
	buildRoute				[label="Route weiterbauen"];
	buildPath				[label="Pfad weiterbauen"];
	complete				[label="initFlag= mapPathComplete\nmapPath.valid= statusOK"];
	notComplete				[label="initFlag= mapPathInitialized\nmapPath.valid= statusOK"];
	idle					[label="Pfad beibehalten\ninitFlag= mapPathComplete\nmapPath.valid= true\n lowExecutionTime= true"];
	error					[label="Fehler\ninitFlag= mapRouteInvalid\nmapPath.valid= false"];

	start			-> psd_check

	psd_check		-> switch1				[label="ja"];
	psd_check		-> error				[label="nein"];

	switch1			-> initRoute			[label="mapRouteInvalid"];
	switch1			-> initPath				[label="mapPathInvalid"];
	switch1			-> position_check		[label="mapPathInitialized"];
	switch1			-> treeChange_check		[label="mapPathComplete"];

	treeChange_check -> position_check		[label="ja"];
	treeChange_check -> idle				[label="nein"];

	position_check	-> initRoute			[label="nein"];
	position_check	-> buildRoute			[label="ja"];

	complete_check	-> complete				[label="ja"];
	complete_check	-> notComplete			[label="nein"];

	buildRoute		-> buildPath			[];
	buildPath		-> complete_check		[];

	initRoute		-> end					[];
	initPath		-> end					[];
	complete		-> end					[];
	notComplete		-> end					[];
	idle			-> end					[];
	error			-> end					[];

	{rank=same; initRoute initPath buildPath idle error}
	{rank=same; position_check treeChange_check}
}
\enddot

\spec SwMS_Innodrive2_PSD_175

\ingroup pathRouter_step
*/
static bool_T	prtStep(		IN	const	vehicleState_T		*vehicleState,			/**<Ausgabe des vehicleObserver*/
								INOUT		pathRouterMemory_T	*pathRouterMemory,		/**<persistente Daten des pathRouter*/
								OUT			mapPathInfo_T		*vobsMapPathInfo,		/**<Struktur des vehicleObserver f�r Feedback vom pathRouter*/
								OUT			mapPath_T			*mapPath  				/**<Ausgabe des pathRouter*/
								);
	

/** \brief Dummy-Funktion f�hrt zur konstant-Haltung der Laufzeit solange Api-Aufrufe durch, bis die Z�hler der parametrierbaren Maximalzahl entsprechen.
\ingroup pathRouter_caching
\spec SwMS_Innodrive2_PSD_119
*/
static void	prtDummyApiCalls(	IN const	parameterSetCtrl_T	*parameterSet,			/**<globale Parameter*/
								INOUT		uint8_T				*nSegmentCalls,			/**<Z�hler f�r Api-Aufrufe*/
								INOUT		uint8_T				*nSpeedLimitCalls,		/**<Z�hler f�r Api-Aufrufe*/
								INOUT		uint8_T				*nAttributeCalls  		/**<Z�hler f�r Api-Aufrufe*/
								);
#endif
