#include "control/pathRouter/prtHeading.h"
#include "control/pathRouter/prtPrepare.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "common/pathRouterCommon/pathRouter_private.h"

/*lint -esym(9045, struct _exception) (Note -- non-hidden definition of type 'struct _exception' [MISRA 2012 Directive 4.8, advisory])*/
#include <math.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtHeading)


bool_T	prtFilterHeadingCorrection(	IN const	parameterSetCtrl_T			*parameterSet,	
									IN const	mapPath_T					*mapPath,		
									IN const	mapSegmentRing_T			*segmentRing,	
									IN const	mapRawVehiclePosition_T		*rawPosition,
									IN const	uint16_T					 newPosition,
									IN const	real32_T					 velocity,
									INOUT		mapHeadingFilter_T			*headingFilter)
{
	real32_T headingInterpolation;
	real32_T correctionSign, newCorrection;
	uint16_T oldPosition;
	bool_T isOldPositionOnPath;
	
	diagFF(mapPath->valid);

	isOldPositionOnPath = prtFindDistanceOnPath(segmentRing, &headingFilter->rawPosition, velocity, &oldPosition);

	if (isOldPositionOnPath && oldPosition >= mapPath->info.gpsInfo.position && headingFilter->isInitialized)
	{
		/*Die vorhandene Korrektur gegen Null zur�ckschleifen*/
		correctionSign = headingFilter->correction >= 0.0f ? +1.0f : -1.0f;
		headingFilter->correction *= correctionSign;
		headingFilter->correction = max(0.0f, headingFilter->correction - parameterSet->pathRouter.headingCorrectionGradient);
		headingFilter->correction *= correctionSign;

		/*Neue Korrektur aus Abweichung von berechneter und gespeicherter Heading*/
		diagFF(prtGetHeadingAtPosition(mapPath, mapPath->positionZero + (real32_T)oldPosition, &headingInterpolation));

		newCorrection = headingInterpolation - headingFilter->reference;
		
		/*Korrektur auf Intervall [-180; 180] wrappen*/
		newCorrection = fmodf(newCorrection, 360.0f);

		if(newCorrection < -180.0f)	{ newCorrection += 360.0f; }
		if(newCorrection > +180.0f) { newCorrection -= 360.0f; }

		diagFNaN(newCorrection);

		headingFilter->correction += newCorrection;
	}
	else
	{
		/*Filter initialisieren*/
		headingFilter->correction = 0.0f;
		headingFilter->isInitialized = true;
	}

	/*Referenzwert f�r den n�chsten Zeitschritt speichern*/
	diagFF(prtGetHeadingAtPosition(mapPath, mapPath->positionZero + (real32_T)newPosition, &headingFilter->reference));
	headingFilter->rawPosition = *rawPosition;

	diagFNaN(headingFilter->correction);

	return true;
}


typedef struct _prtCurvature {
	real32_T curvature;
	real32_T position;
} prtCurvature_T;    /**< Groesse der Struktur = 12 Bytes */


bool_T		prtGetHeadingAtPosition(IN const mapPath_T		*mapPath,
									IN const real32_T		 Position,
									OUT		 real32_T		*gpsHeading)
{
	prtBaseGPS_T baseGps;
	prtCurvature_T currentCurvature, nextCurvature;
	curvatureIterator_T curvatureIterator;
	prtBranchAngle_T currentBranchAngle;
	real32_T currentHeading, curvatureSum;
	uint16_T index;
	bool_T curvatureValid;
	bool_T continueLoop;

	/*G�ltigkeit von mapPath und GPS-Position*/
	*gpsHeading = INVALID_VALUE;
	if (!prtGetBaseGps(mapPath, &baseGps)  ||  Position < baseGps.position)
	{
		return false;
	}

	currentHeading = baseGps.heading;
	curvatureSum = 0.0f;

	diagFF(prtGetCurvatureIterator(mapPath, &curvatureIterator));
	diagFF(prtGetNextCurvature(&curvatureIterator, &curvatureValid, &nextCurvature.position, &nextCurvature.curvature));
	currentCurvature = nextCurvature;

	/*Alle Kr�mmungen zwischen baseGps.position und abgefragter Position*/
	/*Die Laufzeitkonstanz wird zugunsten einer schnelleren Laufzeit aufgegeben. Wenn die abgefragte Position gleich der Fahrzeugposition ist,
	wird dennoch eine relativ konstante Laufzeit erreicht, da die Fahrzeugposition nie weit von der GPS-Referenzposition entfernt ist.*/
	continueLoop = true;
	for (index = 1; index < (uint16_T)mapPATHCURVATURECOUNT && continueLoop; index++)
	{
		currentCurvature = nextCurvature;
		diagFF(prtGetNextCurvature(&curvatureIterator, &curvatureValid, &nextCurvature.position, &nextCurvature.curvature));

		/*Erste Kr�mmung an der baseGps.position. Wird nur einmal eintreten*/
		if (currentCurvature.position <= baseGps.position && baseGps.position < nextCurvature.position)
		{
			currentCurvature.curvature = currentCurvature.curvature + (nextCurvature.curvature - currentCurvature.curvature) * ( baseGps.position - currentCurvature.position ) / (nextCurvature.position - currentCurvature.position);
			currentCurvature.position = baseGps.position;
			continueLoop = false;
		}
	}

	continueLoop = true;
	for (index = index; index < (uint16_T)mapPATHCURVATURECOUNT && continueLoop; index++)
	{
		/*Letzte Kr�mmung an der abgefragte Position. Wird nur einmal eintreten*/
		if (currentCurvature.position < Position  &&  Position <= nextCurvature.position)
		{
			nextCurvature.curvature = currentCurvature.curvature + (nextCurvature.curvature - currentCurvature.curvature) * ( Position - currentCurvature.position ) / (nextCurvature.position - currentCurvature.position);
			nextCurvature.position = Position;
			continueLoop=false;
		}
		
		/*Aufaddieren der Kr�mmungen zwischen baseGps.position und abgefragter Position*/
		if (baseGps.position < nextCurvature.position  &&  nextCurvature.position <= Position && curvatureValid)
		{
			curvatureSum += (currentCurvature.curvature + nextCurvature.curvature) * (nextCurvature.position - currentCurvature.position);
		}

		currentCurvature = nextCurvature;
		diagFF(prtGetNextCurvature(&curvatureIterator, &curvatureValid, &nextCurvature.position, &nextCurvature.curvature));
	}

	/*Umrechnung Radian zu Grad und Faktor 0.5 von der Trapezintegration*/
	/*Beachte: Kr�mmungen sind linksweisend, branchAngles und Heading sind rechtsweisend, daher das Vorzeichen*/
	currentHeading -= (90.0f / defPIf) * curvatureSum;


	/*Alle BranchAngles zwischen baseGps.position und abgefragter Position*/
	for (index = 0; index < (uint16_T)mapINFOBRANCHANGLECOUNT; index++)
	{
		(void)prtGetBranchAngle(mapPath, index, &currentBranchAngle);
		if (baseGps.position < currentBranchAngle.position  &&  currentBranchAngle.position <= Position)
		{
			currentHeading += currentBranchAngle.angle;
		}
	}

	/*heading auf Intervall [0;360] wrappen*/
	while (currentHeading < 0.0f)	{ currentHeading += 360.0f; }
	while (currentHeading > 360.0f) { currentHeading -= 360.0f; }

	*gpsHeading = currentHeading;
	return true;
}

