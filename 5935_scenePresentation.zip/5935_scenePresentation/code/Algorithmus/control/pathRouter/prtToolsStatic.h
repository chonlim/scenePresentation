#ifndef guard_prtToolsStatic_h
#define guard_prtToolsStatic_h

#include "control/control.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"
#include "common/pathRouterCommon/pathRouter_interface.h"


/**\brief Verschiebt eine reelle Position ins Fahrzeugkoordinatensystem anhand der Position der Pfadwurzel.
\spec SwMS_Innodrive2_PSD_152
\ingroup pathRouter_tools
*/
static real32_T scalePosition(		IN const real32_T				positionZero,
									IN const uint16_T				position
									);

/** \brief Berechnet die Position im Fahrzeug-Koordinatensystem aus Segmen-ID und Offset
\ingroup pathRouter_tools
*/
static bool_T	prtConvertPosition(	IN const	mapPathMemory_T		*mapPathMemory,
									IN const	ringId_T			 segmentRingId,
									IN const	uint8_T				 offset,
									OUT			real32_T			*position
									);


/** \brief Gibt an, ob die �bergebene `position` in einer builtUpArea liegt.

R�ckgabewert ist falsch, wenn die zur �bergebenen `position` keine Daten vorliegen.
\ingroup pathRouter_tools
*/
static bool_T	prtGetBuiltUpAtPosition(IN const	pathRouterMemory_T			*pathRouterMemory,		/**<Struktur der linearisierten Streckendaten*/
										IN const	real32_T					 position,				/**<Positin der Abfrage*/		
										OUT			bool_T						*isBuiltUp				/**<Ortschaftsinformation an dieser Stelle*/
										);


#endif
