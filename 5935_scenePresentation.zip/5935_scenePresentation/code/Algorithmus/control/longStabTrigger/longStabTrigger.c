#include "longStabTrigger.h"

/*lint -esym(9045, struct _exception)*/
#include <math.h>

#include "common/longStabTriggerCommon/longStabTrigger_private.h"

#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/pathRouterCommon/prtDataInterface.h"
#include "common/systemControllerCommon/sysTools.h"
#include "control/longController/lnclTools.h"

#include "control/parameterSet/parameterSetCtrl.h"


void		longStabTrigger(MEMORY		triggerMemory_T			*triggerMemory,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	mapPath_T				*mapPath,
							IN	const	systemControl_T			*systemControl,
							IN	const	longControl_T			*longControl,
							OUT			longTrigger_T			*longTrigger)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	uint32_T		tickCount;
	bool_T			trafficPresent;
	real32_T		velocity;

	uint8_T			rerouteCount;
	uint8_T			posResetCount;

	bool_T			autoMode;
	real32_T		setVelocity;
	real32_T		setPosition;
	sysLongMode_T	longMode;

	real32_T		plannedVelocity, difference;

	bool_T			triggered = false;


	/* Relevante Informationen vom vehicleObserver abfragen */
	vobsGetTickCount( vehicleState,
					 &tickCount);

	vobsGetTrafficTarget( vehicleState,
						 &trafficPresent,
						  NULL,
						  NULL,
						  NULL);

	vobsGetVelocity( vehicleState,
					&velocity);


	/* Relevante Informationen vom pathRouter abfragen */
	rerouteCount = prtGetRerouteCount(mapPath);

	posResetCount = prtGetPositionResetCount(mapPath);


	/* Relevante Informationen vom systemController abfragen */
	sysGetAutoModeInfo( systemControl,
					   &autoMode,
					    NULL);

	sysGetCurrentSetSpeed( systemControl,
						  &setPosition,
						  &setVelocity);


	/* Relevante Informationen vom systemController abfragen */
	sysGetLongMode( systemControl,
				   &longMode);


	/* Geplante Geschwindigkeit vom longController abfragen */
	lnclGetPlannedVelocity( longControl,
						   &plannedVelocity);


	/* Auswerten der Triggerbedingungen */
	if(triggerMemory->trafficPresent	!= trafficPresent)		{ triggered = true; } /*lint !e697 (Warning -- Quasi-boolean values should be equality-compared only with 0)*/
	if(triggerMemory->rerouteCount		!= rerouteCount)		{ triggered = true; }
	if(triggerMemory->posResetCount		!= posResetCount)		{ triggered = true; }
	if(triggerMemory->autoMode			!= autoMode)			{ triggered = true; } /*lint !e697 (Warning -- Quasi-boolean values should be equality-compared only with 0)*/
	if(triggerMemory->longMode			!= longMode)			{ triggered = true; }

	difference = triggerMemory->setPosition - setPosition;
	if(fabsf(difference) > 1e-6f)	{ triggered = true; }
	difference = triggerMemory->setVelocity - setVelocity;
	if(fabsf(difference) > 1e-6f)	{ triggered = true; }
	if(velocity <= paramSet->longStabTrigger.prioVelocity)		{ triggered = true; }

	if(   velocity >= plannedVelocity + paramSet->longStabTrigger.maxPlanTolerance
	   || velocity <= plannedVelocity + paramSet->longStabTrigger.minPlanTolerance) {
		triggered = true;
	}


	/* Ggf. muss der Trigger-Tick-Count aktualisiert werden */
	if(triggered) {
		triggerMemory->priorityTick		= tickCount;
	}


	/* Speicher aktualisieren */
	triggerMemory->trafficPresent	= trafficPresent;
	triggerMemory->rerouteCount		= rerouteCount;
	triggerMemory->posResetCount	= posResetCount;
	triggerMemory->autoMode			= autoMode;
	triggerMemory->longMode			= longMode;
	triggerMemory->setPosition		= setPosition;
	triggerMemory->setVelocity		= setVelocity;


	/* Ausgabe */
	longTrigger->priorityTick		= triggerMemory->priorityTick;
}


