#ifndef guard_longStabTrigger_h
#define guard_longStabTrigger_h

#include "control/control.h"

#include "common/longStabTriggerCommon/longStabTrigger_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/pathRouterCommon/pathRouter_interface.h"
#include "common/systemControllerCommon/systemController_interface.h"
#include "control/longController/longController_interface.h"

/**\brief Triggert die Neuberechnung der Stabilisierungsebene im Strategy-Task
\spec SwMS_Innodrive2_Planning_52
*/
void		longStabTrigger(MEMORY		triggerMemory_T			*triggerMemory,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	mapPath_T				*mapPath,
							IN	const	systemControl_T			*systemControl,
							IN	const	longControl_T			*longControl,
							OUT			longTrigger_T			*longTrigger
							);


#endif
