#ifndef guard_longController_h
#define guard_longController_h

#include "control/control.h"
#include "longController_interface.h"

#include "common/vehicleModel/vehicleModel_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/systemControllerCommon/systemController_interface.h"
#include "common/longTorquePlannerCommon/longTorquePlanner_interface.h"
#include "common/systemControllerCommon/systemController_interface.h"





/**	\brief	Step-Funktion der L�ngssteuerung 

\spec SwMS_Innodrive2_Output_66 (G�ltigkeit)

\ingroup longController
*/
void		 longController(INOUT		longMemory_T			*longMemory,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	systemControl_T			*systemControl,
							IN	const	longTorque_T			*longTorque,
							OUT			longControl_T			*longControl,
							OUT			longControlInfo_T		*longControlInfo,
							OUT			longControlStatus_T		*longControlStatus);





#endif
