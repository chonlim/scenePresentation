#ifndef guard_lnclStepStatic_h
#define guard_lnclStepStatic_h


/**\brief Fragt die L�ngsplanung vom Modul longTorquePlanner zu verschiedenen Zeitpunkten ab.

Zeitpunkt T0:		Planung zum aktuellen Zeitpunkt
Ta, Tg, Tc, Tv :	Individuelle Vorgriffszeiten f�r die Regelanforderung der Gr��en Beschleunigung, Gang, Segeln, Geschwindigkeit.

\ingroup longController
*/
static bool_T				lnclGetPlanning(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	vehicleState_T		*vehicleState,			/**<Aktueller Fahrzeugzustand*/
											IN	const	longTorque_T		*longTorque,			/**<Pr�diktion*/
											OUT			vmState_T			*vmState,				/**<aktuelle Fahrdynamik (T0)*/
											OUT			bool_T				*coastNow,				/**<aktuelle Segelanforderung (T0)*/
											OUT			uint8_T				*gearNow,				/**<aktuelle Ganganforderung (T0)*/
											OUT			vmState_T			*vmAdvance,				/**<vorgezogene Fahrdynamik (T0 + Ta)*/
											OUT			forceState_T		*fmAdvance,				/**<vorgezogener Zugkraftzustand (T0 + Ta)*/
											OUT			real32_T			*maxAcceleration,		/**<vorgezogene maximale Beschleunigung (T0 + Ta)*/
											OUT			real32_T			*minAcceleration,		/**<vorgezogene minimale Beschleunigung (T0 + Ta)*/
											OUT			uint8_T				*gearPredicted,			/**<vorgezogene Ganganforderung (T0 + Tg)*/
											OUT			bool_T				*coastThen,				/**<vorgezogene Segelanforderung (T0 + Tc)*/
											OUT			vmState_T			*vmPred					/**<pr�diziertde Fahrdynamik (T0 + Tv)*/
											);


/**\brief Entprellt die Segelanforderung.

Der Segeleinstieg wird verz�gert, der Segelaustieg wird vorgezogen.
Eine Segelanforderung wird nur gestellt, wenn sowohl aktuell, als auch in Zukunft (Tc) Segeln geplant ist und
die Entprellzeit f�r den Segeleinstieg abgelaufen ist.

\ingroup longController
*/
static void			 lnclFilterCoastRequest(INOUT		uint16_T			*coastTicks,			/**<Z�hler f�r Zeitschritte mit Segelanforderung*/
											IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	bool_T				 coastNow,				/**<aktuelle Segelanforderung (T0)*/
											IN	const	bool_T				 coastThen,				/**<pr�dizierte Segelanforderung (T0 + Tc)*/
											OUT			bool_T				*coastRequest			/**<Segelanforderung*/
											);


/**\brief W�hlt einen geeigneten Wert f�r den Beschleunigungsoffset im Segeln aus.
\ingroup longController
*/
static void				lnclCalcCoastOffset(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	vehicleState_T		*vehicleState,			/**<Aktueller Fahrzeugzustand*/
											IN	const	forceState_T		 fmAdvance,				/**<vorgezogener Zugkraftzustand (T0 + Ta)*/
											IN	const	bool_T				 coastRequest,			/**<Segelanforderung*/
											OUT			bool_T				*coastSelected,			/**<Segeln geplant*/
											OUT			real32_T			*coastOffset,			/**<Offset auf Beschleunigungsanforderung im Segelbetrieb*/
											OUT			bool_T				*coastValid				/**<Segelanforderung g�ltig*/
											);


/**\brief Begrenzt Geschwindigkeit und Beschleunigung aus der Planung.

Die R�ckschleife der Reglerbeschleunigung (loopAcceleration) findet mit der Beschleunigungsplanung zum aktuellen Zeitpunkt statt.
Die Geschwindigkeitsanforderung ist hier bereits um (Tv) vorgezogen
Die geplante Geschwindigkeit wird zum aktuellen Zeitpunkt ausgegeben, ist aber nur zur Systeminternen Verwendung gedacht.

\ingroup longController
*/
static void				   lnclCalcDynamics(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	vmState_T			*vmState,				/**<aktuelle Fahrdynamik (T0)*/
											IN	const	vmState_T			*vmPred,				/**<pr�diziertde Fahrdynamik (T0 + Tv)*/
											OUT			real32_T			*loopAcceleration,		/**<aktuelle Beschleunigung (T0)*/
											OUT			real32_T			*velocity,				/**<pr�dizierte Geschwindigkeit (T0 + Tv)*/
											OUT			real32_T			*plannedVelocity		/**<Geplante aktuelle Geschwindigkeit (T0)*/
											);


/**\brief Berechnet die Beschleunigungsanforderung.

Basis der Beschleunigungsanforderung (longAcceleration) ist die vorgezogene geplante Beschleunigung (advanceAccel, T0 + Ta).

Der Rahmen, in dem sich die Beschleunigungsanforderung �ndern darf setzt sich zusammen aus 
der �nderung der aktuell geplanten Beschleunigung (loopAcceleration, T0) und
einem applizierbaren "Sockelruck" (positiv, wie negativ).

Bei Sperrung der Gangschnittstelle wird die entsprechende Maximalbeschleunigung ber�cksichtigt.
Im Segelbetrieb wird der Zus�tzliche Beschleunigungsoffset hinzugerechnet.

\ingroup longController
*/
static void			 lnclFilterAcceleration(INOUT		real32_T			*filterLoop,			/**<Speicher aktuelle Beschleunigung (T0)*/
											INOUT		real32_T			*filterAdvance,			/**<Speicher vorgezogene Beschleunigung*/
											IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	real32_T			 loopAcceleration,		/**<aktuelle Beschleunigung (T0)*/
											IN	const	real32_T			 advanceAccel,			/**<vorgezogene Beschleunigung (T0 + Ta)*/
											IN	const	real32_T			 lockAcceleration,		/**<Maximale Beschleunigung bei gesperrter Gangschnittstelle*/
											IN	const	real32_T			 coastOffset,			/**<Offset auf Beschleunigungsanforderung im Segelbetrieb*/
											OUT			real32_T			*longAcceleration		/**<Beschleunigungsanforderung*/
											);


/**\brief W�hlt geeignete Parameter f�r das Beschleunigungs-Tolernaz-Band aus.

Das Toleranzband h�ngt vom Segelbetrieb ab.

\ingroup longController
*/
static void				  lnclCalcTolerance(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	systemControl_T		*systemControl,			/**<Systemzustand (Aktivierung, Setzgeschwindigkeit)*/
											IN	const	forceState_T		 fmAdvance,				/**<vorgezogene Zugkraftzustand (T0 + Ta)*/
											IN	const	real32_T			 acceleration,			/**<Beschleunigungsanforderung*/
											IN	const	real32_T			 minAcceleration,		/**<vorgezogene minimale Beschleunigung (T0 + Ta)*/
											IN	const	real32_T			 maxAcceleration,		/**<vorgezogene maximale Beschleunigung (T0 + Ta)*/
											IN	const	bool_T				 coastSelected,			/**<Segeln geplant*/
											IN	const	real32_T			 coastOffset,			/**<Offset auf Beschleunigungsanforderung im Segelbetrieb*/
											OUT			real32_T			*toleranceLower,		/**<Anforderung Beschleunigungstoleranz unten*/
											OUT			real32_T			*toleranceUpper			/**<Anforderung Beschleunigungstoleranz oben*/
											);


/**\brief Z�hlt die Zeitschritte seit Aktivierung der Funktion

Brake Only Mode z�hlt als aktiver Modus (Anforderungen sollen ausgegeben werden.)
Solange die Funktion nicht aktiviert ist, bleibt der Z�hler 0.

\spec SwMS_Innodrive2_Output_85
\spec SwMS_Innodrive2_Output_86
\ingroup longController
*/
static void	  lnclCountTicksSinceActivation(INOUT		uint16_T	*activationTicks,				/**<Z�hler f�r Zeitschritte mit aktivem System*/			
											IN	const	sysStatus_T	 status							/**<Aktivierungszustand des Systems*/
											);


/**\brief Berechnet die Ruckbegrenzung

Der erlaubte Ruck ist bei Aktivierung des Systems 0 und wird dann auf den applizierten Wert aufgerampt.

\spec SwMS_Innodrive2_Output_86
\ingroup longController
*/
static void					   lnclCalcJerk(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	bool_T				 coastSelected,			/**<Segeln geplant*/
											IN	const	uint16_T			 activationTicks,		/**<Z�hler f�r Zeitschritte mit aktivem System*/
											OUT			real32_T			*jerkPositive,			/**<Anforderung Positivruck*/
											OUT			real32_T			*jerkNegative			/**<Anforderung Negativruck*/
											);


/**\brief Berechnet die Wunsch�bersetzung aus dem relevanten Gang.

Der relevante Gang (relevatGear) ist das Minimum aus aktuellem Gang (geaNow, T0) und vorhergesagtem Gang (gearPredicted, Tg).
Die Ganganforderung kann  unterdr�ckt werden
durch das Fahrzeugmodell oder im Segelbetrieb oder in einem applizierbaren Zeitraum nach aktivierung des Systems.
Die Umrechnung in eine �bersetzung findet auf Basis des Fahrzeugmodells statt.

\spec SwMS_Innodrive2_Output_83
\spec SwMS_Innodrive2_Output_85
\ingroup longController
*/
static bool_T	  lnclCalcTransmissionRatio(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	vehicleModel_T		*vehicleModel,			/**<Fahrzeugmodell*/
											IN	const	vehicleState_T		*vehicleState,			/**<Aktueller Fahrzeugzustand*/
											IN	const	uint16_T			 activationTicks,		/**<Z�hler f�r Zeitschritte mit aktivem System*/
											IN	const	uint8_T				 gearNow,				/**<aktuelle Ganganforderung (T0)*/
											IN	const	uint8_T				 gearPredicted,			/**<pr�dizierte Ganganforderung (T0+VPT)*/
											IN	const	bool_T				 coastRequest,			/**<Segelanforderung*/
											IN	const	bool_T				 gearLock,				/**<Sperrung der Gangschnittstelle laut vehicleObserver*/
											OUT			real32_T			*transmissionRatio,		/**<Ganganforderung, codiert als Wunsch�bersetzung*/
											OUT			bool_T				*transmissionValid,		/**<Ganganforderung g�ltig*/
											OUT			uint8_T				*relevantGear,			/**<Ganganforderung*/
											OUT			bool_T				*isGearValid			/**<Ganganforderung g�ltig*/
											);


/**\brief Schr�nk (nur) im Brake-Only Modus die Beschleunigungsanforderung ein.
\ingroup longController
*/
static void		   lnclLimitBomAcceletation(IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	sysStatus_T			 status,				/**<Aktivierungszustand des Systems*/
											IN	const	real32_T			 loopAcceleration,		/**<aktuelle Beschleunigung (T0)*/
											INOUT		real32_T			*longAcceleration,		/**<Beschleunigungsanforderung*/
											INOUT		real32_T			*velocity,				/**<Geschiwndigkeitsanforderung*/
											INOUT		real32_T			*toleranceUpper,		/**<Anforderung Beschleunigungstoleranz oben*/
											INOUT		real32_T			*toleranceLower,		/**<Anforderung Beschleunigungstoleranz unten*/
											INOUT		bool_T				*coastValid,			/**<Segelanforderung g�ltig*/
											INOUT		bool_T				*transmissionValid		/**<Ganganforderung g�ltig*/
											);


/**\brief Schr�nkt (nur) bei Fahrt mit Elektromotor die Beschleunigungsanforderung ein.

Die Funktion unterscheidet zwischen vom Fahrer gew�hltem Elektromodus und einer automatischen Auswahl durch das Fahrzeug.

\spec SwMS_Innodrive2_Output_63
\ingroup longController
*/
static bool_T lnclLimitElectricAcceleration(INOUT		real32_T			*longAcceleration,		/**<Beschleunigungsanforderung*/
											IN	const	parameterSetCtrl_T	*paramSet,				/**<Applikationsparameter*/
											IN	const	vehicleState_T		*vehicleState			/**<Aktueller Fahrzeugzustand*/
											);

#endif																								

