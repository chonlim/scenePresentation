#include "longController.h"
#include "lnclTools.h"

#include "longController_private.h"


void		  lnclGetLongTarget(IN	const	longControl_T		*longControl,
								OUT			real32_T			*targetVelocity,
								OUT			real32_T			*targetAcceleration,
								OUT			real32_T			*toleranceUpper,
								OUT			real32_T			*toleranceLower,
								OUT			real32_T			*jerkPositive,
								OUT			real32_T			*jerkNegative)
{
	*targetVelocity		= longControl->velocity;
	*targetAcceleration	= longControl->acceleration;
	*toleranceUpper		= longControl->tolerance.upper;
	*toleranceLower		= longControl->tolerance.lower;
	*jerkPositive		= longControl->jerk.positive;
	*jerkNegative		= longControl->jerk.negative;
}


void		lnclGetPtrainTarget(IN	const	longControl_T		*longControl,
								OUT			bool_T				*coastValid,
								OUT			bool_T				*coastRequest,
								OUT			bool_T				*transmissionValid,
								OUT			real32_T			*transmissionRatio)
{
	*coastValid			= longControl->coastValid;
	*coastRequest		= longControl->coastRequest;
	*transmissionRatio	= longControl->transmissionRatio;
	*transmissionValid	= longControl->transmissionValid;
}


void	 lnclGetPlannedVelocity(IN	const	longControl_T		*longControl,
								OUT			real32_T			*plannedVelocity)
{
	*plannedVelocity	= longControl->plannedVelocity;
}
