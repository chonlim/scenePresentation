#ifndef guard_longController_private_h
#define guard_longController_private_h

#include "control/longController/longController_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */




struct _longControl {
	real32_T acceleration;               /**< Sollbeschleunigung mit applizierbarem Vorlauf Zeitpunkt (T + acceleration.predTime)[m/s²] */
	real32_T velocity;                   /**< Sollgeschwindigkeit mit applizierbarem Vorlauf (T + velocity.predTime)[m/s] */
	real32_T plannedVelocity;            /**< Prädizierte Geschwindigkeit zum aktuellen Zeitpunk (T)[m/s] */
	struct _longControl_tolerance {
		real32_T upper;                  /**< Zulässige Regelabweichung nach oben[m/s²] */
		real32_T lower;                  /**< Zulässige Regelabweichung nach unten[m/s²] */
	} tolerance;
	struct _longControl_jerk {
		real32_T positive;               /**< Positiver Gradient der Sollbeschleunigung[m/s³] */
		real32_T negative;               /**< Negativer Gradient der Sollbeschleunigung[m/s³] */
	} jerk;
	bool_T coastValid;                   /**< Ist die Segelanforderung gültig? */
	bool_T coastRequest;                 /**< Segelanforderung */
	bool_T transmissionValid;            /**< Ist die Wunschübersetzung gültig? */
	real32_T transmissionRatio;          /**< Wunschübersetzung[1] */
} ;                                      /**< Groesse der Struktur = 36 Bytes */

struct _longMemory {
	uint16_T coastTicks;                 /**< Zeitschritt-Zähler für den Nachlauf, bevor eine Segelanforderung durchgestellt wird */
	real32_T lastLoop;                   /**< t0-Beschleunigung, die im letzten Zeitschritt gefordert war */
	real32_T lastAdvance;                /**< Vorgezogene Beschleunigung, die im letzten Zeitschritt ausgegeben wurde */
	uint16_T activationTicks;            /**< Zeitschritt-Zähler nach Systemaktivierung */
} ;                                      /**< Groesse der Struktur = 16 Bytes */


/*lint -restore */

#endif
