#ifndef guard_lnclTools_h
#define guard_lnclTools_h


	void	  lnclGetLongTarget(IN	const	longControl_T		*longControl,				/**< interne Datenstruktur der L�ngssteuerung */
								OUT			real32_T			*targetVelocity,			/**< Sollgeschwindigkeit */
								OUT			real32_T			*targetAcceleration,		/**< Sollbeschleunigung */
								OUT			real32_T			*toleranceUpper,			/**< zul�ssige positive Abweichung von der Sollbeschleunigung */
								OUT			real32_T			*toleranceLower,			/**< zul�ssige negative Abweichung von der Sollbeschleunigung */
								OUT			real32_T			*jerkPositive,				/**< positiver zul�ssiger Beschleunigungsgradient */
								OUT			real32_T			*jerkNegative				/**< negativer zul�ssiger Beschleunigungsgradient */
								);


	void	lnclGetPtrainTarget(IN	const	longControl_T		*longControl,				/**< interne Datenstruktur der L�ngssteuerung */
								OUT			bool_T				*coastValid,				/**< Ist die Segel-/Schubanforderung g�ltig? */
								OUT			bool_T				*coastRequest,				/**< Soll eine Segelanforderung gesetzt werden? */
								OUT			bool_T				*transmissionValid,			/**< Ist die W�nsch�bersetzung g�ltig? */
								OUT			real32_T			*transmissionRatio			/**< Wunsch�bersetzung */
								);


void	 lnclGetPlannedVelocity(IN	const	longControl_T		*longControl,
								OUT			real32_T			*plannedVelocity
								);


#endif
