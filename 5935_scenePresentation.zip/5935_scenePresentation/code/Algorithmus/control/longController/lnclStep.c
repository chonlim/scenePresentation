#include "longController.h"
#include "lnclStep.h"

#include "longController_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"

#include "common/vehicleModel/vehicleModel.h"
#include "common/longTorquePlannerCommon/lntqTools.h"
#include "common/systemControllerCommon/sysTools.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"

#include "lnclStepStatic.h"

#include "common/platformInterface/pltfDiag.h"

diagDeclareModule(diagModule_lnclStep)


bool_T		 lnclGetControl(INOUT		longMemory_T		*longMemory,
							IN	const	vehicleModel_T		*vehicleModel,
							IN	const	longTorque_T		*longTorque,
							IN	const	systemControl_T		*systemControl,
							IN	const	vehicleState_T		*vehicleState,
							OUT			longControl_T		*longControl,
							OUT			longControlInfo_T	*longControlInfo)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	/*t0*/
	vmState_T		vmState;
	bool_T			coastNow;
	uint8_T			gearNow;
	vmState_T		vmAdvance;
	/*t0+acceleration.predTime*/
	forceState_T	fmAdvance;
	real32_T		maxAcceleration;
	real32_T		minAcceleration;
	/*t0+transRatioAdvance*/
	uint8_T			gearPred;
	/*t0+coastFading.leaveTime*/
	bool_T			coastThen;
	/*t0+velocity.predTime*/
	vmState_T		vmPred;
	/*systemController*/
	sysStatus_T		status;
	/*vehicleObserver*/
	bool_T			requestAllowed;
	bool_T			gearLock;
	real32_T		lockAcceleration;
	/*Segelgr��en*/
	bool_T			coastSelected;
	real32_T		coastOffset;
	/*Beschleunigungsr�ckf�hrung*/
	real32_T		loopAcceleration;
	/*Gangr�ckf�hrung*/
	uint8_T			gearRel;
	bool_T			gearValid;


	/*Planung Abfrangen*/
	diagFF(lnclGetPlanning( paramSet,
						    vehicleState,
						    longTorque,
						   &vmState,
						   &coastNow,
						   &gearNow,
						   &vmAdvance,
						   &fmAdvance,
						   &maxAcceleration,
						   &minAcceleration,
						   &gearPred,
						   &coastThen,
						   &vmPred));

	/* Systemstatus abfragen */
	sysGetLongControlStatus( systemControl, 
							&status);

	vmdlIsGearRequestAllowed(vehicleModel, &requestAllowed);
	/* Abfragen, ob vom vehicleObserver ein Sperren der Gangschnittstelle angefordert wird. */
	if (requestAllowed)
	{
		vobsGetGearLock(vehicleState, &gearLock, &lockAcceleration);
	}
	else
	{
		gearLock = false;
		lockAcceleration = INVALID_VALUE;
	}

	/*Triebstrangzustand*/
	lnclFilterCoastRequest(&longMemory->coastTicks,
						    paramSet,
						    coastNow,
						    coastThen,
						   &longControl->coastRequest);

	lnclCalcCoastOffset( paramSet,
						 vehicleState,
						 fmAdvance,
						 longControl->coastRequest,
						&coastSelected,
						&coastOffset,
						&longControl->coastValid);

	/*Geschwindigkeit, Beschleunigung*/
	lnclCalcDynamics( paramSet,
					 &vmState,
					 &vmPred,
					 &loopAcceleration,
					 &longControl->velocity,
					 &longControl->plannedVelocity);

	lnclFilterAcceleration(&longMemory->lastLoop,
						   &longMemory->lastAdvance,
						    paramSet,
						    loopAcceleration,
							vmAdvance.acceleration,
							lockAcceleration,
							coastOffset,
						   &longControl->acceleration);

	/*Beschleunigungstoleranz*/
	lnclCalcTolerance( paramSet,
					   systemControl,
					   fmAdvance,
					   longControl->acceleration,
					   minAcceleration,
					   maxAcceleration,
					   coastSelected,
					   coastOffset,
					  &longControl->tolerance.lower,
					  &longControl->tolerance.upper);

	/*Aktivierungszustand*/
	lnclCountTicksSinceActivation(&longMemory->activationTicks,
								   status);
	
	/*Ruck*/
	lnclCalcJerk(paramSet,
				 coastSelected,
				 longMemory->activationTicks,
				 &longControl->jerk.positive,
				 &longControl->jerk.negative);

	/*�bersetzung (Gang)*/
	diagFF(lnclCalcTransmissionRatio( paramSet,
									  vehicleModel,
									  vehicleState,
									  longMemory->activationTicks,
									  gearNow,
									  gearPred,
									  longControl->coastRequest,
									  gearLock,
									 &longControl->transmissionRatio,
									 &longControl->transmissionValid,
									 &gearRel,
									 &gearValid));

	/*Begrenzungen*/
	lnclLimitBomAcceletation( paramSet,
							  status,
							  loopAcceleration,
							&longControl->acceleration,
							&longControl->velocity,
							&longControl->tolerance.upper,
							&longControl->tolerance.lower,
							&longControl->coastValid,
							&longControl->transmissionValid);

	diagFF(lnclLimitElectricAcceleration(&longControl->acceleration,
										  paramSet,
										  vehicleState));

	/* Informationen �ber die aktuelle Regelanforderung an den vehicleObserver zur�ckliefern */
	vobsSetLongControlInfo(true,
						   loopAcceleration,
						   gearValid,
						   coastNow ? (uint8_T)gearCoast : gearRel,
						   longControlInfo);

	return true;
}


void			   lnclInit(OUT			longMemory_T		*longMemory,
							OUT			longControl_T		*longControl,
							OUT			longControlInfo_T	*longControlInfo)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	longControl->acceleration		= paramSet->longController.acceleration.fail;
	longControl->velocity			= 0.0f;
	longControl->plannedVelocity	= 0.0f;

	longControl->tolerance.upper	= paramSet->longController.tolerance.upper.off.min;
	longControl->tolerance.lower	= paramSet->longController.tolerance.lower.off.max;

	longControl->jerk.positive		= paramSet->longController.jerk.positive;
	longControl->jerk.negative		= paramSet->longController.jerk.negative;

	longControl->coastRequest		= false;
	longControl->coastValid			= false;

	longControl->transmissionRatio	= INVALID_VALUE;
	longControl->transmissionValid	= false;

	longMemory->coastTicks			= 0u;
	longMemory->lastLoop			= longControl->acceleration;
	longMemory->lastAdvance			= longControl->acceleration;
	longMemory->activationTicks		= 0u;


	/* Init-Werte an der vehicleObserver zur�ckliefern */
	vobsSetLongControlInfo(false,
						   longControl->acceleration,
						   false,
						   gearCoast,
						   longControlInfo);
}


static bool_T				lnclGetPlanning(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	vehicleState_T		*vehicleState,
											IN	const	longTorque_T		*longTorque,
											OUT			vmState_T			*vmState,
											OUT			bool_T				*coastNow,
											OUT			uint8_T				*gearNow,
											OUT			vmState_T			*vmAdvance,
											OUT			forceState_T		*fmAdvance,
											OUT			real32_T			*maxAcceleration,
											OUT			real32_T			*minAcceleration,
											OUT			uint8_T				*gearPredicted,
											OUT			bool_T				*coastThen,
											OUT			vmState_T			*vmPred)
{	
	real32_T	time;
	real32_T	maxTime;

	/* Abfragen der aktuellen Zeit */
	vobsGetTime(vehicleState, &time);


	/* Abfragen des sp�testen Zeitpunkts, f�r den eine Momentenplanung vorliegt */
	diagFF(lntqGetMaxPlanTime( longTorque,
							  &maxTime));


	/* Abfragen des geplanten Fahrzeugzustands zu diesem Zeitpunkt */
	diagFF(lntqGetPredictedState( longTorque,
								   time,
								  vmState,
								  coastNow,
								  gearNow,
								   NULL,
								   NULL,
								   NULL));

	/* Abfragen des geplanten Bewegungszustands f�r die vorgezogene Beschleunigungsanforderung */
	diagFF(lntqGetPredictedState( longTorque,
								  min(time + paramSet->longController.acceleration.predTime, maxTime),
								  vmAdvance,
								  NULL,
								  NULL,
								  fmAdvance,
								  maxAcceleration,
								  minAcceleration));

	/* Abfragen des zuk�nftig geplanten Segelzustands */
	diagFF(lntqGetPredictedState( longTorque,
								  min(time + paramSet->longController.transRatioAdvance, maxTime),
								  NULL,
								  NULL,
								  gearPredicted,
								  NULL,
								  NULL,
								  NULL));

	/* Abfragen des zuk�nftig geplanten Segelzustands */
	diagFF(lntqGetPredictedState( longTorque,
								  min(time + paramSet->longController.coastFading.leaveTime, maxTime),
								  NULL,
								  coastThen,
								  NULL,
								  NULL,
								  NULL,
								  NULL));

	/* Abfragen der zuk�nftig geplanten Geschwindigkeit */
	diagFF(lntqGetPredictedState( longTorque,
								  min(time + paramSet->longController.velocity.predTime, maxTime),
								  vmPred,
								  NULL,
								  NULL,
								  NULL,
								  NULL,
								  NULL));

	return true;
}


static void			 lnclFilterCoastRequest(INOUT		uint16_T			*coastTicks,
											IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	bool_T				 coastNow,
											IN	const	bool_T				 coastThen,
											OUT			bool_T				*coastRequest)
{
	uint16_T ticks;
	bool_T request;

	ticks = *coastTicks;

	/* Der Segeleinstieg wird verz�gert, der Segelaustieg wird vorgezogen */
	if(ticks < paramSet->longController.coastFading.enterTicks) {
		ticks++;
	}

	if(!coastNow || !coastThen) {
		ticks = 0;
	}

	/* Eine Segelanforderung wird erst freigegeben, wenn der Tick-Z�hler vollgelaufen ist */
	request = (ticks == paramSet->longController.coastFading.enterTicks) ? true : false;

	*coastTicks = ticks;
	*coastRequest = request;
}


static void				lnclCalcCoastOffset(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	vehicleState_T		*vehicleState,
											IN	const	forceState_T		 fmAdvance,
											IN	const	bool_T				 coastRequest,
											OUT			bool_T				*coastSelected,
											OUT			real32_T			*coastOffset,
											OUT			bool_T				*coastValid
											)
{
	simpleState_T	rawSimpleState;
	bool_T			selected;
	real32_T		offset;

	vobsGetRawSimpleState(vehicleState, &rawSimpleState);
	selected = (paramSet->longController.offsetOnNeutral) ? (fmAdvance == forceStateNeutral) : (coastRequest && rawSimpleState == simpleStateOff);
	
	/* Auswahl des geeigneten Werts f�r den Beschleunigungsoffset im Segeln. */
	offset	= (selected) ? paramSet->longController.coastOffset : 0.0f;
	

	/* Ein positiver offset wird nur zugelassen, wenn bereits Segeln gemeldet wird. */
	if(rawSimpleState != simpleStateOff) {
		offset = min(offset, 0.0f);
	}

	*coastSelected = selected;
	*coastOffset = offset;
	*coastValid = true;
}


static void				   lnclCalcDynamics(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	vmState_T			*vmState,
											IN	const	vmState_T			*vmPred,
											OUT			real32_T			*loopAcceleration,
											OUT			real32_T			*velocity,
											OUT			real32_T			*plannedVelocity)
{
	real32_T vel;
	real32_T acc;
	real32_T plannedVel;

	acc = vmState->acceleration;
	acc = min(acc, paramSet->longController.acceleration.max);
	acc = max(acc, paramSet->longController.acceleration.min);

	vel	= vmPred->velocity;
	vel	= min(vel, paramSet->longController.velocity.max);
	vel	= max(vel, paramSet->longController.velocity.min);

	plannedVel = vmState->velocity;

	*loopAcceleration = acc;
	*velocity = vel;
	*plannedVelocity = plannedVel;
}


static void			 lnclFilterAcceleration(INOUT		real32_T			*filterLoop,
											INOUT		real32_T			*filterAdvance,
											IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	real32_T			 loopAcceleration,
											IN	const	real32_T			 advanceAccel,
											IN	const	real32_T			 lockAcceleration,
											IN	const	real32_T			 coastOffset,
											OUT			real32_T			*longAcceleration)
{
	real32_T		maxAdvanceDelta;
	real32_T		minAdvanceDelta;
	real32_T		baseAdvanceDelta;
	real32_T		maxAdvanceAccel;
	real32_T		minAdvanceAccel;
	real32_T		advanceAcceleration;
	real32_T		acceleration;

	const real32_T lastLoop		= *filterLoop;
	const real32_T lastAdvance	= *filterAdvance;


	baseAdvanceDelta	= paramSet->longController.acceleration.advanceJerk * controlCYCLETIME;

	maxAdvanceDelta		= loopAcceleration - lastLoop;
	minAdvanceDelta		= loopAcceleration - lastLoop;

	maxAdvanceDelta		= max(maxAdvanceDelta, 0.0f);
	minAdvanceDelta		= min(minAdvanceDelta, 0.0f);

	maxAdvanceAccel		= lastAdvance + maxAdvanceDelta + baseAdvanceDelta;
	minAdvanceAccel		= lastAdvance + minAdvanceDelta - baseAdvanceDelta;

	advanceAcceleration	= advanceAccel;
	advanceAcceleration	= min(advanceAcceleration, maxAdvanceAccel);
	advanceAcceleration	= max(advanceAcceleration, minAdvanceAccel);


	acceleration		= min(advanceAcceleration, lockAcceleration);
	acceleration		= min(acceleration, paramSet->longController.acceleration.max);
	acceleration		= max(acceleration, paramSet->longController.acceleration.min);
	acceleration	   += coastOffset;

	*filterLoop			= loopAcceleration;
	*filterAdvance		= advanceAcceleration;
	*longAcceleration	= acceleration;
}


static void				  lnclCalcTolerance(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	systemControl_T		*systemControl,
											IN	const	forceState_T		 fmAdvance,
											IN	const	real32_T			 acceleration,
											IN	const	real32_T			 minAcceleration,
											IN	const	real32_T			 maxAcceleration,
											IN	const	bool_T				 coastSelected,
											IN	const	real32_T			 coastOffset,
											OUT			real32_T			*toleranceLower,
											OUT			real32_T			*toleranceUpper)
{
	real32_T lowerTol;
	real32_T lowerTolMin;
	real32_T lowerTolMax;
	real32_T upperTol;
	real32_T upperTolMin;
	real32_T upperTolMax;
	real32_T toleranceFactor;

	sysGetToleranceFactor(systemControl, &toleranceFactor);

	upperTolMin = (coastSelected) ? paramSet->longController.tolerance.upper.off.min : paramSet->longController.tolerance.upper.on.min;
	upperTolMax = (coastSelected) ? paramSet->longController.tolerance.upper.off.max : paramSet->longController.tolerance.upper.on.max;
	
	/* Auswahl der geeigneten Parameter f�r die zul�ssige obere und untere Abweichung */
	lowerTolMin = (fmAdvance == forceStateNeutral) ? paramSet->longController.tolerance.lower.off.min : paramSet->longController.tolerance.lower.on.min;
	lowerTolMax = (fmAdvance == forceStateNeutral) ? paramSet->longController.tolerance.lower.off.max : paramSet->longController.tolerance.lower.on.max;

	lowerTol	= acceleration - minAcceleration;
	lowerTol	= min(lowerTol, lowerTolMax);
	lowerTol	= max(lowerTol, lowerTolMin);

	upperTol	= maxAcceleration - acceleration;
	upperTol	= min(upperTol, upperTolMax);
	upperTol	= max(upperTol, upperTolMin);
	upperTol   *= toleranceFactor;
	upperTol   -= coastOffset;

	*toleranceLower = lowerTol;
	*toleranceUpper = upperTol;
}


static void	  lnclCountTicksSinceActivation(INOUT		uint16_T	*activationTicks,
											IN	const	sysStatus_T	 status)
{
	uint16_T ticks = *activationTicks;

	if (ticks < (uint16_T)INVALID_UINT16) {
		ticks++;
	}

	if (	status == sysStatusDisabled
		||	status == sysStatusNotAvailable
		||	status == sysStatusAvailable) 
	{
		ticks = 0u;
	}

	*activationTicks = ticks;
}


static void					   lnclCalcJerk(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	bool_T				 coastSelected,
											IN	const	uint16_T			 activationTicks,
											OUT			real32_T			*jerkPositive,
											OUT			real32_T			*jerkNegative)
{
	real32_T		positive;
	real32_T		negative;
	real32_T		ratio;

	const real32_T	rampUpTicks = (real32_T)paramSet->longController.jerk.rampUpTicks;
	const real32_T	actvtnTicks = (real32_T)activationTicks;

	ratio = (rampUpTicks != 0.0f) ? (actvtnTicks / rampUpTicks) : 1.0f;
	ratio = min(ratio, 1.0f);

	positive = paramSet->longController.jerk.positive;
	negative = (coastSelected) ? paramSet->longController.jerk.negCoast : paramSet->longController.jerk.negative;


	positive *= ratio;
	negative *= ratio;

	*jerkPositive = positive;
	*jerkNegative = negative;
}


static bool_T	  lnclCalcTransmissionRatio(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	vehicleModel_T		*vehicleModel,
											IN	const	vehicleState_T		*vehicleState,
											IN	const	uint16_T			 activationTicks,
											IN	const	uint8_T				 gearNow,
											IN	const	uint8_T				 gearPredicted,
											IN	const	bool_T				 coastRequest,
											IN	const	bool_T				 gearLock,
											OUT			real32_T			*transmissionRatio,
											OUT			bool_T				*transmissionValid,
											OUT			uint8_T				*relevantGear,
											OUT			bool_T				*isGearValid)
{
	uint8_T		gearRel;
	real32_T	requestOffset;
	bool_T		requestAllowed;
	bool_T		coastLock;
	bool_T		gearValid;
	real32_T	transRatio;
	bool_T		transValid;
	bool_T		accBoost;

	gearRel = min(gearNow, gearPredicted);
	diagFF(vmdlGetTransmissionRatio(vehicleModel, gearRel, &transRatio));	
	vmdlGetGearRequestOffset(vehicleModel, &requestOffset);
	vmdlIsGearRequestAllowed(vehicleModel, &requestAllowed);

	vobsGetAccBoost(vehicleState, &accBoost);

	coastLock =	(	coastRequest 
				 ||	gearRel == (uint8_T)gearCoast
				)
				&&	paramSet->longController.noTransOnCoast;

	gearValid =		(!paramSet->longController.killTransRatio)
				&&	(!gearLock)
				&&	(requestAllowed);

	transRatio = transRatio + requestOffset;
	transValid = (gearValid && !coastLock);

	if (	activationTicks <= paramSet->longController.transmissionRatio.waitTicks
		||	accBoost)
	{
		transRatio = INVALID_VALUE;
		transValid = false;
	}

	*transmissionRatio = transRatio;
	*transmissionValid = transValid;
	*relevantGear = gearRel;
	*isGearValid = gearValid;

	return true;
}


static void		   lnclLimitBomAcceletation(IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	sysStatus_T			 status,
											IN	const	real32_T			 loopAcceleration,
											INOUT		real32_T			*longAcceleration,
											INOUT		real32_T			*velocity,
											INOUT		real32_T			*toleranceUpper,
											INOUT		real32_T			*toleranceLower,
											INOUT		bool_T				*coastValid,
											INOUT		bool_T				*transmissionValid)
{

	if(   (sysStatusBrakeOnlyMode == status)
	   && (!paramSet->longController.brakeOnly.ignore)) 
	{
		real32_T acc;

		acc = loopAcceleration;
		acc = min(acc, paramSet->longController.brakeOnly.acceleration.max);
		acc = max(acc, paramSet->longController.brakeOnly.acceleration.min);

		*longAcceleration	= acc;
		*velocity			= 0.0f;

		*toleranceUpper		= paramSet->longController.brakeOnly.tolerance.upper;
		*toleranceLower		= paramSet->longController.brakeOnly.tolerance.lower;

		*coastValid			= false;
		*transmissionValid	= false;
	}
}


static bool_T lnclLimitElectricAcceleration(INOUT		real32_T			*longAcceleration,
											IN	const	parameterSetCtrl_T	*paramSet,
											IN	const	vehicleState_T		*vehicleState)
{
	driveMode_T driveMode;
	real32_T maxAccelerationElectric;
	real32_T minAccelerationElectric;
	real32_T acceleration;

	acceleration = *longAcceleration;

	vobsGetDriveMode(vehicleState, &driveMode);
	vobsGetMaxAccelerationElectric(vehicleState, &maxAccelerationElectric);

	if (driveMode == drvMdCombustion)
	{
		/*Keine weitere Einschr�nkung der Sollbeschleunigung*/
	}
	else if (driveMode == drvMdElectricAuto)
	{
		minAccelerationElectric = acceleration - paramSet->longController.accDeviation.drvMdElectricAuto;
		acceleration = min(acceleration, maxAccelerationElectric);
		acceleration = max(acceleration, minAccelerationElectric);
	} 
	else if (driveMode == drvMdEpower)
	{
		minAccelerationElectric = acceleration - paramSet->longController.accDeviation.drvMdEpower;
		acceleration = min(acceleration, maxAccelerationElectric);
		acceleration = max(acceleration, minAccelerationElectric);
	}
	else
	{
		diagFUnreachable();
	}

	*longAcceleration = acceleration;
	return true;
}
