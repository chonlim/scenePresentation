#ifndef guard_lnclStep_h
#define guard_lnclStep_h




/**\brief Setze Regelanforderungen.

Die Regelanforderungen werden auf Basis der L�ngsplanung zum aktuellen Zeitpunkt T0 und 
zu individuellen Vorgriffszeiten (Ta, Tg, Tc, Tv) f�r die Regelgr��en erstellt.

Zur R�ckschleife der Regelgr��en mittels \ref vobsSetLongControlInfo() werden 
die aktuell geplante Beschleunigung (T0), die aktuelle Segelanforderung (T0) und
der f�r die Ganganforderung relevante Gang (T0 oder T0 + Tg) verwendet.

\spec SW_AS_Innodrive2_723

\ingroup longController
*/
bool_T		 lnclGetControl(INOUT		longMemory_T		*longMemory,		/**<Speicher der Moduls*/
							IN	const	vehicleModel_T		*vehicleModel,		/**<Fahrzeugmodell*/
							IN	const	longTorque_T		*longTorque,		/**<Pr�diktion*/
							IN	const	systemControl_T		*systemControl,		/**<Systemzustand*/
							IN	const	vehicleState_T		*vehicleState,		/**<Fahrzeugzustand*/
							OUT			longControl_T		*longControl,		/**<Regelanforderungen*/
							OUT			longControlInfo_T	*longControlInfo	/**<R�ckschleife der Regelanforderungen*/
							);

	
/**\brief Initialisiere Regelanforderungen.
\spec SwMS_Innodrive2_Output_63
\spec SwMS_Innodrive2_Output_83
\ingroup longController
*/
void			   lnclInit(OUT			longMemory_T		*longMemory,		/**<Speicher der Moduls*/
							OUT			longControl_T		*longControl,		/**<Regelanforderungen*/
							OUT			longControlInfo_T	*longControlInfo	/**<R�ckschleife der Regelanforderungen*/
							);




#endif
