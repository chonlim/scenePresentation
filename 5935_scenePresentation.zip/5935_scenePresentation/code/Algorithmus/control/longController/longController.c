#include "longController.h"

#include "lnclStep.h"

#include "longController_private.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/systemControllerCommon/sysTools.h"
#include "common/longTorquePlannerCommon/lntqTools.h"


void		 longController(INOUT		longMemory_T			*longMemory,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	systemControl_T			*systemControl,
							IN	const	longTorque_T			*longTorque,
							OUT			longControl_T			*longControl,
							OUT			longControlInfo_T		*longControlInfo,
							OUT			longControlStatus_T		*longControlStatus)
{
	bool_T		valid;
	bool_T		vobsValid;
	bool_T		lntqValid;
	real32_T	previewPosition;
	real32_T	stopPosition;

	/* Gibt es f�r den Zeitpunkt eine g�ltige Beobachtung? */
	vobsIsValid(vehicleState, &vobsValid);

	/* Gibt es f�r diesen Zeitpunkt eine g�ltige Planung? */
	lntqIsValid(longTorque, &lntqValid);

	if(vobsValid && lntqValid) {
		/* Wenn das regul�re Update fehlschl�gt, werden Init-Werte gesetzt */
		if(!lnclGetControl( longMemory,
							vehicleModel,
							longTorque,
							systemControl,
							vehicleState,
							longControl,
							longControlInfo)) {
			lnclInit(longMemory,
					 longControl,
					 longControlInfo);

			valid = false;
		} else {
			valid = true;
		}
	}
	else {
		/* Wenn keine g�ltige Anforderung vorliegt, werden ebenfalls Init-Werte ausgegeben */
		lnclInit(longMemory,
				 longControl,
				 longControlInfo);
		valid = false;
	}


	/* Abfragen der Vorausschau-Position von der L�ngsmomentenplanung */
	lntqGetPreviewPosition(longTorque,
						   &previewPosition);

	/* Abfragen der Position der relevanten Stoppstelle von der L�ngsmomentenplanung */
	lntqGetStopPosition( longTorque,
						&stopPosition);

	/* Statusr�ckmeldung an den systemController */
	sysSetLongControlStatus(valid,
							previewPosition,
							stopPosition,
							longControlStatus);
}
