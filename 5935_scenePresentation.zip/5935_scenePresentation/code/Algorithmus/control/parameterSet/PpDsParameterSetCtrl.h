#ifndef guard_PpDsparameterSetCtrl_h
#define guard_PpDsparameterSetCtrl_h

#include "base.h"
#include "control/parameterSet/parameterSetCtrl_interface.h"
#include "control/controlTask/iccExports.h"

#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"
#else
#include "Rte_Type.h"
#endif


/*lint -save */
/*lint -e18	 "Error -- Symbol 'ccc' redeclared(origin, strong) conflicts with line aa, file xxx, module yyy[MISRA 2012 Rule 8.2, required])" */
#ifdef __cplusplus
extern "C" {
#endif

	ICC_API bool_T rteCheckBounds_parameterSetCtrl(const parameterSetCtrl_T *p_theDestData);
	ICC_API bool_T rteInConvert_parameterSetCtrl(const Dt_RECORD_InnoDriveControlParameterSetCtrl *p_theSrcData, parameterSetCtrl_T *p_theDestData);

#ifdef __cplusplus
}
#endif
/*lint -restore */

#endif
