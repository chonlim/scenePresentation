#ifndef guard_parameterSetCtrl_interface_h
#define guard_parameterSetCtrl_interface_h

#include "base.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define dobsMAXLEVELCOUNT 7
#define dobsMAXLEVEL 6                   /**< dobsMAXLEVELCOUNT - 1 */
#define dprdMAXRANGECOUNT 8
#define dprdCONSTRAINT_COUNT 64
#define dprdTRAJECTORY_COUNT 64
#define prmNUMADAPTIONRATE 3
#define prmNUMWETNESSFACTOR 4
#define prmNUMFRICTIONFACTOR 4
#define prmNUMTAILFACTOR 3
#define prmNUMCURVATUREFACTOR 3
#define prmNUMLIMITDEVFACTOR 3
#define prmNUMFOLLOWGAPFACTOR 3
#define prmNUMRESETAGEFACTOR 3
#define prmNUMMAXBRAKETORQUE 4
#define prmNUMCOUNTRYLIST 64u
#define vobsCHECKTIMEOUTMAX 1310.0f




#define parameterSetCtrlCrc32 0xe66d8fceU



typedef struct _parameterSetCtrl {
	uint32_T checksumCrc32;              /**< Berechnung der crc ueber alle Variablennamen zur Verifikation der Struktur */
	struct _parameterSetCtrl_displayController {
		struct _parameterSetCtrl_displayController_velocityThreshold {
			real32_T eventFire;          /**< Mindestabweichung zwischen Vorausschau- und Setzgeschwindigkeit für das Auslösen eines Vorausschau-Events[m/s] */
			real32_T eventHold;          /**< Mindestabweichung zwischen Vorausschau- und Setzgeschwindigkeit für das Halten eines Vorausschau-Events[m/s] */
		} velocityThreshold;
		struct _parameterSetCtrl_displayController_accelerationThreshold {
			real32_T eventFire;          /**< Obergrenze für die zulässige Beschleunigung, bei der ein Kurven-Vorausschauevent getriggert wird[m/s²] */
			real32_T eventHold;          /**< Obergrenze für die zulässige Beschleunigung, bei der ein aktiven Kurven-Vorausschauevent zurückgenommen wird[m/s²] */
		} accelerationThreshold;
		struct _parameterSetCtrl_displayController_significanceThreshold {
			real32_T eventFire;          /**< Maximal zulässige Überschreitung der zulässigen Beschleunigung aufgrund der Setzgeschwindigkeit, bei der ein Kurven-Vorausschauevent getriggert wird[m/s²] */
			real32_T eventHold;          /**< Maximal zulässige Überschreitung der zulässigen Beschleunigung aufgrund der Setzgeschwindigkeit, bis zu der ein aktives Kurven-Vorausschauevent gehalten wird[m/s²] */
		} significanceThreshold;
		struct _parameterSetCtrl_displayController_curveTakeover {
			real32_T thresholdSet;       /**< Voraussichtliche Überschreitung der zulässigen Kurvengeschwindigkeit, bei der eine Übernahmeaufforderung ausgelöst wird[m/s] */
			real32_T thresholdHold;      /**< Voraussichtliche Überschreitung der zulässigen Kurvengeschwindigkeit, bei der eine Übernahmeaufforderung gehalten wird[m/s] */
		} curveTakeover;
		real32_T ttcThreshold;           /**< Mindestzeit, die ein Vorausschau-Event nach dem Auslösen voraussichtlich noch angezeigt werden muss[s] */
		real32_T previewThreshold;       /**< Mindestabweichung zwischen Ist- und Vorausschaugeschwindigkeit, damit ein gültiger Wert geschickt wird[m/s] */
		real32_T previewCutOff;          /**< Grenzfrequenz für die Tiefpassfilterung der Vorausschaugeschwindigkeit[Hz] */
		uint16_T torqueHoldTicks;        /**< Anzahl der Zeitschritte, für die ein Wechsel zwischen zwei Krümmungs-Vorausschauicons zurückgehalten wird[20 ms] */
		uint16_T offsetHoldTicks;        /**< Anzahl der Zeitschritte, die ein geänderter permanenter Offset angezeigt wird.[20 ms] */
	} displayController;
	struct _parameterSetCtrl_driverObserver {
		struct _parameterSetCtrl_driverObserver_inputFilter {
			real32_T longAccelerationFilterTime; /**< Zeitkonstante des Tiefpassfilters[s] */
			real32_T latAccelerationFilterTime; /**< Zeitkonstante des Tiefpassfilters[s] */
			real32_T velocityFilterTime; /**< Zeitkonstante des Tiefpassfilters[s] */
			real32_T acceleratorFilterTime; /**< Zeitkonstante des Tiefpassfilters[s] */
		} inputFilter;
		struct _parameterSetCtrl_driverObserver_dynamicValues {
			real32_T lowPassTimeConstant; /**< Zeitkonstante des Tiefpassfilters (Anzahl Rechenzyklen)[s] */
			struct _parameterSetCtrl_driverObserver_dynamicValues_countryInit {
				real32_T longAcceleration; /**< Initialwert für Umgebung Land[m/s²] */
				real32_T longDeceleration; /**< Initialwert für Umgebung Land[m/s²] */
				real32_T latAcceleration; /**< Initialwert für Umgebung Land[m/s²] */
				real32_T offsetVelocity; /**< Initialwert für Umgebung Land[m/s] */
				uint8_T level;           /**< Initialwert für Umgebung Land */
			} countryInit;
			struct _parameterSetCtrl_driverObserver_dynamicValues_countryRadarInit {
				real32_T longAcceleration; /**< Initialwert für Umgebung Land+Radar[m/s²] */
				real32_T longDeceleration; /**< Initialwert für Umgebung Land+Radar[m/s²] */
				real32_T latAcceleration; /**< Initialwert für Umgebung Land+Radar[m/s²] */
				real32_T offsetVelocity; /**< Initialwert für Umgebung Land+Radar[m/s] */
				uint8_T level;           /**< Initialwert für Umgebung Land+Radar */
			} countryRadarInit;
			struct _parameterSetCtrl_driverObserver_dynamicValues_cityInit {
				real32_T longAcceleration; /**< Initialwert für Umgebung Stadt[m/s²] */
				real32_T longDeceleration; /**< Initialwert für Umgebung Stadt[m/s²] */
				real32_T latAcceleration; /**< Initialwert für Umgebung Stadt[m/s²] */
				real32_T offsetVelocity; /**< Initialwert für Umgebung Stadt[m/s] */
				uint8_T level;           /**< Initialwert für Umgebung Stadt */
			} cityInit;
		} dynamicValues;
		struct _parameterSetCtrl_driverObserver_escalation {
			uint8_T levelCount;          /**< Stufengrenzen */
			real32_T longAccelerationLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[m/s²] */
			real32_T longDecelerationLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[m/s²] */
			real32_T latAccelerationLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[m/s²] */
			real32_T wheelPowerLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[W] */
			real32_T acceleratorGradLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[1/100/s] */
			real32_T maxJerkLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[m/s^3] */
			real32_T minJerkLevels[dobsMAXLEVELCOUNT]; /**< Stufengrenzen[m/s^3] */
			real32_T deescalationTimes[dobsMAXLEVELCOUNT]; /**< Wartezeit Stufendeeskalation[s] */
			uint8_T escalationOffset;    /**< Negativer Stufen-Offset bei Mitziehen der anderen Fahrdynamikparameter auf höhere Stufen */
		} escalation;
		struct _parameterSetCtrl_driverObserver_desiredSpeed {
			real32_T minVelocityRampDown; /**< Mindestgeschwindigkeit für das Herunterrampen der Wunschgeschwindigkeit[m/s] */
			real32_T velocityTolerance;  /**< Geschwindigkeitstoleranz für das Herunterrampen der Wunschgeschwindigkeit[m/s] */
			real32_T velocityToleranceLarge; /**< Geschwindigkeitstoleranz für das Hochrampen der Wunschgeschwindigkeit[m/s] */
			real32_T onlineSpeedTolerance; /**< Geschwindigkeitstoleranz für das Erkennen von dichtem Verkehr[m/s] */
			real32_T longAccelerationToleranceUp; /**< Beschleunigungstoleranz für das Hochrampen der Wunschgeschwindigkeit[m/s²] */
			real32_T longAccelerationToleranceDown; /**< Beschleunigungstoleranz für das Herunterrampen der Wunschgeschwindigkeit[m/s²] */
			real32_T longDecelerationTolerance; /**< Verzögerungstoleranz für das Herunterrampen der Wunschgeschwindigkeit[m/s²] */
			real32_T longAccTolPushNextLimit; /**< Beschleunigungstoleranz für VOrzeitige Übernahme des zukünftigen Tempolimits[m/s²] */
			real32_T latAccelerationTolerance; /**< Querbeschleunigungstoleranz für das Herunterrampen der Wunschgeschwindigkeit[m/s²] */
			real32_T extrapolationTime;  /**< Extrapolationszeit für das Hochrampen der Wunschgeschwindigkeit[s] */
			real32_T rampDownTime;       /**< Wartezeit für das Herunterrampen der Wunschgeschwindigkeit[s] */
			real32_T bufferTimeAfterLimit; /**< Pufferzone nach Tempolimitwechsel[s] */
			real32_T bufferLengthBeforeLimit; /**< Pufferzone vor Tempolimitwechsel[m] */
			real32_T maxDistanceNextLimit; /**< Abstand, ab dem ein zukünftiges Tempolimit erkannt wird.[m] */
		} desiredSpeed;
		struct _parameterSetCtrl_driverObserver_offsetVelocity {
			real32_T lowPassTimeConstant; /**< Zeitkonstante Tiefpassfilter Geschiwndigkeitsoffset[s] */
			real32_T lowerBounds[dobsMAXLEVELCOUNT]; /**< Untergrenze Geschiwndigkeitsoffset[m/s] */
			real32_T upperBounds[dobsMAXLEVELCOUNT]; /**< Obergrenze Geschiwndigkeitsoffset[m/s] */
			real32_T initialValues[dobsMAXLEVELCOUNT]; /**< Initialwerte Geschwindigkeitsoffset[m/s] */
		} offsetVelocity;
		struct _parameterSetCtrl_driverObserver_maxVelocity {
			real32_T lowPassTimeConstantUp; /**< Zeitkonstante Tiefpassfilter Freifahrtgeschwindigkeit Hochrampen[s] */
			real32_T lowPassTimeConstantDown; /**< Zeitkonstante Tiefpassfilter Freifahrtgeschwindigkeit Herunterrampen[s] */
			real32_T initialValues[dobsMAXLEVELCOUNT]; /**< Initialwerte Freifahrtgeschwindigkeit[m/s] */
		} maxVelocity;
		struct _parameterSetCtrl_driverObserver_environment {
			real32_T standStillVelocityTolerance; /**< Höchstgeschwindigkeit zur Stillstandserkennung[m/s] */
			real32_T radarPropagationTime; /**< Projektionszeit zur Erkennung der Radarfolgefahrt[s] */
			real32_T radarTimeGapIn;     /**< Zeitlücke zum Erkennendes Eintauchens in den Sicherheitsabstand[s] */
			real32_T radarTimeGapOut;    /**< Zeitlücke zum Erkennendes Austauchens aus demSicherheitsabstand[s] */
			real32_T radarRelativeVelocityIn; /**< Relativegeschwindigkeit: vVorderfahrzeug - vEgo[m/s] */
			real32_T radarRelativeVelocityOut; /**< Relativegeschwindigkeit: vVorderfahrzeug - vEgo[m/s] */
			real32_T radarDebounceTime;  /**< Entprellzeit Radarfolgefahrt[s] */
			real32_T highwayDebounceDynEventBefore; /**< Verhinderung der Erkennung von Radarfolgefahrt um Dynamikevents[m] */
			real32_T highwayDebounceDynEventAfter; /**< Verhinderung der Erkennung von Radarfolgefahrt um Dynamikevents[m] */
			real32_T builtUpSpeedLimit;  /**< Notwendiges Tempolimit zur erkennung Innerorts[m/s] */
		} environment;
	} driverObserver;
	struct _parameterSetCtrl_driverPredictor {
		real32_T deltaTime;              /**< Diskretisierungsschrittweite für die Erstellung der Trajektorie[s] */
		uint8_T timestepCount;           /**< Anzahl der zu berechnenden Zeitschritte auf der Trajektorie */
		uint8_T windowStart[3];          /**< Anzahl der zu berechnenden Zeitschritte auf der Trajektorie */
		uint8_T windowEnd[3];            /**< Anzahl der zu berechnenden Zeitschritte auf der Trajektorie */
		uint8_T minDynamicLevel;         /**< Mindest Dynamik-Level, der bei einem Fahrdynamikevent gesetzt wird */
		real32_T minAcceleration;        /**< Minimaler Grenzwert der zulässigen Beschleunigung */
		real32_T minAccelerationFactor;  /**< Faktor zur Berechnung der Verzögerung auf zwingende Einschränkungen (Kurven) */
		struct _parameterSetCtrl_driverPredictor_onlineLimit {
			real32_T offset;             /**< Geschwindigkeitsoffset, der einer von Geschwindigkeitsbegrenzung subtrahiert und entscheidet ob ein onlineLimit gültig ist oder nicht[m/s] */
			real32_T maxSpeedLimit;      /**< Maximale Geschwindigkeit, die ein onlineLimit aufweisen darf[m/s] */
			real32_T factor;             /**< Faktor um die onlineLimits zu begrenzen */
		} onlineLimit;
		struct _parameterSetCtrl_driverPredictor_prepCount {
			uint16_T speedLimit;         /**< Anzahl von Einschränkungen, die eingelesen werden */
			uint16_T onlineLimit;        /**< Anzahl von Einschränkungen, die eingelesen werden */
			uint16_T curvature;          /**< Anzahl von Einschränkungen, die eingelesen werden */
			uint16_T environment;        /**< Maximale Anzahl von Environments, die eingelesen werden */
		} prepCount;
		struct _parameterSetCtrl_driverPredictor_evalCount {
			uint16_T speedLimit;         /**< Anzahl von Einschränkungen, die bei einer Abfrage von Einschränkunge aus Speed Limits berücksichtigt werden */
			uint16_T onlineLimit;        /**< Anzahl von Einschränkungen, die bei einer Abfrage von Einschränkunge aus Online Limits berücksichtigt werden */
			uint16_T curvature;          /**< Anzahl von Einschränkungen, die bei einer Abfrage von Einschränkunge aus Krümmungen berücksichtigt werden */
		} evalCount;
		struct _parameterSetCtrl_driverPredictor_containerRange {
			real32_T latAcceleration[dprdMAXRANGECOUNT]; /**< Untere Containergrenzen für die Querbeschleunigung[m/s²] */
			real32_T longAcceleration[dprdMAXRANGECOUNT]; /**< Untere Containergrenzen für die Längsbeschleunigung[m/s²] */
			real32_T wheelPower[dprdMAXRANGECOUNT]; /**< Untere Containergrenzen für die Radleistung[W] */
			real32_T velocity[dprdMAXRANGECOUNT]; /**< Untere Containergrenzen für die Geschwindigkeit[m/s] */
		} containerRange;
		struct _parameterSetCtrl_driverPredictor_branch {
			real32_T length;             /**< Bogenlängen-Vektor der Kennlinie für die Ableitung von Abbiege-Bogenlängen aus zulässigen Höchstgeschwindigkeiten */
			real32_T factorIn;           /**< Anteil der ersten Hälfte der Abbiege-Bogenlänge, der als Klothoide und nicht als Kreisbogen angenommen wird */
			real32_T factorOut;          /**< Anteil der zweiten Hälfte der Abbiege-Bogenlänge, der als Klothoide und nicht als Kreisbogen angenommen wird */
		} branch;
	} driverPredictor;
	struct _parameterSetCtrl_inputCodec {
		struct _parameterSetCtrl_inputCodec_powertrain {
			struct _parameterSetCtrl_inputCodec_powertrain_gear {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} gear;
			struct _parameterSetCtrl_inputCodec_powertrain_hybridVehicle {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} hybridVehicle;
			struct _parameterSetCtrl_inputCodec_powertrain_coastingPossible {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} coastingPossible;
			struct _parameterSetCtrl_inputCodec_powertrain_sumTorque {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[Nm] */
			} sumTorque;
			struct _parameterSetCtrl_inputCodec_powertrain_transmissionManual {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} transmissionManual;
			struct _parameterSetCtrl_inputCodec_powertrain_maxTorqueElectric {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[Nm] */
			} maxTorqueElectric;
			struct _parameterSetCtrl_inputCodec_powertrain_combustionEngineActive {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} combustionEngineActive;
			struct _parameterSetCtrl_inputCodec_powertrain_ePowerSelected {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} ePowerSelected;
			struct _parameterSetCtrl_inputCodec_powertrain_eTorquePrimary {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[Nm] */
			} eTorquePrimary;
			struct _parameterSetCtrl_inputCodec_powertrain_eTorqueSecondary {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[Nm] */
			} eTorqueSecondary;
			struct _parameterSetCtrl_inputCodec_powertrain_motorCode {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} motorCode;
		} powertrain;
		struct _parameterSetCtrl_inputCodec_driver {
			struct _parameterSetCtrl_inputCodec_driver_valid {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} valid;
			struct _parameterSetCtrl_inputCodec_driver_enabled {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} enabled;
			struct _parameterSetCtrl_inputCodec_driver_selected {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} selected;
			struct _parameterSetCtrl_inputCodec_driver_tipUp {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} tipUp;
			struct _parameterSetCtrl_inputCodec_driver_tipDown {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} tipDown;
			struct _parameterSetCtrl_inputCodec_driver_set {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} set;
			struct _parameterSetCtrl_inputCodec_driver_resume {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} resume;
			struct _parameterSetCtrl_inputCodec_driver_followingGap {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} followingGap;
			struct _parameterSetCtrl_inputCodec_driver_charisma {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} charisma;
			struct _parameterSetCtrl_inputCodec_driver_autoMode {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} autoMode;
			struct _parameterSetCtrl_inputCodec_driver_maxAutoSpeed {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s] */
			} maxAutoSpeed;
			struct _parameterSetCtrl_inputCodec_driver_turnSignal {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} turnSignal;
			struct _parameterSetCtrl_inputCodec_driver_signalLocked {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} signalLocked;
			struct _parameterSetCtrl_inputCodec_driver_accelerator {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[1/100] */
			} accelerator;
			struct _parameterSetCtrl_inputCodec_driver_displayUnit {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} displayUnit;
			struct _parameterSetCtrl_inputCodec_driver_vMaxRaw {
				bool_T override;         /**< Aktiviert den Override */
				uint16_T value;          /**< Override-Wert[vMaxUnit] */
			} vMaxRaw;
			struct _parameterSetCtrl_inputCodec_driver_vMaxUnit {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} vMaxUnit;
			struct _parameterSetCtrl_inputCodec_driver_offset {
				bool_T override;         /**< Aktiviert den Override */
				int8_T value;            /**< Override-Wert. int8 wg. DebugBuffer-Größe. ACHTUNG: Signal vehicleInput.driver.offset ist in m/s!!![km/h] */
			} offset;
			struct _parameterSetCtrl_inputCodec_driver_ignoreCountry {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert. */
			} ignoreCountry;
			struct _parameterSetCtrl_inputCodec_driver_fodActivation {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert. */
			} fodActivation;
			struct _parameterSetCtrl_inputCodec_driver_fodInitialized {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert. */
			} fodInitialized;
			struct _parameterSetCtrl_inputCodec_driver_stpStatus {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert. */
			} stpStatus;
		} driver;
		struct _parameterSetCtrl_inputCodec_sign {
			struct _parameterSetCtrl_inputCodec_sign_limit {
				bool_T override;         /**< Aktiviert den Override */
				uint16_T value;          /**< Override-Wert */
			} limit;
			struct _parameterSetCtrl_inputCodec_sign_valid {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} valid;
			struct _parameterSetCtrl_inputCodec_sign_text {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} text;
			struct _parameterSetCtrl_inputCodec_sign_predicted {
				struct _parameterSetCtrl_inputCodec_sign_predicted_limit {
					bool_T override;     /**< Aktiviert den Override */
					uint16_T value;      /**< Override-Wert */
				} limit;
				struct _parameterSetCtrl_inputCodec_sign_predicted_distance {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert */
				} distance;
				struct _parameterSetCtrl_inputCodec_sign_predicted_additionalInfo {
					bool_T override;     /**< Aktiviert den Override */
					uint8_T value;       /**< Override-Wert */
				} additionalInfo;
				struct _parameterSetCtrl_inputCodec_sign_predicted_valid {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} valid;
			} predicted;
			struct _parameterSetCtrl_inputCodec_sign_conditions {
				struct _parameterSetCtrl_inputCodec_sign_conditions_trailerLimit {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert */
				} trailerLimit;
				struct _parameterSetCtrl_inputCodec_sign_conditions_trailerRaw {
					bool_T override;     /**< Aktiviert den Override */
					uint16_T value;      /**< Override-Wert */
				} trailerRaw;
				struct _parameterSetCtrl_inputCodec_sign_conditions_fog {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} fog;
				struct _parameterSetCtrl_inputCodec_sign_conditions_wet {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} wet;
				struct _parameterSetCtrl_inputCodec_sign_conditions_trailer {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} trailer;
			} conditions;
		} sign;
		struct _parameterSetCtrl_inputCodec_road {
			struct _parameterSetCtrl_inputCodec_road_slope {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert */
			} slope;
			struct _parameterSetCtrl_inputCodec_road_wetnessLevel {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} wetnessLevel;
			struct _parameterSetCtrl_inputCodec_road_frictionLevel {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} frictionLevel;
		} road;
		struct _parameterSetCtrl_inputCodec_camera {
			struct _parameterSetCtrl_inputCodec_camera_lineLeft {
				struct _parameterSetCtrl_inputCodec_camera_lineLeft_valid {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} valid;
				struct _parameterSetCtrl_inputCodec_camera_lineLeft_curvature {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[1/m] */
				} curvature;
				struct _parameterSetCtrl_inputCodec_camera_lineLeft_curveRate {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[1/m^2] */
				} curveRate;
				struct _parameterSetCtrl_inputCodec_camera_lineLeft_length {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m] */
				} length;
				struct _parameterSetCtrl_inputCodec_camera_lineLeft_distance {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m] */
				} distance;
			} lineLeft;
			struct _parameterSetCtrl_inputCodec_camera_lineRight {
				struct _parameterSetCtrl_inputCodec_camera_lineRight_valid {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} valid;
				struct _parameterSetCtrl_inputCodec_camera_lineRight_curvature {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[1/m] */
				} curvature;
				struct _parameterSetCtrl_inputCodec_camera_lineRight_curveRate {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[1/m^2] */
				} curveRate;
				struct _parameterSetCtrl_inputCodec_camera_lineRight_length {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m] */
				} length;
				struct _parameterSetCtrl_inputCodec_camera_lineRight_distance {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m] */
				} distance;
			} lineRight;
		} camera;
		struct _parameterSetCtrl_inputCodec_dynamics {
			struct _parameterSetCtrl_inputCodec_dynamics_velocity {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s] */
			} velocity;
			struct _parameterSetCtrl_inputCodec_dynamics_longAcceleration {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} longAcceleration;
			struct _parameterSetCtrl_inputCodec_dynamics_latAcceleration {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/^2s] */
			} latAcceleration;
			struct _parameterSetCtrl_inputCodec_dynamics_displayVelocity {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s] */
			} displayVelocity;
			struct _parameterSetCtrl_inputCodec_dynamics_yawRate {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[rad/s] */
			} yawRate;
			struct _parameterSetCtrl_inputCodec_dynamics_heading {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[deg] */
			} heading;
			struct _parameterSetCtrl_inputCodec_dynamics_wheelAngle {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[rad] */
			} wheelAngle;
			struct _parameterSetCtrl_inputCodec_dynamics_wheelRate {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[rad/s] */
			} wheelRate;
			struct _parameterSetCtrl_inputCodec_dynamics_rearAngle {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[rad] */
			} rearAngle;
			struct _parameterSetCtrl_inputCodec_dynamics_rasPresent {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} rasPresent;
			struct _parameterSetCtrl_inputCodec_dynamics_headValid {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} headValid;
			struct _parameterSetCtrl_inputCodec_dynamics_serviceBrakeEngaged {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} serviceBrakeEngaged;
			struct _parameterSetCtrl_inputCodec_dynamics_brakeTorque {
				struct _parameterSetCtrl_inputCodec_dynamics_brakeTorque_frontLeft {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert */
				} frontLeft;
				struct _parameterSetCtrl_inputCodec_dynamics_brakeTorque_frontRight {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert */
				} frontRight;
				struct _parameterSetCtrl_inputCodec_dynamics_brakeTorque_rearLeft {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert */
				} rearLeft;
				struct _parameterSetCtrl_inputCodec_dynamics_brakeTorque_rearRight {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert */
				} rearRight;
			} brakeTorque;
		} dynamics;
		struct _parameterSetCtrl_inputCodec_acc {
			struct _parameterSetCtrl_inputCodec_acc_accStatus {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} accStatus;
			struct _parameterSetCtrl_inputCodec_acc_accAcceleration {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} accAcceleration;
			struct _parameterSetCtrl_inputCodec_acc_systemRelevant {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} systemRelevant;
			struct _parameterSetCtrl_inputCodec_acc_target {
				struct _parameterSetCtrl_inputCodec_acc_target_distance {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m] */
				} distance;
				struct _parameterSetCtrl_inputCodec_acc_target_velocity {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m/s] */
				} velocity;
				struct _parameterSetCtrl_inputCodec_acc_target_acceleration {
					bool_T override;     /**< Aktiviert den Override */
					real32_T value;      /**< Override-Wert[m/s²] */
				} acceleration;
				struct _parameterSetCtrl_inputCodec_acc_target_present {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} present;
				struct _parameterSetCtrl_inputCodec_acc_target_valid {
					bool_T override;     /**< Aktiviert den Override */
					bool_T value;        /**< Override-Wert */
				} valid;
			} target;
		} acc;
		struct _parameterSetCtrl_inputCodec_position {
			struct _parameterSetCtrl_inputCodec_position_valid {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} valid;
			struct _parameterSetCtrl_inputCodec_position_laneCount {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} laneCount;
			struct _parameterSetCtrl_inputCodec_position_lanePosition {
				bool_T override;         /**< Aktiviert den Override */
				int8_T value;            /**< Override-Wert */
			} lanePosition;
			struct _parameterSetCtrl_inputCodec_position_laneType {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} laneType;
		} position;
	} inputCodec;
	struct _parameterSetCtrl_longController {
		struct _parameterSetCtrl_longController_velocity {
			real32_T predTime;           /**< Vorausschauzeit für die Abfrage der Sollgeschwindigkeit[s] */
			real32_T fail;               /**< Fehlerwert für die Sollgeschwindigkeit[m/s] */
			real32_T max;                /**< Maximale Sollgeschwindigkeit, die von der Längsregelung angefordert werden kann[m/s] */
			real32_T min;                /**< Minimale Sollgeschwindigkeit, die von der Längsregelung angefordert werden kann[m/s] */
		} velocity;
		struct _parameterSetCtrl_longController_acceleration {
			real32_T predTime;           /**< Vorausschauzeit fuer die Abfrage der Sollbeschleunigung[s] */
			real32_T max;                /**< Maximale Beschleunigung, die von der Längsregelung angefordert werden kann[m/s²] */
			real32_T min;                /**< Minimale Beschleunigung, die von der Längsregelung angefordert werden kann[m/s²] */
			real32_T fail;               /**< Init-Beschleunigung, die ausgegeben wird, wenn keine gültige Anforderung vorliegt[m/s²] */
			real32_T advanceJerk;        /**< 'Sockelruck', mit der die vorgezogene Beschleunigungsanforderung gegenüber der aktuellen angepasst werden kann[m/s^3] */
		} acceleration;
		struct _parameterSetCtrl_longController_jerk {
			real32_T positive;           /**< Positiver Beschleunigungsgradient, der von der Längsregelung angefordert wird[m/s^3] */
			real32_T negative;           /**< Negativer Beschleunigungsgradient, der von der Längsregelung angefordert wird[m/s^3] */
			real32_T negCoast;           /**< Negativer Beschleunigungsgradient, der während Segelanforderungen gesendet wird[m/s^3] */
			uint16_T rampUpTicks;        /**< Rechenzyklen, über die die Beschleunigungsgradienten bei Aktivierung aufgerampt werden.[0.02s] */
		} jerk;
		struct _parameterSetCtrl_longController_transmissionRatio {
			uint16_T waitTicks;          /**< Rechenzyklen, für die die Anforderung der Wunschübersetzung bei Aktivierung gesperrt wird.[0.02s] */
		} transmissionRatio;
		struct _parameterSetCtrl_longController_tolerance {
			struct _parameterSetCtrl_longController_tolerance_upper {
				struct _parameterSetCtrl_longController_tolerance_upper_on {
					real32_T max;        /**< Maximale zulässige positive Beschleunigungsabweichung, die bei geschlossenem Triebstrang von der Längsregelung angefordert wird[m/s²] */
					real32_T min;        /**< Minimale zulässige positive Beschleunigungsabweichung, die bei geschlossenem Triebstrang von der Längsregelung angefordert wird[m/s²] */
				} on;
				struct _parameterSetCtrl_longController_tolerance_upper_off {
					real32_T max;        /**< Maximale zulässige positive Beschleunigungsabweichung, die bei geöffnetem Triebstrang von der Längsregelung angefordert wird[m/s²] */
					real32_T min;        /**< Minimale zulässige positive Beschleunigungsabweichung, die bei geöffnetem Triebstrang von der Längsregelung angefordert wird[m/s²] */
				} off;
			} upper;
			struct _parameterSetCtrl_longController_tolerance_lower {
				struct _parameterSetCtrl_longController_tolerance_lower_on {
					real32_T max;        /**< Maximale zulässige negative Beschleunigungsabweichung, die bei geschlossenem Triebstrang von der Längsregelung angefordert wird[m/s²] */
					real32_T min;        /**< Minimale zulässige negative Beschleunigungsabweichung, die bei geschlossenem Triebstrang von der Längsregelung angefordert wird[m/s²] */
				} on;
				struct _parameterSetCtrl_longController_tolerance_lower_off {
					real32_T max;        /**< Maximale zulässige negative Beschleunigungsabweichung, die bei geöffnetem Triebstrang von der Längsregelung angefordert wird[m/s²] */
					real32_T min;        /**< Minimale zulässige negative Beschleunigungsabweichung, die bei geöffnetem Triebstrang von der Längsregelung angefordert wird[m/s²] */
				} off;
			} lower;
		} tolerance;
		struct _parameterSetCtrl_longController_brakeOnly {
			bool_T ignore;               /**< Gibt an, ob auch im Brake-Only Modus positive Beschleunigungen zulässig sind */
			struct _parameterSetCtrl_longController_brakeOnly_acceleration {
				real32_T max;            /**< Maximal zulässige Beschleunigungsanforderung im Brake-Only Modus[m/s²] */
				real32_T min;            /**< Minimal zulässige Beschleungiungsanforderung im Brake-Only Modus[m/s²] */
			} acceleration;
			struct _parameterSetCtrl_longController_brakeOnly_tolerance {
				real32_T upper;          /**< Zulässige positive Beschleunigungsabweichung, die im Brake-Only Modus gesendet wird[m/s²] */
				real32_T lower;          /**< ZUlässige negative Beschleunigungsabweichung, die im Brake-Only Modus gesendet wird[m/s²] */
			} tolerance;
		} brakeOnly;
		struct _parameterSetCtrl_longController_coastFading {
			uint16_T enterTicks;         /**< Anzahl der Control-Zeitschritte, um die die Weitergabe einer Segelanforderung verzögert wird[1] */
			real32_T leaveTime;          /**< Zeit, um die die Rücknahme einer Segelanfoderung vorgezogen wird[s] */
		} coastFading;
		struct _parameterSetCtrl_longController_accDeviation {
			real32_T drvMdElectricAuto;  /**< Die maximale Abweichung zwischen originaler und durch maximale E-Beschleunigung angepasste Sollbeschleunigung im Fahrmodus electricAuto[m/s²] */
			real32_T drvMdEpower;        /**< Die maximale Abweichung zwischen originaler und durch maximale E-Beschleunigung angepasste Sollbeschleunigung im Fahrmodus ePower[m/s²] */
		} accDeviation;
		real32_T coastOffset;            /**< Offset, der bei einer Segelanforderung und -Umsetzung auf die Sollbeschleunigung aufgeschlagen wird[m/s²] */
		real32_T transRatioAdvance;      /**< Vorausschauzeit für die Abfrage der Wunschübersetzung[s] */
		bool_T killTransRatio;           /**< Gibt an, ob das Ausgeben gültiger Wunschübersetzungen generell unterdrückt werden soll */
		bool_T noTransOnCoast;           /**< Gibt an, ob das Ausgeben gültiger Wunschübersetzungen im Segeln unterdrückt werden soll */
		bool_T offsetOnNeutral;          /**< Gibt an, ob die Toleranzaufweitung im Segeln bereits mit der 'Neutral'-Anforderung aus der Längsplanung ausgelöst werden soll */
	} longController;
	struct _parameterSetCtrl_longStabTrigger {
		real32_T prioVelocity;           /**< Geschwindigkeitsgrenze, unter die Stabilisierungsebene zwangsweise priorisiert wird[m/s] */
		real32_T maxPlanTolerance;       /**< Maximal zulässige positive Abweichung von der geplanten Geschwindigkeit, bis die Stabilisierungsebene priorisiert wird[m/s] */
		real32_T minPlanTolerance;       /**< Maximal zulässige negative Abweichung von der geplanten Geschwindigkeit, bis die Stabilisierungsebene priorisiert wird[m/s] */
	} longStabTrigger;
	struct _parameterSetCtrl_outputCodec {
		real32_T dsplStateDebounceTime;  /**< Zeit die der Anzeigestatus beim Wechsel in sysStatusOverride auf aktiv gelassen wird. */
		struct _parameterSetCtrl_outputCodec_nextEvent {
			uint8_T nCyclesHoldSignal;   /**< Anzahl der Control-Task-Zyklen, die ein naechstesEvent-Signal gehalten wird. */
		} nextEvent;
		struct _parameterSetCtrl_outputCodec_override {
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Durchschnittsgeschw {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert */
			} DePACC02_Durchschnittsgeschw;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Event_aktiv {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePACC02_Event_aktiv;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Geschw_Vorausschau {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePACC02_Geschw_Vorausschau;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Hinweis_Geschw {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePACC02_Hinweis_Geschw;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_InnoDrive_Texte {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePACC02_InnoDrive_Texte;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Offset_Anzeige {
				bool_T override;         /**< Aktiviert den Override */
				int8_T value;            /**< Override-Wert[km/h] */
			} DePACC02_Offset_Anzeige;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_neg_Sollbeschl_Grad {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} DePACC02_neg_Sollbeschl_Grad;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_pos_Sollbeschl_Grad {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} DePACC02_pos_Sollbeschl_Grad;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Sollbeschleunigung {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} DePACC02_Sollbeschleunigung;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Sollgeschwindigkeit {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s] */
			} DePACC02_Sollgeschwindigkeit;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Vorausschaugeschw {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s] */
			} DePACC02_Vorausschaugeschw;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Wunschuebersetzung {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[1] */
			} DePACC02_Wunschuebersetzung;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_zul_Regelabw_oben {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} DePACC02_zul_Regelabw_oben;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_zul_Regelabw_unten {
				bool_T override;         /**< Aktiviert den Override */
				real32_T value;          /**< Override-Wert[m/s²] */
			} DePACC02_zul_Regelabw_unten;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Offset {
				bool_T override;         /**< Aktiviert den Override */
				int16_T value;           /**< Override-Wert[m/s] */
			} DePACC02_Offset;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Ausrollmanoever {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePACC02_Ausrollmanoever;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_naechstes_Event {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePACC02_naechstes_Event;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Systemstatus {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePACC02_Systemstatus;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Systemstatus_Anzeige {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePACC02_Systemstatus_Anzeige;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Automode {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePACC02_Automode;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Uebernahmeaufforderung {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePACC02_Uebernahmeaufforderung;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_Offset_Aktiv {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePACC02_Offset_Aktiv;
			struct _parameterSetCtrl_outputCodec_override_DePACC02_FoD_Status {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePACC02_FoD_Status;
			struct _parameterSetCtrl_outputCodec_override_DePIF_Toggle {
				bool_T override;         /**< Aktiviert den Override */
				bool_T value;            /**< Override-Wert */
			} DePIF_Toggle;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Status {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Status;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Status {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Status;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Status {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Status;
			struct _parameterSetCtrl_outputCodec_override_DePIF_Identifier {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_Identifier;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_0 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_0;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_1 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_1;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_2 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_2;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_3 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_3;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_4 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_4;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_5 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_5;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_6 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_6;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_7 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_7;
			struct _parameterSetCtrl_outputCodec_override_DePIF_ST_Bin_8 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_ST_Bin_8;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_0 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_0;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_1 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_1;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_2 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_2;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_3 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_3;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_4 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_4;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_5 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_5;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_6 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_6;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_7 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_7;
			struct _parameterSetCtrl_outputCodec_override_DePIF_MT_Bin_8 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_MT_Bin_8;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_0 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_0;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_1 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_1;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_2 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_2;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_3 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_3;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_4 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_4;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_5 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_5;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_6 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_6;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_7 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_7;
			struct _parameterSetCtrl_outputCodec_override_DePIF_LT_Bin_8 {
				bool_T override;         /**< Aktiviert den Override */
				uint8_T value;           /**< Override-Wert */
			} DePIF_LT_Bin_8;
		} override;
	} outputCodec;
	struct _parameterSetCtrl_pathRouter {
		bool_T enableLowExecutionTime;   /**< Wenn keine Segmente und Attribute eingelesen werden und dieser Schalter gesetzt ist, wird die LowExecutionTIme-Flag ausgegeben. */
		bool_T enableTurnSignal;         /**< Berücksichtigung des Blinkers für die Pfadwahl */
		uint8_T maxAttributesPerCycle;   /**< Begrenzt die Anzahl von Api-Aufrufen, um die maximale Laufzeit zu begrenzen. */
		uint8_T maxSpeedLimitsPerCycle;  /**< Begrenzt die Anzahl von Api-Aufrufen, um die maximale Laufzeit zu begrenzen. */
		uint8_T maxSegmentsPerCycle;     /**< Begrenzt die Anzahl von Api-Aufrufen, um die maximale Laufzeit zu begrenzen. */
		uint8_T maxApiCallsPerCycle;     /**< Begrenzt die Anzahl von Api-Aufrufen, um die maximale Laufzeit zu begrenzen. */
		uint8_T minInvariantInfoSlopes;  /**< Zahl der Slopes die ohne Spacing aus dem pathRouter übernommen werden. */
		uint8_T slopeSpacing;            /**< Nachdem minInvariantInfoSlopes Steigungsattribute übertragen wurden, wird nur noch jedes slopeSpacing-ste Steigungsattribut übertragen. */
		real32_T headingCorrectionGradient; /**< Korrekturgradient für die Fahrzeugausrichtung[deg/1] */
		uint8_T angleTolerance;          /**< [Anforderung gelöscht] Bis zu welchem Winkel wird eine Abzweigung als Geradeausfahrt erkannt?[deg] */
		real32_T yieldSignTolerance;     /**< [Anforderung gelöscht] Wie nah muss ein Vorfahrt-Achten-Schild an der Kreuzung stehen, um zur Kreuzung zu gehören?[m] */
		bool_T killVZOOnlyLimits;        /**< Sollen SpeedLimit-Attribute, die ausschließlich über VZO gemeldet wurden, ignoriert werden? */
		struct _parameterSetCtrl_pathRouter_routeFilter {
			bool_T followRouting;        /**< Gibt an, ob bei aktivem Routing bevorzugt dem MPP anstelle des SP gefolgt werden soll */
			bool_T preferMPP;            /**< Gibt an, ob generell bevorzugt dem SP anstelle des MPP gefolgt werden soll */
			bool_T turnStraightest;      /**< Gibt an, ob bei Blinken der betragsmäßig kleinste oder größte Abbiegewinkel ausgewählt werden soll */
			bool_T useCurvature;         /**< Gibt an, ob zusätzlich zum Abbiegewinkel auch die Krümmung von Child-Segmenten ausgewertet werden soll */
			bool_T reluctantOnMultipleLanes; /**< Gibt an, ob das Abfahren von mehrspurigen Straßen über Blinker verzögert werden soll, wenn keine gültige Spurposition vorliegt */
			bool_T lockOnMultipleLanes;  /**< Gibt an, ob das Abfahren von mehrspurigen Straßen über Blinker gesperrt werden soll */
			bool_T lockOnRampOneWay;     /**< Gibt an, ob das Abfahren von baulich getrennten Einbahnstraßen über Blinker gesperrt werden soll */
			real32_T maxBranchAngle;     /**< Maximaler Abbiegewinkel, der bei der Suche nach Abbiegemöglichkeiten in Betracht gezogen wird[deg] */
		} routeFilter;
		struct _parameterSetCtrl_pathRouter_positionFilter {
			real32_T correctionFactor;   /**< Korrekturfaktor für Fahrzeugposition */
			real32_T positionTolerance;  /**< Toleranzgrenze, ab der der Positionsfilter neu initialisiert wird.[m] */
			real32_T headingTolerance;   /**< Toleranzgrenze, ab der der Positionsfilter neu initialisiert wird.[deg] */
			real32_T minKnownDistanceAhead; /**< Mindestlänge vor dem Fahrzeug für einen gültigen mapPath[m] */
			real32_T inhibitTimeFactor;  /**< Faktor für die Berücksichtigung der PSD Inhibit-Zeit[1] */
			real32_T inhibitTimeOffset;  /**< Fester Offset auf die psdPosition.inhibitTime[s] */
		} positionFilter;
		struct _parameterSetCtrl_pathRouter_holdFilter {
			real32_T holdDistance;       /**< Maximale Wegstrecke über die der letzte gültige mapPath bei Kartenfehlern gehalten wird[m] */
			uint32_T holdTicks;          /**< Maximale Anzahl von Control-Zeitschritten, über die der letzte gültige mapPath bei Kartenfehlern gehalten wird[20ms] */
			real32_T holdHeadDeviaton;   /**< Maximale Weg*Heading-Abweichung, über die der letzte gültige mapPath bei Kartenfehlern gehalten wird[m°] */
		} holdFilter;
		struct _parameterSetCtrl_pathRouter_turnFilter {
			real32_T normalDistance;     /**< Einfache Wegstrecke über die die virtuelle Position bei Abbiegevorgängen gehalten wird[m] */
			uint16_T normalTicks;        /**< Einfache Anzahl von Control-Zeitschritten, über die die virtuelle Position bei Abbiegevorgängen gehalten wird[20ms] */
			real32_T normalHeadDeviaton; /**< Einfache Weg*Heading-Abweichung, über die die virtuelle Position bei Abbiegevorgängen gehalten wird[m°] */
			real32_T extendedDistance;   /**< Erweiterte Wegstrecke über die die virtuelle Position bei Abbiegevorgängen mit Blinker gehalten wird[m] */
			uint16_T extendedTicks;      /**< Erweiterte Anzahl von Control-Zeitschritten, über die die virtuelle Position bei Abbiegevorgängen mit Blinker gehalten wird[20ms] */
			real32_T extendedHeadDeviaton; /**< Erweiterte Weg*Heading-Abweichung, über die die virtuelle Position bei Abbiegevorgängen mit Blinker gehalten wird[m°] */
		} turnFilter;
	} pathRouter;
	struct _parameterSetCtrl_systemController {
		uint16_T errorTicks;             /**< Entprellzeit, in der der nach einem internen Fehler der Zustand SystemError angezeigt werden soll.[20ms] */
		struct _parameterSetCtrl_systemController_longPressTime {
			real32_T initial;            /**< Zeit bis zum ersten erkennen eines gehaltenen Bedienelements. Maximum: (2^8)*controlCYCLETIME[s] */
			real32_T periodic;           /**< Zeit bis zum wiederholten erkennen eines gehaltenen Bedienelements. Maximum: (2^8)*controlCYCLETIME[s] */
		} longPressTime;
		struct _parameterSetCtrl_systemController_status {
			real32_T doubleClickTimeout; /**< Zeitfür einen Doppelklick. Maximum: (2^8)*controlCYCLETIME[s] */
			real32_T maxWaitTimeAccAcvn; /**< Maximale Wartezeit auf die Aktivierung von ACC nach der Bedienhandlung Set/Resume[s] */
			real32_T mapValidDebounceTime; /**< Entprellzeit für Ungültige Kartendaten (Kein PSD / Hochlauf). Maximum: (2^16)*controlCYCLETIME[s] */
			real32_T roadDataDebounceTime; /**< Entprellzeit für sonstige die Aktivierung verhindernde Kartendaten. Maximum: (2^16)*controlCYCLETIME[s] */
			real32_T strategyDebounceTime; /**< Entprellzeit für ungültige Strategie (longTorque). Maximum: (2^16)*controlCYCLETIME[s] */
			real32_T speedLimitDebounceTime; /**< Entprellzeit für zu niedriges Tempolimit. Maximum: (2^16)*controlCYCLETIME[s] */
			real32_T overrideDebounceTime; /**< Entprellzeit für Fahrpedalüberdrückung[s] */
			bool_T allowOnBadData;       /**< Aktive Regelung bei ungültigen Kartendaten zulassen */
			bool_T allowOnBadRoad;       /**< Aktive Regelung bei ungültiger Straßenklasse zulassen */
			bool_T allowOnBadLimit;      /**< Aktive Regelung bei ungültigem/zu geringem Speed Limit */
			bool_T overrideLeaveBOM;     /**< Aktive Regelung bei ungültigem/zu geringem Speed Limit */
			bool_T idleWhenSTPactive;    /**< Fahrereingaben bei aktiv regelndem Staupiloten sperren */
		} status;
		struct _parameterSetCtrl_systemController_velocityControl {
			real32_T thresholdStandStill; /**< Kriterium zur Erkennung des Fahrzeugstillstands[m/s] */
			real32_T hintSetDelta;       /**< Abweichung von der Setzgeschwindigkeit ueber der Hinweis aktiviert wird[m/s] */
			real32_T hintResetDelta;     /**< Abweichung von der Setzgeschwindigkeit unter der Hinweis deaktiviert wird[m/s] */
			uint8_T smallIncrementKmh;   /**< Schrittweite  1 km/h[km/h] */
			uint8_T bigIncrementKmh;     /**< Schrittweite 10 km/h[km/h] */
			uint8_T smallIncrementMph;   /**< Schrittweite 1  mph[mph] */
			uint8_T bigIncrementMph;     /**< Schrittweite 5  mph[mph] */
			uint8_T minSetSpeedKmh;      /**< Minimale Setzgeschwindigkeit  30 km/h[km/h] */
			uint8_T maxSetSpeedKmh;      /**< Maximale Setzgeschwindigkeit 210 km/h[km/h] */
			uint8_T minSetSpeedMph;      /**< Minimale Setzgeschwindigkeit  20 mp/h[mph] */
			uint8_T maxSetSpeedMph;      /**< Maximale Setzgeschwindigkeit 130 mp/h[mph] */
			real32_T bufferTimeLastSetSpeed; /**< Pufferzeit zur Widerherstellung der alten Setzgeschwindigkeit mit der Bedienhandlung LongPressResume.Maximum: (2^16)*controlCYCLETIME[s] */
			bool_T enableOverrideLimitPull; /**< Schalter zum Uebernehmen des naechsten Limits durch Fahrpedalueberdrueckung */
			bool_T enableOverrideLimitDrop; /**< Schalter zum Ignorieren des naechsten Limits durch Fahrpedalueberdrueckung */
			bool_T enableCancelTipActions; /**< Schalter zur Aktivierung des Abbrechens von Bedienaktionen */
		} velocityControl;
		struct _parameterSetCtrl_systemController_resumeAction {
			struct _parameterSetCtrl_systemController_resumeAction_manMode {
				bool_T acceptNextLimit;  /**< Im manuellen Modus die zukünftige Setzgeschwindigkeit auf das zukünftige Tempolimit setzen */
				bool_T acceptCurrentLimit; /**< Im manuellen Modus die aktuelle Setzgeschwindigkeit auf das aktuelle Tempolimit setzen */
			} manMode;
			struct _parameterSetCtrl_systemController_resumeAction_autoMode {
				bool_T discardNextLimit; /**< Im automatischen Modus das zukünftige Tempolimit verwerfen und mit der aktuellen Setzgeschwindigkeit weiter fahren */
				bool_T acceptNextLimit;  /**< Im automatischen Modus die zukünftige Setzgeschwindigkeit auf das zukünftige Tempolimit setzen und einen Offset verwerfen */
				bool_T discardCurrentLimit; /**< Im automatischen Modus das aktuelle Tempolimit verwerfen und mit einer gespeicherten letzten Setzgeschwindigkeit weiterfahren */
				bool_T acceptCurrentLimit; /**< Im automatischen Modus die aktuelle Setzgeschwindigkeit auf das aktuelle Tempolimit setzen und einen Offset verwerfen */
			} autoMode;
		} resumeAction;                  /**< Belegung der Bedienaktion Resume für die Setzgeschwindigkeitsverstellung im Bedienkonzept vereinfachter Offset */
		struct _parameterSetCtrl_systemController_limitPreview {
			real32_T timeMax;            /**< Maximale Vorausschauzeit für die Anzeige und Bedienung kommender Geschwindigkeitsbegrenzungen[s] */
			real32_T timeMin;            /**< Minimale Vorausschauzeit für die Anzeige und Bedienung kommender Geschwindigkeitsbegrenzungen[s] */
			real32_T distanceMin;        /**< Minimale Vorausschaudistanz im Stillstand[m] */
			real32_T revertThreshold;    /**< Positionstoleranz für die Rücknahme bereits getriggerter Limitwechsel[m] */
			real32_T positionOffset;     /**< Positionsoffset, der auf die von der Längsplanung gemeldete Reaktionsposition aufgeschlagen wird[m] */
		} limitPreview;
		struct _parameterSetCtrl_systemController_previewLock {
			real32_T timeTrigger;        /**< Zeitlicher Vorlauf für das Zurückhalten von Kurvenevents vor einer neuen Geschwindigkeitsbegrenzung[s] */
			real32_T revertThreshold;    /**< Positionstoleranz für die Rücknahme einer getriggerter Halteanforderung[m] */
		} previewLock;
		struct _parameterSetCtrl_systemController_speedCheck {
			bool_T enabled;              /**< Gibt an, ob die Setzgeschwindigkeitsüberwachung aktiv ist */
			uint16_T toleranceTicks;     /**< Toleranzzeit für das Überschreiten der Setzgeschwindigkeit[20 ms] */
			uint16_T rampTicks;          /**< Zeit für das Auf- und Abrampen der Toleranzreduktion[20 ms] */
			real32_T velocityHyst;       /**< Geschwindigkeitshysterese für das Rücksetzen des Filters[m/s] */
		} speedCheck;
		struct _parameterSetCtrl_systemController_stop {
			real32_T timeMax;            /**< Maximale Vorausschauzeit für die Anzeige und Bedienung kommender Geschwindigkeitsbegrenzungen[s] */
			real32_T timeMin;            /**< Minimale Vorausschauzeit für die Anzeige und Bedienung kommender Geschwindigkeitsbegrenzungen[s] */
			real32_T distanceMin;        /**< Minimale Vorausschaudistanz im Stillstand[m] */
			real32_T revertThreshold;    /**< Positionstoleranz für die Rücknahme bereits getriggerter Limitwechsel[m] */
			real32_T initSweepLength;    /**< Strecke, auf der Stoppstellen bei Aktivierung der Längsregelung einmlaig geräumt werden[m] */
			real32_T proximityEnter;     /**< Abstand zur Stoppstelle, bei dem eine Übernahmeaufforderung ausgelöst wird[m] */
			real32_T proximityHold;      /**< Maximaler Abstand vor der Stoppstelle, bis zu dem die Übernahmeaufforderung gehalten wird[m] */
			real32_T proximityLeave;     /**< Abstand zu einer zurückliegenden Stoppstelle, ab dem Anzeige und Übernahmeaufforderung zurückgenommen werden, wenn der Fahrer noch nicht reagiert hat[m] */
		} stop;
		struct _parameterSetCtrl_systemController_overrideReturn {
			real32_T velocityTolerance;  /**< Geschwindigkeitstoleranz (vEgo - vSet) ab der die overrideReturn-Flag zurueckgesetzt wird[m/s] */
		} overrideReturn;
		struct _parameterSetCtrl_systemController_countryList {
			uint8_T count;               /**< Anzahl freigegebener Länder */
			uint8_T list[prmNUMCOUNTRYLIST]; /**< Liste freigegebener Länder (Code entsprechend PSD_Sys_Laendercode [MIB-2_RQ_NAV_PSD_822]) */
		} countryList;
	} systemController;
	struct _parameterSetCtrl_vehicleObserver {
		struct _parameterSetCtrl_vehicleObserver_velocity {
			bool_T useDisplayVelocity;   /**< Gibt an, ob die Anzeigegeschwindigkeit als Referenz für die angenommene Längsgeschwindigkeit verwendet werden soll */
			real32_T refDecayFactor;     /**< Vergessensrate für den Abgleich mit der tatsächlichen Geschwindigkeit bei Verwendung der Anzeigegeschwindigkeit als Referenzwert */
			struct _parameterSetCtrl_vehicleObserver_velocity_tolerance {
				real32_T maxAbsolute;    /**< Maximale absolute Abweichung der angenommenen Längsgeschwindigkeit von der gemessenen Fahrzeuggeschwindigkeit[m/s] */
				real32_T minAbsolute;    /**< Minimale absolute Abweichung der angenommenen Längsgeschwindigkeit von der gemessenen Fahrzeuggeschwindigkeit[m/s] */
				real32_T maxRelative;    /**< Maximale relative Abweichung der angenommenen Längsgeschwindigkeit von der gemessenen Fahrzeuggeschwindigkeit[1] */
				real32_T minRelative;    /**< Minimale relative Abweichung der angenommenen Längsgeschwindigkeit von der gemessenen Fahrzeuggeschwindigkeit[1] */
			} tolerance;
			struct _parameterSetCtrl_vehicleObserver_velocity_inner {
				real32_T minTolerance;   /**< Untere Toleranzgrenze des inneren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T maxTolerance;   /**< Obere Toleranzgrenze des inneren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T factor;         /**< Korrekturfaktor für den inneren Bereich der Geschwindigkeitskorrektur[1] */
			} inner;
			struct _parameterSetCtrl_vehicleObserver_velocity_outer {
				real32_T minTolerance;   /**< Untere Toleranzgrenze des äußeren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T maxTolerance;   /**< Obere Toleranzgrenze des äußeren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T factor;         /**< Korrekturfaktor für den äußeren Bereich der Geschwindigkeitskorrektur[1] */
			} outer;
		} velocity;
		struct _parameterSetCtrl_vehicleObserver_deviation {
			real32_T updateFactor;       /**< Übertragungsfaktor, mit dem von Korrekturen der Modellgeschwindigkeit auf die Änderung der Zugkraftfehlerschätzung geschlossen wird[Ns/m] */
			real32_T bleedFactor;        /**< Übertragungsfaktor, mit dem der aktuell relevante Zugkraftfehler in jedem Rechenschritt auf den aktuell nicht relevanten Fehlerwert übertragen wird[1] */
			real32_T maxRate;            /**< Maximal zulässige Änderung der Zugkraftfehlerschätzung in einem Rechenschritt[N] */
			real32_T minRate;            /**< Minimal zulässige Änderung der Zugkraftfehlerschätzung in einem Rechenschritt[N] */
			real32_T minVelocity;        /**< Minimale Geschwindigkeit, ab der die Zugkraftfehlerschätzung aktiv wird[m/s] */
			struct _parameterSetCtrl_vehicleObserver_deviation_inner {
				real32_T minTolerance;   /**< Untere Toleranzgrenze des inneren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T maxTolerance;   /**< Obere Toleranzgrenze des inneren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T factor;         /**< Korrekturfaktor für den inneren Bereich der Geschwindigkeitskorrektur[1] */
			} inner;
			struct _parameterSetCtrl_vehicleObserver_deviation_outer {
				real32_T minTolerance;   /**< Untere Toleranzgrenze des äußeren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T maxTolerance;   /**< Obere Toleranzgrenze des äußeren Bereichs der Geschwindigkeitskorrektur[m/s] */
				real32_T factor;         /**< Korrekturfaktor für den äußeren Bereich der Geschwindigkeitskorrektur[1] */
			} outer;
			struct _parameterSetCtrl_vehicleObserver_deviation_stateLimit {
				real32_T minEngaged;     /**< Minimaler Ausgabewert für die Zugraftabweichung bei geschlossenem Triebstrang[N] */
				real32_T maxEngaged;     /**< Maximaler Ausgabewert für die Zugraftabweichung bei geschlossenem Triebstrang[N] */
				real32_T minDisengaged;  /**< Minimaler Ausgabewert für die Zugraftabweichung bei geöffnetem Triebstrang[N] */
				real32_T maxDisengaged;  /**< Maximaler Ausgabewert für die Zugraftabweichung bei geöffnetem Triebstrang[N] */
			} stateLimit;
			struct _parameterSetCtrl_vehicleObserver_deviation_filterLimit {
				real32_T minEngaged;     /**< Minimaler Ausgabewert für die Zugraftabweichung bei geschlossenem Triebstrang[N] */
				real32_T maxEngaged;     /**< Maximaler Ausgabewert für die Zugraftabweichung bei geschlossenem Triebstrang[N] */
				real32_T minDisengaged;  /**< Minimaler Ausgabewert für die Zugraftabweichung bei geöffnetem Triebstrang[N] */
				real32_T maxDisengaged;  /**< Maximaler Ausgabewert für die Zugraftabweichung bei geöffnetem Triebstrang[N] */
			} filterLimit;
			struct _parameterSetCtrl_vehicleObserver_deviation_gearLock {
				real32_T torqueTolerance; /**< Toleranz für die Abweichung zwischen gestelltem und als notwendig berechnetem Abtriebsmoment[N] */
				real32_T bleedRate;      /**< Abbaurate des Fehlerintegrals zwischen gestelltem und berechnetem Antriebsmoment[N] */
				real32_T thresholdLock;  /**< Grenzwert für das Fehlerintegral, bei dessen Überschreitung die Gangschnittstelle gesperrt wird[Ns] */
				real32_T thresholdUnlock; /**< Grenzwert für das Fehlerintegral, bei dessen Unterschreitung die Gangschnittstelle wieder freigegeben werden kann[Ns] */
				real32_T entryJerk;      /**< Maximalruck, mit dem die angeforderte Sollbeschleunigung beim Sperren der Gangschnittstelle einschgeschränkt wird[m/s^3] */
			} gearLock;
		} deviation;
		struct _parameterSetCtrl_vehicleObserver_heading {
			real32_T updateFactor;       /**< Anteil der Differenz zwischen von der Karte gemeldetem und angenommenem Heading, der pro Zeitschritt als Korrektur übernommen wird[1] */
			real32_T maxDeviation;       /**< Maximale Abweichung zwischen angenommener und von der Karte gemeldeter Fahrtrichtung[°] */
			real32_T minDeviation;       /**< Minimale Abweichung zwischen angenommener und von der Karte gemeldeter Fahrtrichtung[°] */
			real32_T maxHeadingInvalidTime; /**< Zeit, die das Heading-Signal vom GPS ungültig sein darf, bevor es im vehicle-observer auf ungültig gesetzt wird[s] */
		} heading;
		struct _parameterSetCtrl_vehicleObserver_steering {
			real32_T angleRateCutOff;    /**< Grenzfrequenz der Tiefpass-Filterung der Lenkradwinkelgeschwindigkeit für die prädizierte Bahnrümmung[Hz] */
			real32_T slowAngleCutOff;    /**< Grenzfrequenz der Tiefpass-Filterung der nachlaufenden Lenkradinwkels für das Anheben von Krümmungs-Constraints[Hz] */
			real32_T predTime;           /**< Zeithorizot der prädizierten Bahnkrümmung[s] */
		} steering;
		struct _parameterSetCtrl_vehicleObserver_curvature {
			real32_T curvatureCutOff;    /**< Grenzfrequenz für die Tiefpass-Filterung der von der Spurerkennung gemeldeten Fahrbahnkrümmung[Hz] */
			real32_T curveRateCutOff;    /**< Grenzfrequenz für die Tiefpass-Filterung der von der Spurerkennung gemeldeten Krümmungsänderung[Hz] */
			real32_T distanceCutOff;     /**< Grenzfrequenz für die Tiefpass-Filterung der von der Spurerkennung gemeldeten Sichtweite[Hz] */
			real32_T confidenceCutOff;   /**< Grenzfrequenz für die Tiefpass-Filterung der von der Spurerkennung gemeldeten Verlässlichkeit[Hz] */
		} curvature;
		struct _parameterSetCtrl_vehicleObserver_slope {
			real32_T tskTolerance;       /**< Toleranz um den vom TSK gemeldeten Steigungswert beim Abgleich mit der gemeldeten Kartensteigung[1] */
		} slope;
		struct _parameterSetCtrl_vehicleObserver_turnSignal {
			real32_T previewTime;        /**< Zeitlicher Abstand, ab dem eine Abzweigung als möglich betrachtet wird[s] */
			uint16_T confTickCount;      /**< Anzahl der Control-Zeitschritte [0.02s], ab denen von gerastetem Blinken ausgegangen wird[1] */
			uint16_T holdTickCount;      /**< Anzahl der Control-Zeitschritte [0.02s], die das Signal turnSignal.extendHold nach einem Blinker-Ereignis gehalten wird.[1] */
			uint16_T lockTickCount;      /**< Anzahl der Control-Zeitschritte [0.02s], die das Signal turnSignal.lockRight gehalten Wird, nachdem das Fahrzeug bei gesetztem Blinker auf die rechte Spur gewechselt ist.[1] */
			bool_T lockByLane;           /**< Gibt an, ob die Pfadwahl ueber Blinken auf Basis der aktuellen Fahrspur gesperrt werden soll */
			bool_T forceByType;          /**< Gibt an, ob die Pfadwahl auf Basis des erkannten Spurtyps durchgefuehrt werden soll */
		} turnSignal;
		struct _parameterSetCtrl_vehicleObserver_traffic {
			struct _parameterSetCtrl_vehicleObserver_traffic_offset {
				uint16_T rampTicks;      /**< Anzahl der Control-Zeitschritte, in denen der Traffic-Offset auf- und abgerampt wird[20ms] */
				real32_T velocity;       /**< Geschwindigkeitsoffset, der für eine ACC-Übergabe auf das Zielfahrzeug aufgerechnet wird[m/s] */
				real32_T acceleration;   /**< Beschleunigungsoffset, der für eine ACC-Übergabe auf das Zielfahrzeug aufgerechnet wird[m/s²] */
			} offset;
			real32_T accelerationCutOff; /**< Grenzfrequenz für die Tiefpassfilterung der Zielfahrzeug-Beschleunigung[1/s] */
			bool_T useEgoAcceleration;   /**< Gibt an, ob die Ego-Beschleunigung als Bezugsgröße für die Relativbeschleunigung herangezogen werden soll */
		} traffic;
		struct _parameterSetCtrl_vehicleObserver_courage {
			struct _parameterSetCtrl_vehicleObserver_courage_wetness {
				bool_T enabled;          /**< Ob das Naesselevel zur Anpassung der maximalen Querbeschleunigung berücksichtigt wird. */
				struct _parameterSetCtrl_vehicleObserver_courage_wetness_adaptionFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in Kennlinie Lenkradwinkel->Anpassrate */
					real32_T level[prmNUMWETNESSFACTOR]; /**< Naesselevel[n/a] */
					real32_T factor[prmNUMWETNESSFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[1] */
				} adaptionFactor;        /**< Kennlinie Lenkradwinkel->Anpassrate */
			} wetness;
			struct _parameterSetCtrl_vehicleObserver_courage_friction {
				bool_T enabled;          /**< Ob Reibwert zur Anpassung der maximalen Querbeschleunigung berücksichtigt wird. */
				struct _parameterSetCtrl_vehicleObserver_courage_friction_adaptionFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in Kennlinie Lenkradwinkel->Anpassrate */
					real32_T level[prmNUMFRICTIONFACTOR]; /**< Reibwert[n/a] */
					real32_T factor[prmNUMFRICTIONFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[1] */
				} adaptionFactor;        /**< Kennlinie Lenkradwinkel->Anpassrate */
			} friction;
			struct _parameterSetCtrl_vehicleObserver_courage_width {
				struct _parameterSetCtrl_vehicleObserver_courage_width_adaptionFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in Kennlinie Lenkradwinkel->Anpassrate */
					real32_T angle[prmNUMADAPTIONRATE]; /**< Lenkradwinkel[rad] */
					real32_T rate[prmNUMADAPTIONRATE]; /**< Faktor für die Anpassraten des Filters[1] */
				} adaptionFactor;        /**< Kennlinie Lenkradwinkel->Anpassrate */
				real32_T faultDistance;  /**< Default-Markierungsabstand, mit dem gerechnet wird, wenn keine Datne zur Verfügung stehen[m] */
				real32_T avgCutOffFreq;  /**< Grenzfrequenz für die Tiefpass-Filterung des durchschnittlichen Abstands zur Markierung[Hz] */
				real32_T pullVelocity;   /**< Virtuelle 'Geschwindigkeit', mit der die Min- und Maxwerte für den Abstand vom Durchschnitt weggezogen werden[m/s] */
				real32_T driftVelocity;  /**< Virtuelle 'Geschwindigkeit', mit der die Min- und Maxwerte für den Abstand zum Durchschnitt zurück driften[m/s] */
				real32_T averageDiv;     /**< Intervall des durchschnittlichen Abstands zur Seitenlinie, über dem die maximale Querbeschleunigungsanpassung linear aufgerampt wird[m] */
				real32_T averageMin;     /**< Mindestwert für den durchschnittlichen Abstand zur Seitenlinie, ab dem eine Querbeschleunigungsanpassung angefordert wird[m] */
				real32_T differenceDiv;  /**< Intervall der Differenz zwischen Minimal- und Maximalabstand zur Seitenlinie, über dem die maximale Querbeschleunigungsanpassung linear aufgerampt wird[m] */
				real32_T differenceMin;  /**< Mindestwert für die Differenz zwischen Minimal- und Maximalabstand zur Seitenlinie, ab dem eine Querbeschleunigungsanpassung angefordert wird[m] */
				real32_T confidenceRate; /**< Anpassrate des Konfidenzwerts[m] */
			} width;
			struct _parameterSetCtrl_vehicleObserver_courage_curtain {
				struct _parameterSetCtrl_vehicleObserver_courage_curtain_tailFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in der Kennlinie Wegstrecke->Anpassfaktor */
					real32_T tail[prmNUMTAILFACTOR]; /**< Zurückgelegte Wegstrecke im Kreisverkehr[m] */
					real32_T factor[prmNUMTAILFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[1] */
				} tailFactor;            /**< Kennlinie Wegstrecke im Kreisverkehr->Anpassfaktor */
				struct _parameterSetCtrl_vehicleObserver_courage_curtain_curvatureFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in der Kennlinie Krümmungsabweichung->Anpassfaktor */
					real32_T curvature[prmNUMCURVATUREFACTOR]; /**< Abweichung zwischen Karten- und Lenkradkrümmung[1/m] */
					real32_T factor[prmNUMCURVATUREFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[1] */
				} curvatureFactor;       /**< Kennlinie Krümmungsabweichung->Anpassfaktor */
			} curtain;
			struct _parameterSetCtrl_vehicleObserver_courage_limit {
				real32_T maxHorizon;     /**< Maximaler Abstand von Geschwindigkeitslimits, die als bekannt aus dem Horizont aufgenommen werden[m] */
				real32_T minHorizon;     /**< Maximaler negativer Abstand von Geschwindigkeitslimits, die als bekannt aus dem Horizont aufgenommen werden[m] */
				uint16_T holdTicks;      /**< Anzahl der Control-Zeitschritte, für die ein bekanntes Speed Limit-Fenster ohne gültige Vorausschau gehalten wird[20ms] */
				real32_T maxVelocity;    /**< Maximale Geschwindigkeit, die für den Filter berücksichtigt wird[m/s] */
				struct _parameterSetCtrl_vehicleObserver_courage_limit_upperDeviation {
					uint16_T count;      /**< Anzahl gültiger Elemente in der Kennlinie Speed Limit-Abweichung->Anpassfaktor */
					real32_T deviation[prmNUMLIMITDEVFACTOR]; /**< Abweichung aktuellem und maximalem Limit[m/s] */
					real32_T factor[prmNUMLIMITDEVFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[n/a] */
				} upperDeviation;
				struct _parameterSetCtrl_vehicleObserver_courage_limit_lowerDeviation {
					uint16_T count;      /**< Anzahl gültiger Elemente in der Kennlinie Speed Limit-Abweichung->Anpassfaktor */
					real32_T deviation[prmNUMLIMITDEVFACTOR]; /**< Abweichung aktuellem und minimalem Limit[m/s] */
					real32_T factor[prmNUMLIMITDEVFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[n/a] */
				} lowerDeviation;
			} limit;
			struct _parameterSetCtrl_vehicleObserver_courage_follow {
				struct _parameterSetCtrl_vehicleObserver_courage_follow_gapFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in der Kennlinie Speed Limit-Abweichung->Anpassfaktor */
					real32_T timeGap[prmNUMFOLLOWGAPFACTOR]; /**< Abweichung zwischen Karten- und Lenkradkrümmung[s] */
					real32_T factor[prmNUMFOLLOWGAPFACTOR]; /**< Anpassfaktor für das Aufheben der Geschwindigkeitseinschränkungen[n/a] */
				} gapFactor;
			} follow;
			struct _parameterSetCtrl_vehicleObserver_courage_reset {
				struct _parameterSetCtrl_vehicleObserver_courage_reset_ageFactor {
					uint16_T count;      /**< Anzahl gültiger Elemente in der Kennlinie Kartenalter->Anpassfaktor */
					real32_T ticks[prmNUMRESETAGEFACTOR]; /**< Anzahl der Control-Zeitschritte, in denen durchgängig ein PSD-Baum verfügbar war[20ms] */
					real32_T factor[prmNUMRESETAGEFACTOR]; /**< Anpassfaktor für den Längsruck[n/a] */
				} ageFactor;
			} reset;
			real32_T curvatureMax;       /**< Maximaler Anpassfaktor für die Querbeschleunigung[1/s] */
			real32_T curvatureMin;       /**< Minimaler Anpassfaktor für die Querbeschleunigung[1/s] */
			real32_T curvatureRateMax;   /**< Maximale Änderungsrate des Anpassfaktors für die Querbeschleunigung[1/s] */
			real32_T curvatureRateMin;   /**< Maximale Änderungsrate des Anpassfaktors für die Querbeschleunigung[1/s] */
			real32_T curtainMaxRate;     /**< Maximale Änderungsrate des Anpassfaktors für die zulässige Geschwindigkeit im Kreisverkehr[1/s] */
			real32_T curtainMinRate;     /**< Maximale Änderungsrate des Anpassfaktors für die zulässige Geschwindigkeit im Kreisverkehr[1/s] */
			real32_T maxJerkMaxRate;     /**< Maximale Änderungsrate des Anpassfaktors für den zulässigen Maximalruck[1/s] */
			real32_T limitJerkMaxRate;   /**< Maximale Änderungsrate des Anpassfaktors für die Reaktion auf Geschwindigkeitslimits[1/s] */
			real32_T curveJerkMaxRate;   /**< Maximale Änderungsrate des Anpassfaktors für die Reaktion auf Geschwindigkeitslimits[1/s] */
		} courage;
		struct _parameterSetCtrl_vehicleObserver_check {
			real32_T codeCheckTimeout;   /**< Entprellzeit für das Setzen eines Fehlerspeichereintrags bei ungültiger Längspfaplanung. Maximalwert deaktiviert das Setzen des Eintrags.[s] */
			real32_T velocityCheckTimeout; /**< Entprellzeit für das Setzen eines Fehlerspeichereintrags bei ungültiger Längspfaplanung. Maximalwert deaktiviert das Setzen des Eintrags.[s] */
			real32_T controlCheckTimeout; /**< Entprellzeit für das Setzen eines Fehlerspeichereintrags bei ungültiger Längspfaplanung. Maximalwert deaktiviert das Setzen des Eintrags.[s] */
		} check;
		struct _parameterSetCtrl_vehicleObserver_sign {
			bool_T holdReleased;         /**< Festahlten eines von der VZE erkanntes 'Tempolimit unbegrenzt', wenn die VZE anschließend 'Tempolimit unbekannt' ausgibt */
		} sign;
		struct _parameterSetCtrl_vehicleObserver_accBoost {
			real32_T holdTime;           /**< Wartezeit für die Erkennung der ACC-Boost-Funktion[s] */
		} accBoost;
		struct _parameterSetCtrl_vehicleObserver_lockCoast {
			real32_T waitTime;           /**< Wartezeit für die Erkennung das Sperren der Segelanforderung[s] */
			real32_T lockTime;           /**< Mindest-Sperrzeit der Segelanforderung[s] */
			struct _parameterSetCtrl_vehicleObserver_lockCoast_maxBrakeTorque {
				uint16_T count;          /**< Anzahl gültiger Elemente in Kennlinie Geschwindigkeit->Bremsmoment */
				real32_T velocity[prmNUMMAXBRAKETORQUE]; /**< Geschwindigkeit[m/s] */
				real32_T torque[prmNUMMAXBRAKETORQUE]; /**< Bremsmoment[Nm] */
			} maxBrakeTorque;
		} lockCoast;
	} vehicleObserver;
	uint16_T bufferSize;                 /**< Buffer fuer zukuenftige Datenelemente */
} parameterSetCtrl_T;                    /**< Groesse der Struktur = 2832 Bytes */


/*lint -restore */

#endif
