#ifndef guard_parameterSetCtrlTools_h
#define guard_parameterSetCtrlTools_h

#include "common/common.h"

#include "control/parameterSet/parameterSetCtrl_interface.h"


/** \brief	Lesezugriff auf die Applikationsparameter f�r den Control-Task
\spec SwMS_Innodrive2_Model_57
*/
const parameterSetCtrl_T*	 prmGetParameterSetCtrl(void);

/** \brief	Schreibzugriff auf die Applikationsparameter f�r den Control-Task

Im Produktivcode nur zur Initialisierung aufrufen.

\spec SwMS_Innodrive2_Model_57
*/
void					   prmApplyParameterSetCtrl(IN	const	parameterSetCtrl_T		*parameterSet);

/** \brief Ob die Applikationsparameter des Control-Task Initialisiert worden sind.

Flag wird in \ref prmApplyParameterSetCtrl() gesetzt.

\spec SwMS_Innodrive2_Model_57
*/
bool_T					  prmIsParameterSetCtrlInit(void);


#if comMULTITHREADAWARE
		bool_T	                   prmEnableThreadLocalParameterCtrlSets(void);
		bool_T	                   prmDisableThreadLocalParameterCtrlSets(void);
		bool_T	                   prmSetLocalParameterSetCtrlPtr(parameterSetCtrl_T *paramSet);
#endif



/** \} */

#endif

