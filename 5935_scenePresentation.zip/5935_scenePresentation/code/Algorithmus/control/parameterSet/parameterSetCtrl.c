#include <string.h>
#include "parameterSetCtrl.h"

#if comMULTITHREADAWARE

#pragma warning(disable : 4255)
#pragma warning(disable : 4668)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#include "control/parameterSet/PpDsParameterSetCtrl.h"

#if !defined INNODRIVE_ZFAS_SWC_BUILD
#include "control/parameterSet/setTstParameterSetCtrl.h"
#endif

#if comMULTITHREADAWARE
static bool_T			tlsInit;
static DWORD			tlsIndexParam;
static DWORD			tlsIndexParamInit;
#endif


/*lint -esym(750, CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT) (Info -- local macro not referenced [MISRA 2012 Rule 2.5, advisory])*/
/*lint -esym(750, CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT) (Info -- local macro not referenced [MISRA 2012 Rule 2.5, advisory])*/
/*lint -esym(766, MemMap.h) (Info -- Header file not used in module 'C:\Data\TFS\992\feature\2500_pcLint\code\Algorithmus\control\parameterSet\parameterSetCtrl.c')*/
/*lint -save -e9019 (Note -- declaration before #include [MISRA 2012 Rule 20.1, advisory]*/
#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
static bool_T				bParameterSetInit;
static parameterSetCtrl_T	glbParameterSet;
#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
/*lint -restore*/

const parameterSetCtrl_T*	 prmGetParameterSetCtrl(void)
{
#if comMULTITHREADAWARE
	if (tlsInit) {
		parameterSetCtrl_T *tlsParameterSet;
		tlsParameterSet = (parameterSetCtrl_T*)TlsGetValue(tlsIndexParam);

		if (tlsParameterSet) {
			if (!TlsGetValue(tlsIndexParamInit)) {
				setparameterSetCtrlDefaultData(tlsParameterSet);
				TlsSetValue(tlsIndexParamInit, tlsParameterSet);
			}
			return tlsParameterSet;
		}
	}
	else {
		if (!bParameterSetInit) {
			if (setparameterSetCtrlDefaultData(&glbParameterSet))
			{
				bParameterSetInit = true;
			} else {
				bParameterSetInit = false;
			}
		}
	}
#endif

	if (!bParameterSetInit)
	{
#if !defined INNODRIVE_ZFAS_SWC_BUILD
		if (setparameterSetCtrlDefaultData(&glbParameterSet))
		{
			bParameterSetInit = true;
		}
		else 
		{
			bParameterSetInit = false;
		}
#endif
	}

	return (&glbParameterSet);
}


#if comMULTITHREADAWARE
bool_T	  prmEnableThreadLocalParameterCtrlSets(void)
{
	if (!tlsInit) {
		if ((tlsIndexParam = TlsAlloc()) == TLS_OUT_OF_INDEXES) {
			return false;
		}

		if ((tlsIndexParamInit = TlsAlloc()) == TLS_OUT_OF_INDEXES) {
			return false;
		}

		tlsInit = true;
	}

	return true;
}


bool_T	 prmDisableThreadLocalParameterCtrlSets(void)
{
	if (tlsInit) {
		TlsFree(tlsIndexParam);
		TlsFree(tlsIndexParamInit);
		tlsInit = false;
	}

	return true;
}


bool_T	prmSetLocalParameterSetCtrlPtr(parameterSetCtrl_T *paramSet)
{
	if (tlsInit) {
		TlsSetValue(tlsIndexParamInit, 0);
		return (TRUE == TlsSetValue(tlsIndexParam, paramSet));
	}

	return false;
}
#endif


void					   prmApplyParameterSetCtrl(IN	const	parameterSetCtrl_T		*parameterSet)
												
{
#if comMULTITHREADAWARE
	if (tlsInit) {
		parameterSetCtrl_T *tlsParameterSet;
		tlsParameterSet = (parameterSetCtrl_T*)TlsGetValue(tlsIndexParam);

		if(tlsParameterSet) {
			TlsSetValue(tlsIndexParamInit, tlsParameterSet);
			memcpy(tlsParameterSet, parameterSet, sizeof(parameterSetCtrl_T));
		}
	}
	else {
		bParameterSetInit	= true;
		memcpy(&glbParameterSet, parameterSet, sizeof(parameterSetCtrl_T));
	}
#endif

	bParameterSetInit	= true;
	memcpy(&glbParameterSet, parameterSet, sizeof(parameterSetCtrl_T));
}


bool_T					  prmIsParameterSetCtrlInit(void)
{
	return bParameterSetInit;
}
