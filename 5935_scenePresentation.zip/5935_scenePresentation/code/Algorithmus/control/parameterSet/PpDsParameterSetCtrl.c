#include "control/parameterSet/PpDsParameterSetCtrl.h"

#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#define Log_AddMsg(ID, Group, Option, ...)
#else
#include "Log.h"
#endif


/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e9029	"Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required]" */
/*lint -e9033	"Note -- Impermissible cast of composite expression (wider essential type for the destination) [MISRA 2012 Rule 10.8, required]" */
/*lint -e9087	"(Note -- cast performed between a pointer to object type and a pointer to a different object type[MISRA 2012 Rule 11.3, required])" */
/* e9087 comment: memcpy want a void* as parameter, so we must do this cast" */

ICC_API bool_T rteInConvert_parameterSetCtrl(const Dt_RECORD_InnoDriveControlParameterSetCtrl *p_theSrcData, parameterSetCtrl_T *p_theDestData)
{
	uint32_T uiArrIdx;
	uint32_T uiBufIdx = 0;
	const uint8_T* pRteBuf;

	pRteBuf = &p_theSrcData->DeData.debugBuffer[0];
	BUILD_BUG_ON((uint32_T)32 > sizeof(p_theSrcData->DeData.debugBuffer));

	p_theDestData->checksumCrc32                                                  = p_theSrcData->DeData.checksumCrc32;
	if( parameterSetCtrlCrc32 != p_theDestData->checksumCrc32)
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_ERROR, "Checksum error!! Include=%d, Dataset=%d", parameterSetCtrlCrc32, p_theDestData->checksumCrc32);
		return false;
	}

	p_theDestData->displayController.velocityThreshold.eventFire                  = p_theSrcData->DeData.displayController_velocityThreshold_eventFire;
	p_theDestData->displayController.velocityThreshold.eventHold                  = p_theSrcData->DeData.displayController_velocityThreshold_eventHold;
	p_theDestData->displayController.accelerationThreshold.eventFire              = p_theSrcData->DeData.displayController_accelerationThreshold_eventFire;
	p_theDestData->displayController.accelerationThreshold.eventHold              = p_theSrcData->DeData.displayController_accelerationThreshold_eventHold;
	p_theDestData->displayController.significanceThreshold.eventFire              = p_theSrcData->DeData.displayController_significanceThreshold_eventFire;
	p_theDestData->displayController.significanceThreshold.eventHold              = p_theSrcData->DeData.displayController_significanceThreshold_eventHold;
	p_theDestData->displayController.curveTakeover.thresholdSet                   = p_theSrcData->DeData.displayController_curveTakeover_thresholdSet;
	p_theDestData->displayController.curveTakeover.thresholdHold                  = p_theSrcData->DeData.displayController_curveTakeover_thresholdHold;
	p_theDestData->displayController.ttcThreshold                                 = p_theSrcData->DeData.displayController_ttcThreshold;
	p_theDestData->displayController.previewThreshold                             = p_theSrcData->DeData.displayController_previewThreshold;
	p_theDestData->displayController.previewCutOff                                = p_theSrcData->DeData.displayController_previewCutOff;
	p_theDestData->driverObserver.inputFilter.longAccelerationFilterTime          = p_theSrcData->DeData.driverObserver_inputFilter_longAccelerationFilterTime;
	p_theDestData->driverObserver.inputFilter.latAccelerationFilterTime           = p_theSrcData->DeData.driverObserver_inputFilter_latAccelerationFilterTime;
	p_theDestData->driverObserver.inputFilter.velocityFilterTime                  = p_theSrcData->DeData.driverObserver_inputFilter_velocityFilterTime;
	p_theDestData->driverObserver.inputFilter.acceleratorFilterTime               = p_theSrcData->DeData.driverObserver_inputFilter_acceleratorFilterTime;
	p_theDestData->driverObserver.dynamicValues.lowPassTimeConstant               = p_theSrcData->DeData.driverObserver_dynamicValues_lowPassTimeConstant;
	p_theDestData->driverObserver.dynamicValues.countryInit.longAcceleration      = p_theSrcData->DeData.driverObserver_dynamicValues_countryInit_longAcceleration;
	p_theDestData->driverObserver.dynamicValues.countryInit.longDeceleration      = p_theSrcData->DeData.driverObserver_dynamicValues_countryInit_longDeceleration;
	p_theDestData->driverObserver.dynamicValues.countryInit.latAcceleration       = p_theSrcData->DeData.driverObserver_dynamicValues_countryInit_latAcceleration;
	p_theDestData->driverObserver.dynamicValues.countryInit.offsetVelocity        = p_theSrcData->DeData.driverObserver_dynamicValues_countryInit_offsetVelocity;
	p_theDestData->driverObserver.dynamicValues.countryRadarInit.longAcceleration = p_theSrcData->DeData.driverObserver_dynamicValues_countryRadarInit_longAcceleration;
	p_theDestData->driverObserver.dynamicValues.countryRadarInit.longDeceleration = p_theSrcData->DeData.driverObserver_dynamicValues_countryRadarInit_longDeceleration;
	p_theDestData->driverObserver.dynamicValues.countryRadarInit.latAcceleration  = p_theSrcData->DeData.driverObserver_dynamicValues_countryRadarInit_latAcceleration;
	p_theDestData->driverObserver.dynamicValues.countryRadarInit.offsetVelocity   = p_theSrcData->DeData.driverObserver_dynamicValues_countryRadarInit_offsetVelocity;
	p_theDestData->driverObserver.dynamicValues.cityInit.longAcceleration         = p_theSrcData->DeData.driverObserver_dynamicValues_cityInit_longAcceleration;
	p_theDestData->driverObserver.dynamicValues.cityInit.longDeceleration         = p_theSrcData->DeData.driverObserver_dynamicValues_cityInit_longDeceleration;
	p_theDestData->driverObserver.dynamicValues.cityInit.latAcceleration          = p_theSrcData->DeData.driverObserver_dynamicValues_cityInit_latAcceleration;
	p_theDestData->driverObserver.dynamicValues.cityInit.offsetVelocity           = p_theSrcData->DeData.driverObserver_dynamicValues_cityInit_offsetVelocity;

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_longAccelerationLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_longAccelerationLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.longAccelerationLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_longAccelerationLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_longDecelerationLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_longDecelerationLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.longDecelerationLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_longDecelerationLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_latAccelerationLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_latAccelerationLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.latAccelerationLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_latAccelerationLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_wheelPowerLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_wheelPowerLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.wheelPowerLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_wheelPowerLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_acceleratorGradLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_acceleratorGradLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.acceleratorGradLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_acceleratorGradLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_maxJerkLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_maxJerkLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.maxJerkLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_maxJerkLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_minJerkLevels) / sizeof(p_theSrcData->DeData.driverObserver_escalation_minJerkLevels[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.minJerkLevels[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_minJerkLevels[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_escalation_deescalationTimes) / sizeof(p_theSrcData->DeData.driverObserver_escalation_deescalationTimes[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.escalation.deescalationTimes[uiArrIdx] = p_theSrcData->DeData.driverObserver_escalation_deescalationTimes[uiArrIdx]; 
	}
	p_theDestData->driverObserver.desiredSpeed.minVelocityRampDown                = p_theSrcData->DeData.driverObserver_desiredSpeed_minVelocityRampDown;
	p_theDestData->driverObserver.desiredSpeed.velocityTolerance                  = p_theSrcData->DeData.driverObserver_desiredSpeed_velocityTolerance;
	p_theDestData->driverObserver.desiredSpeed.velocityToleranceLarge             = p_theSrcData->DeData.driverObserver_desiredSpeed_velocityToleranceLarge;
	p_theDestData->driverObserver.desiredSpeed.onlineSpeedTolerance               = p_theSrcData->DeData.driverObserver_desiredSpeed_onlineSpeedTolerance;
	p_theDestData->driverObserver.desiredSpeed.longAccelerationToleranceUp        = p_theSrcData->DeData.driverObserver_desiredSpeed_longAccelerationToleranceUp;
	p_theDestData->driverObserver.desiredSpeed.longAccelerationToleranceDown      = p_theSrcData->DeData.driverObserver_desiredSpeed_longAccelerationToleranceDown;
	p_theDestData->driverObserver.desiredSpeed.longDecelerationTolerance          = p_theSrcData->DeData.driverObserver_desiredSpeed_longDecelerationTolerance;
	p_theDestData->driverObserver.desiredSpeed.longAccTolPushNextLimit            = p_theSrcData->DeData.driverObserver_desiredSpeed_longAccTolPushNextLimit;
	p_theDestData->driverObserver.desiredSpeed.latAccelerationTolerance           = p_theSrcData->DeData.driverObserver_desiredSpeed_latAccelerationTolerance;
	p_theDestData->driverObserver.desiredSpeed.extrapolationTime                  = p_theSrcData->DeData.driverObserver_desiredSpeed_extrapolationTime;
	p_theDestData->driverObserver.desiredSpeed.rampDownTime                       = p_theSrcData->DeData.driverObserver_desiredSpeed_rampDownTime;
	p_theDestData->driverObserver.desiredSpeed.bufferTimeAfterLimit               = p_theSrcData->DeData.driverObserver_desiredSpeed_bufferTimeAfterLimit;
	p_theDestData->driverObserver.desiredSpeed.bufferLengthBeforeLimit            = p_theSrcData->DeData.driverObserver_desiredSpeed_bufferLengthBeforeLimit;
	p_theDestData->driverObserver.desiredSpeed.maxDistanceNextLimit               = p_theSrcData->DeData.driverObserver_desiredSpeed_maxDistanceNextLimit;
	p_theDestData->driverObserver.offsetVelocity.lowPassTimeConstant              = p_theSrcData->DeData.driverObserver_offsetVelocity_lowPassTimeConstant;

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_offsetVelocity_lowerBounds) / sizeof(p_theSrcData->DeData.driverObserver_offsetVelocity_lowerBounds[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.offsetVelocity.lowerBounds[uiArrIdx] = p_theSrcData->DeData.driverObserver_offsetVelocity_lowerBounds[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_offsetVelocity_upperBounds) / sizeof(p_theSrcData->DeData.driverObserver_offsetVelocity_upperBounds[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.offsetVelocity.upperBounds[uiArrIdx] = p_theSrcData->DeData.driverObserver_offsetVelocity_upperBounds[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_offsetVelocity_initialValues) / sizeof(p_theSrcData->DeData.driverObserver_offsetVelocity_initialValues[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.offsetVelocity.initialValues[uiArrIdx] = p_theSrcData->DeData.driverObserver_offsetVelocity_initialValues[uiArrIdx]; 
	}
	p_theDestData->driverObserver.maxVelocity.lowPassTimeConstantUp               = p_theSrcData->DeData.driverObserver_maxVelocity_lowPassTimeConstantUp;
	p_theDestData->driverObserver.maxVelocity.lowPassTimeConstantDown             = p_theSrcData->DeData.driverObserver_maxVelocity_lowPassTimeConstantDown;

	BUILD_BUG_ON((uint32_T)dobsMAXLEVELCOUNT != sizeof(p_theSrcData->DeData.driverObserver_maxVelocity_initialValues) / sizeof(p_theSrcData->DeData.driverObserver_maxVelocity_initialValues[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		p_theDestData->driverObserver.maxVelocity.initialValues[uiArrIdx] = p_theSrcData->DeData.driverObserver_maxVelocity_initialValues[uiArrIdx]; 
	}
	p_theDestData->driverObserver.environment.standStillVelocityTolerance         = p_theSrcData->DeData.driverObserver_environment_standStillVelocityTolerance;
	p_theDestData->driverObserver.environment.radarPropagationTime                = p_theSrcData->DeData.driverObserver_environment_radarPropagationTime;
	p_theDestData->driverObserver.environment.radarTimeGapIn                      = p_theSrcData->DeData.driverObserver_environment_radarTimeGapIn;
	p_theDestData->driverObserver.environment.radarTimeGapOut                     = p_theSrcData->DeData.driverObserver_environment_radarTimeGapOut;
	p_theDestData->driverObserver.environment.radarRelativeVelocityIn             = p_theSrcData->DeData.driverObserver_environment_radarRelativeVelocityIn;
	p_theDestData->driverObserver.environment.radarRelativeVelocityOut            = p_theSrcData->DeData.driverObserver_environment_radarRelativeVelocityOut;
	p_theDestData->driverObserver.environment.radarDebounceTime                   = p_theSrcData->DeData.driverObserver_environment_radarDebounceTime;
	p_theDestData->driverObserver.environment.highwayDebounceDynEventBefore       = p_theSrcData->DeData.driverObserver_environment_highwayDebounceDynEventBefore;
	p_theDestData->driverObserver.environment.highwayDebounceDynEventAfter        = p_theSrcData->DeData.driverObserver_environment_highwayDebounceDynEventAfter;
	p_theDestData->driverObserver.environment.builtUpSpeedLimit                   = p_theSrcData->DeData.driverObserver_environment_builtUpSpeedLimit;
	p_theDestData->driverPredictor.deltaTime                                      = p_theSrcData->DeData.driverPredictor_deltaTime;
	p_theDestData->driverPredictor.minAcceleration                                = p_theSrcData->DeData.driverPredictor_minAcceleration;
	p_theDestData->driverPredictor.minAccelerationFactor                          = p_theSrcData->DeData.driverPredictor_minAccelerationFactor;
	p_theDestData->driverPredictor.onlineLimit.offset                             = p_theSrcData->DeData.driverPredictor_onlineLimit_offset;
	p_theDestData->driverPredictor.onlineLimit.maxSpeedLimit                      = p_theSrcData->DeData.driverPredictor_onlineLimit_maxSpeedLimit;
	p_theDestData->driverPredictor.onlineLimit.factor                             = p_theSrcData->DeData.driverPredictor_onlineLimit_factor;

	BUILD_BUG_ON((uint32_T)dprdMAXRANGECOUNT != sizeof(p_theSrcData->DeData.driverPredictor_containerRange_latAcceleration) / sizeof(p_theSrcData->DeData.driverPredictor_containerRange_latAcceleration[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		p_theDestData->driverPredictor.containerRange.latAcceleration[uiArrIdx] = p_theSrcData->DeData.driverPredictor_containerRange_latAcceleration[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dprdMAXRANGECOUNT != sizeof(p_theSrcData->DeData.driverPredictor_containerRange_longAcceleration) / sizeof(p_theSrcData->DeData.driverPredictor_containerRange_longAcceleration[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		p_theDestData->driverPredictor.containerRange.longAcceleration[uiArrIdx] = p_theSrcData->DeData.driverPredictor_containerRange_longAcceleration[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dprdMAXRANGECOUNT != sizeof(p_theSrcData->DeData.driverPredictor_containerRange_wheelPower) / sizeof(p_theSrcData->DeData.driverPredictor_containerRange_wheelPower[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		p_theDestData->driverPredictor.containerRange.wheelPower[uiArrIdx] = p_theSrcData->DeData.driverPredictor_containerRange_wheelPower[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)dprdMAXRANGECOUNT != sizeof(p_theSrcData->DeData.driverPredictor_containerRange_velocity) / sizeof(p_theSrcData->DeData.driverPredictor_containerRange_velocity[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		p_theDestData->driverPredictor.containerRange.velocity[uiArrIdx] = p_theSrcData->DeData.driverPredictor_containerRange_velocity[uiArrIdx]; 
	}
	p_theDestData->driverPredictor.branch.length                                  = p_theSrcData->DeData.driverPredictor_branch_length;
	p_theDestData->driverPredictor.branch.factorIn                                = p_theSrcData->DeData.driverPredictor_branch_factorIn;
	p_theDestData->driverPredictor.branch.factorOut                               = p_theSrcData->DeData.driverPredictor_branch_factorOut;
	p_theDestData->inputCodec.powertrain.sumTorque.value                          = p_theSrcData->DeData.inputCodec_powertrain_sumTorque_value;
	p_theDestData->inputCodec.powertrain.maxTorqueElectric.value                  = p_theSrcData->DeData.inputCodec_powertrain_maxTorqueElectric_value;
	p_theDestData->inputCodec.powertrain.eTorquePrimary.value                     = p_theSrcData->DeData.inputCodec_powertrain_eTorquePrimary_value;
	p_theDestData->inputCodec.powertrain.eTorqueSecondary.value                   = p_theSrcData->DeData.inputCodec_powertrain_eTorqueSecondary_value;
	p_theDestData->inputCodec.driver.maxAutoSpeed.value                           = p_theSrcData->DeData.inputCodec_driver_maxAutoSpeed_value;
	p_theDestData->inputCodec.driver.accelerator.value                            = p_theSrcData->DeData.inputCodec_driver_accelerator_value;
	p_theDestData->inputCodec.sign.predicted.distance.value                       = p_theSrcData->DeData.inputCodec_sign_predicted_distance_value;
	p_theDestData->inputCodec.sign.conditions.trailerLimit.value                  = p_theSrcData->DeData.inputCodec_sign_conditions_trailerLimit_value;
	p_theDestData->inputCodec.road.slope.value                                    = p_theSrcData->DeData.inputCodec_road_slope_value;
	p_theDestData->inputCodec.camera.lineLeft.curvature.value                     = p_theSrcData->DeData.inputCodec_camera_lineLeft_curvature_value;
	p_theDestData->inputCodec.camera.lineLeft.curveRate.value                     = p_theSrcData->DeData.inputCodec_camera_lineLeft_curveRate_value;
	p_theDestData->inputCodec.camera.lineLeft.length.value                        = p_theSrcData->DeData.inputCodec_camera_lineLeft_length_value;
	p_theDestData->inputCodec.camera.lineLeft.distance.value                      = p_theSrcData->DeData.inputCodec_camera_lineLeft_distance_value;
	p_theDestData->inputCodec.camera.lineRight.curvature.value                    = p_theSrcData->DeData.inputCodec_camera_lineRight_curvature_value;
	p_theDestData->inputCodec.camera.lineRight.curveRate.value                    = p_theSrcData->DeData.inputCodec_camera_lineRight_curveRate_value;
	p_theDestData->inputCodec.camera.lineRight.length.value                       = p_theSrcData->DeData.inputCodec_camera_lineRight_length_value;
	p_theDestData->inputCodec.camera.lineRight.distance.value                     = p_theSrcData->DeData.inputCodec_camera_lineRight_distance_value;
	p_theDestData->inputCodec.dynamics.velocity.value                             = p_theSrcData->DeData.inputCodec_dynamics_velocity_value;
	p_theDestData->inputCodec.dynamics.longAcceleration.value                     = p_theSrcData->DeData.inputCodec_dynamics_longAcceleration_value;
	p_theDestData->inputCodec.dynamics.latAcceleration.value                      = p_theSrcData->DeData.inputCodec_dynamics_latAcceleration_value;
	p_theDestData->inputCodec.dynamics.displayVelocity.value                      = p_theSrcData->DeData.inputCodec_dynamics_displayVelocity_value;
	p_theDestData->inputCodec.dynamics.yawRate.value                              = p_theSrcData->DeData.inputCodec_dynamics_yawRate_value;
	p_theDestData->inputCodec.dynamics.heading.value                              = p_theSrcData->DeData.inputCodec_dynamics_heading_value;
	p_theDestData->inputCodec.dynamics.wheelAngle.value                           = p_theSrcData->DeData.inputCodec_dynamics_wheelAngle_value;
	p_theDestData->inputCodec.dynamics.wheelRate.value                            = p_theSrcData->DeData.inputCodec_dynamics_wheelRate_value;
	p_theDestData->inputCodec.dynamics.rearAngle.value                            = p_theSrcData->DeData.inputCodec_dynamics_rearAngle_value;
	p_theDestData->inputCodec.dynamics.brakeTorque.frontLeft.value                = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_frontLeft_value;
	p_theDestData->inputCodec.dynamics.brakeTorque.frontRight.value               = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_frontRight_value;
	p_theDestData->inputCodec.dynamics.brakeTorque.rearLeft.value                 = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_rearLeft_value;
	p_theDestData->inputCodec.dynamics.brakeTorque.rearRight.value                = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_rearRight_value;
	p_theDestData->inputCodec.acc.accAcceleration.value                           = p_theSrcData->DeData.inputCodec_acc_accAcceleration_value;
	p_theDestData->inputCodec.acc.target.distance.value                           = p_theSrcData->DeData.inputCodec_acc_target_distance_value;
	p_theDestData->inputCodec.acc.target.velocity.value                           = p_theSrcData->DeData.inputCodec_acc_target_velocity_value;
	p_theDestData->inputCodec.acc.target.acceleration.value                       = p_theSrcData->DeData.inputCodec_acc_target_acceleration_value;
	p_theDestData->longController.velocity.predTime                               = p_theSrcData->DeData.longController_velocity_predTime;
	p_theDestData->longController.velocity.fail                                   = p_theSrcData->DeData.longController_velocity_fail;
	p_theDestData->longController.velocity.max                                    = p_theSrcData->DeData.longController_velocity_max;
	p_theDestData->longController.velocity.min                                    = p_theSrcData->DeData.longController_velocity_min;
	p_theDestData->longController.acceleration.predTime                           = p_theSrcData->DeData.longController_acceleration_predTime;
	p_theDestData->longController.acceleration.max                                = p_theSrcData->DeData.longController_acceleration_max;
	p_theDestData->longController.acceleration.min                                = p_theSrcData->DeData.longController_acceleration_min;
	p_theDestData->longController.acceleration.fail                               = p_theSrcData->DeData.longController_acceleration_fail;
	p_theDestData->longController.acceleration.advanceJerk                        = p_theSrcData->DeData.longController_acceleration_advanceJerk;
	p_theDestData->longController.jerk.positive                                   = p_theSrcData->DeData.longController_jerk_positive;
	p_theDestData->longController.jerk.negative                                   = p_theSrcData->DeData.longController_jerk_negative;
	p_theDestData->longController.jerk.negCoast                                   = p_theSrcData->DeData.longController_jerk_negCoast;
	p_theDestData->longController.tolerance.upper.on.max                          = p_theSrcData->DeData.longController_tolerance_upper_on_max;
	p_theDestData->longController.tolerance.upper.on.min                          = p_theSrcData->DeData.longController_tolerance_upper_on_min;
	p_theDestData->longController.tolerance.upper.off.max                         = p_theSrcData->DeData.longController_tolerance_upper_off_max;
	p_theDestData->longController.tolerance.upper.off.min                         = p_theSrcData->DeData.longController_tolerance_upper_off_min;
	p_theDestData->longController.tolerance.lower.on.max                          = p_theSrcData->DeData.longController_tolerance_lower_on_max;
	p_theDestData->longController.tolerance.lower.on.min                          = p_theSrcData->DeData.longController_tolerance_lower_on_min;
	p_theDestData->longController.tolerance.lower.off.max                         = p_theSrcData->DeData.longController_tolerance_lower_off_max;
	p_theDestData->longController.tolerance.lower.off.min                         = p_theSrcData->DeData.longController_tolerance_lower_off_min;
	p_theDestData->longController.brakeOnly.acceleration.max                      = p_theSrcData->DeData.longController_brakeOnly_acceleration_max;
	p_theDestData->longController.brakeOnly.acceleration.min                      = p_theSrcData->DeData.longController_brakeOnly_acceleration_min;
	p_theDestData->longController.brakeOnly.tolerance.upper                       = p_theSrcData->DeData.longController_brakeOnly_tolerance_upper;
	p_theDestData->longController.brakeOnly.tolerance.lower                       = p_theSrcData->DeData.longController_brakeOnly_tolerance_lower;
	p_theDestData->longController.coastFading.leaveTime                           = p_theSrcData->DeData.longController_coastFading_leaveTime;
	p_theDestData->longController.accDeviation.drvMdElectricAuto                  = p_theSrcData->DeData.longController_accDeviation_drvMdElectricAuto;
	p_theDestData->longController.accDeviation.drvMdEpower                        = p_theSrcData->DeData.longController_accDeviation_drvMdEpower;
	p_theDestData->longController.coastOffset                                     = p_theSrcData->DeData.longController_coastOffset;
	p_theDestData->longController.transRatioAdvance                               = p_theSrcData->DeData.longController_transRatioAdvance;
	p_theDestData->longStabTrigger.prioVelocity                                   = p_theSrcData->DeData.longStabTrigger_prioVelocity;
	p_theDestData->longStabTrigger.maxPlanTolerance                               = p_theSrcData->DeData.longStabTrigger_maxPlanTolerance;
	p_theDestData->longStabTrigger.minPlanTolerance                               = p_theSrcData->DeData.longStabTrigger_minPlanTolerance;
	p_theDestData->outputCodec.dsplStateDebounceTime                              = p_theSrcData->DeData.outputCodec_dsplStateDebounceTime;
	p_theDestData->outputCodec.override.DePACC02_Durchschnittsgeschw.value        = p_theSrcData->DeData.outputCodec_override_DePACC02_Durchschnittsgeschw_value;
	p_theDestData->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.value        = p_theSrcData->DeData.outputCodec_override_DePACC02_neg_Sollbeschl_Grad_value;
	p_theDestData->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.value        = p_theSrcData->DeData.outputCodec_override_DePACC02_pos_Sollbeschl_Grad_value;
	p_theDestData->outputCodec.override.DePACC02_Sollbeschleunigung.value         = p_theSrcData->DeData.outputCodec_override_DePACC02_Sollbeschleunigung_value;
	p_theDestData->outputCodec.override.DePACC02_Sollgeschwindigkeit.value        = p_theSrcData->DeData.outputCodec_override_DePACC02_Sollgeschwindigkeit_value;
	p_theDestData->outputCodec.override.DePACC02_Vorausschaugeschw.value          = p_theSrcData->DeData.outputCodec_override_DePACC02_Vorausschaugeschw_value;
	p_theDestData->outputCodec.override.DePACC02_Wunschuebersetzung.value         = p_theSrcData->DeData.outputCodec_override_DePACC02_Wunschuebersetzung_value;
	p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_oben.value          = p_theSrcData->DeData.outputCodec_override_DePACC02_zul_Regelabw_oben_value;
	p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_unten.value         = p_theSrcData->DeData.outputCodec_override_DePACC02_zul_Regelabw_unten_value;
	p_theDestData->pathRouter.headingCorrectionGradient                           = p_theSrcData->DeData.pathRouter_headingCorrectionGradient;
	p_theDestData->pathRouter.yieldSignTolerance                                  = p_theSrcData->DeData.pathRouter_yieldSignTolerance;
	p_theDestData->pathRouter.routeFilter.maxBranchAngle                          = p_theSrcData->DeData.pathRouter_routeFilter_maxBranchAngle;
	p_theDestData->pathRouter.positionFilter.correctionFactor                     = p_theSrcData->DeData.pathRouter_positionFilter_correctionFactor;
	p_theDestData->pathRouter.positionFilter.positionTolerance                    = p_theSrcData->DeData.pathRouter_positionFilter_positionTolerance;
	p_theDestData->pathRouter.positionFilter.headingTolerance                     = p_theSrcData->DeData.pathRouter_positionFilter_headingTolerance;
	p_theDestData->pathRouter.positionFilter.minKnownDistanceAhead                = p_theSrcData->DeData.pathRouter_positionFilter_minKnownDistanceAhead;
	p_theDestData->pathRouter.positionFilter.inhibitTimeFactor                    = p_theSrcData->DeData.pathRouter_positionFilter_inhibitTimeFactor;
	p_theDestData->pathRouter.positionFilter.inhibitTimeOffset                    = p_theSrcData->DeData.pathRouter_positionFilter_inhibitTimeOffset;
	p_theDestData->pathRouter.holdFilter.holdDistance                             = p_theSrcData->DeData.pathRouter_holdFilter_holdDistance;
	p_theDestData->pathRouter.holdFilter.holdTicks                                = p_theSrcData->DeData.pathRouter_holdFilter_holdTicks;
	p_theDestData->pathRouter.holdFilter.holdHeadDeviaton                         = p_theSrcData->DeData.pathRouter_holdFilter_holdHeadDeviaton;
	p_theDestData->pathRouter.turnFilter.normalDistance                           = p_theSrcData->DeData.pathRouter_turnFilter_normalDistance;
	p_theDestData->pathRouter.turnFilter.normalHeadDeviaton                       = p_theSrcData->DeData.pathRouter_turnFilter_normalHeadDeviaton;
	p_theDestData->pathRouter.turnFilter.extendedDistance                         = p_theSrcData->DeData.pathRouter_turnFilter_extendedDistance;
	p_theDestData->pathRouter.turnFilter.extendedHeadDeviaton                     = p_theSrcData->DeData.pathRouter_turnFilter_extendedHeadDeviaton;
	p_theDestData->systemController.longPressTime.initial                         = p_theSrcData->DeData.systemController_longPressTime_initial;
	p_theDestData->systemController.longPressTime.periodic                        = p_theSrcData->DeData.systemController_longPressTime_periodic;
	p_theDestData->systemController.status.doubleClickTimeout                     = p_theSrcData->DeData.systemController_status_doubleClickTimeout;
	p_theDestData->systemController.status.maxWaitTimeAccAcvn                     = p_theSrcData->DeData.systemController_status_maxWaitTimeAccAcvn;
	p_theDestData->systemController.status.mapValidDebounceTime                   = p_theSrcData->DeData.systemController_status_mapValidDebounceTime;
	p_theDestData->systemController.status.roadDataDebounceTime                   = p_theSrcData->DeData.systemController_status_roadDataDebounceTime;
	p_theDestData->systemController.status.strategyDebounceTime                   = p_theSrcData->DeData.systemController_status_strategyDebounceTime;
	p_theDestData->systemController.status.speedLimitDebounceTime                 = p_theSrcData->DeData.systemController_status_speedLimitDebounceTime;
	p_theDestData->systemController.status.overrideDebounceTime                   = p_theSrcData->DeData.systemController_status_overrideDebounceTime;
	p_theDestData->systemController.velocityControl.thresholdStandStill           = p_theSrcData->DeData.systemController_velocityControl_thresholdStandStill;
	p_theDestData->systemController.velocityControl.hintSetDelta                  = p_theSrcData->DeData.systemController_velocityControl_hintSetDelta;
	p_theDestData->systemController.velocityControl.hintResetDelta                = p_theSrcData->DeData.systemController_velocityControl_hintResetDelta;
	p_theDestData->systemController.velocityControl.bufferTimeLastSetSpeed        = p_theSrcData->DeData.systemController_velocityControl_bufferTimeLastSetSpeed;
	p_theDestData->systemController.limitPreview.timeMax                          = p_theSrcData->DeData.systemController_limitPreview_timeMax;
	p_theDestData->systemController.limitPreview.timeMin                          = p_theSrcData->DeData.systemController_limitPreview_timeMin;
	p_theDestData->systemController.limitPreview.distanceMin                      = p_theSrcData->DeData.systemController_limitPreview_distanceMin;
	p_theDestData->systemController.limitPreview.revertThreshold                  = p_theSrcData->DeData.systemController_limitPreview_revertThreshold;
	p_theDestData->systemController.limitPreview.positionOffset                   = p_theSrcData->DeData.systemController_limitPreview_positionOffset;
	p_theDestData->systemController.previewLock.timeTrigger                       = p_theSrcData->DeData.systemController_previewLock_timeTrigger;
	p_theDestData->systemController.previewLock.revertThreshold                   = p_theSrcData->DeData.systemController_previewLock_revertThreshold;
	p_theDestData->systemController.speedCheck.velocityHyst                       = p_theSrcData->DeData.systemController_speedCheck_velocityHyst;
	p_theDestData->systemController.stop.timeMax                                  = p_theSrcData->DeData.systemController_stop_timeMax;
	p_theDestData->systemController.stop.timeMin                                  = p_theSrcData->DeData.systemController_stop_timeMin;
	p_theDestData->systemController.stop.distanceMin                              = p_theSrcData->DeData.systemController_stop_distanceMin;
	p_theDestData->systemController.stop.revertThreshold                          = p_theSrcData->DeData.systemController_stop_revertThreshold;
	p_theDestData->systemController.stop.initSweepLength                          = p_theSrcData->DeData.systemController_stop_initSweepLength;
	p_theDestData->systemController.stop.proximityEnter                           = p_theSrcData->DeData.systemController_stop_proximityEnter;
	p_theDestData->systemController.stop.proximityHold                            = p_theSrcData->DeData.systemController_stop_proximityHold;
	p_theDestData->systemController.stop.proximityLeave                           = p_theSrcData->DeData.systemController_stop_proximityLeave;
	p_theDestData->systemController.overrideReturn.velocityTolerance              = p_theSrcData->DeData.systemController_overrideReturn_velocityTolerance;
	p_theDestData->vehicleObserver.velocity.refDecayFactor                        = p_theSrcData->DeData.vehicleObserver_velocity_refDecayFactor;
	p_theDestData->vehicleObserver.velocity.tolerance.maxAbsolute                 = p_theSrcData->DeData.vehicleObserver_velocity_tolerance_maxAbsolute;
	p_theDestData->vehicleObserver.velocity.tolerance.minAbsolute                 = p_theSrcData->DeData.vehicleObserver_velocity_tolerance_minAbsolute;
	p_theDestData->vehicleObserver.velocity.tolerance.maxRelative                 = p_theSrcData->DeData.vehicleObserver_velocity_tolerance_maxRelative;
	p_theDestData->vehicleObserver.velocity.tolerance.minRelative                 = p_theSrcData->DeData.vehicleObserver_velocity_tolerance_minRelative;
	p_theDestData->vehicleObserver.velocity.inner.minTolerance                    = p_theSrcData->DeData.vehicleObserver_velocity_inner_minTolerance;
	p_theDestData->vehicleObserver.velocity.inner.maxTolerance                    = p_theSrcData->DeData.vehicleObserver_velocity_inner_maxTolerance;
	p_theDestData->vehicleObserver.velocity.inner.factor                          = p_theSrcData->DeData.vehicleObserver_velocity_inner_factor;
	p_theDestData->vehicleObserver.velocity.outer.minTolerance                    = p_theSrcData->DeData.vehicleObserver_velocity_outer_minTolerance;
	p_theDestData->vehicleObserver.velocity.outer.maxTolerance                    = p_theSrcData->DeData.vehicleObserver_velocity_outer_maxTolerance;
	p_theDestData->vehicleObserver.velocity.outer.factor                          = p_theSrcData->DeData.vehicleObserver_velocity_outer_factor;
	p_theDestData->vehicleObserver.deviation.updateFactor                         = p_theSrcData->DeData.vehicleObserver_deviation_updateFactor;
	p_theDestData->vehicleObserver.deviation.bleedFactor                          = p_theSrcData->DeData.vehicleObserver_deviation_bleedFactor;
	p_theDestData->vehicleObserver.deviation.maxRate                              = p_theSrcData->DeData.vehicleObserver_deviation_maxRate;
	p_theDestData->vehicleObserver.deviation.minRate                              = p_theSrcData->DeData.vehicleObserver_deviation_minRate;
	p_theDestData->vehicleObserver.deviation.minVelocity                          = p_theSrcData->DeData.vehicleObserver_deviation_minVelocity;
	p_theDestData->vehicleObserver.deviation.inner.minTolerance                   = p_theSrcData->DeData.vehicleObserver_deviation_inner_minTolerance;
	p_theDestData->vehicleObserver.deviation.inner.maxTolerance                   = p_theSrcData->DeData.vehicleObserver_deviation_inner_maxTolerance;
	p_theDestData->vehicleObserver.deviation.inner.factor                         = p_theSrcData->DeData.vehicleObserver_deviation_inner_factor;
	p_theDestData->vehicleObserver.deviation.outer.minTolerance                   = p_theSrcData->DeData.vehicleObserver_deviation_outer_minTolerance;
	p_theDestData->vehicleObserver.deviation.outer.maxTolerance                   = p_theSrcData->DeData.vehicleObserver_deviation_outer_maxTolerance;
	p_theDestData->vehicleObserver.deviation.outer.factor                         = p_theSrcData->DeData.vehicleObserver_deviation_outer_factor;
	p_theDestData->vehicleObserver.deviation.stateLimit.minEngaged                = p_theSrcData->DeData.vehicleObserver_deviation_stateLimit_minEngaged;
	p_theDestData->vehicleObserver.deviation.stateLimit.maxEngaged                = p_theSrcData->DeData.vehicleObserver_deviation_stateLimit_maxEngaged;
	p_theDestData->vehicleObserver.deviation.stateLimit.minDisengaged             = p_theSrcData->DeData.vehicleObserver_deviation_stateLimit_minDisengaged;
	p_theDestData->vehicleObserver.deviation.stateLimit.maxDisengaged             = p_theSrcData->DeData.vehicleObserver_deviation_stateLimit_maxDisengaged;
	p_theDestData->vehicleObserver.deviation.filterLimit.minEngaged               = p_theSrcData->DeData.vehicleObserver_deviation_filterLimit_minEngaged;
	p_theDestData->vehicleObserver.deviation.filterLimit.maxEngaged               = p_theSrcData->DeData.vehicleObserver_deviation_filterLimit_maxEngaged;
	p_theDestData->vehicleObserver.deviation.filterLimit.minDisengaged            = p_theSrcData->DeData.vehicleObserver_deviation_filterLimit_minDisengaged;
	p_theDestData->vehicleObserver.deviation.filterLimit.maxDisengaged            = p_theSrcData->DeData.vehicleObserver_deviation_filterLimit_maxDisengaged;
	p_theDestData->vehicleObserver.deviation.gearLock.torqueTolerance             = p_theSrcData->DeData.vehicleObserver_deviation_gearLock_torqueTolerance;
	p_theDestData->vehicleObserver.deviation.gearLock.bleedRate                   = p_theSrcData->DeData.vehicleObserver_deviation_gearLock_bleedRate;
	p_theDestData->vehicleObserver.deviation.gearLock.thresholdLock               = p_theSrcData->DeData.vehicleObserver_deviation_gearLock_thresholdLock;
	p_theDestData->vehicleObserver.deviation.gearLock.thresholdUnlock             = p_theSrcData->DeData.vehicleObserver_deviation_gearLock_thresholdUnlock;
	p_theDestData->vehicleObserver.deviation.gearLock.entryJerk                   = p_theSrcData->DeData.vehicleObserver_deviation_gearLock_entryJerk;
	p_theDestData->vehicleObserver.heading.updateFactor                           = p_theSrcData->DeData.vehicleObserver_heading_updateFactor;
	p_theDestData->vehicleObserver.heading.maxDeviation                           = p_theSrcData->DeData.vehicleObserver_heading_maxDeviation;
	p_theDestData->vehicleObserver.heading.minDeviation                           = p_theSrcData->DeData.vehicleObserver_heading_minDeviation;
	p_theDestData->vehicleObserver.heading.maxHeadingInvalidTime                  = p_theSrcData->DeData.vehicleObserver_heading_maxHeadingInvalidTime;
	p_theDestData->vehicleObserver.steering.angleRateCutOff                       = p_theSrcData->DeData.vehicleObserver_steering_angleRateCutOff;
	p_theDestData->vehicleObserver.steering.slowAngleCutOff                       = p_theSrcData->DeData.vehicleObserver_steering_slowAngleCutOff;
	p_theDestData->vehicleObserver.steering.predTime                              = p_theSrcData->DeData.vehicleObserver_steering_predTime;
	p_theDestData->vehicleObserver.curvature.curvatureCutOff                      = p_theSrcData->DeData.vehicleObserver_curvature_curvatureCutOff;
	p_theDestData->vehicleObserver.curvature.curveRateCutOff                      = p_theSrcData->DeData.vehicleObserver_curvature_curveRateCutOff;
	p_theDestData->vehicleObserver.curvature.distanceCutOff                       = p_theSrcData->DeData.vehicleObserver_curvature_distanceCutOff;
	p_theDestData->vehicleObserver.curvature.confidenceCutOff                     = p_theSrcData->DeData.vehicleObserver_curvature_confidenceCutOff;
	p_theDestData->vehicleObserver.slope.tskTolerance                             = p_theSrcData->DeData.vehicleObserver_slope_tskTolerance;
	p_theDestData->vehicleObserver.turnSignal.previewTime                         = p_theSrcData->DeData.vehicleObserver_turnSignal_previewTime;
	p_theDestData->vehicleObserver.traffic.offset.velocity                        = p_theSrcData->DeData.vehicleObserver_traffic_offset_velocity;
	p_theDestData->vehicleObserver.traffic.offset.acceleration                    = p_theSrcData->DeData.vehicleObserver_traffic_offset_acceleration;
	p_theDestData->vehicleObserver.traffic.accelerationCutOff                     = p_theSrcData->DeData.vehicleObserver_traffic_accelerationCutOff;

	BUILD_BUG_ON((uint32_T)prmNUMWETNESSFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_level) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_level[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMWETNESSFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.level[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_level[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMWETNESSFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMWETNESSFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_factor[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMADAPTIONRATE != sizeof(p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_angle) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_angle[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMADAPTIONRATE; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.width.adaptionFactor.angle[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_angle[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMADAPTIONRATE != sizeof(p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_rate) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_rate[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMADAPTIONRATE; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.width.adaptionFactor.rate[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_rate[uiArrIdx]; 
	}
	p_theDestData->vehicleObserver.courage.width.faultDistance                    = p_theSrcData->DeData.vehicleObserver_courage_width_faultDistance;
	p_theDestData->vehicleObserver.courage.width.avgCutOffFreq                    = p_theSrcData->DeData.vehicleObserver_courage_width_avgCutOffFreq;
	p_theDestData->vehicleObserver.courage.width.pullVelocity                     = p_theSrcData->DeData.vehicleObserver_courage_width_pullVelocity;
	p_theDestData->vehicleObserver.courage.width.driftVelocity                    = p_theSrcData->DeData.vehicleObserver_courage_width_driftVelocity;
	p_theDestData->vehicleObserver.courage.width.averageDiv                       = p_theSrcData->DeData.vehicleObserver_courage_width_averageDiv;
	p_theDestData->vehicleObserver.courage.width.averageMin                       = p_theSrcData->DeData.vehicleObserver_courage_width_averageMin;
	p_theDestData->vehicleObserver.courage.width.differenceDiv                    = p_theSrcData->DeData.vehicleObserver_courage_width_differenceDiv;
	p_theDestData->vehicleObserver.courage.width.differenceMin                    = p_theSrcData->DeData.vehicleObserver_courage_width_differenceMin;
	p_theDestData->vehicleObserver.courage.width.confidenceRate                   = p_theSrcData->DeData.vehicleObserver_courage_width_confidenceRate;

	BUILD_BUG_ON((uint32_T)prmNUMTAILFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_tail) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_tail[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMTAILFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.curtain.tailFactor.tail[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_tail[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMTAILFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMTAILFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.curtain.tailFactor.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_factor[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMCURVATUREFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_curvature) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_curvature[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMCURVATUREFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.curvature[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_curvature[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMCURVATUREFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMCURVATUREFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_factor[uiArrIdx]; 
	}
	p_theDestData->vehicleObserver.courage.limit.maxHorizon                       = p_theSrcData->DeData.vehicleObserver_courage_limit_maxHorizon;
	p_theDestData->vehicleObserver.courage.limit.minHorizon                       = p_theSrcData->DeData.vehicleObserver_courage_limit_minHorizon;
	p_theDestData->vehicleObserver.courage.limit.maxVelocity                      = p_theSrcData->DeData.vehicleObserver_courage_limit_maxVelocity;

	BUILD_BUG_ON((uint32_T)prmNUMLIMITDEVFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_deviation) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_deviation[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.limit.upperDeviation.deviation[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_deviation[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMLIMITDEVFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.limit.upperDeviation.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_factor[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMLIMITDEVFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_deviation) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_deviation[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.limit.lowerDeviation.deviation[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_deviation[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMLIMITDEVFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.limit.lowerDeviation.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_factor[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMFOLLOWGAPFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_timeGap) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_timeGap[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMFOLLOWGAPFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.follow.gapFactor.timeGap[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_timeGap[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMFOLLOWGAPFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMFOLLOWGAPFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.follow.gapFactor.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_factor[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMRESETAGEFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_ticks) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_ticks[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMRESETAGEFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.reset.ageFactor.ticks[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_ticks[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMRESETAGEFACTOR != sizeof(p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_factor) / sizeof(p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_factor[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMRESETAGEFACTOR; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.courage.reset.ageFactor.factor[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_factor[uiArrIdx]; 
	}
	p_theDestData->vehicleObserver.courage.curvatureMax                           = p_theSrcData->DeData.vehicleObserver_courage_curvatureMax;
	p_theDestData->vehicleObserver.courage.curvatureMin                           = p_theSrcData->DeData.vehicleObserver_courage_curvatureMin;
	p_theDestData->vehicleObserver.courage.curvatureRateMax                       = p_theSrcData->DeData.vehicleObserver_courage_curvatureRateMax;
	p_theDestData->vehicleObserver.courage.curvatureRateMin                       = p_theSrcData->DeData.vehicleObserver_courage_curvatureRateMin;
	p_theDestData->vehicleObserver.courage.curtainMaxRate                         = p_theSrcData->DeData.vehicleObserver_courage_curtainMaxRate;
	p_theDestData->vehicleObserver.courage.curtainMinRate                         = p_theSrcData->DeData.vehicleObserver_courage_curtainMinRate;
	p_theDestData->vehicleObserver.courage.maxJerkMaxRate                         = p_theSrcData->DeData.vehicleObserver_courage_maxJerkMaxRate;
	p_theDestData->vehicleObserver.courage.limitJerkMaxRate                       = p_theSrcData->DeData.vehicleObserver_courage_limitJerkMaxRate;
	p_theDestData->vehicleObserver.courage.curveJerkMaxRate                       = p_theSrcData->DeData.vehicleObserver_courage_curveJerkMaxRate;
	p_theDestData->vehicleObserver.check.codeCheckTimeout                         = p_theSrcData->DeData.vehicleObserver_check_codeCheckTimeout;
	p_theDestData->vehicleObserver.check.velocityCheckTimeout                     = p_theSrcData->DeData.vehicleObserver_check_velocityCheckTimeout;
	p_theDestData->vehicleObserver.check.controlCheckTimeout                      = p_theSrcData->DeData.vehicleObserver_check_controlCheckTimeout;
	p_theDestData->vehicleObserver.accBoost.holdTime                              = p_theSrcData->DeData.vehicleObserver_accBoost_holdTime;
	p_theDestData->vehicleObserver.lockCoast.waitTime                             = p_theSrcData->DeData.vehicleObserver_lockCoast_waitTime;
	p_theDestData->vehicleObserver.lockCoast.lockTime                             = p_theSrcData->DeData.vehicleObserver_lockCoast_lockTime;

	BUILD_BUG_ON((uint32_T)prmNUMMAXBRAKETORQUE != sizeof(p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_velocity) / sizeof(p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_velocity[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMMAXBRAKETORQUE; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.velocity[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_velocity[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)prmNUMMAXBRAKETORQUE != sizeof(p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_torque) / sizeof(p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_torque[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMMAXBRAKETORQUE; uiArrIdx++)
	{
		p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.torque[uiArrIdx] = p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_torque[uiArrIdx]; 
	}
	p_theDestData->displayController.torqueHoldTicks                              = p_theSrcData->DeData.displayController_torqueHoldTicks;
	p_theDestData->displayController.offsetHoldTicks                              = p_theSrcData->DeData.displayController_offsetHoldTicks;
	p_theDestData->driverPredictor.prepCount.speedLimit                           = p_theSrcData->DeData.driverPredictor_prepCount_speedLimit;
	p_theDestData->driverPredictor.prepCount.onlineLimit                          = p_theSrcData->DeData.driverPredictor_prepCount_onlineLimit;
	p_theDestData->driverPredictor.prepCount.curvature                            = p_theSrcData->DeData.driverPredictor_prepCount_curvature;
	p_theDestData->driverPredictor.prepCount.environment                          = p_theSrcData->DeData.driverPredictor_prepCount_environment;
	p_theDestData->driverPredictor.evalCount.speedLimit                           = p_theSrcData->DeData.driverPredictor_evalCount_speedLimit;
	p_theDestData->driverPredictor.evalCount.onlineLimit                          = p_theSrcData->DeData.driverPredictor_evalCount_onlineLimit;
	p_theDestData->driverPredictor.evalCount.curvature                            = p_theSrcData->DeData.driverPredictor_evalCount_curvature;
	p_theDestData->inputCodec.driver.vMaxRaw.value                                = p_theSrcData->DeData.inputCodec_driver_vMaxRaw_value;
	p_theDestData->inputCodec.sign.limit.value                                    = p_theSrcData->DeData.inputCodec_sign_limit_value;
	p_theDestData->inputCodec.sign.predicted.limit.value                          = p_theSrcData->DeData.inputCodec_sign_predicted_limit_value;
	p_theDestData->inputCodec.sign.conditions.trailerRaw.value                    = p_theSrcData->DeData.inputCodec_sign_conditions_trailerRaw_value;
	p_theDestData->longController.coastFading.enterTicks                          = p_theSrcData->DeData.longController_coastFading_enterTicks;
	p_theDestData->outputCodec.override.DePACC02_Offset.value                     = p_theSrcData->DeData.outputCodec_override_DePACC02_Offset_value;
	p_theDestData->pathRouter.turnFilter.normalTicks                              = p_theSrcData->DeData.pathRouter_turnFilter_normalTicks;
	p_theDestData->pathRouter.turnFilter.extendedTicks                            = p_theSrcData->DeData.pathRouter_turnFilter_extendedTicks;
	p_theDestData->systemController.errorTicks                                    = p_theSrcData->DeData.systemController_errorTicks;
	p_theDestData->systemController.speedCheck.toleranceTicks                     = p_theSrcData->DeData.systemController_speedCheck_toleranceTicks;
	p_theDestData->systemController.speedCheck.rampTicks                          = p_theSrcData->DeData.systemController_speedCheck_rampTicks;
	p_theDestData->vehicleObserver.turnSignal.confTickCount                       = p_theSrcData->DeData.vehicleObserver_turnSignal_confTickCount;
	p_theDestData->vehicleObserver.turnSignal.holdTickCount                       = p_theSrcData->DeData.vehicleObserver_turnSignal_holdTickCount;
	p_theDestData->vehicleObserver.traffic.offset.rampTicks                       = p_theSrcData->DeData.vehicleObserver_traffic_offset_rampTicks;
	p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.count           = p_theSrcData->DeData.vehicleObserver_courage_wetness_adaptionFactor_count;
	p_theDestData->vehicleObserver.courage.width.adaptionFactor.count             = p_theSrcData->DeData.vehicleObserver_courage_width_adaptionFactor_count;
	p_theDestData->vehicleObserver.courage.curtain.tailFactor.count               = p_theSrcData->DeData.vehicleObserver_courage_curtain_tailFactor_count;
	p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.count          = p_theSrcData->DeData.vehicleObserver_courage_curtain_curvatureFactor_count;
	p_theDestData->vehicleObserver.courage.limit.holdTicks                        = p_theSrcData->DeData.vehicleObserver_courage_limit_holdTicks;
	p_theDestData->vehicleObserver.courage.limit.upperDeviation.count             = p_theSrcData->DeData.vehicleObserver_courage_limit_upperDeviation_count;
	p_theDestData->vehicleObserver.courage.limit.lowerDeviation.count             = p_theSrcData->DeData.vehicleObserver_courage_limit_lowerDeviation_count;
	p_theDestData->vehicleObserver.courage.follow.gapFactor.count                 = p_theSrcData->DeData.vehicleObserver_courage_follow_gapFactor_count;
	p_theDestData->vehicleObserver.courage.reset.ageFactor.count                  = p_theSrcData->DeData.vehicleObserver_courage_reset_ageFactor_count;
	p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.count                 = p_theSrcData->DeData.vehicleObserver_lockCoast_maxBrakeTorque_count;
	p_theDestData->longController.jerk.rampUpTicks                                = p_theSrcData->DeData.reserved_uint16_00;
	p_theDestData->longController.transmissionRatio.waitTicks                     = p_theSrcData->DeData.reserved_uint16_01;
	p_theDestData->vehicleObserver.turnSignal.lockTickCount                       = p_theSrcData->DeData.reserved_uint16_02;
	p_theDestData->vehicleObserver.courage.friction.adaptionFactor.count          = p_theSrcData->DeData.reserved_uint16_03;
	p_theDestData->bufferSize                                                     = p_theSrcData->DeData.bufferSize;
	p_theDestData->driverObserver.dynamicValues.countryInit.level                 = p_theSrcData->DeData.driverObserver_dynamicValues_countryInit_level;
	p_theDestData->driverObserver.dynamicValues.countryRadarInit.level            = p_theSrcData->DeData.driverObserver_dynamicValues_countryRadarInit_level;
	p_theDestData->driverObserver.dynamicValues.cityInit.level                    = p_theSrcData->DeData.driverObserver_dynamicValues_cityInit_level;
	p_theDestData->driverObserver.escalation.levelCount                           = p_theSrcData->DeData.driverObserver_escalation_levelCount;
	p_theDestData->driverObserver.escalation.escalationOffset                     = p_theSrcData->DeData.driverObserver_escalation_escalationOffset;
	p_theDestData->driverPredictor.timestepCount                                  = p_theSrcData->DeData.driverPredictor_timestepCount;

	BUILD_BUG_ON((uint32_T)3 != sizeof(p_theSrcData->DeData.driverPredictor_windowStart) / sizeof(p_theSrcData->DeData.driverPredictor_windowStart[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)3; uiArrIdx++)
	{
		p_theDestData->driverPredictor.windowStart[uiArrIdx] = p_theSrcData->DeData.driverPredictor_windowStart[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)3 != sizeof(p_theSrcData->DeData.driverPredictor_windowEnd) / sizeof(p_theSrcData->DeData.driverPredictor_windowEnd[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)3; uiArrIdx++)
	{
		p_theDestData->driverPredictor.windowEnd[uiArrIdx] = p_theSrcData->DeData.driverPredictor_windowEnd[uiArrIdx]; 
	}
	p_theDestData->driverPredictor.minDynamicLevel                                = p_theSrcData->DeData.driverPredictor_minDynamicLevel;
	p_theDestData->inputCodec.powertrain.gear.override                            = p_theSrcData->DeData.inputCodec_powertrain_gear_override;
	p_theDestData->inputCodec.powertrain.gear.value                               = p_theSrcData->DeData.inputCodec_powertrain_gear_value;
	p_theDestData->inputCodec.powertrain.hybridVehicle.override                   = p_theSrcData->DeData.inputCodec_powertrain_hybridVehicle_override;
	p_theDestData->inputCodec.powertrain.hybridVehicle.value                      = p_theSrcData->DeData.inputCodec_powertrain_hybridVehicle_value;
	p_theDestData->inputCodec.powertrain.coastingPossible.override                = p_theSrcData->DeData.inputCodec_powertrain_coastingPossible_override;
	p_theDestData->inputCodec.powertrain.coastingPossible.value                   = p_theSrcData->DeData.inputCodec_powertrain_coastingPossible_value;
	p_theDestData->inputCodec.powertrain.sumTorque.override                       = p_theSrcData->DeData.inputCodec_powertrain_sumTorque_override;
	p_theDestData->inputCodec.powertrain.transmissionManual.override              = p_theSrcData->DeData.inputCodec_powertrain_transmissionManual_override;
	p_theDestData->inputCodec.powertrain.transmissionManual.value                 = p_theSrcData->DeData.inputCodec_powertrain_transmissionManual_value;
	p_theDestData->inputCodec.powertrain.maxTorqueElectric.override               = p_theSrcData->DeData.inputCodec_powertrain_maxTorqueElectric_override;
	p_theDestData->inputCodec.powertrain.combustionEngineActive.override          = p_theSrcData->DeData.inputCodec_powertrain_combustionEngineActive_override;
	p_theDestData->inputCodec.powertrain.combustionEngineActive.value             = p_theSrcData->DeData.inputCodec_powertrain_combustionEngineActive_value;
	p_theDestData->inputCodec.powertrain.ePowerSelected.override                  = p_theSrcData->DeData.inputCodec_powertrain_ePowerSelected_override;
	p_theDestData->inputCodec.powertrain.ePowerSelected.value                     = p_theSrcData->DeData.inputCodec_powertrain_ePowerSelected_value;
	p_theDestData->inputCodec.powertrain.eTorquePrimary.override                  = p_theSrcData->DeData.inputCodec_powertrain_eTorquePrimary_override;
	p_theDestData->inputCodec.powertrain.eTorqueSecondary.override                = p_theSrcData->DeData.inputCodec_powertrain_eTorqueSecondary_override;
	p_theDestData->inputCodec.powertrain.motorCode.override                       = p_theSrcData->DeData.inputCodec_powertrain_motorCode_override;
	p_theDestData->inputCodec.powertrain.motorCode.value                          = p_theSrcData->DeData.inputCodec_powertrain_motorCode_value;
	p_theDestData->inputCodec.driver.valid.override                               = p_theSrcData->DeData.inputCodec_driver_valid_override;
	p_theDestData->inputCodec.driver.valid.value                                  = p_theSrcData->DeData.inputCodec_driver_valid_value;
	p_theDestData->inputCodec.driver.enabled.override                             = p_theSrcData->DeData.inputCodec_driver_enabled_override;
	p_theDestData->inputCodec.driver.enabled.value                                = p_theSrcData->DeData.inputCodec_driver_enabled_value;
	p_theDestData->inputCodec.driver.selected.override                            = p_theSrcData->DeData.inputCodec_driver_selected_override;
	p_theDestData->inputCodec.driver.selected.value                               = p_theSrcData->DeData.inputCodec_driver_selected_value;
	p_theDestData->inputCodec.driver.tipUp.override                               = p_theSrcData->DeData.inputCodec_driver_tipUp_override;
	p_theDestData->inputCodec.driver.tipUp.value                                  = p_theSrcData->DeData.inputCodec_driver_tipUp_value;
	p_theDestData->inputCodec.driver.tipDown.override                             = p_theSrcData->DeData.inputCodec_driver_tipDown_override;
	p_theDestData->inputCodec.driver.tipDown.value                                = p_theSrcData->DeData.inputCodec_driver_tipDown_value;
	p_theDestData->inputCodec.driver.set.override                                 = p_theSrcData->DeData.inputCodec_driver_set_override;
	p_theDestData->inputCodec.driver.set.value                                    = p_theSrcData->DeData.inputCodec_driver_set_value;
	p_theDestData->inputCodec.driver.resume.override                              = p_theSrcData->DeData.inputCodec_driver_resume_override;
	p_theDestData->inputCodec.driver.resume.value                                 = p_theSrcData->DeData.inputCodec_driver_resume_value;
	p_theDestData->inputCodec.driver.followingGap.override                        = p_theSrcData->DeData.inputCodec_driver_followingGap_override;
	p_theDestData->inputCodec.driver.followingGap.value                           = p_theSrcData->DeData.inputCodec_driver_followingGap_value;
	p_theDestData->inputCodec.driver.charisma.override                            = p_theSrcData->DeData.inputCodec_driver_charisma_override;
	p_theDestData->inputCodec.driver.charisma.value                               = p_theSrcData->DeData.inputCodec_driver_charisma_value;
	p_theDestData->inputCodec.driver.autoMode.override                            = p_theSrcData->DeData.inputCodec_driver_autoMode_override;
	p_theDestData->inputCodec.driver.autoMode.value                               = p_theSrcData->DeData.inputCodec_driver_autoMode_value;
	p_theDestData->inputCodec.driver.maxAutoSpeed.override                        = p_theSrcData->DeData.inputCodec_driver_maxAutoSpeed_override;
	p_theDestData->inputCodec.driver.turnSignal.override                          = p_theSrcData->DeData.inputCodec_driver_turnSignal_override;
	p_theDestData->inputCodec.driver.turnSignal.value                             = p_theSrcData->DeData.inputCodec_driver_turnSignal_value;
	p_theDestData->inputCodec.driver.signalLocked.override                        = p_theSrcData->DeData.inputCodec_driver_signalLocked_override;
	p_theDestData->inputCodec.driver.signalLocked.value                           = p_theSrcData->DeData.inputCodec_driver_signalLocked_value;
	p_theDestData->inputCodec.driver.accelerator.override                         = p_theSrcData->DeData.inputCodec_driver_accelerator_override;
	p_theDestData->inputCodec.driver.displayUnit.override                         = p_theSrcData->DeData.inputCodec_driver_displayUnit_override;
	p_theDestData->inputCodec.driver.displayUnit.value                            = p_theSrcData->DeData.inputCodec_driver_displayUnit_value;
	p_theDestData->inputCodec.driver.vMaxRaw.override                             = p_theSrcData->DeData.inputCodec_driver_vMaxRaw_override;
	p_theDestData->inputCodec.driver.vMaxUnit.override                            = p_theSrcData->DeData.inputCodec_driver_vMaxUnit_override;
	p_theDestData->inputCodec.driver.vMaxUnit.value                               = p_theSrcData->DeData.inputCodec_driver_vMaxUnit_value;
	p_theDestData->inputCodec.driver.offset.override                              = p_theSrcData->DeData.inputCodec_driver_offset_override;
	p_theDestData->inputCodec.driver.offset.value                                 = p_theSrcData->DeData.inputCodec_driver_offset_value;
	p_theDestData->inputCodec.driver.ignoreCountry.override                       = p_theSrcData->DeData.inputCodec_driver_ignoreCountry_override;
	p_theDestData->inputCodec.driver.ignoreCountry.value                          = p_theSrcData->DeData.inputCodec_driver_ignoreCountry_value;
	p_theDestData->inputCodec.driver.fodActivation.override                       = p_theSrcData->DeData.inputCodec_driver_fodActivation_override;
	p_theDestData->inputCodec.driver.fodActivation.value                          = p_theSrcData->DeData.inputCodec_driver_fodActivation_value;
	p_theDestData->inputCodec.sign.limit.override                                 = p_theSrcData->DeData.inputCodec_sign_limit_override;
	p_theDestData->inputCodec.sign.valid.override                                 = p_theSrcData->DeData.inputCodec_sign_valid_override;
	p_theDestData->inputCodec.sign.valid.value                                    = p_theSrcData->DeData.inputCodec_sign_valid_value;
	p_theDestData->inputCodec.sign.text.override                                  = p_theSrcData->DeData.inputCodec_sign_text_override;
	p_theDestData->inputCodec.sign.text.value                                     = p_theSrcData->DeData.inputCodec_sign_text_value;
	p_theDestData->inputCodec.sign.predicted.limit.override                       = p_theSrcData->DeData.inputCodec_sign_predicted_limit_override;
	p_theDestData->inputCodec.sign.predicted.distance.override                    = p_theSrcData->DeData.inputCodec_sign_predicted_distance_override;
	p_theDestData->inputCodec.sign.predicted.additionalInfo.override              = p_theSrcData->DeData.inputCodec_sign_predicted_additionalInfo_override;
	p_theDestData->inputCodec.sign.predicted.additionalInfo.value                 = p_theSrcData->DeData.inputCodec_sign_predicted_additionalInfo_value;
	p_theDestData->inputCodec.sign.predicted.valid.override                       = p_theSrcData->DeData.inputCodec_sign_predicted_valid_override;
	p_theDestData->inputCodec.sign.predicted.valid.value                          = p_theSrcData->DeData.inputCodec_sign_predicted_valid_value;
	p_theDestData->inputCodec.sign.conditions.trailerLimit.override               = p_theSrcData->DeData.inputCodec_sign_conditions_trailerLimit_override;
	p_theDestData->inputCodec.sign.conditions.trailerRaw.override                 = p_theSrcData->DeData.inputCodec_sign_conditions_trailerRaw_override;
	p_theDestData->inputCodec.sign.conditions.fog.override                        = p_theSrcData->DeData.inputCodec_sign_conditions_fog_override;
	p_theDestData->inputCodec.sign.conditions.fog.value                           = p_theSrcData->DeData.inputCodec_sign_conditions_fog_value;
	p_theDestData->inputCodec.sign.conditions.wet.override                        = p_theSrcData->DeData.inputCodec_sign_conditions_wet_override;
	p_theDestData->inputCodec.sign.conditions.wet.value                           = p_theSrcData->DeData.inputCodec_sign_conditions_wet_value;
	p_theDestData->inputCodec.sign.conditions.trailer.override                    = p_theSrcData->DeData.inputCodec_sign_conditions_trailer_override;
	p_theDestData->inputCodec.sign.conditions.trailer.value                       = p_theSrcData->DeData.inputCodec_sign_conditions_trailer_value;
	p_theDestData->inputCodec.road.slope.override                                 = p_theSrcData->DeData.inputCodec_road_slope_override;
	p_theDestData->inputCodec.road.wetnessLevel.override                          = p_theSrcData->DeData.inputCodec_road_wetnessLevel_override;
	p_theDestData->inputCodec.road.wetnessLevel.value                             = p_theSrcData->DeData.inputCodec_road_wetnessLevel_value;
	p_theDestData->inputCodec.camera.lineLeft.valid.override                      = p_theSrcData->DeData.inputCodec_camera_lineLeft_valid_override;
	p_theDestData->inputCodec.camera.lineLeft.valid.value                         = p_theSrcData->DeData.inputCodec_camera_lineLeft_valid_value;
	p_theDestData->inputCodec.camera.lineLeft.curvature.override                  = p_theSrcData->DeData.inputCodec_camera_lineLeft_curvature_override;
	p_theDestData->inputCodec.camera.lineLeft.curveRate.override                  = p_theSrcData->DeData.inputCodec_camera_lineLeft_curveRate_override;
	p_theDestData->inputCodec.camera.lineLeft.length.override                     = p_theSrcData->DeData.inputCodec_camera_lineLeft_length_override;
	p_theDestData->inputCodec.camera.lineLeft.distance.override                   = p_theSrcData->DeData.inputCodec_camera_lineLeft_distance_override;
	p_theDestData->inputCodec.camera.lineRight.valid.override                     = p_theSrcData->DeData.inputCodec_camera_lineRight_valid_override;
	p_theDestData->inputCodec.camera.lineRight.valid.value                        = p_theSrcData->DeData.inputCodec_camera_lineRight_valid_value;
	p_theDestData->inputCodec.camera.lineRight.curvature.override                 = p_theSrcData->DeData.inputCodec_camera_lineRight_curvature_override;
	p_theDestData->inputCodec.camera.lineRight.curveRate.override                 = p_theSrcData->DeData.inputCodec_camera_lineRight_curveRate_override;
	p_theDestData->inputCodec.camera.lineRight.length.override                    = p_theSrcData->DeData.inputCodec_camera_lineRight_length_override;
	p_theDestData->inputCodec.camera.lineRight.distance.override                  = p_theSrcData->DeData.inputCodec_camera_lineRight_distance_override;
	p_theDestData->inputCodec.dynamics.velocity.override                          = p_theSrcData->DeData.inputCodec_dynamics_velocity_override;
	p_theDestData->inputCodec.dynamics.longAcceleration.override                  = p_theSrcData->DeData.inputCodec_dynamics_longAcceleration_override;
	p_theDestData->inputCodec.dynamics.latAcceleration.override                   = p_theSrcData->DeData.inputCodec_dynamics_latAcceleration_override;
	p_theDestData->inputCodec.dynamics.displayVelocity.override                   = p_theSrcData->DeData.inputCodec_dynamics_displayVelocity_override;
	p_theDestData->inputCodec.dynamics.yawRate.override                           = p_theSrcData->DeData.inputCodec_dynamics_yawRate_override;
	p_theDestData->inputCodec.dynamics.heading.override                           = p_theSrcData->DeData.inputCodec_dynamics_heading_override;
	p_theDestData->inputCodec.dynamics.wheelAngle.override                        = p_theSrcData->DeData.inputCodec_dynamics_wheelAngle_override;
	p_theDestData->inputCodec.dynamics.wheelRate.override                         = p_theSrcData->DeData.inputCodec_dynamics_wheelRate_override;
	p_theDestData->inputCodec.dynamics.rearAngle.override                         = p_theSrcData->DeData.inputCodec_dynamics_rearAngle_override;
	p_theDestData->inputCodec.dynamics.rasPresent.override                        = p_theSrcData->DeData.inputCodec_dynamics_rasPresent_override;
	p_theDestData->inputCodec.dynamics.rasPresent.value                           = p_theSrcData->DeData.inputCodec_dynamics_rasPresent_value;
	p_theDestData->inputCodec.dynamics.headValid.override                         = p_theSrcData->DeData.inputCodec_dynamics_headValid_override;
	p_theDestData->inputCodec.dynamics.headValid.value                            = p_theSrcData->DeData.inputCodec_dynamics_headValid_value;
	p_theDestData->inputCodec.dynamics.serviceBrakeEngaged.override               = p_theSrcData->DeData.inputCodec_dynamics_serviceBrakeEngaged_override;
	p_theDestData->inputCodec.dynamics.serviceBrakeEngaged.value                  = p_theSrcData->DeData.inputCodec_dynamics_serviceBrakeEngaged_value;
	p_theDestData->inputCodec.dynamics.brakeTorque.frontLeft.override             = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_frontLeft_override;
	p_theDestData->inputCodec.dynamics.brakeTorque.frontRight.override            = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_frontRight_override;
	p_theDestData->inputCodec.dynamics.brakeTorque.rearLeft.override              = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_rearLeft_override;
	p_theDestData->inputCodec.dynamics.brakeTorque.rearRight.override             = p_theSrcData->DeData.inputCodec_dynamics_brakeTorque_rearRight_override;
	p_theDestData->inputCodec.acc.accStatus.override                              = p_theSrcData->DeData.inputCodec_acc_accStatus_override;
	p_theDestData->inputCodec.acc.accStatus.value                                 = p_theSrcData->DeData.inputCodec_acc_accStatus_value;
	p_theDestData->inputCodec.acc.accAcceleration.override                        = p_theSrcData->DeData.inputCodec_acc_accAcceleration_override;
	p_theDestData->inputCodec.acc.systemRelevant.override                         = p_theSrcData->DeData.inputCodec_acc_systemRelevant_override;
	p_theDestData->inputCodec.acc.systemRelevant.value                            = p_theSrcData->DeData.inputCodec_acc_systemRelevant_value;
	p_theDestData->inputCodec.acc.target.distance.override                        = p_theSrcData->DeData.inputCodec_acc_target_distance_override;
	p_theDestData->inputCodec.acc.target.velocity.override                        = p_theSrcData->DeData.inputCodec_acc_target_velocity_override;
	p_theDestData->inputCodec.acc.target.acceleration.override                    = p_theSrcData->DeData.inputCodec_acc_target_acceleration_override;
	p_theDestData->inputCodec.acc.target.present.override                         = p_theSrcData->DeData.inputCodec_acc_target_present_override;
	p_theDestData->inputCodec.acc.target.present.value                            = p_theSrcData->DeData.inputCodec_acc_target_present_value;
	p_theDestData->inputCodec.acc.target.valid.override                           = p_theSrcData->DeData.inputCodec_acc_target_valid_override;
	p_theDestData->inputCodec.acc.target.valid.value                              = p_theSrcData->DeData.inputCodec_acc_target_valid_value;
	p_theDestData->inputCodec.position.valid.override                             = p_theSrcData->DeData.inputCodec_position_valid_override;
	p_theDestData->inputCodec.position.valid.value                                = p_theSrcData->DeData.inputCodec_position_valid_value;
	p_theDestData->inputCodec.position.laneCount.override                         = p_theSrcData->DeData.inputCodec_position_laneCount_override;
	p_theDestData->inputCodec.position.laneCount.value                            = p_theSrcData->DeData.inputCodec_position_laneCount_value;
	p_theDestData->inputCodec.position.lanePosition.override                      = p_theSrcData->DeData.inputCodec_position_lanePosition_override;
	p_theDestData->inputCodec.position.lanePosition.value                         = p_theSrcData->DeData.inputCodec_position_lanePosition_value;
	p_theDestData->inputCodec.position.laneType.override                          = p_theSrcData->DeData.inputCodec_position_laneType_override;
	p_theDestData->inputCodec.position.laneType.value                             = p_theSrcData->DeData.inputCodec_position_laneType_value;
	p_theDestData->longController.brakeOnly.ignore                                = p_theSrcData->DeData.longController_brakeOnly_ignore;
	p_theDestData->longController.killTransRatio                                  = p_theSrcData->DeData.longController_killTransRatio;
	p_theDestData->longController.noTransOnCoast                                  = p_theSrcData->DeData.longController_noTransOnCoast;
	p_theDestData->longController.offsetOnNeutral                                 = p_theSrcData->DeData.longController_offsetOnNeutral;
	p_theDestData->outputCodec.nextEvent.nCyclesHoldSignal                        = p_theSrcData->DeData.outputCodec_nextEvent_nCyclesHoldSignal;
	p_theDestData->outputCodec.override.DePACC02_Durchschnittsgeschw.override     = p_theSrcData->DeData.outputCodec_override_DePACC02_Durchschnittsgeschw_override;
	p_theDestData->outputCodec.override.DePACC02_Event_aktiv.override             = p_theSrcData->DeData.outputCodec_override_DePACC02_Event_aktiv_override;
	p_theDestData->outputCodec.override.DePACC02_Event_aktiv.value                = p_theSrcData->DeData.outputCodec_override_DePACC02_Event_aktiv_value;
	p_theDestData->outputCodec.override.DePACC02_Geschw_Vorausschau.override      = p_theSrcData->DeData.outputCodec_override_DePACC02_Geschw_Vorausschau_override;
	p_theDestData->outputCodec.override.DePACC02_Geschw_Vorausschau.value         = p_theSrcData->DeData.outputCodec_override_DePACC02_Geschw_Vorausschau_value;
	p_theDestData->outputCodec.override.DePACC02_Hinweis_Geschw.override          = p_theSrcData->DeData.outputCodec_override_DePACC02_Hinweis_Geschw_override;
	p_theDestData->outputCodec.override.DePACC02_Hinweis_Geschw.value             = p_theSrcData->DeData.outputCodec_override_DePACC02_Hinweis_Geschw_value;
	p_theDestData->outputCodec.override.DePACC02_InnoDrive_Texte.override         = p_theSrcData->DeData.outputCodec_override_DePACC02_InnoDrive_Texte_override;
	p_theDestData->outputCodec.override.DePACC02_InnoDrive_Texte.value            = p_theSrcData->DeData.outputCodec_override_DePACC02_InnoDrive_Texte_value;
	p_theDestData->outputCodec.override.DePACC02_Offset_Anzeige.override          = p_theSrcData->DeData.outputCodec_override_DePACC02_Offset_Anzeige_override;
	p_theDestData->outputCodec.override.DePACC02_Offset_Anzeige.value             = p_theSrcData->DeData.outputCodec_override_DePACC02_Offset_Anzeige_value;
	p_theDestData->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.override     = p_theSrcData->DeData.outputCodec_override_DePACC02_neg_Sollbeschl_Grad_override;
	p_theDestData->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.override     = p_theSrcData->DeData.outputCodec_override_DePACC02_pos_Sollbeschl_Grad_override;
	p_theDestData->outputCodec.override.DePACC02_Sollbeschleunigung.override      = p_theSrcData->DeData.outputCodec_override_DePACC02_Sollbeschleunigung_override;
	p_theDestData->outputCodec.override.DePACC02_Sollgeschwindigkeit.override     = p_theSrcData->DeData.outputCodec_override_DePACC02_Sollgeschwindigkeit_override;
	p_theDestData->outputCodec.override.DePACC02_Vorausschaugeschw.override       = p_theSrcData->DeData.outputCodec_override_DePACC02_Vorausschaugeschw_override;
	p_theDestData->outputCodec.override.DePACC02_Wunschuebersetzung.override      = p_theSrcData->DeData.outputCodec_override_DePACC02_Wunschuebersetzung_override;
	p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_oben.override       = p_theSrcData->DeData.outputCodec_override_DePACC02_zul_Regelabw_oben_override;
	p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_unten.override      = p_theSrcData->DeData.outputCodec_override_DePACC02_zul_Regelabw_unten_override;
	p_theDestData->outputCodec.override.DePACC02_Offset.override                  = p_theSrcData->DeData.outputCodec_override_DePACC02_Offset_override;
	p_theDestData->outputCodec.override.DePACC02_Ausrollmanoever.override         = p_theSrcData->DeData.outputCodec_override_DePACC02_Ausrollmanoever_override;
	p_theDestData->outputCodec.override.DePACC02_Ausrollmanoever.value            = p_theSrcData->DeData.outputCodec_override_DePACC02_Ausrollmanoever_value;
	p_theDestData->outputCodec.override.DePACC02_naechstes_Event.override         = p_theSrcData->DeData.outputCodec_override_DePACC02_naechstes_Event_override;
	p_theDestData->outputCodec.override.DePACC02_naechstes_Event.value            = p_theSrcData->DeData.outputCodec_override_DePACC02_naechstes_Event_value;
	p_theDestData->outputCodec.override.DePACC02_Systemstatus.override            = p_theSrcData->DeData.outputCodec_override_DePACC02_Systemstatus_override;
	p_theDestData->outputCodec.override.DePACC02_Systemstatus.value               = p_theSrcData->DeData.outputCodec_override_DePACC02_Systemstatus_value;
	p_theDestData->outputCodec.override.DePACC02_Systemstatus_Anzeige.override    = p_theSrcData->DeData.outputCodec_override_DePACC02_Systemstatus_Anzeige_override;
	p_theDestData->outputCodec.override.DePACC02_Systemstatus_Anzeige.value       = p_theSrcData->DeData.outputCodec_override_DePACC02_Systemstatus_Anzeige_value;
	p_theDestData->outputCodec.override.DePACC02_Automode.override                = p_theSrcData->DeData.outputCodec_override_DePACC02_Automode_override;
	p_theDestData->outputCodec.override.DePACC02_Automode.value                   = p_theSrcData->DeData.outputCodec_override_DePACC02_Automode_value;
	p_theDestData->outputCodec.override.DePACC02_Uebernahmeaufforderung.override  = p_theSrcData->DeData.outputCodec_override_DePACC02_Uebernahmeaufforderung_override;
	p_theDestData->outputCodec.override.DePACC02_Uebernahmeaufforderung.value     = p_theSrcData->DeData.outputCodec_override_DePACC02_Uebernahmeaufforderung_value;
	p_theDestData->outputCodec.override.DePACC02_Offset_Aktiv.override            = p_theSrcData->DeData.outputCodec_override_DePACC02_Offset_Aktiv_override;
	p_theDestData->outputCodec.override.DePACC02_Offset_Aktiv.value               = p_theSrcData->DeData.outputCodec_override_DePACC02_Offset_Aktiv_value;
	p_theDestData->outputCodec.override.DePIF_Toggle.override                     = p_theSrcData->DeData.outputCodec_override_DePIF_Toggle_override;
	p_theDestData->outputCodec.override.DePIF_Toggle.value                        = p_theSrcData->DeData.outputCodec_override_DePIF_Toggle_value;
	p_theDestData->outputCodec.override.DePIF_ST_Status.override                  = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Status_override;
	p_theDestData->outputCodec.override.DePIF_ST_Status.value                     = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Status_value;
	p_theDestData->outputCodec.override.DePIF_MT_Status.override                  = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Status_override;
	p_theDestData->outputCodec.override.DePIF_MT_Status.value                     = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Status_value;
	p_theDestData->outputCodec.override.DePIF_LT_Status.override                  = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Status_override;
	p_theDestData->outputCodec.override.DePIF_LT_Status.value                     = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Status_value;
	p_theDestData->outputCodec.override.DePIF_Identifier.override                 = p_theSrcData->DeData.outputCodec_override_DePIF_Identifier_override;
	p_theDestData->outputCodec.override.DePIF_Identifier.value                    = p_theSrcData->DeData.outputCodec_override_DePIF_Identifier_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_0.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_0_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_0.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_0_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_1.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_1_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_1.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_1_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_2.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_2_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_2.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_2_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_3.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_3_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_3.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_3_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_4.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_4_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_4.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_4_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_5.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_5_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_5.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_5_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_6.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_6_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_6.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_6_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_7.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_7_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_7.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_7_value;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_8.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_8_override;
	p_theDestData->outputCodec.override.DePIF_ST_Bin_8.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_ST_Bin_8_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_0.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_0_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_0.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_0_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_1.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_1_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_1.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_1_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_2.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_2_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_2.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_2_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_3.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_3_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_3.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_3_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_4.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_4_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_4.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_4_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_5.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_5_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_5.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_5_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_6.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_6_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_6.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_6_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_7.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_7_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_7.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_7_value;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_8.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_8_override;
	p_theDestData->outputCodec.override.DePIF_MT_Bin_8.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_MT_Bin_8_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_0.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_0_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_0.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_0_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_1.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_1_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_1.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_1_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_2.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_2_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_2.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_2_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_3.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_3_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_3.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_3_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_4.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_4_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_4.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_4_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_5.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_5_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_5.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_5_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_6.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_6_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_6.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_6_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_7.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_7_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_7.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_7_value;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_8.override                   = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_8_override;
	p_theDestData->outputCodec.override.DePIF_LT_Bin_8.value                      = p_theSrcData->DeData.outputCodec_override_DePIF_LT_Bin_8_value;
	p_theDestData->pathRouter.enableLowExecutionTime                              = p_theSrcData->DeData.pathRouter_enableLowExecutionTime;
	p_theDestData->pathRouter.enableTurnSignal                                    = p_theSrcData->DeData.pathRouter_enableTurnSignal;
	p_theDestData->pathRouter.maxAttributesPerCycle                               = p_theSrcData->DeData.pathRouter_maxAttributesPerCycle;
	p_theDestData->pathRouter.maxSpeedLimitsPerCycle                              = p_theSrcData->DeData.pathRouter_maxSpeedLimitsPerCycle;
	p_theDestData->pathRouter.maxSegmentsPerCycle                                 = p_theSrcData->DeData.pathRouter_maxSegmentsPerCycle;
	p_theDestData->pathRouter.maxApiCallsPerCycle                                 = p_theSrcData->DeData.pathRouter_maxApiCallsPerCycle;
	p_theDestData->pathRouter.minInvariantInfoSlopes                              = p_theSrcData->DeData.pathRouter_minInvariantInfoSlopes;
	p_theDestData->pathRouter.slopeSpacing                                        = p_theSrcData->DeData.pathRouter_slopeSpacing;
	p_theDestData->pathRouter.angleTolerance                                      = p_theSrcData->DeData.pathRouter_angleTolerance;
	p_theDestData->pathRouter.killVZOOnlyLimits                                   = p_theSrcData->DeData.pathRouter_killVZOOnlyLimits;
	p_theDestData->pathRouter.routeFilter.followRouting                           = p_theSrcData->DeData.pathRouter_routeFilter_followRouting;
	p_theDestData->pathRouter.routeFilter.preferMPP                               = p_theSrcData->DeData.pathRouter_routeFilter_preferMPP;
	p_theDestData->pathRouter.routeFilter.turnStraightest                         = p_theSrcData->DeData.pathRouter_routeFilter_turnStraightest;
	p_theDestData->pathRouter.routeFilter.useCurvature                            = p_theSrcData->DeData.pathRouter_routeFilter_useCurvature;
	p_theDestData->pathRouter.routeFilter.reluctantOnMultipleLanes                = p_theSrcData->DeData.pathRouter_routeFilter_reluctantOnMultipleLanes;
	p_theDestData->pathRouter.routeFilter.lockOnMultipleLanes                     = p_theSrcData->DeData.pathRouter_routeFilter_lockOnMultipleLanes;
	p_theDestData->pathRouter.routeFilter.lockOnRampOneWay                        = p_theSrcData->DeData.pathRouter_routeFilter_lockOnRampOneWay;
	p_theDestData->systemController.status.allowOnBadData                         = p_theSrcData->DeData.systemController_status_allowOnBadData;
	p_theDestData->systemController.status.allowOnBadRoad                         = p_theSrcData->DeData.systemController_status_allowOnBadRoad;
	p_theDestData->systemController.status.allowOnBadLimit                        = p_theSrcData->DeData.systemController_status_allowOnBadLimit;
	p_theDestData->systemController.status.overrideLeaveBOM                       = p_theSrcData->DeData.systemController_status_overrideLeaveBOM;
	p_theDestData->systemController.velocityControl.smallIncrementKmh             = p_theSrcData->DeData.systemController_velocityControl_smallIncrementKmh;
	p_theDestData->systemController.velocityControl.bigIncrementKmh               = p_theSrcData->DeData.systemController_velocityControl_bigIncrementKmh;
	p_theDestData->systemController.velocityControl.smallIncrementMph             = p_theSrcData->DeData.systemController_velocityControl_smallIncrementMph;
	p_theDestData->systemController.velocityControl.bigIncrementMph               = p_theSrcData->DeData.systemController_velocityControl_bigIncrementMph;
	p_theDestData->systemController.velocityControl.minSetSpeedKmh                = p_theSrcData->DeData.systemController_velocityControl_minSetSpeedKmh;
	p_theDestData->systemController.velocityControl.maxSetSpeedKmh                = p_theSrcData->DeData.systemController_velocityControl_maxSetSpeedKmh;
	p_theDestData->systemController.velocityControl.minSetSpeedMph                = p_theSrcData->DeData.systemController_velocityControl_minSetSpeedMph;
	p_theDestData->systemController.velocityControl.maxSetSpeedMph                = p_theSrcData->DeData.systemController_velocityControl_maxSetSpeedMph;
	p_theDestData->systemController.velocityControl.enableOverrideLimitPull       = p_theSrcData->DeData.systemController_velocityControl_enableOverrideLimitPull;
	p_theDestData->systemController.velocityControl.enableOverrideLimitDrop       = p_theSrcData->DeData.systemController_velocityControl_enableOverrideLimitDrop;
	p_theDestData->systemController.velocityControl.enableCancelTipActions        = p_theSrcData->DeData.systemController_velocityControl_enableCancelTipActions;
	p_theDestData->systemController.resumeAction.manMode.acceptNextLimit          = p_theSrcData->DeData.systemController_resumeAction_manMode_acceptNextLimit;
	p_theDestData->systemController.resumeAction.manMode.acceptCurrentLimit       = p_theSrcData->DeData.systemController_resumeAction_manMode_acceptCurrentLimit;
	p_theDestData->systemController.resumeAction.autoMode.discardNextLimit        = p_theSrcData->DeData.systemController_resumeAction_autoMode_discardNextLimit;
	p_theDestData->systemController.resumeAction.autoMode.acceptNextLimit         = p_theSrcData->DeData.systemController_resumeAction_autoMode_acceptNextLimit;
	p_theDestData->systemController.resumeAction.autoMode.discardCurrentLimit     = p_theSrcData->DeData.systemController_resumeAction_autoMode_discardCurrentLimit;
	p_theDestData->systemController.resumeAction.autoMode.acceptCurrentLimit      = p_theSrcData->DeData.systemController_resumeAction_autoMode_acceptCurrentLimit;
	p_theDestData->systemController.speedCheck.enabled                            = p_theSrcData->DeData.systemController_speedCheck_enabled;
	p_theDestData->systemController.countryList.count                             = p_theSrcData->DeData.systemController_countryList_count;

	BUILD_BUG_ON((uint32_T)prmNUMCOUNTRYLIST != sizeof(p_theSrcData->DeData.systemController_countryList_list) / sizeof(p_theSrcData->DeData.systemController_countryList_list[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMCOUNTRYLIST; uiArrIdx++)
	{
		p_theDestData->systemController.countryList.list[uiArrIdx] = p_theSrcData->DeData.systemController_countryList_list[uiArrIdx]; 
	}
	p_theDestData->vehicleObserver.velocity.useDisplayVelocity                    = p_theSrcData->DeData.vehicleObserver_velocity_useDisplayVelocity;
	p_theDestData->vehicleObserver.turnSignal.lockByLane                          = p_theSrcData->DeData.vehicleObserver_turnSignal_lockByLane;
	p_theDestData->vehicleObserver.turnSignal.forceByType                         = p_theSrcData->DeData.vehicleObserver_turnSignal_forceByType;
	p_theDestData->vehicleObserver.traffic.useEgoAcceleration                     = p_theSrcData->DeData.vehicleObserver_traffic_useEgoAcceleration;
	p_theDestData->vehicleObserver.courage.wetness.enabled                        = p_theSrcData->DeData.vehicleObserver_courage_wetness_enabled;
	p_theDestData->vehicleObserver.sign.holdReleased                              = p_theSrcData->DeData.vehicleObserver_sign_holdReleased;
	p_theDestData->inputCodec.driver.fodInitialized.override                      = p_theSrcData->DeData.reserved_uint8_00;
	p_theDestData->inputCodec.driver.fodInitialized.value                         = p_theSrcData->DeData.reserved_uint8_01;
	p_theDestData->inputCodec.driver.stpStatus.override                           = p_theSrcData->DeData.reserved_uint8_02;
	p_theDestData->inputCodec.driver.stpStatus.value                              = p_theSrcData->DeData.reserved_uint8_03;
	p_theDestData->inputCodec.road.frictionLevel.override                         = p_theSrcData->DeData.reserved_uint8_04;
	p_theDestData->inputCodec.road.frictionLevel.value                            = p_theSrcData->DeData.reserved_uint8_05;
	p_theDestData->outputCodec.override.DePACC02_FoD_Status.override              = p_theSrcData->DeData.reserved_uint8_06;
	p_theDestData->outputCodec.override.DePACC02_FoD_Status.value                 = p_theSrcData->DeData.reserved_uint8_07;
	p_theDestData->systemController.status.idleWhenSTPactive                      = p_theSrcData->DeData.reserved_uint8_08;
	p_theDestData->vehicleObserver.courage.friction.enabled                       = p_theSrcData->DeData.reserved_uint8_09;

	uiArrIdx = (uint32_T)(4 * prmNUMFRICTIONFACTOR);
	BUILD_BUG_ON((uint32_T)(4 * prmNUMFRICTIONFACTOR) != sizeof(p_theDestData->vehicleObserver.courage.friction.adaptionFactor.level));
	memcpy((void*)(&p_theDestData->vehicleObserver.courage.friction.adaptionFactor.level[0]), (const void*)(&pRteBuf[uiBufIdx]), uiArrIdx); uiBufIdx += uiArrIdx;

	uiArrIdx = (uint32_T)(4 * prmNUMFRICTIONFACTOR);
	BUILD_BUG_ON((uint32_T)(4 * prmNUMFRICTIONFACTOR) != sizeof(p_theDestData->vehicleObserver.courage.friction.adaptionFactor.factor));
	memcpy((void*)(&p_theDestData->vehicleObserver.courage.friction.adaptionFactor.factor[0]), (const void*)(&pRteBuf[uiBufIdx]), uiArrIdx);

	/* The complete structure length is: 2546 Bytes.*/

	return true;
}
/*lint -restore */

/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e529 (Warning -- Symbol 'uiArrIdx' (line 1309) not subsequently referenced)*/
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
ICC_API bool_T rteCheckBounds_parameterSetCtrl(const parameterSetCtrl_T *p_theDestData)
{
	uint32_T uiArrIdx;

#if !defined INNODRIVE_ZFAS_SWC_BUILD
	if((Dt_FLOAT32)p_theDestData->displayController.velocityThreshold.eventFire > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.velocityThreshold.eventFire < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.velocityThreshold.eventHold > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.velocityThreshold.eventHold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.accelerationThreshold.eventFire > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.accelerationThreshold.eventFire < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.accelerationThreshold.eventHold > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.accelerationThreshold.eventHold < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.significanceThreshold.eventFire > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.significanceThreshold.eventFire < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.significanceThreshold.eventHold > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.significanceThreshold.eventHold < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.curveTakeover.thresholdSet > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.curveTakeover.thresholdSet < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.curveTakeover.thresholdHold > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.curveTakeover.thresholdHold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.ttcThreshold > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.ttcThreshold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.previewThreshold > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.previewThreshold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.longAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.longAcceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.longDeceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.longDeceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.latAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.latAcceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.offsetVelocity > (Dt_FLOAT32)5.56) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryInit.offsetVelocity < (Dt_FLOAT32)-5.56) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.longAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.longAcceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.longDeceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.longDeceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.latAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.latAcceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.offsetVelocity > (Dt_FLOAT32)5.56) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.countryRadarInit.offsetVelocity < (Dt_FLOAT32)-5.56) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.longAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.longAcceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.longDeceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.longDeceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.latAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.latAcceleration < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.offsetVelocity > (Dt_FLOAT32)5.56) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.cityInit.offsetVelocity < (Dt_FLOAT32)-5.56) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.minVelocityRampDown > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.minVelocityRampDown < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.velocityTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.velocityTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.velocityToleranceLarge > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.velocityToleranceLarge < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.onlineSpeedTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.onlineSpeedTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longAccelerationToleranceUp > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longAccelerationToleranceUp < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longAccelerationToleranceDown > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longAccelerationToleranceDown < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longDecelerationTolerance > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longDecelerationTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longAccTolPushNextLimit > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.longAccTolPushNextLimit < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.latAccelerationTolerance > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.latAccelerationTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.extrapolationTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.extrapolationTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.rampDownTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.rampDownTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.bufferTimeAfterLimit > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.bufferTimeAfterLimit < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.bufferLengthBeforeLimit > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.bufferLengthBeforeLimit < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.maxDistanceNextLimit > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.desiredSpeed.maxDistanceNextLimit < (Dt_FLOAT32)0.0f) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.lowerBounds[uiArrIdx] > (Dt_FLOAT32)0.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.lowerBounds[uiArrIdx] < (Dt_FLOAT32)-343.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.upperBounds[uiArrIdx] > (Dt_FLOAT32)343.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.upperBounds[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.initialValues[uiArrIdx] > (Dt_FLOAT32)343.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.initialValues[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.maxVelocity.initialValues[uiArrIdx] > (Dt_FLOAT32)343.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.maxVelocity.initialValues[uiArrIdx] < (Dt_FLOAT32) 0.0f) { return false; }
	}
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.standStillVelocityTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.standStillVelocityTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarPropagationTime > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarPropagationTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarTimeGapIn > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarTimeGapIn < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarTimeGapOut > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarTimeGapOut < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarRelativeVelocityIn > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarRelativeVelocityIn < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarRelativeVelocityOut > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarRelativeVelocityOut < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarDebounceTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.radarDebounceTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.highwayDebounceDynEventBefore > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.highwayDebounceDynEventBefore < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.highwayDebounceDynEventAfter > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.highwayDebounceDynEventAfter < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.builtUpSpeedLimit > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.environment.builtUpSpeedLimit < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.minAcceleration > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.minAccelerationFactor > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.minAccelerationFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.onlineLimit.offset > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.onlineLimit.offset < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.onlineLimit.maxSpeedLimit > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.onlineLimit.maxSpeedLimit < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.onlineLimit.factor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.onlineLimit.factor < (Dt_FLOAT32)0.0f) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.latAcceleration[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.latAcceleration[uiArrIdx] < (Dt_FLOAT32)-10.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.longAcceleration[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.longAcceleration[uiArrIdx] < (Dt_FLOAT32)-10.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.wheelPower[uiArrIdx] > (Dt_FLOAT32)1.0E6f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.wheelPower[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dprdMAXRANGECOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.velocity[uiArrIdx] > (Dt_FLOAT32)343.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverPredictor.containerRange.velocity[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.sumTorque.value > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.sumTorque.value < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.maxTorqueElectric.value > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.maxTorqueElectric.value < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.eTorquePrimary.value > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.eTorquePrimary.value < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.eTorqueSecondary.value > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.powertrain.eTorqueSecondary.value < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.driver.maxAutoSpeed.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.driver.maxAutoSpeed.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.driver.accelerator.value > (Dt_FLOAT32)200.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.driver.accelerator.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.sign.predicted.distance.value > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.sign.predicted.distance.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.sign.conditions.trailerLimit.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.sign.conditions.trailerLimit.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.road.slope.value > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.road.slope.value < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.curvature.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.curvature.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.curveRate.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.curveRate.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.length.value > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.length.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.distance.value > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineLeft.distance.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.curvature.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.curvature.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.curveRate.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.curveRate.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.length.value > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.length.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.distance.value > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.camera.lineRight.distance.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.velocity.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.velocity.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.longAcceleration.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.longAcceleration.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.latAcceleration.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.latAcceleration.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.displayVelocity.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.displayVelocity.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.yawRate.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.yawRate.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.heading.value > (Dt_FLOAT32)360.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.heading.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.wheelAngle.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.wheelAngle.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.wheelRate.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.wheelRate.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.rearAngle.value > (Dt_FLOAT32)180.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.rearAngle.value < (Dt_FLOAT32)-180.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.frontLeft.value > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.frontLeft.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.frontRight.value > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.frontRight.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.rearLeft.value > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.rearLeft.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.rearRight.value > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.dynamics.brakeTorque.rearRight.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.accAcceleration.value > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.accAcceleration.value < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.target.distance.value > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.target.distance.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.target.velocity.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.target.velocity.value < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.target.acceleration.value > (Dt_FLOAT32)20.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->inputCodec.acc.target.acceleration.value < (Dt_FLOAT32)-20.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.predTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.predTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.fail > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.fail < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.max > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.max < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.min > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.velocity.min < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.predTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.predTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.max > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.max < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.min > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.min < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.fail > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.fail < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.advanceJerk > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.acceleration.advanceJerk < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.jerk.positive > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.jerk.positive < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.jerk.negative > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.jerk.negative < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.jerk.negCoast > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.jerk.negCoast < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.on.max > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.on.max < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.on.min > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.on.min < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.off.max > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.off.max < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.off.min > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.upper.off.min < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.on.max > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.on.max < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.on.min > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.on.min < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.off.max > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.off.max < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.off.min > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.tolerance.lower.off.min < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.acceleration.max > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.acceleration.max < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.acceleration.min > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.acceleration.min < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.tolerance.upper > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.tolerance.upper < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.tolerance.lower > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.brakeOnly.tolerance.lower < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.coastFading.leaveTime > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.coastFading.leaveTime < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.accDeviation.drvMdElectricAuto > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.accDeviation.drvMdElectricAuto < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.accDeviation.drvMdEpower > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.accDeviation.drvMdEpower < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.coastOffset > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.coastOffset < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.transRatioAdvance > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longController.transRatioAdvance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longStabTrigger.prioVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longStabTrigger.prioVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longStabTrigger.maxPlanTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longStabTrigger.maxPlanTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longStabTrigger.minPlanTolerance > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longStabTrigger.minPlanTolerance < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Durchschnittsgeschw.value > (Dt_FLOAT32)306.9f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Durchschnittsgeschw.value < (Dt_FLOAT32)0) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.value > (Dt_FLOAT32)12.75f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.value > (Dt_FLOAT32)12.75f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Sollbeschleunigung.value > (Dt_FLOAT32)3.005f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Sollbeschleunigung.value < (Dt_FLOAT32)-7.22f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Sollgeschwindigkeit.value > (Dt_FLOAT32)327.04f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Sollgeschwindigkeit.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Vorausschaugeschw.value > (Dt_FLOAT32)327.04f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Vorausschaugeschw.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Wunschuebersetzung.value > (Dt_FLOAT32)25.0635) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_Wunschuebersetzung.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_oben.value > (Dt_FLOAT32)1.9375f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_oben.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_unten.value > (Dt_FLOAT32)1.512) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_unten.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.headingCorrectionGradient > (Dt_FLOAT32)1.0E10) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.headingCorrectionGradient < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.yieldSignTolerance > (Dt_FLOAT32)1000.0) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.yieldSignTolerance < (Dt_FLOAT32)0) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.routeFilter.maxBranchAngle > (Dt_FLOAT32)180.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.routeFilter.maxBranchAngle < (Dt_FLOAT32)0) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.correctionFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.correctionFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.positionTolerance > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.positionTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.headingTolerance > (Dt_FLOAT32)360.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.headingTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.minKnownDistanceAhead > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.minKnownDistanceAhead < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.inhibitTimeFactor > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.inhibitTimeFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.inhibitTimeOffset > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.positionFilter.inhibitTimeOffset < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.holdFilter.holdDistance > (Dt_FLOAT32)10000.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.holdFilter.holdDistance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.holdFilter.holdHeadDeviaton > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.holdFilter.holdHeadDeviaton < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.normalDistance > (Dt_FLOAT32)1000.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.normalDistance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.normalHeadDeviaton > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.normalHeadDeviaton < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.extendedDistance > (Dt_FLOAT32)1000.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.extendedDistance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.extendedHeadDeviaton > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->pathRouter.turnFilter.extendedHeadDeviaton < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.doubleClickTimeout > (Dt_FLOAT32)5.12) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.doubleClickTimeout < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.mapValidDebounceTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.mapValidDebounceTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.roadDataDebounceTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.roadDataDebounceTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.strategyDebounceTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.strategyDebounceTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.speedLimitDebounceTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.speedLimitDebounceTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.overrideDebounceTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.status.overrideDebounceTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.thresholdStandStill > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.thresholdStandStill < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.hintSetDelta > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.hintSetDelta < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.hintResetDelta > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.hintResetDelta < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.bufferTimeLastSetSpeed > (Dt_FLOAT32)1310.72f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.velocityControl.bufferTimeLastSetSpeed < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.timeMax > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.timeMax < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.timeMin > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.timeMin < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.distanceMin > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.distanceMin < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.revertThreshold > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.revertThreshold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.positionOffset > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.limitPreview.positionOffset < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.previewLock.timeTrigger > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.previewLock.timeTrigger < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.previewLock.revertThreshold > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.previewLock.revertThreshold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.speedCheck.velocityHyst > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.speedCheck.velocityHyst < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.timeMax > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.timeMax < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.timeMin > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.timeMin < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.distanceMin > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.distanceMin < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.revertThreshold > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.revertThreshold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.initSweepLength > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.initSweepLength < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.proximityEnter > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.proximityEnter < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.proximityHold > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.proximityHold < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.proximityLeave > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.stop.proximityLeave < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.overrideReturn.velocityTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.overrideReturn.velocityTolerance < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.refDecayFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.refDecayFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.maxAbsolute > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.maxAbsolute < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.minAbsolute > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.minAbsolute < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.maxRelative > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.maxRelative < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.minRelative > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.tolerance.minRelative < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.inner.minTolerance > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.inner.minTolerance < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.inner.maxTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.inner.maxTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.inner.factor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.inner.factor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.outer.minTolerance > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.outer.minTolerance < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.outer.maxTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.outer.maxTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.outer.factor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.velocity.outer.factor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.updateFactor > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.updateFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.bleedFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.bleedFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.maxRate > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.maxRate < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.minRate > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.minRate < (Dt_FLOAT32)-1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.minVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.minVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.inner.minTolerance > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.inner.minTolerance < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.inner.maxTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.inner.maxTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.inner.factor > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.inner.factor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.outer.minTolerance > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.outer.minTolerance < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.outer.maxTolerance > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.outer.maxTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.outer.factor > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.outer.factor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.minEngaged > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.minEngaged < (Dt_FLOAT32)-1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.maxEngaged > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.maxEngaged < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.minDisengaged > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.minDisengaged < (Dt_FLOAT32)-1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.maxDisengaged > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.stateLimit.maxDisengaged < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.minEngaged > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.minEngaged < (Dt_FLOAT32)-1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.maxEngaged > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.maxEngaged < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.minDisengaged > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.minDisengaged < (Dt_FLOAT32)-1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.maxDisengaged > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.filterLimit.maxDisengaged < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.torqueTolerance > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.torqueTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.bleedRate > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.bleedRate < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.thresholdLock > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.thresholdLock < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.thresholdUnlock > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.thresholdUnlock < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.entryJerk > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.deviation.gearLock.entryJerk < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.updateFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.updateFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.maxDeviation > (Dt_FLOAT32)180.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.maxDeviation < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.minDeviation > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.minDeviation < (Dt_FLOAT32)-180.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.maxHeadingInvalidTime > (Dt_FLOAT32)360000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.heading.maxHeadingInvalidTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.steering.predTime > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.steering.predTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.slope.tskTolerance > (Dt_FLOAT32)2.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.slope.tskTolerance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.turnSignal.previewTime > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.turnSignal.previewTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.traffic.offset.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.traffic.offset.velocity < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.traffic.offset.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.traffic.offset.acceleration < (Dt_FLOAT32)-10.0f) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMWETNESSFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.level[uiArrIdx] > (Dt_FLOAT32)6) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.level[uiArrIdx] < (Dt_FLOAT32)0) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMWETNESSFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.factor[uiArrIdx] > (Dt_FLOAT32)1.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.factor[uiArrIdx] < (Dt_FLOAT32)-1.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMADAPTIONRATE; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.adaptionFactor.angle[uiArrIdx] > (Dt_FLOAT32)6.28) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.adaptionFactor.angle[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMADAPTIONRATE; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.adaptionFactor.rate[uiArrIdx] > (Dt_FLOAT32)1.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.adaptionFactor.rate[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.faultDistance > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.faultDistance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.pullVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.pullVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.driftVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.driftVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.averageMin > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.averageMin < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.differenceMin > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.differenceMin < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.confidenceRate > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.confidenceRate < (Dt_FLOAT32)0.0f) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMTAILFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.tailFactor.tail[uiArrIdx] > (Dt_FLOAT32)1000.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.tailFactor.tail[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMTAILFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.tailFactor.factor[uiArrIdx] > (Dt_FLOAT32)1.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.tailFactor.factor[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMCURVATUREFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.curvature[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.curvature[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMCURVATUREFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.factor[uiArrIdx] > (Dt_FLOAT32)1.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.factor[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.maxHorizon > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.maxHorizon < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.minHorizon > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.minHorizon < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.maxVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.maxVelocity < (Dt_FLOAT32)0) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.upperDeviation.deviation[uiArrIdx] > (Dt_FLOAT32)343.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.upperDeviation.deviation[uiArrIdx] < (Dt_FLOAT32)0) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.upperDeviation.factor[uiArrIdx] > (Dt_FLOAT32)0.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.upperDeviation.factor[uiArrIdx] < (Dt_FLOAT32)-1.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.lowerDeviation.deviation[uiArrIdx] > (Dt_FLOAT32)0.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.lowerDeviation.deviation[uiArrIdx] < (Dt_FLOAT32)-343.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMLIMITDEVFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.lowerDeviation.factor[uiArrIdx] > (Dt_FLOAT32)0.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limit.lowerDeviation.factor[uiArrIdx] < (Dt_FLOAT32)-1.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMFOLLOWGAPFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.follow.gapFactor.timeGap[uiArrIdx] > (Dt_FLOAT32)60.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.follow.gapFactor.timeGap[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMFOLLOWGAPFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.follow.gapFactor.factor[uiArrIdx] > (Dt_FLOAT32)1.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.follow.gapFactor.factor[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMRESETAGEFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.reset.ageFactor.ticks[uiArrIdx] > (Dt_FLOAT32)INVALID_VALUE) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.reset.ageFactor.ticks[uiArrIdx] < (Dt_FLOAT32)0) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMRESETAGEFACTOR; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.reset.ageFactor.factor[uiArrIdx] > (Dt_FLOAT32)0.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.reset.ageFactor.factor[uiArrIdx] < (Dt_FLOAT32)-1.0f) { return false; }
	}
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureMax > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureMax < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureMin > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureMin < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureRateMax > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureRateMax < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureRateMin > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curvatureRateMin < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtainMaxRate > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtainMaxRate < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtainMinRate > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curtainMinRate < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.maxJerkMaxRate > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.maxJerkMaxRate < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limitJerkMaxRate > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.limitJerkMaxRate < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curveJerkMaxRate > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.curveJerkMaxRate < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.check.codeCheckTimeout > (Dt_FLOAT32)vobsCHECKTIMEOUTMAX) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.check.codeCheckTimeout < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.check.velocityCheckTimeout > (Dt_FLOAT32)vobsCHECKTIMEOUTMAX) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.check.velocityCheckTimeout < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.check.controlCheckTimeout > (Dt_FLOAT32)vobsCHECKTIMEOUTMAX) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.check.controlCheckTimeout < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.waitTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.waitTime < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.lockTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.lockTime < (Dt_FLOAT32)0.0f) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMMAXBRAKETORQUE; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.velocity[uiArrIdx] > (Dt_FLOAT32)70.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.velocity[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)prmNUMMAXBRAKETORQUE; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.torque[uiArrIdx] > (Dt_FLOAT32)5.0E10f) { return false; }
		if((Dt_FLOAT32)p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.torque[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}
	if((Dt_UINT16_1_0)p_theDestData->inputCodec.driver.vMaxRaw.value > (Dt_UINT16_1_0)1000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->inputCodec.sign.limit.value > (Dt_UINT16_1_0)1000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->inputCodec.sign.predicted.limit.value > (Dt_UINT16_1_0)1000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->inputCodec.sign.conditions.trailerRaw.value > (Dt_UINT16_1_0)1000) { return false; }
	if((Dt_SINT16_1_0)p_theDestData->outputCodec.override.DePACC02_Offset.value > (Dt_SINT16_1_0)256) { return false; }
	if((Dt_SINT16_1_0)p_theDestData->outputCodec.override.DePACC02_Offset.value < (Dt_SINT16_1_0)-255) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.gear.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.gear.value > (Dt_UINT8_1_0)15) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.hybridVehicle.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.hybridVehicle.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.coastingPossible.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.coastingPossible.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.sumTorque.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.transmissionManual.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.transmissionManual.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.maxTorqueElectric.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.combustionEngineActive.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.combustionEngineActive.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.ePowerSelected.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.ePowerSelected.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.eTorquePrimary.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.eTorqueSecondary.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.powertrain.motorCode.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.enabled.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.enabled.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.selected.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.selected.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.tipUp.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.tipUp.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.tipDown.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.tipDown.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.set.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.set.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.resume.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.resume.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.followingGap.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.followingGap.value > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.charisma.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.charisma.value > (Dt_UINT8_1_0)2) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.autoMode.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.autoMode.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.maxAutoSpeed.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.turnSignal.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.turnSignal.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.signalLocked.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.signalLocked.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.accelerator.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.displayUnit.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.displayUnit.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.vMaxRaw.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.vMaxUnit.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.vMaxUnit.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.offset.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_SINT8_1_0)p_theDestData->inputCodec.driver.offset.value > (Dt_SINT8_1_0)10) { return false; }
	if((Dt_SINT8_1_0)p_theDestData->inputCodec.driver.offset.value < (Dt_SINT8_1_0)-10) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.ignoreCountry.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.ignoreCountry.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.fodActivation.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.fodActivation.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.limit.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.text.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.text.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.predicted.limit.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.predicted.distance.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.predicted.additionalInfo.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.predicted.additionalInfo.value > (Dt_UINT8_1_0)15) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.predicted.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.predicted.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.trailerLimit.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.trailerRaw.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.fog.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.fog.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.wet.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.wet.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.trailer.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.sign.conditions.trailer.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.road.slope.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.road.wetnessLevel.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.road.wetnessLevel.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineLeft.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineLeft.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineLeft.curvature.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineLeft.curveRate.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineLeft.length.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineLeft.distance.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineRight.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineRight.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineRight.curvature.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineRight.curveRate.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineRight.length.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.camera.lineRight.distance.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.velocity.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.longAcceleration.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.latAcceleration.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.displayVelocity.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.yawRate.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.heading.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.wheelAngle.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.wheelRate.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.rearAngle.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.rasPresent.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.rasPresent.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.headValid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.headValid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.serviceBrakeEngaged.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.serviceBrakeEngaged.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.brakeTorque.frontLeft.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.brakeTorque.frontRight.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.brakeTorque.rearLeft.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.dynamics.brakeTorque.rearRight.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.accStatus.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.accStatus.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.accAcceleration.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.systemRelevant.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.systemRelevant.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.distance.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.velocity.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.acceleration.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.present.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.present.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.acc.target.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.valid.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.valid.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.laneCount.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.laneCount.value > (Dt_UINT8_1_0)14) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.lanePosition.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_SINT8_1_0)p_theDestData->inputCodec.position.lanePosition.value > (Dt_SINT8_1_0)13) { return false; }
	if((Dt_SINT8_1_0)p_theDestData->inputCodec.position.lanePosition.value < (Dt_SINT8_1_0)0) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.laneType.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.position.laneType.value > (Dt_UINT8_1_0)16) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longController.brakeOnly.ignore > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->longController.killTransRatio > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->longController.noTransOnCoast > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->longController.offsetOnNeutral > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.nextEvent.nCyclesHoldSignal < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Durchschnittsgeschw.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Event_aktiv.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Event_aktiv.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Geschw_Vorausschau.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Geschw_Vorausschau.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Hinweis_Geschw.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Hinweis_Geschw.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_InnoDrive_Texte.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_InnoDrive_Texte.value > (Dt_UINT8_1_0)11) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Offset_Anzeige.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_SINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Offset_Anzeige.value > (Dt_SINT8_1_0)32) { return false; }
	if((Dt_SINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Offset_Anzeige.value < (Dt_SINT8_1_0)-31) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Sollbeschleunigung.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Sollgeschwindigkeit.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Vorausschaugeschw.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Wunschuebersetzung.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_oben.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_zul_Regelabw_unten.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Offset.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Ausrollmanoever.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Ausrollmanoever.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_naechstes_Event.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_naechstes_Event.value > (Dt_UINT8_1_0)63) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Systemstatus.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Systemstatus.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Systemstatus_Anzeige.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Systemstatus_Anzeige.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Automode.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Automode.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Uebernahmeaufforderung.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Uebernahmeaufforderung.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Offset_Aktiv.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_Offset_Aktiv.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_Toggle.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_Toggle.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Status.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Status.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Status.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Status.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Status.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Status.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_Identifier.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_Identifier.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_0.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_0.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_1.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_1.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_2.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_2.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_3.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_3.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_4.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_4.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_5.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_5.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_6.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_6.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_7.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_7.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_8.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_ST_Bin_8.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_0.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_0.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_1.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_1.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_2.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_2.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_3.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_3.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_4.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_4.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_5.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_5.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_6.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_6.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_7.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_7.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_8.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_MT_Bin_8.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_0.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_0.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_1.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_1.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_2.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_2.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_3.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_3.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_4.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_4.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_5.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_5.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_6.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_6.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_7.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_7.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_8.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePIF_LT_Bin_8.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.enableLowExecutionTime > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.enableTurnSignal > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.killVZOOnlyLimits > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.followRouting > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.preferMPP > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.turnStraightest > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.useCurvature > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.reluctantOnMultipleLanes > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.lockOnMultipleLanes > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.routeFilter.lockOnRampOneWay > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.status.allowOnBadData > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.status.allowOnBadRoad > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.status.allowOnBadLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.status.overrideLeaveBOM > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.enableOverrideLimitPull > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.enableOverrideLimitDrop > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.enableCancelTipActions > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.resumeAction.manMode.acceptNextLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.resumeAction.manMode.acceptCurrentLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.resumeAction.autoMode.discardNextLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.resumeAction.autoMode.acceptNextLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.resumeAction.autoMode.discardCurrentLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.resumeAction.autoMode.acceptCurrentLimit > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemController.speedCheck.enabled > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.velocity.useDisplayVelocity > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.turnSignal.lockByLane > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.turnSignal.forceByType > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.traffic.useEgoAcceleration > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.courage.wetness.enabled > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.sign.holdReleased > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.fodInitialized.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.fodInitialized.value > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.stpStatus.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.driver.stpStatus.value > (Dt_UINT8_1_0)15) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.road.frictionLevel.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->inputCodec.road.frictionLevel.value > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_FoD_Status.override > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->outputCodec.override.DePACC02_FoD_Status.value > (Dt_UINT8_1_0)3) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.status.idleWhenSTPactive > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleObserver.courage.friction.enabled > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/

#endif

	if((Dt_FLOAT32)p_theDestData->displayController.previewCutOff > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->displayController.previewCutOff < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.longAccelerationFilterTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.longAccelerationFilterTime < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.latAccelerationFilterTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.latAccelerationFilterTime < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.velocityFilterTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.velocityFilterTime < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.acceleratorFilterTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.inputFilter.acceleratorFilterTime < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.lowPassTimeConstant > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.dynamicValues.lowPassTimeConstant < (Dt_FLOAT32)0.001f) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.longAccelerationLevels[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.longAccelerationLevels[uiArrIdx] < (Dt_FLOAT32)0.01f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.longDecelerationLevels[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.longDecelerationLevels[uiArrIdx] < (Dt_FLOAT32)0.01f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.latAccelerationLevels[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.latAccelerationLevels[uiArrIdx] < (Dt_FLOAT32)0.01f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.wheelPowerLevels[uiArrIdx] > (Dt_FLOAT32)1000.0E3f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.wheelPowerLevels[uiArrIdx] < (Dt_FLOAT32)0.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.acceleratorGradLevels[uiArrIdx] > (Dt_FLOAT32)10E10f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.acceleratorGradLevels[uiArrIdx] < (Dt_FLOAT32)0.01f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.maxJerkLevels[uiArrIdx] > (Dt_FLOAT32)10.0f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.maxJerkLevels[uiArrIdx] < (Dt_FLOAT32)0.01f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.minJerkLevels[uiArrIdx] > (Dt_FLOAT32)-0.01f) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.minJerkLevels[uiArrIdx] < (Dt_FLOAT32)-10.0f) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)dobsMAXLEVELCOUNT; uiArrIdx++)
	{
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.deescalationTimes[uiArrIdx] > (Dt_FLOAT32)1.0E10) { return false; }
		if((Dt_FLOAT32)p_theDestData->driverObserver.escalation.deescalationTimes[uiArrIdx] < (Dt_FLOAT32)0.01f) { return false; }
	}
	if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.lowPassTimeConstant > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.offsetVelocity.lowPassTimeConstant < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.maxVelocity.lowPassTimeConstantUp > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.maxVelocity.lowPassTimeConstantUp < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.maxVelocity.lowPassTimeConstantDown > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverObserver.maxVelocity.lowPassTimeConstantDown < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.deltaTime > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.deltaTime < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.branch.length > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.branch.length < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.branch.factorIn > (Dt_FLOAT32)0.999f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.branch.factorIn < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.branch.factorOut > (Dt_FLOAT32)0.999f) { return false; }
	if((Dt_FLOAT32)p_theDestData->driverPredictor.branch.factorOut < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.dsplStateDebounceTime > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->outputCodec.dsplStateDebounceTime < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.longPressTime.initial > (Dt_FLOAT32)5.12) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.longPressTime.initial < (Dt_FLOAT32)0.02f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.longPressTime.periodic > (Dt_FLOAT32)5.12) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemController.longPressTime.periodic < (Dt_FLOAT32)0.02f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.steering.angleRateCutOff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.steering.angleRateCutOff < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.steering.slowAngleCutOff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.steering.slowAngleCutOff < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.curvatureCutOff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.curvatureCutOff < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.curveRateCutOff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.curveRateCutOff < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.distanceCutOff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.distanceCutOff < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.confidenceCutOff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.curvature.confidenceCutOff < (Dt_FLOAT32)0.01f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.traffic.accelerationCutOff > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.traffic.accelerationCutOff < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.avgCutOffFreq > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.avgCutOffFreq < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.averageDiv > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.averageDiv < (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.differenceDiv > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.courage.width.differenceDiv < (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.accBoost.holdTime > (Dt_FLOAT32)1310.72) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleObserver.accBoost.holdTime < (Dt_FLOAT32)0.1f) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.prepCount.speedLimit > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.prepCount.onlineLimit > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.prepCount.curvature > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.prepCount.environment > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.evalCount.speedLimit > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.evalCount.onlineLimit > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->driverPredictor.evalCount.curvature > (Dt_UINT16_1_0)dprdCONSTRAINT_COUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemController.speedCheck.toleranceTicks > (Dt_UINT16_1_0)32768) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemController.speedCheck.rampTicks > (Dt_UINT16_1_0)32768) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemController.speedCheck.rampTicks < (Dt_UINT16_1_0)1) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.traffic.offset.rampTicks < (Dt_UINT16_1_0)1) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.wetness.adaptionFactor.count > (Dt_UINT16_1_0)prmNUMWETNESSFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.width.adaptionFactor.count > (Dt_UINT16_1_0)prmNUMADAPTIONRATE) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.curtain.tailFactor.count > (Dt_UINT16_1_0)prmNUMTAILFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.curtain.curvatureFactor.count > (Dt_UINT16_1_0)prmNUMCURVATUREFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.limit.upperDeviation.count > (Dt_UINT16_1_0)prmNUMLIMITDEVFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.limit.lowerDeviation.count > (Dt_UINT16_1_0)prmNUMLIMITDEVFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.follow.gapFactor.count > (Dt_UINT16_1_0)prmNUMFOLLOWGAPFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.reset.ageFactor.count > (Dt_UINT16_1_0)prmNUMRESETAGEFACTOR) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.lockCoast.maxBrakeTorque.count > (Dt_UINT16_1_0)prmNUMMAXBRAKETORQUE) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->longController.jerk.rampUpTicks > (Dt_UINT16_1_0)65534) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->longController.transmissionRatio.waitTicks > (Dt_UINT16_1_0)65534) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleObserver.courage.friction.adaptionFactor.count > (Dt_UINT16_1_0)prmNUMFRICTIONFACTOR) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->driverObserver.dynamicValues.countryInit.level > (Dt_UINT8_1_0)dobsMAXLEVEL) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->driverObserver.dynamicValues.countryRadarInit.level > (Dt_UINT8_1_0)dobsMAXLEVEL) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->driverObserver.dynamicValues.cityInit.level > (Dt_UINT8_1_0)dobsMAXLEVEL) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->driverObserver.escalation.levelCount > (Dt_UINT8_1_0)dobsMAXLEVELCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->driverObserver.escalation.escalationOffset > (Dt_UINT8_1_0)dobsMAXLEVELCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->driverPredictor.timestepCount > (Dt_UINT8_1_0)dprdTRAJECTORY_COUNT) { return false; }

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)3; uiArrIdx++)
	{
		if((Dt_UINT8_1_0)p_theDestData->driverPredictor.windowStart[uiArrIdx] > (Dt_UINT8_1_0)dprdTRAJECTORY_COUNT) { return false; }
	}

	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)3; uiArrIdx++)
	{
		if((Dt_UINT8_1_0)p_theDestData->driverPredictor.windowEnd[uiArrIdx] > (Dt_UINT8_1_0)dprdTRAJECTORY_COUNT) { return false; }
	}
	if((Dt_UINT8_1_0)p_theDestData->driverPredictor.minDynamicLevel > (Dt_UINT8_1_0)dobsMAXLEVEL) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxAttributesPerCycle > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxAttributesPerCycle < (Dt_UINT8_1_0)2) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxSpeedLimitsPerCycle > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxSpeedLimitsPerCycle < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxSegmentsPerCycle > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxSegmentsPerCycle < (Dt_UINT8_1_0)6) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxApiCallsPerCycle > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.maxApiCallsPerCycle < (Dt_UINT8_1_0)6) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.minInvariantInfoSlopes > (Dt_UINT8_1_0)29) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.minInvariantInfoSlopes < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.slopeSpacing > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.slopeSpacing < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->pathRouter.angleTolerance > (Dt_UINT8_1_0)180) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.smallIncrementKmh > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.smallIncrementKmh < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.bigIncrementKmh > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.bigIncrementKmh < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.smallIncrementMph > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.smallIncrementMph < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.bigIncrementMph > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.bigIncrementMph < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.minSetSpeedKmh > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.maxSetSpeedKmh > (Dt_UINT8_1_0)250) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.minSetSpeedMph > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.velocityControl.maxSetSpeedMph > (Dt_UINT8_1_0)160) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->systemController.countryList.count > (Dt_UINT8_1_0)prmNUMCOUNTRYLIST) { return false; }

	return true;
}
/*lint -restore */

