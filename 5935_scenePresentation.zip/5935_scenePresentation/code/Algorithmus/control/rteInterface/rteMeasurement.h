#ifndef guard_rteMeasurement_h
#define guard_rteMeasurement_h

#include "Rte_Type.h"
#include "control/controlTask/controlTask_interface.h"


void   rteOutConvert_controlMeasurement(IN	const	controlMeasurement_T					*controlMeasurement,
										OUT			Dt_RECORD_Messwert_InnoDriveControl		*recMeasurement);


#endif

