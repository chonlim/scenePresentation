#include "control/rteInterface/rteVZE.h"
#include "control/inputCodec/inputCodec_private.h"


void		  rteInConvert_vzeInput(IN	const	Dt_RECORD_VZE			*recVZE,
									OUT			vzeInput_T				*vzeInput)
{
	vzeInput->DataValidFlag						= true;

	vzeInput->VZE_Anhaenger_Vmax				= recVZE->VZE_Anhaenger_Vmax;
	vzeInput->VZE_Hinweistext					= recVZE->VZE_Hinweistext;
	vzeInput->VZE_Umweltinfo_Anhaengerbetrieb	= recVZE->VZE_Umweltinfo_Anhaengerbetrieb != 0u;
	vzeInput->VZE_Umweltinfo_Naesse				= recVZE->VZE_Umweltinfo_Naesse != 0u;
	vzeInput->VZE_Umweltinfo_Nebel				= recVZE->VZE_Umweltinfo_Nebel != 0u;
	vzeInput->VZE_Verkehrszeichen_1				= recVZE->VZE_Verkehrszeichen_1;
	vzeInput->VZE_Verkehrszeichen_6				= recVZE->VZE_Verkehrszeichen_6;
	vzeInput->VZE_Verkehrszeichen_Einheit		= recVZE->VZE_Verkehrszeichen_Einheit;
	vzeInput->VZE_Zeichen_01_Gesetz				= recVZE->VZE_Zeichen_01_Gesetz != 0u;
	vzeInput->VZE_Zeichen_01_Kamera				= recVZE->VZE_Zeichen_01_Kamera != 0u;
	vzeInput->VZE_Zeichen_01_Karte				= recVZE->VZE_Zeichen_01_Karte != 0u;
	vzeInput->VZE_Zeichen_06_Entfernung			= recVZE->VZE_Zeichen_06_Entfernung;
	vzeInput->VZE_Zusatzschild_6				= recVZE->VZE_Zusatzschild_6;
}
