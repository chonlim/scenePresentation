#include "control/rteInterface/rteTraceDataOut.h"
#include "control/psdWrapper/psdWrapper.h"

void		rteOutConvert_traceData(INOUT		pemControlHeap_T		*controlHeap,
									OUT			Dt_RECORD_TraceData		*recTraceData)
{
	uint8_T i, j;

	traceDataArrayFormat_T arrayFormat;

	trajectory_T const *trajectoryIn = &controlHeap->driverPredictorMemory.debugDriverPrediction.trajectory;

	getTraceDataFormat(&arrayFormat);

	if (arrayFormat.trajectoryPos + arrayFormat.trajectoryOutSize <= sizeof(recTraceData->DeData)) {
		switch (controlHeap->dprdDebugBuffer.trajectoryMuxId)
		{
		case (uint8_T)PIF_Identifier_Geschwindigkeit:
			j = 0;

			for (i = 0u; i < 31u; i += 3u)
			{ /* Trajektorien f�r die Ausgabe ausd�nnen (jeder f�nfte Wert) */
				if (j < dprdTHINNEDTRAJECTORY_COUNT)
				{
					controlHeap->dprdDebugBuffer.trajectoryVelocityOut[j] = trajectoryIn->vector[i].velocity;
					controlHeap->dprdDebugBuffer.trajectoryLonAccelOut[j] = trajectoryIn->vector[i].longAcceleration;
					controlHeap->dprdDebugBuffer.trajectoryWhlPowerOut[j] = trajectoryIn->vector[i].wheelPower;
					controlHeap->dprdDebugBuffer.trajectoryLatAccelOut[j] = trajectoryIn->vector[i].latAcceleration;
					controlHeap->dprdDebugBuffer.trajectoryPositionOut[j] = trajectoryIn->vector[i].position;
					j++;
				}
			}
			/* Geschwindigkeitstrajektorie m�sste nicht im Heap zwischengespeichert werden, da sie ja direkt ausgegeben wird */
			memcpy(&recTraceData->DeData[arrayFormat.trajectoryPos], controlHeap->dprdDebugBuffer.trajectoryVelocityOut, arrayFormat.trajectoryOutSize);
			controlHeap->dprdDebugBuffer.trajectoryMuxId = (uint8_T)PIF_Identifier_Laengsbeschleunigung;
			break;
		case (uint8_T)PIF_Identifier_Laengsbeschleunigung:
			memcpy(&recTraceData->DeData[arrayFormat.trajectoryPos], controlHeap->dprdDebugBuffer.trajectoryLonAccelOut, arrayFormat.trajectoryOutSize);
			controlHeap->dprdDebugBuffer.trajectoryMuxId = (uint8_T)PIF_Identifier_Leistung;
			break;
		case (uint8_T)PIF_Identifier_Leistung:
			memcpy(&recTraceData->DeData[arrayFormat.trajectoryPos], controlHeap->dprdDebugBuffer.trajectoryWhlPowerOut, arrayFormat.trajectoryOutSize);
			controlHeap->dprdDebugBuffer.trajectoryMuxId = (uint8_T)PIF_Identifier_Querbeschleunigung;
			break;
		case (uint8_T)PIF_Identifier_Querbeschleunigung:
			memcpy(&recTraceData->DeData[arrayFormat.trajectoryPos], controlHeap->dprdDebugBuffer.trajectoryLatAccelOut, arrayFormat.trajectoryOutSize);
			controlHeap->dprdDebugBuffer.trajectoryMuxId = (uint8_T)PIF_Identifier_Strassenklasse;
			break;
		case (uint8_T)PIF_Identifier_Strassenklasse:
			memcpy(&recTraceData->DeData[arrayFormat.trajectoryPos], controlHeap->dprdDebugBuffer.trajectoryPositionOut, arrayFormat.trajectoryOutSize);
			controlHeap->dprdDebugBuffer.trajectoryMuxId = (uint8_T)PIF_Identifier_Geschwindigkeit;
			break;
		default:
			controlHeap->dprdDebugBuffer.trajectoryMuxId = (uint8_T)PIF_Identifier_Geschwindigkeit;
			break;
		}
	}
	
	if (arrayFormat.dynamicSetListPos + arrayFormat.dynamicSetListSize <= sizeof(recTraceData->DeData)) {
		memcpy(&recTraceData->DeData[arrayFormat.dynamicSetListPos], &controlHeap->driverState.dynamicSetList, arrayFormat.dynamicSetListSize);
	}
	if (arrayFormat.environmentStatePos + arrayFormat.environmentStateSize <= sizeof(recTraceData->DeData)) {
		memcpy(&recTraceData->DeData[arrayFormat.environmentStatePos], &controlHeap->driverState.environmentState, arrayFormat.environmentStateSize);
	}
	if (arrayFormat.desiredSpeedPos + arrayFormat.desiredSpeedSize <= sizeof(recTraceData->DeData)) {
		memcpy(&recTraceData->DeData[arrayFormat.desiredSpeedPos], &controlHeap->driverState.velocitySet.desiredSpeed.value, arrayFormat.desiredSpeedSize);
	}
	if (arrayFormat.maxVelocityPos + arrayFormat.maxVelocitySize <= sizeof(recTraceData->DeData)) {
		memcpy(&recTraceData->DeData[arrayFormat.maxVelocityPos], &controlHeap->driverState.maxVelocity, arrayFormat.maxVelocitySize);
	}
	if (arrayFormat.nextLimitInfoPos + arrayFormat.nextLimitInfoSize <= sizeof(recTraceData->DeData)) {
		memcpy(&recTraceData->DeData[arrayFormat.nextLimitInfoPos], &controlHeap->driverState.nextLimitInfo, arrayFormat.nextLimitInfoSize);
	}
	if (arrayFormat.trajectoryMuxIdPos + arrayFormat.trajectoryMuxIdSize <= sizeof(recTraceData->DeData)) {
		memcpy(&recTraceData->DeData[arrayFormat.trajectoryMuxIdPos], &controlHeap->dprdDebugBuffer.trajectoryMuxId, arrayFormat.trajectoryMuxIdSize);
	}
	if (arrayFormat.rglStatusPos + arrayFormat.rglStatusSize <= sizeof(recTraceData->DeData)) {
		psdStatus_T ehrStatus;
		if(psdwGetQuality(&ehrStatus)) {
			recTraceData->DeData[arrayFormat.rglStatusPos]=ehrStatus;
		}
		else {
			recTraceData->DeData[arrayFormat.rglStatusPos]=INVALID_UINT8;
		}
	}
}

#ifndef INNODRIVE_ZFAS_SWC_BUILD
void		 rteInConvert_traceData(IN			Dt_RECORD_TraceData				*recTraceData,
									OUT			driverState_T					*driverState,
									OUT			driverPredictorDebugBuffer_T	*dprdDebugBuffer)
{

	traceDataArrayFormat_T arrayFormat;

	getTraceDataFormat(&arrayFormat);

	memcpy(&dprdDebugBuffer->trajectoryMuxId, &recTraceData->DeData[arrayFormat.trajectoryMuxIdPos], arrayFormat.trajectoryMuxIdSize);


	if (arrayFormat.trajectoryPos + arrayFormat.trajectoryOutSize <= sizeof(recTraceData->DeData)) {
		switch (dprdDebugBuffer->trajectoryMuxId)
		{
		case (uint8_T)PIF_Identifier_Geschwindigkeit:
			/* Geschwindigkeitstrajektorie m�sste nicht im Heap zwischengespeichert werden, da sie ja direkt ausgegeben wird */
			memcpy(dprdDebugBuffer->trajectoryVelocityOut, &recTraceData->DeData[arrayFormat.trajectoryPos], arrayFormat.trajectoryOutSize);
			break;
		case (uint8_T)PIF_Identifier_Laengsbeschleunigung:
			memcpy(dprdDebugBuffer->trajectoryLonAccelOut, &recTraceData->DeData[arrayFormat.trajectoryPos], arrayFormat.trajectoryOutSize);
			break;
		case (uint8_T)PIF_Identifier_Leistung:
			memcpy(dprdDebugBuffer->trajectoryWhlPowerOut, &recTraceData->DeData[arrayFormat.trajectoryPos], arrayFormat.trajectoryOutSize);
			break;
		case (uint8_T)PIF_Identifier_Querbeschleunigung:
			memcpy(dprdDebugBuffer->trajectoryLatAccelOut, &recTraceData->DeData[arrayFormat.trajectoryPos], arrayFormat.trajectoryOutSize);
			break;
		case (uint8_T)PIF_Identifier_Strassenklasse:
			memcpy(dprdDebugBuffer->trajectoryPositionOut, &recTraceData->DeData[arrayFormat.trajectoryPos], arrayFormat.trajectoryOutSize);
			break;
		default:
			break;
		}
	}

	if (arrayFormat.dynamicSetListPos + arrayFormat.dynamicSetListSize <= sizeof(recTraceData->DeData)) {
		memcpy(&driverState->dynamicSetList, &recTraceData->DeData[arrayFormat.dynamicSetListPos], arrayFormat.dynamicSetListSize);
	}
	if (arrayFormat.environmentStatePos + arrayFormat.environmentStateSize <= sizeof(recTraceData->DeData)) {
	memcpy(&driverState->environmentState, &recTraceData->DeData[arrayFormat.environmentStatePos], arrayFormat.environmentStateSize);
	}
	if (arrayFormat.desiredSpeedPos + arrayFormat.desiredSpeedSize <= sizeof(recTraceData->DeData)) {
	memcpy(&driverState->velocitySet.desiredSpeed.value, &recTraceData->DeData[arrayFormat.desiredSpeedPos], arrayFormat.desiredSpeedSize);
	}
	if (arrayFormat.maxVelocityPos + arrayFormat.maxVelocitySize <= sizeof(recTraceData->DeData)) {
	memcpy(&driverState->maxVelocity, &recTraceData->DeData[arrayFormat.maxVelocityPos], arrayFormat.maxVelocitySize);
	}
	if (arrayFormat.nextLimitInfoPos + arrayFormat.nextLimitInfoSize <= sizeof(recTraceData->DeData)) {
		memcpy(&driverState->nextLimitInfo, &recTraceData->DeData[arrayFormat.nextLimitInfoPos], arrayFormat.nextLimitInfoSize);
	}

}
#endif

static void getTraceDataFormat(OUT traceDataArrayFormat_T *traceDataArrayFormat)
{
	traceDataArrayFormat->dynamicSetListPos = 0;
	traceDataArrayFormat->dynamicSetListSize = sizeof(dynamicSetList_T); /* 168 Bytes */

	traceDataArrayFormat->environmentStatePos = traceDataArrayFormat->dynamicSetListPos + traceDataArrayFormat->dynamicSetListSize;
	traceDataArrayFormat->environmentStateSize = sizeof(environmentState_T); /* 16 Bytes */

	traceDataArrayFormat->desiredSpeedPos = traceDataArrayFormat->environmentStatePos + traceDataArrayFormat->environmentStateSize;
	traceDataArrayFormat->desiredSpeedSize = sizeof(real32_T); /* 4 Bytes */

	traceDataArrayFormat->maxVelocityPos = traceDataArrayFormat->desiredSpeedPos + traceDataArrayFormat->desiredSpeedSize;
	traceDataArrayFormat->maxVelocitySize = sizeof(maxVelocity_T); /* 8 Bytes */

	traceDataArrayFormat->nextLimitInfoPos = traceDataArrayFormat->maxVelocityPos + traceDataArrayFormat->maxVelocitySize;
	traceDataArrayFormat->nextLimitInfoSize = sizeof(dobsNextLimitInfo_T); /* 12 Bytes */

	traceDataArrayFormat->trajectoryPos = traceDataArrayFormat->nextLimitInfoPos + traceDataArrayFormat->nextLimitInfoSize;
	traceDataArrayFormat->trajectoryOutSize = (size_t)dprdTHINNEDTRAJECTORY_COUNT * sizeof(real32_T); /* 44 Bytes */

	traceDataArrayFormat->trajectoryMuxIdPos = traceDataArrayFormat->trajectoryPos + traceDataArrayFormat->trajectoryOutSize;
	traceDataArrayFormat->trajectoryMuxIdSize = sizeof(uint8_T); /* 1 Byte */

	/* insgesamt 253 Bytes */

	/* Try to set rgl status position to last position of TraceDataArray.
	 * If position is larger than sizeof(Array), then no data will be
	 * written (this is checked in rteOutConvert_traceData)
	 */
	traceDataArrayFormat->rglStatusPos = max(sizeof(((Dt_RECORD_TraceData*)(0))->DeData) - 1u,
		traceDataArrayFormat->trajectoryMuxIdPos + traceDataArrayFormat->trajectoryMuxIdSize);
	traceDataArrayFormat->rglStatusSize = sizeof(uint8_T); /* 1 Byte */
}
