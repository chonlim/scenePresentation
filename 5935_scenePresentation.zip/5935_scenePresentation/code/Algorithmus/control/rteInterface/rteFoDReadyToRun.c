#include "control/rteInterface/rteFoDReadyToRun.h"
#include "common/systemControllerCommon/systemController_private.h"


void			rteOutConvert_fodOutput(IN	const	fodOutput_T					*fodOutput,
										OUT			Dt_RECORD_FoDReadyToRun		*recFoDReadyToRun)
{
	Dt_RECORD_Timestamp innodriveControlOutTimestamp;
	uint32_T uiPemControlTimeHigh = 0;
	uint32_T uiPemControlTimeLow = 0;

	innodriveControlOutTimestamp.DeTimestampHigh = 0;
	innodriveControlOutTimestamp.DeTimestampLow = 0;

	recFoDReadyToRun->DeFoDReadyToRun = fodOutput->DeFoDReadyToRun;

	recFoDReadyToRun->DeTimestamp.DeTimestampMW_TX.DeTimestampHigh = uiPemControlTimeHigh;
	recFoDReadyToRun->DeTimestamp.DeTimestampMW_TX.DeTimestampLow = uiPemControlTimeLow;
	recFoDReadyToRun->DeTimestamp.DeTimestampMW_RX.DeTimestampHigh = 0xFF;
	recFoDReadyToRun->DeTimestamp.DeTimestampMW_RX.DeTimestampLow = 0x00;
	recFoDReadyToRun->DeTimestamp.DeTimestampZGT.DeTimestampHigh = innodriveControlOutTimestamp.DeTimestampHigh;
	recFoDReadyToRun->DeTimestamp.DeTimestampZGT.DeTimestampLow = innodriveControlOutTimestamp.DeTimestampLow;
}
