#ifndef guard_rtePemCtrlIntf_h
#define guard_rtePemCtrlIntf_h

#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"
#else
#include "Rte_Type.h"
#endif

#include "common/common.h"
#include "control/controlTask/controlTask_interface.h"


typedef struct {
	portState_T		FRInnoDriveIn;
	portState_T		pemPlanning;
	portState_T		EML;
	portState_T		VZE;
	portState_T		OBF;
	portState_T		Lanes;
	portState_T		FRRGout;
	portState_T		FoDFunctionActivationState;
} controlPortStates_T;


void		rtePushVehicleModelCtrl(const	Dt_RECORD_InnoDriveControlVehicleModel		*recVehicleModel);


bool_T	 rteIsVehicleModelCtrlValid(void);


void		rtePushParameterSetCtrl(const	Dt_RECORD_InnoDriveControlParameterSetCtrl	*recParameterSetCtrl);


bool_T	 rteIsParameterSetCtrlValid(void);

/**\brief Umwandlung von RTE-Signale zu ID2-Datenstrukturen und vis versa

In_1. 
Die Funktion rteRunControl muss die im System Innodrive2 verwendeten Signale 1:1 aus den RTE-Signalen kopieren. 
Die verwendeten Signale werden in der Schnittstellenspezifikation inputCodec.ifxml aufgelistet.

In_2. 
Zus�tzlich muss die Funktion rteRunControl f�r jede Signalgruppe (Flexray, EML, VZE, ...) je eine "DataValidFlag" bereitstellen, 
welche bei Einlesefehlern oder von der RTE als ung�ltig markierten Signalen auf FALSE gesetzt wird, 
bei erfolgreichem Einlesen der Signale auf TRUE.

In_3.
Im Fall DataValidFlag == FALSE muss die Funktion rteRunControl alle Signale der Signalgruppe auf Null setzen.

Out_1.
Die Funktion rteRunControl muss die von der Innodrive2 Funktion (iccRunControl) berechneten Werte in die zugeh�rigen RTE-Signale umwandeln.
F�r den FlexrayOutput m�ssen die Werte aus der Datenstruktur flexrayOutput_T in die Datenstruktur Dt_RECORD_FRInnoDriveOut umgewandelt werden.
Die Namen der Attribute deckt sich mit in den jeweiligen Datenstrukturen mit Ausnahme von folgender Zuordnung:
Dt_BOOL DePACC02_Offset_aktiv = DePACC02_Offset_aktiv statt DePACC02_Offset_Aktiv

Out_2.
Die verwendeten Signale werden in der Schnittstellenspezifikation outputCodec.ifxml aufgelistet. 
Die angegbenen Signalbereich (Min/Max/Init) muss �bertragen werden k�nnen.


TODO: Anforderung f�r:
		UINT_GAP_8 PaddingGap8_1;
		Dt_RECORD_TimestampMid DeTimestamp;
		Dt_UINT8_1_0 DePACC02_Segelanteil;

NOTE: dataValidFlag entf�llt


\spec SW_FE_Innodrive2_71
\spec SW_FE_Innodrive2_73
\spec SW_FE_Innodrive2_66

\ingroup inputCodec
*/
void				  rteRunControl(INOUT		pemControlHeap_T						*controlHeap,
									IN	const	controlPortStates_T						*portStates,
									IN	const	Dt_RECORD_FRInnoDriveIn					*recFRInnoDriveIn,
									IN	const	Dt_RECORD_PemPlanning					*recPemPlanning,
									IN	const	Dt_RECORD_EML							*recEML,
									IN	const	Dt_RECORD_VZE							*recVZE,
									IN	const	Dt_RECORD_ObjectListOBFLightOut			*recOBF,
									IN	const	Dt_RECORD_GeometryLanes					*recRGLanes,
									IN	const	Dt_RECORD_FRRGout						*recFRRGout,
									IN	const	Dt_RECORD_FoDFunctionActivationState	*recFoDFunctionActivationState,
									IN	const	Dt_RECORD_Diag_Coding					*recDiagCoding,
									OUT			Dt_RECORD_FRInnoDriveOut				*recFRInnoDriveOut,
									OUT			Dt_RECORD_FoDReadyToRun					*recFoDReadyToRun,
									OUT			Dt_RECORD_TraceData						*recTraceData,
									OUT			Dt_RECORD_PemControl					*recPemControl,
									OUT			Dt_RECORD_Messwert_InnoDriveControl		*recMeasurement,
									OUT			checkState_T							*checkState);

#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
static bool_T diff_array(char* diff_dest, const char* src, const char* ref, size_t size);
#endif

#endif
