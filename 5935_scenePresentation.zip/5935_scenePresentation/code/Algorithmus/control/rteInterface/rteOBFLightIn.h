#ifndef guard_rteOBFLightIn_h
#define guard_rteOBFLightIn_h

#include "Rte_Type.h"
#include "control/controlTask/controlTask_interface.h"


bool_T		  rteInConvert_obfInput(IN	const	Dt_RECORD_ObjectListOBFLightOut		*recObjectOBFLout,
									OUT			obfInput_T							*obfInput);


#endif

