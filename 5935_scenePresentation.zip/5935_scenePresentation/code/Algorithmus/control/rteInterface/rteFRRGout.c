#include "control/rteInterface/rteFRRGout.h"
#include "control/inputCodec/inputCodec_private.h"


void		  rteInConvert_lapInput(IN	const	Dt_RECORD_FRRGout		*recFRRGout,
									OUT			lapInput_T				*lapInput)
{
	lapInput->DataValidFlag				= true;

	lapInput->DeSDF2_Pos_AnzHauptspuren	= recFRRGout->DeFRRGout.DeSDF2_Pos_AnzHauptspuren;
	lapInput->DeSDF2_Pos_Spurnummer		= recFRRGout->DeFRRGout.DeSDF2_Pos_Spurnummer;
	lapInput->DeSDF2_Pos_Spurtype		= recFRRGout->DeFRRGout.DeSDF2_Pos_Spurtype;
}
