
#include "control/rteInterface/rteRGExtPSD.h"


/*lint -esym(759,convertRteRGExtPSDTovehicleInput)*/
/*lint -esym(765,convertRteRGExtPSDTovehicleInput)*/
/*lint -esym(714,convertRteRGExtPSDTovehicleInput)*/
bool_T	convertRteRGExtPSDTovehicleInput(const	Dt_RECORD_RGExtractorPSD	*recRGExtPSD)
{
	if (NULL != recRGExtPSD){;}	 /*Unterdr�ckt warning C4199 unreferenced formal parameter*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeBridge = recRGExtPSD.DeBridge; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeConstructionArea = recRGExtPSD.DeConstructionArea; *//*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeCountryCode = recRGExtPSD.DeCountryCode; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeDistCrossing = recRGExtPSD.DeDistCrossing; */ /*Routing PSD 1.5.2 */

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeDistRoundabout = recRGExtPSD.DeDistRoundabout; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeNumberLanes = recRGExtPSD.DeNumberLanes; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DePlaceNameSign = recRGExtPSD.DePlaceNameSign; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeRamp = recRGExtPSD.DeRamp; */ /*Routing PSD 1.5.2;*/

	/* [Min]Dt_ENUM_TrafficDirection_LowerLimit[/Min]                                              */
	/* [Max]Dt_ENUM_TrafficDirection_UpperLimit[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/*if (recRGExtPSD.DeRightHandTraffic >= Dt_ENUM_TrafficDirection_LowerLimit && recRGExtPSD.DeRightHandTraffic <= Dt_ENUM_TrafficDirection_UpperLimit) */

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/*recRGExtPSD.DeStatus >= Dt_ENUM_RGExtractorPSD_LowerLimit && recRGExtPSD.DeStatus <= Dt_ENUM_RGExtractorPSD_UpperLimit)*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeStreetClass = recRGExtPSD.DeStreetClass; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeStreetClassAhead = recRGExtPSD.DeStreetClassAhead; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeTunnel = recRGExtPSD.DeTunnel; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/*for (uint16_T uiIdx = 0; uiIdx < sizeof(recRGExtPSD.DeUpdateData) / sizeof(recRGExtPSD.DeUpdateData[0]); uiIdx++)
	{
		if (recRGExtPSD.DeUpdateData >= 0 && recRGExtPSD.DeUpdateData <= 255)
		{
			;
		}
		else
		{
			Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeUpdateData out of range. DeUpdateData = %i ", recRGExtPSD.DeUpdateData);
		}
	}*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeUpdateState = recRGExtPSD.DeUpdateState; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/* vehicleInput->DeUrbanArea = recRGExtPSD.DeUrbanArea; */ /*Routing PSD 1.5.2;*/

	/* [Min]0[/Min]                                              */
	/* [Max]255[/Max]                                            */
	/* [Init][/Init]                                             */
	/* [Unit][/Unit]                                             */
	/* [Accuracy]1[/Accuracy]                                    */
	/*for (uint16_T uiIdx = 0; uiIdx < sizeof(recRGExtPSD.DeVZFSign) / sizeof(recRGExtPSD.DeVZFSign[0]); uiIdx++)
	{
		if (recRGExtPSD.DeVZFSign >= 0 && recRGExtPSD.DeVZFSign <= 64)
		{
			; Routing PSD 1.5.2
		}
		else
		{
			Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeVZFSign out of range. DeVZFSign = %i ", recRGExtPSD.DeVZFSign);
		}
	}*/

	return true;
}
