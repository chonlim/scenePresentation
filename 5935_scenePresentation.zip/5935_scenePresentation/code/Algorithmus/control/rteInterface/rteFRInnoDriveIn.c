#include "Log.h"
#include "Rte_Type.h"
#include "BusSignals_status.h"

#include "control/inputCodec/inputCodec_private.h"
#include "control/rteInterface/rteInterface.h"
#include "control/rteInterface/rteFRInnoDriveIn.h"


#define	defIFVERSION (100*IFSET_VERSION_VARIANT + 10*IFSET_VERSION_MAJOR + IFSET_VERSION_MINOR)


typedef enum eRteFRState
{
	ePDUValid = 0,
	ePDUValidNotUpdated = 1,
	ePDUDTCSet = 2,
	/* ePDUSignalInit = 3, */
	/* ePDUSignalError = 4, */
	/* ePDUSignalOutOfRange = 5, */
	ePDUError = 6
}eRteFRState_t;


static bool_T rteFlexrayPduStateHandler(uint8_T uiPDUState, eRteFRState_t* intError);

/*! \brief Flexray communication handler.


The delivered PduState is checked in this handler 
*/
/*lint -save */
/*lint -e774	(Info -- Boolean within 'left side of && within left side of && within if' always evaluates to True MISRA 2012 Rule 14.3, required])*/
static bool_T rteFlexrayPduStateHandler(uint8_T uiPDUState, eRteFRState_t* intError)
{
	bool_T b_Ret;
	uint8 pdu_state, dtc /*, e2e_state*/;
	eRteFRState_t error = ePDUValid;

	/* get receive status for the PDU containing signal EPS_Zahnstangen_Pos,*/
#ifdef ZFAS_SIL_SWC_BUILD
	/* zFAS x09x documentation / User Guide SiL / SiL Platform Environment / ADTF Filter / TTTech SW-C Filter / CtApCom_in_ADTF / FlexRay Config Codec
	* In it�s crrent version the CtApCom Filter does not provide valid PDU Status information.
	* Therefore, please exclude logic that performs E2E protection checks from compilation when
	* building your SWC for SiL, by using the preprocessor symbol ZFAS_SIL_SWC_BUILD as shown by
	* the example below. As Defined within the Userconfig.ini, it�s automatically defined when
	* building your SWC for SiL using Fast Project.
	*/
	/*e2e_state = (uint8_T)E2ESTATE_NORMAL;*/
#else
	/*Similar to the PDU status the name of an E2E - status consists of :
		A prefix DeE2EStatus_ uncomment if the DeE2eStatus exist. At the moment 30.01.2017 we dont't get it JJS */
	/*e2e_state = GET_E2ESTATE(uiPDUState);*/
	/*e2e_state = (uint8_T)E2ESTATE_NORMAL;*/
#endif
	pdu_state = GET_PDUSTATE(uiPDUState);
	dtc = GET_PDUDTC(uiPDUState);

	if (/*e2e_state == (uint8_T)E2ESTATE_NORMAL &&*/
		pdu_state == (uint8_T)PDUSTATE_IS_UPDATED &&
			  dtc == (uint8_T)0)
	{
		/* all things are ok the signal is valid */
		error = ePDUValid;
		b_Ret = true;
	}
	else if (/*e2e_state == (uint8_T)E2ESTATE_NORMAL &&*/
			 pdu_state == (uint8_T)PDUSTATE_NOT_UPDATED &&
				   dtc == (uint8_T)0)
	{
		/* Flexray is ok but the value isn't updated */
		error = ePDUValidNotUpdated;
		b_Ret = true;
	}
	else if (dtc == 1u)
	{
		error = ePDUDTCSet;
		b_Ret = false;
	}
	else
	{
		error = ePDUError;
		b_Ret = false;
	}

	*intError = error;
	return b_Ret;
}
/*lint -restore*/

void	  rteInConvert_flexrayInput(IN	const	Dt_RECORD_FRInnoDriveIn		*recFRInnoDriveIn,
									OUT			flexrayInput_T				*flexrayInput)
{
	eRteFRState_t intError = ePDUValid;

	flexrayInput->DataValidFlag = true;

#if defIFVERSION > 203
	flexrayInput->DeHAL_Radwinkel						= (real32_T)recFRInnoDriveIn->DeHAL_Radwinkel;
#else
	flexrayInput->DeHAL_Radwinkel						= INVALID_VALUE;
#endif
	flexrayInput->DeKBI_angez_Geschw					= (real32_T)recFRInnoDriveIn->DeKBI_angez_Geschw;
	flexrayInput->DeKBI_aktive_Laengsfunktion			= (uint8_T)recFRInnoDriveIn->DeKBI_aktive_Laengsfunktion;
	flexrayInput->DeKBI_Einheit_Tacho					= (uint8_T)recFRInnoDriveIn->DeKBI_Einheit_Tacho;
	flexrayInput->DeLWI_Lenkradwinkel					= (real32_T)recFRInnoDriveIn->DeLWI_Lenkradwinkel;
	flexrayInput->DeMO_Fahrpedalrohwert_01				= (real32_T)recFRInnoDriveIn->DeMO_Fahrpedalrohwert_01;
#if defIFVERSION > 203
	flexrayInput->DeSDF1_Obj_01_BeschlRelX				= (real32_T)recFRInnoDriveIn->DeSDF1_Obj_01_BeschlRelX;
#else
	flexrayInput->DeSDF1_Obj_01_BeschlRelX				= 0.0f;
#endif
	flexrayInput->DeSDF1_Obj_01_GeschwRelX				= (real32_T)recFRInnoDriveIn->DeSDF1_Obj_01_GeschwRelX;
	flexrayInput->DeSDF1_Obj_01_PositionX				= (real32_T)recFRInnoDriveIn->DeSDF1_Obj_01_PositionX;
	flexrayInput->DeTSK_Steigung_02						= (real32_T)recFRInnoDriveIn->DeTSK_Steigung_02;
	flexrayInput->DeTSK_vMax_Fahrerassistenz			= (uint16_T)recFRInnoDriveIn->DeTSK_vMax_Fahrerassistenz;
	flexrayInput->DeTSK_Einheit_vMax_Fahrerassistenz	= (uint8_T)recFRInnoDriveIn->DeTSK_Einheit_vMax_Fahrerassistenz;
	flexrayInput->DeLWI_Lenkradw_Geschw					= (uint16_T)recFRInnoDriveIn->DeLWI_Lenkradw_Geschw;
	flexrayInput->DeMO_Mom_Ist_Summe					= (int16_T)recFRInnoDriveIn->DeMO_Mom_Ist_Summe;
	flexrayInput->DeESP_VL_Bremsmoment					= (uint16_T)recFRInnoDriveIn->DeESP_VL_Bremsmoment;
	flexrayInput->DeESP_VR_Bremsmoment					= (uint16_T)recFRInnoDriveIn->DeESP_VR_Bremsmoment;
	flexrayInput->DeESP_HL_Bremsmoment					= (uint16_T)recFRInnoDriveIn->DeESP_HL_Bremsmoment;
	flexrayInput->DeESP_HR_Bremsmoment					= (uint16_T)recFRInnoDriveIn->DeESP_HR_Bremsmoment;
	flexrayInput->DeACC_Gesetzte_Zeitluecke				= (uint8_T)recFRInnoDriveIn->DeACC_Gesetzte_Zeitluecke;
	flexrayInput->DeACC_Status_ACC						= (uint8_T)recFRInnoDriveIn->DeACC_Status_ACC;
	flexrayInput->DeACC_vLimit1_PACC					= (uint8_T)recFRInnoDriveIn->DeACC_vLimit1_PACC;
	flexrayInput->DeCHA_Ziel_FahrPr_PACC				= (uint8_T)recFRInnoDriveIn->DeCHA_Ziel_FahrPr_PACC;
	flexrayInput->DeGE_Fahrstufe						= (uint8_T)recFRInnoDriveIn->DeGE_Fahrstufe;
	flexrayInput->DeGE_Freilauf_Status					= (uint8_T)recFRInnoDriveIn->DeGE_Freilauf_Status;
	flexrayInput->DeGE_Zielgang							= (uint8_T)recFRInnoDriveIn->DeGE_Zielgang;
	flexrayInput->DeMO_Fahrzeugtyp						= (uint8_T)recFRInnoDriveIn->DeMO_Fahrzeugtyp;
	flexrayInput->DeMO_Faktor_Momente_02				= (uint8_T)recFRInnoDriveIn->DeMO_Faktor_Momente_02;
	flexrayInput->DeMO_Code								= (uint8_T)recFRInnoDriveIn->DeMO_Code;
	flexrayInput->DeSDF1_Obj_01_ID						= (uint8_T)recFRInnoDriveIn->DeSDF1_Obj_01_ID;
	flexrayInput->DeTSK_Hauptschalter_GRA_ACC			= (uint8_T)recFRInnoDriveIn->DeTSK_Hauptschalter_GRA_ACC;
	flexrayInput->DeACC_Nutzung_VZ_PACC					= recFRInnoDriveIn->DeACC_Nutzung_VZ_PACC != 0u;
	flexrayInput->DeACC_Regelung_durch_PACC				= recFRInnoDriveIn->DeACC_Regelung_durch_PACC != 0u;
	flexrayInput->DeBM_Autobahn							= recFRInnoDriveIn->DeBM_Autobahn != 0u;
	flexrayInput->DeBM_links							= recFRInnoDriveIn->DeBM_links != 0u;
	flexrayInput->DeBM_rechts							= recFRInnoDriveIn->DeBM_rechts != 0u;
	flexrayInput->DeESP_QBit_HL_Bremsmoment				= recFRInnoDriveIn->DeESP_QBit_HL_Bremsmoment != 0u;
	flexrayInput->DeESP_QBit_HR_Bremsmoment				= recFRInnoDriveIn->DeESP_QBit_HR_Bremsmoment != 0u;
	flexrayInput->DeESP_QBit_VR_Bremsmoment				= recFRInnoDriveIn->DeESP_QBit_VR_Bremsmoment != 0u;
	flexrayInput->DeESP_QBit_VL_Bremsmoment				= recFRInnoDriveIn->DeESP_QBit_VL_Bremsmoment != 0u;
#if defIFVERSION > 253
	/* This is a breaking point: The signal should be part of the "next" IFset. Unless it happens, increase the min. version */
	flexrayInput->DeHAL_QBit_Radwinkel					= recFRInnoDriveIn->DeHAL_QBit_Radwinkel != 0u;
#else
	flexrayInput->DeHAL_QBit_Radwinkel					= true;
#endif
#if defIFVERSION > 203
	flexrayInput->DeHAL_VZ_Radwinkel					= recFRInnoDriveIn->DeHAL_VZ_Radwinkel != 0u;
#else
	flexrayInput->DeHAL_VZ_Radwinkel					= false;
#endif
	flexrayInput->DeGRA_Tip_Hoch						= recFRInnoDriveIn->DeGRA_Tip_Hoch != 0u;
	flexrayInput->DeGRA_Tip_Runter						= recFRInnoDriveIn->DeGRA_Tip_Runter != 0u;
	flexrayInput->DeGRA_Tip_Setzen						= recFRInnoDriveIn->DeGRA_Tip_Setzen != 0u;
	flexrayInput->DeGRA_Tip_Wiederaufnahme				= recFRInnoDriveIn->DeGRA_Tip_Wiederaufnahme != 0u;
	flexrayInput->DeLWI_VZ_Lenkradwinkel				= recFRInnoDriveIn->DeLWI_VZ_Lenkradwinkel != 0u;
	flexrayInput->DeLWI_VZ_Lenkradw_Geschw				= recFRInnoDriveIn->DeLWI_VZ_Lenkradw_Geschw != 0u;
	flexrayInput->DeEM1_MaxDyn_Moment					= (int16_T)recFRInnoDriveIn->DeEM1_MaxDyn_Moment;
	flexrayInput->DeEM1_IstMoment						= recFRInnoDriveIn->DeEM1_IstMoment;
	flexrayInput->DeEM2_IstMoment						= recFRInnoDriveIn->DeEM2_IstMoment;
	flexrayInput->DeMO_HYB_VM_aktiv						= recFRInnoDriveIn->DeMO_HYB_VM_aktiv != 0u;
	flexrayInput->DeCHA_EV_LED							= recFRInnoDriveIn->DeCHA_EV_LED != 0u;

	flexrayInput->DeEFP_NaesseLevel						= recFRInnoDriveIn->DeEFP_NaesseLevel;
	flexrayInput->DeEFP_NaesseLevel_Classifier			= recFRInnoDriveIn->DeEFP_NaesseLevel_Classifier != 0u;
#if defIFVERSION >= 310
	flexrayInput->DeEFP_Fahrbahnreibwert_dyn_Class		= recFRInnoDriveIn->DeEFP_Fahrbahnreibwert_dyn_Class;
	flexrayInput->DeSTP_Status							= recFRInnoDriveIn->DeSTP_Status;
#endif

	flexrayInput->DeStatus_ACC06 = GET_STATUS_DeFRInnoDriveIn_SG_ACC_06(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_ACC06, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state ACC06 error %d  occured", intError);
		flexrayInput->DeStatus_ACC06 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_ACC12 = GET_STATUS_DeFRInnoDriveIn_SG_ACC_12(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_ACC12, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state ACC12 error %d  occured", intError);
		flexrayInput->DeStatus_ACC12 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_ACC16 = GET_STATUS_DeFRInnoDriveIn_SG_ACC_16(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_ACC16, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state ACC16 error %d  occured", intError);
		flexrayInput->DeStatus_ACC16 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Blinkmodi02 = GET_STATUS_DeFRInnoDriveIn_SG_Blinkmodi_02(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Blinkmodi02, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Blinkmodi02 error %d  occured", intError);
		flexrayInput->DeStatus_Blinkmodi02 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Charisma03 = GET_STATUS_DeFRInnoDriveIn_SG_Charisma_03(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Charisma03, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Charisma03 error %d  occured", intError);
		flexrayInput->DeStatus_Charisma03 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Charisma08 = GET_STATUS_DeFRInnoDriveIn_SG_Charisma_08(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Charisma08, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Charisma08 error %d  occured", intError);
		flexrayInput->DeStatus_Charisma08 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_ESP22 = GET_STATUS_DeFRInnoDriveIn_SG_ESP_22(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_ESP22, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state ESP22 error %d  occured", intError);
		flexrayInput->DeStatus_ESP22 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Getriebe11 = GET_STATUS_DeFRInnoDriveIn_SG_Getriebe_11(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Getriebe11, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Getriebe11 error %d  occured", intError);
		flexrayInput->DeStatus_Getriebe11 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Getriebe17 = GET_STATUS_DeFRInnoDriveIn_SG_Getriebe_17(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Getriebe17, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Getriebe17 error %d  occured", intError);
		flexrayInput->DeStatus_Getriebe17 = (uint8_T)ePDUIntInValid;
	}

#if defIFVERSION > 203
	flexrayInput->DeStatus_HAL01 = GET_STATUS_DeFRInnoDriveIn_SG_HAL_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_HAL01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state HAL01 error %d  occured", intError);
		flexrayInput->DeStatus_HAL01 = (uint8_T)ePDUIntInValid;
	}
#else
	flexrayInput->DeStatus_HAL01 = (uint8_T)ePDUIntInValid;
#endif

	flexrayInput->DeStatus_GRAACC01 = GET_STATUS_DeFRInnoDriveIn_SG_GRA_ACC_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_GRAACC01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state GRAACC01 error %d  occured", intError);
		flexrayInput->DeStatus_GRAACC01 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Kombi01 = GET_STATUS_DeFRInnoDriveIn_SG_Kombi_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Kombi01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Kombi01 error %d  occured", intError);
		flexrayInput->DeStatus_Kombi01 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Kombi02 = GET_STATUS_DeFRInnoDriveIn_SG_Kombi_02(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Kombi02, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Kombi02 error %d  occured", intError);
		flexrayInput->DeStatus_Kombi02 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_LWI01 = GET_STATUS_DeFRInnoDriveIn_SG_LWI_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_LWI01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state LWI01 error %d  occured", intError);
		flexrayInput->DeStatus_LWI01 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_MotorCode01 = GET_STATUS_DeFRInnoDriveIn_SG_Motor_Code_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_MotorCode01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state MotorCode01 error %d  occured", intError);
		flexrayInput->DeStatus_MotorCode01 = (uint8_T)ePDUIntInValid;
	}
	
	flexrayInput->DeStatus_Motor11 = GET_STATUS_DeFRInnoDriveIn_SG_Motor_11(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Motor11, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Motor11 error %d  occured", intError);
		flexrayInput->DeStatus_Motor11 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Motor14 = GET_STATUS_DeFRInnoDriveIn_SG_Motor_14(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Motor14, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Motor14 error %d  occured", intError);
		flexrayInput->DeStatus_Motor14 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Motor16 = GET_STATUS_DeFRInnoDriveIn_SG_Motor_16(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Motor16, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Motor16 error %d  occured", intError);
		flexrayInput->DeStatus_Motor16 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Motor18 = GET_STATUS_DeFRInnoDriveIn_SG_Motor_18(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Motor18, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Motor18 error %d  occured", intError);
		flexrayInput->DeStatus_Motor18 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Motor20 = GET_STATUS_DeFRInnoDriveIn_SG_Motor_20(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Motor20, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state Motor20 error %d  occured", intError);
		flexrayInput->DeStatus_Motor20 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Em1Hyb06 = GET_STATUS_DeFRInnoDriveIn_SG_EM1_HYB_06(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Em1Hyb06, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state EM1_HYB_06 error %d  occured", intError);
		flexrayInput->DeStatus_Em1Hyb06 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Em1Hyb12 = GET_STATUS_DeFRInnoDriveIn_SG_EM1_HYB_12(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Em1Hyb12, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state EM1_HYB_12 error %d  occured", intError);
		flexrayInput->DeStatus_Em1Hyb12 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_SDF1Objekt01 = GET_STATUS_DeFRInnoDriveIn_SG_SDF1_Objekt_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_SDF1Objekt01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state SDF1Objekt01 error %d  occured", intError);
		flexrayInput->DeStatus_SDF1Objekt01 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_TSK06 = GET_STATUS_DeFRInnoDriveIn_SG_TSK_06(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_TSK06, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state DeStatus_TSK06 error %d  occured", intError);
		flexrayInput->DeStatus_TSK06 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_TSK08 = GET_STATUS_DeFRInnoDriveIn_SG_TSK_08(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_TSK08, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state DeStatus_TSK08 error %d  occured", intError);
		flexrayInput->DeStatus_TSK08 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_Fahrwerk07 = GET_STATUS_DeFRInnoDriveIn_SG_Fahrwerk_07(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_Fahrwerk07, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state DeStatus_Fahrwerk07 error %d  occured", intError);
		flexrayInput->DeStatus_Fahrwerk07 = (uint8_T)ePDUIntInValid;
	}
	
#if defIFVERSION >= 310
	flexrayInput->DeStatus_CSPH01 = GET_STATUS_DeFRInnoDriveIn_SG_CSPH_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_CSPH01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state DeStatus_CSPH01 error %d  occured", intError);
		flexrayInput->DeStatus_CSPH01 = (uint8_T)ePDUIntInValid;
	}

	flexrayInput->DeStatus_STP01 = GET_STATUS_DeFRInnoDriveIn_SG_STP_01(*recFRInnoDriveIn);
	if (!rteFlexrayPduStateHandler(flexrayInput->DeStatus_STP01, &intError))
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "PDU state DeStatus_STP01 error %d  occured", intError);
		flexrayInput->DeStatus_STP01 = (uint8_T)ePDUIntInValid;
	}
#endif
}

