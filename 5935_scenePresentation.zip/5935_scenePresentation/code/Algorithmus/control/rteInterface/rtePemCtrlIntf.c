/*! \file 
\brief This file contains the rte-calls to get/set data to or from the rte and map the data to the internal structures of the swc.
	   

Details.
*/

#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
#include <Windows.h>
#endif

#include "Log.h"

#include "string.h"
#include "base.h"

#include "control/controlTask/controlTask.h"
#include "control/controlTask/controlTask_private.h"

#include "control/parameterSet/parameterSetCtrl.h"
#include "control/parameterSet/PpDsparameterSetCtrl.h"

#include "common/vehicleModel/PpDsVehicleModel.h"
#include "common/swcCommunication/PpPemControl.h"
#include "common/swcCommunication/PpPemPlanning.h"

#include "control/rteInterface/rteEML.h"
#include "control/rteInterface/rteVZE.h"
#include "control/rteInterface/rteFRInnoDriveIn.h"
#include "control/rteInterface/rteFRInnoDriveOut.h"
#include "control/rteInterface/rteFoDReadyToRun.h"
#include "control/rteInterface/rteTraceDataOut.h"
#include "control/rteInterface/rteRGLanes.h"
#include "control/rteInterface/rtePemCtrlIntf.h"
#include "control/rteInterface/rteOBFLightIn.h"
#include "control/rteInterface/rteFRRGout.h"
#include "control/rteInterface/rteFoDFunctionActivationState.h"
#include "control/rteInterface/rteCoding.h"
#include "control/rteInterface/rteMeasurement.h"


#ifndef _MSC_VER
/* Speicher-Allokation (Start) */
#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
#endif


static struct inputBuffer_tag {
	vehicleModel_T		vehicleModel;
	parameterSetCtrl_T	parameterSetCtrl;

	flexrayInput_T		flexrayInput;
	pemPlanning_T		pemPlanning;
	emlInput_T			emlInput;
	laneInput_T			laneInput;
	vzeInput_T			vzeInput;
	obfInput_T			obfInput;
	lapInput_T			lapInput;
	fodInput_T			fodInput;
	codingInput_T		codingInput;
} inputBuffer;


/* for debugging */
#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
static bool_T               refs_initialized=0;
static vehicleModel_T	    *ref_vehicleModel=0;
static pemPlanning_T	    *ref_pemPlanning=0;
static flexrayInput_T	    *ref_flexrayInput=0;
static emlInput_T		    *ref_emlInput=0;
static vzeInput_T		    *ref_vzeInput=0;
static obfInput_T		    *ref_obfInput=0;
static laneInput_T          *ref_laneInput=0;
static pemControl_T 		*ref_pemControl=0;
static flexrayOutput_T		*ref_flexrayOutput=0;
static pemControlStack_T	*ref_pemControlStack=0;
#endif


#ifndef _MSC_VER
/* Speicher-Allokation (Ende) */
#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
#endif


void		rtePushVehicleModelCtrl(const	Dt_RECORD_InnoDriveControlVehicleModel		*recVehicleModel)
{
	/* vehicleModel-Record konvertieren und im lokalen Buffer ablegen. Falls die Konvertierung "ung�ltig" zur�ckmeldet,
	   setzen wir die lokale vehicleModel-Struktur auf 0/ung�ltig. */
	if(!rteInConvert_vehicleModel(recVehicleModel, &inputBuffer.vehicleModel)) {
		memset(&inputBuffer.vehicleModel, 0, sizeof(inputBuffer.vehicleModel));
		inputBuffer.vehicleModel.valid = false;
	}
	if (!rteCheckBounds_vehicleModel(&inputBuffer.vehicleModel)) {
		memset(&inputBuffer.vehicleModel, 0, sizeof(inputBuffer.vehicleModel));
		inputBuffer.vehicleModel.valid = false;
	}
}


bool_T	 rteIsVehicleModelCtrlValid(void)
{
	return inputBuffer.vehicleModel.valid;
}


void		rtePushParameterSetCtrl(const	Dt_RECORD_InnoDriveControlParameterSetCtrl	*recParameterSetCtrl)
{
	/* parameterSet-Record konvertieren und im lokalen Buffer ablegen. Falls die Konvertierung "ung�ltig" zur�ckmeldet,
	   setzen wir die lokale parameterSet-Struktur auf 0 und die Checksumme auf "ung�ltig". */
	if(!rteInConvert_parameterSetCtrl(recParameterSetCtrl, &inputBuffer.parameterSetCtrl)) {
		memset(&inputBuffer.parameterSetCtrl, 0, sizeof(inputBuffer.parameterSetCtrl));
		inputBuffer.parameterSetCtrl.checksumCrc32 = ~parameterSetCtrlCrc32;
	}
	if (!rteCheckBounds_parameterSetCtrl(&inputBuffer.parameterSetCtrl)) {
		memset(&inputBuffer.parameterSetCtrl, 0, sizeof(inputBuffer.parameterSetCtrl));
		inputBuffer.parameterSetCtrl.checksumCrc32 = ~parameterSetCtrlCrc32;
	}

	prmApplyParameterSetCtrl(&inputBuffer.parameterSetCtrl);
}


bool_T	 rteIsParameterSetCtrlValid(void)
{
	bool_T isInit = prmIsParameterSetCtrlInit();

	return (prmGetParameterSetCtrl()->checksumCrc32 == parameterSetCtrlCrc32) && (isInit);
}


void				  rteRunControl(INOUT		pemControlHeap_T						*controlHeap,
									IN	const	controlPortStates_T						*portStates,
									IN	const	Dt_RECORD_FRInnoDriveIn					*recFRInnoDriveIn,
									IN	const	Dt_RECORD_PemPlanning					*recPemPlanning,
									IN	const	Dt_RECORD_EML							*recEML,
									IN	const	Dt_RECORD_VZE							*recVZE,
									IN	const	Dt_RECORD_ObjectListOBFLightOut			*recOBF,
									IN	const	Dt_RECORD_GeometryLanes					*recRGLanes,
									IN	const	Dt_RECORD_FRRGout						*recFRRGout,
									IN	const	Dt_RECORD_FoDFunctionActivationState	*recFoDFunctionActivationState,
									IN	const	Dt_RECORD_Diag_Coding					*recDiagCoding,
									OUT			Dt_RECORD_FRInnoDriveOut				*recFRInnoDriveOut,
									OUT			Dt_RECORD_FoDReadyToRun					*recFoDReadyToRun,
									OUT			Dt_RECORD_TraceData						*recTraceData,
									OUT			Dt_RECORD_PemControl					*recPemControl,
									OUT			Dt_RECORD_Messwert_InnoDriveControl		*recMeasurement,
									OUT			checkState_T							*checkState)
{
	pemControlStack_T		controlStack;
	controlRteInfo_T		controlRteInfo;
	pemControl_T			pemControl;
	flexrayOutput_T			flexrayOutput;
	fodOutput_T				fodOutput;
	controlMeasurement_T	controlMeasurement;

#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
    vehicleModel_T	diff_vehicleModel;
    pemPlanning_T	diff_pemPlanning;
    flexrayInput_T	diff_flexrayInput;
    emlInput_T		diff_emlInput;
    vzeInput_T		diff_vzeInput;
	obfInput_T		diff_obfInput;
    laneInput_T     diff_laneInput;
    flexrayOutput_T diff_flexrayOutput;
    pemControl_T    diff_pemControl;
    pemControlStack_T    diff_pemControlStack;

    volatile bool_T is_different;
#endif

	if((portStates->EML == portStateValid) && (NULL != recEML)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		rteInConvert_emlInput(recEML, &inputBuffer.emlInput);
	}
	else if((portStates->EML == portStateInvalid) || (portStates->EML == portStateUnknown)) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.emlInput, 0, sizeof(inputBuffer.emlInput));
	}
	else if(portStates->EML == portStateNoUpdate) {
		/* ...andernfalls halten wir die aktuellen Daten... */
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}


	if((portStates->VZE == portStateValid) && (NULL != recVZE)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		rteInConvert_vzeInput(recVZE, &inputBuffer.vzeInput);
	}
	else if(portStates->VZE == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.vzeInput, 0, sizeof(inputBuffer.vzeInput));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}


	if((portStates->OBF == portStateValid) && (NULL != recOBF)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		if(!rteInConvert_obfInput(recOBF, &inputBuffer.obfInput)) {
			memset(&inputBuffer.obfInput, 0, sizeof(inputBuffer.obfInput));
		}
	}
	else if(portStates->OBF == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.obfInput, 0, sizeof(inputBuffer.obfInput));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}


	if((portStates->FRInnoDriveIn == portStateValid) && (NULL != recFRInnoDriveIn)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		rteInConvert_flexrayInput(recFRInnoDriveIn, &inputBuffer.flexrayInput);
	}
	else if(portStates->FRInnoDriveIn == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.flexrayInput, 0, sizeof(inputBuffer.flexrayInput));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}


	if((portStates->pemPlanning == portStateValid) && (NULL != recPemPlanning)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		if(!rteInConvert_pemPlanning(recPemPlanning, &inputBuffer.pemPlanning)) {
			memset(&inputBuffer.pemPlanning, 0, sizeof(inputBuffer.pemPlanning));
		}
	}
	else if(portStates->pemPlanning == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.pemPlanning, 0, sizeof(inputBuffer.pemPlanning));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}

	if((portStates->Lanes == portStateValid) && (NULL != recRGLanes)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		rteInConvert_laneInput(recRGLanes, &inputBuffer.laneInput);
	}
	else if(portStates->Lanes == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.laneInput, 0, sizeof(inputBuffer.laneInput));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}

	
	if((portStates->FRRGout == portStateValid) && (NULL != recFRRGout)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		rteInConvert_lapInput(recFRRGout, &inputBuffer.lapInput);
	}
	else if(portStates->FRRGout == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.lapInput, 0, sizeof(inputBuffer.lapInput));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}


	if((portStates->FoDFunctionActivationState == portStateValid) && (NULL != recFoDFunctionActivationState)) {
		/* Wenn g�ltige und aktualisierte Daten von der RTE vorliegen, werden sie konvertiert... */
		rteInConvert_fodInput(recFoDFunctionActivationState, &inputBuffer.fodInput);
	}
	else if(portStates->FoDFunctionActivationState == portStateInvalid) {
		/* ...wenn die Daten explizit ung�ltig sind, setzen wir die Struktur auf 0... */
		memset(&inputBuffer.fodInput, 0, sizeof(inputBuffer.fodInput));
	}
	else {
		/* ...andernfalls halten wir die aktuellen Daten. */
	}
	
	rteInConvert_codingInput(recDiagCoding, &inputBuffer.codingInput);


	/* Port-States in der controlRteInfo-Struktur setzen */
	controlRteInfo.portStates.emlInput		= portStates->EML;
	controlRteInfo.portStates.vzeInput		= portStates->VZE;
	controlRteInfo.portStates.flexrayInput	= portStates->FRInnoDriveIn;
	controlRteInfo.portStates.pemPlanning	= portStates->pemPlanning;
	controlRteInfo.portStates.laneInput		= portStates->Lanes;
	controlRteInfo.portStates.lapInput		= portStates->FRRGout;
	controlRteInfo.portStates.fodInput		= portStates->FoDFunctionActivationState;


#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
    if(!refs_initialized){
        HINSTANCE hLib;
        if( (hLib=LoadLibrary("adtfContainer.plb")) != NULL){
            FARPROC tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_vehicleModel"))!=NULL)
                ref_vehicleModel=*(vehicleModel_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_pemPlanning"))!=NULL)
                ref_pemPlanning=*(pemPlanning_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_flexrayInput"))!=NULL)
                ref_flexrayInput=*(flexrayInput_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_emlInput"))!=NULL)
                ref_emlInput=*(emlInput_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_vzeInput"))!=NULL)
                ref_vzeInput=*(vzeInput_T**)(void*)tmp_ptr;
			if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_obfInput"))!=NULL)
				ref_obfInput=*(obfInput_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_laneInput"))!=NULL)
                ref_laneInput=*(laneInput_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_pemControl"))!=NULL)
                ref_pemControl=*(pemControl_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_flexrayOutput"))!=NULL)
                ref_flexrayOutput=*(flexrayOutput_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_ref_pemControlStack"))!=NULL)
                ref_pemControlStack=*(pemControlStack_T**)(void*)tmp_ptr;
            if( (tmp_ptr=GetProcAddress(hLib,"ID2_RP_ctrl_references_initialized"))!=NULL)
                refs_initialized=*(bool_T*)(void*)tmp_ptr;
            FreeLibrary(hLib);
        }

    }

    /* cleanup differences*/
    if(ref_vehicleModel!=NULL){
        ((char*)&inputBuffer.vehicleModel)[1]   =((char*)ref_vehicleModel)[1];
        ((char*)&inputBuffer.vehicleModel)[2]   =((char*)ref_vehicleModel)[2];
        ((char*)&inputBuffer.vehicleModel)[3]   =((char*)ref_vehicleModel)[3];
        ((char*)&inputBuffer.vehicleModel)[21]  =((char*)ref_vehicleModel)[21];
        ((char*)&inputBuffer.vehicleModel)[22]  =((char*)ref_vehicleModel)[22];
        ((char*)&inputBuffer.vehicleModel)[23]  =((char*)ref_vehicleModel)[23];
        ((char*)&inputBuffer.vehicleModel)[2229]=((char*)ref_vehicleModel)[2229];
        ((char*)&inputBuffer.vehicleModel)[2230]=((char*)ref_vehicleModel)[2230];
        ((char*)&inputBuffer.vehicleModel)[2231]=((char*)ref_vehicleModel)[2231];
        inputBuffer.vehicleModel.checksumCrc32 = ref_vehicleModel->checksumCrc32;
        }
    if(ref_flexrayInput!=NULL){
        ((char*)&inputBuffer.flexrayInput)[1]   =((char*)ref_flexrayInput)[1];
        ((char*)&inputBuffer.flexrayInput)[2]   =((char*)ref_flexrayInput)[2];
        ((char*)&inputBuffer.flexrayInput)[3]   =((char*)ref_flexrayInput)[3];
    }
    if(ref_emlInput!=NULL){
        ((char*)&inputBuffer.emlInput)[1]   =((char*)ref_emlInput)[1];
        ((char*)&inputBuffer.emlInput)[2]   =((char*)ref_emlInput)[2];
        ((char*)&inputBuffer.emlInput)[3]   =((char*)ref_emlInput)[3];
    }
	if (ref_obfInput != NULL){
		int i;
		*((char*)&inputBuffer.obfInput.count + 1) = *((char*)&ref_obfInput->count + 1);
		*((char*)&inputBuffer.obfInput.count + 2) = *((char*)&ref_obfInput->count + 2);
		*((char*)&inputBuffer.obfInput.count + 3) = *((char*)&ref_obfInput->count + 3);
		for (i = 0; i<20; ++i){
			/* adjustment due to DataValidFlag (1 byte) before float32 values */
			*((char*)&inputBuffer.obfInput.objects[i].DataValidFlag + 1) = *((char*)&ref_obfInput->objects[i].DataValidFlag + 1);
			*((char*)&inputBuffer.obfInput.objects[i].DataValidFlag + 2) = *((char*)&ref_obfInput->objects[i].DataValidFlag + 2);
			*((char*)&inputBuffer.obfInput.objects[i].DataValidFlag + 3) = *((char*)&ref_obfInput->objects[i].DataValidFlag + 3);
			*((char*)&inputBuffer.obfInput.objects[i].DeClass + 1) = *((char*)&ref_obfInput->objects[i].DeClass + 1);
			*((char*)&inputBuffer.obfInput.objects[i].DeClass + 2) = *((char*)&ref_obfInput->objects[i].DeClass + 2);
			*((char*)&inputBuffer.obfInput.objects[i].DeClass + 3) = *((char*)&ref_obfInput->objects[i].DeClass + 3);
		}
	}

    if (ref_flexrayInput != NULL){
        /* temporarily ignore differences of HAL input signals */
        inputBuffer.flexrayInput.DeHAL_QBit_Radwinkel     = ref_flexrayInput->DeHAL_QBit_Radwinkel;
    }

    /* determine real differences*/
    is_different=diff_array((char*)&diff_vehicleModel,      (char*)&inputBuffer.vehicleModel,     (char*)ref_vehicleModel,    sizeof(vehicleModel_T)-4);
    is_different=diff_array((char*)&diff_pemPlanning,       (char*)&inputBuffer.pemPlanning,      (char*)ref_pemPlanning,     (char*)&ref_pemPlanning->debug-(char*)ref_pemPlanning);
    is_different=diff_array((char*)&diff_flexrayInput,      (char*)&inputBuffer.flexrayInput,     (char*)ref_flexrayInput,    sizeof(flexrayInput_T));
    is_different=diff_array((char*)&diff_emlInput,          (char*)&inputBuffer.emlInput,         (char*)ref_emlInput,        sizeof(emlInput_T));
    is_different=diff_array((char*)&diff_vzeInput,          (char*)&inputBuffer.vzeInput,         (char*)ref_vzeInput,        sizeof(vzeInput_T));
	/* is_different=diff_array((char*)&diff_obfInput,          (char*)&inputBuffer.obfInput,         (char*)ref_obfInput,        sizeof(obfInput_T)); */
    is_different=diff_array((char*)&diff_laneInput,         (char*)&inputBuffer.laneInput,        (char*)ref_laneInput,       sizeof(laneInput_T));

    memset(&controlStack,  0, sizeof(pemControlStack_T));
    memset(&pemControl,    0, sizeof(pemControl_T));
    memset(&flexrayOutput, 0, sizeof(flexrayOutput_T));
#endif

	/*call the SWC InnodriveControl*/
	iccRunControl( controlHeap,
				  &inputBuffer.vehicleModel,
				  &inputBuffer.pemPlanning,
				  &inputBuffer.flexrayInput,
				  &inputBuffer.emlInput,
				  &inputBuffer.laneInput,
				  &inputBuffer.vzeInput,
				  &inputBuffer.obfInput,
				  &inputBuffer.lapInput,
				  &inputBuffer.codingInput,
				  &inputBuffer.fodInput,
				  &controlRteInfo,
				  &controlStack,
				  &pemControl,
				  &flexrayOutput,
				  &fodOutput,
				  &controlMeasurement,
				   checkState);

#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
    /* cleanup differences*/
    if(ref_pemControl!=NULL){
        pemControl.debug = ref_pemControl->debug;
    }
    /* determine real differences*/
    /*is_different=diff_array((char*)&diff_pemControlHeap, (char*)s_heap,           (char*)ref_pemControlHeap,  sizeof(pemControlHeap_T));*/
    is_different=diff_array((char*)&diff_pemControlStack,(char*)&controlStack,  (char*)ref_pemControlStack, sizeof(pemControlStack_T));
    is_different=diff_array((char*)&diff_flexrayOutput,  (char*)&flexrayOutput, (char*)ref_flexrayOutput, sizeof(flexrayOutput_T));
    is_different=diff_array((char*)&diff_pemControl,     (char*)&pemControl,    (char*)ref_pemControl,    sizeof(pemControl_T));
    is_different=0;
#endif

	if(!rteOutConvert_pemControl(&pemControl, recPemControl)) {
		memset(recPemControl, 0, sizeof(*recPemControl));
	}

	rteOutConvert_traceData(controlHeap, recTraceData);
	rteOutConvert_flexrayOutput(&flexrayOutput, recFRInnoDriveOut);
	rteOutConvert_fodOutput(&fodOutput, recFoDReadyToRun);
	rteOutConvert_controlMeasurement(&controlMeasurement, recMeasurement);
}


#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
static bool_T diff_array(char* diff_dest, const char* src, const char* ref, size_t size){
    size_t i;
    if(ref!=0){
        bool_T ret=false;
        for(i=0;i<size;++i){
            diff_dest[i] = src[i] - ref[i];
            if(diff_dest[i]!=0){
                ret=true;
            }
        }
        return ret;
    }else{
        for(i=0;i<size;++i)
            diff_dest[i] = 0;
        return false;
    }
}
#endif
