#include "control/rteInterface/rteMeasurement.h"
#include "control/controlTask/controlTask_private.h"


void   rteOutConvert_controlMeasurement(IN	const	controlMeasurement_T					*controlMeasurement,
										OUT			Dt_RECORD_Messwert_InnoDriveControl		*recMeasurement)
{
	recMeasurement->DePID_Reason_For_Activation_Prohibition_0x1741.PID_Reason_For_Activation_Prohibition	= controlMeasurement->PID_Reason_For_Activation_Prohibition;
	recMeasurement->DePID_Reason_For_Degradation_0x1743.PID_Reason_For_Degradation							= controlMeasurement->PID_Reason_For_Degradation;
	recMeasurement->DePID_Resistance_Deviation_0x1742.PID_Resistance_Deviation_disengaged					= controlMeasurement->PID_Resistance_Deviation_disengaged;
	recMeasurement->DePID_Resistance_Deviation_0x1742.PID_Resistance_Deviation_engaged						= controlMeasurement->PID_Resistance_Deviation_engaged;
	recMeasurement->DePID_Status_Code_Control_0x1740.PID_Status_Code_Control								= controlMeasurement->PID_Status_Code_Control;
}
