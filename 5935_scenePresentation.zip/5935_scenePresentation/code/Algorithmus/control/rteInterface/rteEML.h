#ifndef guard_rteEML_h
#define guard_rteEML_h

#include "Rte_Type.h"
#include "control/inputCodec/inputCodec_interface.h"


void		  rteInConvert_emlInput(IN	const	Dt_RECORD_EML			*recEML,
									OUT			emlInput_T				*emlInput);


#endif
