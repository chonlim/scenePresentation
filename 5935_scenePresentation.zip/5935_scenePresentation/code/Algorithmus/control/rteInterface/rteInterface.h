#ifndef guard_rteInterface_h
#define guard_rteInterface_h

#ifdef __cplusplus
extern "C" {
#endif

	enum ePduStateIntern
	{
		ePDUIntInValid = 0/*,*/
		/*ePDUIntValid = 1*/
	};

#ifdef __cplusplus
}
#endif


#endif
