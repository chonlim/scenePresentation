#ifndef guard_rteCoding_h
#define guard_rteCoding_h

#include "Rte_Type.h"
#include "control/inputCodec/inputCodec_interface.h"


void		   rteInConvert_codingInput(IN	const	Dt_RECORD_Diag_Coding		*recCoding,
										OUT			codingInput_T				*codingInput);


#endif

