#include "control/rteInterface/rteRGLanes.h"
#include "control/inputCodec/inputCodec_private.h"


void		 rteInConvert_laneInput(IN	const	Dt_RECORD_GeometryLanes	*recRGLanes,
									OUT			laneInput_T				*laneInput)
{
	uint16 uiLaneIdx;
	uint16 uiSegmentIdx;

	laneInput->DataValidFlag		= true;
	laneInput->DeNumLaneBoundaries	= recRGLanes->DeNumLaneBoundaries;

	for (uiLaneIdx = 0; uiLaneIdx < (uint16)incNUMLANEBOUNDARIES; uiLaneIdx++)
	{
		laneInput->DeLaneBoundary[uiLaneIdx].DeNumSegments = recRGLanes->DeLaneBoundary[uiLaneIdx].DeNumSegments;

		for (uiSegmentIdx = 0; uiSegmentIdx < (uint16)incNUMLANESEGMENTS; uiSegmentIdx++)
		{
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeLength                  = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeLength;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeLengthMeasured          = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeLengthMeasured;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeClothoidStartCurvature  = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeClothoidStartCurvature;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeClothoidCurvatureChange = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeClothoidCurvatureChange;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeStartPositionX          = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeStartPositionX;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeStartPositionY          = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeStartPositionY;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeStartYawAngle           = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeStartYawAngle;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeQualityBegin            = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeQualityBegin;
			laneInput->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeValid                   = recRGLanes->DeLaneBoundary[uiLaneIdx].DeLaneSegments[uiSegmentIdx].DeValid; /*lint !e9034 cast DtBool to bool_T*/
		}
	}
}
