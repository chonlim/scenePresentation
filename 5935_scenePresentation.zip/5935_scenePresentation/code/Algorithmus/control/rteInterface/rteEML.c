#include "control/rteInterface/rteEML.h"
#include "control/inputCodec/inputCodec_private.h"


void		  rteInConvert_emlInput(IN	const	Dt_RECORD_EML			*recEML,
									OUT			emlInput_T				*emlInput)
{
	emlInput->DataValidFlag		= true;

	emlInput->DeHeadingConf		= recEML->DeHeadingConf;
	emlInput->DeHeading			= recEML->DeHeading;

	emlInput->DeAccXConf		= recEML->DeAccXConf;
	emlInput->DeAccX			= recEML->DeAccX;

	emlInput->DeAccYConf		= recEML->DeAccYConf;
	emlInput->DeAccY			= recEML->DeAccY;

	emlInput->DeYawRateConf		= recEML->DeYawRateConf;
	emlInput->DeYawRate			= recEML->DeYawRate;

	emlInput->DeVelocityXConf	= recEML->DeVelocityXConf;
	emlInput->DeVelocityX		= recEML->DeVelocityX;
}
