#ifndef guard_rteFRInnoDriveOut_h
#define guard_rteFRInnoDriveOut_h

#include "Rte_Type.h"
#include "control/outputCodec/outputCodec_interface.h"


void		rteOutConvert_flexrayOutput(IN	const	flexrayOutput_T				*flexrayOutput,
										OUT			Dt_RECORD_FRInnoDriveOut	*recFRInnoDriveOut);


#endif

