#ifndef guard_rteRGExtPSD_h
#define guard_rteRGExtPSD_h

#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"
#else
#include "Rte_Type.h"
#endif
#include "common/common.h"

#include "control/controlTask/controlTask_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"


bool_T	convertRteRGExtPSDTovehicleInput(const	Dt_RECORD_RGExtractorPSD	*recRGExtPSD);


#endif

