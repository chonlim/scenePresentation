#ifndef guard_rteFoDFunctionActivationState_h
#define guard_rteFoDFunctionActivationState_h

#include "Rte_Type.h"
#include "control/inputCodec/inputCodec_interface.h"


void		  rteInConvert_fodInput(IN	const	Dt_RECORD_FoDFunctionActivationState		*recFoDFunctionActivationState,
									OUT			fodInput_T									*fodInput);


#endif

