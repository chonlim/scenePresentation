#ifndef guard_rteFoDReadyToRun_h
#define guard_rteFoDReadyToRun_h

#include "Rte_Type.h"
#include "common/systemControllerCommon/systemController_interface.h"


void			rteOutConvert_fodOutput(IN	const	fodOutput_T					*fodOutput,
										OUT			Dt_RECORD_FoDReadyToRun		*recFoDReadyToRun);


#endif

