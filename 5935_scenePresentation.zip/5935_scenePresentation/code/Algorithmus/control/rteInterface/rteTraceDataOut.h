#ifndef guard_rteTraceDataOut_h
#define guard_rteTraceDataOut_h

#include "Rte_Type.h"
#include "control/controlTask/controlTask_private.h"

typedef struct {
	size_t dynamicSetListPos;
	size_t dynamicSetListSize;

	size_t environmentStatePos;
	size_t environmentStateSize;

	size_t desiredSpeedPos;
	size_t desiredSpeedSize;

	size_t maxVelocityPos;
	size_t maxVelocitySize;

	size_t nextLimitInfoPos;
	size_t nextLimitInfoSize;

	size_t trajectoryPos;
	size_t trajectoryOutSize;

	size_t trajectoryMuxIdPos;
	size_t trajectoryMuxIdSize;

	size_t rglStatusPos;
	size_t rglStatusSize;
}traceDataArrayFormat_T;


void		rteOutConvert_traceData(INOUT		pemControlHeap_T		*controlHeap,
									OUT			Dt_RECORD_TraceData		*recTraceData);

#ifndef INNODRIVE_ZFAS_SWC_BUILD
void		 rteInConvert_traceData(IN			Dt_RECORD_TraceData				*recTraceData,
									OUT			driverState_T					*driverState,
									OUT			driverPredictorDebugBuffer_T	*dprdDebugBuffer);
#endif

static void getTraceDataFormat(OUT traceDataArrayFormat_T *traceDataArrayFormat);

#endif

