#ifndef guard_rteFRInnoDriveIn_h
#define guard_rteFRInnoDriveIn_h

#include "Rte_Type.h"
#include "common/common.h"
#include "control/inputCodec/inputCodec_interface.h"


void	  rteInConvert_flexrayInput(IN	const	Dt_RECORD_FRInnoDriveIn		*recFRInnoDriveIn,
									OUT			flexrayInput_T				*flexrayInput);


#endif

