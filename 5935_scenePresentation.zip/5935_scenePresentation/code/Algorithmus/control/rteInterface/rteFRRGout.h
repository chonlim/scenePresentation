#ifndef guard_rteFRRGout_h
#define guard_rteFRRGout_h

#include "Rte_Type.h"
#include "control/inputCodec/inputCodec_interface.h"


void		  rteInConvert_lapInput(IN	const	Dt_RECORD_FRRGout		*recFRRGout,
									OUT			lapInput_T				*lapInput);


#endif

