#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"
#include "FastProject/rteInterfaceCtrl/Log_Types.h"
#define Log_AddMsg(ID, Group, Option, ...)
#else
#include "Log.h"
#endif

#include "control/rteInterface/rteOBFLightIn.h"


static bool_T appendRteOBFLightObject(const	Dt_RECORD_ObjectOBFLout *recOBFObject,
											obfInput_T				*objectList)
{
	uint8_T idx;

	/*Parameter check*/
	if (objectList == NULL)
	{
		return false;
	}
	
	idx = objectList->count;
	if (idx >= (uint8_T)incNUMOBFOBJECTS)
	{
		return false;
	}
	memset(&objectList->objects[idx], 0, sizeof(obfObject_T));

	if (recOBFObject->DeId > 0u)
	{
		; /*Id ok;*/
	}


	/* [Min]0.0[/Min]                                            */
	/* [Max]1.0[/Max]                                            */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Wahrscheinlichkeit, dass an der      */
	/* angegebenen Position (im 3sigma-Bereich) zum angegebenen  */
	/* Zeitpunkt ein Objekt existiert.[/Description (short)]     */
	/* [Unit]%[/Unit]                                            */
	/* [Accuracy]-[/Accuracy]                                    */

	if (recOBFObject->DeExistenceProb >= 0.0f && recOBFObject->DeExistenceProb <= 1.0f)
	{
		; /* angegebenen Position (im 3sigma-Bereich) zum angegebenen Zeitpunkt ein Objekt existiert.*/
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeExistenceProb out of range. DeExistenceProb = %f ", recOBFObject->DeExistenceProb); /* angegebenen Position (im 3sigma-Bereich) zum angegebenen Zeitpunkt ein Objekt existiert.*/
		return false;
	}

	/* [Min]-200[/Min]                                           */
	/* [Max]800.0[/Max]                                          */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Position des Objektes in x-Richtung  */
	/* (Referenzpunkt der 3D-Objektbox)[/Description (short)]    */
	/* [Unit]m[/Unit]                                            */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DePositionX >= -200.0f && recOBFObject->DePositionX <= 800.0f)
	{
		objectList->objects[idx].DePositionX = recOBFObject->DePositionX; /*Position des Objektes in x-Richtung  */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DePositionX out of range. DePositionX = %f ", recOBFObject->DePositionX); /*Position des Objektes in x-Richtung (Referenzpunkt der 3D-Objektbox)*/
		return false;
	}

	/* [Min]-400[/Min]                                           */
	/* [Max]400.0[/Max]                                          */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Position des Objektes in y-Richtung  */
	/* (Referenzpunkt der 3D-Objektbox)[/Description (short)]    */
	/* [Unit]m[/Unit]                                            */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DePositionY >= -400.0f && recOBFObject->DePositionY <= 400.0f)
	{
		objectList->objects[idx].DePositionY = recOBFObject->DePositionY; /*Position des Objektes in y - Richtung (Referenzpunkt der 3D-Objektbox)*/
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DePositionY out of range. DePositionY = %f ", recOBFObject->DePositionY); /*Position des Objektes in y - Richtung (Referenzpunkt der 3D-Objektbox)*/
		return false;
	}

	/* [Min]-100[/Min]                                           */
	/* [Max]100.0[/Max]                                          */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Position der Unterkante des Objektes */
	/* in z bzgl. des 3D Koordinatensystems  (Referenzpunkt der  */
	/* 3D-Objektbox). Anmerkung: Fahrzeuge knnen durch           */
	/* Bodenunebenheiten Z-Werte<>0 erhalten!!![/Description     */
	/* (short)]   [Unit]m[/Unit]                                 */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DePositionZ >= -100.0f && recOBFObject->DePositionZ <= 100.0f)
	{
		objectList->objects[idx].DePositionZ = recOBFObject->DePositionZ; /* Position der Unterkante des Objektes in z bzgl. des 3D Koordinatensystems  (Referenzpunkt der 3D-Objektbox). */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DePositionZ out of range. DePositionZ = %f ", recOBFObject->DePositionZ); /* Position der Unterkante des Objektes in z bzgl. des 3D Koordinatensystems  (Referenzpunkt der 3D-Objektbox). */
		return false;
	}

	/* [Min]-110[/Min]                                           */
	/* [Max]110.0[/Max]                                          */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]absolute Geschwindigkeit in          */
	/* x-Richtung. Geschwindigkeiten beziehen sich immer auf den */
	/* Objektmittelpunkt.[/Description (short)]                  */
	/* [Unit]m/s[/Unit]                                          */
	/* [Accuracy]0,0001[/Accuracy]                               */
	if (recOBFObject->DeVelocityX >= -110.0f && recOBFObject->DeVelocityX <= 110.0f)
	{
		objectList->objects[idx].DeVelocityX = recOBFObject->DeVelocityX; /*absolute Geschwindigkeit in          */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeVelocityX out of range. DeVelocityX = %f ", recOBFObject->DeVelocityX); /* absolute Geschwindigkeit in x-Richtung. */
		return false;
	}

	/* [Min]-110[/Min]                                           */
	/* [Max]110.0[/Max]                                          */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]absolute Geschwindigkeit in          */
	/* y-Richtung. Geschwindigkeiten beziehen sich immer auf den */
	/* Objektmittelpunkt.[/Description (short)]                  */
	/* [Unit]m/s[/Unit]                                          */
	/* [Accuracy]0,0001[/Accuracy]                               */
	if (recOBFObject->DeVelocityY >= -110.0f && recOBFObject->DeVelocityY <= 110.0f)
	{
		objectList->objects[idx].DeVelocityY = recOBFObject->DeVelocityY; /*absolute Geschwindigkeit in          */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeVelocityY out of range. DeVelocityY = %f ", recOBFObject->DeVelocityY); /* absolute Geschwindigkeit in y-Richtung. */
		return false;
	}

	/* [Min]-15[/Min]                                            */
	/* [Max]15.0[/Max]                                           */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]absolute Beschleunigung in           */
	/* x-Richtung. Beschleunigungen beziehen sich immer auf den  */
	/* Objektmittelpunkt.[/Description (short)]                  */
	/* [Unit]m/s^2[/Unit]                                        */
	/* [Accuracy]0,0001[/Accuracy]                               */
	if (recOBFObject->DeAccX >= -15.0f && recOBFObject->DeAccX <= 15.0f)
	{
		objectList->objects[idx].DeAccX = recOBFObject->DeAccX; /*absolute Beschleunigung in x-Richtung */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeAccX out of range. DeAccX = %f ", recOBFObject->DeAccX); /*absolute Beschleunigung in x-Richtung. */
		return false;
	}

	/* [Min]-15[/Min]                                            */
	/* [Max]15.0[/Max]                                           */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]absolute Beschleunigung in           */
	/* y-Richtung. Beschleunigungen beziehen sich immer auf den  */
	/* Objektmittelpunkt[/Description (short)]                   */
	/* [Unit]m/s^2[/Unit]                                        */
	/* [Accuracy]0,0001[/Accuracy]                               */
	if (recOBFObject->DeAccY >= -15.0f && recOBFObject->DeAccY <= 15.0f)
	{
		objectList->objects[idx].DeAccY = recOBFObject->DeAccY; /*absolute Beschleunigung in y-Richtung */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeAccY out of range. DeAccY = %f ", recOBFObject->DeAccY); /*absolute Beschleunigung in y-Richtung. */
		return false;
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]5.0[/Max]                                            */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Hhe der 3D-Objektbox (m).  Nur       */
	/* indirekt durch Kamera messbar.[/Description (short)]      */
	/* [Unit]m[/Unit]                                            */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DeHeight >= 0.0 && recOBFObject->DeHeight <= 5.0)
	{
		; /*H�he der 3D-Objektbox (m).  Nur indirekt durch Kamera messbar.*/
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeHeight out of range. DeHeight = %f ", recOBFObject->DeHeight); /*H�he der 3D-Objektbox (m).  Nur indirekt durch Kamera messbar.*/
		return false;
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]5.0[/Max]                                            */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Breite der 3D-Objektbox              */
	/* (m).[/Description (short)]                                */
	/* [Unit]m[/Unit]                                            */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DeWidth >= 0.0f && recOBFObject->DeWidth <= 5.0f)
	{
		; /*Breite der 3D-Objektbox*/
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeWidth out of range. DeWidth = %f ", recOBFObject->DeWidth); /*Breite der 3D-Objektbox*/
		return false;
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]50.0[/Max]                                           */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Lnge der 3D-Objektbox. Anmerkung:    */
	/* Lnge ist generell nur bei entsprechend groem Gierwinkel   */
	/* bzw. Querversatz zu ermitteln[/Description (short)]       */
	/* [Unit]m[/Unit]                                            */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DeLength >= 0.0f && recOBFObject->DeLength <= 50.0f)
	{
		; /*L�nge der 3D-Objektbox. */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeLength out of range. DeLength = %f ", recOBFObject->DeLength); /*L�nge der 3D-Objektbox. */
		return false;
	}

	/* [Min]-PI[/Min]                                            */
	/* [Max]PI[/Max]                                             */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Gierwinkel des Objektes              */
	/* (Fahrzeuglngsachse) relativ zur Sichtachse des            */
	/* Objektlistenerzeugers zum Referenzpunkt (=Orientierung    */
	/* der 3D-Objektbox)[/Description (short)]                   */
	/* [Unit]rad[/Unit]                                          */
	/* [Accuracy]0,001[/Accuracy]                                */
	if (recOBFObject->DeYawAngle >= -defPI && recOBFObject->DeYawAngle <= defPI)
	{
		; /* Gierwinkel des Objektes (Fahrzeuglngsachse) relativ zur Sichtachse des Objektlistenerzeugers zum Referenzpunkt */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeYawAngle out of range. DeYawAngle = %f ", recOBFObject->DeYawAngle);  /* Gierwinkel des Objektes (Fahrzeuglngsachse) relativ zur Sichtachse des Objektlistenerzeugers zum Referenzpunkt */
		return false;
	}

	/* [Min]-2*PI[/Min]                                          */
	/* [Max]2*PI[/Max]                                           */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Drehrate des Objektes um die         */
	/* Hochachse/z-Achse des Fremdobjekts.[/Description (short)] */
	/* [Unit]rad/s[/Unit]                                        */
	/* [Accuracy]0,0001[/Accuracy]                               */
	if (recOBFObject->DeYawRate >= ((Dt_FLOAT32)-2 * defPI) && recOBFObject->DeYawRate <= ((Dt_FLOAT32)2 * defPI))
	{
		; /* Drehrate des Objektes um die Hochachse/z-Achse des Fremdobjekts.*/
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeYawRate out of range. DeYawRate = %f ", recOBFObject->DeYawRate); /* Drehrate des Objektes um die Hochachse/z-Achse des Fremdobjekts.*/
		return false;
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]-[/Max]                                              */
	/* [Logical]TBD Objektfusion[/Logical]                       */
	/* [Init]0xFFFFFFFF[/Init]                                   */
	/* [Description (short)]Zuverlssigkeitsaussage ber ein       */
	/* Objekt, abstrahiert von den konkreten Sensorbeitrgen:     */
	/* "Qualittsklasse" Enthalten sind folgende Gren: - NIS-Test */
	/* fehlgeschlagen - Fusions- und Sensorassoziationen         */
	/* inkonsistent - Assoziationsmehrdeutigkeiten -             */
	/* #Sensorbeitrge momentan - #Sensorbeitrge momentan fehlend */
	/* - #komplementre Messprinzipien momentan[/Description      */
	/* (short)]                    [Unit]-[/Unit]                */
	/* [Accuracy]1.0[/Accuracy]                                  */

	if (recOBFObject->DeQualityClass == 0xFFFFFFFFU)
	{
		; /*Zuverlaessigkeitsaussage �ber ein Objekt, abstrahiert von den konkreten Sensorbeitraegen */
	}
	

	/* [Min]0.0[/Min]                                            */
	/* [Max]1.0[/Max]                                            */
	/* [Logical]0:  0x0  Erstmalige_Ausgabe_auf_dem_Bus  1:  0x1 */
	/* Obj_wurde_bereits_ausgegeben[/Logical]                    */
	/* [Init]0xFF[/Init]                                         */
	/* [Description (short)]Information, ob Objekt bereits auf   */
	/* dem Bus ausgegeben wurde. Anmerkung: Wenn das Objekt      */
	/* zwischenzeitlich nicht auf der Schnittstelle ausgegeben   */
	/* wird, aber intern weiter existiert, wird das Signal bei   */
	/* einer weiteren Ausgabe des SELBEN Objekts nicht wieder    */
	/* auf 0 gesetzt.[/Description (short)]                      */
	/* [Unit]-[/Unit]                                            */
	/* [Accuracy]1.0[/Accuracy]                                  */
	if (recOBFObject->DeHistory == 0u || recOBFObject->DeHistory == 1u)
	{
		; /*Information, ob Objekt bereits auf   */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeHistory out of range. DeHistory = %i ", recOBFObject->DeHistory);
		return false;
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]13.0[/Max]                                           */
	/* [Logical]
	0   0x0  Unbekannt 
	1   0x1  Dynamisch 
	2   0x2  VRU 
	3   0x3  Fussgaenger 
	4   0x4  Fussgaengergruppe 
	5   0x5  Radfahrer 
	6   0x6  Motorrad 
	7   0x7  PKW 
	8   0x8  Mindestens_Vierrad 
	9   0x9  LKW 
	10 0xA Zweirad 
	11 0xB Tier 
	12 0xC Mindestens_Zweirad 
	13 0xD Objektcluster 
	255 0xFF Init[/Logical]                                      */
	/* [Init]0xFF[/Init]                                         */
	/* [Accuracy]1.0[/Accuracy]                                  */
	if (recOBFObject->DeClass >= 1u && recOBFObject->DeClass <= 13u)
	{
		objectList->objects[idx].DeClass = recOBFObject->DeClass;
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeClass out of range. DeClass = %l ", recOBFObject->DeClass); /* Objektklasse */
		return false;
	}

	/* [Call Cycle][/Call Cycle]                                 */
	/* [Signal Availability][/Signal Availability]               */
	/* [Min][/Min]                                               */
	/* [Max][/Max]                                               */
	/* [Logical][/Logical]                                       */
	/* [ASIL LEVEL]QM[/ASIL LEVEL]                               */
	/* [Init][/Init]                                             */
	/* [Description (short)][/Description (short)]               */
	/* [Unit][/Unit]                                             */
	/* [Accuracy][/Accuracy]                                     */
	/*recOBFObject->DeBrightness;*/

	/* [Min]0.0[/Min]                                            */
	/* [Max]17.0[/Max]                                           */
	/* [Logical]
	0 0x0 unbestimmt  
	1 0x1 vorne_links  
	2 0x2 vorne_Mitte  
	3 0x3 vorne_rechts 
	4 0x4 rechts_Mitte 
	5 0x5 hinten_rechts  
	6 0x6 hinten_Mitte  
	7 0x7 hinten_links 
	8 0x8 links_Mitte  
	9 0x9 Objektmitte  
	10 0xA beliebige_Seite  
	11 0xB beliebige_Ecke  
	12 0xC hinten_links_oben  
	13 0xD hinten_rechts_oben  
	14 0xE vorne_links_oben  
	15 0xF vorne_rechts_oben 
	16 0x10 hinten_Mitte_Heckleuchten 
	17 0x11 vorne_Mitte_Scheinwerfer 
	255 0xFF Init[/Logical]          */
	/* [Init]0xFF[/Init]                                         */
	/* [Description (short)]Index des verwendeten Bezugspunktes  */
	/* auf der 3D-Objektbox Bemerkungen: * 0-11 liegen auf der   */
	/* Fahrbahn * hinten_Mitte_Heckleuchten und                  */
	/* vorne_Mitte_Scheinwerfer sind durch Sensoren zu befllen,  */
	/* die lediglich die Scheinwerfer erkennen knnen.            */
	/* Unterschied zu hinten_Mitte und vorne_Mitte:              */
	/* Unterschiedliche z-Position.[/Description (short)]        */
	/* [Unit]-[/Unit]                                            */
	/* [Accuracy]1.0[/Accuracy]                                  */
	if (recOBFObject->DeReferencePoint >= 1u && recOBFObject->DeReferencePoint <= 17u)
	{
		; /* Index des verwendeten Bezugspunktes auf der 3D-Objektbox */
	}
	else if (recOBFObject->DeReferencePoint == (uint8_T)0xff)
	{
		; /* Index des verwendeten Bezugspunktes auf der 3D-Objektbox */
	}
	else
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_INFO, "DeReferencePoint out of range. DeReferencePoint = %i ", recOBFObject->DeReferencePoint); /* Index des verwendeten Bezugspunktes auf der 3D-Objektbox */
		return false;
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]-[/Max]                                              */
	/* [Logical]
	0x0 None 
	0x1 brakeLightsOn 
	0x2 lowBeamHeadlightsOn + RearLightOn 
	0x4 highBeamHeadlightsOn + RearLightOn 
	0x8 leftTurnSignalOn
	0x10 rightTurnSignalOn 
	0x20 reverseLightOn
	0x40 fogLightOn 
	0x80 parkingLightsOn 
	0xFF Undefined[/Logical]  */
	/* [ASIL LEVEL]B[/ASIL LEVEL]                                */
	/* [Init]0xFF[/Init]                                         */
	/* [Description (short)]Lichtzustand des Objektes. Ob        */
	/* Lichtstatus berhaupt ermittelt werden kann, wird in       */
	/* LightStatusAvailability bertragen (bei Sensoren im        */
	/* Header, bei Fusionsobjekten am Objekt). Erkennung         */
	/* eingschalteter Blinker: fr den gesamten Zyklus von Ein-   */
	/* und Ausphasen der Leuchte auf "eingeschaltet" gesetzt     */
	/* Heckleuchten sind nicht getrennt zum Abblendlicht         */
	/* schaltbar. Unterscheidung zwischen Abblendlicht &         */
	/* Heckleuchten ber Gierwinkel relativ zum                   */
	/* Egofahrzeug.[/Description (short)]                        */
	/* [Unit]-[/Unit]                                            */
	/* [Accuracy]1.0[/Accuracy]                                  */
	if (recOBFObject->DeLightStatus != (uint8_T)0xff)
	{
		; /* Lichtzustand des Objektes. */
	}
	else
	{
		; /* Lichtzustand des Objektes. */
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]15.0[/Max]                                           */
	/* [Logical]
	-127: LANE_UNKNOWN,
	7: LANE_SEVENTH_LEFT,
	6: LANE_SIXTH_LEFT, 
	5: LANE_FIFTH_LEFT, 
	4: LANE_FOURTH_LEFT,
	3: LANE_THIRD_LEFT, 
	2: LANE_SECOND_LEFT,
	1: LANE_FIRST_LEFT,
	0: LANE_EGO_LANE,
	-1: LANE_FIRST_RIGHT,
	-2: LANE_SECOND_RIGHT,
	-3: LANE_THIRD_RIGHT,
	-4: LANE_FOURTH_RIGHT,
	-5: LANE_FIFTH_RIGHT,
	-6: LANE_SIXTH_RIGHT,
	-7: LANE_SEVENTH_RIGHT.
	[/Logical]       */
	/* [ASIL LEVEL]B[/ASIL LEVEL]                                */
	/* [Init]0xFF[/Init]                                         */
	/* [Description (short)]relative Spurzuordnung zum           */
	/* Egofahrzeug, von der Kamera / evtl. Roadgraph             */
	/* bestimmt.[/Description (short)]                           */
	/* [Unit]-[/Unit]                                            */
	/* [Accuracy]1.0[/Accuracy]                                  */
	if (recOBFObject->DeLaneAssignmentRel == (sint8)-1)
	{
		; /* relative Spurzuordnung zum Egofahrzeug, von der Kamera / evtl. Roadgraph bestimmt.*/
	}

	/* [Min]0.0[/Min]                                            */
	/* [Max]-[/Max]                                              */
	/* [Logical]
	0x0 None 
	0x1 brakeLightsMeasurable 
	0x2 lowBeamHeadlightsMeasurable + RearLightMeasurable 
	0x4 highBeamHeadlightsMeasurable + RearLightMeasurable 
	0x8 leftTurnSignalMeasurable
	0x10 rightTurnSignalMeasurable
	0x20 reverseLightMeasurable
	0x40 fogLightMeasurable
	0x80 parkingLightsMeasurable
	0xFF Undefined
	[/Logical]          */
	/* [Init]0xFF[/Init]                                         */
	/* [Description (short)]Kennzeichnet, welche Lichtstati fr   */
	/* ein Fusionsobjekt ermittelt werden konnten.[/Description  */
	/* (short)]                                                  */
	/* [Unit]-[/Unit]                                            */
	/* [Accuracy]1.0[/Accuracy]                                  */
	if (recOBFObject->DeLightStatusAvailability != (uint8_T)0xff)
	{
		; /*Kennzeichnet, welche Lichtstati f�r ein Fusionsobjekt ermittelt werden konnten.*/
	}

	objectList->objects[idx].DataValidFlag = true;
	objectList->count++;

	return true;
}


bool_T		  rteInConvert_obfInput(IN	const	Dt_RECORD_ObjectListOBFLightOut		*recObjectOBFLout,
									OUT			obfInput_T							*obfInput)
{
	uint8_T i;
	memset(obfInput, 0, sizeof(obfInput_T));
	for (i = 0; i < (uint8_T)incNUMOBFOBJECTS && i < recObjectOBFLout->DeCount; i++)
	{
		if (!appendRteOBFLightObject(&recObjectOBFLout->DeObjects[i], obfInput))
		{
			return false;
		}
	}

	return true;
}
