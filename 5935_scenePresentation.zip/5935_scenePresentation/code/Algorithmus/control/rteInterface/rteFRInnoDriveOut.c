#include "control/rteInterface/rteFRInnoDriveOut.h"
#include "control/outputCodec/outputCodec_private.h"
#include "BusSignals_enums.h"


void		rteOutConvert_flexrayOutput(IN	const	flexrayOutput_T				*flexrayOutput,
										OUT			Dt_RECORD_FRInnoDriveOut	*recFRInnoDriveOut)
{
	Dt_RECORD_Timestamp innodriveControlOutTimestamp;
	uint32_T uiPemControlTimeHigh = 0;
	uint32_T uiPemControlTimeLow = 0;

	innodriveControlOutTimestamp.DeTimestampHigh = 0;
	innodriveControlOutTimestamp.DeTimestampLow = 0;

	recFRInnoDriveOut->DePACC02_Durchschnittsgeschw = flexrayOutput->DePACC02_Durchschnittsgeschw;
	recFRInnoDriveOut->DePACC02_neg_Sollbeschl_Grad = flexrayOutput->DePACC02_neg_Sollbeschl_Grad;
	recFRInnoDriveOut->DePACC02_pos_Sollbeschl_Grad = flexrayOutput->DePACC02_pos_Sollbeschl_Grad;
	recFRInnoDriveOut->DePACC02_Sollbeschleunigung = flexrayOutput->DePACC02_Sollbeschleunigung;
	recFRInnoDriveOut->DePACC02_Sollgeschwindigkeit = flexrayOutput->DePACC02_Sollgeschwindigkeit;
	recFRInnoDriveOut->DePACC02_Vorausschaugeschw = flexrayOutput->DePACC02_Vorausschaugeschw;
	recFRInnoDriveOut->DePACC02_Wunschuebersetzung = flexrayOutput->DePACC02_Wunschuebersetzung;
	recFRInnoDriveOut->DePACC02_zul_Regelabw_oben = flexrayOutput->DePACC02_zul_Regelabw_oben;
	recFRInnoDriveOut->DePACC02_zul_Regelabw_unten = flexrayOutput->DePACC02_zul_Regelabw_unten;
	recFRInnoDriveOut->DePACC02_Offset = flexrayOutput->DePACC02_Offset;
	recFRInnoDriveOut->DePACC02_Ausrollmanoever = flexrayOutput->DePACC02_Ausrollmanoever;
	recFRInnoDriveOut->DePACC02_naechstes_Event = flexrayOutput->DePACC02_naechstes_Event;
	recFRInnoDriveOut->DePACC02_Segelanteil = DeFRInnoDriveOut_DePACC02_Segelanteil_DEFAULT;
	recFRInnoDriveOut->DePACC02_Systemstatus = flexrayOutput->DePACC02_Systemstatus;
	recFRInnoDriveOut->DePACC02_Uebernahmeaufforderung = flexrayOutput->DePACC02_Uebernahmeaufforderung ? 1u : 0u;

#if ((100*IFSET_VERSION_VARIANT + 10*IFSET_VERSION_MAJOR + IFSET_VERSION_MINOR)> 95)
	recFRInnoDriveOut->DePACC02_Automode = flexrayOutput->DePACC02_Automode ? 1u : 0u;
	recFRInnoDriveOut->DePACC02_Systemstatus_Anzeige = flexrayOutput->DePACC02_Systemstatus_Anzeige;

	recFRInnoDriveOut->DePIF_Toggle = flexrayOutput->DePIF_Toggle ? 1u : 0u;
	recFRInnoDriveOut->DePIF_ST_Status = flexrayOutput->DePIF_ST_Status;
	recFRInnoDriveOut->DePIF_MT_Status = flexrayOutput->DePIF_MT_Status;
	recFRInnoDriveOut->DePIF_LT_Status = flexrayOutput->DePIF_LT_Status;
	recFRInnoDriveOut->DePIF_Identifier = flexrayOutput->DePIF_Identifier;
	recFRInnoDriveOut->DePIF_ST_Bin_0 = flexrayOutput->DePIF_ST_Bin_0;
	recFRInnoDriveOut->DePIF_ST_Bin_1 = flexrayOutput->DePIF_ST_Bin_1;
	recFRInnoDriveOut->DePIF_ST_Bin_2 = flexrayOutput->DePIF_ST_Bin_2;
	recFRInnoDriveOut->DePIF_ST_Bin_3 = flexrayOutput->DePIF_ST_Bin_3;
	recFRInnoDriveOut->DePIF_ST_Bin_4 = flexrayOutput->DePIF_ST_Bin_4;
	recFRInnoDriveOut->DePIF_ST_Bin_5 = flexrayOutput->DePIF_ST_Bin_5;
	recFRInnoDriveOut->DePIF_ST_Bin_6 = flexrayOutput->DePIF_ST_Bin_6;
	recFRInnoDriveOut->DePIF_ST_Bin_7 = flexrayOutput->DePIF_ST_Bin_7;
	recFRInnoDriveOut->DePIF_ST_Bin_8 = flexrayOutput->DePIF_ST_Bin_8;
	recFRInnoDriveOut->DePIF_MT_Bin_0 = flexrayOutput->DePIF_MT_Bin_0;
	recFRInnoDriveOut->DePIF_MT_Bin_1 = flexrayOutput->DePIF_MT_Bin_1;
	recFRInnoDriveOut->DePIF_MT_Bin_2 = flexrayOutput->DePIF_MT_Bin_2;
	recFRInnoDriveOut->DePIF_MT_Bin_3 = flexrayOutput->DePIF_MT_Bin_3;
	recFRInnoDriveOut->DePIF_MT_Bin_4 = flexrayOutput->DePIF_MT_Bin_4;
	recFRInnoDriveOut->DePIF_MT_Bin_5 = flexrayOutput->DePIF_MT_Bin_5;
	recFRInnoDriveOut->DePIF_MT_Bin_6 = flexrayOutput->DePIF_MT_Bin_6;
	recFRInnoDriveOut->DePIF_MT_Bin_7 = flexrayOutput->DePIF_MT_Bin_7;
	recFRInnoDriveOut->DePIF_MT_Bin_8 = flexrayOutput->DePIF_MT_Bin_8;
	recFRInnoDriveOut->DePIF_LT_Bin_0 = flexrayOutput->DePIF_LT_Bin_0;
	recFRInnoDriveOut->DePIF_LT_Bin_1 = flexrayOutput->DePIF_LT_Bin_1;
	recFRInnoDriveOut->DePIF_LT_Bin_2 = flexrayOutput->DePIF_LT_Bin_2;
	recFRInnoDriveOut->DePIF_LT_Bin_3 = flexrayOutput->DePIF_LT_Bin_3;
	recFRInnoDriveOut->DePIF_LT_Bin_4 = flexrayOutput->DePIF_LT_Bin_4;
	recFRInnoDriveOut->DePIF_LT_Bin_5 = flexrayOutput->DePIF_LT_Bin_5;
	recFRInnoDriveOut->DePIF_LT_Bin_6 = flexrayOutput->DePIF_LT_Bin_6;
	recFRInnoDriveOut->DePIF_LT_Bin_7 = flexrayOutput->DePIF_LT_Bin_7;
	recFRInnoDriveOut->DePIF_LT_Bin_8 = flexrayOutput->DePIF_LT_Bin_8;
#endif

#if ((100*IFSET_VERSION_VARIANT + 10*IFSET_VERSION_MAJOR + IFSET_VERSION_MINOR) >= 252)
	recFRInnoDriveOut->DePACC02_Event_aktiv = flexrayOutput->DePACC02_Event_aktiv ? 1u : 0u;
	recFRInnoDriveOut->DePACC02_Geschw_Vorausschau = flexrayOutput->DePACC02_Geschw_Vorausschau ? 1u : 0u;
	recFRInnoDriveOut->DePACC02_Offset_aktiv = flexrayOutput->DePACC02_Offset_Aktiv ? 1u : 0u;
	recFRInnoDriveOut->DePACC02_Offset_Anzeige = flexrayOutput->DePACC02_Offset_Anzeige;
#endif
	recFRInnoDriveOut->DePACC02_FoD_Status = flexrayOutput->DePACC02_FoD_Status;

	recFRInnoDriveOut->DePACC02_InnoDrive_Texte = flexrayOutput->DePACC02_InnoDrive_Texte;
	recFRInnoDriveOut->DePACC02_Hinweis_Geschw = flexrayOutput->DePACC02_Hinweis_Geschw ? 1u : 0u;
	recFRInnoDriveOut->DeTimestamp.DeTimestampMW_TX.DeTimestampHigh = uiPemControlTimeHigh;
	recFRInnoDriveOut->DeTimestamp.DeTimestampMW_TX.DeTimestampLow = uiPemControlTimeLow;
	recFRInnoDriveOut->DeTimestamp.DeTimestampMW_RX.DeTimestampHigh = 0xFF;
	recFRInnoDriveOut->DeTimestamp.DeTimestampMW_RX.DeTimestampLow = 0x00;
	recFRInnoDriveOut->DeTimestamp.DeTimestampZGT.DeTimestampHigh = innodriveControlOutTimestamp.DeTimestampHigh;
	recFRInnoDriveOut->DeTimestamp.DeTimestampZGT.DeTimestampLow = innodriveControlOutTimestamp.DeTimestampLow;
}
