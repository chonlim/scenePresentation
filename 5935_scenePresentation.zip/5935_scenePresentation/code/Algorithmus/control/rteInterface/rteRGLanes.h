#ifndef guard_rteRGLanes_h
#define guard_rteRGLanes_h

#include "Rte_Type.h"
#include "control/inputCodec/inputCodec_interface.h"


void		 rteInConvert_laneInput(IN	const	Dt_RECORD_GeometryLanes	*recRGLanes,
									OUT			laneInput_T				*laneInput);

#endif

