#ifndef guard_rteVZE_h
#define guard_rteVZE_h

#include "Rte_Type.h"
#include "control/inputCodec/inputCodec_interface.h"


void		  rteInConvert_vzeInput(IN	const	Dt_RECORD_VZE			*recVZE,
									OUT			vzeInput_T				*vzeInput);


#endif

