#include "control/rteInterface/rteCoding.h"
#include "control/inputCodec/inputCodec_private.h"


void		   rteInConvert_codingInput(IN	const	Dt_RECORD_Diag_Coding		*recCoding,
										OUT			codingInput_T				*codingInput)
{
	codingInput->DataValidFlag			= true;

	codingInput->FW_HAL					= recCoding->FW_HAL != 0u;
	codingInput->ID_Curve_Profile		= recCoding->ID_Curve_Profile;
	codingInput->ID_SpeedLimit_Profile	= recCoding->ID_SpeedLimit_Profile;
}
