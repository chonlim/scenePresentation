#include "control/rteInterface/rteFoDFunctionActivationState.h"
#include "control/inputCodec/inputCodec_private.h"


void		  rteInConvert_fodInput(IN	const	Dt_RECORD_FoDFunctionActivationState		*recFoDFunctionActivationState,
									OUT			fodInput_T									*fodInput)
{
	fodInput->DataValidFlag				= true;

	fodInput->DeFoDActivation_InnoDrive2	= recFoDFunctionActivationState->DeFoDActivation_InnoDrive2;
	fodInput->DeFoDFunctionRelevant			= recFoDFunctionActivationState->DeFoDFunctionRelevant != 0u;
}
