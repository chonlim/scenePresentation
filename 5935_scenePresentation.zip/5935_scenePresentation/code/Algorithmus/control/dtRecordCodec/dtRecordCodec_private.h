#ifndef __dtRecordCodec_private_h_
#define __dtRecordCodec_private_h_

#include "control\dtRecordCodec\dtRecordCodec_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */






/*lint -restore */

#endif
