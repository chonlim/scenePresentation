#ifdef USE_PSDEHR_LIB
#include "control/psdWrapper/ehrInterface.h"
#include "control/psdWrapper/eifSynchro.h"

#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_debug.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_construct_debug.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_event_debug.h"

#if comMULTITHREADAWARE

#define WIN32_LEAN_AND_MEAN

#pragma warning(push)
#pragma warning(disable:4668) /*'__midl' is not defined as a preprocessor macro, replacing with '0' for '#if/#elif'*/
#pragma warning(disable:4255) /* 'FARPROC' : no function prototype given: converting '()' to '(void)' */
#include <windows.h>
#pragma warning(pop)

struct _eifSynchronization {
	bool_T				init;
	CRITICAL_SECTION	eifAccess;
} eifSynchronization;


bool_T		   eifInitMutex(void)
{
	if(!eifSynchronization.init) {
		InitializeCriticalSection(&eifSynchronization.eifAccess);
		eifSynchronization.init = true;
	}

	return true;
}


bool_T		  eifEnterMutex(void)
{
	if(!eifSynchronization.init) {
		if(!eifInitMutex()) {
			return false;
		}
	}

	EnterCriticalSection(&eifSynchronization.eifAccess);

	return true;
}


bool_T		  eifLeaveMutex(void)
{
	LeaveCriticalSection(&eifSynchronization.eifAccess);

	return true;
}

#endif

bool_T		eifPushCoreData(IN			eifMemory_T		*eifMemory)
{
	if(PSD_EHR_ERROR_NO_ERROR != PsdEhr_SetCoreData(&eifMemory->coreData))  { return false; }
	if(PSD_EHR_ERROR_NO_ERROR != PsdEhr_SetEventUserDataPointer(eifMemory)) { return false; }

	return true;
}


bool_T		eifPullCoreData(INOUT		eifMemory_T		*eifMemory)
{
	const PsdEhr_CoreData_t		*ehrCoreData;

	if(PSD_EHR_ERROR_NO_ERROR != PsdEhr_GetCoreData(&ehrCoreData)) { return false; }

	eifMemory->coreData = *ehrCoreData;

	(void)PsdEhr_SetEventUserDataPointer(NULL);

	return true;
}


#endif