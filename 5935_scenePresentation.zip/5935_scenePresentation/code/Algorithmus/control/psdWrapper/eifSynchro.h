#ifndef guard_eifSynchro_h
#define guard_eifSynchro_h

#ifdef USE_PSDEHR_LIB

#include "base.h"
#include "control/psdWrapper/eifTypes.h"



#if comMULTITHREADAWARE
    bool_T		   eifInitMutex(void);


	bool_T		  eifEnterMutex(void);


	bool_T		  eifLeaveMutex(void);

#endif

	/*lint -esym(757,eifPushCoreData)*/
	bool_T		eifPushCoreData(IN			eifMemory_T		*eifMemory);

	/*lint -esym(757,eifPullCoreData)*/
	bool_T		eifPullCoreData(INOUT		eifMemory_T		*eifMemory);


#endif

#endif
