#ifdef USE_PSDEHR_LIB

#include "control/psdWrapper/psdWrapper.h"

#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_low.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_status.h"


bool_T				 psdwGetRgDatabaseMutex(OUT			bool_T							*swcMutexOK)
{
	/*Wenn wir die EHR-Bibliothek nutzen, m�ssen wir keinen Mutex beachten.*/
	*swcMutexOK = true;
	return true;
}

bool_T			 psdwReleaseRgDatabaseMutex(OUT			bool_T							*swcMutexOK)
{
	/*Wenn wir die EHR-Bibliothek nutzen, m�ssen wir keinen Mutex beachten.*/
	*swcMutexOK = true;
	return true;
}

static void		   psdCopyTreeConfiguration(IN	const	PsdEhr_TreeConfiguration_t		*ehrTreeConfiguration,
											OUT			psdTreeConfiguration_T			*psdTreeConfiguration)
{
	psdTreeConfiguration->configurationFlags1	= ehrTreeConfiguration->configurationFlags1;
	psdTreeConfiguration->configurationFlags2	= ehrTreeConfiguration->configurationFlags2;
	psdTreeConfiguration->maxAttributes			= ehrTreeConfiguration->maxAttributes;
	psdTreeConfiguration->maxSegments			= ehrTreeConfiguration->maxSegments;
	psdTreeConfiguration->maxSpeedLimits		= ehrTreeConfiguration->maxSpeedLimits;
	psdTreeConfiguration->treeVersionMajor		= ehrTreeConfiguration->treeVersionMajor;
	psdTreeConfiguration->treeVersionMinor		= ehrTreeConfiguration->treeVersionMinor;
}


bool_T			   psdwGetTreeConfiguration(OUT			psdTreeConfiguration_T			*psdTreeConfiguration)
{
	PsdEhr_Error_t				ehrResult;
	PsdEhr_TreeConfiguration_t	ehrTreeConfiguration;

	ehrResult = PsdEhr_GetTreeConfiguration(&ehrTreeConfiguration);
	psdCopyTreeConfiguration(&ehrTreeConfiguration, psdTreeConfiguration);

	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


bool_T						 psdwGetQuality(OUT			psdStatus_T						*psdStatus)
{
	PsdEhr_Error_t		ehrResult = PSD_EHR_ERROR_UNEXPECTED;
	PsdEhr_EhrStatus_t	ehrStatus = PSD_EHR_STATUS_PRE_INIT;

	ehrResult = PsdEhr_GetQuality(&ehrStatus);

	*psdStatus = (psdStatus_T)ehrStatus;
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


bool_T				 psdwGetTreeChangeCount(OUT			psdChangeCount_T				*changeCount)
{
	PsdEhr_Error_t		ehrResult = PSD_EHR_ERROR_UNEXPECTED;
	PsdEhr_ChangeCount_t	ehrChangeCount = 0u;

	ehrResult = PsdEhr_GetTreeChangeCount(&ehrChangeCount);

	*changeCount = (psdChangeCount_T)ehrChangeCount;
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


static void				  psdwCopySytemData(IN	const	PsdEhr_SystemData_t				*ehrSystemData,
											OUT			psdSystemData_T					*psdSystemData)
{
	psdSystemData->isRoutingActive		= ehrSystemData->isRoutingActive;
	psdSystemData->isRoutingChanged		= ehrSystemData->isRoutingChanged;		
	psdSystemData->qualityMapMatching	= ehrSystemData->qualityMapMatching;
}


bool_T					  psdwGetSystemData(OUT			psdSystemData_T					*systemData)
{
	PsdEhr_Error_t		ehrResult = PSD_EHR_ERROR_UNEXPECTED;
	PsdEhr_SystemData_t	ehrSystemData = {0};

	ehrResult = PsdEhr_GetSystemData(&ehrSystemData);

	psdwCopySytemData(&ehrSystemData, systemData);
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


static void				   psdwCopyPosition(IN	const	PsdEhr_Position_t				*ehrPosition,
											OUT			psdPosition_T					*psdPosition)
{
	psdPosition->id						= ehrPosition->id;						
	psdPosition->inhibitTime			= ehrPosition->inhibitTime;
	psdPosition->isLocationUnique		= ehrPosition->isLocationUnique;
	psdPosition->lane					= ehrPosition->lane;
	psdPosition->length					= ehrPosition->length;
	psdPosition->longitudinalError		= ehrPosition->longitudinalError;
}


bool_T					psdwGetPositionData(OUT			psdPosition_T					*position)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_Position_t ehrPosition;

	ehrResult = PsdEhr_GetPositionData(&ehrPosition);

	psdwCopyPosition(&ehrPosition, position);
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


static void				psdwCopyGpsPosition(IN	const	PsdEhr_GpsPosition_t			*ehrGpsPosition,
											OUT			psdGpsPosition_T				*psdGpsPosition)
{
	psdGpsPosition->altitude				= ehrGpsPosition->altitude;
	psdGpsPosition->heading					= ehrGpsPosition->heading;
	psdGpsPosition->latitude				= ehrGpsPosition->latitude;
	psdGpsPosition->longitude				= ehrGpsPosition->longitude;
	psdGpsPosition->referenceSegment		= ehrGpsPosition->referenceSegment;
}


bool_T						 psdwGetGpsData(OUT			psdGpsPosition_T				*gpsPosition)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_GpsPosition_t ehrGpsPosition;

	ehrResult = PsdEhr_GetGpsData(&ehrGpsPosition);

	psdwCopyGpsPosition(&ehrGpsPosition, gpsPosition);
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


bool_T					 psdwGetRootSegment(OUT			psdSegmentId_T					*idRoot)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_SegmentId_t ehrIdRoot;

	ehrResult = PsdEhr_GetRootSegment(&ehrIdRoot);

	*idRoot = (psdSegmentId_T)ehrIdRoot;
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


bool_T	 psdwGetRootTreeStateAttributeValue(IN	const	psdAttributeType_T				 type,
											OUT			psdAttributeValue_T				*value)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_AttributeValue_t ehrAttributeValue;

	ehrResult = PsdEhr_GetRootTreeStateAttributeValue((PsdEhr_AttributeType_t) type, &ehrAttributeValue);

	*value = (psdAttributeValue_T)ehrAttributeValue;
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


bool_T	psdwGetRootTreeStateSpeedLimitIndex(IN	const	psdSpeedLimitScope_T			 scope,
											IN	const	psdSpeedLimitOrigin_T			 origin,
											OUT			psdSpeedLimitIndex_T			*speedLimitIndex)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_SpeedLimitIndex_t ehrSpeedLimitIndex = 0u;

	ehrResult = PsdEhr_GetRootTreeStateSpeedLimitIndex((PsdEhr_SpeedLimitScope_t) scope, (PsdEhr_SpeedLimitOrigin_t) origin, &ehrSpeedLimitIndex);

	*speedLimitIndex = (psdSpeedLimitIndex_T)ehrSpeedLimitIndex;
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


static void					psdwCopySegment(IN	const	PsdEhr_Segment_t				*ehrSegment,
											OUT			psdSegment_T					*psdSegment)
{
	uint8_T index;

	psdSegment->attributeIndex					= ehrSegment->attributeIndex;

	psdSegment->attributes.isADASQuality		= ehrSegment->attributes.isADASQuality;
	psdSegment->attributes.isBuiltUpArea		= ehrSegment->attributes.isBuiltUpArea;
	psdSegment->attributes.isMostProbablePath	= ehrSegment->attributes.isMostProbablePath;
	psdSegment->attributes.isStraightestPath	= ehrSegment->attributes.isStraightestPath;
	psdSegment->attributes.lanes				= ehrSegment->attributes.lanes;
	psdSegment->attributes.ramp					= ehrSegment->attributes.ramp;
	psdSegment->attributes.streetClass			= ehrSegment->attributes.streetClass;

	psdSegment->completeFlags					= ehrSegment->completeFlags;
	psdSegment->geometry.branchAngle			= ehrSegment->geometry.branchAngle;
	psdSegment->geometry.curvatureEnd			= ehrSegment->geometry.curvatureEnd;
	psdSegment->geometry.curvatureStart			= ehrSegment->geometry.curvatureStart;
	psdSegment->geometry.length					= ehrSegment->geometry.length;

	psdSegment->id								= ehrSegment->id;
	psdSegment->identity						= ehrSegment->identity;
	psdSegment->parentId						= ehrSegment->parentId;
	psdSegment->speedLimitIndex					= ehrSegment->speedLimitIndex;

	psdSegment->childCount = 0u;
	for (index = 0u; index < (uint8_T)psdMAXCHILDRENCOUNT; index++)
	{
		psdSegment->childSegments[index]			= ehrSegment->childSegments[index];
		if (psdSegment->childSegments[index] != (psdSegmentId_T)PSD_EHR_SEGMENT_ID_INIT) 
		{ 
			psdSegment->childCount++; 
		}
	}
}


bool_T					 psdwGetSegmentData(IN const	psdSegmentId_T					 id,
											OUT			psdSegment_T					*segment)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_Segment_t ehrSegment = {0};

	ehrResult = PsdEhr_GetSegmentData((PsdEhr_SegmentId_t)id, &ehrSegment);

	psdwCopySegment(&ehrSegment, segment);
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


static void				  psdwCopyAttribute(IN	const	PsdEhr_Attribute_t				*ehrAttribute,
											OUT			psdAttribute_T					*psdAttribute)
{
	psdAttribute->nextAttribute			= ehrAttribute->nextAttribute;
	psdAttribute->offset				= ehrAttribute->offset;
	psdAttribute->type					= ehrAttribute->type;
	psdAttribute->value					= ehrAttribute->value;
}


bool_T				   psdwGetAttributeData(IN	const	psdAttributeIndex_T				 attributeIndex,
											OUT			psdAttribute_T					*attribute)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_Attribute_t ehrAttribute;

	ehrResult = PsdEhr_GetAttributeData((PsdEhr_AttributeIndex_t)attributeIndex, &ehrAttribute);

	psdwCopyAttribute(&ehrAttribute, attribute);
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}


static void				 psdwCopySpeedLimit(IN	const	PsdEhr_SpeedLimit_t				*ehrSpeedLimit,
											OUT			psdSpeedLimit_T					*psdSpeedLimit)
{
	psdSpeedLimit->nextSpeedLimit				=	ehrSpeedLimit->nextSpeedLimit;
	psdSpeedLimit->offset						=	ehrSpeedLimit->offset;
	psdSpeedLimit->type							=	ehrSpeedLimit->type;
	psdSpeedLimit->source						=	ehrSpeedLimit->source;
	psdSpeedLimit->speedLimitLower				=	ehrSpeedLimit->speedLimitLower;
	psdSpeedLimit->speedLimitUpper				=	ehrSpeedLimit->speedLimitUpper;
	psdSpeedLimit->speedLimitUnit				=	ehrSpeedLimit->speedLimitUnit;
	psdSpeedLimit->constraintLane				=	ehrSpeedLimit->constraintLane;
	psdSpeedLimit->constraintTrailer			=	ehrSpeedLimit->constraintTrailer;
	psdSpeedLimit->constraintWeather			=	ehrSpeedLimit->constraintWeather;
	psdSpeedLimit->constraintWeekDayStart		=	ehrSpeedLimit->constraintWeekDayStart;
	psdSpeedLimit->constraintWeekDayEnd			=	ehrSpeedLimit->constraintWeekDayEnd;
	psdSpeedLimit->constraintHourStart			=	ehrSpeedLimit->constraintHourStart;
	psdSpeedLimit->constraintHourEnd			=	ehrSpeedLimit->constraintHourEnd;
	psdSpeedLimit->constraintLegalStreetClass	=	ehrSpeedLimit->constraintLegalStreetClass;
	psdSpeedLimit->constraintLegalAddition		=	ehrSpeedLimit->constraintLegalAddition;
	psdSpeedLimit->variableMessageSign			=	ehrSpeedLimit->variableMessageSign;
	psdSpeedLimit->variableMessageSignType		=	ehrSpeedLimit->variableMessageSignType;
	psdSpeedLimit->noPassingSign				=	ehrSpeedLimit->noPassingSign;
}


bool_T				  psdwGetSpeedLimitData(IN	const	psdSpeedLimitIndex_T			 speedLimitIndex,
											IN	const	psdSpeedLimitUnit_T				 currentUnit,
											IN	const	psdSpeedLimitUnit_T				 requestedUnit,
											OUT			psdSpeedLimit_T					*speedLimit)
{
	PsdEhr_Error_t ehrResult;
	PsdEhr_SpeedLimit_t ehrSpeedLimit;

	ehrResult = PsdEhr_GetSpeedLimitData((PsdEhr_SpeedLimitIndex_t)speedLimitIndex, (PsdEhr_SpeedLimitUnit_t)currentUnit, (PsdEhr_SpeedLimitUnit_t)requestedUnit, &ehrSpeedLimit);

	psdwCopySpeedLimit(&ehrSpeedLimit, speedLimit);
	return PSD_EHR_IS_NO_ERROR(ehrResult) ? true : false; /*lint !e641*/
}

#endif /*USE_PSDEHR_LIB*/
