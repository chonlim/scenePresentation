#ifndef guard_ehrTypes_h
#define guard_ehrTypes_h

#ifdef USE_PSDEHR_LIB

/** \ingroup ehrInterface_types
	\{ */

#define ehrMAXMPPSEGMENTS		32		/* Includes current segment */
#define psdSEGMENTCOUNT			64

/*lint -save */
/*lint -e621 (Warning -- Identifier clash [Misra 2004 Rules 1.4 and 5.1]) */
/*lint -e912 (Note -- Implicit binary conversion from int to unsigned int) */
/*lint -e960 (Note -- Violates MISRA 2004 Required Rule 18.4, unions shall not be used) */
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_data.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_construct_types.h"
/*lint -restore */

#ifdef __cplusplus
using namespace psdehr;
#endif

typedef enum psdMessageType_tag {
	psdMessageNone,
	psdMessage4,
	psdMessage5,
	psdMessage6
} psdMessageType_T;


typedef struct psdInput_tag {
	psdMessageType_T	type;

	union {
		PsdEhr_Psd4Message_t	psd4;
		PsdEhr_Psd5Message_t	psd5;
		PsdEhr_Psd6Message_t	psd6;
	} data;
} psdInput_T;


/** "Arbeitsspeicher" von ehrInterface */
typedef struct _eifMemory
{
	uint8_T				ehrKnownMPPSegments[ehrMAXMPPSEGMENTS];
	uint16_T			lastMPPDeviations;

	bool_T				isEHRInitialized;

	uint32_T			uniqueID[psdSEGMENTCOUNT];
	uint32_T			nextUniqueID;

#if defined(__cplusplus)
	psdehr::PsdEhr_CoreData_t	coreData;
#else
	PsdEhr_CoreData_t	coreData;
#endif

} eifMemory_T;

/** \} */
#endif

#endif
