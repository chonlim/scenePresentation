#ifndef USE_PSDEHR_LIB

#include "control/psdWrapper/psdWrapper.h"
#include "Rte_CtApInnoDriveControl.h"

#if IFSET_VERSION_VARIANT >= 3 && !defined(_MSC_VER)
#include <SWCMutex.h>
#include <NonRteInterfaces.h>
bool_T				 psdwGetRgDatabaseMutex(OUT			bool_T							*swcMutexOK)
{
	e_swcmutex_return_type rgMutex;

	rgMutex = GetRGDatabaseMutex_InnoDriveControl();
	*swcMutexOK = (SWCMUTEX_OK == rgMutex) ? true : false;
	
	return rgMutex < SWCMUTEX_NOK_INVALID_ID;
}

bool_T			 psdwReleaseRgDatabaseMutex(OUT			bool_T							*swcMutexOK)
{
	e_swcmutex_return_type rgMutex;

	rgMutex = ReleaseRGDatabaseMutex_InnoDriveControl();
	*swcMutexOK = (SWCMUTEX_OK == rgMutex) ? true : false;
	
	return rgMutex < SWCMUTEX_NOK_INVALID_ID;
}
#else
bool_T				 psdwGetRgDatabaseMutex(OUT			bool_T							*swcMutexOK)
{
	*swcMutexOK = true;	
	return true;
}

bool_T			 psdwReleaseRgDatabaseMutex(OUT			bool_T							*swcMutexOK)
{
	*swcMutexOK = true;
	return true;
}
#endif

/*lint -save -e9026 (Note -- Function-like macro, 'IS_NO_PSD_EHR_ERROR', defined [MISRA 2012 Directive 4.9, advisory])*/
#define IS_NO_PSD_EHR_ERROR(X) ((X) == 0u)
#define IS_NO_RTE_ERROR(X) ((X) == RTE_E_OK)
/*lint -restore*/

/*lint -save -e9034 (Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required])*/

static void		   psdCopyTreeConfiguration(IN	const	Dt_RECORD_RGTreeConfiguration	*rgTreeConfiguration,
											OUT			psdTreeConfiguration_T			*psdTreeConfiguration)
{
	psdTreeConfiguration->configurationFlags1	= rgTreeConfiguration->DeConfigurationFlags1;
	psdTreeConfiguration->configurationFlags2	= rgTreeConfiguration->DeConfigurationFlags2;
	psdTreeConfiguration->maxAttributes			= rgTreeConfiguration->DeMaxAttributes;
	psdTreeConfiguration->maxSegments			= rgTreeConfiguration->DeMaxSegments;
	psdTreeConfiguration->maxSpeedLimits		= rgTreeConfiguration->DeMaxSpeedLimits;
	psdTreeConfiguration->treeVersionMajor		= rgTreeConfiguration->DeTreeVersionMajor;
	psdTreeConfiguration->treeVersionMinor		= rgTreeConfiguration->DeTreeVersionMinor;
}


bool_T			   psdwGetTreeConfiguration(OUT			psdTreeConfiguration_T			*psdTreeConfiguration)
{
	uint8_T			errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGTreeConfiguration rgTreeConfiguration;

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetTreeConfiguration(&errorCode, &rgTreeConfiguration);
	psdCopyTreeConfiguration(&rgTreeConfiguration, psdTreeConfiguration);

	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/
}


bool_T						 psdwGetQuality(OUT			psdStatus_T						*psdStatus)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	uint8_T ehrStatus;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetQuality(&errorCode, &ehrStatus);

	*psdStatus = (psdStatus_T)ehrStatus;
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


bool_T				 psdwGetTreeChangeCount(OUT			psdChangeCount_T				*changeCount)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	uint16_T rgChangeCount;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetTreeChangeCount(&errorCode, &rgChangeCount);

	*changeCount = (psdChangeCount_T)rgChangeCount;
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


static void				  psdwCopySytemData(IN	const	Dt_RECORD_RGSystemData			*rgSystemData,
											OUT			psdSystemData_T					*psdSystemData)
{
	psdSystemData->isRoutingActive		= rgSystemData->DeIsRoutingActive;
	psdSystemData->isRoutingChanged		= rgSystemData->DeIsRoutingChanged;
	psdSystemData->qualityMapMatching	= rgSystemData->DeQualityMapMatching;
}


bool_T					  psdwGetSystemData(OUT			psdSystemData_T					*systemData)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGSystemData rgSystemData;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSystemData(&errorCode, &rgSystemData);

	psdwCopySytemData(&rgSystemData, systemData);
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


static void				   psdwCopyPosition(IN	const	Dt_RECORD_RGPosition			*rgPosition,
											OUT			psdPosition_T					*psdPosition)
{
	psdPosition->id						= rgPosition->DeId;						
	psdPosition->inhibitTime			= rgPosition->DeInhibitTime;
	psdPosition->isLocationUnique		= rgPosition->DeIsLocationUnique;
	psdPosition->lane					= rgPosition->DeLane;
	psdPosition->length					= rgPosition->DeLength;
	psdPosition->longitudinalError		= rgPosition->DeLongitudinalError;
}


bool_T psdwGetPositionData(					OUT			psdPosition_T					*position)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGPosition rgPosition;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetPositionData(&errorCode, &rgPosition);

	psdwCopyPosition(&rgPosition, position);
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


static void				psdwCopyGpsPosition(IN	const	Dt_RECORD_RGGpsPosition			*rgGpsPosition,
											OUT			psdGpsPosition_T				*psdGpsPosition)
{
	psdGpsPosition->altitude				= rgGpsPosition->DeAltitude;
	psdGpsPosition->heading					= rgGpsPosition->DeHeading;
	psdGpsPosition->latitude				= rgGpsPosition->DeLatitude;
	psdGpsPosition->longitude				= rgGpsPosition->DeLongitude;
	psdGpsPosition->referenceSegment		= rgGpsPosition->DeReferenceSegment;
}


bool_T						 psdwGetGpsData(OUT			psdGpsPosition_T				*gpsPosition)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGGpsPosition rgGpsPosition;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetGpsData(&errorCode, &rgGpsPosition);

	psdwCopyGpsPosition(&rgGpsPosition, gpsPosition);
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


bool_T					 psdwGetRootSegment(OUT			psdSegmentId_T					*idRoot)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	uint8_T rgIdRoot;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootSegment(&errorCode, &rgIdRoot);

	*idRoot = (psdSegmentId_T)rgIdRoot;
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


bool_T	 psdwGetRootTreeStateAttributeValue(IN	const	psdAttributeType_T				 type,
											OUT			psdAttributeValue_T				*value)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	uint16_T rgValue;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootTreeStateAttributeValue(&errorCode, (uint8_T)type, &rgValue);

	*value = (psdAttributeValue_T)rgValue;
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


bool_T	psdwGetRootTreeStateSpeedLimitIndex(IN	const	psdSpeedLimitScope_T			 scope,
											IN	const	psdSpeedLimitOrigin_T			 origin,
											OUT			psdSpeedLimitIndex_T			*speedLimitIndex)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	uint16_T rgSpeedLimitIndex;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootTreeStateSpeedLimitIndex(&errorCode, (uint8_T)scope, (uint8_T)origin,&rgSpeedLimitIndex);

	*speedLimitIndex = (psdSpeedLimitIndex_T)rgSpeedLimitIndex;
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


static void					psdwCopySegment(IN	const	Dt_RECORD_RGSegment				*rgSegment,
											OUT			psdSegment_T					*psdSegment)
{
	uint8_T index;

	psdSegment->attributeIndex					= rgSegment->DeAttributeIndex;
	psdSegment->attributes.isADASQuality		= rgSegment->DeAttributes.DeIsADASQuality;
	psdSegment->attributes.isBuiltUpArea		= rgSegment->DeAttributes.DeIsBuiltUpArea;
	psdSegment->attributes.isMostProbablePath	= rgSegment->DeAttributes.DeIsMostProbablePath;
	psdSegment->attributes.isStraightestPath	= rgSegment->DeAttributes.DeIsStraightestPath;
	psdSegment->attributes.lanes				= rgSegment->DeAttributes.DeLanes;
	psdSegment->attributes.ramp					= rgSegment->DeAttributes.DeRamp;
	psdSegment->attributes.streetClass			= rgSegment->DeAttributes.DeStreetClass;
	psdSegment->completeFlags					= rgSegment->DeCompleteFlags;
	psdSegment->geometry.branchAngle			= rgSegment->DeGeometry.DeBranchAngle;
	psdSegment->geometry.curvatureEnd			= rgSegment->DeGeometry.DeCurvatureEnd;
	psdSegment->geometry.curvatureStart			= rgSegment->DeGeometry.DeCurvatureStart;
	psdSegment->geometry.length					= rgSegment->DeGeometry.DeLength;
	psdSegment->id								= rgSegment->DeId;
	psdSegment->identity						= rgSegment->DeIdentity;
	psdSegment->parentId						= rgSegment->DeParentId;
	psdSegment->speedLimitIndex					= rgSegment->DeSpeedLimitIndex;

	psdSegment->childCount = 0u;
	for (index = 0u; index < (uint8_T)psdMAXCHILDRENCOUNT; index++)
	{
		psdSegment->childSegments[index]			= rgSegment->DeChildSegments[index];
        if (psdSegment->childSegments[index] != (psdSegmentId_T)0x0) 
		{ 
			psdSegment->childCount++; 
		}
	}
}


bool_T					 psdwGetSegmentData(IN	const	psdSegmentId_T					 id,
											OUT			psdSegment_T					*segment)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGSegment rgSegment;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSegmentData(&errorCode, (uint8_T)id, &rgSegment);

	psdwCopySegment(&rgSegment, segment);
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


static void				  psdwCopyAttribute(IN	const	Dt_RECORD_RGAttribute			*rgAttribute,
											OUT			psdAttribute_T					*psdAttribute)
{
	psdAttribute->nextAttribute			= rgAttribute->DeNextAttribute;
	psdAttribute->offset				= rgAttribute->DeOffset;
	psdAttribute->type					= rgAttribute->DeType;
	psdAttribute->value					= rgAttribute->DeValue;
}


bool_T				   psdwGetAttributeData(IN	const	psdAttributeIndex_T				 attributeIndex,
											OUT			psdAttribute_T					*attribute)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGAttribute rgAttribute;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetAttributeData(&errorCode, (uint16_T)attributeIndex, &rgAttribute);

	psdwCopyAttribute(&rgAttribute, attribute);
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}


static void				 psdwCopySpeedLimit(IN	const	Dt_RECORD_RGSpeedLimit			*rgSpeedLimit,
											OUT			psdSpeedLimit_T					*psdSpeedLimit)
{
	psdSpeedLimit->nextSpeedLimit				=	rgSpeedLimit->DeNextSpeedLimit;
	psdSpeedLimit->offset						=	rgSpeedLimit->DeOffset;
	psdSpeedLimit->type							=	rgSpeedLimit->DeType;
	psdSpeedLimit->source						=	rgSpeedLimit->DeSource;
	psdSpeedLimit->speedLimitLower				=	rgSpeedLimit->DeSpeedLimitLower;
	psdSpeedLimit->speedLimitUpper				=	rgSpeedLimit->DeSpeedLimitUpper;
	psdSpeedLimit->speedLimitUnit				=	rgSpeedLimit->DeSpeedLimitUnit;
	psdSpeedLimit->constraintLane				=	rgSpeedLimit->DeConstraintLane;
	psdSpeedLimit->constraintTrailer			=	rgSpeedLimit->DeConstraintTrailer;
	psdSpeedLimit->constraintWeather			=	rgSpeedLimit->DeConstraintWeather;
	psdSpeedLimit->constraintWeekDayStart		=	rgSpeedLimit->DeConstraintWeekDayStart;
	psdSpeedLimit->constraintWeekDayEnd			=	rgSpeedLimit->DeConstraintWeekDayEnd;
	psdSpeedLimit->constraintHourStart			=	rgSpeedLimit->DeConstraintHourStart;
	psdSpeedLimit->constraintHourEnd			=	rgSpeedLimit->DeConstraintHourEnd;
	psdSpeedLimit->constraintLegalStreetClass	=	rgSpeedLimit->DeConstraintLegalStreetClass;
	psdSpeedLimit->constraintLegalAddition		=	rgSpeedLimit->DeConstraintLegalAddition;
	psdSpeedLimit->variableMessageSign			=	rgSpeedLimit->DeVariableMessageSign;
	psdSpeedLimit->variableMessageSignType		=	rgSpeedLimit->DeVariableMessageSignType;
	psdSpeedLimit->noPassingSign				=	rgSpeedLimit->DeNoPassingSign;
}


bool_T				  psdwGetSpeedLimitData(IN	const	psdSpeedLimitIndex_T			 speedLimitIndex,
											IN	const	psdSpeedLimitUnit_T				 currentUnit,
											IN	const	psdSpeedLimitUnit_T				 requestedUnit,
											OUT			psdSpeedLimit_T					*speedLimit)
{
	uint8_T errorCode;
	Std_ReturnType	rteResult;
	Dt_RECORD_RGSpeedLimit rgSpeedLimit;
	

	rteResult = Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSpeedLimitData(&errorCode, (uint16_T)speedLimitIndex, (uint8_T)currentUnit, (uint8_T)requestedUnit, &rgSpeedLimit);

	psdwCopySpeedLimit(&rgSpeedLimit, speedLimit);
	return IS_NO_PSD_EHR_ERROR(errorCode) && IS_NO_RTE_ERROR(rteResult) ? true : false; /*lint !e641*/ 
}

/*lint -restore*/
#else
; /*Unterdr�ckt die Compilerwarnung wegen einer leeren Datei.*/
#endif /*USE_PSDEHR_LIB*/
