#ifndef guard_psdWrapper_h
#define guard_psdWrapper_h

#include "control/control.h"
#include "common/psdWrapperCommon/psdWrapper_interface.h"


/** \brief Lock the RG Database Mutex

\spec SwMS_Innodrive2_Input_1454
*/
bool_T				 psdwGetRgDatabaseMutex(OUT			bool_T							*swcMutexOK);

/** \brief Release the RG Database Mutex

\spec SwMS_Innodrive2_Input_1454
*/
bool_T			 psdwReleaseRgDatabaseMutex(OUT			bool_T							*swcMutexOK);


/** \brief Get the PSD tree configuration

This function returns the configuration of the PSD tree.

\param[out]    psdTreeConfiguration    Tree configuration

\spec SwMS_Innodrive2_Input_264
*/
bool_T			   psdwGetTreeConfiguration(OUT			psdTreeConfiguration_T			*psdTreeConfiguration
											);


/** \brief  Get the status of the Ehr Module.
  
This function provides the state of the Ehr Module. Only in state \ref PSD_EHR_STATUS_VALID
a tree is available.   
\param[out]   psdStatus    Reconstructor state. For possible values see \ref PsdEhr_EhrStatusValues_t
\return       Standard Error Code.
\spec SwMS_Innodrive2_Input_264
*/
bool_T						 psdwGetQuality(OUT			psdStatus_T						*psdStatus
											);



/** \brief  Get the change counter of the Ehr Module.

This function provides a change counter. Every cycle the tree changes this counter is
incremented. With its help applications can check if they have to process the electronic
horizon again.
\param[out]    changeCount    Pointer to resulting change counter.
\return        Standard Error Code. See \ref PsdEhr_ErrorValues for possible values.
\spec SwMS_Innodrive2_Input_264
 */
bool_T				 psdwGetTreeChangeCount(OUT			psdChangeCount_T				*changeCount
											);



/**\brief Get system data of the PSD tree

This function returns the tree dependent system data of the PSD tree. For segment dependent system
data you have to search the attributes of the affected segment.
If no tree is available the error code \ref PSD_EHR_ERROR_INIT is returned as return value and the content
of \c systemData is not defined. 
\param[out]    systemData    Data of the PSD tree
\return        Standard Error Code. See \ref PsdEhr_ErrorValues for possible values.
\spec SwMS_Innodrive2_Input_264
*/
bool_T					  psdwGetSystemData(OUT			psdSystemData_T					*systemData
											);


/**\brief  Get position data of the PSD tree

This function returns the position data of the PSD tree if a tree is available. If no tree is available
the error code \ref PSD_EHR_ERROR_INIT is returned as return value and the content of \c position
is not defined. 
\param[out]    position    Position data of the PSD tree
\return        Standard Error Code. See \ref PsdEhr_ErrorValues for possible values.
\spec SwMS_Innodrive2_Input_264
*/
bool_T					psdwGetPositionData(OUT			psdPosition_T					*position
											);

/**\brief Get GPS data of the PSD tree
This function returns the GPS position data of the PSD tree  
\b Attention: This GPS should be also available if the tree is in init state. You have to validate
the contained data yourself.
\param[out]    gpsPosition    Position data of the PSD tree
\return        Standard Error Code. See \ref PsdEhr_ErrorValues for possible values.
\spec SwMS_Innodrive2_Input_264
*/
bool_T						 psdwGetGpsData(OUT			psdGpsPosition_T				*gpsPosition
											);

/**\brief Get it of the PSD tree root segment

This function returns the id of the tree root segment if a tree is available. If no tree is available
the error code \ref PSD_EHR_ERROR_INIT is returned as return value and \c idRoot is set to PSD_EHR_SEGMENT_ID_INIT.
\spec SwMS_Innodrive2_Input_264
*/
bool_T					 psdwGetRootSegment(OUT			psdSegmentId_T					*idRoot
											);

/**\brief Get attribute values from the root tree state
 
This function retrieves a (system) attribute or slope value from the root tree state.
 
The root tree state collects the last values of ranged attributes, system attribute and slopes
that were in effect last prior to the root segment. This assures that nothing needed (e.g. the
begin of a ranged attribute) drops out at the end of the tree.
\spec SwMS_Innodrive2_Input_264
*/
bool_T	 psdwGetRootTreeStateAttributeValue(IN	const	psdAttributeType_T				 type,
											OUT			psdAttributeValue_T				*value
											);

/**\brief Get a speed limit index from the root tree state.
  
This function retrieves the index of a (legal) speed limit from the root tree state.
  
The root tree state collects the last values of speed limits and legal speed limits
that were in effect last prior to the root segment. This assures that nothing needed (e.g. the
begin of a ranged attribute) drops out at the end of the tree.
  
See the description of the type \ref PsdEhr_SpeedLimitIndex_t to get more information about the concept of
speed limits and speed limit lists in the PSD Ehr. Remember several speed limits (with different constraints) can
be in effect at the same time. So it is not uncommon that root state contains a list of speed limits 
for each scope and origin.
\spec SwMS_Innodrive2_Input_264
*/
bool_T	psdwGetRootTreeStateSpeedLimitIndex(IN	const	psdSpeedLimitScope_T			 scope,
											IN	const	psdSpeedLimitOrigin_T			 origin,
											OUT			psdSpeedLimitIndex_T			*speedLimitIndex
											);


/**\brief Get segment data of the given id. 
This function returns the segment data of the segment with the given \c id.
If the segment is not available in the tree the error code \ref PSD_EHR_ERROR_NOT_AVAILABLE is
returned. In this case it is only assured that the members \ref PsdEhr_Segment_t#id and
\ref PsdEhr_Segment_t::parentId of the returned \c segment are equal PSD_EHR_SEGMENT_ID_INIT.
If no tree is available the error code \ref PSD_EHR_ERROR_INIT is returned as return value
and the content of \c segment is not defined. 
\param[in]     id         Id of the segment to get data of. Valid are only ids between \ref PSD_EHR_SEGMENT_ID_MIN
                        and \ref PSD_EHR_SEGMENT_ID_MAX (both inclusive).
\param[out]    segment    Segment data of the given \c id.
\return    Standard Error Code. See \ref PsdEhr_ErrorValues for possible values.
\spec SwMS_Innodrive2_Input_264
*/
bool_T					 psdwGetSegmentData(IN	const	psdSegmentId_T					 id,
											OUT			psdSegment_T					*segment
											);


/**\brief Get the attribute data of the given index
  
This function returns the \c attribute data of the given \c index.
  
If no tree is available the error code \ref PSD_EHR_ERROR_INIT is returned as return value and the content
of \c attribute is not defined.
  
See the description of the type \ref PsdEhr_Attribute_t to get more information about the concept of
attributes and attribute lists in the PSD Ehr. Remember system attributes and slopes
are also represented as attributes.
\spec SwMS_Innodrive2_Input_264
*/
bool_T				   psdwGetAttributeData(IN	const	psdAttributeIndex_T				 attributeIndex,
											OUT			psdAttribute_T					*attribute
											);

/**\brief Get the speed limit data of the given index
  
This function returns the \c speedLimit data of the given \c index.
  
If no tree is available the error code \ref PSD_EHR_ERROR_INIT is returned as return value and the content
of \c speedLimit is not defined.
  
See the description of the type \ref PsdEhr_SpeedLimitIndex_t to get more information about the concept of
speed limits and speed limit in the PSD Ehr. Remember legal speed limits are also represented as speed limits.
  
The unit of the result is determined by the parameter \c requestedUnit. You can either specify a unit directly
and all values will be converted (\ref PSD_EHR_SPEED_LIMIT_UNIT_KMH, \ref PSD_EHR_SPEED_LIMIT_UNIT_MPH) or 
accept the native unit (\ref PSD_EHR_SPEED_LIMIT_UNIT_LOCAL).
\spec SwMS_Innodrive2_Input_264
*/
bool_T				  psdwGetSpeedLimitData(IN	const	psdSpeedLimitIndex_T			 speedLimitIndex,
											IN	const	psdSpeedLimitUnit_T				 currentUnit,
											IN	const	psdSpeedLimitUnit_T				 requestedUnit,
											OUT			psdSpeedLimit_T					*speedLimit
											);	


#endif /*__PSDWRAPPER_H_*/
