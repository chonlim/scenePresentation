#include "base.h"


#ifndef USE_PSDEHR_LIB
#define USE_PSDEHR_LIB
#endif

#include "control/psdWrapper/eifTypes.h"

#define USE_NEW_MPP

#ifndef guard_ehrInterface_h
#define guard_ehrInterface_h


/*lint -esym(765, eifInterface)*/
bool_T	   eifInterface(MEMORY		eifMemory_T		*eifMemory,
						IN			uint8_T			 isNewMessage,
						IN			uint16_T		 inMessageID,
						IN			uint8_T			 inCanByte0,
						IN			uint8_T			 inCanByte1,
						IN			uint8_T			 inCanByte2,
						IN			uint8_T			 inCanByte3,
						IN			uint8_T			 inCanByte4,
						IN			uint8_T			 inCanByte5,
						IN			uint8_T			 inCanByte6,
						IN			uint8_T			 inCanByte7);


bool_T		   eifInput(MEMORY		eifMemory_T		*eifMemory,
						IN	const	psdInput_T		*input);


/* psdPath */
typedef struct _psdPath
{
	uint8_T		Status;
	uint8_T		segmentID[ehrMAXMPPSEGMENTS];
	uint8_T		segmentCount;

} psdPath_T;

uint8_T		eifMakeSureEHRIsInitialized(MEMORY eifMemory_T		*eifMemory);




#endif
