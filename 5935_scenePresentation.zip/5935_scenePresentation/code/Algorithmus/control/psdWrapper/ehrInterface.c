#ifdef USE_PSDEHR_LIB
/** \file ehrInterface.c
	
	\ingroup environmentFusion 
	\{
		\defgroup ehrInterface ehrInterface
		Stellt die Kommunikation zwischen PSD-CAN Schnittstelle und dem EHR zur Verf�gung. 
		Liest relevante Karteninformationen aus dem EHR aus und stellt sie dem Restsystem zur Verf�gung (`mapTree`).
		\{
			\defgroup	ehrInterface_step		Step
			Update-Funktionen, des EHR Interface, die zyklisch vom Rahmensystem aufgerufen werden.
			
			\defgroup	ehrInterface_internal	Internal
			Interne Verarbeitung der EHR Interface
			
			\defgroup	ehrInterface_api		API
			API, die vom ehrInterface bereitgestellt wird, um auf Karteninformationen zuzugreifen.

			\defgroup	ehrInterface_types		Types
			API, die vom ehrInterface bereitgestellt wird, um auf Karteninformationen zuzugreifen.
		\}
	\}

	\typedef	mapTree_T
	\ingroup	ehrInterface_types
			
	\struct		_mapTree
	\ingroup	ehrInterface_types
			
	\typedef	psdPath_T
	\ingroup	ehrInterface_types

	\struct		_psdPath
	\ingroup	ehrInterface_types
	*/

#include <math.h>
#include <string.h>
#include "ehrInterface.h"

#include "Lib/EHR/PSD_EHR/include/psd_ehr_construct_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_debug.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_high.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_low.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_ranged.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_construct.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_construct_debug.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_construct_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_control.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_data.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_diagnosis.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_event.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_event_debug.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_event_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_status.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_status_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_tree_types.h"

#include "common/platformInterface/pltfDiag.h"

static void	eifErrorCallbackEntry(PsdEhr_ErrorCode_t errorCode, void* const userData);
static void	eifEventCallbackEntry(PsdEhr_EventCode_t eventCode, PsdEhr_EventSubCode_t eventSubCode, PsdEhr_SegmentId_t segment, void * const userData);


/** \brief		"F�ttert" eine CAN-Botschaft an den EHR. 
	\ingroup	ehrInterface_step
	\todo		`isNewMessage` und unn�tigen `eifMemory->cycleState` entfernen */
bool_T	   eifInterface(MEMORY	eifMemory_T		*eifMemory,
						IN		uint8_T			 isNewMessage,		/*<! Gibt an, ob die Botschaft neu ist; bei `false` wird der Aufruf ignoriert. \deprecated{ Das ist eigentlich Unsinn und sollte entfernt werden}.*/
						IN		uint16_T		 inMessageID,
						IN		uint8_T			 inCanByte0,
						IN		uint8_T			 inCanByte1,
						IN		uint8_T			 inCanByte2,
						IN		uint8_T			 inCanByte3,
						IN		uint8_T			 inCanByte4,
						IN		uint8_T			 inCanByte5,
						IN		uint8_T			 inCanByte6,
						IN		uint8_T			 inCanByte7)
{
	PsdEhr_Error_t	returnValue;

	if (eifMakeSureEHRIsInitialized(eifMemory)) { return false; }

	if(isNewMessage) {

		/* PSD_04*/
		if(inMessageID == 1122) {
			PsdEhr_Psd4Message_t psdMsg04;

			psdMsg04.id					= ((inCanByte0 & 0x3F) >> 0);
			psdMsg04.parentId			= ((inCanByte0 & 0xC0) >> 6) | ((inCanByte1 & 0x0F) << 2);
			psdMsg04.length				= ((inCanByte1 & 0xF0) >> 4) | ((inCanByte2 & 0x07) << 4);
			psdMsg04.streetClass		= ((inCanByte2 & 0x38) >> 3);
			psdMsg04.curvatureEnd		= ((inCanByte2 & 0xC0) >> 6) | ((inCanByte3 & 0x3F) << 2);
			psdMsg04.curvatureEndSign	= ((inCanByte3 & 0x40) >> 6);
			psdMsg04.identity			= ((inCanByte3 & 0x80) >> 7) | ((inCanByte4 & 0x1F) << 1);
			psdMsg04.isADASQuality		= ((inCanByte4 & 0x20) >> 5);
			psdMsg04.isMostProbablePath	= ((inCanByte4 & 0x40) >> 6);
			psdMsg04.isStraightestPath	= ((inCanByte4 & 0x80) >> 7);
			psdMsg04.lanes				= ((inCanByte5 & 0x07) >> 0);
			psdMsg04.isBuiltUpArea		= ((inCanByte5 & 0x08) >> 3);
			psdMsg04.completeFlag		= ((inCanByte5 & 0x10) >> 4);
			psdMsg04.ramp				= ((inCanByte5 & 0x60) >> 5);
			psdMsg04.curvatureStart		= ((inCanByte5 & 0x80) >> 7) | ((inCanByte6 & 0x7F) << 1);
			psdMsg04.curvatureStartSign	= ((inCanByte6 & 0x80) >> 7);
			psdMsg04.branchDirection	= ((inCanByte7 & 0x01) >> 0);
			psdMsg04.branchAngle		= ((inCanByte7 & 0xFE) >> 1);

			returnValue = PsdEhr_AcceptPsd04(&psdMsg04);
			
			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd04() reporting error.");
			}
		}

		/* PSD_05 */
		if(inMessageID == 1123) {
			PsdEhr_Psd5Message_t psdMsg05;

			psdMsg05.positionId					= ((inCanByte0 & 0x3F) >> 0);
			psdMsg05.positionLength				= ((inCanByte0 & 0xC0) >> 6) | ((inCanByte1 & 0x1F) << 2);
			psdMsg05.positionInhibitTime		= ((inCanByte1 & 0xE0) >> 5) | ((inCanByte2 & 0x03) << 3);
			psdMsg05.positionIsLocationUnique	= ((inCanByte2 & 0x04) >> 2);
			psdMsg05.positionLongitudinalError	= ((inCanByte2 & 0x38) >> 3);
			psdMsg05.positionLane				= ((inCanByte2 & 0xC0) >> 6) | ((inCanByte3 & 0x01) << 2);
			psdMsg05.attributesSegmentId		= ((inCanByte3 & 0x7E) >> 1);
			psdMsg05.attribute1Type				= ((inCanByte3 & 0x80) >> 7) | ((inCanByte4 & 0x0F) << 1);
			psdMsg05.attribute1Value			= ((inCanByte4 & 0xF0) >> 4);
			psdMsg05.attribute1Offset			= ((inCanByte5 & 0x7F) >> 0);
			psdMsg05.attribute2Type				= ((inCanByte5 & 0x80) >> 7) | ((inCanByte6 & 0x0F) << 1);
			psdMsg05.attribute2Value			= ((inCanByte6 & 0xF0) >> 4);
			psdMsg05.attribute2Offset			= ((inCanByte7 & 0x7F) >> 0);
			psdMsg05.completeFlag				= ((inCanByte7 & 0x80) >> 7);

			returnValue = PsdEhr_AcceptPsd05(&psdMsg05);
			
			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd05() reporting error.");
			}
		}

		/* PSD_06 */
		if(inMessageID == 1124) {

			if((inCanByte0 & 0x07) == 0) {
				PsdEhr_Psd60Message_t psdMsg060;

				psdMsg060.id							= ((inCanByte0 & 0xF8) >> 3) | ((inCanByte1 & 0x01) << 5);
				psdMsg060.countryCode					= ((inCanByte1 & 0xFE) >> 1) | ((inCanByte2 & 0x01) << 7);
				psdMsg060.unitSpeed						= ((inCanByte2 & 0x02) >> 1);
				psdMsg060.trafficDirection				= ((inCanByte2 & 0x04) >> 2);
				psdMsg060.qualityGeometry				= ((inCanByte2 & 0x18) >> 3);
				psdMsg060.qualityMapMatching			= ((inCanByte2 & 0x60) >> 5);
				psdMsg060.ageMapData					= ((inCanByte2 & 0x80) >> 7) | ((inCanByte3 & 0x03) << 1);
				psdMsg060.isRoutingActive				= ((inCanByte3 & 0x04) >> 2);
				psdMsg060.usStateCode					= ((inCanByte3 & 0xF8) >> 3) | ((inCanByte4 & 0x01) << 5);

#if defined(PSD_EHR_SYSTEM_VERSION_USED) && (PSD_EHR_SYSTEM_VERSION_USED == PSD_EHR_SYSTEM_VERSION_152)
				psdMsg060.isRoutingChanged				= ((inCanByte4 & 0x80) >> 7);
				psdMsg060.qualityGeometryExt			= ((inCanByte5 & 0xFF) >> 0);

				psdMsg060.regionQualiGeometry			= ((inCanByte4 & 0x0E) >> 1);
				psdMsg060.regionQualiPlaceInfo			= ((inCanByte4 & 0x30) >> 4);
				psdMsg060.regionQualiAvailable			= ((inCanByte4 & 0x40) >> 6);
				psdMsg060.regionQualiSpecialInfo		= ((inCanByte6 & 0x07) >> 0);
				psdMsg060.regionQualiSlope				= ((inCanByte6 & 0x38) >> 3);
				psdMsg060.regionQualiStreetLabel		= ((inCanByte6 & 0xC0) >> 6) | ((inCanByte7 & 0x01 << 2));
				psdMsg060.regionQualiSpeedLimit			= ((inCanByte7 & 0x0E) >> 1);
				psdMsg060.regionQualiRightOfWayRules	= ((inCanByte7 & 0x70) >> 4);
#endif

				returnValue = PsdEhr_AcceptPsd06m00(&psdMsg060);
			
				if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
					diagLogInfo("PsdEhr_AcceptPsd06m00() reporting error.");
				}
			}

			if((inCanByte0 & 0x07) == 1) {
				PsdEhr_Psd61Message_t psdMsg061 = {0};

				psdMsg061.attributesSegmentId	= ((inCanByte0 & 0xF8) >> 3) | ((inCanByte1 & 0x01) << 5);
				psdMsg061.attribute1Type		= ((inCanByte1 & 0x3E) >> 1);
				/* ALT:	psdMsg061.attribute1Value		= ((inCanByte1 & 0xC0) >> 6) | ((inCanByte2 & 0x03) << 2);*/
				/* ALT:	psdMsg061.attribute1Offset		= ((inCanByte2 & 0xFC) >> 2) | ((inCanByte3 & 0x01) << 6);*/
				psdMsg061.attribute1Value		= ((inCanByte2 & 0xE0) >> 5) | ((inCanByte3 & 0x01) << 3);/**< PSD_06.PSD_Attribut_3_Wert */
				psdMsg061.attribute1Offset		= ((inCanByte1 & 0xC0) >> 6) | ((inCanByte2 & 0x1F) << 2);/**< PSD_06.PSD_Attribut_3_Offset */
				psdMsg061.attribute2Type		= ((inCanByte3 & 0x3E) >> 1);
				psdMsg061.attribute2Value		= ((inCanByte3 & 0xC0) >> 6) | ((inCanByte4 & 0x03) << 2);
				psdMsg061.attribute2Offset		= ((inCanByte4 & 0xFC) >> 2) | ((inCanByte5 & 0x01) << 6);
				psdMsg061.attribute3Type		= ((inCanByte5 & 0x3E) >> 1);
				/* ALT:	psdMsg061.attribute3Value		= ((inCanByte5 & 0xC0) >> 6) | ((inCanByte6 & 0x03) << 2);*/
				/* ALT:	psdMsg061.attribute3Offset		= ((inCanByte6 & 0xFC) >> 2) | ((inCanByte7 & 0x01) << 6);*/
				psdMsg061.attribute3Value		= ((inCanByte6 & 0xE0) >> 5) | ((inCanByte7 & 0x01) << 3);/**< PSD_06.PSD_Attribut_5_Wert */
				psdMsg061.attribute3Offset		= ((inCanByte5 & 0xC0) >> 6) | ((inCanByte6 & 0x1F) << 2);/**< PSD_06.PSD_Attribut_5_Offset */
				psdMsg061.completeFlag			= ((inCanByte7 & 0x02) >> 1);

				returnValue = PsdEhr_AcceptPsd06m01(&psdMsg061);
			
				if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
					diagLogInfo("PsdEhr_AcceptPsd06m01() reporting error.");
				}
			}

			if((inCanByte0 & 0x07) == 2) {
				PsdEhr_Psd62Message_t psdMsg062;

				psdMsg062.id							= ((inCanByte0 & 0xF8) >> 3) | ((inCanByte1 & 0x01) << 5);
				psdMsg062.offset						= ((inCanByte1 & 0xFE) >> 1);
				psdMsg062.speedLimit					= ((inCanByte2 & 0x1F) >> 0);
				psdMsg062.type							= ((inCanByte2 & 0x60) >> 5);
				psdMsg062.constraintLane				= ((inCanByte2 & 0x80) >> 7) | ((inCanByte3 & 0x1F) << 1);
				psdMsg062.constraintTrailer				= ((inCanByte3 & 0x60) >> 5);
				psdMsg062.constraintWeather				= ((inCanByte3 & 0x80) >> 7) | ((inCanByte4 & 0x01) << 1);
				psdMsg062.constraintWeekDayStart		= ((inCanByte4 & 0x0E) >> 1);
				psdMsg062.constraintWeekDayEnd			= ((inCanByte4 & 0x70) >> 4);
				psdMsg062.constraintHourStart			= ((inCanByte4 & 0x80) >> 7) | ((inCanByte5 & 0x0F) << 1);
				psdMsg062.constraintHourEnd				= ((inCanByte5 & 0xF0) >> 4) | ((inCanByte6 & 0x01) << 4);
				psdMsg062.noPassingSign					= ((inCanByte6 & 0x06) >> 1);
				psdMsg062.variableMessageSign			= ((inCanByte6 & 0x38) >> 3);
				psdMsg062.variableMessageSignType		= ((inCanByte6 & 0xC0) >> 6);
				psdMsg062.constraintLegalStreetClass	= ((inCanByte7 & 0x07) >> 0);
				psdMsg062.constraintLegalAddition		= ((inCanByte7 & 0x18) >> 3);/**< PSD_06.PSD_Ges_Gesetzlich_Zusatz */
				psdMsg062.sourceSpeedLimit				= ((inCanByte7 & 0x60) >> 5);/**< PSD_06.PSD_Ges_Verkehrszeichen_Quelle */		
				psdMsg062.completeFlag					= ((inCanByte7 & 0x80) >> 7);

				returnValue = PsdEhr_AcceptPsd06m02(&psdMsg062);
							
				if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
					diagLogInfo("PsdEhr_AcceptPsd06m02() reporting error.");
				}
			}

			if((inCanByte0 & 0x07) == 3) {
				PsdEhr_Psd63Message_t psdMsg063;

				psdMsg063.longitudeSign				= ((inCanByte0 & 0x08) >> 3);
				psdMsg063.longitude					= ((inCanByte0 & 0xF0) >> 4) | ((inCanByte1 & 0xFF) << 4) | ((inCanByte2 & 0xFF) << 12) | ((inCanByte3 & 0x1F) << 20);
				psdMsg063.latitudeSign				= ((inCanByte3 & 0x10) >> 4);
				psdMsg063.latitude					= ((inCanByte3 & 0xC0) >> 6) | ((inCanByte4 & 0xFF) << 2) | ((inCanByte5 & 0xFF) << 10) | ((inCanByte6 & 0x3F) << 18);
				psdMsg063.direction					= ((inCanByte6 & 0xC0) >> 6) | ((inCanByte7 & 0xFF) << 2);

				returnValue = PsdEhr_AcceptPsd06m03(&psdMsg063);
							
				if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
					diagLogInfo("PsdEhr_AcceptPsd06m03() reporting error.");
				}
			}

			if((inCanByte0 & 0x07) == 4) {
				PsdEhr_Psd64Message_t psdMsg064;

				psdMsg064.segment1Id			= ((inCanByte0 & 0xF8) >> 3) | ((inCanByte1 & 0x01) << 5);
				psdMsg064.segment1Slope1Value	= ((inCanByte1 & 0xFE) >> 1);
				psdMsg064.segment1Slope1Sign	= ((inCanByte2 & 0x01) >> 0);
				psdMsg064.segment1Slope1Offset	= ((inCanByte2 & 0xFE) >> 1);
				psdMsg064.segment1Slope2Value	= ((inCanByte3 & 0x7F) >> 0);
				psdMsg064.segment1Slope2Sign	= ((inCanByte3 & 0x80) >> 7);
				psdMsg064.segment1Slope2Offset	= ((inCanByte4 & 0x7F) >> 0);
				psdMsg064.segment1CompleteFlag	= ((inCanByte4 & 0x80) >> 7);
				psdMsg064.segment2Id			= ((inCanByte5 & 0x3F) >> 0);
				psdMsg064.segment2Slope1Value	= ((inCanByte5 & 0xC0) >> 6) | ((inCanByte6 & 0x1F) << 2);
				psdMsg064.segment2Slope1Sign	= ((inCanByte6 & 0x20) >> 5);
				psdMsg064.segment2Slope1Offset	= ((inCanByte6 & 0xC0) >> 6) | ((inCanByte7 & 0x1F) << 2);
				psdMsg064.segment2CompleteFlag	= ((inCanByte7 & 0x20) >> 5);

				returnValue = PsdEhr_AcceptPsd06m04(&psdMsg064);
							
				if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
					diagLogInfo("PsdEhr_AcceptPsd06m04() reporting error.");
				}
			}	

			returnValue = PsdEhr_ProcessMessageCycle();

			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_ProcessMessageCycle() reporting error.");
			}

			return true;
		}
	}

	return false;
}


bool_T			   eifInput(MEMORY		eifMemory_T			*eifMemory,
							IN	const	psdInput_T			*input)
{
	PsdEhr_Error_t	returnValue;

	if (eifMakeSureEHRIsInitialized(eifMemory)) { return false; }

	/* PSD_04*/
	if(psdMessage4 == input->type) {
		returnValue = PsdEhr_AcceptPsd04(&input->data.psd4);

		if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
			diagLogInfo("PsdEhr_AcceptPsd04() reporting error.");
		}
	}

	/* PSD_05 */
	if(psdMessage5 == input->type) {
		returnValue = PsdEhr_AcceptPsd05(&input->data.psd5);

		if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
			diagLogInfo("PsdEhr_AcceptPsd05() reporting error.");
		}
	}

	/* PSD_06 */
	if(psdMessage6 == input->type) {
		if(0 == input->data.psd6.multiplex) {
			PsdEhr_Psd60Message_t m0 = input->data.psd6.message.m0;

			returnValue = PsdEhr_AcceptPsd06m00(&m0);

			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd06m00() reporting error.");
			}
		}

		if(1 == input->data.psd6.multiplex) {
			returnValue = PsdEhr_AcceptPsd06m01(&input->data.psd6.message.m1);

			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd06m01() reporting error.");
			}
		}

		if(2 == input->data.psd6.multiplex) {
			returnValue = PsdEhr_AcceptPsd06m02(&input->data.psd6.message.m2);

			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd06m02() reporting error.");
			}
		}

		if(3 == input->data.psd6.multiplex) {
			returnValue = PsdEhr_AcceptPsd06m03(&input->data.psd6.message.m3);

			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd06m03() reporting error.");
			}
		}

		if(4 == input->data.psd6.multiplex) {
			returnValue = PsdEhr_AcceptPsd06m04(&input->data.psd6.message.m4);

			if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
				diagLogInfo("PsdEhr_AcceptPsd06m04() reporting error.");
			}
		}

		returnValue = PsdEhr_ProcessMessageCycle();

		if(returnValue != (PsdEhr_Error_t)PSD_EHR_ERROR_NO_ERROR) {
			diagLogInfo("PsdEhr_ProcessMessageCycle() reporting error.");
		}

		return true;
	}

	return false;
}


/** Stellt sicher, dass der EHR initialisiert ist, bevor Abfragen durchgef�hrt werden. 
	\ingroup ehrInterface_internal
	\bug Diese Funktion ist nicht "mutlimodulsicher".
	\todo Funktion durch vern�nftige Initialisierungsroutine ersetzen.*/
uint8_T		eifMakeSureEHRIsInitialized(MEMORY eifMemory_T		*eifMemory)			/*!< Speicher, der den aktuellen Status des EHR vorh�lt*/
{
	uint8_T returnValue = 0;

	if(!eifMemory->isEHRInitialized) {
		returnValue = PsdEhr_Init();
		
		(void)PsdEhr_SetEventUserDataPointer(eifMemory);
		(void)PsdEhr_RegisterErrorCallback(eifErrorCallbackEntry);
		(void)PsdEhr_RegisterEventCallback(eifEventCallbackEntry);
	
		memset(eifMemory->uniqueID, 0, sizeof(eifMemory->uniqueID));
		eifMemory->nextUniqueID = 0;

		memset(eifMemory->ehrKnownMPPSegments, 0xFF, sizeof(eifMemory->ehrKnownMPPSegments));
		eifMemory->lastMPPDeviations = 0;
		eifMemory->isEHRInitialized = true;
	}

	return returnValue;
}


/** Callback-Funktion, die vom EHR im Fall eines internen Fehlers aufgerufen wird.
	Gibt den Fehler auf der Konsole aus.*/
static void eifErrorCallbackEntry(PsdEhr_ErrorCode_t errorCode, void* const userData)
{
	char_T		*errorText;
	
	eifMemory_T	*eifMemory;
	eifMemory = (eifMemory_T*)userData;

	switch (errorCode) {
		case PSD_EHR_CONSTRUCT_ERROR_NONE:					errorText = "PSD_EHR_CONSTRUCT_ERROR_NONE"; break;
		case PSD_EHR_CONSTRUCT_ERROR_VALUE_RANGE:			errorText = "PSD_EHR_CONSTRUCT_ERROR_VALUE_RANGE"; break;
		case PSD_EHR_CONSTRUCT_ERROR_INCONSISTENT:			errorText = "PSD_EHR_CONSTRUCT_ERROR_INCONSISTENT"; break;
		case PSD_EHR_CONSTRUCT_ERROR_NAV_ERROR_RESET:		errorText = "PSD_EHR_CONSTRUCT_ERROR_NAV_ERROR_RESET"; break;
		case PSD_EHR_CONSTRUCT_ERROR_POSITION_INVALID:		errorText = "PSD_EHR_CONSTRUCT_ERROR_POSITION_INVALID"; break;
		case PSD_EHR_CONSTRUCT_ERROR_REDUNDANCY:			errorText = "PSD_EHR_CONSTRUCT_ERROR_REDUNDANCY"; break;
		case PSD_EHR_CONSTRUCT_ERROR_ATTRIBUTE_INVALID:		errorText = "PSD_EHR_CONSTRUCT_ERROR_ATTRIBUTE_INVALID"; break;
		case PSD_EHR_CONSTRUCT_ERROR_MEMORY:				errorText = "PSD_EHR_CONSTRUCT_ERROR_MEMORY"; break;
		case PSD_EHR_CONSTRUCT_ERROR_SPEED_LIMIT_INVALID:	errorText = "PSD_EHR_CONSTRUCT_ERROR_SPEED_LIMIT_INVALID"; break;
		case PSD_EHR_CONSTRUCT_ERROR_SLOPE_INVALID:			errorText = "PSD_EHR_CONSTRUCT_ERROR_SLOPE_INVALID"; break;
		case PSD_EHR_CONSTRUCT_ERROR_UNEXPECTED:			errorText = "PSD_EHR_CONSTRUCT_ERROR_UNEXPECTED"; break;
		default: errorText = "---";
	}

	eifMemory->isEHRInitialized = false;

	diagLogInfo(errorText);
}


/** Callback-Funktion, die vom EHR im Fall eines internen Events aufgerufen wird. */
static void eifEventCallbackEntry(PsdEhr_EventCode_t eventCode, PsdEhr_EventSubCode_t eventSubCode, PsdEhr_SegmentId_t segment, void * const userData)
{	
	eifMemory_T	*eifMemory;
	eifMemory = (eifMemory_T*)userData;

	if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_NONE) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_TREE_RESET) {
		char_T* errorText;

		switch (eventSubCode) {
			case PSD_EHR_CONSTRUCT_ESC_NONE:						errorText = "PSD_EHR_CONSTRUCT_ESC_NONE"; break;
			case PSD_EHR_CONSTRUCT_ESC_NAV_RESET:					errorText = "PSD_EHR_CONSTRUCT_ESC_NAV_RESET"; break;
			case PSD_EHR_CONSTRUCT_ESC_NAV_ERROR_RESET:				errorText = "PSD_EHR_CONSTRUCT_ESC_NAV_ERROR_RESET"; break;
			case PSD_EHR_CONSTRUCT_ESC_POSITION_INVALID:			errorText = "PSD_EHR_CONSTRUCT_ESC_POSITION_INVALID"; break;
			case PSD_EHR_CONSTRUCT_ESC_NEW_ROOT:               		errorText = "PSD_EHR_CONSTRUCT_ESC_NEW_ROOT"; break;
			case PSD_EHR_CONSTRUCT_ESC_SEGMENT_SAME:           		errorText = "PSD_EHR_CONSTRUCT_ESC_SEGMENT_SAME"; break;
			case PSD_EHR_CONSTRUCT_ESC_SEGMENT_NEW:            		errorText = "PSD_EHR_CONSTRUCT_ESC_SEGMENT_NEW"; break;
			case PSD_EHR_CONSTRUCT_ESC_DATA_SEGMENT:           		errorText = "PSD_EHR_CONSTRUCT_ESC_DATA_SEGMENT"; break;
			case PSD_EHR_CONSTRUCT_ESC_DATA_ATTRIBUTE:         		errorText = "PSD_EHR_CONSTRUCT_ESC_DATA_ATTRIBUTE"; break;
			case PSD_EHR_CONSTRUCT_ESC_DATA_SPEED_LIMIT:       		errorText = "PSD_EHR_CONSTRUCT_ESC_DATA_SPEED_LIMIT"; break;
			case PSD_EHR_CONSTRUCT_ESC_DATA_SLOPE:             		errorText = "PSD_EHR_CONSTRUCT_ESC_DATA_SLOPE"; break;
			case PSD_EHR_CONSTRUCT_ESC_REDUNDANCY:             		errorText = "PSD_EHR_CONSTRUCT_ESC_REDUNDANCY"; break;
			case PSD_EHR_CONSTRUCT_ESC_CYCLE_INVALID:          		errorText = "PSD_EHR_CONSTRUCT_ESC_CYCLE_INVALID"; break;
			case PSD_EHR_CONSTRUCT_ESC_ATTRIBUTE_INVALID:      		errorText = "PSD_EHR_CONSTRUCT_ESC_ATTRIBUTE_INVALID"; break;
			case PSD_EHR_CONSTRUCT_ESC_SPEED_LIMIT_INVALID:    		errorText = "PSD_EHR_CONSTRUCT_ESC_SPEED_LIMIT_INVALID"; break;
			case PSD_EHR_CONSTRUCT_ESC_SLOPE_INVALID:          		errorText = "PSD_EHR_CONSTRUCT_ESC_SLOPE_INVALID"; break;
			case PSD_EHR_CONSTRUCT_ESC_CYCLE_BEGIN:            		errorText = "PSD_EHR_CONSTRUCT_ESC_CYCLE_BEGIN"; break;
			case PSD_EHR_CONSTRUCT_ESC_CYCLE_END:              		errorText = "PSD_EHR_CONSTRUCT_ESC_CYCLE_END"; break;
			case PSD_EHR_CONSTRUCT_ESC_DEALLOCATION:           		errorText = "PSD_EHR_CONSTRUCT_ESC_DEALLOCATION"; break;
			case PSD_EHR_CONSTRUCT_ESC_ROOT_STATE_UPDATED:     		errorText = "PSD_EHR_CONSTRUCT_ESC_ROOT_STATE_UPDATED"; break;
			case PSD_EHR_CONSTRUCT_ESC_ROOT_VEHICLE_SEGMENT:   		errorText = "PSD_EHR_CONSTRUCT_ESC_ROOT_VEHICLE_SEGMENT"; break;
			case PSD_EHR_CONSTRUCT_ESC_ROOT_PROVIDER:          		errorText = "PSD_EHR_CONSTRUCT_ESC_ROOT_PROVIDER"; break;
			case PSD_EHR_CONSTRUCT_ESC_DATA_SYSTEM_ATTRIBUTES: 		errorText = "PSD_EHR_CONSTRUCT_ESC_DATA_SYSTEM_ATTRIBUTES"; break;
			case PSD_EHR_CONSTRUCT_ESC_DATA_LEGAL_SPEED_LIMITS:		errorText = "PSD_EHR_CONSTRUCT_ESC_DATA_LEGAL_SPEED_LIMITS"; break;
			default: errorText = "---";
		}

		diagLogInfo(errorText);
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_ROOT_NEW) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_SEGMENT_NEW) {
		eifMemory->uniqueID[segment] = eifMemory->nextUniqueID;
		eifMemory->nextUniqueID++;
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_SEGMENT_UPDATED) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_SEGMENT_COMPLETED) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_SEGMENT_REDUNDANT) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_SEGMENT_REMOVED) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_POSITION_UPDATED) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_SYSTEM_UPDATED) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_GPS_UPDATED) {
	}
	else if (eventCode == (uint16_T)PSD_EHR_CONSTRUCT_EC_CYCLE) {
	}
	else {
		diagLogInfo("PSD EHR: Unknown eventCode");
	}
}
#endif
