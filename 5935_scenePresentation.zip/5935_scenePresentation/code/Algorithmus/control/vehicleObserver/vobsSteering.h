#ifndef guard_vobsSteering_h
#define guard_vobsSteering_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"

/**\brief Update der aus dem Lenkradwinkel ermittelten Bahnkr�mmung

\spec SwMS_Innodrive2_Input_300 (Berechnung der aktuellen Kr�mmung aus Lenkradwinkel)
\spec SwMS_Innodrive2_Input_301 (Pr�diktion der Kr�mmung aus Lenkradwinkelgeschwindigkeit)
\spec SwMS_Innodrive2_Input_302 (Begrenzung der pr�dizierten Kr�mmung auf aktuelle Kr�mmung)
\spec SwMS_Innodrive2_Input_303 (Position der Pr�dizierten Bahnkr�mmung)
\spec SwMS_Innodrive2_Input_367 (Nachlaufender Lenkradwinkel => slowCurvature)

\ingroup vehicleObserver
*/
bool_T			 vobsSteeringUpdate(INOUT		steeringFilter_T	*filter,
									IN	const	vehicleModel_T		*vehicleModel,
									IN	const	real32_T			 deltaTime,
									IN	const	real32_T			 velocity,
									IN	const	real32_T			 wheelAngle,
									IN	const	real32_T			 wheelRate,
									IN	const	real32_T			 rearAngle,
									IN	const	bool_T				 rasPresent,
									OUT			steeringState_T		*state
									);


#endif
