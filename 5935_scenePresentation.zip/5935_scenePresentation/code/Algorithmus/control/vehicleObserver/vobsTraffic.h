#ifndef guard_vobsTraffic_h
#define guard_vobsTraffic_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "control/inputCodec/inputCodec_private.h"

/**\brief Aktualisierung der Dynamik des Vorausfahrenden Fahrzeugs.

\spec SwMS_Innodrive2_Input_322
\spec SwMS_Innodrive2_Input_323

\ingroup vehicleObserver
*/
void			  vobsTrafficUpdate(INOUT		trafficFilter_T			*filter,
									IN	const	accTarget_T				*target,
									IN	const	real32_T				 egoAcceleration,
									IN	const	real32_T				 deltaTime,
									IN	const	turnSignal_T			 turnSignal,
									IN	const	real32_T				 position,
									IN	const	real32_T				 velocity,
									OUT			trafficState_T			*state
									);


#endif
