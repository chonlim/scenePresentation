#ifndef guard_vobsSlopeStatic_h
#define guard_vobsSlopeStatic_h


static bool_T		vobsSlpGetSlope(IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	real32_T				 position,
									OUT			real32_T				*slope,
									OUT			bool_T					*known
									);


#endif
