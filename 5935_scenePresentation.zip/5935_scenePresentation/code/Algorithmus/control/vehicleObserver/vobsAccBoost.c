#include "control/vehicleObserver/vobsAccBoost.h"

#include "control/parameterSet/parameterSetCtrl.h"


void				 vobsUpdateAccBoost(INOUT		accBoostFilter_T *filter,
										IN	const	bool_T			  resume,
										OUT			bool_T			 *accBoost)
{
	uint16_T ticks;
	bool_T boost;

	const real32_T holdTime = prmGetParameterSetCtrl()->vehicleObserver.accBoost.holdTime;

	ticks = (uint16_T)min(INVALID_UINT16, (uint32_T)filter->holdTicks + 1u);

	if ((real32_T)ticks * controlCYCLETIME > holdTime) {
		boost = true;
	} else {
		boost = false;
	}

	if (resume) {
		filter->holdTicks = ticks;
		*accBoost = boost;
	} else {
		filter->holdTicks = 0u;
		*accBoost = false;
	}
}
