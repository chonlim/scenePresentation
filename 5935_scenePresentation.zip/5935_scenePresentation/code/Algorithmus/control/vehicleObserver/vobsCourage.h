#ifndef guard_vobsCourage_h
#define guard_vobsCourage_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "control/inputCodec/inputCodec_private.h"


/**\brief Update der Faktoren zur Anpassung der Fahrdynamik im constraintMaster

Die Funktion berechnet Faktoren im Wertebereich [-1;1], welche im constraintMaster verwendet werden, um die
Fahrdynmaik anhand von Kennlinien zu erniedrigen oder zu erh�hen.

Standardm��ig sind die Faktoren 0. Wenn die jeweiligen Voraussetzungen nicht mehr vorliegen, werden die Faktoren
tiefpassgefiltert gegen 0 zur�ck geschleift.

state.curvatureFactor	(Anpassung der maximalen absoluten Querbeschleunigung)
state.maxJerkFactor		(Anpassung des maximalen Beschleunigungsrucks)
state.limitJerkFactor	(Anpassung des maximalen Bremsrucks auf Tempolimits)
state.curveJerkFactor	(Anpassung des maximalen Bremsrucks auf Kurven)
state.curtainFactor		(Anpassung der Geschwindigkeitseinschr�nkung beim Verlassen von Kreisverkehren)

\spec SwMS_Innodrive2_Input_334

\ingroup vehicleObserver
*/
bool_T			  vobsCourageUpdate(INOUT		courageFilter_T			*filter,
									IN	const	real32_T				 deltaTime,
									IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	cameraLine_T			*lineLeft,
									IN	const	cameraLine_T			*lineRight,
									IN	const	bool_T					 signValid,
									IN	const	real32_T				 signLimit,
									IN	const	real32_T				 egoPosition,
									IN	const	real32_T				 egoVelocity,
									IN	const	real32_T				 wheelAngle,
									IN	const	real32_T				 wheelCurvature,
									IN	const	bool_T					 trafficPresent,
									IN	const	real32_T				 trafficPosition,
									IN	const	uint8_T					 wetnessLevel,
									IN	const	uint8_T					 frictionLevel,
									OUT			courageState_T			*state
									);


#endif
