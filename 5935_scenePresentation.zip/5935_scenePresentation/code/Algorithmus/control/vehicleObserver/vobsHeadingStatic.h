#ifndef vobsHeadingStatic_h
#define vobsHeadingStatic_h

/**\brief  Sicherstellen, dass das Heading im Bereich [0� 360�] bleibt.
\ingroup vehicleObserver_internal
*/
static bool_T  vobsHeadingNormalize(IN	const	real32_T			 arbitrary,
									OUT			real32_T			*normalized
									);


#endif
