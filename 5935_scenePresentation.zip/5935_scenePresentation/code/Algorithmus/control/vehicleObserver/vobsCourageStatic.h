#ifndef guard_vobsCourageStatic_h
#define guard_vobsCourageStatic_h


/**\brief Erh�ht den curvatureFactor, wenn die Fahrspur breit ist und vom Fahrzeug eine gro�e breite ausgenutzt wird.

Dazu werden die linke und rechte von der Kamera erkannte Fahrspurbegrenzung `cameraLine` ausgewertet. 

\spec SwMS_Innodrive2_Input_358

\ingroup vehicleObserver_internal
*/
static bool_T		 vobsCrgWidthUpdate(INOUT		vobsWidthFilter_T		*filter,
										IN	const	real32_T				 deltaTime,
										IN	const	real32_T				 wheelAngle,
										IN	const	cameraLine_T			*cameraLine,
										IN	const	bool_T					 lineIsLeft,
										OUT			real32_T				*target,
										OUT			real32_T				*confidence
										);

/**\brief Erh�ht den curtainFaktor, wenn das Fahrzeug einen Kreisverkehr verl�sst.

Das Verlasen eines Kreisverkehrs wird �ber die zur�ckgelegte Strecke im Kreisverkehr `mapPathInfo.roundaboutTail` 
und die Kurvenkr�mmung aufgrund Lenkradstellung `wheelCurvature` erkannt.

\spec SwMS_Innodrive2_Input_359

\ingroup vehicleObserver_internal
*/
static bool_T	   vobsCrgCurtainUpdate(IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	real32_T				 wheelCurvature,
										OUT			real32_T				*curtainFactor
										);


/**\brief Erniedrigt den maxJerkFactor und/oder den limitJerkFactor, wenn sich das Tempolimit deutlich �ndert.

Im `vobsLimitFilter_T filter` werden das minimale und maximale Tempolimit auf einem parametrierbaren Horizont gespeichert.
Die Abweichung des aktuellen Limits vom Maximum bestimmt �ber `maxJerkTarget` den `maxJerkFactor`.
Die Abweichung des aktuellen Limits vom Minimum bestimmt �ber `limitJerkTarget` den `limitJerkFactor`.

\spec SwMS_Innodrive2_Input_362

\ingroup vehicleObserver_internal
*/
static bool_T		 vobsCrgLimitUpdate(INOUT		vobsLimitFilter_T		*filter,
										IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	bool_T					 cameraValid,
										IN	const	real32_T				 cameraLimit,
										IN	const	real32_T				 egoPosition,
										OUT			real32_T				*maxJerkTarget,
										OUT			real32_T				*limitJerkTarget
										);


/**\brief Erh�ht den curvatureFactor, wenn sich das Fahrzeug in Folgefahrt befindet.

Die Folgefahrt wird �ber die Zeitl�cke zum vorausfahrenden Fahrzeug erkannt.

\spec SwMS_Innodrive2_Input_358

\ingroup vehicleObserver_internal
*/
static bool_T	   vobsCrgTrafficUpdate(IN	const	real32_T				 egoPosition,
										IN	const	real32_T				 egoVelocity,
										IN	const	bool_T					 trafficPresent,
										IN	const	real32_T				 trafficPosition,
										OUT			real32_T				*curvatureTarget
										);


/**\brief Erh�ht/erniedrigt den curvatureFactor, wenn sich das Fahrzeug auf trockener/nasser Stra�e befindet.

\spec SwMS_Innodrive2_Input_1467

\ingroup vehicleObserver_internal
*/
static bool_T	   vobsCrgWetnessUpdate(IN	const	uint8_T					 wetnessLevel,
										OUT			real32_T				*wetnessTarget
										);

/**\brief Erh�ht/erniedrigt den curvatureFactor, wenn sich das Fahrzeug auf Stra�e mit hohem/niedrigen Reibwert befindet.

\spec SwMS_Innodrive2_Input_1471

\ingroup vehicleObserver_internal
*/
static bool_T	  vobsCrgFrictionUpdate(IN	const	uint8_T					 frictionLevel,
										OUT			real32_T				*frictionTarget
										);


/**\brief Erniedrigt den  maxJerkFactor, den curveJerkFactor und den limitJerkFactor, wenn der mapPath neu aufgebaut wird.

Der Neuaufbau des mapPath wird �ber den Z�hler `mapPathInfo.ageTicks` ermittelt.
\spec SwMS_Innodrive2_Input_361

\ingroup vehicleObserver_internal
*/
static bool_T	 vobsCrgResetUpdate(IN	const	mapPathInfo_T			*mapPathInfo,
									OUT			real32_T				*maxJerkTarget,
									OUT			real32_T				*limitJerkTarget,
									OUT			real32_T				*curveJerkTarget
									);



#endif
