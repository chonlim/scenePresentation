#include "vehicleObserver.h"
#include "vobsHeading.h"
#include "vobsHeadingStatic.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsHeading)


bool_T			  vobsHeadingUpdate(INOUT		headingFilter_T		*filter,
									IN	const	real32_T			 deltaTime,
									IN	const	real32_T			 yawRate,
									IN	const	real32_T			 gpsHeading,
									IN	const	bool_T				 gpsValid,
									OUT			headingState_T		*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T deltaHeading;
	real32_T correction;
	real32_T deviation;

	real32_T maxHeadingInvalidCycles;

	/* Aktualisieren der angenommenen Fahrtrichtung mit der gemeldeten Gierrate */
	filter->heading += (yawRate * -180.0f / defPIf) * deltaTime;

	diagFF(vobsHeadingNormalize(filter->heading, &filter->heading));


	/* Wenn das Heading im letzten Zeitschritt nicht mit der Karte abgeglichen wurde, jetzt aber ein g�ltiger Wert
	   zur Verf�gung steht, wird dieser Wert einmalig �bernommen */
	if(!filter->valid && gpsValid) {
		filter->heading = gpsHeading;
	}


	/* Berechnen der Differenz zwischen der angenommenen und der von der Karte gemeldeten Fahrtrichtung */
	deltaHeading	= gpsHeading - filter->heading;
	if(deltaHeading >  180.0f) { deltaHeading -= 360.0f; }
	if(deltaHeading < -180.0f) { deltaHeading += 360.0f; }

	correction		= deltaHeading * paramSet->vehicleObserver.heading.updateFactor;

	if(gpsValid) {
		filter->heading += correction;
	}

	diagFF(vobsHeadingNormalize(filter->heading, &filter->heading));


	/* Begrenzen der maximalen Abweichung zwischen angenommenem und von der Karte gemeldetem Heading */
	deviation = filter->heading - gpsHeading;
	if(deviation >  180.0f) { deviation -= 360.0f; }
	if(deviation < -180.0f) { deviation += 360.0f; }

	deviation = min(deviation, paramSet->vehicleObserver.heading.maxDeviation);
	deviation = max(deviation, paramSet->vehicleObserver.heading.minDeviation);


	if(gpsValid) {
		real32_T delta;
		diagFF(vobsHeadingNormalize(filter->heading - (gpsHeading + deviation), &delta));
		if (fabsf(delta) > 1.0e-4f) {
			filter->heading = gpsHeading + deviation;
		} else {
			filter->heading = filter->heading;
		}
	}
	
	/*filter.valid f�r applizierbare Zeit auf true halten*/
	maxHeadingInvalidCycles = paramSet->vehicleObserver.heading.maxHeadingInvalidTime / controlCYCLETIME;

	if (gpsValid) {
		filter->valid = true;
		filter->invalidCount = 0u;
	} else {
		if (filter->invalidCount < (uint32_T)maxHeadingInvalidCycles)
		{
			filter->invalidCount++;
		} else {
			filter->valid = false;
		}
	}

	diagFF(vobsHeadingNormalize(filter->heading, &filter->heading));

	/* Ausgabestruktur mit Werten belegen */
	state->heading	= filter->heading;
	state->valid	= filter->valid;
	

	return true;
}


static bool_T  vobsHeadingNormalize(IN	const	real32_T			 arbitrary,
									OUT			real32_T			*normalized)
{
	/* Sicherstellen, dass das Heading im Bereich [0� 360�] bleibt */
	*normalized = fmodf(arbitrary, 360.0f);

	if(*normalized < 0.0f) { 
		*normalized += 360.0f; 
	}

	diagFNaN(*normalized);

	return true;
}
