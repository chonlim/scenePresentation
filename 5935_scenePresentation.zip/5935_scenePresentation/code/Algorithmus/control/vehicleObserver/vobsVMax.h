#ifndef guard_vobsVMax_h
#define guard_vobsVMax_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "control/inputCodec/inputCodec_private.h"


/**\brief Speichern der maximal einregelbaren Setzgeschwindigkeit aus dem Signal TSK_vMax_Fahrerassistenz.

Abh�ngig vom Wert des Signal vMaxUnit (aus TSK_Einheit_vMax_Fahrerassistenz) wird das Signal vMaxRaw (aus TSK_vMax_Fahrerassistenz)
in das entsprechende .value-Fled des vMaxFilter geschrieben und die zugeh�rige .valid-Flag wird auf true gesetzt. Damit ist der Wert initialisert.
�ber das Signal state werden die gespeicherten Werte f�r beide Einheiten ausgegeben. Im unitialiserten Fall wir INVALID_UNIT16 ausgegeben.

\spec SwMS_Innodrive2_Input_331

\ingroup vehicleObserver_internal
*/
bool_T				 vobsVMaxUpdate(INOUT		vMaxFilter_T			*filter,
									IN	const	displayUnit_T			 vMaxUnit,
									IN	const	uint16_T				 vMaxRaw,
									OUT			vMax_T					*state
									);


#endif
