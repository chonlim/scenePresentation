#ifndef guard_vobsSlope_h
#define guard_vobsSlope_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"

/**\brief Aktualisierung der Steigungsinformationen

Wenn eine g�ltige Steigungsinformation aus der Karte vorliegt, muss die Funktion diese annehmen, aber auf die TSK-Steigung mit Toleranz begrenzen.
Wenn keine g�ltige Kartensteigung vorliegt, muss die Funktion die Steigung ausschlie�lich aus dem TSK-Signal ableiten.
Wenn keine g�ltige TSK Steigung vorliegt, muss die Funktion die Steigung ausschlie�lich aus den Kartendaten ableiten.
Wenn beide Steigungen ung�ltig sind, muss die Funktion die Steigung 0 ausgeben.

\spec SwMS_Innodrive2_Input_321

\ingroup vehicleObserver
*/
bool_T				vobsSlopeUpdate(IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	real32_T				 position,
									IN	const	real32_T				 resistanceSlope,
									OUT			slopeState_T			*state
									);


#endif
