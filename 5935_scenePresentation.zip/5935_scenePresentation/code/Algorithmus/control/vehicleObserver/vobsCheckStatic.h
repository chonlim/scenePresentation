#ifndef guard_vobsCheckStatic_h
#define guard_vobsCheckStatic_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/vehicleModel/vehicleModel_interface.h"
#include "common/platformInterface/pltfDiagTypes.h"


/**\brief Wertet einen `checkState` aus.

Inkrementiert `filterCount`, wenn `failed == filterFailed`
Legt das Signal `failed` auf die Signale `filterFailed` und `stateFailed`
Gibt einmalig `stateSetDTC == true`aus, wenn `controlCYCLETIME * *filterCount == timeout`

Wenn timeout >= 1310.0f, wird der DTC nie gesetzt.

\ingroup vehicleObserver_internal
*/
static void	  vobsCheckUpdateFilter(INOUT		bool_T					*initialized,		/**<Filter Initialisiert*/
									INOUT		bool_T					*filterFailed,		/**<Entrpellter Zustand Pr�fung ist Fehlgeschlagen*/
									INOUT		uint16_T				*filterCount,		/**<Z�hler f�r entprellten Zustand*/
									IN	const	bool_T					 checkFailed,		/**<Pr�fung ist fehlgeschlagen*/
									IN	const	real32_T				 timeout,			/**<Entprellzeit*/
									IN	const	diagInfo_T				 diagInfoFail,		/**<diagReportInfo-Nachricht, wenn Zustand nach true wechselt*/
									IN	const	diagInfo_T				 diagInfoPass,		/**<diagReportInfo-Nachricht, wenn Zustand nach false wechselt*/
									OUT			bool_T					*stateFailed,		/**<Ausgabe des Entprellten Zustands*/
									OUT			bool_T					*stateSetDTC		/**<Ausgabe der Flag zum Setzen des DTC*/
									);


/**\brief Vergleicht zwei Booleans.

\ingroup vehicleObserver_internal
*/
static bool_T		   vobsAreEqual(IN	const	bool_T	first,
									IN	const	bool_T	second
									);

#endif
