#ifndef guard_vehicleObserver_h
#define guard_vehicleObserver_h


#include "control/control.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/vehicleModel/vehicleModel_interface.h"
#include "control/inputCodec/inputCodec_interface.h"


/**\brief Update des Fahrzeugzustands. Im Fehlerfall werden vehicleState und interner Zustand zur�ckgesetzt 
\ingroup vehicleObserver
*/
void		vehicleObserver(MEMORY		vobsMemory_T			*memory,
							IN	const	vehicleInput_T			*vehicleInput,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	mapPathInfo_T			*mapPathInfo,
							IN	const	longControlInfo_T		*longControlInfo,
							OUT			vehicleState_T			*vehicleState,
							OUT			checkState_T			*checkState
							);


#endif
