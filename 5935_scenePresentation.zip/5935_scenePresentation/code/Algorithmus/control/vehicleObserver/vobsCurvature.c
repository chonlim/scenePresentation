#include "vehicleObserver.h"
#include "vobsCurvature.h"
#include "vobsFilter.h"

#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsCurvature)


bool_T			vobsCurvatureUpdate(INOUT		curvatureFilter_T		*filter,
									IN	const	real32_T				 deltaTime,
									IN	const	cameraLine_T			*lineLeft,
									IN	const	cameraLine_T			*lineRight,
									OUT			curvatureState_T		*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	confSum;
	real32_T	partLeft;
	real32_T	partRight;

	real32_T	curveMix;
	real32_T	rateMix;
	real32_T	distMix;

	real32_T	curveFlt;
	real32_T	rateFlt;
	real32_T	distFlt;
	real32_T	confFlt;


	/* Berechnen der Verl�sslichkeiten von linker und rechter Linie */
	confSum		= (lineLeft->valid ? 0.5f : 0.0f) + (lineRight->valid ? 0.5f : 0.0f);
	partLeft	= (lineLeft->valid ? (lineRight->valid ? 0.5f : 1.0f) : 0.0f);
	partRight	= (lineRight->valid ? (lineLeft->valid ? 0.5f : 1.0f) : 0.0f);


	/* Verechnen der Informationen von linker und rechter Linie */
	curveMix	= (lineLeft->curvature * partLeft) + (lineRight->curvature * partRight);
	rateMix		= (lineLeft->curveRate * partLeft) + (lineRight->curveRate * partRight);
	distMix		= (lineLeft->length	   * partLeft) + (lineRight->length    * partRight);

	diagFNaN(curveMix);
	diagFNaN(rateMix);
	diagFNaN(distMix);


	/* Tiefpassfiltern der Informationen */
	vobsLowPassFilter(&filter->curvature,
					   deltaTime,
					   paramSet->vehicleObserver.curvature.curvatureCutOff,
					   curveMix,
					  &curveFlt);


	vobsLowPassFilter(&filter->curveRate,
					   deltaTime,
					   paramSet->vehicleObserver.curvature.curveRateCutOff,
					   rateMix,
					  &rateFlt);


	vobsLowPassFilter(&filter->horizon,
					   deltaTime,
					   paramSet->vehicleObserver.curvature.distanceCutOff,
					   distMix,
					  &distFlt);


	vobsLowPassFilter(&filter->confidence,
					   deltaTime,
					   paramSet->vehicleObserver.curvature.confidenceCutOff,
					   confSum,
					  &confFlt);


	/* Ausgabe */
	state->curvature	= curveFlt;
	state->curveRate	= rateFlt;
	state->horizon		= distFlt;
	state->confidence	= confFlt;

	return true;
}
