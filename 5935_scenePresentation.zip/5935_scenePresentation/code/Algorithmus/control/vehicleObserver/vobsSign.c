#include "vehicleObserver.h"
#include "vobsSign.h"
#include "control/parameterSet/parameterSetCtrl.h"

/*lint -esym(438, valid)*/
/*lint -esym(438, limit)*/
/*lint -esym(438, unit)*/
/*lint -esym(438, position)*/
/*lint -esym(438, velocity)*/

void				 vobsSignUpdate(INOUT		signFilter_T			*filter,
									IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	signInput_T				*input,
									IN	const	real32_T				 egoPostion,
									OUT			signState_T				*state)
{
	const parameterSetCtrl_T *param = prmGetParameterSetCtrl();
	
	/*Eing�nge einlesen*/
	volatile bool_T			valid = input->valid;
	volatile uint16_T		limit = input->limit == INVALID_UINT16 ? (uint16_T)rawLimitReleased : input->limit;
	volatile vobsSignUnit_T	unit  = mapPathInfo->signUnit;
	volatile real32_T		position;
	volatile real32_T		velocity;

	uint8_T					text  = input->text;
	bool_T					changed;

	/*Position nur bei Wechsel des VZE-Limits anpassen*/
	changed = (valid != filter->valid) /*lint !e697 Quasi-boolean values should be equality-compared only with 0 */;
	changed = (limit != filter->limit) || changed;
	changed = (mapPathInfo->signUnit != filter->unit) || changed;

	if(changed) {
		position = egoPostion;
	} else {
		position = filter->position;
	}
			
	/*Einheiten umrechnen*/
	if(unit == signUnitKMH) {
		velocity	= (real32_T)limit / 3.6f;		/* km/h -> m/s */
	}
	else if(mapPathInfo->signUnit == signUnitMPH) {
		velocity	= (real32_T)limit / 2.23694f;	/* mph -> m/s */
	}
	else {
		valid		= false;
		velocity	= 0.0f;
	}

	/*Filter aktualisieren*/
	if(		!valid
		&&	filter->valid
		&&	filter->limit == (uint16_T)rawLimitReleased  
		&&	text == 0u
		&&	param->vehicleObserver.sign.holdReleased)
	{
		/*Wechsel von unbegrenzt auf unbekannt. Filter halten. Zeit verdummen*/
		limit = filter->limit;		
		position = filter->position;
		unit = filter->unit;		
		valid = filter->valid;		
		velocity = filter->velocity;
	} else {
		/*Eingang �bernehmen*/
		filter->limit = limit;
		filter->position = position;
		filter->unit = unit;
		filter->valid = valid;
		filter->velocity = velocity;
	}
	
	/*Ausgabe aktuelles Verkehrszeichen*/
	state->current.valid			= filter->valid;
	state->current.position			= filter->position;
	state->current.velocity			= filter->velocity;
	state->current.raw				= filter->limit;


	/* Verarbeiten des pr�diktiven Verkehrszeichens */
	state->predicted.raw			= input->predicted.limit == INVALID_UINT16 ? (uint16_T)rawLimitReleased : input->predicted.limit;

	if(mapPathInfo->signUnit == signUnitKMH) {
		state->predicted.velocity	= (real32_T)state->predicted.raw / 3.6f;		/* km/h -> m/s */
	}
	else if(mapPathInfo->signUnit == signUnitMPH) {
		state->predicted.velocity	= (real32_T)state->predicted.raw / 2.23694f;	/* mph -> m/s */
	}
	else {
		state->predicted.velocity	= 0.0f;
	}

	state->predicted.valid			=    (input->predicted.valid)
									  && (input->predicted.additionalInfo == 0u)
									  && (state->predicted.velocity > 0.0f);
	state->predicted.position		= egoPostion + input->predicted.distance;


	/* Verarbeiten der VZE-Umweltbedingungen */
	state->conditions.fog			= input->conditions.fog;
	state->conditions.wet			= input->conditions.wet;
	state->conditions.trailer		= input->conditions.trailer;
	state->conditions.trailerLimit	= input->conditions.trailerLimit;
	state->conditions.trailerRaw	= input->conditions.trailerRaw;
}
