#ifndef guard_vobsDeviationStatic_h
#define guard_vobsDeviationStatic_h


static bool_T	  vobsDeviationStep(INOUT		deviationFilter_T		*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	uint8_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	bool_T					 trqRelevant,
									OUT			real32_T				*devEngaged,
									OUT			real32_T				*devDisengaged,
									OUT			real32_T				*modelAcceleration);


static bool_T	   vobsGearLockStep(INOUT		deviationFilter_T		*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	longControlInfo_T		*longControlInfo,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	uint8_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	bool_T					 trqRelevant,
									IN	const	bool_T					 systemRelevant,
									IN	const	real32_T				 modelAcceleration,
									OUT			bool_T					*gearLock,
									OUT			real32_T				*lockAcceleration);


#endif
