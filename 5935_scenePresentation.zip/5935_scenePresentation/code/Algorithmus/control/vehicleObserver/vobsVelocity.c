#include "vehicleObserver.h"
#include "vobsVelocity.h"

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsVelocity)


void			vobsVelocityReplace(IN	const	real32_T			 rawVelocityIn,
									IN	const	real32_T			 displayVelocityIn,
									OUT			real32_T			*rawVelocityOut,
									OUT			real32_T			*displayVelocityOut,
									OUT			bool_T				*valid)
{
	real32_T raw;
	real32_T display;
	bool_T retval;

	if (	rawVelocityIn == INVALID_VALUE
		&&	displayVelocityIn == INVALID_VALUE)
	{
		raw = 0.0f;
		display = 0.0f;
		retval = false;
	}
	else if (rawVelocityIn == INVALID_VALUE)
	{
		raw = displayVelocityIn;
		display = displayVelocityIn;
		retval = true;
	}
	else if (displayVelocityIn == INVALID_VALUE)
	{
		raw = rawVelocityIn;
		display = rawVelocityIn;
		retval = true;
	}
	else
	{
		raw = rawVelocityIn;
		display = displayVelocityIn;
		retval = true;
	}

	*rawVelocityOut = raw;
	*displayVelocityOut = display;
	*valid = retval;
}


bool_T			 vobsVelocityUpdate(INOUT		velocityFilter_T	*filter,
									IN	const	real32_T			 deltaTime,
									IN	const	real32_T			 rawVelocity,
									IN	const	real32_T			 displayVelocity,
									IN	const	real32_T			 acceleration,
									IN	const	bool_T				 enabled,
									OUT			vmState_T			*vmState)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	refVelocity;

	real32_T	innerDev;
	real32_T	innerCor;

	real32_T	outerDev;
	real32_T	outerCor;

	real32_T	correction;


	/* Auswahl von tats�chlicher oder angezeigter Geschwindigkeit als Referenz */
	if (paramSet->vehicleObserver.velocity.useDisplayVelocity) {
		real32_T displayDelta = displayVelocity - filter->anchorDisplay;

		if (fabsf(displayDelta) > ROUNDING_ERROR) {
			filter->anchorRaw = rawVelocity;
			filter->anchorDisplay = displayVelocity;
		}

		/* "Vergessensrate" f�r Raw-Ankergeschwindigkeit */
		filter->anchorRaw = rawVelocity       * (paramSet->vehicleObserver.velocity.refDecayFactor)
						  + filter->anchorRaw * (1.0f - paramSet->vehicleObserver.velocity.refDecayFactor);

		refVelocity = displayVelocity + (rawVelocity - filter->anchorRaw);
		refVelocity = max(refVelocity, 0.0f);
	}
	else
	{
		refVelocity = rawVelocity;
	}

	/* Aktualisieren der angenommenen Geschwindigkeit*/
	filter->velocity	+= deltaTime * acceleration;


	/* Berechnen des inneren und �u�eren Korrekturwerts*/
	innerDev			= filter->velocity - refVelocity;
	outerDev			= innerDev;

	if(innerDev >= 0.0f)	{ innerDev = max(0.0f, innerDev - paramSet->vehicleObserver.velocity.inner.maxTolerance); }
	else					{ innerDev = min(0.0f, innerDev - paramSet->vehicleObserver.velocity.inner.minTolerance); }
	innerCor			= innerDev * paramSet->vehicleObserver.velocity.inner.factor;

	if(outerDev >= 0.0f)	{ outerDev = max(0.0f, outerDev - paramSet->vehicleObserver.velocity.outer.maxTolerance); }
	else					{ outerDev = min(0.0f, outerDev - paramSet->vehicleObserver.velocity.outer.minTolerance); }
	outerCor			= outerDev * paramSet->vehicleObserver.velocity.outer.factor;

	correction			= innerCor + outerCor;
	filter->velocity	-= correction;


	/* Begrenzen der maximalen Abweichung zwischen gemeldeter und angenommener Geschwindigkeit*/
	filter->velocity	= min(filter->velocity, refVelocity + paramSet->vehicleObserver.velocity.tolerance.maxAbsolute);
	filter->velocity	= max(filter->velocity, refVelocity + paramSet->vehicleObserver.velocity.tolerance.minAbsolute);

	filter->velocity	= min(filter->velocity, refVelocity * (1.0f + paramSet->vehicleObserver.velocity.tolerance.maxRelative));
	filter->velocity	= max(filter->velocity, refVelocity * (1.0f + paramSet->vehicleObserver.velocity.tolerance.minRelative));


	/* In Fahrsituationen, in denen das System nicht direkt regelt, wird die angenommene Geschwindigkeit durch 
	   die gemeldete �berschrieben */
	if(!enabled) {
		filter->velocity = refVelocity;
	}

	diagFNaN(filter->velocity);


	/* Aktualisieren der L�ngsposition*/
	if(rawVelocity < INVALID_VALUE) {
		filter->position	+= fabsf(rawVelocity) * deltaTime;
	}


	/* Die vom longController zur�ckgemeldete Sollbeschleunigung wird als Beschleunigung angenommen*/
	vmState->position		= filter->position;
	vmState->velocity		= filter->velocity;
	vmState->acceleration	= acceleration;


	return true;
}
