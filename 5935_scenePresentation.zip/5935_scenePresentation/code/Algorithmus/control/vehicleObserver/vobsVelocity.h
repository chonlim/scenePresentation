#ifndef guard_vobsVelocity_h
#define guard_vobsVelocity_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"




/**\brief Wechselseitiges ersetzen von ung�ltigen Geschwindigkeitssignalen

\spec SwMS_Innodrive2_Input_368

\ingroup vehicleObserver
*/
void			vobsVelocityReplace(IN	const	real32_T			 rawVelocityIn,
									IN	const	real32_T			 displayVelocityIn,
									OUT			real32_T			*rawVelocityOut,
									OUT			real32_T			*displayVelocityOut,
									OUT			bool_T				*valid
									);


/**\brief Update von Beschleunigung, Geschwindigkeit und Position

�bernahme der Regler-Sollbeschleunigung aus dem Modul longController.

\spec SwMS_Innodrive2_Input_279 (Beschleunigung von LongController �bernehmen)
\spec SwMS_Innodrive2_Input_281 (Geschwindigkeit aus Beschleunigung integrieren)
\spec SwMS_Innodrive2_Input_282 (Korrektur der Geschwindigkeit)
\spec SwMS_Innodrive2_Input_283 (Begrenzung Geschwindigkeitsabweichung von physikalischem Wert)
\spec SwMS_Innodrive2_Input_284 (Initialisierung auf physikalische Geschwindigkeit bei inaktivem System)
\spec SwMS_Innodrive2_Input_286 (Position wird aus physikalischer Geschwindigkeit integriert)

\ingroup vehicleObserver
*/
bool_T			 vobsVelocityUpdate(INOUT		velocityFilter_T	*filter,
									IN	const	real32_T			 deltaTime,
									IN	const	real32_T			 rawVelocity,
									IN	const	real32_T			 displayVelocity,
									IN	const	real32_T			 acceleration,
									IN	const	bool_T				 enabled,
									OUT			vmState_T			*vmState
									);


#endif
