#include "vehicleObserver.h"
#include "vobsDeviation.h"
#include "vobsDeviationStatic.h"

#include <math.h>

#include "common/vehicleModel/vehicleModel.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsDeviation)



bool_T			vobsDeviationUpdate(INOUT		deviationFilter_T		*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	longControlInfo_T		*longControlInfo,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	uint8_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	bool_T					 serviceBrakeEngaged,
									IN	const	bool_T					 systemRelevant,
									OUT			deviationState_T		*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	bool_T		trqRelevant;
	uint8_T		numGears;
	uint8_T		adjGear;

	real32_T	devEngaged;
	real32_T	devDisengaged;
	real32_T	modelAcceleration;

	bool_T		gearLock;
	real32_T	lockAcceleration;


	/* Die Zugkraftfehlersch�tzung wird nur aktiv, wenn die Betriebsbremse nicht aktiv ist und die Minimalgeschwindigkeit
	   nicht unterschritten ist. */
	trqRelevant	= ((!serviceBrakeEngaged) && (velocity >= paramSet->vehicleObserver.deviation.minVelocity)) ? true : false;


	/* Sicherstellen, dass wir vom Fahrzeug keinen Gang bekommen, der au�erhalb unserer internen Grenzen liegt */
	diagFF(vmdlGetNumGears(vehicleModel, &numGears));
	adjGear		= ((uint8_T)gearCoast == gear) ? (uint8_T)gearCoast : min(gear, numGears-1u);


	/* Aktualisieren der Zugkraftfehler */
	diagFF(vobsDeviationStep( filter,
							  vehicleModel,
							  deltaTime,
							  curvature,
							  slope,
							  velocity,
							  adjGear,
							  torque,
							  trqRelevant,
							 &devEngaged,
							 &devDisengaged,
							 &modelAcceleration));


	/* Aktualisieren der Sperre f�r die Gangschnittstelle */
	diagFF(vobsGearLockStep( filter,
							 vehicleModel,
							 longControlInfo,
							 deltaTime,
							 curvature,
							 slope,
							 velocity,
							 adjGear,
							 torque,
							 trqRelevant,
							 systemRelevant,
							 modelAcceleration,
							&gearLock,
							&lockAcceleration));


	/* Ausgabe */
	state->engaged			= devEngaged;
	state->disengaged		= devDisengaged;
	state->gearLock			= gearLock;
	state->lockAccleration	= lockAcceleration;


	return true;
}


static bool_T	  vobsDeviationStep(INOUT		deviationFilter_T		*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	uint8_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	bool_T					 trqRelevant,
									OUT			real32_T				*devEngaged,
									OUT			real32_T				*devDisengaged,
									OUT			real32_T				*modelAcceleration)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	relevantDev;
	real32_T	mdlAcceleration;
	real32_T	innerDev;
	real32_T	innerCor;
	real32_T	outerDev;
	real32_T	outerCor;
	real32_T	correction;
	real32_T	update;
	real32_T	bleedTarget;
	real32_T	outEngaged;
	real32_T	outDisengaged;


	/* Auswahl der relevanten Abweichung f�r diesen Triebstrangzustand */
	relevantDev	= ((uint8_T)gearCoast == gear) ? filter->deviation.disengaged : filter->deviation.engaged;


	/* Berechnen der laut Fahrzeugmodell anzunehmenden Fahrzeugbeschleunigung */
	diagFF(vmdlGetTorqueAcceleration( vehicleModel,
									  curvature,
									  slope,
									  velocity,
									  gear,
									  torque,
									  relevantDev,
									 &mdlAcceleration));


	/* Update der Modellgeschwindigkeit */
	filter->modelVelocity += mdlAcceleration * deltaTime;

	/* Berechnen des inneren und �u�eren Korrekturwerts */
	innerDev	= filter->modelVelocity - velocity;
	outerDev	= innerDev;

	if(innerDev >= 0.0f)	{ innerDev = max(0.0f, innerDev - paramSet->vehicleObserver.deviation.inner.maxTolerance); }
	else					{ innerDev = min(0.0f, innerDev - paramSet->vehicleObserver.deviation.inner.minTolerance); }

	if(outerDev >= 0.0f)	{ outerDev = max(0.0f, outerDev - paramSet->vehicleObserver.deviation.outer.maxTolerance); }
	else					{ outerDev = min(0.0f, outerDev - paramSet->vehicleObserver.deviation.outer.minTolerance); }

	innerCor	= innerDev * paramSet->vehicleObserver.deviation.inner.factor;
	outerCor	= outerDev * paramSet->vehicleObserver.deviation.outer.factor;

	correction	= innerCor + outerCor;
	filter->modelVelocity -= correction;

	diagFNaN(filter->modelVelocity);


	/* Berechnen des Updates f�r die Zugkraftfehlersch�tzung */
	update		= correction * paramSet->vehicleObserver.deviation.updateFactor;
	update		= min(update, paramSet->vehicleObserver.deviation.maxRate);
	update		= max(update, paramSet->vehicleObserver.deviation.minRate);


	/* In Fahrsitationen, in denen das Motormoment nicht ma�geblich f�r die Beschleunigung ist, wird die Fehlersch�tzung nicht 
	   aktualisiert und die Modellgeschwindigkeit an die gemeldete Geschwindigkeit angeglichen. */
	if(!trqRelevant) {
		update	= 0.0f;
		filter->modelVelocity = velocity;
	}


	/* Update des relevanten Fehlerwerts */
	if((uint8_T)gearCoast == gear) {
		filter->deviation.disengaged += update;
	}
	else {
		filter->deviation.engaged += update;
	}


	/* Auswahl des bleedTarget */
	if(!trqRelevant) {
		bleedTarget	= 0.0f;
	}
	else if((uint8_T)gearCoast == gear) {
		bleedTarget	= filter->deviation.disengaged;
	}
	else {
		bleedTarget	= filter->deviation.engaged;
	}


	/* Mischen der Sch�tzwerte mit dem bleedTarget */
	filter->deviation.engaged		= filter->deviation.engaged		* (1.0f - paramSet->vehicleObserver.deviation.bleedFactor)
									+ bleedTarget					* (       paramSet->vehicleObserver.deviation.bleedFactor);

	filter->deviation.disengaged	= filter->deviation.disengaged	* (1.0f - paramSet->vehicleObserver.deviation.bleedFactor)
									+ bleedTarget					* (       paramSet->vehicleObserver.deviation.bleedFactor);

	diagFNaN(filter->deviation.engaged);
	diagFNaN(filter->deviation.disengaged);


	/* Interne Filterwerte auf den zul�ssigen Bereich begrenzen */
	filter->deviation.engaged		= max(filter->deviation.engaged, paramSet->vehicleObserver.deviation.filterLimit.minEngaged);
	filter->deviation.engaged		= min(filter->deviation.engaged, paramSet->vehicleObserver.deviation.filterLimit.maxEngaged);

	filter->deviation.disengaged	= max(filter->deviation.disengaged, paramSet->vehicleObserver.deviation.filterLimit.minDisengaged);
	filter->deviation.disengaged	= min(filter->deviation.disengaged, paramSet->vehicleObserver.deviation.filterLimit.maxDisengaged);


	/* Ausgabewerte auf den zul�ssigen Bereich begrenzen */
	outEngaged			= filter->deviation.engaged;
	outDisengaged		= filter->deviation.disengaged;

	outEngaged			= max(outEngaged, paramSet->vehicleObserver.deviation.stateLimit.minEngaged);
	outEngaged			= min(outEngaged, paramSet->vehicleObserver.deviation.stateLimit.maxEngaged);

	outDisengaged		= max(outDisengaged, paramSet->vehicleObserver.deviation.stateLimit.minDisengaged);
	outDisengaged		= min(outDisengaged, paramSet->vehicleObserver.deviation.stateLimit.maxDisengaged);


	/* Ausgabe */
	*devEngaged			= outEngaged;
	*devDisengaged		= outDisengaged;
	*modelAcceleration	= mdlAcceleration;


	return true;
}


static bool_T	   vobsGearLockStep(INOUT		deviationFilter_T		*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	longControlInfo_T		*longControlInfo,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	uint8_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	bool_T					 trqRelevant,
									IN	const	bool_T					 systemRelevant,
									IN	const	real32_T				 modelAcceleration,
									OUT			bool_T					*gearLock,
									OUT			real32_T				*lockAcceleration)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	relevantDev;
	
	real32_T	resistance;
	real32_T	mdlTorque;
	real32_T	mdlOmega;

	real32_T	trqDelta;
	real32_T	devStep;

	bool_T		wasLocked;


	/* Auswahl der relevanten Abweichung f�r diesen Triebstrangzustand */
	relevantDev	= ((uint8_T)gearCoast == gear) ? filter->deviation.disengaged : filter->deviation.engaged;


	/* Berechnen der laut Fahrzeugmodell anzunehmenden Fahrwiderst�nde */
	diagFF(vmdlGetResistanceForce( vehicleModel,
								   velocity,
								   curvature,
								   slope,
								   relevantDev,
								  &resistance));


	/* Berechnen der laut Fahrzeugmodell notwendigen */
	diagFF(vmdlGetAccelerationTorque( vehicleModel,
									  longControlInfo->acceleration,
									  resistance,
									  velocity,
									  gear,
									 &mdlTorque,
									 &mdlOmega));


	/* Berechnen der betragsm��igen Abweichung zwischen tats�chlichem und als notwendig berechnetem
	   Antriebsmoment unter Ber�cksichtigung einer Abweichungstoleranz */
	trqDelta	 = mdlTorque - torque;
	trqDelta	 = fabsf(trqDelta);
	trqDelta	-= paramSet->vehicleObserver.deviation.gearLock.torqueTolerance;
	trqDelta	 = max(trqDelta, 0.0f);


	/* Berechnen der �nderung des Fehlerintegrals unter Ber�cksichtigung der Abbaurate */
	devStep		 = (trqDelta - paramSet->vehicleObserver.deviation.gearLock.bleedRate) * deltaTime;


	/* Das Fehlerintegral wird nur aktualisiert, wenn das Modell verl�sslich ist,d unsere Wunschbeschleunigung
	   eigentlich durchgestellt werden sollte und wir uns nicht im Segeln befinden. */
	devStep		 = (systemRelevant && trqRelevant && gear != (uint8_T)gearCoast) ? devStep : 0.0f;

	filter->gearLock.torqueDeviation += devStep;
	filter->gearLock.torqueDeviation = max(filter->gearLock.torqueDeviation, 0.0f);


	/* Wenn das maximal zul�ssige Fehlerintegral �berschritten wird, setzen wir dss gearLock */
	wasLocked = filter->gearLock.locked;
	if(filter->gearLock.torqueDeviation > paramSet->vehicleObserver.deviation.gearLock.thresholdLock) {
		filter->gearLock.locked = true;
	}
	/* Wenn der Grenzwert f�r das R�cksetzen erreicht oder unterschritten wurde und der aktuell eingelegte Gang
	   unserer (gesperrten) Anforderung entspricht, nehmen wir die Sperre wieder zur�ck. */
	else if(   (filter->gearLock.torqueDeviation <= paramSet->vehicleObserver.deviation.gearLock.thresholdUnlock)
			&& (gear == longControlInfo->gear)) {
		filter->gearLock.locked = false;
	}
	/* Andernfalls bleibt alles wie es ist */
	else {
		filter->gearLock.locked = filter->gearLock.locked;
	}


	/* Die maximal zul�ssige Sollbeschleunigung wird in jedem Zeitschritt erh�ht und nur bei einem �bergang [gearLock: false->true]
	   einmalig mit der aktuell vom L�ngsdynamikmodell L�ngsbeschleunigung initialisiert */
	if(!wasLocked && filter->gearLock.locked) {
		filter->gearLock.acceleration = modelAcceleration;
	}
	else {
		filter->gearLock.acceleration += paramSet->vehicleObserver.deviation.gearLock.entryJerk * deltaTime;
	}


	/* Ausgabe */
	*gearLock			= filter->gearLock.locked;
	*lockAcceleration	= filter->gearLock.locked ? filter->gearLock.acceleration : INVALID_VALUE;


	return true;
}
