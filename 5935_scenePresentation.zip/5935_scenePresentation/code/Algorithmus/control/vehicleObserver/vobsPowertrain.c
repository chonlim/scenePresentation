#include "vehicleObserver.h"
#include "vobsPowertrainStatic.h"
#include "vobsPowertrain.h"
#include "control/inputCodec/inputCodec_private.h"
#include "common/platformInterface/pltfDiag.h"
#include "common/vehicleModel/vmdlTools.h"
#include "common/parameterSet/parameterSet.h"
#include "control/parameterSet/parameterSetCtrl.h"
diagDeclareModule(diagModule_vobsPowertrain)

bool_T		   vobsPowertrainUpdate(IN	const	vehicleModel_T		*vehicleModel,
									IN	const	powertrainInput_T	*powertrain,
									IN	const	real32_T			 curvature,
									IN	const	real32_T			 slope,
									IN	const	real32_T			 velocity,
									IN	const	real32_T			 devEngaged,
									IN	const	real32_T			 devDisengaged,
									IN	const	uint8_T				 controlGear,
									IN	const	bool_T				 gearRelevant,
									OUT			powertrainState_T	*state)
{
	uint8_T			gear;
	simpleState_T	simple;
	simpleState_T	rawSimple;
	real32_T		maxAccelerationElectric;
	driveMode_T		driveMode;
	real32_T		torque;

	diagFF(vobsGearUpdate( powertrain->gear,
						   controlGear,
						   gearRelevant,
						  &gear,
						  &simple,
						  &rawSimple));


	diagFF(vobsMaxAccelerationElectric( vehicleModel,
									    powertrain,
									    curvature,
									    slope,
									    velocity,
									    devEngaged,
									    devDisengaged,
									   &maxAccelerationElectric));


	diagFF(vobsSetDriveMode( powertrain->hybridVehicle,
							 powertrain->combustionEngineActive,
							 powertrain->ePowerSelected,
							&driveMode));


	/* Berechnen des �quivalenten Gesamt-Antriebsmoments */
	diagFF(vmdlGetTotalTorque( vehicleModel,
							   powertrain->sumTorque,
							   powertrain->eTorquePrimary,
							   powertrain->eTorqueSecondary,
							   powertrain->gear,
							  &torque));

	
	state->gear						= gear;
	state->simple					= simple;
	state->rawSimple				= rawSimple;
	state->torque					= torque;
	state->maxAccelerationElectric	= maxAccelerationElectric;
	state->driveMode				= driveMode;
	state->coastingPossible			= powertrain->coastingPossible;

	return true;
}


static bool_T		 vobsGearUpdate(IN	const	uint8_T				 rawGear,
									IN	const	uint8_T				 controlGear,
									IN	const	bool_T				 gearRelevant,
									OUT			uint8_T				*outGear,
									OUT			simpleState_T		*outSimple,
									OUT			simpleState_T		*outRawSimple)
{
	uint8_T			gear;
	simpleState_T	simple;
	simpleState_T	rawSimple;

	/* Wenn das System aktiv regelt und einen Gang vorgibt, wird mit dem Wunschgang gerechnet, andernfalls mit dem Gang, der tats�chlich
	   eingelegt ist. */
	if(gearRelevant) {
		gear = controlGear;
	}
	else {
		gear = rawGear;
	}

	if(gear == (uint8_T)gearCoast) {
		simple = simpleStateOff;
	}
	else {
		simple = simpleStateOn;
	}

	if(rawGear == (uint8_T)gearCoast) {
		rawSimple = simpleStateOff;
	}
	else {
		rawSimple = simpleStateOn;
	}


	/* Ausgabe */
	*outGear			= gear;
	*outSimple			= simple;
	*outRawSimple		= rawSimple;

	return true;
}


static bool_T	vobsMaxAccelerationElectric(IN	const	vehicleModel_T		*vehicleModel,
											IN	const	powertrainInput_T	*powertrain,
											IN	const	real32_T			 curvature,
											IN	const	real32_T			 slope,
											IN	const	real32_T			 velocity,
											IN	const	real32_T			 devEngaged,
											IN	const	real32_T			 devDisengaged,
											OUT			real32_T			*maxAccelerationElectric)
{
	uint8_T		numGears;
	uint8_T		adjGear;
	real32_T	acceleration;
	real32_T	offset;


	/* Sicherstellen, dass wir vom Fahrzeug keinen Gang bekommen, der au�erhalb unserer internen Grenzen liegt */
	diagFF(vmdlGetNumGears(vehicleModel, &numGears));
	adjGear		= ((uint8_T)gearCoast == powertrain->gear) ? (uint8_T)gearCoast : min(powertrain->gear, numGears-1u);


	diagFF(vmdlGetTorqueAcceleration(	  vehicleModel,
										  curvature,
										  slope,
										  velocity,
										  adjGear,
										  powertrain->maxTorqueElectric,
										  powertrain->gear == (uint8_T)gearCoast ? devDisengaged : devEngaged,
										 &acceleration));
	
	diagFF(vmdlGetEpowerAccelOffset(	 vehicleModel,
										&offset));

	*maxAccelerationElectric = acceleration + offset;

	return true;
}


static bool_T	   vobsSetDriveMode(IN	const	bool_T				 hybridVehicle,
									IN	const	bool_T				 combustionEngineActive,
									IN	const	bool_T				 ePowerSelected,
									OUT			driveMode_T			*driveMode)
{
	driveMode_T mode;

	if (!hybridVehicle || combustionEngineActive) {
		mode = drvMdCombustion;
	} 
	else if (ePowerSelected) {
		mode = drvMdEpower;
	}
	else {
		mode = drvMdElectricAuto;
	}

	*driveMode = mode;

	return true;
}


bool_T			vobsUpdateLockCoast(INOUT		lockCoastFilter_T	*filter,
									IN	const	dynamicsInput_T		*dynamcis,
									IN	const	real32_T			 velocity,
									INOUT		bool_T				*coastingPossible)
{
	real32_T sum; 

	/*Parameter*/
	const struct _parameterSetCtrl_vehicleObserver_lockCoast *param = &prmGetParameterSetCtrl()->vehicleObserver.lockCoast;
	const real32_T prmWaitTicks = (param->waitTime / controlCYCLETIME);
	const real32_T prmLockTicks = (param->lockTime / controlCYCLETIME);

	real32_T prmBrakeTorque;
	diagFF(prmInterpolate( param->maxBrakeTorque.velocity,
						   param->maxBrakeTorque.torque, 
						   param->maxBrakeTorque.count,
						   (uint16_T)prmNUMMAXBRAKETORQUE,
						   velocity, 
						  &prmBrakeTorque));

	/*Gesamtbremsmoment*/
	sum = 0.0f;
	sum += dynamcis->brakeTorque.frontLeft;
	sum += dynamcis->brakeTorque.frontRight;
	sum += dynamcis->brakeTorque.rearLeft;
	sum += dynamcis->brakeTorque.rearRight;

	/*Wenn Bremsen geschlossen: warten.*/
	if (sum > prmBrakeTorque) {
		filter->waitTicks++;
	} else {
		filter->waitTicks = 0u;
	}

	/*Nach Wartezeit: Segeln sperren*/
	if ((real32_T)filter->waitTicks > prmWaitTicks) {
		filter->lockCoast = true;
		filter->lockTicks = 0u;
	} else {
		/*Wenn Bremsen wieder ge�ffnet: noch Sperrzeit abwarten*/
		filter->lockTicks++;
	}

	/*Nach Sperrzeit: Sperre aufheben*/
	if ((real32_T)filter->lockTicks > prmLockTicks) {
		filter->lockCoast = false;
	} else {
		/*Nichts tun*/
	}

	/*Ausgabe*/
	*coastingPossible = filter->lockCoast ? false : *coastingPossible;

	return true;
}
