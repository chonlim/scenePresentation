#ifndef guard_vobsTurnSignal_h
#define guard_vobsTurnSignal_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"


/**\brief Aufbereiten der Informationen zum Fahrtrichtungsanzeiger (Blinker)

\spec SwMS_Innodrive2_Input_335
\spec SwMS_Innodrive2_Input_336
\spec SwMS_Innodrive2_Input_337
\spec SwMS_Innodrive2_Input_1482
\spec SwMS_Innodrive2_Input_346
\spec SwMS_Innodrive2_Input_348
\spec SwMS_Innodrive2_Input_363

\ingroup vehicleObserver
*/
void		   vobsTurnSignalUpdate(INOUT		turnSignalFilter_T		*filter,
									IN	const	turnSignal_T			 turnSignal,
									IN	const	bool_T					 signalLocked,
									IN	const	positionInput_T			*positionInput,
									IN  const	vmState_T				*velocityInput,
									OUT			turnSignalState_T		*state
									);


#endif
