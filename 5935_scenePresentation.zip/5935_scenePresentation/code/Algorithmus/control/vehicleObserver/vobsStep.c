#include "vehicleObserver.h"
#include "vobsStep.h"

#include <string.h>

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "control/inputCodec/inputCodec_private.h"

#include "vobsVelocity.h"
#include "vobsDeviation.h"
#include "vobsPowertrain.h"
#include "vobsHeading.h"
#include "vobsSteering.h"
#include "vobsCurvature.h"
#include "vobsTurnSignal.h"
#include "vobsSlope.h"
#include "vobsTraffic.h"
#include "vobsUnfiltered.h"
#include "vobsSign.h"
#include "vobsCourage.h"
#include "vobsVMax.h"
#include "vobsCheck.h"
#include "control/vehicleObserver/vobsAccBoost.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsStep)


bool_T			 vobsUpdate(MEMORY		vobsMemory_T			*memory,
							IN	const	vehicleInput_T			*vehicleInput,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	mapPathInfo_T			*mapPathInfo,
							IN	const	longControlInfo_T		*longControlInfo,
							OUT			vehicleState_T			*vehicleState,
							OUT			checkState_T			*checkState)
{
	real32_T	rawVelocity;
	real32_T	displayVelocity;
	bool_T		controlRelevant;
	bool_T		gearRelevant;


	/* Tick-Count hochz�hlen */
	memory->tickCount++;

	/* Die Anzeigegeschwindigkeit und die ESP-Geschwindigkeit werden wechselseitig als Ersatzwerte gesetzt.
	   Wenn keines der Signale g�ltig ist, wird der vehicleObserver neu initialisiert und ist ung�ltig.*/
	vobsVelocityReplace( vehicleInput->dynamics.velocity,
						 vehicleInput->dynamics.displayVelocity,
						 &rawVelocity,
						 &displayVelocity,
						 &vehicleState->valid);
	if (!vehicleState->valid) {
		return false;
	}

	vobsUpdateAccBoost(&memory->accBoostFilter,
					    vehicleInput->driver.resume,
					   &vehicleState->accBoost);

	/* Die Geschwindigkeitsfilterung ist relevant, wenn das System aktiv ist und nicht vom Fahrer oder ACC
	   �berstimmt wird. */
	controlRelevant	= vehicleInput->acc.systemRelevant && !vehicleState->accBoost;


	/* Die Gangvorgabe ist relevant, wenn das System regelt und einen Gang anfordert. */
	gearRelevant	= controlRelevant && longControlInfo->gearValid;


	/* Update des Tick-Count */
	vehicleState->tickCount	= memory->tickCount;


	/* Update der Geschwindigkeit */
	diagFF(vobsVelocityUpdate(&memory->velocityFilter,
							   controlCYCLETIME,
							   rawVelocity,
							   displayVelocity,
							   longControlInfo->acceleration,
							   controlRelevant,
							  &vehicleState->velocity));


	/* Update der Fahrtrichtung */
	diagFF(vobsHeadingUpdate(&memory->headingFilter,
							  controlCYCLETIME,
							  vehicleInput->dynamics.yawRate,
							  vehicleInput->dynamics.heading,
							  vehicleInput->dynamics.headValid,
							 &vehicleState->heading));


	/* Update der Bahnkr�mmung */
	diagFF(vobsSteeringUpdate(&memory->steeringFilter,
							   vehicleModel,
							   controlCYCLETIME,
							   rawVelocity,
							   vehicleInput->dynamics.wheelAngle,
							   vehicleInput->dynamics.wheelRate,
							   vehicleInput->dynamics.rearAngle,
							   vehicleInput->dynamics.rasPresent,
							  &vehicleState->steering));


	/* Update der Spurerkennung */
	diagFF(vobsCurvatureUpdate(&memory->curvatureFilter,
							    controlCYCLETIME,
							   &vehicleInput->camera.lineLeft,
							   &vehicleInput->camera.lineRight,
							   &vehicleState->curvature));


	/* Update der Steigung */
	diagFF(vobsSlopeUpdate( mapPathInfo,
						    vehicleState->velocity.position,
						    vehicleInput->road.slope,
						   &vehicleState->slope));


	/* Update des Gangs */
	diagFF(vobsPowertrainUpdate( vehicleModel,
								&vehicleInput->powertrain,
								 vehicleState->curvature.curvature,
								 vehicleState->slope.slope,
								 rawVelocity,
								 memory->deviationFilter.deviation.engaged,
								 memory->deviationFilter.deviation.disengaged,
								 longControlInfo->gear,
								 gearRelevant,
								&vehicleState->powertrain));

	diagFF(vobsUpdateLockCoast(&memory->lockCoastFilter,
							   &vehicleInput->dynamics,
							    vehicleState->velocity.velocity,
							   &vehicleState->powertrain.coastingPossible));

	/* Update der Zugkraftfehlersch�tzung */
	diagFF(vobsDeviationUpdate(&memory->deviationFilter,
							    vehicleModel,
							    longControlInfo,
							    controlCYCLETIME,
							    vehicleState->steering.curvature,
							    vehicleInput->road.slope,
							    rawVelocity,
							    vehicleInput->powertrain.gear,
							    vehicleState->powertrain.torque,
							    vehicleInput->dynamics.serviceBrakeEngaged,
							    vehicleInput->acc.systemRelevant,
							   &vehicleState->deviation));


	/* Update des Blinker-Status */
	vobsTurnSignalUpdate(&memory->turnSignalFilter,
						 vehicleInput->driver.turnSignal,
						 vehicleInput->driver.signalLocked,
						&vehicleInput->position,
						&vehicleState->velocity,
						&vehicleState->turnSignal);


	/* Update des Umgebungsverkehrs */
	vobsTrafficUpdate(&memory->trafficFilter,
					  &vehicleInput->acc.target,
					   vehicleInput->dynamics.longAcceleration,
					   controlCYCLETIME,
					   vehicleInput->driver.turnSignal,
					   vehicleState->velocity.position,
					   vehicleState->velocity.velocity,
					  &vehicleState->traffic);


	/* Update der ungefilterten Daten*/
	vobsUnfilteredUpdate( rawVelocity,
						  displayVelocity,
						  vehicleInput->dynamics.longAcceleration,
						  vehicleInput->dynamics.latAcceleration,
						  vehicleInput->driver.accelerator,
						 &vehicleState->unfiltered);


	/* Update der VZE */
	vobsSignUpdate(&memory->signFilter,
				    mapPathInfo,
				   &vehicleInput->sign,
				    vehicleState->velocity.position,
				   &vehicleState->sign);


	/* Update der Anpassfaktoren f�r die Geschwindigkeitseinschr�nkungen */
	diagFF(vobsCourageUpdate(&memory->courageFilter,
							  controlCYCLETIME,
							  mapPathInfo,
							 &vehicleInput->camera.lineLeft,
							 &vehicleInput->camera.lineRight,
							  vehicleState->sign.current.valid,
							  vehicleState->sign.current.velocity,
							  vehicleState->velocity.position,
							  vehicleState->velocity.velocity,
							  vehicleInput->dynamics.wheelAngle,
							  vehicleState->steering.curvature,
							  vehicleState->traffic.present,
							  vehicleState->traffic.position,
							  vehicleInput->road.wetnessLevel,
							  vehicleInput->road.frictionLevel,
							 &vehicleState->courage));

	diagFF(vobsVMaxUpdate(&memory->vMaxFilter,
						   vehicleInput->driver.vMaxUnit,
						   vehicleInput->driver.vMaxRaw,
						  &vehicleState->vMax));


	diagFF(vobsCheckUpdate(&memory->checkFilter,
						    vehicleModel,
							vehicleInput->powertrain.motorCode,
						    vehicleInput->dynamics.velocity,
						    vehicleInput->dynamics.displayVelocity,
							vehicleInput->driver.maxAutoSpeed,
						    longControlInfo->valid,
						    checkState));

	return true;
}


void			   vobsInit(INOUT		vobsMemory_T			*memory,
							OUT			vehicleState_T			*vehicleState,
							OUT			checkState_T			*checkState)
{
	uint32_T	tickCount;
	real32_T	position;

	tickCount	= memory->tickCount;
	position	= memory->velocityFilter.position;

	memset(memory,			0, sizeof(*memory));
	memset(vehicleState,	0, sizeof(*vehicleState));
	memset(checkState,		0, sizeof(*checkState));

	memory->tickCount				= tickCount;
	memory->velocityFilter.position	= position;

	vehicleState->tickCount			= memory->tickCount;
	vehicleState->velocity.position	= memory->velocityFilter.position;
}
