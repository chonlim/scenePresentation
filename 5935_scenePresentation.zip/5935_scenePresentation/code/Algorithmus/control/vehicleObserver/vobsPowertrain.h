#ifndef guard_vobsPowertrain_h
#define guard_vobsPowertrain_h

#include "control/inputCodec/inputCodec_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"

/**\brief Aktualisiert den Triebstrangzustand.

\spec SwMS_Innodrive2_Input_292
\spec SwMS_Innodrive2_Input_373

Wenn das System aktiv regelt und einen Gang vorgibt, wird mit dem Wunschgang gerechnet, andernfalls mit dem Gang, der tats�chlich eingelegt ist.
\ingroup vehicleObserver_internal
*/
bool_T		   vobsPowertrainUpdate(IN	const	vehicleModel_T		*vehicleModel,	/**< Fahrzeugmodell */
									IN	const	powertrainInput_T	*powertrain,	/**< Eingelesene Triebstrangsignale */
									IN	const	real32_T			 curvature,		/**< Kurvenkr�mmung */
									IN	const	real32_T			 slope,			/**< Steigung */
									IN	const	real32_T			 velocity,		/**< Geschwindigkeit */
									IN	const	real32_T			 devEngaged,	/**< Zugkraftabweichung (geschlossener Triebstang) */
									IN	const	real32_T			 devDisengaged,	/**< Zugkraftabweichung (offener Triebstang) */
									IN	const	uint8_T				 controlGear,	/**< Wunschgang vom Modul longController */
									IN	const	bool_T				 gearRelevant,	/**< Ob der Wunschgang ber�cksichtigt wird */
									OUT			powertrainState_T	*state			/**< Triebstrangzustand */
									);


/**\brief Sperrt Segeln bei Bremsvorg�ngen

Wenn das Gesamtbremsmoment eine applizierbare Schwelle �berschreitet, sperrt die Funktion wird nach einer Wartezeit die Segelanforderung.
Nachdem die Bremse wirder ge�ffnet ist, wartet die Funktion eine applizierbare Sperrzeit ab.
Nach Ablauf der Sperrzeit gibt die FUnktion die Segelanforderung wieder frei.

\spec SwMS_Innodrive2_Input_1466
\ingroup vehicleObserver_internal
*/
bool_T			vobsUpdateLockCoast(INOUT		lockCoastFilter_T	*filter,					/**<Entprellz�hler und Sperrstatus Segeln*/
									IN	const	dynamicsInput_T		*dynamcis,					/**<Enth�lt Bremsmomente*/
									IN	const	real32_T			 velocity,					/**<Eigengeschwindigkeit*/
									INOUT		bool_T				*coastingPossible			/**<�berschreiben der Segel-Erlaubnis*/
									);


#endif
