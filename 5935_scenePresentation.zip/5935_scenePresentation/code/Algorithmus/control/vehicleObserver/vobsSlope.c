#include "vehicleObserver.h"
#include "vobsSlope.h"
#include "vobsSlopeStatic.h"

#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsSlope)


bool_T				vobsSlopeUpdate(IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	real32_T				 position,
									IN	const	real32_T				 resistanceSlope,
									OUT			slopeState_T			*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	pathSlope;
	bool_T		pathKnown;
	bool_T		resistanceKnown;

	real32_T	adjSlope;
	real32_T	maxSlope;
	real32_T	minSlope;
	real32_T	outSlope;

	diagFF(vobsSlpGetSlope( mapPathInfo,
						    position,
						   &pathSlope,
						   &pathKnown));

	resistanceKnown = (resistanceSlope != INVALID_VALUE) ? true : false;

	maxSlope	= resistanceSlope + paramSet->vehicleObserver.slope.tskTolerance;
	minSlope	= resistanceSlope - paramSet->vehicleObserver.slope.tskTolerance;

	adjSlope	= pathSlope;
	adjSlope	= min(adjSlope, maxSlope);
	adjSlope	= max(adjSlope, minSlope);

	if (pathKnown) {
		if (resistanceKnown) {
			outSlope = adjSlope;
		}
		else {
			outSlope = pathSlope;
		}
	}
	else {
		if (resistanceKnown) {
			outSlope = resistanceSlope;
		}
		else {
			outSlope = 0.0f;
		}
	}

	state->slope = outSlope;

	return true;
}


static bool_T		vobsSlpGetSlope(IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	real32_T				 position,
									OUT			real32_T				*slope,
									OUT			bool_T					*known)
{
	uint16_T index;
	uint16_T idxFirst;
	uint16_T idxSecond;

	const pathInfoSlope_T	*itemFirst;
	const pathInfoSlope_T	*itemSecond;

	real32_T delta;


	/* Wenn keine g�ltigen Eintr�ge vorliegen, geben wir "unbekannt" zur�ck */
	if(mapPathInfo->slopes.count == 0u) {
		*slope	= INVALID_VALUE;
		*known	= false;

		return true;
	}


	diagFF(mapPathInfo->slopes.count <= (uint16_T)vobsINFOSLOPECOUNT);
	diagFF(position >= mapPathInfo->slopes.item[0].position);


	/* 1. Schritt: Suche nach dem Segment, das die gesuchte Position einschlie�t */
	for(index = 0u; index < (uint16_T)(vobsINFOSLOPECOUNT-1u); index++) {
		/* Die Positionen der g�ltigen Attribute m�ssen monoton steigend sein */
		diagFF(mapPathInfo->slopes.item[index+1u].position >= mapPathInfo->slopes.item[index].position || index + 1u >= mapPathInfo->slopes.count);

		if(mapPathInfo->slopes.item[index+1u].position >= position || index+1u == mapPathInfo->slopes.count) {
			break;
		}
		else {
			continue;
		}
	}


	/* 2. Schritt: Interpolation auf dem relevanten Segment. Wenn eine Position hinter der 
	   letzten St�tzstelle abgefragt wurde, wird "unbekannt" ausgegeben. */
	idxFirst	= min(index,    mapPathInfo->slopes.count-1u);
	idxSecond	= min(index+1u, mapPathInfo->slopes.count-1u);

	diagFF(idxFirst  < (uint16_T)vobsINFOSLOPECOUNT);
	diagFF(idxSecond < (uint16_T)vobsINFOSLOPECOUNT);

	itemFirst	= &mapPathInfo->slopes.item[idxFirst];
	itemSecond	= &mapPathInfo->slopes.item[idxSecond];


	/* Interpolation */
	delta	= (position - itemFirst->position) / (itemSecond->position - itemFirst->position);
	if(itemSecond->position <= itemFirst->position) { delta = 1.0f; }

	*slope	= itemFirst->slope + (itemSecond->slope - itemFirst->slope) * delta;
	*known	= idxSecond > idxFirst;
	
	diagFNaN(*slope);


	/* 3. Schritt: Restliche Segmente abfragen, um �bersch�ssige Rechenzeit zu "verbrennen" */
	for(; index < (uint16_T)vobsINFOSLOPECOUNT-1u; index++) {
		/* Die Positionen der g�ltigen Attribute m�ssen monoton steigend sein */
		diagFF(mapPathInfo->slopes.item[index+1u].position >= mapPathInfo->slopes.item[index].position || index + 1u >= mapPathInfo->slopes.count);

		if(mapPathInfo->slopes.item[index+1u].position > position) {
			continue;
		}
		else {
			continue;
		}
	}


	return true;
}


