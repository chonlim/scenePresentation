#include "vehicleObserver.h"
#include "vobsTurnSignal.h"
#include "vobsTurnSignalStatic.h"

#include "control/parameterSet/parameterSetCtrl.h"
#include "control/inputCodec/inputCodec_private.h"


void		   vobsTurnSignalUpdate(INOUT		turnSignalFilter_T		*filter,
									IN	const	turnSignal_T			 turnSignal,
									IN	const	bool_T					 signalLocked,
									IN	const	positionInput_T			*positionInput,
									IN  const	vmState_T				*velocityInput,
									OUT			turnSignalState_T		*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	bool_T			lockLeft;
	bool_T			lockRight;
	bool_T			forceLeft;
	bool_T			forceRight;
	turnSignal_T	resultSignal;
	bool_T			extendHold;
	bool_T			confident;

	vobsTsgGetLockConditions( positionInput,
							  paramSet->vehicleObserver.turnSignal.lockByLane,
							  paramSet->vehicleObserver.turnSignal.forceByType,
							 &lockRight,
							 &lockLeft,
							 &forceRight,
							 &forceLeft);

	vobsTsgLockFilter(&filter->lockRightTicks,
					  &lockRight,
					   paramSet->vehicleObserver.turnSignal.lockTickCount,
					   turnSignal == turnSignalRight,
					   positionInput->valid);
	
	vobsTsgLockFilter(&filter->lockLeftTicks,
					  &lockLeft,
					   paramSet->vehicleObserver.turnSignal.lockTickCount,
					   turnSignal == turnSignalLeft,
					   positionInput->valid);

	vobsTsgResultSignal( turnSignal,
						 lockRight,
						 lockLeft,
						 forceRight,
						 forceLeft,
						&resultSignal);

	vobsTsgTurnPosition(&filter->turnPosition,
						 filter->turnSignal,
						 turnSignal,
						 resultSignal,
						 paramSet->vehicleObserver.turnSignal.previewTime,
						 velocityInput);

	vobsTsgExtendHold(&filter->holdTicks,
					   paramSet->vehicleObserver.turnSignal.holdTickCount,
					   resultSignal,
					  &extendHold);
	
	/*Als letztes aufrufen, da filter->turnSignal oben verwendet wird.*/
	vobsTsgConfident(&filter->turnTicks,
					 &filter->turnSignal,
					  turnSignal,
					  paramSet->vehicleObserver.turnSignal.confTickCount,
					  signalLocked,
					  positionInput->valid,
					 &confident);

	/* Ausgabe */
	state->turnSignal	= resultSignal;
	state->position		= filter->turnPosition;
	state->confident	= confident;
	state->extendHold	= extendHold;
}


static void	   vobsTsgGetLockConditions(IN	const	positionInput_T			*positionInput,
										IN	const	bool_T					 lockByLane,
										IN	const	bool_T					 forceByType,
										OUT			bool_T					*lockRight,
										OUT			bool_T					*lockLeft,
										OUT			bool_T					*forceRight,
										OUT			bool_T					*forceLeft)
{
	/* Auswerten der spurgenauen Ortung */
	if(positionInput->valid) {
		/* Das Abbiegen nach rechts wird gesperrt, wenn wird uns nicht entweder auf der rechten oder einer
		   Abbiegespur nach rechts befinden. */
		*lockRight	= (   (positionInput->lanePosition > 1)
					   && (positionInput->laneType != laneTypeExitCombinedRight)
					   && (positionInput->laneType != laneTypeExitOnlyRight)
					   && (positionInput->laneType != laneTypeOffRampRight))
					  && lockByLane;

		/* Das Abbiegen nach links wird gesperrt, wenn wird uns nicht entweder auf der linken oder einer
		   Abbiegespur nach links befinden. */
		*lockLeft	= (   (positionInput->lanePosition < (int8_T)positionInput->laneCount)
					   && (positionInput->laneType != laneTypeExitCombinedLeft)
					   && (positionInput->laneType != laneTypeExitOnlyLeft)
					   && (positionInput->laneType != laneTypeOffRampLeft))
					  && lockByLane;

		*forceRight	= (   (positionInput->laneType == laneTypeExitOnlyRight)
					   || (positionInput->laneType == laneTypeOffRampRight))
					  && forceByType;

		*forceLeft	= (   (positionInput->laneType == laneTypeExitOnlyLeft)
					   || (positionInput->laneType == laneTypeOffRampLeft))
					  && forceByType;
	}
	else {
		*lockLeft	= false;
		*lockRight	= false;
		*forceLeft	= false;
		*forceRight	= false;
	}
}


static void			  vobsTsgLockFilter(INOUT		uint16_T				*lockTicks,
										INOUT		bool_T					*lockFlag,
										IN	const	uint16_T				 maxLockTicks,
										IN	const	bool_T					 turnSignalSet,
										IN	const	bool_T					 lapValid)
{
	uint16_T ticks = *lockTicks;
	bool_T lock;


	if (*lockFlag) {
		ticks = maxLockTicks;
		lock = true;
	} 
	else if (	(ticks > 0u) 
			 &&	turnSignalSet 
			 &&	lapValid) {
		ticks--;
		lock = true;
	}
	else {
		ticks = 0u;
		lock = false;
	}

	*lockTicks = ticks;
	*lockFlag = lock;
}


static void			vobsTsgResultSignal(IN	const	turnSignal_T			 turnSignal,
										IN	const	bool_T					 lockRight,
										IN	const	bool_T					 lockLeft,
										IN	const	bool_T					 forceRight,
										IN	const	bool_T					 forceLeft,
										OUT			turnSignal_T			*resultSignalOut)
{
	turnSignal_T resultSignal;

	/* Ausgabe */
	if(forceLeft) {
		if(lockRight) {
			resultSignal = turnSignalLeftOnly;
		}
		else if (turnSignal == turnSignalRight) {
			resultSignal = turnSignalRight;
		}
		else {
			resultSignal = turnSignalLeft;
		}
	}
	else if(forceRight) {
		if(lockLeft) {
			resultSignal = turnSignalRightOnly;
		}
		else if (turnSignal == turnSignalLeft) {
			resultSignal = turnSignalLeft;
		}
		else {
			resultSignal = turnSignalRight;
		}
	}
	else if (lockLeft && lockRight) {
		resultSignal = turnSignalLockBoth;
	}
	else if(lockLeft) 
	{
		if (turnSignal == turnSignalRight) {
			resultSignal = turnSignalRightOnly;
		}
		else {
			resultSignal = turnSignalLockLeft;
		}
	}
	else if(lockRight) {
		if (turnSignal == turnSignalLeft) {
			resultSignal = turnSignalLeftOnly;
		}
		else {
			resultSignal = turnSignalLockRight;
		}
	}
	else {
		resultSignal = turnSignal;
	}

	*resultSignalOut = resultSignal;
}


static void			vobsTsgTurnPosition(INOUT		real32_T				*turnPosition,
										IN	const	turnSignal_T			 lastTurnSignal,
										IN	const	turnSignal_T			 turnSignal,
										IN	const	turnSignal_T			 resultSignal,
										IN	const	real32_T				 previewTime,
										IN	const	vmState_T				*velocityInput)
{
	if (    (turnSignal != lastTurnSignal)
		 && (    (    (turnSignal == turnSignalLeft)
			       && (resultSignal == turnSignalLeft || resultSignal == turnSignalLeftOnly))
			  || (    (turnSignal == turnSignalRight)
				   && (resultSignal == turnSignalRight || resultSignal == turnSignalRightOnly))
			)
		)
	{
		/* wird in vobsInit() mit 0 initialisiert */
		 *turnPosition = velocityInput->position + velocityInput->velocity * previewTime;
	}
}


static void			  vobsTsgExtendHold(INOUT		uint16_T				*holdTicks,
										IN	const	uint16_T				 holdTickCount,
										IN	const	turnSignal_T			 resultSignal,
										OUT			bool_T					*extendHold)
{
	uint16_T ticks = *holdTicks;
	if (resultSignal != turnSignalNone)
	{
		ticks = holdTickCount;
	} else {
		if (ticks > 0u) {
			ticks--; 
		}
	}

	*holdTicks = ticks;
	*extendHold	= (ticks > 0u) ? true : false;
}


static void			   vobsTsgConfident(INOUT		uint16_T				*turnTicks,
										INOUT		turnSignal_T			*turnFilter,
										IN	const	turnSignal_T			 turnSignal,
										IN	const	uint16_T				 confTickCount,
										IN	const	bool_T					 signalLocked,
										IN	const	bool_T					 lapValid,
										OUT			bool_T					*confident)
{
	uint16_T ticks		= *turnTicks;
	turnSignal_T lastTurnSignal	= *turnFilter;

	if ((turnSignal == lastTurnSignal) && signalLocked) {
		if(ticks < confTickCount) {
			ticks++;
		}
	}
	else {
		ticks = 0;
	}
	
	*turnTicks = ticks;
	*turnFilter = turnSignal;
	*confident = ((ticks == confTickCount) || (lapValid)) ? true : false;

}
