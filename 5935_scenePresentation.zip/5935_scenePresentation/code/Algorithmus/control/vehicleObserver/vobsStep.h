#ifndef guard_vobsStep_h
#define guard_vobsStep_h


/**\brief Step-Funktion des Fahrzeugbeobachters

\spec SwMS_Innodrive2_Input_273 Hochz�hlen des vehicleState.tickCount

\ingroup vehicleObserver
*/
bool_T			 vobsUpdate(MEMORY		vobsMemory_T			*memory,
							IN	const	vehicleInput_T			*vehicleInput,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	mapPathInfo_T			*mapPathInfo,
							IN	const	longControlInfo_T		*longControlInfo,
							OUT			vehicleState_T			*vehicleState,
							OUT			checkState_T			*checkState
							);

/**\brief Initialisierung des Fahrzeugbeobachters

Es werden alle Werte auf Null gesetzt mit folgenden ausnahmen:
vehicleState.tickCount wird beibehalten. Er muss in \ref vobsUpdate bereits inkrementiert worden sein.
vehicleState.velocityFilter.position 

\spec SwMS_Innodrive2_Input_286

\ingroup vehicleObserver
*/
void			   vobsInit(INOUT		vobsMemory_T			*memory,
							OUT			vehicleState_T			*vehicleState,
							OUT			checkState_T			*checkState
							);


#endif
