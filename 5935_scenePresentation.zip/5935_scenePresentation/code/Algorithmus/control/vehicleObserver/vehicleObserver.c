#include "vehicleObserver.h"
#include "vobsStep.h"


void		vehicleObserver(MEMORY		vobsMemory_T			*memory,
							IN	const	vehicleInput_T			*vehicleInput,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	mapPathInfo_T			*mapPathInfo,
							IN	const	longControlInfo_T		*longControlInfo,
							OUT			vehicleState_T			*vehicleState,
							OUT			checkState_T			*checkState)
{
	/* Update des Fahrzeugzustands. Im Fehlerfall werden vehicleState und interner Zustand zur�ckgesetzt */
	if(!vobsUpdate(memory,
				   vehicleInput,
				   vehicleModel,
				   mapPathInfo,
				   longControlInfo,
				   vehicleState,
				   checkState)) {
		vobsInit(memory,
				 vehicleState,
				 checkState);
	}

}
