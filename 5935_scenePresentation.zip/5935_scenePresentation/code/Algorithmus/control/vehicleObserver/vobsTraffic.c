#include "vehicleObserver.h"
#include "vobsTraffic.h"
#include "vobsFilter.h"

#include "control/parameterSet/parameterSetCtrl.h"


void			  vobsTrafficUpdate(INOUT		trafficFilter_T			*filter,
									IN	const	accTarget_T				*target,
									IN	const	real32_T				 egoAcceleration,
									IN	const	real32_T				 deltaTime,
									IN	const	turnSignal_T			 turnSignal,
									IN	const	real32_T				 position,
									IN	const	real32_T				 velocity,
									OUT			trafficState_T			*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();
	uint16_T rampTarget;
	real32_T rampFactor;

	real32_T velocityOffset;
	real32_T accelerationOffset;

	real32_T resultAcceleration;
	real32_T filteredAcceleration;

	if(turnSignal == turnSignalNone) {
		rampTarget = 0;
	}
	else {
		rampTarget = paramSet->vehicleObserver.traffic.offset.rampTicks;
	}

	if(filter->rampFilter < rampTarget) { filter->rampFilter++; }
	if(filter->rampFilter > rampTarget) { filter->rampFilter--; }

	/* Offset-Faktor f�r die ACC-�bergabge berechnen */
	rampFactor = (real32_T)filter->rampFilter / (real32_T)paramSet->vehicleObserver.traffic.offset.rampTicks;
	rampFactor = min(rampFactor, 1.0f);

	velocityOffset		= rampFactor * paramSet->vehicleObserver.traffic.offset.velocity;
	accelerationOffset	= rampFactor * paramSet->vehicleObserver.traffic.offset.acceleration;

	resultAcceleration	= target->relAcceleration + ((paramSet->vehicleObserver.traffic.useEgoAcceleration) ? egoAcceleration : 0.0f);

	vobsLowPassFilter(&filter->acceleration,
					   deltaTime,
					   paramSet->vehicleObserver.traffic.accelerationCutOff,
					   resultAcceleration,
					  &filteredAcceleration);

	state->present		= target->present;
	state->position		= target->distance + position;
	state->position		= min(INVALID_VALUE, state->position);
	state->velocity		= target->relVelocity + velocity + velocityOffset;
	state->acceleration	= filteredAcceleration + accelerationOffset;
}
