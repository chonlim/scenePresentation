#include "vehicleObserver.h"
#include "vobsCourage.h"
#include "vobsCourageStatic.h"
#include "vobsFilter.h"

#include "control/parameterSet/parameterSetCtrl.h"
#include "common/parameterSet/parameterSet.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsCourage)


bool_T				  vobsCourageUpdate(INOUT		courageFilter_T			*filter,
										IN	const	real32_T				 deltaTime,
										IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	cameraLine_T			*lineLeft,
										IN	const	cameraLine_T			*lineRight,
										IN	const	bool_T					 signValid,
										IN	const	real32_T				 signLimit,
										IN	const	real32_T				 egoPosition,
										IN	const	real32_T				 egoVelocity,
										IN	const	real32_T				 wheelAngle,
										IN	const	real32_T				 wheelCurvature,
										IN	const	bool_T					 trafficPresent,
										IN	const	real32_T				 trafficPosition,
										IN	const	uint8_T					 wetnessLevel,
										IN	const	uint8_T					 frictionLevel,
										OUT			courageState_T			*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	widthTargetLeft;
	real32_T	widthTargetRight;
	real32_T	widthTargetMix;
	real32_T	widthConfLeft;
	real32_T	widthConfRight;
	real32_T	widthConfMix;
	real32_T	widthTarget;

	real32_T	followTarget;
	real32_T	wetnessTarget;
	real32_T	frictionTarget;

	real32_T	curvatureTarget;

	real32_T	limitLimitTarget;
	real32_T	limitMaxTarget;

	real32_T	resetLimitTarget;
	real32_T	resetCurveTarget;
	real32_T	resetMaxTarget;

	real32_T	maxJerkTarget;
	real32_T	limitJerkTarget;
	real32_T	curveJerkTarget;
	real32_T	curtainTarget;


	/* Aktualisieren der Fahrbahnbreiten-Filter */
	diagFF(vobsCrgWidthUpdate(&filter->widthLeft,
							   deltaTime,
							   wheelAngle,
							   lineLeft,
							   true,
							  &widthTargetLeft,
							  &widthConfLeft));

	diagFF(vobsCrgWidthUpdate(&filter->widthRight,
							   deltaTime,
							   wheelAngle,
							   lineRight,
							   false,
							  &widthTargetRight,
							  &widthConfRight));


	/* Die Kr�mmungsanpassung ergibt sich aus dem Minimum von linkem und rechtem Fahrbahnrand */
	widthConfMix	= min(widthConfLeft, widthConfRight);
	widthTargetMix	= max(widthTargetLeft, widthTargetRight);

	widthTargetMix	=   ((1.0f - widthConfLeft)  * widthTargetMix)
					  + (widthConfLeft  * min(widthTargetMix, widthTargetLeft));
	widthTargetMix	=   ((1.0f - widthConfRight) * widthTargetMix)
					  + (widthConfRight * min(widthTargetMix, widthTargetRight));

	/* Multiplizieren von Target-Wert und Konfidenz */
	widthTarget	= widthTargetMix * widthConfMix;


	/* Abfragen des Anpassfaktors f�r die Folgefahrt */
	diagFF(vobsCrgTrafficUpdate( egoPosition,
								 egoVelocity,
								 trafficPresent,
								 trafficPosition,
								&followTarget));

	/* Abfragen des Anpassfaktors f�r das N�sselevel*/
	diagFF(vobsCrgWetnessUpdate( wetnessLevel,
								&wetnessTarget));
	
	/* Abfragen des Anpassfaktors f�r das Reibwert-Level*/
	diagFF(vobsCrgFrictionUpdate( frictionLevel,
								 &frictionTarget));

	/* Aktualisieren des Filters f�r ds Verlassen des Kreisverkehrs */
	diagFF(vobsCrgCurtainUpdate( mapPathInfo,
								 wheelCurvature,
								&curtainTarget));


	/* Aktualiseren des Filters f�r unerwartete Speed Limit-�nderungen */
	diagFF(vobsCrgLimitUpdate(&filter->limitFilter,
							   mapPathInfo,
							   signValid,
							   signLimit,
							   egoPosition,
							  &limitMaxTarget,
							  &limitLimitTarget));


	/* Aktualisieren des Filters f�r PSD-Baum-Resets */
	diagFF(vobsCrgResetUpdate( mapPathInfo,
							  &resetMaxTarget,
							  &resetLimitTarget,
							  &resetCurveTarget));


	/* Zielwerte f�r Ruckanpassungen zwischen Limit- und Reset-Filter aushandeln  */
	maxJerkTarget	= min(limitMaxTarget,	resetMaxTarget);
	limitJerkTarget	= min(limitLimitTarget,	resetLimitTarget);
	curveJerkTarget	= resetCurveTarget;


	/* Zielwerte einschr�nken */
	curvatureTarget = widthTarget + followTarget + wetnessTarget + frictionTarget;
	curvatureTarget = min(curvatureTarget,	paramSet->vehicleObserver.courage.curvatureMax);
	curvatureTarget = max(curvatureTarget,	paramSet->vehicleObserver.courage.curvatureMin);


	/* Anpassraten einschr�nken */
	curvatureTarget	= min(curvatureTarget,	filter->curvatureFactor + paramSet->vehicleObserver.courage.curvatureRateMax	* deltaTime);
	curvatureTarget	= max(curvatureTarget,	filter->curvatureFactor + paramSet->vehicleObserver.courage.curvatureRateMin	* deltaTime);

	curtainTarget	= min(curtainTarget,	filter->curtainFactor	+ paramSet->vehicleObserver.courage.curtainMaxRate		* deltaTime);
	curtainTarget	= max(curtainTarget,	filter->curtainFactor	+ paramSet->vehicleObserver.courage.curtainMinRate		* deltaTime);

	maxJerkTarget	= min(maxJerkTarget,	filter->maxJerkFactor	+ paramSet->vehicleObserver.courage.maxJerkMaxRate		* deltaTime);
	limitJerkTarget	= min(limitJerkTarget,	filter->limitJerkFactor	+ paramSet->vehicleObserver.courage.limitJerkMaxRate	* deltaTime);
	curveJerkTarget	= min(curveJerkTarget,	filter->curveJerkFactor	+ paramSet->vehicleObserver.courage.curveJerkMaxRate	* deltaTime);


	/* Aktualisieren des Filters */
	filter->curvatureFactor	= curvatureTarget;
	filter->maxJerkFactor	= maxJerkTarget;
	filter->limitJerkFactor	= limitJerkTarget;
	filter->curveJerkFactor	= curveJerkTarget;
	filter->curtainFactor	= curtainTarget;


	/* Ausgabe */
	state->curvatureFactor	= filter->curvatureFactor;
	state->maxJerkFactor	= filter->maxJerkFactor;
	state->limitJerkFactor	= filter->limitJerkFactor;
	state->curveJerkFactor	= filter->curveJerkFactor;
	state->curtainFactor	= filter->curtainFactor;


	return true;
}


static bool_T		 vobsCrgWidthUpdate(INOUT		vobsWidthFilter_T		*filter,
										IN	const	real32_T				 deltaTime,
										IN	const	real32_T				 wheelAngle,
										IN	const	cameraLine_T			*cameraLine,
										IN	const	bool_T					 lineIsLeft,
										OUT			real32_T				*target,
										OUT			real32_T				*confidence)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	adaptionFactor;

	real32_T	lastAverage;
	real32_T	targetDistance;
	real32_T	average;
	real32_T	confTarget;
	bool_T		lineValid;

	real32_T	targetMin;
	real32_T	targetMax;

	real32_T	avgFactor;
	real32_T	difFactor;
	real32_T	sumFactor;


	/* Anpassrate aus dem Lenkradwinkel berechnen */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.width.adaptionFactor.angle,
						   paramSet->vehicleObserver.courage.width.adaptionFactor.rate,
						   paramSet->vehicleObserver.courage.width.adaptionFactor.count,
						   prmNUMADAPTIONRATE,
						   fabsf(wheelAngle),
						  &adaptionFactor));


	/* Abh�ngig von Links- bzw. Rechtsverkehr w�hlen wir die Fahrbahnbegrenzung aus,
	   die n�her am Stra�enrand liegt */
	lineValid		= cameraLine->valid;
	targetDistance	= lineValid ? cameraLine->distance : (lineIsLeft ? -paramSet->vehicleObserver.courage.width.faultDistance : paramSet->vehicleObserver.courage.width.faultDistance);


	/* Ggf. muss der Konfidenzwert des Filters angepasst werden */
	if (lineValid) {
		confTarget = min(1.0f, filter->confidence + paramSet->vehicleObserver.courage.width.confidenceRate * deltaTime);
	} else {
		confTarget = max(0.0f, filter->confidence - paramSet->vehicleObserver.courage.width.confidenceRate * deltaTime);
	}
	

	/* Abfragen des durchschnittlichen Abstands im letzten Zeitschritt */
	vobsFilterGetOutput(&filter->avgDistance, &lastAverage);


	/* Wenn wir im letzten Zeitschritt keine g�ltige Markierung gesehen haben,
	   initialisieren wir den Durchschnitts-Filter neu */
	if(!filter->lastValid) {
		vobsFilterSetMemory(&filter->avgDistance,
							 targetDistance);

		average	= targetDistance;
	}
	else {
		vobsLowPassFilter(&filter->avgDistance,
						   deltaTime,
						   paramSet->vehicleObserver.courage.width.avgCutOffFreq,
						   targetDistance,
						  &average);
	}


	/* �nderungen am Durchschnittswert werden auf den Minimal- und Maximalwert �bertragen */
	filter->maxDistance	+= average - lastAverage;
	filter->minDistance	+= average - lastAverage;


	/* Abh�ngig vom Istabstand relativ zum durchschnittlichen Abstand aktualisieren wir
	   entweder den Min- oder der Maxwert. Der andere Wert driftet in Richtung Durchschnitt. */
	targetMin	= targetDistance;
	targetMin	= min(targetMin, average);
	targetMin	= min(targetMin, filter->minDistance + paramSet->vehicleObserver.courage.width.driftVelocity * adaptionFactor * deltaTime);
	targetMin	= max(targetMin, filter->minDistance - paramSet->vehicleObserver.courage.width.pullVelocity  * adaptionFactor * deltaTime);

	targetMax	= targetDistance;
	targetMax	= max(targetMax, average);
	targetMax	= min(targetMax, filter->maxDistance + paramSet->vehicleObserver.courage.width.pullVelocity  * adaptionFactor * deltaTime);
	targetMax	= max(targetMax, filter->maxDistance - paramSet->vehicleObserver.courage.width.driftVelocity * adaptionFactor * deltaTime);


	/* Der Anpassfaktor ergibt sich aus dem Durchschnitt und der Differenz zwischen Min- und Maxwert */
	avgFactor	= (fabsf(average)        - paramSet->vehicleObserver.courage.width.averageMin)    / (paramSet->vehicleObserver.courage.width.averageDiv);
	difFactor	= ((targetMax - targetMin) - paramSet->vehicleObserver.courage.width.differenceMin) / (paramSet->vehicleObserver.courage.width.differenceDiv);

	avgFactor	= max(avgFactor, 0.0f);
	difFactor	= max(difFactor, 0.0f);

	sumFactor	= avgFactor + difFactor;
	sumFactor	= min(sumFactor, 1.0f);


	/* Aktualisieren des Filters */
	filter->lastValid	= lineValid;
	filter->confidence	= confTarget;
	filter->maxDistance	= targetMax;
	filter->minDistance	= targetMin;


	/* Ausgabe */
	*target				= sumFactor;
	*confidence			= confTarget;


	return true;
}


static bool_T	   vobsCrgCurtainUpdate(IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	real32_T				 wheelCurvature,
										OUT			real32_T				*curtainFactor)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	curvatureDelta;

	real32_T	tailFactor;
	real32_T	curvatureFactor;


	/* Berechnen der relevanten Kr�mmungsabweichung */
	curvatureDelta	= mapPathInfo->curvature > 0.0f 
					  ? (mapPathInfo->curvature - wheelCurvature)
					  : (wheelCurvature - mapPathInfo->curvature);


	/* Anpassrate aus der Wegstrecke im Kreisverkehr berechnen */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.curtain.tailFactor.tail,
						   paramSet->vehicleObserver.courage.curtain.tailFactor.factor,
						   paramSet->vehicleObserver.courage.curtain.tailFactor.count,
						   prmNUMTAILFACTOR,
						   mapPathInfo->roundaboutTail,
						  &tailFactor));


	/* Anpassrate aus der Kr�mmungsdifferenz zwischen Karte und Lenkrad berechnen */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.curtain.curvatureFactor.curvature,
						   paramSet->vehicleObserver.courage.curtain.curvatureFactor.factor,
						   paramSet->vehicleObserver.courage.curtain.curvatureFactor.count,
						   prmNUMCURVATUREFACTOR,
						   curvatureDelta,
						  &curvatureFactor));


	/* Ausgabe */
	*curtainFactor = tailFactor * curvatureFactor;


	return true;
}


static bool_T		 vobsCrgLimitUpdate(INOUT		vobsLimitFilter_T		*filter,
										IN	const	mapPathInfo_T			*mapPathInfo,
										IN	const	bool_T					 cameraValid,
										IN	const	real32_T				 cameraLimit,
										IN	const	real32_T				 egoPosition,
										OUT			real32_T				*maxJerkTarget,
										OUT			real32_T				*limitJerkTarget)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	uint16_T	index;
	real32_T	knownMin;
	real32_T	knownMax;
	real32_T	currentLimit;

	real32_T	upperTarget;
	real32_T	lowerTarget;


	knownMin		=  INVALID_VALUE;
	knownMax		= -INVALID_VALUE;
	currentLimit	=  INVALID_VALUE;

	for(index = 0; index < (uint16_T)vobsINFOLIMITCOUNT; index++) {
		const pathInfoLimit_T *limit = &mapPathInfo->limits.item[index];

		/* Ist dieser Eintrag relevant f�r das aktuell g�ltige Limit? */
		if(   (limit->position < egoPosition)
		   && (index < mapPathInfo->limits.count)) {
			currentLimit	= limit->velocity;
		}
		else {
			currentLimit	= currentLimit;
		}


		/* Ist dieser Eintrag relevant f�r das minimal und maximal erwartete Limit? */
		if(   (limit->position < egoPosition + paramSet->vehicleObserver.courage.limit.maxHorizon)
		   && (limit->position > egoPosition + paramSet->vehicleObserver.courage.limit.minHorizon)
		   && (index < mapPathInfo->limits.count)) {
			knownMin		= min(knownMin, limit->velocity);
			knownMax		= max(knownMax, limit->velocity);
		}
		else {
	
			knownMin		= min(knownMin, knownMin);
			knownMax		= max(knownMax, knownMax);
		}
	}


	/* Ggf. �berschreibt die Kamera das aktuell g�ltige Limit */
	currentLimit = cameraValid ? cameraLimit : currentLimit;

	knownMax = max(knownMax, currentLimit);
	knownMin = min(knownMin, currentLimit);


	/* Begrenzen der maximalen Geschwindigkeit, die f�r den Filter herangezogen wird */
	currentLimit	= min(currentLimit,	paramSet->vehicleObserver.courage.limit.maxVelocity);
	knownMax		= min(knownMax,		paramSet->vehicleObserver.courage.limit.maxVelocity);
	knownMin		= min(knownMin,		paramSet->vehicleObserver.courage.limit.maxVelocity);


	/* Abgleich des aktuellen Limits mit den letzten bekannten  Werten */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.limit.upperDeviation.deviation,
						   paramSet->vehicleObserver.courage.limit.upperDeviation.factor,
						   paramSet->vehicleObserver.courage.limit.upperDeviation.count,
						   prmNUMLIMITDEVFACTOR,
						   currentLimit - filter->knownMax,
						  &upperTarget));

	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.limit.lowerDeviation.deviation,
						   paramSet->vehicleObserver.courage.limit.lowerDeviation.factor,
						   paramSet->vehicleObserver.courage.limit.lowerDeviation.count,
						   prmNUMLIMITDEVFACTOR,
						   currentLimit - filter->knownMin,
						  &lowerTarget));

	if(   (filter->holdTicks >= paramSet->vehicleObserver.courage.limit.holdTicks)
	   || (!filter->valid)) {
		upperTarget = 0.0f;
		lowerTarget = 0.0f;
	}


	/* Aktualisieren des Filters */
	filter->holdTicks	+= (filter->holdTicks <= paramSet->vehicleObserver.courage.limit.holdTicks) ? (uint16_T)1 : (uint16_T)0;

	filter->valid		= (mapPathInfo->limits.count > 0u) ? true		: filter->valid;
	filter->holdTicks	= (mapPathInfo->limits.count > 0u) ? 0u			: filter->holdTicks;
	filter->knownMax	= (mapPathInfo->limits.count > 0u) ? knownMax	: filter->knownMax;
	filter->knownMin	= (mapPathInfo->limits.count > 0u) ? knownMin	: filter->knownMin;


	/* Ausgabe */
	*maxJerkTarget		= upperTarget;
	*limitJerkTarget	= lowerTarget;


	return true;
}


static bool_T	   vobsCrgTrafficUpdate(IN	const	real32_T				 egoPosition,
										IN	const	real32_T				 egoVelocity,
										IN	const	bool_T					 trafficPresent,
										IN	const	real32_T				 trafficPosition,
										OUT			real32_T				*curvatureTarget)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T timeGap;
	real32_T gapFactor;


	/* Berechnen der Zeitl�cke aus der Ego-Geschwindigkeit und dem Abstand zum Vorausfahrenden */
	timeGap = (trafficPosition - egoPosition) / max(egoVelocity, 0.1f);


	/* Anpassfaktor aus der Zeitl�cke zum Zielobjekt berechnen */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.follow.gapFactor.timeGap,
						   paramSet->vehicleObserver.courage.follow.gapFactor.factor,
						   paramSet->vehicleObserver.courage.follow.gapFactor.count,
						   prmNUMFOLLOWGAPFACTOR,
						   timeGap,
						  &gapFactor));


	/* Ausgabe */
	*curvatureTarget = (trafficPresent ? gapFactor : 0.0f);


	return true;
}


static bool_T	   vobsCrgWetnessUpdate(IN	const	uint8_T					 wetnessLevel,
										OUT			real32_T				*wetnessTarget)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();
	real32_T target;

	/* Anpassfaktor aus dem N�sselevel berechnen */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.wetness.adaptionFactor.level,
						   paramSet->vehicleObserver.courage.wetness.adaptionFactor.factor,
						   paramSet->vehicleObserver.courage.wetness.adaptionFactor.count,
						   prmNUMWETNESSFACTOR,
						   (real32_T)wetnessLevel,
						  &target));


	/* Ausgabe */
	if (	wetnessLevel < (uint8_T)incWetnessLevelError
		&&	paramSet->vehicleObserver.courage.wetness.enabled)
	{
		*wetnessTarget = target;
	} else {
		*wetnessTarget = 0.0f;
	}

	return true;
}



static bool_T	  vobsCrgFrictionUpdate(IN	const	uint8_T					 frictionLevel,
										OUT			real32_T				*frictionTarget)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();
	real32_T target;

	/* Anpassfaktor aus dem Reibwert berechnen */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.friction.adaptionFactor.level,
						   paramSet->vehicleObserver.courage.friction.adaptionFactor.factor,
						   paramSet->vehicleObserver.courage.friction.adaptionFactor.count,
						   prmNUMFRICTIONFACTOR,
						   (real32_T)frictionLevel,
						  &target));


	/* Ausgabe */
	if (	frictionLevel < (uint8_T)incFrictionLevelError
		&&	paramSet->vehicleObserver.courage.friction.enabled)
	{
		*frictionTarget = target;
	} else {
		*frictionTarget = 0.0f;
	}

	return true;
}


static bool_T		 vobsCrgResetUpdate(IN	const	mapPathInfo_T			*mapPathInfo,
										OUT			real32_T				*maxJerkTarget,
										OUT			real32_T				*limitJerkTarget,
										OUT			real32_T				*curveJerkTarget)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T ageTarget;


	/* Anpassungsfaktor f�r L�ngsruck aus dem Alter des PSD-Baums ableiten */
	diagFF(prmInterpolate( paramSet->vehicleObserver.courage.reset.ageFactor.ticks,
						   paramSet->vehicleObserver.courage.reset.ageFactor.factor,
						   paramSet->vehicleObserver.courage.reset.ageFactor.count,
						   prmNUMRESETAGEFACTOR,
						  (real32_T)mapPathInfo->ageTicks,
						  &ageTarget));


	/* Ausgabe */
	*maxJerkTarget		= ageTarget;
	*limitJerkTarget	= ageTarget;
	*curveJerkTarget	= ageTarget;


	return true;
}
