#include "vehicleObserver.h"
#include "vobsVMax.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsVMax)


bool_T				 vobsVMaxUpdate(INOUT		vMaxFilter_T			*filter,
									IN	const	displayUnit_T			 vMaxUnit,
									IN	const	uint16_T				 vMaxRaw,
									OUT			vMax_T					*state)
{
	if (vMaxUnit == dsplUnitKph)
	{
		filter->kmh.valid = true;
		filter->kmh.value = vMaxRaw;
	}
	else if (vMaxUnit == dsplUnitMph) 
	{
		filter->mph.valid = true;
		filter->mph.value = vMaxRaw;
	}
	else
	{
		diagFUnreachable();
	}

	state->kmh = filter->kmh.valid ? filter->kmh.value : INVALID_UINT16;
	state->mph = filter->mph.valid ? filter->mph.value : INVALID_UINT16;

	return true;
}
