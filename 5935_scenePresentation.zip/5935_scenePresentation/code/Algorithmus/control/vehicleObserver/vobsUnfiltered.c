#include "vehicleObserver.h"
#include "vobsUnfiltered.h"


void			vobsUnfilteredUpdate(	IN	const	real32_T				 rawVelocity,
										IN	const	real32_T				 displayVelocity,
										IN	const	real32_T				 longAcceleration,
										IN	const	real32_T				 latAcceleration,
										IN	const	real32_T				 accelerator,
										OUT			unfilteredState_T		*state)
{
	state->velocity			= rawVelocity;
	state->displayVelocity  = displayVelocity;
	state->longAcceleration	= longAcceleration;
	state->latAcceleration	= latAcceleration;
	state->accelerator		= accelerator;
}
