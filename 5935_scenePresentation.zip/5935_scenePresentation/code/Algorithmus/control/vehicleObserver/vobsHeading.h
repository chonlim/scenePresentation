#ifndef guard_vobsHeading_h
#define guard_vobsHeading_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"


/**\brief Update der Fahrzeugausrichtung

\spec SwMS_Innodrive2_Input_294 (Aktualisierung �ber Gierrate)
\spec SwMS_Innodrive2_Input_295 (Korrektur �ber Eingangssignal)
\spec SwMS_Innodrive2_Input_296 (Begrenzung der Abweichung vom Eingangssignal)
\spec SwMS_Innodrive2_Input_297 (Neuinitialisierung auf Eingangssignal)
\spec SwMS_Innodrive2_Input_298 (Valid-Flag)

\ingroup vehicleOobserver
*/
bool_T			  vobsHeadingUpdate(INOUT		headingFilter_T		*filter,
									IN	const	real32_T			 deltaTime,
									IN	const	real32_T			 yawRate,
									IN	const	real32_T			 gpsHeading,
									IN	const	bool_T				 gpsValid,
									OUT			headingState_T		*state
									);


#endif
