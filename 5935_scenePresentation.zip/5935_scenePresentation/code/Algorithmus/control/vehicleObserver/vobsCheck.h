#ifndef guard_vobsCheck_h
#define guard_vobsCheck_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/vehicleModel/vehicleModel_interface.h"


/**\brief Berechnet Angaben zum Setzen von Diagnose-Fehlerspeichereintr�ge (DTCs)

Die Funktion vobsCheckUpdate() f�hrt drei �berpr�fungen durch und speichert die Ergebnisse im `checkState_T`:
Der `codeCheck` schl�gt fehl, wenn der Motorcode nicht im vehicleModel eingetragen ist.
Der `velocityCheck` schl�gt fehl, wenn genau eine Geschwindigkeit ung�ltig ist, da sie dann durch die andere Geschwindigkeit ersetzt wird.
Der `controlCheck` schl�gt fehl, wenn der longController meldet, dass keine g�ltige Pfadplanung aus dem strategy-Task vorliegt.
Der `freeRideCheck` schl�gt fehl, wenn als maximal automatisch eingeregelte Geschwindigkeit ein ung�ltiges Signal empfangen wird.

Ein fehlgeschlagener Test wird durch `failed == true` angezeigt. 
Die Variable `count` z�hlt die Rechenzyklen seit dem letzten Wechsel des jeweiligen `failed`-Zustands.

\spec SwMS_Innodrive2_Input_384
\spec SwMS_Innodrive2_Input_385
\spec SwMS_Innodrive2_Input_386
\spec SwMS_Innodrive2_Input_1479

\ingroup vehicleObserver_internal
*/
bool_T				vobsCheckUpdate(INOUT		checkFilter_T			*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	uint8_T					 motorCode,
									IN	const	real32_T				 rawVelocity,
									IN	const	real32_T				 displayVelocity,
									IN	const	real32_T				 maxAutoSpeed,
									IN	const	bool_T					 longControlValid,
									OUT			checkState_T			*state
									);


#endif
