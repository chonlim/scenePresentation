#ifndef guard_vobsCurvature_h
#define guard_vobsCurvature_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "control/inputCodec/inputCodec_private.h"

/**\brief Aktualisierung des Fahrbahnverlaufs aus Kameradaten

\spec SwMS_Innodrive2_Input_315 (Kombination von Angaben f�r linke und rechte Fahrbahnbegrenzung)
\spec SwMS_Innodrive2_Input_319 (Tiefpassfilter der Angaben)
\spec SwMS_Innodrive2_Input_314 (Initialisierung bei nicht vorhandenen Eingangsdaten)

\ingroup vehicleObserver
*/
bool_T			vobsCurvatureUpdate(INOUT		curvatureFilter_T		*filter,
									IN	const	real32_T				 deltaTime,
									IN	const	cameraLine_T			*lineLeft,
									IN	const	cameraLine_T			*lineRight,
									OUT			curvatureState_T		*state
									);


#endif
