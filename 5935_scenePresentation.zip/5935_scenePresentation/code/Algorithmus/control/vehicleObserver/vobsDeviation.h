#ifndef guard_vobsDeviation_h
#define guard_vobsDeviation_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"

/**\brief Update der Zugkraftabweichung

\spec SwMS_Innodrive2_Input_306
\spec SwMS_Innodrive2_Input_307
\spec SwMS_Innodrive2_Input_308
\spec SwMS_Innodrive2_Input_309
\spec SwMS_Innodrive2_Input_310

\ingroup vehicleObserver
*/
bool_T			vobsDeviationUpdate(INOUT		deviationFilter_T		*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	longControlInfo_T		*longControlInfo,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	uint8_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	bool_T					 serviceBrakeEngaged,
									IN	const	bool_T					 systemRelevant,
									OUT			deviationState_T		*state
									);



#endif
