#ifndef guard_vobsTurnSignalStatic_h
#define guard_vobsTurnSignalStatic_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"


/**\brief SPerrt oder erwzingt Abzewigungen aufgrund der Spurpositionierung
\spec SwMS_Innodrive2_Input_336
\spec SwMS_Innodrive2_Input_337

\ingroup vehicleObserver
*/


static void	   vobsTsgGetLockConditions(IN	const	positionInput_T			*positionInput,		/**<Spurposition*/
										IN	const	bool_T					 lockByLane,		/**<Parameter: Abzweige sperren*/
										IN	const	bool_T					 forceByType,		/**<Parameter: Abzweige erzwingen*/
										OUT			bool_T					*lockRight,			/**<Rechts sperren*/
										OUT			bool_T					*lockLeft,			/**<Links  sperren*/
										OUT			bool_T					*forceRight,		/**<Rechts erzwingen*/
										OUT			bool_T					*forceLeft			/**<Links  erzwingen*/
										);


/**\brief H�lt die Sperrung einer Abzweigung f�r eine applizierbare Anzahl von Zeitschritten aufrecht.

Wenn der Fahrer mit gesetztem Blinker nach rechts auf die rechte Spur wechselt, 
soll der Zustand "lock" f�r eine applizierbare Zeit gehalten werden, 
nachdem das Fahrzeug auf die rechte Spur gewechselt hat. 
Erst nach Ablauf dieser Zeit ist ein Abfahren nach rechts zul�ssig.
Die Sperrung soll aufgehoben werden, wenn der Blinker zur�ckgenommen wird oder die Spurinformation nicht mehr verf�gbar ist.


\spec SwMS_Innodrive2_Input_1482

\ingroup vehicleObserver
*/
static void			  vobsTsgLockFilter(INOUT		uint16_T				*lockTicks,			/**<Restticks, die die Sperrung noch gehalten wird. [0.02s]*/
										INOUT		bool_T					*lockFlag,			/**<Abfahrt sperren*/
										IN	const	uint16_T				 maxLockTicks,		/**<Parameter: Maximale Ticks, die die Sperrung gehalten wird [0.02s]*/
										IN	const	bool_T					 turnSignalSet,		/**<Blinker gesetzt?*/
										IN	const	bool_T					 lapValid			/**<Spurpositionsinformationen g�ltig?*/
										);


/**\brief Blinksignal nach Spurpositionierung plausibilisieren.

\spec SwMS_Innodrive2_Input_335
\spec SwMS_Innodrive2_Input_346

\ingroup vehicleObserver
*/
static void			vobsTsgResultSignal(IN	const	turnSignal_T			 turnSignal,		/**<Original Blinksignal (Nur None, Left, Right)*/
										IN	const	bool_T					 lockRight,			/**<Rechts sperren*/
										IN	const	bool_T					 lockLeft,			/**<Links  sperren*/
										IN	const	bool_T					 forceRight,		/**<Rechts erzwingen*/
										IN	const	bool_T					 forceLeft,			/**<Links  erzwingen*/
										OUT			turnSignal_T			*resultSignalOut	/**<Blinksignal nach Ber�cksichtigung Spurpositionierung*/
										);


/*\brief Aktualisiert die Position der �nderung des Blinkersignals.

\specSwMS_Innodrive2_Input_380 

\ingroup vehicleObserver
*/
static void			vobsTsgTurnPosition(INOUT		real32_T				*turnPosition,		/**<Position der letzten Blinker-�nderung*/
										IN	const	turnSignal_T			 lastTurnSignal,	/**<Letzter Blinker-Rohwert*/
										IN	const	turnSignal_T			 turnSignal,		/**<Aktueller Blinker-Rohwert*/
										IN	const	turnSignal_T			 resultSignal,		/**<Blinkerwert mit ber�cksichtigtem perrenz/erzwingen*/
										IN	const	real32_T				 previewTime,		/**<Parameter: Vorausschauzeit f�r die Positionierung der �nderung*/
										IN	const	vmState_T				*velocityInput		/**<Eigengeschwindigkeit und -Position*/
										);


/*\brief Ob sich resultSignal in der letzten Zeit ge�ndert hat.

\spec SwMS_Innodrive2_Input_363

\ingroup vehicleObserver
*/
static void			  vobsTsgExtendHold(INOUT		uint16_T				*holdTicks,			/**<Gehaltene Zeitschritte*/
										IN	const	uint16_T				 holdTickCount,		/**<Parameter: Zu haltende Zeitschritte*/
										IN	const	turnSignal_T			 resultSignal,		/**<Blinkersignal nach Auswertung von sperren/erzwingen*/
										OUT			bool_T					*extendHold			/**<Ob �nderung von resultSignal*/
										);


/**\brief Wenn sich der Blinker-Rohwert eine Zeitlang nicht ver�ndert, wird die Confidence-Flag gesetzt.

\spec SwMS_Innodrive2_Input_348  

\ingroup vehicleObserver
*/
static void			   vobsTsgConfident(INOUT		uint16_T				*turnTicks,			/**<Ticks seit letzter Blinker-�nderung*/
										INOUT		turnSignal_T			*turnFilter,		/**<Letzter Blinker-Rohwert*/
										IN	const	turnSignal_T			 turnSignal,		/**<Blinker-Rohwert*/
										IN	const	uint16_T				 confTickCount,		/**<Warteticks zum setzen der confident-Flag*/
										IN	const	bool_T					 signalLocked,		/**<Blinkerhebel eingerastet (d.h.: nicht Autobahnblinken/Comfortblinken)*/
										IN	const	bool_T					 lapValid,			/**<Spurpositionsinformationen g�ltig?*/
										OUT			bool_T					*confident			/**<*/
										);

#endif
