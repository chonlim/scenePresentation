#ifndef guard_vobsAccBoost_h
#define guard_vobsAccBoost_h

#include "control/vehicleObserver/vehicleObserver.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"

/**\brief Erkkent die aktivierung der Funktion ACC-Boost wenn die Taste "resume" gehalten wird.

\spec SwMS_Innodrive2_Input_1452

\ingroup vehicleObserver_internal
*/
void				 vobsUpdateAccBoost(INOUT		accBoostFilter_T *filter,
										IN	const	bool_T			  resume,
										OUT			bool_T			 *accBoost
										);

#endif
