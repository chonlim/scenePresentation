#ifndef __vobsLineTracking_h__
#define __vobsLineTracking_h__

#include "common/vehicleObserverCommon/vehicleObserver_private.h"

typedef struct _lineResult {
	bool_T		valid;

	struct _lr_right {
		trackedLine_T	ego;
		trackedLine_T	next;
	} left, right;
} lineResult_T;


#ifdef __cplusplus
extern "C" {
#endif


	bool_T			  vobsUpdateLineTracking(MEMORY		lineTracking_T	*lineTracking,
											IN	const	real32_T			 position,
											IN	const	real32_T			 time,
											IN	const	real32_T			 egoDeltaD,
											IN	const	real32_T			 egoDeltaH,
											IN	const	cameraInput_T		*cameraInput,
											OUT	OPT		lineResult_T		*lineResult);


	static bool_T	 vobsPredictLineTracking(INOUT		lineTracking_T	*lineTracking,
											IN	const	real32_T			 position,
											IN	const	real32_T			 time,
											IN	const	real32_T			 egoDeltaD,
											IN	const	real32_T			 egoDeltaH);


	static bool_T			 vobsPredictLine(INOUT		trackedLine_T	*line,
											IN	const	real32_T			 position,
											IN	const	real32_T			 time,
											IN	const	real32_T			 egoDeltaD,
											IN	const	real32_T			 egoDeltaH);


	static bool_T	 vobsConfirmLineTracking(INOUT		lineTracking_T	*lineTracking,
											IN	const	real32_T			 position,
											IN	const	real32_T			 time,
											IN	const	cameraInput_T		*cameraInput);


	static bool_T			vobsGetBestMatch(IN	const	lineTracking_T	*lineTracking,
											IN	const	cameraInputLine_T	*cameraLine,
											OUT	OPT		uint8_T				*matchIndex);


	static bool_T			vobsAllocateLine(INOUT		lineTracking_T	*lineTracking,
											OUT	OPT		uint8_T				*index);


	static bool_T			 vobsConfirmLine(IN	const	cameraInputLine_T	*cameraLine,
											IN	const	real32_T			 position,
											IN	const	real32_T			 time,
											OUT			trackedLine_T	*line);


	static bool_T			vobsGetLineResult(	IN	const	lineTracking_T	*lineTracking,
												OUT			lineResult_T	*lineResult);


#ifdef __cplusplus
}
#endif


#endif
