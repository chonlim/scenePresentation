#ifndef guard_vobsFilter_h
#define guard_vobsFilter_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"


/**\brief PT1-Tiefpassfilter
\ingroup vehicleObserver_internal
*/
void			  vobsLowPassFilter(MEMORY		vobsFilter_T			*filter,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 cutoffFreq,
									IN	const	real32_T				 input,
									INOUT		real32_T				*output
									);

/**\brief Setter f�r den PT1-Tiefpassfilter
\ingroup vehicleObserver_internal
*/
void			vobsFilterSetMemory(MEMORY		vobsFilter_T			*filter,
									IN	const	real32_T				 input
									);

/**\brief Getter f�r den PT1-Tiefpassfilter
\ingroup vehicleObserver
*/
void			vobsFilterGetOutput(IN	const	vobsFilter_T			*filter,
									OUT			real32_T				*output
									);


#endif
