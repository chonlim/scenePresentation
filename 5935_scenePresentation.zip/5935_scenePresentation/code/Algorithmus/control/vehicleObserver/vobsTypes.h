#ifndef guard_vobsTypes_h
#define guard_vobsTypes_h

#include "control/control.h"

#endif
