#ifndef _vobsLateral_H_
#define _vobsLateral_H_

#include "control/control.h"
#include "vobsLineTracking.h"

#ifdef __cplusplus
extern "C" {
#endif


	bool_T			  vobsLateralFilter(INOUT		lateralFilter_T			*lateralFilter,
										IN	const	cameraInput_T			*cameraInput,	
										IN	const	real32_T				 time,			
										IN	const	real32_T				 position,		
										IN	const	real32_T				 measuredYawRate);


	static bool_T	vobsGetTrackPosition(IN	const	lineResult_T			*lineResult,
										 OUT			trackPosition_T			*trackPosition,
										 OUT			cameraInfo_T			*cameraInfo);


#ifdef __cplusplus
}
#endif


#endif
