#ifndef guard_vobsUnfiltered_h
#define guard_vobsUnfiltered_h

#include "common/vehicleObserverCommon/vehicleObserver_private.h"


/** \brief Update der ungefilterten Daten
\spec SwMS_Innodrive2_Input_329
\ingroup vehicleObserver_internal
*/
void			vobsUnfilteredUpdate(	IN	const	real32_T				 rawVelocity,
										IN	const	real32_T				 displayVelocity,
										IN	const	real32_T				 longAcceleration,
										IN	const	real32_T				 latAcceleration,
										IN	const	real32_T				 accelerator,
										OUT			unfilteredState_T		*state
										);

#endif
