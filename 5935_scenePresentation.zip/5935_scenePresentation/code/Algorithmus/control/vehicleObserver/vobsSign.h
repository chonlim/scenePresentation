#ifndef guard_vobsSign_h
#define guard_vobsSign_h

#include "../../common/vehicleObserverCommon/vehicleObserver_private.h"
#include "../inputCodec/inputCodec_private.h"


/**\brief Update der von der Verkehrszeichenerkennung erkannten Tempolimit

\spec SwMS_Innodrive2_Input_324
\spec SwMS_Innodrive2_Input_325
\spec SwMS_Innodrive2_Input_326
\spec SwMS_Innodrive2_Input_327
\spec SwMS_Innodrive2_Input_407

\ingroup vehicleObserver
*/
void				 vobsSignUpdate(INOUT		signFilter_T			*filter,
									IN	const	mapPathInfo_T			*mapPathInfo,
									IN	const	signInput_T				*input,
									IN	const	real32_T				 egoPostion,
									OUT			signState_T				*state
									);


#endif
