#ifndef guard_vobsPowertrainStatic_h
#define guard_vobsPowertrainStatic_h

#include "control/inputCodec/inputCodec_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"


/**\brief Aktualisiert Gang, Triebstrangzustand, eingelesenen Triebstrangzustand
Wenn das System aktiv regelt und einen Gang vorgibt, wird mit dem Wunschgang gerechnet, andernfalls mit dem Gang, der tats�chlich eingelegt ist.
\spec SwMS_Innodrive2_Input_289

Als Ausgangszustand f�r die Fahrstrategieplanung rechnet das System mit einem vereinfachten Triebstrangzustand outSimple, der den Wert simpleStateOff (Triebstrang ge�ffnet) 
annimmt, wenn der angenommene eingelegte Gang den Wert gearCoast (Segeln) annimmt. 
Andernfalls gilt vehicleState.powertrain.simple = simpleStateOn (Triebstrang ge�ffnet).
\spec SwMS_Innodrive2_Input_290 (outSimple)
\spec SwMS_Innodrive2_Input_291 (outRawSimple)

\ingroup vehicleObserver_internal
*/
static bool_T		 vobsGearUpdate(IN	const	uint8_T				 rawGear,		/**<Tats�chlich eingelegter Gang*/
									IN	const	uint8_T				 controlGear,	/**<Wunschgang des longControllers*/
									IN	const	bool_T				 gearRelevant,	/**<Ob der Wunschgang als relevanter Gang verwendet werden soll*/
									OUT			uint8_T				*outGear,		/**<Relevanter Gang*/
									OUT			simpleState_T		*outSimple,		/**<Triebstrangzustand laut relevantem Gang*/
									OUT			simpleState_T		*outRawSimple	/**<Eingelesener Triebstrangzustand*/
									);


/**\brief Berechnet die gesch�tzte maximale Beschleunigung, die mit dem E-Motor m�glich ist.
\spec SwMS_Innodrive2_Input_133
\ingroup vehicleObserver_internal
*/
static bool_T	vobsMaxAccelerationElectric(IN	const	vehicleModel_T		*vehicleModel,				/**<Fahrzeugmodel*/
											IN	const	powertrainInput_T	*powertrain,				/**<Eingelesene Triebstrangsignale*/
											IN	const	real32_T			 curvature,					/**<Kurvenkr�mmung*/
											IN	const	real32_T			 slope,						/**<Steigung*/
											IN	const	real32_T			 velocity,					/**<Geschwindigkeit*/
											IN	const	real32_T			 devEngaged,				/**<Zugkraftabweichung (geschlossener Triebstrang) */
											IN	const	real32_T			 devDisengaged,				/**<Zugkraftabweichung (offener Triebstang) */
											OUT			real32_T			*maxAccelerationElectric	/**<Maximale Beschleunigung, die mit dem E-Motor m�glich ist.*/
											);


/**\brief Ermittelt den Fahrmodus

hybridVehicle | cumbustionEngineActive | ePowerSelected     | driveMode
-----------------------------------------------------------------------------------------------------
false         | *                      | *                  | 0 drvMdCombustion (Init-Wert)
true          | true                   | false              | 0 drvMdCombustion (Init-Wert)
true          | true                   | true               | 0 drvMdCombustion (Init-Wert) (D�rfte nicht vorkommen)
true          | false                  | false              | 1 drvMdElectricAuto
true          | false                  | true               | 2 drvMdEpower

\spec SwMS_Innodrive2_Input_141
\ingroup vehicleObserver_internal
*/
static bool_T	   vobsSetDriveMode(IN	const	bool_T				 hybridVehicle,				/**< Wird vom Motor ein Hybridfahrzeug gemeldet? */
									IN	const	bool_T				 combustionEngineActive,	/**< Ob der Verbrennungsmotor l�uft*/
									IN	const	bool_T				 ePowerSelected,			/**< Ob ePower vom Fahrer ausgew�hlt ist*/
									OUT			driveMode_T			*driveMode					/**< Fahrmodus*/
									);



#endif
