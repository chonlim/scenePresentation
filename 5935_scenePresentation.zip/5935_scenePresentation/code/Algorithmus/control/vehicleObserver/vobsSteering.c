#include "vehicleObserver.h"
#include "vobsSteering.h"
#include "vobsFilter.h"

#include "common/vehicleModel/vehicleModel.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vobsSteering)


bool_T			 vobsSteeringUpdate(INOUT		steeringFilter_T	*filter,
									IN	const	vehicleModel_T		*vehicleModel,
									IN	const	real32_T			 deltaTime,
									IN	const	real32_T			 velocity,
									IN	const	real32_T			 wheelAngle,
									IN	const	real32_T			 wheelRate,
									IN	const	real32_T			 rearAngle,
									IN	const	bool_T				 rasPresent,
									OUT			steeringState_T		*state)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	curvature;
	real32_T	rate;
	real32_T	predAngle;
	real32_T	predDistance;
	real32_T	predCurvature;
	real32_T	slowAngle;
	real32_T	absSlow;
	real32_T	absAngle;
	real32_T	relSlowAngle;
	real32_T	slowCurvature;


	/* Aktuelle Bahnkr�mmung aus dem Lenkradwinkel berechnen */
	diagFF(vmdlGetSteeringCurvature( vehicleModel,
									 wheelAngle,
									 rearAngle,
									 velocity,
									 rasPresent,
									&curvature));


	/* Tiefpass-Filterung des nachlaufenden Lenkradwinkels und Berechnen der resultierenden
	   Bahnkr�mmung aus dem "Betragsminimum" von aktuellem und gefiltertem Lenkradwinkel */
	vobsLowPassFilter(&filter->slowAngle,
					   deltaTime,
					   paramSet->vehicleObserver.steering.slowAngleCutOff,
					   wheelAngle,
					  &slowAngle);

	absSlow		= fabsf(slowAngle);
	absAngle	= fabsf(wheelAngle);

	relSlowAngle = (absSlow < absAngle) ? slowAngle : wheelAngle;

	diagFF(vmdlGetSteeringCurvature( vehicleModel,
									 relSlowAngle,
									 rearAngle,
									 velocity,
									 rasPresent,
									&slowCurvature));


	/* Tiefpass-Filterung der Lenkradwinkel-Geschwindigkeit */
	vobsLowPassFilter(&filter->angleRate,
					   deltaTime,
					   paramSet->vehicleObserver.steering.angleRateCutOff,
					   wheelRate,
					  &rate);

	predAngle		= wheelAngle + rate * paramSet->vehicleObserver.steering.predTime;
	predDistance	= velocity * paramSet->vehicleObserver.steering.predTime;


	/* Voraussichtliche Bahnkr�mmung aus pr�diziertem Lenkradwinkel berechnen */
	diagFF(vmdlGetSteeringCurvature( vehicleModel,
									 predAngle,
									 rearAngle,
									 velocity,
									 rasPresent,
									&predCurvature));


	/* Der Betrag der voraussichtlichen Kr�mmung darf nicht gr��er werden als der Betrag der aktuellen Kr�mmung */
	if(fabsf(predCurvature) > fabsf(curvature)) { /*lint !e931 (fabsf hat keine Nebeneffekte)*/
		predCurvature = curvature;
	}
	else {
		predCurvature = predCurvature;
	}


	/* Ausgabe */
	state->curvature		= curvature;
	state->slowCurvature	= slowCurvature;
	state->predCurvature	= predCurvature;
	state->predDistance		= predDistance;


	return true;
}
