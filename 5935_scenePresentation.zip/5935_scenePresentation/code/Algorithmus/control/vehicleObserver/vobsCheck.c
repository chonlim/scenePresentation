#include "control/vehicleObserver/vehicleObserver.h"
#include "control/vehicleObserver/vobsCheck.h"
#include "control/vehicleObserver/vobsCheckStatic.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "common/vehicleModel/vmdlTools.h"

#include "common/platformInterface/pltfDiag.h"


bool_T				vobsCheckUpdate(INOUT		checkFilter_T			*filter,
									IN	const	vehicleModel_T			*vehicleModel,
									IN	const	uint8_T					 motorCode,
									IN	const	real32_T				 rawVelocity,
									IN	const	real32_T				 displayVelocity,
									IN	const	real32_T				 maxAutoSpeed,
									IN	const	bool_T					 longControlValid,
									OUT			checkState_T			*state)
{
	const parameterSetCtrl_T *params = prmGetParameterSetCtrl();
	bool_T motorCodeValid;

	/*code Check*/
	vmdlIsMotorCodeValid( vehicleModel,
						  motorCode, 
						 &motorCodeValid);

	vobsCheckUpdateFilter(&filter->codeCheck.initialized,
						  &filter->codeCheck.failed,
						  &filter->codeCheck.count, 
						   !motorCodeValid,
						   params->vehicleObserver.check.codeCheckTimeout,
						   diagInfo_vobsFailDTC_MotorCode_46005,
						   diagInfo_vobsPassDTC_MotorCode_46005,
						  &state->codeCheck.failed,
						  &state->codeCheck.setDTC);

	/*velocity Check*/
	vobsCheckUpdateFilter(&filter->velocityCheck.initialized,
						  &filter->velocityCheck.failed,
						  &filter->velocityCheck.count, 
						   (displayVelocity == INVALID_VALUE) != (rawVelocity == INVALID_VALUE), /*lint !e731 (Info -- Boolean argument to equal/not equal)*/
						   params->vehicleObserver.check.velocityCheckTimeout,
						   diagInfo_vobsFailDTC_ReplaceVelocity_46006,
						   diagInfo_vobsPassDTC_ReplaceVelocity_46006,
						  &state->velocityCheck.failed,
						  &state->velocityCheck.setDTC);

	/*control Check*/
	vobsCheckUpdateFilter(&filter->controlCheck.initialized,
						  &filter->controlCheck.failed,
						  &filter->controlCheck.count, 
						  !longControlValid,
						   params->vehicleObserver.check.controlCheckTimeout,
						   diagInfo_vobsFailDTC_LongControlInvalid_46003,
						   diagInfo_vobsPassDTC_LongControlInvalid_46003,
						  &state->controlCheck.failed,
						  &state->controlCheck.setDTC);

	/*freeRideSpeed Check*/
	vobsCheckUpdateFilter(&filter->freeRideCheck.initialized,
						  &filter->freeRideCheck.failed,
						  &filter->freeRideCheck.count,
						   (maxAutoSpeed == INVALID_VALUE),
						   params->vehicleObserver.check.controlCheckTimeout,
						   diagInfo_vobsFailDTC_AccFreeRideSpeed_46007,
						   diagInfo_vobsPassDTC_AccFreeRideSpeed_46007,
						  &state->freeRideCheck.failed,
						  &state->freeRideCheck.setDTC);
	
	return true;
}


static void	  vobsCheckUpdateFilter(INOUT		bool_T					*initialized,
									INOUT		bool_T					*filterFailed,
									INOUT		uint16_T				*filterCount,
									IN	const	bool_T					 checkFailed,
									IN	const	real32_T				 timeout,
									IN	const	diagInfo_T				 diagInfoFail,
									IN	const	diagInfo_T				 diagInfoPass,
									OUT			bool_T					*stateFailed,
									OUT			bool_T					*stateSetDTC)
{
	real32_T timeoutCount;
	bool_T setDTC, failed;

	failed = checkFailed;

	if (!(*initialized))
	{
		if (vobsAreEqual(failed, *filterFailed))
		{
			*filterCount += 1u;
		} else {
			*filterCount = 0u;
		}
		*filterFailed = failed;
	}
	else
	{
		if (vobsAreEqual(failed, *filterFailed))
		{
			*filterCount = 0u;
		} else {
			*filterCount += 1u;
		}
	}

	timeoutCount = timeout / controlCYCLETIME + 0.5f;	/*plus 1/2 f�r Rundung*/
	if (*filterCount == (uint16_T)timeoutCount)			/*cast rundet ab.*/
	{
		*initialized = true;
		*filterFailed = failed;
		*filterCount = 0u;
		setDTC = true;
	} else {
		*initialized = *initialized;
		*filterFailed = *filterFailed;
		*filterCount = *filterCount;
		setDTC = false;
	}

	if (timeout >= vobsCHECKTIMEOUTMAX) {
		failed = false;
		setDTC = false;
	} else {
		failed = failed;
		setDTC = setDTC;
	}

	if (setDTC) {
		diagReportInfo(failed ? diagInfoFail : diagInfoPass);
	}
	
	*stateFailed = failed;
	*stateSetDTC = setDTC;
}

static bool_T		   vobsAreEqual(IN	const	bool_T	first,
									IN	const	bool_T	second) 
{
	return ((first && second) || (!first && !second));
}
