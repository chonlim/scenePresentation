#ifndef guard_outputCodec_private_h
#define guard_outputCodec_private_h

#include "control/outputCodec/outputCodec_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */


typedef enum _oclPIF_Identifier {
	PIF_Identifier_Init = 0,
	PIF_Identifier_Geschwindigkeit = 1,
	PIF_Identifier_Laengsbeschleunigung = 2,
	PIF_Identifier_Leistung = 3,
	PIF_Identifier_Querbeschleunigung = 4,
	PIF_Identifier_Strassenklasse = 5,
	PIF_Identifier_INVALID = 8
} oclPIF_Identifier_T;

typedef enum _oclPIF_ST_Status {
	PIF_ST_Status_Init = 0,
	PIF_ST_Status_Invalid = 1,
	PIF_ST_Status_valid = 2
} oclPIF_ST_Status_T;



struct _predictionWindows {
	uint8_T shortTerm[dprdBIN_COUNT];
	uint8_T midTerm[dprdBIN_COUNT];
	uint8_T longTerm[dprdBIN_COUNT];
} ;                                      /**< Groesse der Struktur = 27 Bytes */

struct _oclPredictionFilter {
	bool_T dprdToggleBitPrev;
	bool_T DePIFTogglePrev;
	uint8_T muxIdentifierPrev;
	uint8_T cycleCount;
	uint8_T shortTermStatus;
	uint8_T midTermStatus;
	uint8_T longTermStatus;
	predictionWindows_T velocity;
	predictionWindows_T longAcceleration;
	predictionWindows_T wheelPower;
	predictionWindows_T latAcceleration;
	predictionWindows_T streetClass;
} ;                                      /**< Groesse der Struktur = 142 Bytes */

struct _oclInnoDriveMessage {
	uint8_T errVal;
	uint16_T cntVal;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _outputControlFilter {
	oclPredictionFilter_T driverPrediction;
	oclInnoDriveMessage_T innoDriveMessage;
	uint16_T dsplStateDebounceCntr;
} ;                                      /**< Groesse der Struktur = 148 Bytes */


/*lint -restore */

#endif
