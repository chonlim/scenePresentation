#ifndef guard_outputCodec_interface_h
#define guard_outputCodec_interface_h

#include "base.h"
#include "control/driverPredictor/driverPredictor_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef struct _predictionWindows predictionWindows_T;
typedef struct _oclPredictionFilter oclPredictionFilter_T;
typedef struct _oclInnoDriveMessage oclInnoDriveMessage_T;
typedef struct _outputControlFilter outputControlFilter_T;


typedef struct _flexrayOutput {
	bool_T dataValidFlag;                /**< 0=data corrupt, 1=data valid */
	real32_T DePACC02_Durchschnittsgeschw; /**< Nicht verwendet */
	real32_T DePACC02_neg_Sollbeschl_Grad; /**< Regelgröße Bremsruck[m/s^3] */
	real32_T DePACC02_pos_Sollbeschl_Grad; /**< Regelgröße Beschleunigungs[m/s^3] */
	real32_T DePACC02_Sollbeschleunigung; /**< Regelgröße Beschleunigung[m/s^2] */
	real32_T DePACC02_Sollgeschwindigkeit; /**< Anzeige Setzgeschwindigkeit am Tachokranz[km/h] */
	real32_T DePACC02_Vorausschaugeschw; /**< Anzeige Vorausschaugeschwindigkeit am Tachokranz[km/h] */
	real32_T DePACC02_Wunschuebersetzung; /**< Regelgröße Getriebe-Übersetzung (entspricht Gang)[1] */
	real32_T DePACC02_zul_Regelabw_oben; /**< Regelgröße Beschleunigungsabweichung positiv[m/s^2] */
	real32_T DePACC02_zul_Regelabw_unten; /**< Regelgröße Beschleunigungsabweichung negativ[m/s^2] */
	int16_T DePACC02_Offset;             /**< Regelgröße Geschwindigkeit[km/h] */
	uint8_T DePACC02_Ausrollmanoever;    /**< Regelug: bei negativer Beschleunigung Segeln oder Schubbetrieb[n/a] */
	uint8_T DePACC02_naechstes_Event;    /**< Anzeige Regelrelevantes Event[n/a] */
	uint8_T DePACC02_Systemstatus;       /**< Systemstatus zur Kommunikation mit ACC[n/a] */
	uint8_T DePACC02_Systemstatus_Anzeige; /**< Systemstatus zur Anzeige[n/a] */
	uint8_T DePACC02_InnoDrive_Texte;    /**< Anzeige von Warnmeldungen durch Innodrive[n/a] */
	bool_T DePACC02_Automode;            /**< Anzeige Automatische übernahme Tempolimits aktiv[n/a] */
	bool_T DePACC02_Uebernahmeaufforderung; /**< Anzeige Fahrer muss kontrolle übernehmen[n/a] */
	bool_T DePACC02_Offset_Aktiv;        /**< Anzeige Offset auf Tempolimits aktiv[n/a] */
	int8_T DePACC02_Offset_Anzeige;      /**< Temporäre Anzeige des eingestellten Offsets[km/h] */
	bool_T DePACC02_Geschw_Vorausschau;  /**< 0: Setzgeschwindigkeit_aktuell, 1: Setzgeschwindigkeit_Vorausschau[n/a] */
	bool_T DePACC02_Event_aktiv;         /**< 0: Vorausschauevent_inaktiv, 1: Vorausschauevent_aktiv[n/a] */
	bool_T DePACC02_Hinweis_Geschw;      /**< 0: kein Hinweis, 1: Hinweis[n/a] */
	uint8_T DePACC02_FoD_Status;         /**< 0: Init, 1: inaktiv, 2: aktiv[n/a] */
	bool_T DePIF_Toggle;                 /**< Signalisierung: PIF rechnet[n/a] */
	uint8_T DePIF_ST_Status;             /**< Status der Short-Term Botschaft (0 - 10 s Praediktionshorizont)[n/a] */
	uint8_T DePIF_MT_Status;             /**< Status der Mid-Term Botschaft (0 - 10 s Praediktionshorizont)[n/a] */
	uint8_T DePIF_LT_Status;             /**< Status der Long-Term Botschaft (0 - 10 s Praediktionshorizont)[n/a] */
	uint8_T DePIF_Identifier;            /**< Mux Identifier PIF Botschaft[n/a] */
	uint8_T DePIF_ST_Bin_0;              /**< Wahrscheinlichkeit für Bereich 0 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_1;              /**< Wahrscheinlichkeit für Bereich 1 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_2;              /**< Wahrscheinlichkeit für Bereich 2 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_3;              /**< Wahrscheinlichkeit für Bereich 3 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_4;              /**< Wahrscheinlichkeit für Bereich 4 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_5;              /**< Wahrscheinlichkeit für Bereich 5 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_6;              /**< Wahrscheinlichkeit für Bereich 6 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_7;              /**< Wahrscheinlichkeit für Bereich 7 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_ST_Bin_8;              /**< Wahrscheinlichkeit für Bereich 8 im Short-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_0;              /**< Wahrscheinlichkeit für Bereich 0 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_1;              /**< Wahrscheinlichkeit für Bereich 1 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_2;              /**< Wahrscheinlichkeit für Bereich 2 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_3;              /**< Wahrscheinlichkeit für Bereich 3 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_4;              /**< Wahrscheinlichkeit für Bereich 4 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_5;              /**< Wahrscheinlichkeit für Bereich 5 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_6;              /**< Wahrscheinlichkeit für Bereich 6 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_7;              /**< Wahrscheinlichkeit für Bereich 7 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_MT_Bin_8;              /**< Wahrscheinlichkeit für Bereich 8 im Mid-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_0;              /**< Wahrscheinlichkeit für Bereich 0 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_1;              /**< Wahrscheinlichkeit für Bereich 1 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_2;              /**< Wahrscheinlichkeit für Bereich 2 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_3;              /**< Wahrscheinlichkeit für Bereich 3 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_4;              /**< Wahrscheinlichkeit für Bereich 4 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_5;              /**< Wahrscheinlichkeit für Bereich 5 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_6;              /**< Wahrscheinlichkeit für Bereich 6 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_7;              /**< Wahrscheinlichkeit für Bereich 7 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
	uint8_T DePIF_LT_Bin_8;              /**< Wahrscheinlichkeit für Bereich 8 im Long-Term Horizont. Uebermittelte Groesse entsprechend PIF_Mux[n/a] */
} flexrayOutput_T;                       /**< Groesse der Struktur = 88 Bytes */


/*lint -restore */

#endif
