#ifndef guard_outputCodec_h
#define guard_outputCodec_h

#include "control/control.h"
#include "outputCodec_interface.h"

#include "control/driverPredictor/driverpredictor_interface.h"
#include "control/longController/longController_interface.h"
#include "control/displayController/displayController.h"
#include "control/controlReporter/controlReporter_interface.h"
#include "common/systemControllerCommon/systemController_interface.h"


/**\brief Einsprungfunktion des Moduls \ref outputCodec

\spec SW_AS_Innodrive2_54
\spec SW_AS_Innodrive2_55
\spec SwMS_Innodrive2_Output_73

\ingroup outputCodec
*/
void			outputCodec(IN	const	systemControl_T			*systemControl,
							IN	const	longControl_T			*longControl,
							IN	const	displayControl_T		*displayControl,
							IN	const	driverPrediction_T		*driverPrediction,
							IN	const	uint16_T				 controlCode,
							MEMORY		outputControlFilter_T	*outputControlFilter,
							OUT			flexrayOutput_T			*flexrayOutput
							);


#endif
