#include "outputCodec.h"
#include "outputCodec_private.h"
#include "control/outputCodec/outputCodecStatic.h"

#include "control/parameterSet/parameterSetCtrl.h"

#include "common/systemControllerCommon/sysTools.h"
#include "control/longController/lnclTools.h"
#include "control/driverPredictor/dprdDataInterface.h"
#include "control/displayController/dclTools.h"
#include "control/controlReporter/controlReporter.h"

#include <BusSignals_enums.h>

#define oclMAXPIFCYCLE_COUNT		20
#define oclDePACC02_Sollgeschwindigkeit_INIT (1023.0f * 0.32f)

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_outputCodec)


void						outputCodec(IN	const	systemControl_T			*systemControl,
										IN	const	longControl_T			*longControl,
										IN	const	displayControl_T		*displayControl,
										IN	const	driverPrediction_T		*driverPrediction,
										IN	const	uint16_T				 controlCode,
										MEMORY		outputControlFilter_T	*outputControlFilter,
										OUT			flexrayOutput_T			*flexrayOutput)
{
	/* Systemstatus und �bernahmeaufforderung */
	oclSetLongStatus( systemControl,
					  displayControl,
					  outputControlFilter,
					 &flexrayOutput->DePACC02_Systemstatus,
					 &flexrayOutput->DePACC02_Systemstatus_Anzeige,
					 &flexrayOutput->DePACC02_Automode,
					 &flexrayOutput->DePACC02_Uebernahmeaufforderung,
					 &flexrayOutput->DePACC02_Offset_Aktiv,
					 &flexrayOutput->DePACC02_Offset_Anzeige,
					 &flexrayOutput->DePACC02_FoD_Status);

	/* Sollgr��en f�r die L�ngsregelung */
	oclSetLongControl( longControl,
					   systemControl,
					  &flexrayOutput->DePACC02_Sollgeschwindigkeit,
					  &flexrayOutput->DePACC02_Sollbeschleunigung,
					  &flexrayOutput->DePACC02_neg_Sollbeschl_Grad,
					  &flexrayOutput->DePACC02_pos_Sollbeschl_Grad,
					  &flexrayOutput->DePACC02_zul_Regelabw_unten,
					  &flexrayOutput->DePACC02_zul_Regelabw_oben,
					  &flexrayOutput->DePACC02_Offset,
					  &flexrayOutput->DePACC02_Wunschuebersetzung,
					  &flexrayOutput->DePACC02_Ausrollmanoever);


	/* Display-Gr��en der L�ngsregelung */
	oclSetLongDisplay(	systemControl,
						displayControl,
						outputControlFilter,
					   &flexrayOutput->DePACC02_Vorausschaugeschw,
					   &flexrayOutput->DePACC02_naechstes_Event,
					   &flexrayOutput->DePACC02_InnoDrive_Texte,
					   &flexrayOutput->DePACC02_Geschw_Vorausschau,
					   &flexrayOutput->DePACC02_Event_aktiv,
					   &flexrayOutput->DePACC02_Hinweis_Geschw
					   );


	/* Porsche Intelligent Forecast */
	oclSetForecast(	driverPrediction,
					outputControlFilter,
				   &flexrayOutput->DePIF_Toggle,
				   &flexrayOutput->DePIF_ST_Status,
				   &flexrayOutput->DePIF_MT_Status,
				   &flexrayOutput->DePIF_LT_Status,
				   &flexrayOutput->DePIF_Identifier,
				   &flexrayOutput->DePIF_ST_Bin_0,
				   &flexrayOutput->DePIF_ST_Bin_1,
				   &flexrayOutput->DePIF_ST_Bin_2,
				   &flexrayOutput->DePIF_ST_Bin_3,
				   &flexrayOutput->DePIF_ST_Bin_4,
				   &flexrayOutput->DePIF_ST_Bin_5,
				   &flexrayOutput->DePIF_ST_Bin_6,
				   &flexrayOutput->DePIF_ST_Bin_7,
				   &flexrayOutput->DePIF_ST_Bin_8,
				   &flexrayOutput->DePIF_MT_Bin_0,
				   &flexrayOutput->DePIF_MT_Bin_1,
				   &flexrayOutput->DePIF_MT_Bin_2,
				   &flexrayOutput->DePIF_MT_Bin_3,
				   &flexrayOutput->DePIF_MT_Bin_4,
				   &flexrayOutput->DePIF_MT_Bin_5,
				   &flexrayOutput->DePIF_MT_Bin_6,
				   &flexrayOutput->DePIF_MT_Bin_7,
				   &flexrayOutput->DePIF_MT_Bin_8,
				   &flexrayOutput->DePIF_LT_Bin_0,
				   &flexrayOutput->DePIF_LT_Bin_1,
				   &flexrayOutput->DePIF_LT_Bin_2,
				   &flexrayOutput->DePIF_LT_Bin_3,
				   &flexrayOutput->DePIF_LT_Bin_4,
				   &flexrayOutput->DePIF_LT_Bin_5,
				   &flexrayOutput->DePIF_LT_Bin_6,
				   &flexrayOutput->DePIF_LT_Bin_7,
				   &flexrayOutput->DePIF_LT_Bin_8);  


	/* Debug-Ausgabe */
	oclSetDebugOutput( controlCode,
					  &flexrayOutput->DePACC02_Durchschnittsgeschw);


	/* Override */
	oclOverride(flexrayOutput);


	flexrayOutput->dataValidFlag = true;
}


static void			   oclSetLongStatus(IN	const	systemControl_T			*systemControl,
										IN	const	displayControl_T		*displayControl,
										MEMORY		outputControlFilter_T	*filter,
										OUT			uint8_T					*DePACC02_Systemstatus,
										OUT			uint8_T					*DePACC02_Systemstatus_Anzeige,
										OUT			bool_T					*DePACC02_Automode,
										OUT			bool_T					*DePACC02_Uebernahmeaufforderung,
										OUT			bool_T					*DePACC02_Offset_Aktiv,
										OUT			int8_T					*DePACC02_Offset_Anzeige,
										OUT			uint8_T					*DePACC02_FoD_Status)
{
	sysStatus_T	longControlStatus;
	sysFodStatus_T	fodStatus;
	sysDisplayError_T displayError;
	bool_T		takeoverRequest;
	bool_T		curveTakeover;
	bool_T		displayAuto;
	uint16_T	errorTicks;
	real32_T	dsplStateDebounceCntr_f;

	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	/*API-Zugriff auf Daten anderer Module*/
	sysGetLongControlStatus(systemControl,	&longControlStatus);
	sysGetDisplayError(systemControl, &displayError);
	sysGetTakeoverRequest(systemControl, &takeoverRequest);
	sysGetDisplayAuto(systemControl, &displayAuto);
	sysGetErrorTicks(systemControl, &errorTicks);
	sysGetFodStatus(systemControl, &fodStatus);
	dclGetCurveTakeover(displayControl, &curveTakeover);

	/*Systemstatus*/
	switch (longControlStatus) {
		case sysStatusDisabled:			/*\spec SW_AS_Innodrive2_115*/
			*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx0_OFF;
			*DePACC02_Systemstatus_Anzeige		= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx0_OFF;
			*DePACC02_Uebernahmeaufforderung	= takeoverRequest;
			*DePACC02_Automode					= displayAuto;
			filter->dsplStateDebounceCntr		= 0u;
			break;

		case sysStatusNotAvailable:		/*\spec SW_AS_Innodrive2_119*/
			if (displayError == sysErrorAccIrreversible) {
				*DePACC02_Systemstatus_Anzeige	= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx7_FEHLER_Irreversibel;
				*DePACC02_Systemstatus			= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx7_FEHLER_Irreversibel;
			} else if (displayError == sysErrorAccReversible) {
				*DePACC02_Systemstatus_Anzeige	= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx6_FEHLER_System;
				*DePACC02_Systemstatus			= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx6_FEHLER_System;
			} else {
				*DePACC02_Systemstatus_Anzeige	= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx5_FEHLER_Karte;
				*DePACC02_Systemstatus			= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx5_FEHLER_Karte;
			}
			*DePACC02_Uebernahmeaufforderung	= takeoverRequest;
			*DePACC02_Automode					= displayAuto;
			filter->dsplStateDebounceCntr		= 0u;
			break;

		case sysStatusAvailable:		/*\spec SW_AS_Innodrive2_116*/
			*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx2_STANDBY;
			*DePACC02_Systemstatus_Anzeige		= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx2_STANDBY;
			*DePACC02_Uebernahmeaufforderung	= takeoverRequest;
			*DePACC02_Automode					= displayAuto;
			dsplStateDebounceCntr_f				= paramSet->outputCodec.dsplStateDebounceTime / controlCYCLETIME;
			filter->dsplStateDebounceCntr		= (uint16_T)dsplStateDebounceCntr_f;
			break;

		case sysStatusActive:			/*\spec SW_AS_Innodrive2_117*/
			if (filter->dsplStateDebounceCntr > 0u)
			{
				filter->dsplStateDebounceCntr--;
			}
			*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt;
			*DePACC02_Systemstatus_Anzeige		= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt;
			*DePACC02_Uebernahmeaufforderung	= takeoverRequest || curveTakeover;
			*DePACC02_Automode					= displayAuto;
			break;

		case sysStatusBrakeOnlyMode:	/*\spec SW_AS_Innodrive2_117 / 121*/
			*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt;
			*DePACC02_Systemstatus_Anzeige		= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx5_FEHLER_Karte;
			*DePACC02_Uebernahmeaufforderung	= true;
			*DePACC02_Automode					= displayAuto;
			filter->dsplStateDebounceCntr		= 0u;
			break;

		case sysStatusOverride:			/*\spec SW_AS_Innodrive2_118*/
			if (filter->dsplStateDebounceCntr > 0u)
			{
				*DePACC02_Systemstatus_Anzeige = DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt;
				filter->dsplStateDebounceCntr--;
			}
			else
			{
				*DePACC02_Systemstatus_Anzeige = DeFRInnoDriveOut_DePACC02_Systemstatus_Cx4_PASSIV;
			}

			*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx4_PASSIV;
			*DePACC02_Uebernahmeaufforderung	= takeoverRequest;
			*DePACC02_Automode					= displayAuto;
			break;

		default:
			*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx6_FEHLER_System;
			*DePACC02_Systemstatus_Anzeige		= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx6_FEHLER_System;
			*DePACC02_Uebernahmeaufforderung	= false;
			*DePACC02_Automode					= false;
			filter->dsplStateDebounceCntr		= 0u;
			break;
	}

	if (errorTicks > 0u)
	{
		*DePACC02_Systemstatus_Anzeige		= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx6_FEHLER_System;
		*DePACC02_Systemstatus				= DeFRInnoDriveOut_DePACC02_Systemstatus_Cx6_FEHLER_System;
		*DePACC02_Uebernahmeaufforderung	= false;
		*DePACC02_Automode					= false;
		filter->dsplStateDebounceCntr		= 0u;
	}

	/**Angezeigter Offset und Offsetaktiv auf Null setzen*/
	*DePACC02_Offset_Anzeige = 0;
	*DePACC02_Offset_Aktiv = false;

	switch (fodStatus) {
		case sysFodStatusInit		: *DePACC02_FoD_Status = DeFRInnoDriveOut_DePACC02_FoD_Status_Cx0_Init;				break;
		case sysFodStatusNotActive	: *DePACC02_FoD_Status = DeFRInnoDriveOut_DePACC02_FoD_Status_Cx1_PACC_FoD_inaktiv;	break;
		case sysFodStatusActive		: *DePACC02_FoD_Status = DeFRInnoDriveOut_DePACC02_FoD_Status_Cx2_PACC_FoD_aktiv;	break;
		default						: *DePACC02_FoD_Status = DeFRInnoDriveOut_DePACC02_FoD_Status_Cx0_Init;				break;
	}

}


static void			  oclSetLongControl(IN	const	longControl_T			*longControl,
										IN	const	systemControl_T			*systemControl,
										OUT			real32_T				*DePACC02_Sollgeschwindigkeit,
										OUT			real32_T				*DePACC02_Sollbeschleunigung,
										OUT			real32_T				*DePACC02_neg_Sollbeschl_Grad,
										OUT			real32_T				*DePACC02_pos_Sollbeschl_Grad,
										OUT			real32_T				*DePACC02_zul_Regelabw_unten,
										OUT			real32_T				*DePACC02_zul_Regelabw_oben,
										OUT			int16_T					*DePACC02_Offset,
										OUT			real32_T				*DePACC02_Wunschuebersetzung,
										OUT			uint8_T					*DePACC02_Ausrollmanoever)
{
	real32_T	targetVelocity;
	real32_T	targetVelocityKPH;
	real32_T	targetAcceleration;
	real32_T	toleranceUpper;
	real32_T	toleranceLower;
	real32_T	jerkPositive;
	real32_T	jerkNegative;

	bool_T		coastValid;
	bool_T		coastRequest;
	bool_T		transmissionValid;
	real32_T	transmissionRatio;

	real32_T	setSpeedPosition;
	real32_T	setSpeedVelocity;

	bool_T		setDisplayValid;


	/* Zielbeschleunigung und Vorausschaugeschwindigkeit abfragen */
	lnclGetLongTarget( longControl,
					  &targetVelocity,
					  &targetAcceleration,
					  &toleranceUpper,
					  &toleranceLower,
					  &jerkPositive,
					  &jerkNegative);


	/* Ziel-Triebstrangzustand abfragen */
	lnclGetPtrainTarget( longControl,
						&coastValid,
						&coastRequest,
						&transmissionValid,
						&transmissionRatio);


	/* Abfragen der Setzgeschwindigkeit */
	sysGetCurrentSetSpeed( systemControl,
						  &setSpeedPosition,
						  &setSpeedVelocity);


	/* Abfragen,  ob die Setzgeschwindigkeit als g�ltig angezeigt werden soll */
	sysIsSetDisplayValid( systemControl,
						 &setDisplayValid);


	/* Beschleunigung */
	*DePACC02_Sollbeschleunigung	= targetAcceleration;


	/* Sollgeschwindigkeit - die Signale Sollgeschwindigkeit und Setzgeschwindigkeit werden im ACC vertauscht ausgewertet */
	*DePACC02_Sollgeschwindigkeit	= ((setSpeedVelocity > 0.0f) && setDisplayValid) ? (3.6f * setSpeedVelocity) : oclDePACC02_Sollgeschwindigkeit_INIT;


	/* Ruckbegrenzung und zul�ssige Regelabweichung */
	*DePACC02_neg_Sollbeschl_Grad	= -jerkNegative;
	*DePACC02_pos_Sollbeschl_Grad	=  jerkPositive;
	*DePACC02_zul_Regelabw_unten	=  toleranceLower;
	*DePACC02_zul_Regelabw_oben		=  toleranceUpper;


	/* Setzgeschwindigkeit - die Signale Sollgeschwindigkeit und Setzgeschwindigkeit werden im ACC vertauscht ausgewertet */
	targetVelocityKPH				= MPS_TO_KPH * targetVelocity;
	*DePACC02_Offset				= (targetVelocity > 0.0f) ? (int16_T)targetVelocityKPH : DeFRInnoDriveOut_DePACC02_Offset_DEFAULT;


	/* �bersetzungsverh�ltnis und Segelanforderung */
	*DePACC02_Wunschuebersetzung	= (transmissionValid) ? transmissionRatio : DeFRInnoDriveOut_DePACC02_Wunschuebersetzung_Cx000_Init;

	if(coastValid) {
		*DePACC02_Ausrollmanoever	= (coastRequest) ? DeFRInnoDriveOut_DePACC02_Ausrollmanoever_Cx1_Segelbetrieb_gewuenscht : DeFRInnoDriveOut_DePACC02_Ausrollmanoever_Cx2_Schubbetrieb_gewuenscht;
	}
	else {
		*DePACC02_Ausrollmanoever	= DeFRInnoDriveOut_DePACC02_Ausrollmanoever_Cx0_keine_Anforderung;
	}
}


static void			  oclSetLongDisplay(IN	const	systemControl_T			*systemControl,
										IN	const	displayControl_T		*displayControl,
										INOUT		outputControlFilter_T	*filter,
										OUT			real32_T				*DePACC02_Vorausschaugeschw,
										OUT			uint8_T					*DePACC02_naechstes_Event,
										OUT			uint8_T					*DePACC02_InnoDrive_Texte,
										OUT			bool_T					*DePACC02_Geschw_Vorausschau,
										OUT			bool_T					*DePACC02_Event_aktiv,
										OUT			bool_T					*DePACC02_Hinweis_Geschw)
{
	bool_T				previewValid;
	bool_T				displayLimitEventsActive;
	bool_T				displayNextSetSpeed;
	bool_T				unsuccesfulActivation;
	real32_T			previewVelocity;
	displayEvent_T		displayEvent;
	sysDisplayError_T	displayError;
	bool_T			autoMode;
	bool_T			showHint;
	real32_T		previewPosition;
	sysStatus_T		status;
	
	sysGetDisplayLimitEventsActive(systemControl, &displayLimitEventsActive);
	sysGetLongControlStatus(systemControl, &status);
	sysGetAutoModeInfo(systemControl, &autoMode, &previewPosition);
	sysGetShowHint(systemControl, &showHint);

	sysGetDisplayError(systemControl, &displayError);

	sysGetUnsuccessfulActivation(systemControl, &unsuccesfulActivation);


	/* Vorausschau-Geschwindigkeit abfragen */
	dclGetPreviewVelocity( displayControl,
						  &previewVelocity,
						  &previewValid,
						  &displayNextSetSpeed);

	/* Vorausschau-Event abfragen */
	dclGetDisplayEvent( displayControl,
					   &displayEvent);

	/* Vorausschaugeschwindigkeit. Wenn wir im Stillstand 0 schicken, kann das ACC nicht mehr �ber Resume anfahren. 
	   Bei einer Vorausschaugeschwindigkeit 0 wird daher Init geschickt. */
	*DePACC02_Geschw_Vorausschau	= displayNextSetSpeed;
	*DePACC02_Vorausschaugeschw		= (previewValid && previewVelocity > 0.0f)	?			(3.6f * previewVelocity)	: DeFRInnoDriveOut_DePACC02_Vorausschaugeschw_DEFAULT;

	/* Vorausschau-Event */
	if(		eventNone				== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx00_Init; }
	else if(eventSpeedLimit_5		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx01_Tempolimit_5kmh; }
	else if(eventSpeedLimit_10		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx02_Tempolimit_10kmh; }
	else if(eventSpeedLimit_15		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx03_Tempolimit_15kmh; }
	else if(eventSpeedLimit_20		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx04_Tempolimit_20kmh; }
	else if(eventSpeedLimit_25		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx05_Tempolimit_25kmh; }
	else if(eventSpeedLimit_30		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx06_Tempolimit_30kmh; }
	else if(eventSpeedLimit_35		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx07_Tempolimit_35kmh; }
	else if(eventSpeedLimit_40		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx08_Tempolimit_40kmh; }
	else if(eventSpeedLimit_45		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx09_Tempolimit_45kmh; }
	else if(eventSpeedLimit_50		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx0A_Tempolimit_50kmh; }
	else if(eventSpeedLimit_55		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx0B_Tempolimit_55kmh; }
	else if(eventSpeedLimit_60		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx0C_Tempolimit_60kmh; }
	else if(eventSpeedLimit_65		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx0D_Tempolimit_65kmh; }
	else if(eventSpeedLimit_70		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx0E_Tempolimit_70kmh; }
	else if(eventSpeedLimit_75		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx0F_Tempolimit_75kmh; }
	else if(eventSpeedLimit_80		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx10_Tempolimit_80kmh; }
	else if(eventSpeedLimit_90		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx11_Tempolimit_90kmh; }
	else if(eventSpeedLimit_100		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx12_Tempolimit_100kmh; }
	else if(eventSpeedLimit_110		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx13_Tempolimit_110kmh; }
	else if(eventSpeedLimit_120		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx14_Tempolimit_120kmh; }
	else if(eventSpeedLimit_130		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx15_Tempolimit_130kmh; }
	else if(eventSpeedLimit_140		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx16_Tempolimit_140kmh; }
	else if(eventSpeedLimit_150		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx17_Tempolimit_150kmh; }
	else if(eventSpeedLimit_160		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx18_Tempolimit_160kmh; }
	else if(eventSpeedLimitReleased	== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx19_Tempolimit_unbegrenzt; }
	else if(eventCurveLeft			== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx1A_Linkskurve; }
	else if(eventCurveRight			== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx1B_Rechtskurve; }
	else if(eventBranchLeft			== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx24_Abzweigung_links; }
	else if(eventBranchRight		== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx25_Abzweigung_rechts; }
	else if(eventRampLeft			== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx26_Abfahrt_links; }
	else if(eventRampRight			== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx27_Abfahrt_rechts; }
	else if(eventRoundabout			== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx23_Kreisverkehr; }
	else if(eventStop				== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx28_Stoppstelle; }
	else if(eventYield				== displayEvent) { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx29_Vorfahrt_beachten; }
	else											 { *DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx00_Init; }

	switch (displayEvent)
	{
	case eventSpeedLimit_5:		
	case eventSpeedLimit_10:		
	case eventSpeedLimit_15:		
	case eventSpeedLimit_20:		
	case eventSpeedLimit_25:		
	case eventSpeedLimit_30:		
	case eventSpeedLimit_35:		
	case eventSpeedLimit_40:		
	case eventSpeedLimit_45:		
	case eventSpeedLimit_50:		
	case eventSpeedLimit_55:		
	case eventSpeedLimit_60:		
	case eventSpeedLimit_65:		
	case eventSpeedLimit_70:		
	case eventSpeedLimit_75:		
	case eventSpeedLimit_80:		
	case eventSpeedLimit_90:		
	case eventSpeedLimit_100:		
	case eventSpeedLimit_110:		
	case eventSpeedLimit_120:		
	case eventSpeedLimit_130:		
	case eventSpeedLimit_140:		
	case eventSpeedLimit_150:		
	case eventSpeedLimit_160:		
	case eventSpeedLimitReleased:
		*DePACC02_Event_aktiv = displayLimitEventsActive ? true : false;
		break;	
	case eventNone:
	case eventCurveLeft:
	case eventCurveRight:	
	case eventBranchLeft:
	case eventBranchRight:
	case eventRampLeft:
	case eventRampRight:
	case eventRoundabout:
	case eventStop:	
	case eventYield:
	default:				  
		*DePACC02_Event_aktiv = true;
		break;
	}

	switch (status)
	{
	case sysStatusDisabled:
	case sysStatusNotAvailable:
	case sysStatusBrakeOnlyMode:
		*DePACC02_naechstes_Event = DeFRInnoDriveOut_DePACC02_naechstes_Event_Cx00_Init;
		*DePACC02_Event_aktiv = false;
		break;
	case sysStatusAvailable:
		/*Event senden, aber ausgrauen*/
		*DePACC02_Event_aktiv = false;
		break;
	case sysStatusActive:
	case sysStatusOverride:
	default:
		/*Beide Signale senden.*/
		break;
	}

	if (unsuccesfulActivation)
	{
		if (filter->innoDriveMessage.cntVal == 0u)
		{ /* only set new error value while no message is shown (otherwise message could change during display duration) */
			switch (displayError)
			{
			case sysErrorStreetClass:
				filter->innoDriveMessage.errVal = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx1_Strasse_nicht_moeglich;
				break;
			case sysErrorMapData:
				filter->innoDriveMessage.errVal = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx2_Strasse_nicht_erfasst;
				break;
			case sysErrorSpeedLimit:
				filter->innoDriveMessage.errVal = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx3_zul_Geschw_zu_gering;
				break;
			case sysErrorCountryCode:
				filter->innoDriveMessage.errVal = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx4_Land_nicht_moeglich;
				break;
			case sysErrorStrategy:
			case sysErrorRoadInfo:
				filter->innoDriveMessage.errVal = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx6_temporaer_nicht_moeglich;
				break;
			case sysErrorNone:
			case sysErrorAccInBom:
			case sysErrorAccReversible:
			case sysErrorAccIrreversible:
			default:
				filter->innoDriveMessage.errVal = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx0_Init;
				break;
			}
		}		

		if (filter->innoDriveMessage.errVal != DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx0_Init){
			/* (re)set value of counter for each unsuccesful activation that causes a display message */
			filter->innoDriveMessage.cntVal = (uint16_T)((2.0f / controlCYCLETIME));
		}
	}

	if (filter->innoDriveMessage.cntVal > 0u)
	{
		*DePACC02_InnoDrive_Texte = filter->innoDriveMessage.errVal;
		filter->innoDriveMessage.cntVal--;
	}
	else
	{
		*DePACC02_InnoDrive_Texte = DeFRInnoDriveOut_DePACC02_InnoDrive_Texte_Cx0_Init;
	}

	if ((status == sysStatusActive) && autoMode)
	{
		*DePACC02_Hinweis_Geschw = false;
		if (showHint)
		{
			*DePACC02_Hinweis_Geschw = true;
		}
	}
	else /* System not active or not in autoMode */
	{
		*DePACC02_Hinweis_Geschw = true;
	}
}


static bool_T oclGetPIFMuxIDDprdData(	IN const	driverPrediction_T		*driverPrediction,
										INOUT		outputControlFilter_T	*filter,
										OUT			uint8_T					*muxID)
{
	const oclPIF_ST_Status_T statusInit		= PIF_ST_Status_Init;
	const oclPIF_ST_Status_T statusInvalid	= PIF_ST_Status_Invalid;
	const oclPIF_ST_Status_T statusValid	= PIF_ST_Status_valid;

	bool_T validWindow = false;
	uint8_T muxIdentifier;
	predictionWindows_T tmpWindow;

	uint8_T PIFIdentifierBits[oclMAXPIFCYCLE_COUNT] = { (uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Geschwindigkeit,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Geschwindigkeit,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Geschwindigkeit,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Geschwindigkeit,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Laengsbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Laengsbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Laengsbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Laengsbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Leistung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Leistung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Leistung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Leistung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Querbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Querbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Querbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Querbeschleunigung,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Strassenklasse,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Strassenklasse,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Strassenklasse,
														(uint8_T)(oclPIF_Identifier_T)PIF_Identifier_Strassenklasse };

	const bool_T validPrediction = dprdIsValidPrediction(driverPrediction);

	if (filter->driverPrediction.cycleCount < (uint8_T)oclMAXPIFCYCLE_COUNT)
	{
		muxIdentifier = (uint8_T)PIFIdentifierBits[filter->driverPrediction.cycleCount];
	}
	else
	{
		muxIdentifier = (uint8_T)PIF_Identifier_INVALID;
	}


	if (filter->driverPrediction.cycleCount == 0u)
	{
		memset(&filter->driverPrediction.latAcceleration, 0, sizeof(predictionWindows_T));
		memset(&filter->driverPrediction.longAcceleration, 0, sizeof(predictionWindows_T));
		memset(&filter->driverPrediction.velocity, 0, sizeof(predictionWindows_T));
		memset(&filter->driverPrediction.wheelPower, 0, sizeof(predictionWindows_T));
		memset(&filter->driverPrediction.streetClass, 0, sizeof(predictionWindows_T));
	}
	else
	{/*konstante Laufzeit realisieren*/
		memset(&tmpWindow, 0, sizeof(predictionWindows_T));
		memset(&tmpWindow, 0, sizeof(predictionWindows_T));
		memset(&tmpWindow, 0, sizeof(predictionWindows_T));
		memset(&tmpWindow, 0, sizeof(predictionWindows_T));
		memset(&tmpWindow, 0, sizeof(predictionWindows_T));
	}

	/*Daten des driverPredictors abfragen*/
	diagFF(dprdGetLatAcceleration(driverPrediction, shortTermWindow,	tmpWindow.shortTerm));
	diagFF(dprdGetLatAcceleration(driverPrediction, midTermWindow,		tmpWindow.midTerm));
	diagFF(dprdGetLatAcceleration(driverPrediction, longTermWindow,		tmpWindow.longTerm));
	filter->driverPrediction.latAcceleration = filter->driverPrediction.cycleCount == 0u ? tmpWindow : filter->driverPrediction.latAcceleration;

	diagFF(dprdGetLongAcceleration(driverPrediction, shortTermWindow,	tmpWindow.shortTerm));
	diagFF(dprdGetLongAcceleration(driverPrediction, midTermWindow,		tmpWindow.midTerm));
	diagFF(dprdGetLongAcceleration(driverPrediction, longTermWindow,	tmpWindow.longTerm));
	filter->driverPrediction.longAcceleration = filter->driverPrediction.cycleCount == 0u ? tmpWindow : filter->driverPrediction.longAcceleration;

	diagFF(dprdGetVelocity(driverPrediction, shortTermWindow,	tmpWindow.shortTerm));
	diagFF(dprdGetVelocity(driverPrediction, midTermWindow,		tmpWindow.midTerm));
	diagFF(dprdGetVelocity(driverPrediction, longTermWindow,	tmpWindow.longTerm));
	filter->driverPrediction.velocity = filter->driverPrediction.cycleCount == 0u ? tmpWindow : filter->driverPrediction.velocity;

	diagFF(dprdGetWheelPower(driverPrediction, shortTermWindow,	tmpWindow.shortTerm));
	diagFF(dprdGetWheelPower(driverPrediction, midTermWindow,	tmpWindow.midTerm));
	diagFF(dprdGetWheelPower(driverPrediction, longTermWindow,	tmpWindow.longTerm));
	filter->driverPrediction.wheelPower = filter->driverPrediction.cycleCount == 0u ? tmpWindow : filter->driverPrediction.wheelPower;

	diagFF(dprdGetStreetClass(driverPrediction, shortTermWindow, tmpWindow.shortTerm));
	diagFF(dprdGetStreetClass(driverPrediction, midTermWindow,	tmpWindow.midTerm));
	diagFF(dprdGetStreetClass(driverPrediction, longTermWindow,	tmpWindow.longTerm));
	filter->driverPrediction.streetClass = filter->driverPrediction.cycleCount == 0u ? tmpWindow : filter->driverPrediction.streetClass;

	/*behandeln der Zust�nde des outputCodecs zum aufbereiten der driverPredictor Daten*/
	if (filter->driverPrediction.cycleCount == 0u)
	{
		if (validPrediction)
		{
			diagFF(dprdIsWindowValid(driverPrediction, shortTermWindow, &validWindow));
			filter->driverPrediction.shortTermStatus = validWindow ? (uint8_T)statusValid : (uint8_T)statusInvalid;

			diagFF(dprdIsWindowValid(driverPrediction, midTermWindow, &validWindow));
			filter->driverPrediction.midTermStatus = validWindow ? (uint8_T)statusValid : (uint8_T)statusInvalid;
			
			diagFF(dprdIsWindowValid(driverPrediction, longTermWindow, &validWindow));
			filter->driverPrediction.longTermStatus = validWindow ? (uint8_T)statusValid : (uint8_T)statusInvalid;

			filter->driverPrediction.cycleCount++;

		/*konstante Laufzeit realisieren*/
			muxIdentifier = muxIdentifier;
		/*konstante Laufzeit realisieren*/
		}
		else
		{ /*der driverPredictor hat noch keine g�ltigen Daten, weshalb der muxIdentifier auf PIF_Init gesetzt werden muss*/
			muxIdentifier = 0u;

		/*konstante Laufzeit realisieren*/
			diagFF(dprdIsWindowValid(driverPrediction, shortTermWindow, &validWindow));
			filter->driverPrediction.shortTermStatus = validWindow ? (uint8_T)statusInit : (uint8_T)statusInit;

			diagFF(dprdIsWindowValid(driverPrediction, midTermWindow, &validWindow));
			filter->driverPrediction.midTermStatus = validWindow ? (uint8_T)statusInit : (uint8_T)statusInit;

			diagFF(dprdIsWindowValid(driverPrediction, longTermWindow, &validWindow));
			filter->driverPrediction.longTermStatus = validWindow ? (uint8_T)statusInit : (uint8_T)statusInit;
			
			filter->driverPrediction.cycleCount = filter->driverPrediction.cycleCount;
		/*konstante Laufzeit realisieren*/
		}
	}
	else
	{
	/*konstante Laufzeit realisieren*/
		diagFF(dprdIsWindowValid(driverPrediction, shortTermWindow, &validWindow));
		filter->driverPrediction.shortTermStatus = validWindow ? filter->driverPrediction.shortTermStatus : filter->driverPrediction.shortTermStatus;

		diagFF(dprdIsWindowValid(driverPrediction, midTermWindow, &validWindow));
		filter->driverPrediction.midTermStatus = validWindow ? filter->driverPrediction.midTermStatus : filter->driverPrediction.midTermStatus;

		diagFF(dprdIsWindowValid(driverPrediction, longTermWindow, &validWindow));
		filter->driverPrediction.longTermStatus = validWindow ? filter->driverPrediction.longTermStatus : filter->driverPrediction.longTermStatus;
	/*konstante Laufzeit realisieren*/

		filter->driverPrediction.cycleCount++;
		if (filter->driverPrediction.cycleCount >= (uint8_T)oclMAXPIFCYCLE_COUNT)
		{ 
			filter->driverPrediction.cycleCount = 0u;
		}
	}

	*muxID = muxIdentifier;
	return true;
}


static void				 oclSetForecast(IN const	driverPrediction_T		*driverPrediction,
							INOUT		outputControlFilter_T	*filter,
							OUT			bool_T					*DePIF_Toggle,
							OUT			uint8_T					*DePIF_ST_Status,
							OUT			uint8_T					*DePIF_MT_Status,
							OUT			uint8_T					*DePIF_LT_Status,
							OUT			uint8_T					*DePIF_Identifier,
							OUT			uint8_T					*DePIF_ST_Bin_0,
							OUT			uint8_T					*DePIF_ST_Bin_1,
							OUT			uint8_T					*DePIF_ST_Bin_2,
							OUT			uint8_T					*DePIF_ST_Bin_3,
							OUT			uint8_T					*DePIF_ST_Bin_4,
							OUT			uint8_T					*DePIF_ST_Bin_5,
							OUT			uint8_T					*DePIF_ST_Bin_6,
							OUT			uint8_T					*DePIF_ST_Bin_7,
							OUT			uint8_T					*DePIF_ST_Bin_8,
							OUT			uint8_T					*DePIF_MT_Bin_0,
							OUT			uint8_T					*DePIF_MT_Bin_1,
							OUT			uint8_T					*DePIF_MT_Bin_2,
							OUT			uint8_T					*DePIF_MT_Bin_3,
							OUT			uint8_T					*DePIF_MT_Bin_4,
							OUT			uint8_T					*DePIF_MT_Bin_5,
							OUT			uint8_T					*DePIF_MT_Bin_6,
							OUT			uint8_T					*DePIF_MT_Bin_7,
							OUT			uint8_T					*DePIF_MT_Bin_8,
							OUT			uint8_T					*DePIF_LT_Bin_0,
							OUT			uint8_T					*DePIF_LT_Bin_1,
							OUT			uint8_T					*DePIF_LT_Bin_2,
							OUT			uint8_T					*DePIF_LT_Bin_3,
							OUT			uint8_T					*DePIF_LT_Bin_4,
							OUT			uint8_T					*DePIF_LT_Bin_5,
							OUT			uint8_T					*DePIF_LT_Bin_6,
							OUT			uint8_T					*DePIF_LT_Bin_7,
							OUT			uint8_T					*DePIF_LT_Bin_8)
{
	/*lint -esym(954, predictionWindows) (Note -- Pointer variable 'predictionWindows' (line 477) could be declared as pointing to const [MISRA 2012 Rule 8.13, advisory])*/
	uint8_T muxIdentifier;
	predictionWindows_T *predictionWindows = NULL;
	bool_T valid = true;
	bool_T dprdToggleBit;

	if (!oclGetPIFMuxIDDprdData(driverPrediction, filter, &muxIdentifier))
	{
		muxIdentifier = (uint8_T)PIF_Identifier_Init;
	}

	*DePIF_Identifier = muxIdentifier;

	switch (muxIdentifier)
	{
	case (uint8_T)PIF_Identifier_Init:					predictionWindows = NULL;											break;
	case (uint8_T)PIF_Identifier_Geschwindigkeit:		predictionWindows = &filter->driverPrediction.velocity;				break;
	case (uint8_T)PIF_Identifier_Laengsbeschleunigung:	predictionWindows = &filter->driverPrediction.longAcceleration;		break;
	case (uint8_T)PIF_Identifier_Leistung:				predictionWindows = &filter->driverPrediction.wheelPower;			break;
	case (uint8_T)PIF_Identifier_Querbeschleunigung:	predictionWindows = &filter->driverPrediction.latAcceleration;		break;
	case (uint8_T)PIF_Identifier_Strassenklasse:		predictionWindows = &filter->driverPrediction.streetClass;			break;
	/*
	case PIF_Identifier_reserviert_6:			reserviert break;
	case PIF_Identifier_reserviert_7:			reserviert break;
	*/
	default:	*DePIF_ST_Status = (uint8_T)PIF_ST_Status_Invalid;
				*DePIF_MT_Status = (uint8_T)PIF_ST_Status_Invalid;
				*DePIF_LT_Status = (uint8_T)PIF_ST_Status_Invalid;
				valid = false;
				break;
	}

	if (!valid)
	{
		return;
	}


	dprdGetToggleBitState(driverPrediction, &dprdToggleBit);

	if (   (muxIdentifier != filter->driverPrediction.muxIdentifierPrev) 
		&& (    /* Fix Lint-error 697: Quasi-boolean values should be equality-compared only with 0 */
				(dprdToggleBit && !filter->driverPrediction.dprdToggleBitPrev)
		     || (!dprdToggleBit && filter->driverPrediction.dprdToggleBitPrev)
			)
		){
		/* Bei neuer Mux-ID und dprd noch aktiv, �ndere Output-ToggleBit*/
		filter->driverPrediction.DePIFTogglePrev = !(filter->driverPrediction.DePIFTogglePrev);
	}
	else
	{ /* konstante Laufzeit realisieren */
		filter->driverPrediction.DePIFTogglePrev = filter->driverPrediction.DePIFTogglePrev;
	}

	filter->driverPrediction.muxIdentifierPrev = muxIdentifier;
	filter->driverPrediction.dprdToggleBitPrev = dprdToggleBit;

	*DePIF_Toggle = filter->driverPrediction.DePIFTogglePrev;

	*DePIF_ST_Status = filter->driverPrediction.shortTermStatus;
	*DePIF_MT_Status = filter->driverPrediction.midTermStatus;
	*DePIF_LT_Status = filter->driverPrediction.longTermStatus;
	if (NULL != predictionWindows)
	{
		*DePIF_ST_Bin_0 = predictionWindows->shortTerm[0];
		*DePIF_ST_Bin_1 = predictionWindows->shortTerm[1];
		*DePIF_ST_Bin_2 = predictionWindows->shortTerm[2];
		*DePIF_ST_Bin_3 = predictionWindows->shortTerm[3];
		*DePIF_ST_Bin_4 = predictionWindows->shortTerm[4];
		*DePIF_ST_Bin_5 = predictionWindows->shortTerm[5];
		*DePIF_ST_Bin_6 = predictionWindows->shortTerm[6];
		*DePIF_ST_Bin_7 = predictionWindows->shortTerm[7];
		*DePIF_ST_Bin_8 = predictionWindows->shortTerm[8];
		*DePIF_MT_Bin_0 = predictionWindows->midTerm[0];
		*DePIF_MT_Bin_1 = predictionWindows->midTerm[1];
		*DePIF_MT_Bin_2 = predictionWindows->midTerm[2];
		*DePIF_MT_Bin_3 = predictionWindows->midTerm[3];
		*DePIF_MT_Bin_4 = predictionWindows->midTerm[4];
		*DePIF_MT_Bin_5 = predictionWindows->midTerm[5];
		*DePIF_MT_Bin_6 = predictionWindows->midTerm[6];
		*DePIF_MT_Bin_7 = predictionWindows->midTerm[7];
		*DePIF_MT_Bin_8 = predictionWindows->midTerm[8];
		*DePIF_LT_Bin_0 = predictionWindows->longTerm[0];
		*DePIF_LT_Bin_1 = predictionWindows->longTerm[1];
		*DePIF_LT_Bin_2 = predictionWindows->longTerm[2];
		*DePIF_LT_Bin_3 = predictionWindows->longTerm[3];
		*DePIF_LT_Bin_4 = predictionWindows->longTerm[4];
		*DePIF_LT_Bin_5 = predictionWindows->longTerm[5];
		*DePIF_LT_Bin_6 = predictionWindows->longTerm[6];
		*DePIF_LT_Bin_7 = predictionWindows->longTerm[7];
		*DePIF_LT_Bin_8 = predictionWindows->longTerm[8];
	}
	else
	{ /*konstante Laufzeit realisieren*/
		*DePIF_ST_Bin_0 = 0;
		*DePIF_ST_Bin_1 = 0;
		*DePIF_ST_Bin_2 = 0;
		*DePIF_ST_Bin_3 = 0;
		*DePIF_ST_Bin_4 = 0;
		*DePIF_ST_Bin_5 = 0;
		*DePIF_ST_Bin_6 = 0;
		*DePIF_ST_Bin_7 = 0;
		*DePIF_ST_Bin_8 = 0;
		*DePIF_MT_Bin_0 = 0;
		*DePIF_MT_Bin_1 = 0;
		*DePIF_MT_Bin_2 = 0;
		*DePIF_MT_Bin_3 = 0;
		*DePIF_MT_Bin_4 = 0;
		*DePIF_MT_Bin_5 = 0;
		*DePIF_MT_Bin_6 = 0;
		*DePIF_MT_Bin_7 = 0;
		*DePIF_MT_Bin_8 = 0;
		*DePIF_LT_Bin_0 = 0;
		*DePIF_LT_Bin_1 = 0;
		*DePIF_LT_Bin_2 = 0;
		*DePIF_LT_Bin_3 = 0;
		*DePIF_LT_Bin_4 = 0;
		*DePIF_LT_Bin_5 = 0;
		*DePIF_LT_Bin_6 = 0;
		*DePIF_LT_Bin_7 = 0;
		*DePIF_LT_Bin_8 = 0;
	}
}


static void					oclOverride(INOUT		flexrayOutput_T			*flexrayOutput)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if (paramSet->outputCodec.override.DePACC02_Durchschnittsgeschw.override) {
		flexrayOutput->DePACC02_Durchschnittsgeschw = paramSet->outputCodec.override.DePACC02_Durchschnittsgeschw.value;
	}
	
	if (paramSet->outputCodec.override.DePACC02_Event_aktiv.override) {
		flexrayOutput->DePACC02_Event_aktiv = paramSet->outputCodec.override.DePACC02_Event_aktiv.value;
	}
	
	if (paramSet->outputCodec.override.DePACC02_Geschw_Vorausschau.override) {
		flexrayOutput->DePACC02_Geschw_Vorausschau = paramSet->outputCodec.override.DePACC02_Geschw_Vorausschau.value;
	}
	
	if (paramSet->outputCodec.override.DePACC02_Hinweis_Geschw.override) {
		flexrayOutput->DePACC02_Hinweis_Geschw = paramSet->outputCodec.override.DePACC02_Hinweis_Geschw.value;
	}
	
	if (paramSet->outputCodec.override.DePACC02_InnoDrive_Texte.override) {
		flexrayOutput->DePACC02_InnoDrive_Texte = paramSet->outputCodec.override.DePACC02_InnoDrive_Texte.value;
	}
	
	if (paramSet->outputCodec.override.DePACC02_Offset_Anzeige.override) {
		flexrayOutput->DePACC02_Offset_Anzeige = paramSet->outputCodec.override.DePACC02_Offset_Anzeige.value;
	}

	if (paramSet->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.override) {
		flexrayOutput->DePACC02_neg_Sollbeschl_Grad = paramSet->outputCodec.override.DePACC02_neg_Sollbeschl_Grad.value;
	}

	if (paramSet->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.override) {
		flexrayOutput->DePACC02_pos_Sollbeschl_Grad = paramSet->outputCodec.override.DePACC02_pos_Sollbeschl_Grad.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Sollbeschleunigung.override) {
		flexrayOutput->DePACC02_Sollbeschleunigung = paramSet->outputCodec.override.DePACC02_Sollbeschleunigung.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Sollgeschwindigkeit.override) {
		flexrayOutput->DePACC02_Sollgeschwindigkeit = paramSet->outputCodec.override.DePACC02_Sollgeschwindigkeit.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Vorausschaugeschw.override) {
		flexrayOutput->DePACC02_Vorausschaugeschw = paramSet->outputCodec.override.DePACC02_Vorausschaugeschw.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Wunschuebersetzung.override) {
		flexrayOutput->DePACC02_Wunschuebersetzung = paramSet->outputCodec.override.DePACC02_Wunschuebersetzung.value;
	}

	if (paramSet->outputCodec.override.DePACC02_zul_Regelabw_oben.override) {
		flexrayOutput->DePACC02_zul_Regelabw_oben = paramSet->outputCodec.override.DePACC02_zul_Regelabw_oben.value;
	}

	if (paramSet->outputCodec.override.DePACC02_zul_Regelabw_unten.override) {
		flexrayOutput->DePACC02_zul_Regelabw_unten = paramSet->outputCodec.override.DePACC02_zul_Regelabw_unten.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Offset.override) {
		flexrayOutput->DePACC02_Offset = paramSet->outputCodec.override.DePACC02_Offset.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Ausrollmanoever.override) {
		flexrayOutput->DePACC02_Ausrollmanoever = paramSet->outputCodec.override.DePACC02_Ausrollmanoever.value;
	}

	if (paramSet->outputCodec.override.DePACC02_naechstes_Event.override) {
		flexrayOutput->DePACC02_naechstes_Event = paramSet->outputCodec.override.DePACC02_naechstes_Event.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Systemstatus.override) {
		flexrayOutput->DePACC02_Systemstatus = paramSet->outputCodec.override.DePACC02_Systemstatus.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Systemstatus_Anzeige.override) {
		flexrayOutput->DePACC02_Systemstatus_Anzeige = paramSet->outputCodec.override.DePACC02_Systemstatus_Anzeige.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Automode.override) {
		flexrayOutput->DePACC02_Automode = paramSet->outputCodec.override.DePACC02_Automode.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Uebernahmeaufforderung.override) {
		flexrayOutput->DePACC02_Uebernahmeaufforderung = paramSet->outputCodec.override.DePACC02_Uebernahmeaufforderung.value;
	}

	if (paramSet->outputCodec.override.DePACC02_Offset_Aktiv.override) {
		flexrayOutput->DePACC02_Offset_Aktiv = paramSet->outputCodec.override.DePACC02_Offset_Aktiv.value;
	}

	if (paramSet->outputCodec.override.DePACC02_FoD_Status.override) {
		flexrayOutput->DePACC02_FoD_Status = paramSet->outputCodec.override.DePACC02_FoD_Status.value;
	}
	
	if (paramSet->outputCodec.override.DePIF_Toggle.override)
	{
		flexrayOutput->DePIF_Toggle = paramSet->outputCodec.override.DePIF_Toggle.value;

	}
	
	if (paramSet->outputCodec.override.DePIF_ST_Status.override)
	{
		flexrayOutput->DePIF_ST_Status = paramSet->outputCodec.override.DePIF_ST_Status.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Status.override)
	{
		flexrayOutput->DePIF_MT_Status = paramSet->outputCodec.override.DePIF_MT_Status.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Status.override)
	{
		flexrayOutput->DePIF_LT_Status = paramSet->outputCodec.override.DePIF_LT_Status.value;
	}

	if (paramSet->outputCodec.override.DePIF_Identifier.override)
	{
		flexrayOutput->DePIF_Identifier = paramSet->outputCodec.override.DePIF_Identifier.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_0.override)
	{
		flexrayOutput->DePIF_ST_Bin_0 = paramSet->outputCodec.override.DePIF_ST_Bin_0.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_1.override)
	{
		flexrayOutput->DePIF_ST_Bin_1 = paramSet->outputCodec.override.DePIF_ST_Bin_1.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_2.override)
	{
		flexrayOutput->DePIF_ST_Bin_2 = paramSet->outputCodec.override.DePIF_ST_Bin_2.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_3.override)
	{
		flexrayOutput->DePIF_ST_Bin_3 = paramSet->outputCodec.override.DePIF_ST_Bin_3.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_4.override)
	{
		flexrayOutput->DePIF_ST_Bin_4 = paramSet->outputCodec.override.DePIF_ST_Bin_4.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_5.override)
	{
		flexrayOutput->DePIF_ST_Bin_5 = paramSet->outputCodec.override.DePIF_ST_Bin_5.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_6.override)
	{
		flexrayOutput->DePIF_ST_Bin_6 = paramSet->outputCodec.override.DePIF_ST_Bin_6.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_7.override)
	{
		flexrayOutput->DePIF_ST_Bin_7 = paramSet->outputCodec.override.DePIF_ST_Bin_7.value;
	}

	if (paramSet->outputCodec.override.DePIF_ST_Bin_8.override)
	{
		flexrayOutput->DePIF_ST_Bin_8 = paramSet->outputCodec.override.DePIF_ST_Bin_8.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_0.override)
	{
		flexrayOutput->DePIF_MT_Bin_0 = paramSet->outputCodec.override.DePIF_MT_Bin_0.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_1.override)
	{
		flexrayOutput->DePIF_MT_Bin_1 = paramSet->outputCodec.override.DePIF_MT_Bin_1.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_2.override)
	{
		flexrayOutput->DePIF_MT_Bin_2 = paramSet->outputCodec.override.DePIF_MT_Bin_2.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_3.override)
	{
		flexrayOutput->DePIF_MT_Bin_3 = paramSet->outputCodec.override.DePIF_MT_Bin_3.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_4.override)
	{
		flexrayOutput->DePIF_MT_Bin_4 = paramSet->outputCodec.override.DePIF_MT_Bin_4.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_5.override)
	{
		flexrayOutput->DePIF_MT_Bin_5 = paramSet->outputCodec.override.DePIF_MT_Bin_5.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_6.override)
	{
		flexrayOutput->DePIF_MT_Bin_6 = paramSet->outputCodec.override.DePIF_MT_Bin_6.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_7.override)
	{
		flexrayOutput->DePIF_MT_Bin_7 = paramSet->outputCodec.override.DePIF_MT_Bin_7.value;
	}

	if (paramSet->outputCodec.override.DePIF_MT_Bin_8.override)
	{
		flexrayOutput->DePIF_MT_Bin_8 = paramSet->outputCodec.override.DePIF_MT_Bin_8.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_0.override)
	{
		flexrayOutput->DePIF_LT_Bin_0 = paramSet->outputCodec.override.DePIF_LT_Bin_0.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_1.override)
	{
		flexrayOutput->DePIF_LT_Bin_1 = paramSet->outputCodec.override.DePIF_LT_Bin_1.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_2.override)
	{
		flexrayOutput->DePIF_LT_Bin_2 = paramSet->outputCodec.override.DePIF_LT_Bin_2.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_3.override)
	{
		flexrayOutput->DePIF_LT_Bin_3 = paramSet->outputCodec.override.DePIF_LT_Bin_3.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_4.override)
	{
		flexrayOutput->DePIF_LT_Bin_4 = paramSet->outputCodec.override.DePIF_LT_Bin_4.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_5.override)
	{
		flexrayOutput->DePIF_LT_Bin_5 = paramSet->outputCodec.override.DePIF_LT_Bin_5.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_6.override)
	{
		flexrayOutput->DePIF_LT_Bin_6 = paramSet->outputCodec.override.DePIF_LT_Bin_6.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_7.override)
	{
		flexrayOutput->DePIF_LT_Bin_7 = paramSet->outputCodec.override.DePIF_LT_Bin_7.value;
	}

	if (paramSet->outputCodec.override.DePIF_LT_Bin_8.override)
	{
		flexrayOutput->DePIF_LT_Bin_8 = paramSet->outputCodec.override.DePIF_LT_Bin_8.value;
	}

}


static void			  oclSetDebugOutput(IN	const	uint16_T				 controlCode,
										OUT			real32_T				*DePACC02_Durchschnittsgeschw)
{
	*DePACC02_Durchschnittsgeschw = (real32_T)controlCode * DeFRInnoDriveOut_DePACC02_Durchschnittsgeschw_RANGE_MIN;
}
