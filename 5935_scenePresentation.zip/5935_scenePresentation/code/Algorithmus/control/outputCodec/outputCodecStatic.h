#ifndef guard_outputCodecStatic_h
#define guard_outputCodecStatic_h

#include "base.h"
#include "control/outputCodec/outputCodec_private.h"
#include "common/systemControllerCommon/systemController_interface.h"
#include "control/longController/longController_interface.h"


/**\brief Setzt den Ausgabe-Systemstatus.
\spec SW_AS_Innodrive2_51
\spec SW_AS_Innodrive2_115
\spec SW_AS_Innodrive2_116
\spec SW_AS_Innodrive2_117
\spec SW_AS_Innodrive2_121
\spec SW_AS_Innodrive2_118
\spec SW_AS_Innodrive2_119
\spec SW_AS_Innodrive2_595
\spec SW_AS_Innodrive2_49
\spec SW_AS_Innodrive2_600
\spec SW_AS_Innodrive2_681
\spec SW_AS_Innodrive2_742
\ingroup outputCodec_internal
*/
static void	   oclSetLongStatus(IN	const	systemControl_T			*systemControl,
								IN	const	displayControl_T		*displayControl,
								MEMORY		outputControlFilter_T	*filter,
								OUT			uint8_T					*DePACC02_Systemstatus,
								OUT			uint8_T					*DePACC02_Systemstatus_Anzeige,
								OUT			bool_T					*DePACC02_Automode,
								OUT			bool_T					*DePACC02_Uebernahmeaufforderung,
								OUT			bool_T					*DePACC02_Offset_Aktiv,
								OUT			int8_T					*DePACC02_Offset_Anzeige,
								OUT			uint8_T					*DePACC02_FoD_Status
								);

/**\brief Setzt die Ausgabe zur L�ngsregelung

\spec SW_AS_Innodrive2_59
\spec SwMS_Innodrive2_Output_75
\spec SwMS_Innodrive2_Output_76
\spec SwMS_Innodrive2_Output_77
\spec SwMS_Innodrive2_Output_78
\spec SwMS_Innodrive2_Output_79
\spec SwMS_Innodrive2_Output_80
\spec SwMS_Innodrive2_Output_81
\spec SwMS_Innodrive2_Output_82

\ingroup outputCodec_internal
*/
static void	  oclSetLongControl(IN	const	longControl_T			*longControl,
								IN	const	systemControl_T			*systemControl,
								OUT			real32_T				*DePACC02_Sollgeschwindigkeit,
								OUT			real32_T				*DePACC02_Sollbeschleunigung,
								OUT			real32_T				*DePACC02_neg_Sollbeschl_Grad,
								OUT			real32_T				*DePACC02_pos_Sollbeschl_Grad,
								OUT			real32_T				*DePACC02_zul_Regelabw_unten,
								OUT			real32_T				*DePACC02_zul_Regelabw_oben,
								OUT			int16_T					*DePACC02_Offset,
								OUT			real32_T				*DePACC02_Wunschuebersetzung,
								OUT			uint8_T					*DePACC02_Ausrollmanoever
								);

/**\brief Setzt die Ausgabe zur Display-Anzeige
\spec SW_AS_Innodrive2_645
\spec SW_AS_Innodrive2_63
\spec SW_AS_Innodrive2_71
\spec SW_AS_Innodrive2_72
\spec SW_AS_Innodrive2_596
\spec SW_AS_Innodrive2_671
\spec SW_AS_Innodrive2_672
\spec SW_AS_Innodrive2_675
\ingroup outputCodec_internal
*/
static void	  oclSetLongDisplay(IN	const	systemControl_T			*systemControl,					/**< Systemstatus und Setzgeschwindigkeiten */
								IN	const	displayControl_T		*displayControl,				/**< Anzeigeereignisse */
								INOUT		outputControlFilter_T	*filter,						/**< Interne Struktur des outputCodecs*/
								OUT			real32_T				*DePACC02_Vorausschaugeschw,	/**< Anzeige Vorausschaugeschwindigkeit */
								OUT			uint8_T					*DePACC02_naechstes_Event,		/**< Anzeige n�chstes EVent */
								OUT			uint8_T					*DePACC02_InnoDrive_Texte,		/**< Anzeige Informationstexte */
								OUT			bool_T					*DePACC02_Geschw_Vorausschau,	/**< Zuk�nftige (1) oder aktuelle (0) Setzgeschwindigkeit anzeigen?*/
								OUT			bool_T					*DePACC02_Event_aktiv,			/**< Event in blau (1) oder grau (0) anzeigen? */
								OUT			bool_T					*DePACC02_Hinweis_Geschw		/**< Geschwindigkeitswarnung f�r Fahrer anzeigen? */
								);

/**\brief Setzt die Ausgabe auf Applikationsparameter

\spec SwMS_Innodrive2_Output_72

\ingroup outputCodec_internal
*/
static void			oclOverride(INOUT		flexrayOutput_T			*flexrayOutput
								);


/**\brief Kopiert die Ausgabe des driverPredictors in die interne Datenstruktur des outputCodecs.

	Weiterhin z�hlt diese Funktion intern die 16 Takte zum Senden der MUX-Botschaft. Ihr R�ckgabewert `muxID`
	ist eine Zahl zwischen 0 ... 15, die in \ref oclSetForecast() verwendet wird um die MUX-Botschaft
	vorzubrereiten.

\ingroup outputCodec_constraints
*/
static bool_T oclGetPIFMuxIDDprdData(	IN const	driverPrediction_T		*driverPrediction,	/**<Ausgabestruktur des driverPredictors*/
										INOUT		outputControlFilter_T	*filter,			/**<Interne Struktur des outputCodecs mit einer Kopie des driverPredictor-Ausgangs f�r insgesamt 16 Takte*/
										OUT			uint8_T					*muxID				/**<Ausgabe der muxID*/
										);

/**\brief Konvertiert die internen Daten des driverPredictors in das Ausgangsformats des outputCodecs.

	�ber 16 Takte hinweg sendet der outputCodec alle verf�gbaren driverPredictor Zeitfenster. 
	Innerhalb dieser 16 Takte ist jedes verf�gbare Zeitfenster f�r insgesamt 4 Takte an den Ausg�ngen des
	outputCodecs vorhanden.

	\spec SwMS_Innodrive2_Output_59
	\spec SwMS_Innodrive2_Output_58
	\spec SwMS_Innodrive2_Output_60
	\spec SwMS_Innodrive2_Output_61

\ingroup outputCodec_constraints
*/
static void oclSetForecast(	IN const	driverPrediction_T		*driverPrediction,		/**<Ausgabestruktur des driverPredictors*/
							INOUT		outputControlFilter_T	*filter,				/**<Interne Struktur des outputCodecs mit einer Kopie des driverPredictor-Ausgangs f�r insgesamt 16 Takte*/
							OUT			bool_T					*DePIF_Toggle,			/**<Toggle Bit des driverPredictors zum signalisieren, dass das Modul sich nicht im Fehlerzustande befindet*/
							OUT			uint8_T					*DePIF_ST_Status,		/**<Status des shortTerm Zeitfensters*/
							OUT			uint8_T					*DePIF_MT_Status,		/**<Status des midTerm Zeitfensters*/
							OUT			uint8_T					*DePIF_LT_Status,		/**<Status des longTerm Zeitfensters*/
							OUT			uint8_T					*DePIF_Identifier,		/**<Identifier des Zeitfensters, dass sich an den Ausg�ngen des outputCodes befindet*/
							OUT			uint8_T					*DePIF_ST_Bin_0,		/**<shortTerm Zeitfenster Bin 0*/
							OUT			uint8_T					*DePIF_ST_Bin_1,		/**<shortTerm Zeitfenster Bin 1*/
							OUT			uint8_T					*DePIF_ST_Bin_2,		/**<shortTerm Zeitfenster Bin 2*/
							OUT			uint8_T					*DePIF_ST_Bin_3,		/**<shortTerm Zeitfenster Bin 3*/
							OUT			uint8_T					*DePIF_ST_Bin_4,		/**<shortTerm Zeitfenster Bin 4*/
							OUT			uint8_T					*DePIF_ST_Bin_5,		/**<shortTerm Zeitfenster Bin 5*/
							OUT			uint8_T					*DePIF_ST_Bin_6,		/**<shortTerm Zeitfenster Bin 6*/
							OUT			uint8_T					*DePIF_ST_Bin_7,		/**<shortTerm Zeitfenster Bin 7*/
							OUT			uint8_T					*DePIF_ST_Bin_8,		/**<shortTerm Zeitfenster Bin 8*/
							OUT			uint8_T					*DePIF_MT_Bin_0,		/**<midTerm Zeitfenster Bin 0*/
							OUT			uint8_T					*DePIF_MT_Bin_1,		/**<midTerm Zeitfenster Bin 1*/
							OUT			uint8_T					*DePIF_MT_Bin_2,		/**<midTerm Zeitfenster Bin 2*/
							OUT			uint8_T					*DePIF_MT_Bin_3,		/**<midTerm Zeitfenster Bin 3*/
							OUT			uint8_T					*DePIF_MT_Bin_4,		/**<midTerm Zeitfenster Bin 4*/
							OUT			uint8_T					*DePIF_MT_Bin_5,		/**<midTerm Zeitfenster Bin 5*/
							OUT			uint8_T					*DePIF_MT_Bin_6,		/**<midTerm Zeitfenster Bin 6*/
							OUT			uint8_T					*DePIF_MT_Bin_7,		/**<midTerm Zeitfenster Bin 7*/
							OUT			uint8_T					*DePIF_MT_Bin_8,		/**<midTerm Zeitfenster Bin 8*/
							OUT			uint8_T					*DePIF_LT_Bin_0,		/**<longTerm Zeitfenster Bin 0*/
							OUT			uint8_T					*DePIF_LT_Bin_1,		/**<longTerm Zeitfenster Bin 1*/
							OUT			uint8_T					*DePIF_LT_Bin_2,		/**<longTerm Zeitfenster Bin 2*/
							OUT			uint8_T					*DePIF_LT_Bin_3,		/**<longTerm Zeitfenster Bin 3*/
							OUT			uint8_T					*DePIF_LT_Bin_4,		/**<longTerm Zeitfenster Bin 4*/
							OUT			uint8_T					*DePIF_LT_Bin_5,		/**<longTerm Zeitfenster Bin 5*/
							OUT			uint8_T					*DePIF_LT_Bin_6,		/**<longTerm Zeitfenster Bin 6*/
							OUT			uint8_T					*DePIF_LT_Bin_7,		/**<longTerm Zeitfenster Bin 7*/
							OUT			uint8_T					*DePIF_LT_Bin_8			/**<longTerm Zeitfenster Bin 8*/
							);

/**\brief Setzt die Ausgabe zu
\ingroup outputCodec_internal
*/
static void			  oclSetDebugOutput(IN	const	uint16_T				 controlCode,
										OUT			real32_T				*DePACC02_Durchschnittsgeschw
										);


#endif
