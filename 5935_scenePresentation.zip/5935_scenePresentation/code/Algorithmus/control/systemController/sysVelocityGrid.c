#include "control/systemController/sysVelocityGrid.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "control/inputCodec/inputCodec_private.h"
#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysVelocityGrid)



bool_T	sysInitVelocityGrid(		IN const	vehicleInput_T			*vehicleInput,
									IN const	vehicleState_T			*vehicleState,
									OUT			velocityGrid_T			*velocityGrid)
{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();
	uint16_T vMaxKmh, vMaxMph;
	vobsGetVMaxRaw(vehicleState, &vMaxKmh, &vMaxMph);

	/*Freifahrtgeschwindigkeit in m/s*/
	velocityGrid->maxAutoSpeed = vehicleInput->driver.maxAutoSpeed;
	/*Abh�ngig von der Tachoeinheit Schrittweiten und Grenzen setzen*/
	switch (vehicleInput->driver.displayUnit)
	{
	case dsplUnitKph:
		/*Einheit*/
		velocityGrid->gridUnit = KPH_TO_MPS;
		/*Schrittweiten*/
		velocityGrid->smallIncrement = parameterSet->systemController.velocityControl.smallIncrementKmh;
		velocityGrid->bigIncrement   = parameterSet->systemController.velocityControl.bigIncrementKmh;
		/*Grenzen*/
		velocityGrid->minSetSpeed    = parameterSet->systemController.velocityControl.minSetSpeedKmh;
		velocityGrid->maxSetSpeed    = min(vMaxKmh, parameterSet->systemController.velocityControl.maxSetSpeedKmh);
		break;

	case dsplUnitMph: 
		/*Einheit*/
		velocityGrid->gridUnit = MPH_TO_MPS; 
		/*Schrittweiten*/
		velocityGrid->smallIncrement = parameterSet->systemController.velocityControl.smallIncrementMph;
		velocityGrid->bigIncrement   = parameterSet->systemController.velocityControl.bigIncrementMph;
		/*Grenzen*/
		velocityGrid->minSetSpeed    = parameterSet->systemController.velocityControl.minSetSpeedMph;
		velocityGrid->maxSetSpeed    = min(vMaxMph, parameterSet->systemController.velocityControl.maxSetSpeedMph);
		break;
	default: 
		diagFUnreachable();
	} /*lint !e9077*/

	return true;
}


bool_T	sysSaturateSetSpeed(IN const		velocityGrid_T			*grid,
							IN const		real32_T				 setSpeed,
							OUT				real32_T				*saturated)
{
	real32_T speed = setSpeed;

	/*Runden*/
	speed = speed / grid->gridUnit + 0.5f;
	diagFNaN(speed);
	speed = (real32_T)floorf(speed) * grid->gridUnit;

	/*Begrenzen*/
	speed = min(speed, grid->gridUnit * (real32_T)grid->maxSetSpeed);
	speed = max(speed, grid->gridUnit * (real32_T)grid->minSetSpeed);

	*saturated = speed;

	return true;
}

