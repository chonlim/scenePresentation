#ifndef guard_SysDriverInputStatic_h
#define guard_SysDriverInputStatic_h


/**\brief Bricht eine Bedienhandlung abh�ngig von der Abbruchflag ab.

Wenn die Abbruchflag `doCancel = true` ist, muss die Funktion den `driverInput` auf den Zustand
`sysCanceled` setzen, wenn `isPressed = true` ist und sonst auf `sysNotPressed`

\spec SW_AS_Innodrive2_677 (Resume abbrechen)
\ingroup systemController_input
*/
static void		sysCancelDriverInput(	IN const	longPressCycleCount_T		*longPressCount,	/**<Anzahl der Zyklen zur Erkennung eines gehaltenen Bedienelements*/
										IN const	bool_T						 isPressed,			/**<Aktueller Zustand des Bedienelements*/
										IN const	bool_T						 doCancel,			/**<Abbruch der Longpressed-Funktion*/
										INOUT		sysDriverInput_T			*driverInput		/**<Entprellter Zustand des Bedienelements*/
										);															

#endif
