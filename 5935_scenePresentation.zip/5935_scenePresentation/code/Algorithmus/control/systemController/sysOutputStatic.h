#ifndef guard_sysOutputStatic_h
#define guard_sysOutputStatic_h

#include "control/systemController/systemController.h"
#include "control/systemController/sysSetSpeed.h"

#include "common/systemControllerCommon/systemController_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"


/** \brief Gibt die aktuelle und zuk�nftige Setzgeschwindigkeit aus.

Aktuelle und zuk�nftige Setzgeschwindigkeit werden ausgegeben.
Eine ung�ltige zuk�nftige Setzgeschwindigkeit wird als -INVALID_VALUE ausgegeben.
Die Position ist die Fahrzeugposition f�r die aktuelle Setzgeschwindigkeit und die Limit-Position f�r die zuk�nftige Setzgeschwindigkeit
Die Flag displayValid zeigt an, dass die aktuelle Setzgeschwindigkeit g�ltig ist. Nur bei inaktivem system kann es vorkommen, 
dass keine aktuelle Setzgeschwindigkeit vorliegt. Dann muss dem Fahrer "---" angezeigt werden (`displayValid == false`)
Die Flag displayAuto zeigt an, dass der automatische Modus aktiviert ist und die vom Fahrer verstellbare Setzgeschwindigkeit dem Tempolimit entspricht.

\spec SW_AS_Innodrive2_544
\spec SW_AS_Innodrive2_59
\spec SW_AS_Innodrive2_595

\ingroup systemController_step
*/
static bool_T	sysSetSpeedPermanent(	IN const	setSpeedControl_T		*setSpeedControl,		/**< Daten der Setzgeschwindigkeitsverstellung*/
										IN const	speedInfo_T				*egoSpeed,				/**< Fahrzeugposition und -Geschwindigkeit*/
										IN const	bool_T					 isActivated,			/**< System im Zustand sysActive oder sysOverride*/
										OUT			speedInfo_T				*currentSetSpeed,		/**< Aktuelle Setzgeschwindigkeit*/
										OUT			speedInfo_T				*nextSetSpeed,			/**< Zuk�nftige Setzgeschwindigkeit*/
										OUT			bool_T					*displayValid,			/**< Kann die Setzgeschwindigkeit dem Fahrer angezeigt werden? */
										OUT			bool_T					*dsplLimitEventsActive	/**< Soll dem Fahrer "AUTO" anstelle der Setzgeschwindigkeit angezeigt werden? */
										);


/** \brief Schieberegister f�r die Setzgeschwindigkeit

Wenn die aktuelle Setzgeschwindigkeit `currentSetSpeed` sich �ndert, also von der gespeicherten Setzgeschwindigkeit `setSpeedFilter.currentSetSpeed` abweicht,
muss die Funktion sysFilterSetSpeed die gespeicherte aktuelle Setzgeschwindigkeit als vergangene Setzgeschwindigkeit speichern und die aktuelle Setzgeschwindigkeit
mit der aktuellen Fahrzeugposition `egoSpeed.position` als `setSpeedFilter.currentSetSpeed`speichern.
Sonst muss der `setSpeedFilter`unver�ndert bleiben.
Die Position der aktuellen Setzgeschwindigkeit muss echt gr��er als die Position der vergangenen Setzgeschwindigkeit sein.

Dies dient dazu, dem constraintMaster den letzten Setzgeschwindigkeitswechsel an der Stelle, an der er tats�chlich stattgefunden hat, anzuzeigen.

\spec SW_AS_Innodrive2_544

\ingroup systemController_step
*/
static bool_T	sysFilterSetSpeed(		IN const	speedInfo_T				*currentSetSpeed,		/**< Aktualle Setzgeschwindigkeit*/
										IN const	speedInfo_T				*egoSpeed,				/**< Fahrzeugposition und -Geschwindigkeit*/
										INOUT		setSpeedFilter_T		*setSpeedFilter			/**< Filter zum speichern der vergangenen Setzgeschwindigkeit*/
										);

#endif
