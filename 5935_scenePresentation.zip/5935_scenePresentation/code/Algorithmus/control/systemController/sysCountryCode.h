#ifndef guard_sysCountryCode_h
#define guard_sysCountryCode_h

#include "control/systemController/systemController.h"


/** \brief Gibt an, ob die FUnktionen Innodrive2 und Intelligent Forecastf�r den L�ndercode freigegeben sind.

\spec SW_AS_Innodrive2_94
\spec SwMS_Innodrive2_Control_53
\spec SW_AS_PIF_679

\ingroup systemController_preconditions
*/
bool_T			sysIsCountryOk(		IN const	uint8_T				countryCode,		/**<L�ndercode*/
									IN const	bool_T				ignore				/**<Flag zum Ignorieren des L�ndercodes*/
									);

#endif
