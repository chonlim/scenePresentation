#include "control/systemController/sysStatus.h"
#include "control/systemController/sysStatusStatic.h"
#include "control/systemController/sysPreconditions.h"
#include "control/systemController/sysJamPilot.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "control/inputCodec/inputCodec_private.h"
#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysStatus)


static void	sysInit_boolDebounce_T(	OUT	boolDebounce_T *boolDebounce)
{
	boolDebounce->status = false;
	boolDebounce->debounceCounter = (uint16_T)INVALID_UINT16;
	boolDebounce->debounceMaxCount = (uint16_T)INVALID_UINT16;
}

void	sysInit_systemStatus_T(	OUT	systemStatus_T	*systemStatus)
{
	systemStatus->status = sysStatusDisabled;
	systemStatus->mapStatus.status = false;
	sysInit_boolDebounce_T(&systemStatus->mapStatus.mapValidStatus);
	sysInit_boolDebounce_T(&systemStatus->mapStatus.roadDataStatus);
	sysInit_boolDebounce_T(&systemStatus->mapStatus.strategyStatus);
	sysInit_boolDebounce_T(&systemStatus->mapStatus.speedLimitStatus);

	sysInit_boolDebounce_T(&systemStatus->overrideStatus);
	sysInit_boolDebounce_T(&systemStatus->activationStatus);
	systemStatus->lastAcvnAction = sysAcvnNone;
}

void		sysInitSystemStatus(IN const	parameterSetCtrl_T		*parameterSet,
								OUT			systemStatus_T			*systemStatus)
{
	real32_T count;
	const struct _parameterSetCtrl_systemController_status *prmStatus = &parameterSet->systemController.status;
	sysInit_systemStatus_T(systemStatus);

	/*Entprellzeiten in Zykluszahlen umrechnen mit Rundung*/
	count = prmStatus->mapValidDebounceTime   / controlCYCLETIME + 0.5f;
	systemStatus->mapStatus.mapValidStatus.debounceMaxCount		= (uint16_T)floorf(count);
	count = prmStatus->roadDataDebounceTime   / controlCYCLETIME + 0.5f;
	systemStatus->mapStatus.roadDataStatus.debounceMaxCount		= (uint16_T)floorf(count);
	count = prmStatus->strategyDebounceTime   / controlCYCLETIME + 0.5f;
	systemStatus->mapStatus.strategyStatus.debounceMaxCount		= (uint16_T)floorf(count);
	count = prmStatus->speedLimitDebounceTime / controlCYCLETIME + 0.5f;
	systemStatus->mapStatus.speedLimitStatus.debounceMaxCount	= (uint16_T)floorf(count);
	count = prmStatus->overrideDebounceTime   / controlCYCLETIME + 0.5f;
	systemStatus->overrideStatus.debounceMaxCount				= (uint16_T)floorf(count);
	count = prmStatus->maxWaitTimeAccAcvn     / controlCYCLETIME + 0.5f;
	systemStatus->activationStatus.debounceMaxCount				= (uint16_T)floorf(count);

	/*Entrpellz�hler initialisieren. Die Entprellz�hler z�hlen r�ckw�rts auf Null.*/
	systemStatus->mapStatus.mapValidStatus.debounceCounter		= systemStatus->mapStatus.mapValidStatus.debounceMaxCount;
	systemStatus->mapStatus.roadDataStatus.debounceCounter		= systemStatus->mapStatus.roadDataStatus.debounceMaxCount;
	systemStatus->mapStatus.strategyStatus.debounceCounter		= systemStatus->mapStatus.strategyStatus.debounceMaxCount;
	systemStatus->mapStatus.speedLimitStatus.debounceCounter	= systemStatus->mapStatus.speedLimitStatus.debounceMaxCount;
	systemStatus->overrideStatus.debounceCounter				= systemStatus->overrideStatus.debounceMaxCount;
	systemStatus->activationStatus.debounceCounter				= systemStatus->activationStatus.debounceMaxCount;
}


bool_T		sysEvalSystemStatus(IN const	vehicleInput_T			*vehicleInput,
								IN const	vehicleState_T			*vehicleState,
								IN const	pathRouterMemory_T		*pathRouterMemory,
								IN const	roadModelInfo_T			*roadModelInfo,
								IN const	longControlStatus_T		*longControlStatus,
								IN const	velocityGrid_T			*velocityGrid,
								IN const	bool_T					setSpeedValid,
								INOUT		systemStatus_T			*systemStatus,
								OUT			sysDisplayError_T		*displayError,
								OUT			bool_T					*isNewActivation)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	bool_T	isSystemEnabled, isOverride, isBrakeOnlyMode, isAccError,
			isAccActive, isMapDataValid, isSpeedLimitOk, isRoadDataOk, isStrategyValid, debouncedMapStatus,
			isAvailable, isExitBOM, isEnterBOM;
	uint8_T mapInvalidReason;

	/*�bergangsbedingungen abfragen*/
	diagFF(sysIsSystemEnabled(	vehicleInput,	&isSystemEnabled));
	diagFF(sysIsOverride(		vehicleInput,	&isOverride));
	diagFF(sysIsBrakeOnlyMode(	vehicleInput,	&isBrakeOnlyMode));
	diagFF(sysIsAccActive(		vehicleInput,	&isAccActive));

	diagFF(sysIsMapDataValid(									pathRouterMemory,				&mapInvalidReason, &isMapDataValid));
	diagFF(sysIsRoadDataOk(		vehicleInput,	vehicleState,	pathRouterMemory,				&mapInvalidReason, &isRoadDataOk));
	diagFF(sysIsSpeedLimitOk(									roadModelInfo,	velocityGrid,	&mapInvalidReason, &isSpeedLimitOk));
	diagFF(sysIsStrategyValid(	vehicleInput,	vehicleState,	*longControlStatus,				&mapInvalidReason, &isStrategyValid));
	diagFF(sysIsAccError(		vehicleInput,													&mapInvalidReason, &isAccError));

	/*Zeitabh�ngige Zust�nde aktualisieren*/
	diagFF(sysHoldTrue(isOverride,		&systemStatus->overrideStatus));
	diagFF(sysUpdateMapStatus(isMapDataValid, isRoadDataOk, isSpeedLimitOk, isStrategyValid, &systemStatus->mapStatus, &debouncedMapStatus));

	/*Kombinierte Bedingungen*/
	isAvailable		=     (isMapDataValid  || paramSet->systemController.status.allowOnBadData)
					  &&  (isRoadDataOk    || paramSet->systemController.status.allowOnBadRoad)
					  &&  (isSpeedLimitOk  || paramSet->systemController.status.allowOnBadLimit)
					  &&  (isStrategyValid)
					  &&  (!isBrakeOnlyMode)
					  &&  (!isAccError);
	isExitBOM		=	  (!isAccActive && !isBrakeOnlyMode)
					  ||  (isOverride && paramSet->systemController.status.overrideLeaveBOM);
	isEnterBOM		= !debouncedMapStatus && !isAvailable;

	/*Bedienhandlung Aktivierung (Resume hat Vorrang vor Set)*/
	diagFF(sysUpdateAcvnStatus( vehicleInput, 
							   &systemStatus->jamPilot, 
							    setSpeedValid, 
							   &systemStatus->activationStatus, 
							   &systemStatus->lastAcvnAction));

	/*Zustands�bergang*/
	diagFF(sysSwitchStatus(&systemStatus->status,
							systemStatus,
							isSystemEnabled,
							isAvailable,
							isAccActive,
							isBrakeOnlyMode,
							isEnterBOM,
							isExitBOM,
							mapInvalidReason,
						    isNewActivation));


	/*\spec SW_AS_Innodrive2_592 Setzen displayError*/
	sysSetDisplayError(systemStatus->status, 
					   mapInvalidReason, 
					   isBrakeOnlyMode, 
					   displayError);

	return true;
}

static bool_T	sysSwitchStatus(INOUT		sysStatus_T				*sysStatus,
								IN	const	systemStatus_T			*systemStatus,
								IN	const	bool_T					 isSystemEnabled,
								IN	const	bool_T					 isAvailable,
								IN	const	bool_T					 isAccActive,
								IN	const	bool_T					 isBrakeOnlyMode,
								IN	const	bool_T					 isEnterBOM,
								IN	const	bool_T					 isExitBOM,
								IN	const	uint8_T					 mapInvalidReason,
								OUT			bool_T					*isNewActivation)
{
	const sysStatus_T oldStatus = *sysStatus;
	sysStatus_T status = *sysStatus;

	bool_T recheck = true;
	while (recheck) {
		recheck = false;

		switch (status)
		{
		case sysStatusDisabled: /*\spec SW_AS_Innodrive2_82*/
			if (isSystemEnabled) { 
				status = sysStatusNotAvailable; 
				diagReportInfo(diagInfo_sysStatusNotAvailable);
			}
			break;
		case sysStatusNotAvailable:	/*\spec SW_AS_Innodrive2_100*/
			if (isAvailable) { 
				status = sysStatusAvailable; 
				diagReportInfo(diagInfo_sysStatusAvailable);
			}
			break;
		case sysStatusBrakeOnlyMode: /*\spec SW_AS_Innodrive2_114*/
			if (isExitBOM) { 
				status = sysStatusAvailable; 
				recheck = true;
				diagReportInfo(diagInfo_sysStatusAvailable);
			}
			break;
		case sysStatusAvailable:
			if (!isAvailable) {	/*\spec SW_AS_Innodrive2_90*/
				status = sysStatusNotAvailable;
				diagReportInfo(diagInfo_sysStatusNotAvailable);
				if (0u != mapInvalidReason)	{ diagPrintMapInvalidReason(mapInvalidReason); }
				if (isBrakeOnlyMode)		{ diagReportInfo(diagInfo_sysReasonACCinBOM); }
			}
			else if (isAccActive && systemStatus->activationStatus.status) { /*\spec SW_AS_Innodrive2_89*/
				status = sysStatusActive;
				diagReportInfo(diagInfo_sysStatusActive);
			}
			else {
				status = sysStatusAvailable;
			}
			break;
		case sysStatusActive:
			if (!isAccActive && !isBrakeOnlyMode) { /*\spec SW_AS_Innodrive2_105*/
				status = sysStatusAvailable;
				recheck = true;
				diagReportInfo(diagInfo_sysStatusAvailable);
				diagReportInfo(diagInfo_sysReasonACCDeactivation);
			}
			else if (isEnterBOM) { /*\spec SW_AS_Innodrive2_107*/
				status = sysStatusBrakeOnlyMode;
				diagReportInfo(diagInfo_sysStatusBrakeOnlyMode);
				diagFF(0u != mapInvalidReason);
				diagPrintMapInvalidReason(mapInvalidReason);
				if (isBrakeOnlyMode)	{ diagReportInfo(diagInfo_sysReasonACCinBOM); }
			}
			else if (systemStatus->overrideStatus.status) { /*\spec SW_AS_Innodrive2_110*/
				status = sysStatusOverride;
				diagReportInfo(diagInfo_sysStatusOverride);
			}
			else {
				status = sysStatusActive;
			}
			break;
		case sysStatusOverride:
			if (!isAccActive && !isBrakeOnlyMode) { /*\spec SW_AS_Innodrive2_105*/
				status = sysStatusAvailable;
				recheck = true;
				diagReportInfo(diagInfo_sysStatusAvailable);
				diagReportInfo(diagInfo_sysReasonACCDeactivation);
			}
			else if (!systemStatus->overrideStatus.status) { /*\spec SW_AS_Innodrive2_109*/
				status = sysStatusActive;
				recheck = true;
				diagReportInfo(diagInfo_sysStatusActive);
			} 
			else {
				status = sysStatusOverride;
			}
			break;
		default:
			diagFUnreachable();
		}/*lint !e9077*/

	} /*ENDWHILE recheck*/
	
	/*\spec SW_AS_Innodrive2_81 (globaler �bergang nach `sysStatusDisabled`)*/
	if (!isSystemEnabled) {
		diagReportInfo(diagInfo_sysStatusDisabled);
		status = sysStatusDisabled;
	}

	/*Ausgabe*/
	*isNewActivation = ((status == sysStatusActive) && (oldStatus == sysStatusAvailable)) ? true : false;
	*sysStatus = status;
	return true;
}


static bool_T		sysHoldTrue(	IN const	bool_T				 inStatus,
									INOUT		boolDebounce_T		*debounced)
{
	bool_T   outStatus;
	uint16_T outCounter;

	if (debounced->debounceCounter == 0u)
	{
		outStatus = inStatus;
		outCounter = 0;
	} else {
		outStatus = debounced->status;
		outCounter = debounced->debounceCounter - 1u;
	}

	if (inStatus)
	{
		debounced->status = inStatus;
		debounced->debounceCounter = debounced->debounceMaxCount;
	} else {
		debounced->status = outStatus;
		debounced->debounceCounter = outCounter;
	}

	return true;
}


static bool_T	sysUpdateMapStatus(	IN const	bool_T					 isMapDataValid,
									IN const	bool_T					 isRoadDataOk,
									IN const	bool_T					 isSpeedLimitOk,
									IN const	bool_T					 isStrategyValid,
									INOUT		sysMapStatus_T			*debounced,
									OUT			bool_T					*status)
{
	/*Zeitabh�ngige Zust�nde aktualisieren*/
	diagFF(sysHoldTrue(isMapDataValid,	&debounced->mapValidStatus));
	diagFF(sysHoldTrue(isRoadDataOk,	&debounced->roadDataStatus));
	diagFF(sysHoldTrue(isStrategyValid,	&debounced->strategyStatus));
	diagFF(sysHoldTrue(isSpeedLimitOk,	&debounced->speedLimitStatus));

	/*Karten-Stati in einem Status zusammenfassen*/
	*status =		debounced->mapValidStatus.status
				&&	debounced->roadDataStatus.status
				&&	debounced->strategyStatus.status
				&&	debounced->speedLimitStatus.status;

	/* Debounced-Status in die mapStatus-Struktur �bertragen */
	debounced->status = *status;

	return true;
}


static bool_T		sysUpdateAcvnStatus(IN const	vehicleInput_T			*vehicleInput,
										IN const	sysJamPilotStatus_T		*jamPilot,
										IN const	bool_T					setSpeedValid,
										INOUT		boolDebounce_T			*activationStatus,
										INOUT		sysActivation_T			*lastAcvnAction)
{
	
	if (vehicleInput->driver.resume && (vehicleInput->driver.autoMode || setSpeedValid))
	{
		*lastAcvnAction = sysAcvnResume;
		diagFF(sysHoldTrue(true, activationStatus));
	}
	else if (vehicleInput->driver.set)
	{
		*lastAcvnAction = sysAcvnSet;	
		diagFF(sysHoldTrue(true, activationStatus));
	}
	else
	{
		diagFF(sysHoldTrue(false, activationStatus));
		if (!activationStatus->status)
		{
			*lastAcvnAction = sysAcvnNone;		
		} else {
			*lastAcvnAction = *lastAcvnAction;
		}
	}
	
	if (sysJamPilotIsActive(jamPilot))
	{
		activationStatus->status = false;
		activationStatus->debounceCounter = 0u;
		*lastAcvnAction = sysAcvnNone;
	}

	return true;
}


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "sysDebug.h"

ICC_API void dbg_sysGet_sysUpdateMapStatus(sysUpdateMapStatusCB *sysUpdateMapStatusPointer)
{
	*sysUpdateMapStatusPointer = sysUpdateMapStatus;
}

ICC_API void dbg_sysGet_sysUpdateAcvnStatus(sysUpdateAcvnStatusCB *sysUpdateAcvnStatusPointer)
{
	*sysUpdateAcvnStatusPointer = sysUpdateAcvnStatus;
}

ICC_API void dbg_sysGet_sysHoldTrue(sysHoldTrueCB *sysHoldTruePointer)
{
	*sysHoldTruePointer = sysHoldTrue;
}

ICC_API void dbg_sysGet_sysInit_boolDebounce_T(sysInit_boolDebounce_TCB *sysInit_boolDebounce_TPointer)
{
	*sysInit_boolDebounce_TPointer = sysInit_boolDebounce_T;
}
#endif
