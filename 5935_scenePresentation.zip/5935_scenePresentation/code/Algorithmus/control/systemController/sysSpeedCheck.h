#ifndef guard_sysSpeedCheck_h
#define guard_sysSpeedCheck_h


bool_T		  sysSpeedCheck(MEMORY		speedCheckFilter_T	*filter,
							IN	const	bool_T				 systemActive,
							IN	const	real32_T			 setSpeed,
							IN	const	real32_T			 velocity,
							OUT			real32_T			*toleranceFactor
							);


#endif
