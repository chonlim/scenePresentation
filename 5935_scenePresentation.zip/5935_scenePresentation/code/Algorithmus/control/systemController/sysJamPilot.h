#ifndef guard_sysJamPilot_h
#define guard_sysJamPilot_h

#include "control/systemController/systemController.h"
#include "common/systemControllerCommon/systemController_private.h"

/** \brief Aktualisierung des Status der Funktion Staupilot

\spec SwMS_Innodrive2_Control_55

\ingroup systemController_status
*/
void		 sysJamUpdateStatus(IN	const	vehicleInput_T		*vehicleInput,		/**<Eingangssignale*/
								INOUT		sysJamPilotStatus_T	*jamPilotStatus		/**<Status der Funktion Staupilot*/
								);

/** \brief Abfrage des Status der Funktion Staupilot

\spec SwMS_Innodrive2_Control_55

\ingroup systemController_status
*/
bool_T		sysJamPilotIsActive(IN	const	sysJamPilotStatus_T *jamPilotStatus		/**<Status der Funktion Staupilot*/
								);

#endif
