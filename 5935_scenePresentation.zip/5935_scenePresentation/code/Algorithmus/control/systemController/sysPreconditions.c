#include "control/systemController/sysPreconditions.h"
#include "control/systemController/sysCountryCode.h"
#include "common/systemControllerCommon/sysInfo.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "control/pathRouter/prtTools.h"

#include "control/inputCodec/inputCodec_private.h"

#include "common/platformInterface/pltfDiag.h"


/*Gr�nde f�r Deaktivierung aufgrund von ung�ltigen Kartendaten*/
/*lint -emacro(835, debug_map_valid)*/
#define debug_map_valid					((uint8_T)  0)
#define debug_map_inv_prtMemory			((uint8_T)  1)
#define debug_map_inv_roadInfo			((uint8_T)  2)
#define debug_map_inv_speedLimit		((uint8_T)  4)
#define debug_map_inv_countryCode		((uint8_T)  8)
#define debug_map_inv_streetClass		((uint8_T) 16)
#define debug_map_inv_strategy			((uint8_T) 32)
#define debug_acc_inv_reversible		((uint8_T) 64)
#define debug_acc_inv_irreversible		((uint8_T)128)


bool_T		sysIsSystemEnabled(		IN const	vehicleInput_T		*vehicleInput,
									OUT			bool_T				*isEnabled)
{
	if (vehicleInput->driver.selected  &&  
		vehicleInput->driver.enabled   &&
		vehicleInput->driver.fodActivation)
	{
		*isEnabled = true;
	} else {
		*isEnabled = false;
	}

	return true;
}


bool_T		sysIsMapDataValid(		IN const	pathRouterMemory_T	*pathRouterMemory,
									OUT			uint8_T				*reasonFlags,
									OUT			bool_T				*valid)
{
	*reasonFlags = debug_map_valid;

	/*Kartendaten generell g�ltig*/
	*valid = prtIsMemoryValid(pathRouterMemory);
	*reasonFlags |= *valid ? debug_map_valid : debug_map_inv_prtMemory;

	return true;
}


bool_T		sysIsSpeedLimitOk(		IN const	roadModelInfo_T		*roadModelInfo,
									IN const	velocityGrid_T		*velocityGrid,
									INOUT		uint8_T				*reasonFlags,
									OUT			bool_T				*isOk)
{
	real32_T limitValue, vehiclePosition;
	uint16_T limitRaw;
	uint8_T reason;
	bool_T valid;
	
	reason = debug_map_valid;
	sysRoadInfoGetRefPosition(roadModelInfo, &vehiclePosition);

	/*Tempolimit*/
	sysRoadInfoIsValid(roadModelInfo, &valid);
	reason |= valid ? debug_map_valid : debug_map_inv_roadInfo;
	valid = sysRoadInfoGetLimit(roadModelInfo, vehiclePosition, &limitValue, &limitRaw, NULL);
	reason |= valid ? debug_map_valid : debug_map_inv_roadInfo;

	valid = limitValue - (real32_T)velocityGrid->minSetSpeed * velocityGrid->gridUnit >= -ROUNDING_ERROR;
	reason |= valid ? debug_map_valid : debug_map_inv_speedLimit;
	
	*reasonFlags |= reason;
	*isOk = reason == debug_map_valid ? true : false;

	return true;
}


bool_T		sysIsRoadDataOk(		IN const	vehicleInput_T		*vehicleInput,
									IN const	vehicleState_T		*vehicleState,
									IN const	pathRouterMemory_T	*pathRouterMemory,
									INOUT		uint8_T				*reasonFlags,
									OUT			bool_T				*isOk)
{
	real32_T vehiclePosition;
	prtStreetClassValues_T streetClass;
	uint8_T countryCode, reason;
	bool_T valid;
	
	reason = debug_map_valid;
	vobsGetPosition(vehicleState, &vehiclePosition);

	/*L�ndercode*/
	countryCode = prtGetCountryCode(pathRouterMemory);
	valid = sysIsCountryOk(countryCode, vehicleInput->driver.ignoreCountry);
	reason |= valid ? debug_map_valid : debug_map_inv_countryCode;

	/*Stra�enklasse*/
	valid = prtGetStreetClassAtPosition(pathRouterMemory, vehiclePosition, &streetClass);
	reason |= valid ? debug_map_valid : debug_map_inv_prtMemory;

	valid =		prtStreetClassMisc != streetClass
			&&	prtStreetClassInit != streetClass; 
	reason |= valid ? debug_map_valid : debug_map_inv_streetClass;

	*reasonFlags |= reason;
	*isOk = reason == debug_map_valid ? true : false;

	return true;
}


bool_T		sysIsStrategyValid(		IN const    vehicleInput_T		*vehicleInput,
									IN const	vehicleState_T		*vehicleState,
									IN const	longControlStatus_T	 status,
									INOUT		uint8_T				*reasonFlags,
									OUT			bool_T				*isValid)
{
	bool_T vobsValid;
	vobsIsValid(vehicleState, &vobsValid);

	if (status.valid  &&  vobsValid && vehicleInput->driver.maxAutoSpeed != INVALID_VALUE)
	{
		*reasonFlags |= debug_map_valid;
		*isValid = true;
	} else {
		*reasonFlags |= debug_map_inv_strategy;
		*isValid = false;
	}

	return true;
}


bool_T		sysIsOverride(			IN const	vehicleInput_T		*vehicleInput,
									OUT			bool_T				*isOverride)
{
	*isOverride = vehicleInput->acc.accStatus == accStatusOverride;

	return true;
}


bool_T		sysIsBrakeOnlyMode(		IN const	vehicleInput_T		*vehicleInput,
									OUT			bool_T				*isBOM)
{
	*isBOM = vehicleInput->acc.accStatus == accStatusBrakeOnly;
	return true;
}


bool_T		sysIsAccError(			IN const	vehicleInput_T		*vehicleInput,
									INOUT		uint8_T				*reasonFlags,
									OUT			bool_T				*isAccError)
{
	if (vehicleInput->acc.accStatus == accStatusErrorReversible) 
	{
		*reasonFlags |= debug_acc_inv_reversible;
		*isAccError = true;
	} 
	else if (vehicleInput->acc.accStatus == accStatusErrorIrreversible) 
	{
		*reasonFlags |= debug_acc_inv_irreversible;
		*isAccError = true;		
	}	
	else
	{
		*reasonFlags |= debug_map_valid;
		*isAccError = false;
	}
	return true;
}


bool_T		sysIsAccActive(			IN const	vehicleInput_T		*vehicleInput,
									OUT			bool_T				*isActive)
{

	if (	vehicleInput->acc.accStatus == accStatusActive
		||  vehicleInput->acc.accStatus == accStatusOverride)
	{
		*isActive = true;
	} else {
		*isActive = false;
	}

	return true;
}


void	sysSetDisplayError(			IN const	sysStatus_T			 status,
									IN const	uint8_T				 reason,
									IN const	bool_T				 isAccInBom,
									OUT			sysDisplayError_T	*error)
{
	if (status == sysStatusNotAvailable)
	{
		if		(0u != (reason & debug_acc_inv_irreversible))	{ *error = sysErrorAccIrreversible;	}
		else if (0u != (reason & debug_acc_inv_reversible ))	{ *error = sysErrorAccReversible;	}
		else if (0u != (reason & debug_map_inv_prtMemory  ))	{ *error = sysErrorMapData;			}
		else if (0u != (reason & debug_map_inv_countryCode))	{ *error = sysErrorCountryCode;		}
		else if (0u != (reason & debug_map_inv_roadInfo   ))	{ *error = sysErrorRoadInfo;		}
		else if (0u != (reason & debug_map_inv_streetClass))	{ *error = sysErrorStreetClass;		}
		else if (0u != (reason & debug_map_inv_speedLimit ))	{ *error = sysErrorSpeedLimit;		}
		else if ( isAccInBom )									{ *error = sysErrorAccInBom;		}
		else if (0u != (reason & debug_map_inv_strategy   ))	{ *error = sysErrorStrategy;		}
		else													{ *error = sysErrorNone;			}
	} else {
		*error = sysErrorNone;
	}
}


void diagPrintMapInvalidReason(		IN const	uint8_T				reason)
{
	if (0u != (reason & debug_map_inv_prtMemory  )) { diagReportInfo(diagInfo_sysReasonMapMemory); }
	if (0u != (reason & debug_map_inv_roadInfo   )) { diagReportInfo(diagInfo_sysReasonRoadInfo); }
	if (0u != (reason & debug_map_inv_speedLimit )) { diagReportInfo(diagInfo_sysReasonSpeedLimit); }
	if (0u != (reason & debug_map_inv_countryCode)) { diagReportInfo(diagInfo_sysReasonCountryCode); }
	if (0u != (reason & debug_map_inv_streetClass)) { diagReportInfo(diagInfo_sysReasonStreetClass); }
	if (0u != (reason & debug_map_inv_strategy   )) { diagReportInfo(diagInfo_sysReasonStrategy); }
	if (0u != (reason & debug_acc_inv_reversible )) { diagReportInfo(diagInfo_sysReasonACCerrorReversible); }
	if (0u != (reason & debug_acc_inv_irreversible)){ diagReportInfo(diagInfo_sysReasonACCerrorIrreversible); }
}
