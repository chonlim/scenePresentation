#ifndef guard_sysVelocityGrid_h
#define guard_sysVelocityGrid_h

#include "control/systemController/sysSetSpeed.h"

/** \brief Initialisiert das Geschwindigkeitsraste mit L�nderabh�ngigen Grenzen und Schrittweiten.

\spec SW_AS_Innodrive2_130
\spec SW_AS_Innodrive2_131
\spec SW_AS_Innodrive2_133
\spec SW_AS_Innodrive2_540
\ingroup systemController_setSpeed
*/
bool_T	sysInitVelocityGrid(IN const	vehicleInput_T			*vehicleInput,		/**<Signaleingang*/
							IN const	vehicleState_T			*vehicleState,		/**<Gefilterte Eingangssignale (vMax)*/
							OUT			velocityGrid_T			*velocityGrid		/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
							);



/** \brief Begrenzt und rundet die Geschwindigkeit `setSpeed`.

Begrenzt auf den Bereich zwischen `grid.minSetSpeed` und `grid->maxSetSpeed`.
Rundet auf Vielfache von grid->unit.

R�ckgabewert ist der begrenzte und gerundete Geschwindigkeitswert in [ms/s].

\spec SW_AS_Innodrive2_131
\spec SW_AS_Innodrive2_133

\ingroup systemController_setSpeed
*/
bool_T		sysSaturateSetSpeed(	IN const		velocityGrid_T			*grid,				/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
									IN const		real32_T				 setSpeed,			/**<Geschwindigkeit*/
									OUT				real32_T				*saturated			/**<Begrenzte und gerundete Geschwindigkeit*/
									);

#endif
