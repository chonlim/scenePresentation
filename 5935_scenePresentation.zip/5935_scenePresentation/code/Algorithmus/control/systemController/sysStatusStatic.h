#ifndef guard_sysStatusStatic_h
#define guard_sysStatusStatic_h

#include "control/systemController/systemController.h"
#include "control/systemController/sysSetSpeedTypes.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "control/parameterSet/parameterSetCtrl.h"


/** \brief Aktualisiert den Aktivierungszustand gem�� den �bergebenen Vorbedingungen `is...`.

\spec SW_AS_Innodrive2_81  (globaler �bergang nach `sysStatusDisabled`)
\spec SW_AS_Innodrive2_82  (sysStatusDisabled -> sysStatusNotAvailable)
\spec SW_AS_Innodrive2_100 (sysStatusNotAvailable -> sysStatusAvailable)
\spec SW_AS_Innodrive2_90  (sysStatusAvailable -> sysStatusNotAvailable)
\spec SW_AS_Innodrive2_89  (sysStatusAvailable -> sysStatusActive)
\spec SW_AS_Innodrive2_110 (sysStatusNotAvailable -> sysStatusAvailable)
\spec SW_AS_Innodrive2_114 (sysStatusBrakeOnlyMode -> sysStatusAvailable)
\spec SW_AS_Innodrive2_211 (sysStatusAvailable -> sysStatusNotAvailable)
\spec SW_AS_Innodrive2_103 (Reihenfolge)
\spec SW_AS_Innodrive2_105 (sysStatusActive -> sysStatusAvailable)
\spec SW_AS_Innodrive2_109 (sysStatusActive -> sysStatusOverride)
\spec SW_AS_Innodrive2_107 (sysStatusActive -> sysStatusBrakeOnlyMode)

\ingroup systemController_status
*/
static bool_T	sysSwitchStatus(INOUT		sysStatus_T				*sysStatus,			/**<Aktivierungszustand*/
								IN	const	systemStatus_T			*systemStatus,		/**<Systemzustand (inkl. Aktivierungszustand)*/
								IN	const	bool_T					 isSystemEnabled,	/**<Vom Fahrer aktiviert*/
								IN	const	bool_T					 isAvailable,		/**<Funktion Aufgrund Umgebungsdaten Verf�gbar*/
								IN	const	bool_T					 isAccActive,		/**<Acc vom Fahrer aktiviert*/
								IN	const	bool_T					 isBrakeOnlyMode,	/**<Abschaltreaktion ACC*/
								IN	const	bool_T					 isEnterBOM,		/**<Abschaltbedingung Innodrive*/
								IN	const	bool_T					 isExitBOM,			/**<Abschaltreaktion Innodrive beendet*/
								IN	const	uint8_T					 mapInvalidReason,	/**<Grund f�r Nichtverf�gbarkeit*/
								OUT			bool_T					*isNewActivation	/**<Wurde der Zustand Active neu angenommen?*/
								);

/** \brief Aktualisiert den Status der Fahrer-Aktivierung.

In der Variable `activationStatus` wird die Fahrer-Aktivierung entprellt gespeichert. 
Wenn eines der Signale "driverInputList.resume.status" oder "diverInputList.set.status" den Wert `sysNewPressed` annimmt,
nimmt der `activationStatus.status` den Wert `true` an und h�lt diesen Wert f�r eine parametrierbare Anzahl von Rechentakten.
Solange der `activationStatus.status == true` ist, zeigt die Variable `lastAcvnAction` an, ob mit Set oder Resume aktiviert wurde.

Die letztendliche Aktivierungsbedingung ist die Aktivierung der Funktion "ACC" (\ref sysIsAccActive()). Diese kann einige Takte nach 
der Fahrer-Bedienhandlung erfolgen. Wechselt der ACC-Zustand auf Aktiv oder Passiv, kann mit den R�ckabewerten der Funktion \ref sysUpdateAcvnStatus()
gepr�ft werden, ob und welche Fahrer-Bedienhandlung erfolgt ist.

\spec SW_AS_Innodrive2_89
\spec SwMS_Innodrive2_Control_55 (Deaktivierung der Teilfunktion bei aktivem Staupilot)

\ingroup systemController_status
*/
static bool_T	sysUpdateAcvnStatus(IN const	vehicleInput_T			*vehicleInput,		/**<Signaleingang*/
									IN const	sysJamPilotStatus_T		*jamPilot,			/**<Status Staupilot*/
									IN const	bool_T					 setSpeedValid,		/**<Es liegt eine g�ltige Setzgeschwindigkeit vor*/
									INOUT		boolDebounce_T			*activationStatus,	/**<Entprellter Zustand: Systemaktivierung*/
									INOUT		sysActivation_T			*lastAcvnAction		/**<Zeigt an, ob mit Set oder Resume aktiviert wurde*/
									);


/** \brief Entprellt die Karten-Stati, mit der Funktion \ref sysHoldTrue().

Jeder Eingang wird in dem Filter `debounced` entprellt gespeichert.
Wenn ein Eingang falsch ist und der entsprechende Entprell-Z�hler den Wert 0 erreicht,
genau dann nimmt der ausgegebene `mapStatus` den Wert `false` an.

\spec SW_AS_Innodrive2_78			(Systemzustand)
\spec SW_AS_Innodrive2_530 Entwurf	(Kartendaten)
\spec SW_AS_Innodrive2_110			(Override)
\spec SW_AS_Innodrive2_559			(Strategie)

\ingroup systemController_status
*/
static bool_T	sysUpdateMapStatus(	IN const	bool_T					 isMapDataValid,	/**<Unentprellt Kartendaten generell g�ltig*/
									IN const	bool_T					 isRoadDataOk,		/**<Unentprellt Stra�enkalsse und Land freigegeben*/
									IN const	bool_T					 isSpeedLimitOk,	/**<Unentprellt Tempolimit vorhanden und gro� genug*/
									IN const	bool_T					 isStrategyValid,	/**<Unentprellt G�ltige Planungstrajektorie vorhanden*/
									INOUT		sysMapStatus_T			*debounced,			/**<Entprellte Karten-Stati*/
									OUT			bool_T					*status				/**<Wahr, wenn alle entprellten Karten-Stati g�ltig sind.*/
									);


/** \brief Gibt den Wahrheitswert von isBool zeitlich entprellt zur�ck.

Wenn	das Signal `inStatus` f�r `debounced.debounceMaxCount` Rechenzyklen ununterbrochen den Wert `false` annimmt,
genau dann muss die Funktion sysHoldTrue das Signal `debounced.status` auf `false` setzen.

\spec SW_AS_Innodrive2_530 Entwurf	(Kartendaten)
\spec SW_AS_Innodrive2_110			(Override)

\ingroup systemController_status
*/
static bool_T		sysHoldTrue(IN const	bool_T				 inStatus,				/**<Eingangsstatus*/
								INOUT		boolDebounce_T		*debounced				/**<Entprellter Status*/
								);


/** \brief Initialisiert den Systemzustand und die Entprellz�hler

\ingroup systemController_status
*/
static void	sysInit_boolDebounce_T(	OUT	boolDebounce_T *boolDebounce	/**<Entprellter Status*/
									);
#endif
