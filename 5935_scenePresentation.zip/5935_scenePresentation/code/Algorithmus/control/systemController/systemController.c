#include "control/parameterSet/parameterSetCtrl.h"

#include "control/parameterSet/parameterSetCtrl.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "common/systemControllerCommon/systemController_private.h"

#include "control/inputCodec/inputCodec_private.h"


#include "control/systemController/systemController.h"
#include "control/systemController/systemControllerStatic.h"
#include "common/systemControllerCommon/sysInfo.h"

#include "control/systemController/sysDriverInput.h"
#include "control/systemController/sysJamPilot.h"
#include "control/systemController/sysStatus.h"
#include "control/systemController/sysSetSpeed.h"
#include "control/systemController/sysOutput.h"
#include "control/systemController/sysStop.h"

#include <string.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_systemController)


void			systemController(	IN	const	vehicleInput_T			*vehicleInput,
									IN	const	vehicleState_T			*vehicleState,
									IN	const	pathRouterMemory_T		*pathRouterMemory,
									IN	const	roadModelInfo_T			*roadModelInfo,
									IN	const	longControlStatus_T		*longControlStatus,
									INOUT		systemControlMemory_T	*memory,
									OUT			systemControl_T			*systemControl,
									OUT			fodOutput_T				*fodOutput)
{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();
	
	/* Initialisierung Datenstrukturen systemController */
	if(!memory->init) {
		sysInit(memory, systemControl);
	}

	if(!sysStep(vehicleInput,
				vehicleState,
				pathRouterMemory,
				roadModelInfo,
				longControlStatus,
				memory,
				systemControl)) {
		sysInit(memory, systemControl);
		memory->errorTicks = parameterSet->systemController.errorTicks;
	}

	sysFodOutput(vehicleInput,
				 fodOutput);

	systemControl->errorTicks = memory->errorTicks;
}

static void				sysInit(OUT			systemControlMemory_T	*memory,
								OUT			systemControl_T			*systemControl)
{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();
	sysInit_systemControllerMemory_T(memory);
	memset(systemControl, 0, sizeof(systemControl_T));
	sysInitDriverInputList(parameterSet, &memory->setSpeedControl.driverInputs);
	sysInitSystemStatus(parameterSet, &memory->systemStatus);
	memory->init = true;
}
	
	
static bool_T	sysStep(			IN	const	vehicleInput_T			*vehicleInput,
									IN	const	vehicleState_T			*vehicleState,
									IN	const	pathRouterMemory_T		*pathRouterMemory,
									IN	const	roadModelInfo_T			*roadModelInfo,
									IN	const	longControlStatus_T		*longControlStatus,
									INOUT		systemControlMemory_T	*memory,
									OUT			systemControl_T			*systemControl)
{
	velocityGrid_T velocityGrid;

	bool_T			isNewActivation;
	sysStopType_T	stopInRange;
	bool_T			stopTakeover, stopCanceled;
	real32_T		stopSweepPosition;

	bool_T			setSpeedValid;

	limitInfo_T		limitInfo;

	if (memory->errorTicks > 0u)
	{
		memory->errorTicks--;
	}

	/*Vorbereiten des L�nderabh�ngigen Geschwindgkeitsrasters*/
	diagFF(sysInitVelocityGrid( vehicleInput, 
							    vehicleState, 
							   &velocityGrid));

	/*Auswerten Systemzustand*/
	sysIsSetSpeedValid(&memory->setSpeedControl,
					   &setSpeedValid);

	sysJamUpdateStatus( vehicleInput,
					   &memory->systemStatus.jamPilot);

	diagFF(sysEvalSystemStatus( vehicleInput, 
							    vehicleState,
							    pathRouterMemory, 
							    roadModelInfo, 
							    longControlStatus,
								&velocityGrid,
								setSpeedValid,
							   &memory->systemStatus, 
							   &systemControl->displayError,
							   &isNewActivation));

	
	/* Auswerten Resume und Set (auch Longpressed-Funktionen)*/
	diagFF(sysEvalResumeSet( vehicleInput,
							&memory->systemStatus.jamPilot,
							 memory->systemStatus.status,
							 isNewActivation, 
							&memory->setSpeedControl.driverInputs));


	/* Bedienung und Anzeige Stoppstellen */
	diagFF(sysUpdateStop(&memory->stopFilter,
						  vehicleState,
						  roadModelInfo,
						  longControlStatus,
						  memory->setSpeedControl.driverInputs.resume.status,
						  memory->systemStatus.status,
						  isNewActivation,
						 &stopInRange,
						 &stopTakeover,
						 &stopSweepPosition,
						 &stopCanceled));

	/*Resume zus�tzlich Abbrechen, wenn eine Stoppstelle vom Fahrer best�tigt wurde
	oder wenn das Stillstand erkannt wird.*/
	diagFF(sysCancelResume( vehicleInput,
							vehicleState,
							stopCanceled,
						   &memory->setSpeedControl.driverInputs));

	/*Auswerten Setzgeschwindigkeit*/
	diagFF(sysUpdateSetSpeedControl( vehicleInput,
									 vehicleState,
									 pathRouterMemory,
									 roadModelInfo,
									 longControlStatus,
									&memory->systemStatus,
									&velocityGrid,
									 isNewActivation,
									(stopInRange != sysStopNone),
									&memory->setSpeedControl,
									&limitInfo));


	/*Ausgabestruktur schreiben*/
	diagFF(sysOutput(	&memory->speedCheckFilter,
						&memory->overrideReturnFilter,
						vehicleInput,
						vehicleState, 
						memory->systemStatus.status,
						&memory->setSpeedControl, 
						&velocityGrid,
						 stopInRange,
						 stopTakeover,
						 stopSweepPosition,
						 &limitInfo,
						 isNewActivation,
						&memory->setSpeedFilter, 
						systemControl));

	return true;
}

static void	sysInit_systemControllerMemory_T(OUT		systemControlMemory_T	*memory)
{
	memset(memory, 0, sizeof(systemControlMemory_T));

	sysInit_systemStatus_T(&memory->systemStatus);
	sysInit_driverInputList_T(&memory->setSpeedControl.driverInputs);
}


static void				  sysIsSetSpeedValid(IN	const	setSpeedControl_T		*setSpeedControl,
											 OUT		bool_T					*setSpeedValid)
{		
			*setSpeedValid = (setSpeedControl->permanentMode.currentSetSpeed > 0.0f);
}
