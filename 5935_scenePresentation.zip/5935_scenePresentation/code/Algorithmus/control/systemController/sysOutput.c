#include "control/systemController/sysOutput.h"
#include "control/systemController/sysOutputStatic.h"
#include "control/systemController/sysSpeedCheck.h"
#include "control/systemController/sysOverrideReturn.h"
#include "control/systemController/sysSimplifiedMode.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "control/inputCodec/inputCodec_private.h"
#include <math.h> /*lint -esym(9045, struct _exception)*/

#include <Rte_Type.h>
#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysOutput)


bool_T						  sysOutput(INOUT		speedCheckFilter_T		*speedCheckFilter,
										INOUT		overrideReturnFilter_T	*overrideReturnFilter,
										IN	const	vehicleInput_T			*vehicleInput,
										IN	const	vehicleState_T			*vehicleState,
										IN	const	sysStatus_T				 status,		
										IN	const	setSpeedControl_T		*setSpeedControl,
										IN	const	velocityGrid_T			*velocityGrid,
										IN	const	sysStopType_T			 stopInRange,
										IN	const	bool_T					 stopTakeover,
										IN	const	real32_T				 stopSweepPosition,
										IN  const	limitInfo_T				*limitInfo,
										IN	const	bool_T					 isNewActivation,
										INOUT		setSpeedFilter_T		*setSpeedFilter,
										OUT			systemControl_T			*systemControl)
{
	real32_T	toleranceFactor;
	bool_T		setDisplayValid;
	bool_T		dsplLimitEventsActive;
	
	speedInfo_T egoSpeed = {0.0f, 0.0f, 0u};
	speedInfo_T currentSetSpeed = {0.0f, 0.0f, 0u};
	speedInfo_T nextSetSpeed = {0.0f, 0.0f, 0u};

	const parameterSetCtrl_T *parameterSet	= prmGetParameterSetCtrl();
	const bool_T isActivated				= (status == sysStatusActive)  ||  (status == sysStatusOverride);
	const bool_T isActiveOrAvailable		= isActivated || (status == sysStatusAvailable);

	vobsGetPosition(vehicleState, &egoSpeed.position);
	vobsGetUnfilteredState(vehicleState, NULL, &egoSpeed.value, NULL, NULL, NULL);

	/*Aktuelle und n�chste Setzgeschwindigkeit abh�ngig vom gew�hlten Status und vom Aktivierungszustand*/
	diagFF(sysSetSpeedPermanent( setSpeedControl,
							    &egoSpeed,
							    isActivated,
							    &currentSetSpeed,
							    &nextSetSpeed,
							    &setDisplayValid,
							    &dsplLimitEventsActive));

	
	/*In jedem Fall ist die anzuzeigende Setzgeschwindigkeit bei nicht verf�gbarem System "---"*/
	setDisplayValid = isActiveOrAvailable ? setDisplayValid : false;

	/* Nochmal Saturieren */	
	diagFF(sysSaturateSetSpeed(velocityGrid, currentSetSpeed.value, &currentSetSpeed.value));
	diagFF(sysSaturateSetSpeed(velocityGrid, nextSetSpeed.value, &nextSetSpeed.value));
	
	diagFF(sysFilterSetSpeed(&currentSetSpeed, &egoSpeed, setSpeedFilter));


	/* Setzgeschwindigkeits�berwachung */
	diagFF(sysSpeedCheck( speedCheckFilter,
						  status == sysStatusActive,
						  currentSetSpeed.value,
						  egoSpeed.value,
						 &toleranceFactor));


	/* Flag f�r verlangsamte rueckkehr nach Override */
	diagFF(sysUpdateOverrideReturn( overrideReturnFilter,
									status,
									egoSpeed.value,
									currentSetSpeed.value));

	/*Ausgabe Systemstatus*/
	systemControl->status			= status;
	systemControl->isAutoModeActive	= setSpeedControl->isAutoModeActive;
	systemControl->distIndex = vehicleInput->driver.followingGap;

	switch(vehicleInput->driver.charisma)
	{
		case charismaNormal	: systemControl->mode = sysModeNormal ; break;
		case charismaDynamic: systemControl->mode = sysModeDynamic; break;
		case charismaEconomy: systemControl->mode = sysModeEconomy; break;
		default: diagFUnreachable();
	}/*lint !e9077*/

	/*Ausgabe FoD-Status*/
	if (vehicleInput->driver.fodActivation) {
		systemControl->fodStatus = sysFodStatusActive;
	}
	else {
		if (vehicleInput->driver.fodInitialized) {
			systemControl->fodStatus = sysFodStatusNotActive;
		} 
		else {
			systemControl->fodStatus = sysFodStatusInit;
		}
	}

	/*Ausgabe Setzgeschwindigkeit*/
	systemControl->previousSetSpeed	= setSpeedFilter->previousSetSpeed;
	systemControl->currentSetSpeed	= setSpeedFilter->currentSetSpeed;
	systemControl->nextSetSpeed		= nextSetSpeed;

	systemControl->setDisplayValid		 = setDisplayValid;
	systemControl->dsplLimitEventsActive = dsplLimitEventsActive;

	/*Ausgabe Toleranzfaktor*/
	systemControl->toleranceFactor	= toleranceFactor;

	/*Ausgabe Vorausschauposition*/
	systemControl->previewPosition	= setSpeedControl->limits.previewPosition;

	/*Ausgabe Vorausschau-Speed Limit*/
	systemControl->previewLimit		= setSpeedControl->limits.nextLimit.valid ? setSpeedControl->limits.nextLimit.raw : (uint16_T)rawLimitInvalid;
	systemControl->previewLock		= setSpeedControl->limits.previewLock;

	/* Ausgabe Stoppstellen-Funktion */
	systemControl->stopInRange			= stopInRange;
	systemControl->stopTakeover			= stopTakeover;
	systemControl->stopSweepPosition	= stopSweepPosition;

	/* Ausgabe Override*/
	systemControl->overrideReturn		= overrideReturnFilter->overrideReturn;

	/* Ausgabe von nicht erfolgreicher Aktivierung*/
	systemControl->unsuccessfulActivation = ((systemControl->status == sysStatusNotAvailable) && (vehicleInput->driver.resume || vehicleInput->driver.set));

	/* Ausgabe ob Geschwindigkeitshinweis angezeigt werden darf */
	if (    (isNewActivation || limitInfo->isCurrentLimitChange)
		 && (egoSpeed.value > systemControl->currentSetSpeed.value + parameterSet->systemController.velocityControl.hintSetDelta)
	   )	   
	{
		setSpeedFilter->showHint = true;
	}

	if ((setSpeedFilter->showHint) && (egoSpeed.value < systemControl->currentSetSpeed.value + parameterSet->systemController.velocityControl.hintResetDelta))
	{
		setSpeedFilter->showHint = false;
	}
		
	systemControl->showHint = setSpeedFilter->showHint;

	return true;
}


static bool_T	sysSetSpeedPermanent(	IN const	setSpeedControl_T		*setSpeedControl,
										IN const	speedInfo_T				*egoSpeed,
										IN const	bool_T					 isActivated,
										OUT			speedInfo_T				*currentSetSpeed,
										OUT			speedInfo_T				*nextSetSpeed,
										OUT			bool_T					*displayValid,
										OUT			bool_T					*dsplLimitEventsActive)
{
	real32_T driverOffset;
	bool_T dsplLimitsIfActivated, zeroDriverOffset;

	/*Aktuelle Setzgeschwindigkeit*/
	currentSetSpeed->value		= setSpeedControl->permanentMode.currentSetSpeed;
	currentSetSpeed->position	= egoSpeed->position;

	/*Durch den Fahrer "getippter" Offset (nicht permanenter Offset)*/
	driverOffset = setSpeedControl->permanentMode.nextSetSpeed - setSpeedControl->limits.nextLimit.value;
	zeroDriverOffset = (fabsf(driverOffset) < ROUNDING_ERROR) ? true : false;
	
	/*Zuk�nftige Setzgeschwindigkeit und Event-Anzeige*/
	if (setSpeedControl->limits.nextLimit.valid) 
	{
		nextSetSpeed->value			= setSpeedControl->permanentMode.nextSetSpeed;
		nextSetSpeed->position		= max(setSpeedControl->limits.nextLimit.position, egoSpeed->position);
		dsplLimitsIfActivated		= zeroDriverOffset;
	} else {
		nextSetSpeed->value			= -INVALID_VALUE;
		nextSetSpeed->position		= -INVALID_VALUE;
		dsplLimitsIfActivated		= true;
	}
	
	if (isActivated)
	{
		/*Setzgeschwindkgeit immer Anzeigen, Limit-Events eventuell ausgrauen.*/
		*displayValid = true;
		diagFF(currentSetSpeed->value > 0.0f);
		*dsplLimitEventsActive = dsplLimitsIfActivated;
	} else {
		/*Nur bekannte Setzgeschwindigkeiten anzeigen, Events immer ausgrauen.*/
		*displayValid = (currentSetSpeed->value > 0.0f) ? true : false;
		nextSetSpeed->position = min(nextSetSpeed->position, egoSpeed->position);
		*dsplLimitEventsActive = false;
	}

	return true;
}


static bool_T	sysFilterSetSpeed(		IN const	speedInfo_T				*currentSetSpeed,
										IN const	speedInfo_T				*egoSpeed,
										INOUT		setSpeedFilter_T		*setSpeedFilter)
{
	/*Vergangene Setzgeschwindigkeit bei �nderung der aktuellen Setzgeschwindigkeit neu setzen*/
	const real32_T deltaCurrentSetSpeed = currentSetSpeed->value - setSpeedFilter->currentSetSpeed.value;
	if (fabsf(deltaCurrentSetSpeed) > ROUNDING_ERROR)
	{
		setSpeedFilter->previousSetSpeed			= setSpeedFilter->currentSetSpeed;
		setSpeedFilter->currentSetSpeed.value		= currentSetSpeed->value;
		setSpeedFilter->currentSetSpeed.position	= egoSpeed->position;
	} else {
		/*Unver�ndert.*/
		setSpeedFilter->previousSetSpeed			= setSpeedFilter->previousSetSpeed;
		setSpeedFilter->currentSetSpeed.value		= setSpeedFilter->currentSetSpeed.value;
		setSpeedFilter->currentSetSpeed.position	= setSpeedFilter->currentSetSpeed.position;
	}
	/*
	Der constraintMaster l�scht Limits, die an der selben position liegen.
	Daher previousSetSpeed um maximal 10cm zur�ckverlegen.
	Die Situation tritt auf, wenn im Stillstand eine Neue Setzgeschwindigkeit erkannt wird (Bsp. Ampel).
	*/
	setSpeedFilter->previousSetSpeed.position	= min(setSpeedFilter->previousSetSpeed.position, setSpeedFilter->currentSetSpeed.position - 0.1f);

	return true;
}



void					   sysFodOutput(IN	const	vehicleInput_T			*vehicleInput,
										OUT			fodOutput_T				*fodOutput)
{
	fodOutput->dataValidFlag = true;
	
	if (	vehicleInput->acc.accStatus == accStatusErrorIrreversible
		||	vehicleInput->acc.accStatus == accStatusErrorReversible) 
	{
		fodOutput->DeFoDReadyToRun = FOD_RTR_NOT_READY;
	} else {
		fodOutput->DeFoDReadyToRun = FOD_RTR_READY;
	}
}
