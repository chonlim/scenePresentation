#ifndef guard_sysSimplifiedModeStatic_h
#define guard_sysSimplifiedModeStatic_h

#include "control/systemController/sysSetSpeed.h"
#include "common/systemControllerCommon/systemController_private.h"


/**\brief Zur�cksetzen der aktuellen und zuk�nftigen Setzgeschwindigkeit

\spec SW_AS_Innodrive2_688	(Zur�cksetzen bei sysStatusDisabled)
\spec SW_AS_Innodrive2_721  (Zur�cksetzen im manuellen Modus)

\ingroup systemController_setSpeed
*/
static bool_T				sysSomReset(IN	const	sysStatus_T				 status,				/**<Aktivierungsstaus des Systems Innodrive2*/
										IN	const	bool_T					 isAutoModeActive,		/**<Automatische �bernahme gesetzlicher Tempolimits aktiviert*/
										INOUT		lastSetSpeed_T			*lastSetSpeed,			/**<Gespeicherte Setzgeschwindigkeit*/
										INOUT		real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		real32_T				*nextSetSpeed,			/**<Zuk�nftige Setzgeschwindigkeit*/
										INOUT		bool_T					*autoNextLimit,			/**<N�chstes Tempolimit automatisch �bernehmen?*/
										INOUT		bool_T					*setSpeedManipulated	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										); 


/**\brief Setzgeschwindigkeiten bei Systemaktivierung setzen.

\spec SW_AS_Innodrive2_697	(Aktivierung mit Set: aktuelle Setzgeschwindigkeit auf Anzeigegeschwindigkeit)
\spec SW_AS_Innodrive2_698	(Aktivierung mit Set: zuk�nftige Setzgeschwindigkeit auf Anzeigegeschwindigkeit)
\spec SW_AS_Innodrive2_720	(Beibehalten der Setzgeschwindigkeiten bei Aktivierung mit Resume)
\spec SW_AS_Innodrive2_684	(Saturierung)

\ingroup systemController_setSpeed
*/
static bool_T			 sysSomActivate(IN	const	sysActivation_T			 lastAcvnAction,		/**<Aktivierungsstaus des Systems Innodrive2*/
										IN	const	velocityGrid_T			*velocityGrid,			/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	sysControlLimits_T		*limits,				/**<aktuelles und n�chstes Tempolimit*/
										IN	const	real32_T				 displayVelocity,		/**<Anzeigegeschwindigkeit im Kombi-Display*/
										OUT			real32_T				*lastSetSpeed,			/**<Gespeicherte Setzgeschwindigkeit*/
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										OUT			bool_T					*autoNextLimit,			/**<N�chstes Tempolimit automatisch �bernehmen?*/
										OUT			bool_T					*doSaveCurrent,			/**<Muss die aktuelle Setzgeschwindigkeit als letzte Setzgeschwindigkeit gespeichert werden?*/
										INOUT		real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		real32_T				*nextSetSpeed			/**<Zuk�nftige Setzgeschwindigkeit*/
										);			


/**\brief Auswertung der Bedienaktion Resume, wen KEIN zuk�nftiges Tempolimit erkannt wird.

\spec SW_AS_Innodrive2_704 (Resume im manuellen Modus ohne zuk�nftiges Limit)

\ingroup systemController_setSpeed
*/
static bool_T	  sysSomResumeOnCurrent(IN	const	driverInputStatus_T		 resume,				/**<Zustand der Fahrerbedienaktion Resume*/
										IN	const	real32_T				 currentSL,				/**<Aktuelles Tempolimit*/
										IN	const	bool_T					 isStopInRange,			/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										INOUT		real32_T				*currentSetSpeed		/**<Aktuelle Setzgeschwindigkeit*/
										);


/**\brief Auswertung der Bedienaktion Resume wenn ein zuk�nftiges Tempolimit erkannt wird.

\spec SW_AS_Innodrive2_709 (Resume im manuellen Modus mit zuk�nftigem Limit)

\ingroup systemController_setSpeed
*/
static bool_T		 sysSomResumeOnNext(IN	const	driverInputStatus_T		 resume,				/**<Zustand der Fahrerbedienaktion Resume*/
										IN	const	real32_T				 nextSL,				/**<Zuk�nftiges Tempolimit*/
										IN	const	bool_T					 isStopInRange,			/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										INOUT		real32_T				*nextSetSpeed			/**<Zuk�nftige Setzgeschwindigkeit*/
										);


/**\brief

Aktuelle Setzgeschwindigkeit bei �nderung des aktuellen Tempolimits abspeichern und im automatischen Modus anpassen
\spec SW_AS_Innodrive2_699
\spec SW_AS_Innodrive2_691

Zuk�nftige Setzgeschwindigkeit bei �nderung des zuk�nftigen Tempolimits auf anpassen.
\spec SW_AS_Innodrive2_695 (im manuellen Modus auf aktuelle Setzgeschwindigkeit setzen)
\spec SW_AS_Innodrive2_694 (im automatischen Modus auf das zuk�nftige SpeedLimit setzen)

Bei Vorbeifahrt an einem Tempolimit aktuelle Setzgeschwindigkeit speichern und
Zuk�nftige Setzgeschwindigkeiten als aktuelle Setzgeschwindigkeit �bernehmen.
\spec SW_AS_Innodrive2_692

Bei Wegfall eines zuk�nftigen Tempolimits zuk�nftige Setzgeschwindigkeit verwerfen.
\spec SW_AS_Innodrive2_693

Saturierung
\spec SW_AS_Innodrive2_684

\ingroup systemController_setSpeed
*/
static bool_T		  sysSomAdoptLimits(IN	const	sysControlLimits_T		*limits,				/**<aktuelles und n�chstes Tempolimit*/
										IN	const	velocityGrid_T			*velocityGrid,			/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	limitInfo_T				*limitInfo,				/**<Lokale Informationen zum aktuellen Tempolimitsatz*/
										IN	const	real32_T				 currentSL,			    /**<Aktuelles Tempolimit*/
										IN	const	real32_T				 nextSL,				/**<Zuk�nftiges Tempolimit*/
										IN	const	bool_T					 isAutoModeActive,		/**<Automatische �bernahme gesetzlicher Tempolimits aktiviert*/
										OUT			bool_T					*autoNextLimit,			/**<N�chstes Tempolimit automatisch �bernehmen?*/
										INOUT		real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		real32_T				*nextSetSpeed,			/**<Zuk�nftige Setzgeschwindigkeit*/
										INOUT		bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										INOUT		bool_T					*doSaveCurrent			/**<Muss die aktuelle Setzgeschwindigkeit als letzte Setzgeschwindigkeit gespeichert werden?*/
										);


/**\brief Verwirft die aktuelle automatisch �bernommene Setzgeschwindigkeit.

\spec SW_AS_Innodrive2_706

\ingroup systemController_setSpeed
*/
static bool_T	   sysSomDiscardCurrent(IN	const	driverInputStatus_T		 resume,				/**<Zustand der Fahrerbedienaktion Resume*/
										IN	const	bool_T					 isStopInRange,			/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										OUT			real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		real32_T				*lastSetSpeed			/**<Gespeicherte Setzgeschwindigkeit*/
										);


/**\brief Verwirft die zuk�nftige automatisch �bernommene Setzgeschwindigkeit.

\spec SW_AS_Innodrive2_712

\ingroup systemController_setSpeed
*/
static bool_T		  sysSomDiscardNext(IN	const	driverInputStatus_T		 resume,				/**<Zustand der Fahrerbedienaktion Resume*/
										IN	const	bool_T					 isStopInRange,			/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										IN  const	real32_T				 currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										INOUT		bool_T					*autoNextLimit,			/**<N�chstes Tempolimit automatisch �bernehmen?*/
										OUT			real32_T				*nextSetSpeed			/**<Zuk�nftige Setzgeschwindigkeit*/
										);


/**\brief �bernimmt aktuelles Tempolimit im automatischen Modus.

\spec SW_AS_Innodrive2_707

\ingroup systemController_setSpeed
*/
static bool_T	   sysSomConfirmCurrent(IN	const	driverInputStatus_T		 resume,				/**<Zustand der Fahrerbedienaktion Resume*/
										IN	const	real32_T				 currentLimit,			/**<Aktuelles Tempolimit*/
										IN	const	bool_T					 isStopInRange,			/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										OUT			real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										OUT			lastSetSpeed_T			*lastSetSpeed			/**<Gespeicherte Setzgeschwindigkeit*/
										);


/**\brief �bernimmt zuk�nftiges Tempolimit im automatischen Modus.

\spec SW_AS_Innodrive2_713

\ingroup systemController_setSpeed
*/
static bool_T		  sysSomConfirmNext(IN	const	driverInputStatus_T		 resume,				/**<Zustand der Fahrerbedienaktion Resume*/
										IN	const	real32_T				 nextLimit,				/**<Zuk�nftiges Tempolimit*/
										IN	const	bool_T					 isStopInRange,			/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										OUT			bool_T					*autoNextLimit,			/**<N�chstes Tempolimit automatisch �bernehmen?*/
										OUT			real32_T				*nextSetSpeed			/**<Zuk�nftige Setzgeschwindigkeit*/
										);


/**\brief Erh�ht oder erniedrigt die Setzgeschwindigkeit `inSpeed` um die Schrittweite `step`.

\spec SW_AS_Innodrive2_700 (Aktuelle Setzgeschwindigkeit)
\spec SW_AS_Innodrive2_701 (Zuk�nftige Setzgeschwindigkeit)

Saturierung
\spec SW_AS_Innodrive2_684

\ingroup systemController_setSpeed
*/
static bool_T		  sysSomOverrideSet(IN	const	velocityGrid_T			*velocityGrid,			/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	driverInputStatus_T		 set,					/**<Zustand der Fahrerbedienaktion Set*/
										IN	const	real32_T				 displayVelocity,		/**<Anzeigegeschwindigkeit im Kombi-Display*/
										IN	const	bool_T					 nextLimitValid,		/**<G�ltigkeit des zuk�nftigen Tempolimits*/
										INOUT		real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		real32_T				*nextSetSpeed,			/**<Zuk�nftige Setzgeschwindigkeit*/
										INOUT		bool_T					*setSpeedManipulated	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										);


/**\brief Setzt im Fall Override+Set die aktuelle und zuk�nftige Setzegschwindigkeit auf die Anzeigegeschwindigkeit

\spec SW_AS_Innodrive2_702

Saturierung
\spec SW_AS_Innodrive2_684

\ingroup systemController_setSpeed
*/
static bool_T		   sysSomTipActions(IN	const	velocityGrid_T			*grid,					/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	driverInputStatus_T		 tipUp,					/**<Zustand der Fahrerbedienaktion "Tip Hoch"*/
										IN	const	driverInputStatus_T		 tipDown,				/**<Zustand der Fahrerbedienaktion "Tip Runter"*/
										IN	const	bool_T					 nextLimitValid,		/**<Wurde ein zuk�nftiges Tempolimit erkannt?*/
										OUT			real32_T				*lastSetSpeed,			/**<Gespeicherte Setzgeschwindigkeit*/
										OUT			bool_T					*setSpeedManipulated,	/**<Wird gesetzt, wenn die Setzgeschwindigkeit ver�ndert wird.*/
										OUT			bool_T					*autoNextLimit,			/**<N�chstes Tempolimit automatisch �bernehmen?*/
										INOUT		real32_T				*currentSetSpeed,		/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		real32_T				*nextSetSpeed			/**<Zuk�nftige Setzgeschwindigkeit*/
										);

/**\brief H�lt f�r eine aplizierbare Anzahl Rechentakte nach einem Trigger die aktuelle Setzgeschwindigkeit im speicher.

Wenn der Trigger `doSaveCurrent` wahr ist, wird der `lastCycleSetSpeed` als `bufferedSetSpeed` gehalten und der `counter`
auf einen applizierbaren Wert gesetzt.
Wenn der counter auf Null zur�ck gez�hlt worden ist, wird der `bufferedSetSpeed` verworfen.
Der `lastCycleSetSpeed` wird in jedem Takt auf den `currentSetSpeed`aktualisiert.

\spec SW_AS_Innodrive2_689

\ingroup systemController_setSpeed
*/
static bool_T     sysSomUpdateLastSetSpeed(IN	const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
										   IN	const	bool_T					 doSaveCurrent,		/**<Triggert den Filter.*/
										   IN	const	real32_T				 lastCycleSetSpeed, /**<Setzgeschwindigkeit vom Ende des letzten und Anfang des aktuellen Taktes*/
										   INOUT		lastSetSpeed_T			*buffer				/**<Puffer zur Wiederherstellung der letzten Setzgeschwindigkeit*/
										   );


/**\brief Setzt im Fall Override+Set die aktuelle und zuk�nftige Setzegschwindigkeit auf die Anzeigegeschwindigkeit

\spec SW_AS_Innodrive2_179
\spec SW_AS_Innodrive2_180
\spec SW_AS_Innodrive2_181
\spec SW_AS_Innodrive2_525
\spec SW_AS_Innodrive2_182
\spec SW_AS_Innodrive2_183
\spec SW_AS_Innodrive2_184
\spec SW_AS_Innodrive2_526

\ingroup systemController_setSpeed
*/
static bool_T				  sysSomTip(IN	const	velocityGrid_T			*grid,				/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	uint8_T					 step,				/**<Betrag der Schrittweite*/
										IN	const	bool_T					 up,				/**<Richtung des Schritts (true: aufw�rts, false: abw�rts)*/
										IN	const	real32_T				 inSpeed,			/**<Setzgeschwindigkeit in m/s*/
										OUT			real32_T				*outSpeed			/**<Angepasste und saturierte Setzgeschwindigkeit in m/s*/
										);

/**\brief Bei Fahrpedal�berdr�ckung kann das n�chste Limit vorgezogen werden

Die Aktuelle Setzgeschwindigkeit wird dann auf den Wert des zuk�nftigen Tempolimits.
Die Aktuelle Setzgeschwindigkeit wird zur sp�teren Wiederherstellung durch einen Resume-Doppelklick gespeichert.

\spec SW_AS_Innodrive2_715
\spec SwMS_Innodrive2_Control_55 (Deaktivierung der Teilfunktion bei aktivem Staupilot)

\ingroup systemController_setSpeed
*/
static bool_T	sysSomOverrideLimitPull(IN	const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
										IN	const	sysJamPilotStatus_T		*jamPilot,			/**<Staupilot-Status*/
										IN	const	real32_T				 nextSetSpeed,		/**<Zuk�nftige Setzgeschwindigkeit*/
										IN	const	bool_T					 isAutoModeActive,	/**<Auswertung gesetzlicher Tempolimits aktiv*/
										INOUT		real32_T				*currentSetSpeed,	/**<Aktuelle Setzgeschwindigkeit*/
										INOUT		bool_T					*doSaveCurrent		/**<Trigger f�r den bufferLastSetSpeed*/
										);

/**\brief Bei Fahrpedal�berdr�ckung kann das n�chste Limit ignoriert werden

Die Zuk�nftige Setzgeschwindigkeit wird dann auf den Wert der aktuellen Setzgeschwindigkeit gesetzt.

\spec SW_AS_Innodrive2_716
\spec SwMS_Innodrive2_Control_55 (Deaktivierung der Teilfunktion bei aktivem Staupilot)

\ingroup systemController_setSpeed
*/
static bool_T	sysSomOverrideLimitDrop(IN	const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
										IN	const	sysJamPilotStatus_T		*jamPilot,			/**<Staupilot-Status*/
										IN	const	real32_T				 currentSetSpeed,	/**<Aktuelle Setzgeschwindigkeit*/
										IN	const	bool_T					 isAutoModeActive,	/**<Auswertung gesetzlicher Tempolimits aktiv*/
										INOUT		real32_T				*nextSetSpeed		/**<Zuk�nfitge Setzgeschwindigkeit*/
										);

#endif
