#include "control/systemController/systemController.h"
#include "control/systemController/sysSpeedCheck.h"

#include "common/systemControllerCommon/systemController_private.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysSpeedCheck)


bool_T		  sysSpeedCheck(MEMORY		speedCheckFilter_T	*filter,
							IN	const	bool_T				 systemActive,
							IN	const	real32_T			 setSpeed,
							IN	const	real32_T			 velocity,
							OUT			real32_T			*toleranceFactor)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	uint16_T maxTarget;
	uint16_T target;
	real32_T rampDownFactor;

	maxTarget = paramSet->systemController.speedCheck.toleranceTicks + paramSet->systemController.speedCheck.rampTicks;

	if(   !systemActive
	   || !paramSet->systemController.speedCheck.enabled
	   || velocity < setSpeed - paramSet->systemController.speedCheck.velocityHyst) {
		target = 0;
	}
	else if (velocity > setSpeed) {
		target = maxTarget;
	}
	else {
		target = filter->overSpeedTicks;
	}

	if(filter->overSpeedTicks < target) { filter->overSpeedTicks++; }
	if(filter->overSpeedTicks > target) { filter->overSpeedTicks--; }

	diagFF(paramSet->systemController.speedCheck.rampTicks > 0u);

	if(filter->overSpeedTicks >= paramSet->systemController.speedCheck.toleranceTicks) {
		uint16_T ticks = filter->overSpeedTicks - paramSet->systemController.speedCheck.toleranceTicks;
		rampDownFactor = (real32_T)ticks / (real32_T)(paramSet->systemController.speedCheck.rampTicks);
	}
	else {
		rampDownFactor = 0.0f;
	}

	rampDownFactor = min(rampDownFactor, 1.0f);
	rampDownFactor = max(rampDownFactor, 0.0f);

	*toleranceFactor = 1.0f - rampDownFactor;

	return true;
}
