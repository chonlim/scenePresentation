#ifndef guard_sysStatus_h
#define guard_sysStatus_h

#include "control/systemController/systemController.h"
#include "control/systemController/sysSetSpeedTypes.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "control/parameterSet/parameterSetCtrl.h"


/** \brief Initialisiert die Struktur `systemStatus_T` mit geeigneten Standard Werten

\ingroup systemController_status
*/
void	sysInit_systemStatus_T(	OUT	systemStatus_T	*systemStatus	/**<Aktivierungsszustand des Systems Innodrive2*/
								);


/** \brief Initialisiert den Systemzustand und die Entprellz�hler

\spec SW_AS_Innodrive2_78			(Systemzustand)
\spec SW_AS_Innodrive2_530 Entwurf	(Kartendaten)
\spec SW_AS_Innodrive2_110			(Override)
\spec SW_AS_Innodrive2_559			(Strategie)

\ingroup systemController_status
*/
void		sysInitSystemStatus(IN const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
								OUT			systemStatus_T			*systemStatus		/**<Aktivierungsszustand des Systems Innodrive2*/
								);
								

/** \brief Aktualisiert den Systemzustand des Systems Innodrive2.

Der Wert `systemStatus.status` muss abh�ngig von seinem Eingangswerten die �berg�nge aus den folgenden Anforderungen annehmen:
Zur Auswertung der Vorbedingungen m�ssen dabei die Funktionen des Untermoduls \ref systemController_preconditions verwendet werden.

Nach einem �bergang in den Zustand `sysStatusAbailable` muss im gleichen Rechentakt der �bergang in den Zustand `sysStatusNotAvailable`
nach SW_AS_Innodrive2_90 gepr�ft und durchgef�hrt werden.

Die Flag `isNewActivation gibt an, ober der Zustand `sysStatusActive` neu angenommen wurde.

\spec SW_AS_Innodrive2_81  (globaler �bergang nach `sysStatusDisabled`)
\spec SW_AS_Innodrive2_82  (sysStatusDisabled -> sysStatusNotAvailable)
\spec SW_AS_Innodrive2_100 (sysStatusNotAvailable -> sysStatusAvailable)
\spec SW_AS_Innodrive2_90  (sysStatusAvailable -> sysStatusNotAvailable)
\spec SW_AS_Innodrive2_89  (sysStatusAvailable -> sysStatusActive)
\spec SW_AS_Innodrive2_110 (sysStatusNotAvailable -> sysStatusAvailable)
\spec SW_AS_Innodrive2_114 (sysStatusBrakeOnlyMode -> sysStatusAvailable)
\spec SW_AS_Innodrive2_211 (sysStatusAvailable -> sysStatusNotAvailable)
\spec SW_AS_Innodrive2_103 (Reihenfolge)
\spec SW_AS_Innodrive2_105 (sysStatusActive -> sysStatusAvailable)
\spec SW_AS_Innodrive2_109 (sysStatusActive -> sysStatusOverride)
\spec SW_AS_Innodrive2_107 (sysStatusActive -> sysStatusBrakeOnlyMode)

\ingroup systemController_status
*/
bool_T		sysEvalSystemStatus(IN const	vehicleInput_T			*vehicleInput,		/**<Signaleingang*/
								IN const	vehicleState_T			*vehicleState,		/**<Fahrzeugzustand*/
								IN const	pathRouterMemory_T		*pathRouterMemory,	/**<Linearisierte Kartendaten*/
								IN const	roadModelInfo_T			*roadModelInfo,		/**<Information zu Tempolimits aus dem roadProcessor*/
								IN const	longControlStatus_T		*longControlStatus,	/**<Status der Regelstrategie*/
								IN const	velocityGrid_T			*velocityGrid,		/**<Raster zur Geschwindigkeitsverstellung abh�ngig von Tachoeinheit (kph/mph)*/
								IN const	bool_T					 setSpeedValid,     /**<Es liegt eine g�ltige Setzgeschwindigkeit vor*/
								INOUT		systemStatus_T			*systemStatus,		/**<Aktivierungsszustand des Systems Innodrive2*/
								OUT			sysDisplayError_T		*displayError,		/**<Grund f�r die Nichtaktivierbarkeit des Systems Innodrive 2*/
								OUT			bool_T					*isNewActivation	/**<Wurde der Zustand Active neu angenommen?*/
								);

#endif
