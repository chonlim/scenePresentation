#ifndef guard_SysDriverInput_h
#define guard_SysDriverInput_h

#include "control/systemController/systemController.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "control/systemController/sysSetSpeedTypes.h"
#include "control/parameterSet/parameterSetCtrl.h"



/** \brief Zustandsautomat. Aktualisiert den Zustand eines Bedienelements.

Die Funktion sysEvalDriverInput muss einem Bedienelement `driverInput.status` kann abh�ngig vom Argument `isPressed` folgende Zust�nde zuweisen:
 - sysNotPressed:	Nicht bet�tigt oder Abbruch-Flag `doCancel` gesetzt.
 - sysNewPressed:	Bet�tigt, wenn im vorigen Rechentakt nicht bet�tigt
 - sysPressed:		Bet�tigt ab dem zweiten Rechentakt
 - sysLongPressed:	Eine parametrierte Anzahl `longPressCycleCount` von Rechentakten gehalten
 - sysReleased:		Losgelasssen, nach sysNewPressed oder sysPressed
 - syHeld:			gehalten, nach sysLongPressed

Die Stati sysNewPressed, sysRekleased und sysLongPressed d�rfen jeweils nur einen Rechentakt lang angemonnen werden.
Die Anzahl der Zyklen zur Erkennung eines gehaltenen Bedienelements kann getrennt f�r die erste (`longPressCycleCount.initial`)
und alle weiteren (`longPressCycleCount.periodic`) Annahmen des Zustands `sysLongPressed` parametriert werden.

\spec SW_AS_Innodrive2_593 (Zustandsautomat)
\spec SW_AS_Innodrive2_638 (f�r tipUp, tipDown, Resume, Set)
\spec SW_AS_Innodrive2_520 (Abbruchbedingung)
\spec SwMS_Innodrive2_Control_55 (Deaktivierung der Teilfunktion bei aktivem Staupilot)

\ingroup systemController_input
*/
static bool_T	sysEvalDriverInput(	IN const	longPressCycleCount_T		*longPressCount,	/**<Anzahl der Zyklen zur Erkennung eines gehaltenen Bedienelements*/
									IN const	sysJamPilotStatus_T			*jamPilot,			/**<Staupilot-Zustand*/
									IN const	bool_T						 isActive,			/**<Ist die Auswertung des driverInput-Elements aktiviert?*/
									IN const	bool_T						 isPressed,			/**<Aktueller Zustand des Bedienelements*/
									IN const	bool_T						 doCancel,			/**<Abbruch der Longpressed-Funktion*/
									INOUT		sysDriverInput_T			*driverInput		/**<Entprellter Zustand des Bedienelements*/
									);

/**\brief Bricht die bedienhandlung Resume ab.

Wenn die Anzeigegeschwindigkeit klein ist, wird Stillstand angenommen und die Bedienhandlung Resume abgebrochen.
Wenn eine Stopstelle vom Fahrer aufgehoben wurde, wird die Bedienhandlung Resume ebenfalls abgebrochen.

\spec SW_AS_Innodrive2_677 (Resume abbrechen)
\ingroup systemController_input
*/
bool_T			sysCancelResume(	IN const	vehicleInput_T			*input,
									IN const	vehicleState_T			*vehicleState,
									IN const	bool_T					 stopCanceled,
									INOUT		driverInputList_T		*list
									);

/** \brief Aktualisiert die Bedienhandlungen `resume` und `set`.

Die Funktion sysEvalResumeSet muss die Werte `list.cancel.status`, `list.resume.status`, `list.set.status`
mittels der Funktion \ref sysEvalDriverInput() aktualisieren.

\spec SW_AS_Innodrive2_638 (f�r Resume, Set)
\spec SW_AS_Innodrive2_677 (Resume abbrechen)
\ingroup systemController_input
*/
bool_T			sysEvalResumeSet(	IN const	vehicleInput_T				*input,				/**<Eingangssignale vom Fahrzeugbus*/
									IN const	sysJamPilotStatus_T			*jamPilot,			/**<Staupilot-Zustand*/
									IN const	sysStatus_T					 sysStatus,			/**<Aktivierungsstatus des Systems Innodrive2*/
									IN const	bool_T						 isNewActivation,	/**<In diesem Takt neu aktiviert*/
									INOUT		driverInputList_T			*list				/**<Liste Entprellter Bedienaktionen des Fahrers*/
									);


/** \brief Aktualisiert die Bedienhandlungen `tipUp` und `tipDown`

Wenn die Abbruchbedingung `doCancel`den Wert TRUE annimmt, muss die Funktion sysEvalTipActions die Werte
`list.tipUp.status` und `list.tipDown.status` auf `sysNotPressed` setzen.
Sonst muss die Funktion die Werte mittels der Funktion \ref sysEvalDriverInput() aktualisieren.


\spec SW_AS_Innodrive2_638 (f�r tipUp, tipDown)
\spec SW_AS_Innodrive2_520 (Abbruchbedingung)
\ingroup systemController_input
*/
bool_T		sysEvalTipActions(		IN const	vehicleInput_T				*input,				/**<Eingangssignale vom Fahrzeugbus*/	
									IN const	sysJamPilotStatus_T			*jamPilot,			/**<Staupilot-Zustand*/
									IN const	limitInfo_T					*limitInfo,			/**<tempor�rer Informationen zum aktuellen Tempolimitsatz*/
									IN const	sysStatus_T					 sysStatus,			/**<Aktivierungsstatus des Systems Innodrive2*/
									IN const	bool_T						 isAutoModeChange,	/**<Wechsel der Modus Auto/Manuell*/
									INOUT		driverInputList_T			*list				/**<Liste Entprellter Bedienaktionen des Fahrers*/
									);


/**\brief Initialisiert alle Bedienelement-Zust�nde

Die Funktion sysInitDriverInputList muss alle Fahrerbedienaktionen im Argument `list` auf den Wert `sysNotPressed` intialisieren.
Die Funktion sysInitDriverInputList muss die Entrpellz�hler so initialisieren, dass sie nach Ablauf der parameterierbaren Zeitspannen
`parameterSet.systemController.longPressTime` bei Dekrementierung um Eins in jedem Rechentakt den Wert Null erreichen.

\spec SW_AS_Innodrive2_593 (Zustandsautomat)
\spec SW_AS_Innodrive2_638 (f�r tipUp, tipDown, Resume, Set)
\ingroup systemController_input
*/		
void		sysInitDriverInputList(	IN const	parameterSetCtrl_T			*parameterSet,		/**<Globaler Parametersatz*/
									OUT			driverInputList_T			*list				/**<Liste mit Entprellten Bedienelement-Zust�nden*/
									);


/**\brief Initialisiert die Struktur driverInputList_T mit geeigneten Standard Werten.

\ingroup systemController_input
*/
void	sysInit_driverInputList_T(	OUT	driverInputList_T	*list		/**<Liste mit Entprellten Bedienelement-Zust�nden*/
									);

#endif
