#ifndef guard_sysSetSpeedStatic_h
#define guard_sysSetSpeedStatic_h

#include "control/systemController/systemController.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "control/systemController/sysSetSpeedTypes.h"


/** \brief Aktualisiert den Modus der Setzgeschwindigkeitsverstellung
\spec SW_AS_Innodrive2_520
\ingroup systemController_setSpeed
*/
static bool_T		sysUpdateMode(	IN	const	vehicleInput_T			*vehicleInput,		/**<Signaleingang*/
									INOUT		bool_T					*isAutoModeActive,	/**<Automatische �bernahme der Tempolimits aktiv*/
									OUT			bool_T					*isAutoModeChange	/**<Wechsel des Modus Automatische �bernahme der Tempolimits*/
									);

#endif
