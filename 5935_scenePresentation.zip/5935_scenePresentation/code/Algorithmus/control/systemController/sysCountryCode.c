#include "control/systemController/sysCountryCode.h"
#include "control/parameterSet/parameterSetCtrl.h"

bool_T			sysIsCountryOk(		IN const	uint8_T				countryCode,
									IN const	bool_T				ignore)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	bool_T	found;
	uint8_T index;

	found = false;

	for(index = 0; index < (uint8_T)prmNUMCOUNTRYLIST; index++) {
		/* Wenn der L�ndercode dem aktuellen Eintrag der Liste entspricht und wir die Anzahl g�ltiger Eintr�ge nicht
		   �berschritten haben, haben wir unser Land gefunden */
		if(   (paramSet->systemController.countryList.list[index] == countryCode)
		   && (index < paramSet->systemController.countryList.count)) {
			found = true;
		}
	}

	found = ignore ? true : found;

	return found;
}
