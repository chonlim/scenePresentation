#ifndef guard_SysSetSpeedTypes_h
#define guard_SysSetSpeedTypes_h

#include "control/systemController/systemController.h"


typedef struct limitInfo_tag {				
	bool_T		isCurrentLimitChange;		/**<Wahr, wenn sich der Wert des aktuellen Tempolimits �ndert [m]*/
	bool_T		isNextLimitChange;			/**<Wahr, wenn sich der Wert des n�chsten Tempolimits �ndert*/
	bool_T		isNewLimitPassed;			/**<Wahr, wenn sich der Wert des aktuellen Tempolimits auf den bisherigen Wert des n�chsten Tempolimits �ndert.*/
} limitInfo_T;								/**< Lokale Informationen zum aktuellen Tempolimitsatz*/

typedef struct _velocityGrid {
	real32_T maxAutoSpeed;			/**< Maximale automatisch eingestellte Setzgeschwindigkeit (h�ufig: Freifahrtgeschwindigkeit) [m/s]*/
	real32_T gridUnit;						/**< Abh�ngig von der Tachoeinheit ist die Rastereinheit 1 kmh oder 1 mph[m/s] */
	uint8_T smallIncrement;					/**< Schrittweite auf dem Raster[gridUnit] */
	uint8_T bigIncrement;					/**< Schrittweite auf dem Raster[gridUnit] */
	uint16_T minSetSpeed;					/**< Untergrenze auf dem Raster[gridUnit] */
	uint16_T maxSetSpeed;					/**< Obergrenze auf dem Raster[gridUnit] */
} velocityGrid_T;							/**< Raster zur Geschwindigkeitsverstellung abh�ngig von Tachoeinheit (kph/mph)*/


#endif
