#ifndef guard_systemControllerStatic_h
#define guard_systemControllerStatic_h

#include "control/control.h"
#include "common/systemControllerCommon/systemController_interface.h"

/**\brief Initialisiert die Struktur systemControllerMemory_T mit geeigneten Standard Werten.

\ingroup systemController_step
*/
static void	sysInit_systemControllerMemory_T(OUT	systemControlMemory_T	*memory		/**< Interner Status des SystemController */
											 );
	
/**\brief Gibt es eine g�ltige Setzgeschwindigkeit, mit der mit Resume aktiviert werden kann?

\spec SW_AS_Innodrive2_89

\ingroup systemController_step
*/										 
static void				  sysIsSetSpeedValid(IN	const	setSpeedControl_T		*setSpeedControl,
											 OUT		bool_T					*setSpeedValid
											 );


/**\brief Initialisiert den Aktivierungszustand und die Setzgeschwindigkeit des Systems Innodrive2

\ingroup systemController_step
*/
static void			sysInit(		OUT			systemControlMemory_T	*memory,				/**< Interner Status des SystemController */
									OUT			systemControl_T			*systemControl			/**< Statusr�ckmeldung der L�ngsregelung */
									);


/**\brief Aktualisiert den Aktivierungszustand und die Setzgeschwindigkeit des Systems Innodrive2

Es werden nacheinander folgende Aktionen durchgef�hrt.
- Aktualisieren der Fahrer-Bedienaktionen Resume(Wiederaufnahme), Cancel(Abbruch), Set(Setzen). \ref sysEvalResumeSet()
- Auswerten des Systemstatus \ref sysEvalSystemStatus()
- Aktualisieren der Daten der Setzgeschwindigkeitskontroller \ref sysUpdateSetSpeedControl().
	inklusive Aktualisierung der Tempolimits und Auswetung der Fahrer-Bedienaktionen TipUp(Tip Hoch) und TipDown (Tip Runter).
	Grund f�r die Reihenfolge: Die Auswertung des Systemstatus ben�tigt die Bedienaktionen Cancel, Resume, Set.
	Die Bedienaktionen TipUp, TipDown k�nnen durch ein 
- Bef�llen der Ausgabe-Schnittstelle \ref systemControl_T in \ref sysOutput()
	Dabei wird auch bei aktivierbarem, aber inaktivem System eine aktuelle, vergangene und zuk�nftige Setzgeschwindigkeit ausgegeben,
	da diese vom constraintMaster zur Vorausplanung ben�tigt werden.

\ingroup systemController_step
*/
static bool_T			sysStep(	IN	const	vehicleInput_T			*vehicleInput,			/**< Datenstruktur vehicleInput(hier: Fahrereingriffe driverInput, lateralControl.driverInput, velocityInfo) */
									IN	const	vehicleState_T			*vehicleState,			/**< Datenstruktur des Moduls vehicleObserver */
									IN	const	pathRouterMemory_T		*pathRouterMemory,		/**< Linearisierte Kartendaten */
									IN	const	roadModelInfo_T			*roadModelInfo,			/**< Struktur mit kurzem Horizont der Karteninformationen(PSD-Steigung, Kurvenkr�mmung, Tempolimits) */
									IN	const	longControlStatus_T		*longControlStatus,		/**< Statusr�ckmeldung der L�ngsregelung */
									INOUT		systemControlMemory_T	*memory,				/**< Interner Status des SystemController */
									OUT			systemControl_T			*systemControl			/**< Fl�chtige Ausgangsdaten des SystemController */
									);

#endif
