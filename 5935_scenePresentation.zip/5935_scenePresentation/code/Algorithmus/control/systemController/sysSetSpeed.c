#include "control/systemController/sysSetSpeed.h"
#include "control/systemController/sysSetSpeedStatic.h"
#include "control/systemController/sysDriverInput.h"
#include "control/systemController/sysSpeedLimit.h"
#include "control/systemController/sysSimplifiedMode.h"
#include "control/inputCodec/inputCodec_private.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysSetSpeed)


bool_T	   sysUpdateSetSpeedControl(IN	const	vehicleInput_T			*vehicleInput,
									IN	const	vehicleState_T			*vehicleState,
									IN	const	pathRouterMemory_T		*pathRouterMemory,
									IN	const	roadModelInfo_T			*roadModelInfo,
									IN	const	longControlStatus_T		*longControlStatus,
									IN	const	systemStatus_T			*systemStatus,
									IN	const	velocityGrid_T			*velocityGrid,
									IN	const	bool_T					 isNewActivation,
									IN	const	bool_T					 stopInRange,
									INOUT		setSpeedControl_T		*setSpeedControl,
									OUT			limitInfo_T				*limitInfo)
{
	bool_T	isAutoModeChange;
	real32_T displayVelocity = 0.0f;
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();
	
	vobsGetUnfilteredState( vehicleState, 
						    NULL, 
						   &displayVelocity, 
						    NULL,
							NULL, 
							NULL);

	/*Aktualisieren der Tempolimits*/
	diagFF(sysUpdateSpeedLimits( pathRouterMemory,
								 roadModelInfo,
								 longControlStatus,
								 systemStatus,
								 velocityGrid,
								 vehicleState,
								 vehicleInput,
								&setSpeedControl->limits,
								 limitInfo));

	/*Aktualisieren des Modus (Auto/Manuell)*/
	diagFF(sysUpdateMode( vehicleInput, 
						 &setSpeedControl->isAutoModeActive, 
						 &isAutoModeChange));
	
	/*Auswerten DriverInputs (auch Longpressed-Funktionen)*/
	diagFF(sysEvalTipActions( vehicleInput,
							 &systemStatus->jamPilot,
							  limitInfo,
							  systemStatus->status, 
							  isAutoModeChange, 
							 &setSpeedControl->driverInputs));

	/*Aktualisieren der Setzgeschwindigkeit*/
	diagFF(sysUpdateSimplifiedMode( parameterSet,
								    systemStatus,
								    velocityGrid,
								   &setSpeedControl->driverInputs,
								   &setSpeedControl->limits,
								    limitInfo,
								    displayVelocity,
								    isNewActivation,
								    stopInRange,
								    setSpeedControl->isAutoModeActive,
								   &setSpeedControl->permanentMode));
		
	return true;
}


static bool_T	sysUpdateMode(		IN const	vehicleInput_T			*vehicleInput,
									INOUT		bool_T					*isAutoModeActive,
									OUT			bool_T					*isAutoModeChange)
{
	bool_T oldAutoMode = *isAutoModeActive;
	*isAutoModeActive = vehicleInput->driver.autoMode;
	*isAutoModeChange = (oldAutoMode == *isAutoModeActive) ? false : true; /*lint !e697 Quasi-boolean values should be equality-compared only with 0 */

	return true;
}


/** \brief Erkennt den Stillstand des Fahrzeugs

\spec SW_AS_Innodrive2_186
Wenn die Fahrzeuggeschwindigkeit kleiner als der Parameter `parameterSet.systemController.velocityControl.tresholdStandStill ist,
dann muss die Funktion sysVelocityStandStill die Variable `velocity` auf den Wert 0.0f setzen.

\ingroup systemController_setspeed
*/
bool_T	sysIsStandstill(			IN const	parameterSetCtrl_T		*parameterSet,
									IN const	real32_T				 velocity,
									OUT			bool_T					*isStandStill)
{
	*isStandStill = velocity < parameterSet->systemController.velocityControl.thresholdStandStill ? true : false;

	return true;
}


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "sysDebug.h"

ICC_API void dbg_sysGet_sysUpdateMode(sysUpdateModeCB *sysUpdateModePointer)
{
	*sysUpdateModePointer = sysUpdateMode;
}
#endif
