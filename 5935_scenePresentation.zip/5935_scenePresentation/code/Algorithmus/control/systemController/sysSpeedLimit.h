#ifndef guard_sysSpeedLimit_h
#define guard_sysSpeedLimit_h

#include "control/systemController/sysSetSpeed.h"


/** \brief Holt bei abh�ngig vom Systemstatus das aktuelle und n�chste Tempolimit von der roadModelInfo.

Die Limits werden in den Unterfunktionen \ref sysUpdateCurrentLimit() und \ref sysUpdateNextLimit() aktualisiert.

Wenn sich der Wert des aktuellen Limits �ndert, muss die Funktion die Flag `limitInfo.isCurrentLimitChange` auf WAHR setzen
Wenn sich der Wert des n�chsten  Limits �ndert, muss die Funktion die Flag `limitInfo.isCurrentLimitChange` auf WAHR setzen
Wenn sich der Wert des aktuellen Limits auf den Wert des n�chsten Limits �ndert (wenn das Fharzeug das Limit passiert), muss die Funktion die Flag `limitInfo.isNewLimitPassed` auf WAHR setzen

\spec SW_AS_Innodrive2_520

\ingroup \ingroup systemController_speedLimit
*/
bool_T			   sysUpdateSpeedLimits(IN	const	pathRouterMemory_T		*pathRouterMemory,		/**<Kartendaten vom pathRouter*/
										IN	const	roadModelInfo_T			*roadModelInfo,			/**<Information zu Tempolimits aus dem roadProcessor*/
										IN	const	longControlStatus_T		*longControlStatus,		/**<Statusr�ckmeldung von der L�ngsregelung */
										IN	const	systemStatus_T			*systemStatus,			/**<Systemzustand des Systems Innodrive2*/
										IN	const	velocityGrid_T			*velocityGrid,			/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	vehicleState_T			*vehicleState,			/**<Daten des vehicleObserver*/
										IN	const	vehicleInput_T			*vehicleInput,			/**<Signaleingang*/
										INOUT		sysControlLimits_T		*speedLimits,			/**<Letztes, aktuelles und n�chstes Tempolimit*/
										OUT			limitInfo_T				*tmpSpeedLimitInfo		/**<tempor�rer Informationen zum aktuellen Tempolimitsatz*/
										);


#endif
