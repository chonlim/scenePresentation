#ifndef guard_sysSpeedLimitStatic_h
#define guard_sysSpeedLimitStatic_h

#include "control/systemController/sysSetSpeed.h"

/** \brief Aktualisiert das aktuelle Tempolimit

Wenn das Argument `status` NICHT den Wert `sysStatusNotAvailable` oder `sysStatusDiabled` annimmt,
UND das Argument `mapStatus` den Wert WAHR annimmt,
muss die Funktion sysUpdateCurrentLimit das aktuelle Tempolimit �bernehmen.

Wenn das Argument `status` den Wert `sysStatusNotAvailable` oder `sysStatusDisabled` annimmt
UND das Argument `mapStatus` den Wert FALSCH annimmt,
muss die Funktion sysUpdateCurrentLimit das aktuelle Tempolimit inklusive Position auf 0.0f setzen.

Sonst muss das gespeicherte aktuelle Tempolimit beibehalten werden.

Nur wenn das aktuelle Limit �bernommen wird, muss die Funktion sysUpdateCurrentLimit 
die Position des aktuellen Tempolimits auf die aktuelle Fahrzeugposition vom vehicleObserver setzen.

\spec SW_AS_Innodrive2_134
\spec SW_AS_Innodrive2_140

\ingroup \ingroup systemController_speedLimit
*/
static bool_T	  sysUpdateCurrentLimit(IN	const	roadModelInfo_T			*roadModelInfo,			/**<Information zu Tempolimits aus dem roadProcessor*/	
										IN	const	bool_T					 actualMapStatus,		/**<G�ltigkeitszustand der Kartendaten*/
										IN	const	bool_T					 mapDataValid,			/**<Aktivierungsszustand des Systems Innodrive2*/
										IN	const	sysStatus_T				 status,				/**<Entprellter G�ltigkeitszustand der Kartendaten*/
										IN	const	velocityGrid_T			*grid,					/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										INOUT		limitItem_T				*currentLimit			/**<Aktuell g�ltiges Tempolimit*/
										);


/** \brief Aktualisiert das n�chste Tempolimit

Wenn das Argument `status` den Wert `sysStatusActive` oder `sysStatusOverride` annimmt,
UND das Argument `mapStatus` den Wert WAHR annimmt,
UND die FUnktion \ref sysRoadInfoGetNextLimit() ein g�ltiges Tempolimit zur�ckgibt, dass in der Zeit `previewHorizonMaxTime` erreicht wird,
dann muss die Funktion sysUpdateNextLimit das n�chste Tempolimit `nextLimit` inklusive Position �bernehmen.

Wenn das Argument `status` NICHT den Wert `sysStatusActive` oder `sysStatusOverride` annimmt,
UND das Argument `mapStatus` den Wert FALSCH annimmt,
UND die FUnktion \ref sysRoadInfoGetNextLimit() KEIN g�ltiges Tempolimit zur�ckgibt, dass in der Zeit `previewHorizonMaxTime * previewHorizonMaxTimeTolerance` erreicht wird,
dann muss die Funktion sysUpdateNextLimit das n�chste Tempolimit `nextLimit` inklusive Position auf 0.0f setzen.

Die Funktion sysUpdateNextLimit muss sicherstellen, dass eine g�ltige `nextLimit.Position` gr��er als die Fahrzeugposition ist.

\spec SW_AS_Innodrive2_138
\spec SW_AS_Innodrive2_139

\ingroup systemController_speedLimit
*/
static bool_T		 sysUpdateNextLimit(INOUT		limitItem_T				*nextLimit,				/**< Zuk�nftiges Tempolimit */
										INOUT		real32_T				*previewPosition,		/**< Aktuelle Vorausschauposition f�r kommende Geschwindigkeitslimits */
										INOUT		bool_T					*previewLock,			/**< Anforderung f�r das Zur�ckhalten von Voraausschauevents */
										IN	const	vehicleState_T			*vehicleState,			/**< Daten des vehicleObserver */
										IN	const	roadModelInfo_T			*roadModelInfo,			/**< Information zu Tempolimits aus dem roadProcessor */
										IN	const	longControlStatus_T		*longControlStatus,		/**< Statusr�ckmeldung von der L�ngsregelung */
										IN	const	velocityGrid_T			*grid,					/**< Geschwindigkeitsraster abh�ngig von der Einheit des Displays */
										IN	const	bool_T					 actualMapStatus,		/**< G�ltigkeitszustand der Kartendaten*/
										IN	const	bool_T					 mapDataValid,			/**< Entprellter G�ltigkeitszustand der Kartendaten*/
										IN	const	sysStatus_T				 status					/**< Aktivierungsszustand des Systems Innodrive2 */
										);

/**\brief Vergleicht zwei FLie�kommazahlen mit der Tolaranz ROUNDING_ERROR.
\ingroup systemController_speedLimit
*/
static bool_T		  sysFloatsAreEqual(IN	const	real32_T				 floatA,
										IN	const	real32_T				 floatB
										);


#endif
