#include "control/systemController/sysJamPilot.h"
#include "control/inputCodec/inputCodec_private.h"
#include "control/parameterSet/parameterSetCtrl.h"

void		 sysJamUpdateStatus(IN	const	vehicleInput_T		*vehicleInput,
								INOUT		sysJamPilotStatus_T	*jamPilotStatus)
{
	const parameterSetCtrl_T *param = prmGetParameterSetCtrl();
	bool_T active;

	switch (vehicleInput->driver.stpStatus)
	{
	case stpStatusActive: 
	case stpStatusActivation: 
	case stpStatusActiveEsc0: 
	case stpStatusActiveEsc1: 
	case stpStatusActiveEsc2: 
	case stpStatusActiveEsc3: 
	case stpStatusEmergencyOperation: 
	case stpStatusStable: 
		active = true;
		break;
	case stpStatusInit:
	case stpStatusInactive:
	case stpStatusNotAssigned2:
	case stpStatusNotAvailable:
	case stpStatusNotAssigned4:
	case stpStatusAvailable:
	case stpStatusActiveTakeover:
	case stpStatusError:
		active = false;
		break;
	default: 
		active = false; 
		break;
	}

	if (param->systemController.status.idleWhenSTPactive) 
	{
		jamPilotStatus->active = active;
	} else {
		jamPilotStatus->active = false;
	}
}


bool_T		sysJamPilotIsActive(IN	const	sysJamPilotStatus_T *jamPilotStatus)
{
	return jamPilotStatus->active;
}
