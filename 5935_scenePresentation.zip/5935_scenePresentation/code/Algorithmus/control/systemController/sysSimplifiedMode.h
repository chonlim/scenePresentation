#ifndef guard_sysSimplifiedMode_h
#define guard_sysSimplifiedMode_h

#include "control/systemController/sysSetSpeed.h"
#include "common/systemControllerCommon/systemController_private.h"

/**\brief Aktualisiert die n�chste, aktuelle und letze Setzgeschwindigkeit f�r den Modus "vereinfachter Offset".

Um �berlagerungseffekte zu vermeiden, werden die Unterfunktionen zu unterscheidlichen 
Fahrsituationen schon in dieser Funktion gegeneinander gesperrt.

Situationsabh�ngiger Aufruf folgender Unterfunktionen:
\ref sysSomReset()
\ref sysSomTip()
\ref sysSomUpdateLastSetSpeed()
\ref sysSomOverrideLimitPull()
\ref sysSomOverrideLimitDrop()

\ingroup systemController_setSpeed
*/
bool_T			sysUpdateSimplifiedMode(IN	const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
										IN	const	systemStatus_T			*systemStatus,		/**<Aktivierungsstaus des Systems Innodrive2*/
										IN	const	velocityGrid_T			*velocityGrid,		/**<Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	driverInputList_T		*driverInputs,		/**<Entprellte Bedienaktionen (inkl. longPressed)*/
										IN	const	sysControlLimits_T		*limits,			/**<aktuelles und n�chstes Tempolimit*/
										IN	const	limitInfo_T				*limitInfo,			/**<Lokale Informationen zum aktuellen Tempolimitsatz*/
										IN	const	real32_T				 displayVelocity,	/**<Anzeigegeschwindigkeit im Kombi-Display*/
										IN	const	bool_T					 isNewActivation,	/**<Wahr, wenn das System neu aktiviert (sysStatusActive / sysStatusOverride) wird*/
										IN	const	bool_T					 isStopInRange,		/**<Wird die Bedienhandlung "Resume" aktuell von der Stoppstellen-Funktion belegt? */
										IN	const	bool_T					 isAutoModeActive,	/**<Ist die automatische Tempolimit-�bernahme aktiviert?*/
										INOUT		permanentMode_T			*permanentMode		/**<Setzgeschwindigkeiten f�r den permanenten Offset-Modus*/
										);

#endif
