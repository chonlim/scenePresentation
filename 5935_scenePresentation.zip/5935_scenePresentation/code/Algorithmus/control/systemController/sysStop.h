#ifndef guard_sysStop_h
#define guard_sysStop_h


/**\brief Aktualisierung der Position, bis zu der Stoppstellen vom Regler unber�cksichtigt bleiben.
\spec SW_AS_Innodrive2_677
*\ingroup systemController_stop*/
bool_T		  sysUpdateStop(MEMORY		stopFilter_T			*filter,				/**<persistente Daten*/
							IN	const	vehicleState_T			*vehicleState,			/**<Fahrzeugbeobachtung*/
							IN	const	roadModelInfo_T			*roadModelInfo,			/**<Streckendaten*/
							IN	const	longControlStatus_T		*longControlStatus,		/**<Regeler-Status*/
							IN	const	driverInputStatus_T		 resumeStatus,			/**<Fahrerbedienaktion Resume*/
							IN	const	sysStatus_T				 systemStatus,			/**<Aktivierungsstatus*/
							IN	const	bool_T					 newlyActivated,		/**<Neuaktivierung*/
							OUT			sysStopType_T			*stopInRange,			/**<Stopptelle in Reichweite*/
							OUT			bool_T					*takeoverRequest,		/**<�bernahmeaufforderung an Fahrer*/
							OUT			real32_T				*stopSweepPosition,		/**<Position, bis zu der Stoppstellen vom Regler unber�cksichtigt bleiben*/
							OUT			bool_T					*stopCanceled			/**<Stoppstelle wurd durch Fahrer aufgehoben*/
							);


#endif
