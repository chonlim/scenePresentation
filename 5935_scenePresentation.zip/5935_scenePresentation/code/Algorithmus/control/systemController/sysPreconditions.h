#ifndef guard_sysPreeconditions_h
#define guard_sysPreeconditions_h

#include "control/systemController/systemController.h"
#include "control/systemController/sysSetSpeedTypes.h"
#include "common/systemControllerCommon/systemController_private.h"




/** \brief Gibt an, ob das System durch den Fahrer ausgew�hlt ist.

Wenn	das Signal `vehicleInput.driver.selected` den Wert `true` annimmt
UND		das Signal `vehicleInput.driver.enabled`  den Wert `true` annimmt,
UND		das Signal `vehicleInput.driver.fodActivation`  den Wert `true` annimmt,
genau dann muss die Funktion `sysIsSystemEnabled` den Wert `true` zur�ckgeben.

\spec SW_AS_Innodrive2_122

\ingroup systemController_preconditions
*/
bool_T		sysIsSystemEnabled(		IN const	vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									OUT			bool_T				*isEnabled			/**<Ausgabe*/			
									);


/** \brief Gibt an, ob die Kartendaten generell g�ltig sind.

Wenn	die Funktion \ref prtIsMemoryValid()	den Wert `true` zur�ckgibt,
genau dann muss die Funktion `sysIsMapDataValid` den Wert `true` zur�ckgeben.

\spec SW_AS_Innodrive2_94 Entwurf

\ingroup systemController_preconditions
*/
bool_T		sysIsMapDataValid(		IN const	pathRouterMemory_T	*pathRouterMemory,	/**<Linearisierte Kartendaten*/
									OUT			uint8_T				*reasonFlags,		/**<Grund f�r nicht-Aktivierbarkeit*/
									OUT			bool_T				*valid				/**<Ausgabe*/
									);


/** \brief Gibt an, ob die Kartendaten unentprellt f�r eine Aktivierung des Systems ausreichen.

Wenn	die Funktion \ref sysRoadInfoGetLimit()	ein ung�ltiges Tempolimit oder eines kleiner als 30 km/h zur�ckgibt
genau dann muss die Funktion `sysIsMapDataOk` den Wert `true` zur�ckgeben.

\spec SW_AS_Innodrive2_94 Entwurf

\ingroup systemController_preconditions
*/
bool_T		sysIsSpeedLimitOk(		IN const	roadModelInfo_T		*roadModelInfo,		/**<Information zu Tempolimits aus dem roadProcessor*/
									IN const	velocityGrid_T		*velocityGrid,		/**< Raster zur Geschwindigkeitsverstellung abh�ngig von Tachoeinheit (kph/mph)*/
									INOUT		uint8_T				*reasonFlags,		/**<Grund f�r nicht-Aktivierbarkeit*/
									OUT			bool_T				*isOk				/**<Ausgabe*/
									);													


/** \brief Gibt an, ob die Kartendaten unentprellt f�r eine Aktivierung des Systems ausreichen.

UND		die Funktion \ref prtGetCountryCode()	einen L�ndercode zur�ckgibt, der in der L�nderliste freigegeben ist
UND		die Funktion \ref prtGetStreetClass()	eine Stra�enklasse ungleich `0 (Feldweg/Privatweg)` zur�ckgibt
genau dann muss die Funktion `sysIsMapDataOk` den Wert `true` zur�ckgeben.

\spec SW_AS_Innodrive2_94

\ingroup systemController_preconditions
*/
bool_T		sysIsRoadDataOk(		IN const	vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									IN const	vehicleState_T		*vehicleState,		/**<Fahrzeugzustand*/
									IN const	pathRouterMemory_T	*pathRouterMemory,	/**<Linearisierte Kartendaten*/
									INOUT		uint8_T				*reasonFlags,		/**<Grund f�r nicht-Aktivierbarkeit*/
									OUT			bool_T				*isOk				/**<Ausgabe*/
									);


/** \brief Gibt an, ob eine Regelstrategie verf�gbar ist.

Wenn	das Signal `longControlStatus.valid` den Wert `true` annimmt,
genau dann muss die Funktion `sysIsStrategyValid` den Wert `true` zur�ckgeben.

\spec SW_AS_Innodrive2_99
\spec SW_AS_Innodrive2_559

\ingroup systemController_preconditions
*/
bool_T		sysIsStrategyValid(		IN const    vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									IN const	vehicleState_T		*vehicleState,		/**<Fahrzeugzustand*/
									IN const	longControlStatus_T	 status,			/**<Status der Regelstrategie*/
									INOUT		uint8_T				*reasonFlags,		/**<Grund f�r nicht-Aktivierbarkeit*/
									OUT			bool_T				*isValid			/**<Ausgabe*/
									);


/** \brief Gibt an, ob der Fahrer mit dem Gaspedal �berdr�ckt.

Wenn	das Signal `vehicleInput.accStatus.status` den Wert  `accStatusOverride` annimt
genau dann muss die Funktion sysIsOverride den Wert `true` ausgeben.

\spec SW_AS_Innodrive2_97

\ingroup systemController_preconditions
*/
bool_T		sysIsOverride(			IN const	vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									OUT			bool_T				*isOverride			/**<Ausgabe*/
									);


/** \brief Gibt an, ob sich das ACC im Break-Only-Modus befindet.

Wenn	das Signal `vehicleInput.acc.accStatus` den Wert  `accStatusBrakeOnly` annimt
genau dann muss die Funktion sysIsBrakeOnlyMode den Wert `true` ausgeben.

\spec SW_AS_Innodrive2_98

\ingroup systemController_preconditions
*/
bool_T		sysIsBrakeOnlyMode(		IN const	vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									OUT			bool_T				*isBOM				/**<Ausgabe*/
									);

/** \brief Gibt an, ob sich das ACC im Fehlermodus befindet.

Wenn	das Signal `vehicleInput.acc.accStatus` den Wert  `accStatusErrorReversible` annimt
genau dann muss die Funktion sysIsAccError den Wert `true` ausgeben.

\spec SW_AS_Innodrive2_591
\ingroup systemController_preconditions
*/
bool_T		sysIsAccError(			IN const	vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									INOUT		uint8_T				*reasonFlags,		/**<Grund f�r nicht-Aktivierbarkeit*/
									OUT			bool_T				*isAccError			/**<Ausgabe*/
									);


/** \brief Gibt an, ob die Funktion ACC aktiviert ist.

Wenn	das Signal `vehicleInput.acc.accStatus` den Wert  `accStatusActive` ODER `accStatusPassive` annimmt,
genau dann muss die Funktion sysIsAccActive den Wert `true` ausgeben.

\spec SW_AS_Innodrive2_101

\ingroup systemController_preconditions
*/
bool_T		sysIsAccActive(			IN const	vehicleInput_T		*vehicleInput,		/**<Signaleingang*/
									OUT			bool_T				*isActive			/**<Ausgabe*/
									);

/** \brief Priorisiert das Fehler-Flag-Array und gibt einen Anzeigefehler aus.

\spec SW_AS_Innodrive2_592

\ingroup systemController_preconditions
*/
void	sysSetDisplayError(			IN const	sysStatus_T			 status,			/**<Systemstatus*/
									IN const	uint8_T				 reason,			/**<Grund f�r nicht-Aktivierbarkeit*/
									IN const	bool_T				 isAccInBom,		/**<Ob Acc im Brake Only Modus*/
									OUT			sysDisplayError_T	*error				/**<Ausgegebenes Fehlersignal*/
									);

/** \brief Gibt Log-Nachrichten zum Grund f�r eine Kartendatenbedingte Abschaltung aus.
\ingroup systemController_preconditions
*/
void diagPrintMapInvalidReason(		IN const	uint8_T				reason				/**<Grund f�r nicht-Aktivierbarkeit*/
									);





#endif
