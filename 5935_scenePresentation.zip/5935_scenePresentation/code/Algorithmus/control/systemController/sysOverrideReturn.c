#include "control/systemController/sysOverrideReturn.h"
#include "control/parameterSet/parameterSetCtrl.h"

bool_T	sysUpdateOverrideReturn(INOUT		overrideReturnFilter_T	*filter,		
								IN const	sysStatus_T				 status,		
								IN const	real32_T				 egoSpeed,		
								IN const	real32_T				 setSpeed)
{
	real32_T toleranceSpeed = prmGetParameterSetCtrl()->systemController.overrideReturn.velocityTolerance;

	if (egoSpeed < setSpeed + toleranceSpeed)
	{ 
		filter->overrideReturn = false; 
	}
	if (setSpeed + ROUNDING_ERROR < filter->setSpeed)	
	{ 
		filter->overrideReturn = false; 
	}
	if (status != sysStatusActive)
	{ 
		filter->overrideReturn = false; 
	}
	if (status == sysStatusOverride)
	{
		filter->overrideReturn = true;  
	}

	filter->setSpeed = setSpeed;

	return true;
}
