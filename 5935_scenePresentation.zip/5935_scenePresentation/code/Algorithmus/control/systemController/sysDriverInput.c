#include "control/systemController/sysDriverInput.h"
#include "control/systemController/sysDriverInputStatic.h"

#include "common/systemControllerCommon/systemController_private.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "control/systemController/sysSetSpeed.h"
#include "control/systemController/sysJamPilot.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "control/inputCodec/inputCodec_private.h"
#include <math.h> /*lint -esym(9045, struct _exception)*/
#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysDriverInput)

static bool_T		sysEvalDriverInput(	IN const	longPressCycleCount_T		*longPressCount,
										IN const	sysJamPilotStatus_T			*jamPilot,
										IN const	bool_T						 isActive,
										IN const	bool_T						 isPressed,
										IN const	bool_T						 doCancel,
										INOUT		sysDriverInput_T			*driverInput)
{
	const bool_T isLongPressed = isPressed && driverInput->debounceCounter == 0u;
	const bool_T isDoubleTimeout = !isPressed && driverInput->debounceCounter == 0u;
	const uint8_T decrementedCounter = (driverInput->debounceCounter > 0u) ? driverInput->debounceCounter - 1u : 0u;
	const bool_T jamPilotActive = sysJamPilotIsActive(jamPilot);

	/*Status�bergang*/
	switch (driverInput->status)
	{
	case sysCanceled:
		driverInput->status = isPressed ? sysCanceled : sysNotPressed;
		break;
	case sysNotPressed:
		driverInput->status = isPressed ? sysNewPressed : sysNotPressed;
		break;
	case sysNewPressed:
		driverInput->status = isPressed ? sysPressed : sysReleased;
		break;
	case sysPressed:
		driverInput->status = isPressed ? sysPressed : sysReleased;
		driverInput->status = isLongPressed ? sysLongPressed : driverInput->status;
		break;
	case sysLongPressed:
		driverInput->status = isPressed ? sysHeld : sysNotPressed;
		break;
	case sysHeld:
		driverInput->status = isPressed ? sysHeld : sysNotPressed;
		driverInput->status = isLongPressed ? sysLongPressed : driverInput->status;
		break;
	case sysReleased:
		driverInput->status = isPressed ? sysNewDouble : sysWaitDouble;
		break;
	case sysWaitDouble:
		driverInput->status = isPressed ? sysNewDouble : sysWaitDouble; 
		driverInput->status = isDoubleTimeout ? sysNotPressed : driverInput->status;
		break;
	case sysNewDouble:
		driverInput->status = isPressed ? sysDoublePressed : sysDoubleReleased;
		break;
	case sysDoublePressed:
		driverInput->status = isPressed ? sysDoublePressed : sysDoubleReleased;
		driverInput->status = isLongPressed ? sysLongPressed : driverInput->status;
		break;
	case sysDoubleReleased:
		driverInput->status = isPressed ? sysNewPressed : sysNotPressed;
		break;
	default:
		diagFUnreachable();
	}/*lint !e9077*/


	/*System kann nur im Status sysStatusActive mit dem Hebel bedient werden und wenn keine Abbruchbedingung vorliegt.*/
	if (!isActive  ||  doCancel  ||  jamPilotActive)
	{
		driverInput->status = isPressed ? sysCanceled : sysNotPressed;
	}

	/*Eingangsaktionen*/
	switch (driverInput->status)
	{		
	case sysCanceled:
	case sysNotPressed:
	case sysDoubleReleased:
		driverInput->debounceCounter = longPressCount->initial;
		break;
	case sysReleased:
		driverInput->debounceCounter = longPressCount->waitDouble;
		break;
	case sysNewDouble:
		driverInput->debounceCounter = longPressCount->initial - 1u;
		break;
	case sysNewPressed:
	case sysPressed:
	case sysHeld:
	case sysDoublePressed:
	case sysWaitDouble:
		driverInput->debounceCounter = decrementedCounter;
		break;
	case sysLongPressed:
		driverInput->debounceCounter = longPressCount->periodic;
		break;
	default:
		diagFUnreachable();
	}/*lint !e9077*/

	return true;
}


static void	sysCancelDriverInput(	IN const	longPressCycleCount_T		*longPressCount,
									IN const	bool_T						 isPressed,
									IN const	bool_T						 doCancel,
									INOUT		sysDriverInput_T			*driverInput)
{
	volatile driverInputStatus_T status;
	volatile uint8_T counter;

	status = isPressed ? sysCanceled : sysNotPressed;
	counter = longPressCount->initial;

	if (doCancel)
	{
		driverInput->status = status;
		driverInput->debounceCounter = counter;
	} else {
		status = driverInput->status;
		counter = driverInput->debounceCounter;
	}
}


bool_T			sysCancelResume(	IN const	vehicleInput_T			*input,
									IN const	vehicleState_T			*vehicleState,
									IN const	bool_T					 stopCanceled,
									INOUT		driverInputList_T		*list)

{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();
	real32_T displayVelocity;
	bool_T isStandstill;

	vobsGetUnfilteredState( vehicleState,
							NULL,
							&displayVelocity, 
							NULL, 
							NULL, 
							NULL);

	diagFF(sysIsStandstill( parameterSet,
							displayVelocity, 
							&isStandstill));

	sysCancelDriverInput(	&list->longPressCycleCount,
							input->driver.resume,
							stopCanceled || isStandstill,
							&list->resume);

	return true;
}


bool_T			sysEvalResumeSet(	IN const	vehicleInput_T			*input,
									IN const	sysJamPilotStatus_T		*jamPilot,
									IN const	sysStatus_T				 sysStatus,
									IN const	bool_T					 isNewActivation,
									INOUT		driverInputList_T		*list)
{
	bool_T isActivated;

	/*Als aktiv gilt das System in diesem Kontext nur, wenn es bereits zu Beginn des Rechentaktes aktiv war.*/
	isActivated = ((sysStatus == sysStatusActive) || (sysStatus == sysStatusOverride));
	isActivated = isActivated && !isNewActivation;

	diagFF(sysEvalDriverInput(&list->longPressCycleCount,
							   jamPilot,
							   isActivated, 
							   input->driver.resume,	
							   false, 
							  &list->resume));

	diagFF(sysEvalDriverInput(&list->longPressCycleCount, 
							   jamPilot, 
							   isActivated, 
							   input->driver.set,
							   false, 
							   &list->set));

	return true;
}

bool_T		sysEvalTipActions(		IN const	vehicleInput_T			*input,
									IN const	sysJamPilotStatus_T		*jamPilot,
									IN const	limitInfo_T				*limitInfo,
									IN const	sysStatus_T				 sysStatus,
									IN const	bool_T					 isAutoModeChange,
									INOUT		driverInputList_T		*list)
{
	const parameterSetCtrl_T *param = prmGetParameterSetCtrl();
	bool_T doCancel;

	doCancel = limitInfo->isCurrentLimitChange;
	doCancel = doCancel || limitInfo->isNextLimitChange;
	doCancel = doCancel || isAutoModeChange;
	doCancel = doCancel && param->systemController.velocityControl.enableCancelTipActions;
	
	diagFF(sysEvalDriverInput(&list->longPressCycleCount, 
							   jamPilot,
							   sysStatus == sysStatusActive, 
							   input->driver.tipDown,	
							   doCancel, 
							  &list->tipDown));

	diagFF(sysEvalDriverInput(&list->longPressCycleCount, 
							   jamPilot,
							   sysStatus == sysStatusActive, 
							   input->driver.tipUp,
							   doCancel, 
							  &list->tipUp));
	return true;
}

void		sysInitDriverInputList(	IN const	parameterSetCtrl_T		*parameterSet,
									OUT			driverInputList_T		*list)
{
	real32_T count;

	sysInit_driverInputList_T(list);

	count = parameterSet->systemController.longPressTime.initial  / controlCYCLETIME + 0.5f;
	list->longPressCycleCount.initial  = (uint8_T)floorf(count);
	count = parameterSet->systemController.longPressTime.periodic / controlCYCLETIME + 0.5f;
	list->longPressCycleCount.periodic = (uint8_T)floorf(count);
	count = parameterSet->systemController.status.doubleClickTimeout / controlCYCLETIME + 0.5f;
	list->longPressCycleCount.waitDouble = (uint8_T)floorf(count) == (uint8_T)0 ? 0u : (uint8_T)floorf(count) - 1u;

	list->resume.debounceCounter	= list->longPressCycleCount.initial;
	list->set.debounceCounter		= list->longPressCycleCount.initial;
	list->tipDown.debounceCounter	= list->longPressCycleCount.initial;
	list->tipUp.debounceCounter		= list->longPressCycleCount.initial;
}


void	sysInit_driverInputList_T(OUT	driverInputList_T	*list)
{
	list->longPressCycleCount.initial = (uint8_T)INVALID_UINT8;
	list->longPressCycleCount.periodic = (uint8_T)INVALID_UINT8;
	list->longPressCycleCount.waitDouble = (uint8_T)INVALID_UINT8;
	list->tipUp.status = sysNotPressed;
	list->tipUp.debounceCounter = (uint8_T)INVALID_UINT8;
	list->tipDown.status = sysNotPressed;
	list->tipDown.debounceCounter = (uint8_T)INVALID_UINT8;
	list->set.status = sysNotPressed;
	list->set.debounceCounter = (uint8_T)INVALID_UINT8;
	list->resume.status = sysNotPressed;
	list->resume.debounceCounter = (uint8_T)INVALID_UINT8;
}
