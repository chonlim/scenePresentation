#ifndef guard_sysSetSpeed_h
#define guard_sysSetSpeed_h

#include "control/systemController/systemController.h"
#include "control/parameterSet/parameterSetCtrl.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "control/systemController/sysSetSpeedTypes.h"
#include "control/systemController/sysVelocityGrid.h"


/** \brief Aktualisiert die Setzgeschwindigkeitskontrolle.
\ingroup systemController_setSpeed
*/
bool_T	   sysUpdateSetSpeedControl(IN	const	vehicleInput_T			*vehicleInput,		/**< Signaleingang*/
									IN	const	vehicleState_T			*vehicleState,		/**< Daten vom vehicleObserver*/
									IN	const	pathRouterMemory_T		*pathRouterMemory,	/**<Kartendaten vom pathRouter*/
									IN	const	roadModelInfo_T			*roadModelInfo,		/**< Information zu Tempolimits aus dem roadProcessor*/
									IN	const	longControlStatus_T		*longControlStatus,	/**< Statusr�ckmeldung von der L�ngsregelung */
									IN	const	systemStatus_T			*systemStatus,		/**< Systemstatus Innodrive2*/
									IN	const	velocityGrid_T			*velocityGrid,		/**< Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
									IN	const	bool_T					 isNewActivation,	/**< System nimmt den Status `sysStatusActive` neu an*/
									IN	const	bool_T					 stopInRange,		/**< Ist die Bedienung der Stoppstellen-Funktion momenten aktiv? */
									INOUT		setSpeedControl_T		*setSpeedControl,	/**< Zustand der Setzgeschwindigkeitskontrolle*/
									OUT			limitInfo_T				*limitInfo			/**<tempor�re Informationen zum aktuellen Tempolimitsatz*/
									);


/** \brief Erkennt den Stillstand des Fahrzeugs

Wenn die Fahrzeuggeschwindigkeit kleiner als der Parameter `parameterSet.systemController.velocityControl.tresholdStandStill` ist,
dann muss die Funktion sysDetectStandstill den Wert TRUE zur�ckgeben.

\spec SW_AS_Innodrive2_186

\ingroup systemController_setspeed
*/
bool_T	sysIsStandstill(			IN const	parameterSetCtrl_T		*parameterSet,		/**<Globale Parameter*/
									IN const	real32_T				 velocity,			/**<Fahrzeuggeschwindigkeit*/
									OUT			bool_T					*isStandStill		/**<Stillstand des Fahrzeugs erkannt*/
									);



#endif
