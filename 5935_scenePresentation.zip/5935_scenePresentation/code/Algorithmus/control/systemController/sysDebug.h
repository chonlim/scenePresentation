#ifndef guard_sysDebug_h
#define guard_sysDebug_h

#include "control/controlTask/iccExports.h"

typedef bool_T	(*sysUpdateModeCB)(IN const	vehicleInput_T*, INOUT bool_T*, OUT	bool_T*);
ICC_API void dbg_sysGet_sysUpdateMode(sysUpdateModeCB *sysUpdateModePointer);

typedef bool_T(*sysUpdateMapStatusCB)(IN const bool_T, IN const bool_T, IN const bool_T, IN const	bool_T, INOUT sysMapStatus_T*, OUT bool_T*);
ICC_API void dbg_sysGet_sysUpdateMapStatus(sysUpdateMapStatusCB *sysUpdateMapStatusPointer);

typedef bool_T(*sysUpdateAcvnStatusCB)(IN const vehicleInput_T*, IN const sysJamPilotStatus_T*, IN const bool_T, INOUT boolDebounce_T*, INOUT sysActivation_T*);
ICC_API void dbg_sysGet_sysUpdateAcvnStatus(sysUpdateAcvnStatusCB *sysUpdateAcvnStatusPointer);

typedef bool_T (*sysHoldTrueCB)(IN const bool_T, INOUT boolDebounce_T*);
ICC_API void dbg_sysGet_sysHoldTrue(sysHoldTrueCB *sysHoldTruePointer);

typedef void (*sysInit_boolDebounce_TCB)(OUT boolDebounce_T*);
ICC_API void dbg_sysGet_sysInit_boolDebounce_T(sysInit_boolDebounce_TCB *sysInit_boolDebounce_TPointer);

typedef void (*sysInit_systemControllerMemory_TCB)(OUT systemControlMemory_T*);
ICC_API void dbg_sysGet_sysInit_systemControllerMemory_T(sysInit_systemControllerMemory_TCB *sysInit_systemControllerMemory_TPointer);
#endif
