#ifndef guard_sysOutput_h
#define guard_sysOutput_h

#include "control/systemController/systemController.h"
#include "control/systemController/sysSetSpeed.h"

#include "common/vehicleObserverCommon/vehicleObserver_interface.h"




/** \brief Schreibt die Ausgabedaten des Moduls in die Struktur systemControl

Bei aktivem System werden die aktuelle und die zuk�nftige Setzgeschwindigkeit aus dem Untermodul \ref sysUpdateSetSpeedControl() 
ausgegeben (SW_AS_Innodrive2_544) in der Funktion \ref sysSetSpeedOnActive(). 
Bei inaktivem System werden in der Funktion \ref sysSetSpeedOnInactive() Ersatzwerte ausgegeben, da der ConstraintMaster f�r eine
g�ltige Planung immer mindestens eine aktuelle Setzgeschwindigkeit ben�tigt (SW_AS_Innodrive2_544).

Die ausgegebene `systemControl.previewPosition` ist die maximale Position zu der eine g�ltige Setzgeschwindigkeit ausgegeben wird zuz�glich einem kleinen
Delta zur Vermeidung von Flie�kommafehlern. Sie ist mindestens die Fahrzeugposition (SW_AS_Innodrive2_418).

\spec SW_AS_Innodrive2_544
\spec SW_AS_Innodrive2_46
\spec SW_AS_Innodrive2_595
\spec SW_AS_Innodrive2_596
\spec SW_AS_Innodrive2_49
\spec SW_AS_Innodrive2_59
\spec SW_AS_Innodrive2_676
\spec SW_AS_Innodrive2_725
\spec SW_AS_Innodrive2_742

\ingroup systemController_step
*/
	bool_T					  sysOutput(INOUT		speedCheckFilter_T		*speedCheckFilter,		/**< Filter f�r Setzgeschwindigkeitskontrolle*/
										INOUT		overrideReturnFilter_T	*overrideReturnFilter,	/**< Filter f�r Update der OverrideReturn-Flag*/
										IN	const	vehicleInput_T			*vehicleInput,			/**< Signaleingang*/
										IN	const	vehicleState_T			*vehicleState,			/**< Datenstruktur des Moduls vehicleObserver */
										IN	const	sysStatus_T				 status,				/**< Aktivierungszustand des Systems Innodrive2*/
										IN	const	setSpeedControl_T		*setSpeedControl,		/**< Daten der Setzgeschwindigkeitsverstellung*/
										IN	const	velocityGrid_T			*velocityGrid,			/**< Geschwindigkeitsraster abh�ngig von der Einheit des Displays*/
										IN	const	sysStopType_T			 stopInRange,			/**< Anforderung der Vorausschau-Anzeige "Stoppstelle" an den displayController */
										IN	const	bool_T					 stopTakeover,			/**< Anforderung einer �bernahmeaufforderung an den Fahrer */
										IN	const	real32_T				 stopSweepPosition,		/**< Position, bis zu der Stoppstellen vom Fahrer freigegeben wurden */
										IN  const	limitInfo_T				*limitInfo,				/**<tempor�re Informationen zum aktuellen Tempolimitsatz*/
										IN	const	bool_T					 isNewActivation,		/**< System nimmt den Status `sysStatusActive` neu an*/
										INOUT		setSpeedFilter_T		*setSpeedFilter,		/**< Filter zur Ausgabe der previousSetSpeed*/
										OUT			systemControl_T			*systemControl			/**< Ausgabedaten des systemController*/	
										);
	
/** \brief Schreibt die Function On Demand Ausgabe

\spec SW_AS_Innodrive2_725
\ingroup systemController_step
*/
	void				   sysFodOutput(IN	const	vehicleInput_T			*vehicleInput,			/**< Signaleingang*/
										OUT			fodOutput_T				*fodOutput				/**< Signalausgang*/
										);


#endif
