#include "control/systemController/sysSimplifiedMode.h"
#include "control/systemController/sysSimplifiedModeStatic.h"
#include "control/systemController/sysVelocityGrid.h"
#include "control/systemController/sysJamPilot.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/
#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysPermanentMode)


bool_T			sysUpdateSimplifiedMode(IN	const	parameterSetCtrl_T		*parameterSet,
										IN	const	systemStatus_T			*systemStatus,
										IN	const	velocityGrid_T			*velocityGrid,
										IN	const	driverInputList_T		*driverInputs,
										IN	const	sysControlLimits_T		*limits,
										IN	const	limitInfo_T				*limitInfo,
										IN	const	real32_T				 displayVelocity,
										IN	const	bool_T					 isNewActivation,
										IN	const	bool_T					 isStopInRange,
										IN	const	bool_T					 isAutoModeActive,
										INOUT		permanentMode_T			*permanentMode)
{
	bool_T doSaveCurrent = false;
	const real32_T lastCycleSetSpeed = permanentMode->currentSetSpeed;

	/*Setzgeschwindigkeiten aus Tempolimits aktualisieren, wenn das System aktiv oder aktivierbar ist.*/
	if (systemStatus->status != sysStatusDisabled && systemStatus->status != sysStatusNotAvailable)
	{
		diagFF(sysSomAdoptLimits(	 limits,
									 velocityGrid,						 
									 limitInfo,
									 limits->currentLimit.value,
									 limits->nextLimit.value,
									 isAutoModeActive,
									&permanentMode->autoNextLimit,
									&permanentMode->currentSetSpeed,
									&permanentMode->nextSetSpeed,
									&permanentMode->setSpeedManipulated,
									&doSaveCurrent));
	}
	
	if (isNewActivation)
	{
		/*Das System wird in diesem Rechentakt aktiviert.*/
		diagFF(sysSomActivate(	 systemStatus->lastAcvnAction,
								 velocityGrid,
								 limits,
								 displayVelocity,
								&permanentMode->lastSetSpeed.bufferedSetSpeed,
								&permanentMode->setSpeedManipulated,
								&permanentMode->autoNextLimit,
								&doSaveCurrent,
								&permanentMode->currentSetSpeed,
								&permanentMode->nextSetSpeed));
	} 
	else 
	{ 
		if (systemStatus->status == sysStatusActive  ||  systemStatus->status == sysStatusOverride)
		{
			/*703-713*/
			if (!isAutoModeActive)
			{
				/*704 709*/
				if (limits->nextLimit.valid)
				{
					if (parameterSet->systemController.resumeAction.manMode.acceptNextLimit) 
					{
						/*709*/
						diagFF(sysSomResumeOnNext(	 driverInputs->resume.status,
													 limits->nextLimit.value,
													 isStopInRange,
													&permanentMode->setSpeedManipulated,
													&permanentMode->nextSetSpeed));
					}
				} 
				else 
				{
					if (parameterSet->systemController.resumeAction.manMode.acceptCurrentLimit)
					{
						/*704*/
						diagFF(sysSomResumeOnCurrent(	 driverInputs->resume.status,
														 limits->currentLimit.value,
														 isStopInRange,
														&permanentMode->setSpeedManipulated,
														&permanentMode->currentSetSpeed));
					}
				}
			}
			else
			{
				/*705-707 711-713*/
				if (limits->nextLimit.valid)
				{
					/*Resume*/
					if (parameterSet->systemController.resumeAction.autoMode.acceptNextLimit)
					{
						/*713*/
						diagFF(sysSomConfirmNext(	 driverInputs->resume.status,
													 limits->nextLimit.value,
													 isStopInRange,
													&permanentMode->setSpeedManipulated,
													&permanentMode->autoNextLimit,
													&permanentMode->nextSetSpeed));
					}
					else
					{
						/*Keine Aktion f�r einfaches Resume*/
					}

					if (parameterSet->systemController.resumeAction.autoMode.discardNextLimit)
					{
						/*712*/
						diagFF(sysSomDiscardNext(	 driverInputs->resume.status,
													 isStopInRange,
													 permanentMode->currentSetSpeed,
													&permanentMode->setSpeedManipulated,
													&permanentMode->autoNextLimit,
													&permanentMode->nextSetSpeed));
					}
				}
				else
				{
					/*Resume*/
					if (parameterSet->systemController.resumeAction.autoMode.acceptCurrentLimit)
					{
						/*707*/
						diagFF(sysSomConfirmCurrent(	 driverInputs->resume.status,
														 limits->currentLimit.value,
														 isStopInRange,
														&permanentMode->setSpeedManipulated,
														&permanentMode->currentSetSpeed,
														&permanentMode->lastSetSpeed));
					} 
					else 
					{
						/*Keine Aktion f�r einfaches Resume*/
					}

					/*Resume-Longpress*/
					if (parameterSet->systemController.resumeAction.autoMode.discardCurrentLimit)
					{
						/*706*/
						diagFF(sysSomDiscardCurrent( driverInputs->resume.status,
													 isStopInRange,
													&permanentMode->setSpeedManipulated,
													&permanentMode->currentSetSpeed,
													&permanentMode->lastSetSpeed.bufferedSetSpeed));
					}
				}
			}

			if (systemStatus->status == sysStatusOverride)
			{
				/*Status Override*/
				if (driverInputs->set.status != sysNotPressed)
				{
					diagFF(sysSomOverrideSet(	 velocityGrid,
												 driverInputs->set.status,
												 displayVelocity,
												 limits->nextLimit.valid,
												&permanentMode->currentSetSpeed,
												&permanentMode->nextSetSpeed,
												&permanentMode->setSpeedManipulated));
				} 
				else if (limits->nextLimit.valid)
				{
					if (permanentMode->nextSetSpeed > permanentMode->currentSetSpeed)
					{
						diagFF(sysSomOverrideLimitPull(	 parameterSet,
														&systemStatus->jamPilot,
														 permanentMode->nextSetSpeed,
														 isAutoModeActive,
														&permanentMode->currentSetSpeed,
														&doSaveCurrent));
					} 
					else if (permanentMode->nextSetSpeed < permanentMode->currentSetSpeed) 
					{
						diagFF(sysSomOverrideLimitDrop(	 parameterSet,
														&systemStatus->jamPilot,
														 permanentMode->currentSetSpeed,
														 isAutoModeActive,
														&permanentMode->nextSetSpeed));
					}
					else {
						/*Setzgeschwindigkeiten sind bereits gleich.*/
					}
				}
				else
				{
					/*Keine Anpassung der Setzgeschwindigkeiten*/
				}
			} 
			else 
			{
				/*Status Active*/
				diagFF(sysSomTipActions(	 velocityGrid,
											 driverInputs->tipUp.status,
											 driverInputs->tipDown.status,
											 limits->nextLimit.valid,
											&permanentMode->lastSetSpeed.bufferedSetSpeed,
											&permanentMode->setSpeedManipulated,
											&permanentMode->autoNextLimit,
											&permanentMode->currentSetSpeed,
											&permanentMode->nextSetSpeed));
			}
		}
	}

	diagFF(sysSomUpdateLastSetSpeed( parameterSet,
									 doSaveCurrent,
									 lastCycleSetSpeed,
									&permanentMode->lastSetSpeed));

	/*Zur�cksetzen von Setzgeschwindigkeiten*/
	diagFF(sysSomReset(	 systemStatus->status,
						 isAutoModeActive,
						&permanentMode->lastSetSpeed,
						&permanentMode->currentSetSpeed,
						&permanentMode->nextSetSpeed,
						&permanentMode->autoNextLimit,
						&permanentMode->setSpeedManipulated));


	return true;
}


static bool_T				sysSomReset(IN	const	sysStatus_T				 status,
										IN	const	bool_T					 isAutoModeActive,
										INOUT		lastSetSpeed_T			*lastSetSpeed,
										INOUT		real32_T				*currentSetSpeed,
										INOUT		real32_T				*nextSetSpeed,
										INOUT		bool_T					*autoNextLimit,
										INOUT		bool_T					*setSpeedManipulated)
{
	const parameterSetCtrl_T *parameterSet = prmGetParameterSetCtrl();
	real32_T current, next, last;
	bool_T autoNext, speedManipulated;
	uint16_T lastCount;

	/*Zur�cksetzen je nach Status und g�ltigkeit der Tempolimits*/
	if (status == sysStatusDisabled)
	{
		current	= 0.0f;
		next	= 0.0f;
		last = 0.0f;
		lastCount = 0u;
		autoNext = false;
		speedManipulated = false;

	} else {
		current	= *currentSetSpeed;
		next	= *nextSetSpeed;
		last = lastSetSpeed->bufferedSetSpeed;
		lastCount = lastSetSpeed->counter;
		autoNext = *autoNextLimit;
		speedManipulated = *setSpeedManipulated;
	}

	if (!isAutoModeActive)
	{
		last = 0.0f;
		lastCount = 0u;
	}
	
	if (	*setSpeedManipulated
		||	!parameterSet->systemController.resumeAction.autoMode.discardCurrentLimit)
	{
		last = 0.0f;
		lastCount = 0u;
	}

	
	/*Ausgabe*/
	*currentSetSpeed = current;
	*nextSetSpeed = next;
	lastSetSpeed->bufferedSetSpeed = last;
	lastSetSpeed->counter = lastCount;
	*autoNextLimit = autoNext;
	*setSpeedManipulated = speedManipulated;

	return true;
}


static bool_T			 sysSomActivate(IN	const	sysActivation_T			 lastAcvnAction,
										IN	const	velocityGrid_T			*velocityGrid,
										IN	const	sysControlLimits_T		*limits,
										IN	const	real32_T				 displayVelocity,
										OUT			real32_T				*lastSetSpeed,
										OUT			bool_T					*setSpeedManipulated,
										OUT			bool_T					*autoNextLimit,
										OUT			bool_T					*doSaveCurrent,
										INOUT		real32_T				*currentSetSpeed,
										INOUT		real32_T				*nextSetSpeed)
{
	real32_T current, next;
	real32_T satCurrent, satNext;

	/*SW_AS_Innodrive2_697*/
	/*Aktivierung mit SET oder RESUME?*/
	if (lastAcvnAction == sysAcvnSet)
	{
		current	= displayVelocity;
		*setSpeedManipulated = true;
		*lastSetSpeed = 0.0f;
		*doSaveCurrent = false;

		if (limits->nextLimit.valid)
		{
			next = displayVelocity;
			*autoNextLimit = false;
		}
		else
		{
			next = 0.0f;
		}
	} 
	/*SW_AS_Innodrive2_698*/
	else if (lastAcvnAction == sysAcvnResume)
	{
		diagFF(*currentSetSpeed > 0.0f);
		current = *currentSetSpeed;
		next = *nextSetSpeed;
	}
	else
	{
		/*Aktivierung ohne Tastendruck darf es nicht geben*/
		diagFUnreachable();
	}

	/*Saturierung*/
	diagFF(sysSaturateSetSpeed(velocityGrid, current,	&satCurrent));
	diagFF(sysSaturateSetSpeed(velocityGrid, next,		&satNext));

	/*Ausgabe*/
	*currentSetSpeed = satCurrent;
	*nextSetSpeed	 = limits->nextLimit.valid ? satNext : 0.0f;

	return true;
}
										

static bool_T		  sysSomAdoptLimits(IN	const	sysControlLimits_T		*limits,
										IN	const	velocityGrid_T			*velocityGrid,
										IN	const	limitInfo_T				*limitInfo,
										IN	const	real32_T				 currentSL,
										IN	const	real32_T				 nextSL,
										IN	const	bool_T					 isAutoModeActive,
										OUT			bool_T					*autoNextLimit,
										INOUT		real32_T				*currentSetSpeed,
										INOUT		real32_T				*nextSetSpeed,
										INOUT		bool_T					*setSpeedManipulated,
										INOUT		bool_T					*doSaveCurrent)
{
	real32_T current = *currentSetSpeed;
	real32_T next = *nextSetSpeed;

	real32_T satCurrent, satNext;

	/*Anpassung aktuelle Setzgeschwindigkeit*/
	if (    (limitInfo->isCurrentLimitChange || current == 0.0f)
		&&	limits->currentLimit.valid
		&&	isAutoModeActive)
	{
		/*SW_AS_Innodrive2_699*/
		if (!limits->nextLimit.valid || *autoNextLimit)
		{
			/*Wenn die Vorausschaugeschw. noch nicht manipuliert wurde, soll die letzte Setzgeschwindigkeit gespeichert werden*/
			*doSaveCurrent = true;
		}

		/*SW_AS_Innodrive2_691*/
		if (!limitInfo->isNewLimitPassed)
		{
			/*Nur bei aktivem autoMode wird das SL als Setzgeschwindigkeit �bernommen*/
			current = currentSL;
			if (!limits->nextLimit.valid)
			{
				*setSpeedManipulated = false;
			}
		}

	}	
	
	/*SW_AS_Innodrive2_692*/
	if (limitInfo->isNewLimitPassed)
	{
		diagFF(limits->currentLimit.valid);
		current = *nextSetSpeed;
		if (!*autoNextLimit) 
		{
			*doSaveCurrent = false;
		}
	}
	
	/*Anpassung zuk�nftige Setzgeschwindigkeit*/
	/*SW_AS_Innodrive2_693*/
	if (!limits->nextLimit.valid)
	{
		next = 0.0f;
		*autoNextLimit = false;
	} 
	else if (limitInfo->isNextLimitChange)
	{
		/*SW_AS_Innodrive2_694*/
		if (isAutoModeActive)
		{
			next = nextSL;
			*autoNextLimit = true;
			*setSpeedManipulated = false;
		}
		/*SW_AS_Innodrive2_695*/
		else
		{
			next = current;
			*autoNextLimit = false;
		}
	}
	else {
	/*Keine Anpassung*/
	}

	/*Saturierung*/
	diagFF(sysSaturateSetSpeed(velocityGrid, current, &satCurrent));
	diagFF(sysSaturateSetSpeed(velocityGrid, next, &satNext));

	/*Ausgabe*/
	*currentSetSpeed = current > 0.0f ? satCurrent : 0.0f;
	*nextSetSpeed	 = limits->nextLimit.valid ? satNext : 0.0f;

	return true;
}


static bool_T	  sysSomResumeOnCurrent(IN	const	driverInputStatus_T		 resume,
										IN	const	real32_T				 currentSL,
										IN	const	bool_T					 isStopInRange,
										OUT			bool_T					*setSpeedManipulated,
										INOUT		real32_T				*currentSetSpeed)
{
	volatile real32_T newCurrent;

	const bool_T resumePressed = resume == sysReleased || resume == sysDoubleReleased;

	/*Was tun?*/
	newCurrent = currentSL;

	/*Ausgabe*/
	if (!isStopInRange && resumePressed)
	{
		*currentSetSpeed = newCurrent;
		*setSpeedManipulated = true;
	} else {
		newCurrent = *currentSetSpeed;
	}

	return true;
}



static bool_T		 sysSomResumeOnNext(IN	const	driverInputStatus_T		 resume,
										IN	const	real32_T				 nextSL,
										IN	const	bool_T					 isStopInRange,
										OUT			bool_T					*setSpeedManipulated,
										INOUT		real32_T				*nextSetSpeed)
{
	volatile real32_T newNext;

	const bool_T resumePressed = resume == sysReleased || resume == sysDoubleReleased;

	/*Was tun?*/
	newNext = nextSL;

	/*Ausgabe*/
	if (!isStopInRange && resumePressed)
	{
		*nextSetSpeed = newNext;
		*setSpeedManipulated = true;
	} else {
		newNext = *nextSetSpeed;
	}

	return true;
}


static bool_T	  sysSomDiscardCurrent(	IN	const	driverInputStatus_T		 resume,
										IN	const	bool_T					 isStopInRange,
										OUT			bool_T					*setSpeedManipulated,
										OUT			real32_T				*currentSetSpeed,
										INOUT		real32_T				*lastSetSpeed)
{
	const bool_T resumeLongPressed = resume == sysLongPressed;

	/*Ausgabe*/
	if (!isStopInRange && (*lastSetSpeed > 0.0f) && resumeLongPressed)
	{
		*currentSetSpeed = *lastSetSpeed;
		*lastSetSpeed = 0.0f;
		*setSpeedManipulated = false;
	}

	return true;
}

static bool_T	  sysSomDiscardNext(IN	const	driverInputStatus_T		 resume,
									IN	const	bool_T					 isStopInRange,
									IN  const	real32_T				 currentSetSpeed,
									OUT			bool_T					*setSpeedManipulated,
									INOUT		bool_T					*autoNextLimit,
									OUT			real32_T				*nextSetSpeed)
{
	const bool_T resumeLongPressed = resume == sysLongPressed;

	/*Ausgabe*/
	if (!isStopInRange && *autoNextLimit && resumeLongPressed)
	{
		*nextSetSpeed = currentSetSpeed;
		*autoNextLimit = false;
		*setSpeedManipulated = false;
	}

	return true;
}


static bool_T	  sysSomConfirmCurrent(	IN	const	driverInputStatus_T		 resume,
										IN	const	real32_T				 currentLimit,
										IN	const	bool_T					 isStopInRange,
										OUT			bool_T					*setSpeedManipulated,
										OUT			real32_T				*currentSetSpeed,
										OUT			lastSetSpeed_T			*lastSetSpeed)
{
	const bool_T resumePressed = resume == sysReleased || resume == sysDoubleReleased;

	/*Ausgabe*/
	if (!isStopInRange && resumePressed)
	{
		*currentSetSpeed = currentLimit; /*Laut Spec nur SL*/
		*setSpeedManipulated = false;
		lastSetSpeed->bufferedSetSpeed = 0.0f;
		lastSetSpeed->counter = 0u;
	}

	return true;
}

static bool_T	  sysSomConfirmNext(IN	const	driverInputStatus_T		 resume,
									IN	const	real32_T				 nextLimit,
									IN	const	bool_T					 isStopInRange,
									OUT			bool_T					*setSpeedManipulated,
									OUT			bool_T					*autoNextLimit,
									OUT			real32_T				*nextSetSpeed)
{
	const bool_T resumePressed = resume == sysReleased || resume == sysDoubleReleased;

	/*Ausgabe*/
	if (!isStopInRange && resumePressed)
	{
		*nextSetSpeed = nextLimit; /*Laut Spec nur SL*/
		*setSpeedManipulated = false;
		*autoNextLimit = false;
	}

	return true;
}


static bool_T		  sysSomOverrideSet(IN	const	velocityGrid_T			*velocityGrid,
										IN	const	driverInputStatus_T		 set,
										IN	const	real32_T				 displayVelocity,
										IN	const	bool_T					 nextLimitValid,
										INOUT		real32_T				*currentSetSpeed,
										INOUT		real32_T				*nextSetSpeed,
										INOUT		bool_T					*setSpeedManipulated)
{
	real32_T satVelocity;
	volatile real32_T current, next;
	volatile bool_T manip = false;

	/*Anzeigegeschwindigkeit saturieren*/
	diagFF(sysSaturateSetSpeed(velocityGrid, displayVelocity, &satVelocity));
	current = satVelocity;
	next = nextLimitValid ? satVelocity : 0.0f;

	/*Nur wenn Anzeigeegeschwindigkeit gr��er als Setzgeschwindigkeit, wird neu gesetzt*/
	if (current > *currentSetSpeed) {
		manip = true;
	}
	else {
		current = *currentSetSpeed;
	}

	if (next > *nextSetSpeed) {
		manip = true;
	}
	else {
		next = *nextSetSpeed;
	}

	/*Ausgabe wenn set gedr�ckt wurde*/
	if (set == sysNewPressed || set == sysNewDouble)
	{
		*currentSetSpeed = current;
		*nextSetSpeed = next;
		*setSpeedManipulated = manip;
	}
	else {
		current = *currentSetSpeed;
		next = *nextSetSpeed;
		manip = *setSpeedManipulated;
	}

	return true;
}
										

static bool_T		   sysSomTipActions(IN	const	velocityGrid_T			*grid,
										IN	const	driverInputStatus_T		 tipUp,
										IN	const	driverInputStatus_T		 tipDown,
										IN	const	bool_T					 nextLimitValid,
										OUT			real32_T				*lastSetSpeed,
										OUT			bool_T					*setSpeedManipulated,
										OUT			bool_T					*autoNextLimit,
										INOUT		real32_T				*currentSetSpeed,
										INOUT		real32_T				*nextSetSpeed)
{
	/*Welche Schrittweite in welche Richtung?*/
	const bool_T upSmall	=   ((tipUp == sysNewPressed) || (tipUp	  == sysNewDouble));	/*179 180*/
	const bool_T downSmall	= ((tipDown == sysNewPressed) || (tipDown == sysNewDouble));	/*182 183*/
	const bool_T upBig		=    (tipUp == sysLongPressed);									/*181 525*/
	const bool_T downBig	=  (tipDown == sysLongPressed);									/*184 526*/
	
	/*Welche Richtung, welche Schrittweite?*/
	const bool_T  up	= (upBig || upSmall);
	const uint8_T step	= (upBig || downBig) ? grid->bigIncrement : grid->smallIncrement;

	/*Tun wir �berhaupt irgendetwas?*/
	const bool_T valid = upSmall || upBig || downSmall || downBig;

	real32_T current, next;
	real32_T paraCurrent;

	/*Schritte durchf�hren*/
	diagFF(sysSomTip(grid, step, up, *currentSetSpeed, &current));	/*alle 8 Anforderungen*/
	diagFF(sysSomTip(grid, step, up, *nextSetSpeed, &next));		/*180 525 183 526*/


	/*current parallel in Richtung von next mitbewegen und auf next begrenzen, ...*/
	if (up)
	{
		/*180 525  (je iv, v)*/
		paraCurrent = min(current, next);
		paraCurrent = (*currentSetSpeed < next) ? paraCurrent : *currentSetSpeed;
	} else {
		/*183 526  (je iv, v)*/
		paraCurrent = max(current, next);
		paraCurrent = (*currentSetSpeed > next) ? paraCurrent : *currentSetSpeed;
	}
	
	/*... aber nur wenn next bewegt wird*/
	if (nextLimitValid)
	{
		current = paraCurrent;	/*180 525 183 526  (je iv, v)*/
	} else {
		next = 0.0f;			/*179 181 182 184*/
	}

	/*Ausgabe*/
	if (valid)
	{
		*currentSetSpeed = current;
		*nextSetSpeed = next;

		*lastSetSpeed = 0.0f;
		*setSpeedManipulated = true;
		*autoNextLimit = false;
	} else {
		*currentSetSpeed = *currentSetSpeed;
		*nextSetSpeed = *nextSetSpeed;
	}

	return true;
}

static bool_T				  sysSomTip(IN	const	velocityGrid_T			*grid,
										IN	const	uint8_T					 step,
										IN	const	bool_T					 up,
										IN	const	real32_T				 inSpeed,
										OUT			real32_T				*outSpeed)
{
	const real32_T real32SetSpeed = inSpeed / grid->gridUnit + 0.5f;
	uint16_T setSpeed = (uint16_T)floorf(real32SetSpeed);

	diagFNaN(real32SetSpeed);
	diagFF(step > 0u);

	/*Hoch- bzw. Runterz�hlen*/
	if (up) { /*up*/
		setSpeed = (uint16_T)(step * ((setSpeed + step) / step));
	}
	else { /*down*/
		setSpeed = (uint16_T)(step * ((setSpeed - 1u) / step));
	}

	/*Begrenzen*/
	setSpeed = min(setSpeed, grid->maxSetSpeed);
	setSpeed = max(setSpeed, grid->minSetSpeed);

	*outSpeed = grid->gridUnit * (real32_T)setSpeed;

	return true;
}


static bool_T			   sysSomUpdateLastSetSpeed(IN	const	parameterSetCtrl_T		*parameterSet,
													IN	const	bool_T					 doSaveCurrent,
													IN	const	real32_T				 lastCycleSetSpeed,
													INOUT		lastSetSpeed_T			*buffer)
{
	real32_T bufferedSetSpeed;
	uint16_T maxCount, counter;

	/*Initialisierung*/
	real32_T count = parameterSet->systemController.velocityControl.bufferTimeLastSetSpeed / controlCYCLETIME + 0.5f;
	maxCount = (uint16_T)floorf(count);

	/*Wert halten*/
	if (buffer->counter > 0u)
	{
		counter = buffer->counter - 1u;
		bufferedSetSpeed = buffer->bufferedSetSpeed;
	}
	else {
		counter = 0u;
		bufferedSetSpeed = 0.0f;
	}

	/*Bei Trigger neuen Wert lernen*/
	if (doSaveCurrent)
	{
		bufferedSetSpeed = lastCycleSetSpeed;
		counter = bufferedSetSpeed > 0.0f ? maxCount : (uint16_T)0;
	}
	else {
		bufferedSetSpeed = bufferedSetSpeed;
		counter = bufferedSetSpeed > 0.0f ? counter : (uint16_T)0;
	}

	/*Ausgabe*/
	buffer->counter = counter;
	buffer->bufferedSetSpeed = bufferedSetSpeed;

	return true;
}


static bool_T			sysSomOverrideLimitPull(IN	const	parameterSetCtrl_T		*parameterSet,
												IN	const	sysJamPilotStatus_T		*jamPilot,
												IN	const	real32_T				 nextSetSpeed,
												IN	const	bool_T					 isAutoModeActive,
												INOUT		real32_T				*currentSetSpeed,
												INOUT		bool_T					*doSaveCurrent)
{
	const bool_T enabled = parameterSet->systemController.velocityControl.enableOverrideLimitPull;
	real32_T current;
	bool_T saveCurrent;

	diagFF(nextSetSpeed > 0.0f);

	/*N�chstes Limit vorziehen*/
	if (enabled && isAutoModeActive && !sysJamPilotIsActive(jamPilot))
	{
		current = nextSetSpeed;
		saveCurrent = true;
	}
	else {
		current = *currentSetSpeed;
		saveCurrent = *doSaveCurrent;
	}

	/*Ausgabe*/
	*currentSetSpeed = current;
	*doSaveCurrent = saveCurrent;

	return true;
}


static bool_T			sysSomOverrideLimitDrop(IN	const	parameterSetCtrl_T		*parameterSet,
												IN	const	sysJamPilotStatus_T		*jamPilot,
												IN	const	real32_T				 currentSetSpeed,
												IN	const	bool_T					 isAutoModeActive,
												INOUT		real32_T				*nextSetSpeed)
{
	const bool_T enabled = parameterSet->systemController.velocityControl.enableOverrideLimitDrop;
	real32_T next;

	diagFF(currentSetSpeed > 0.0f);

	/*AktuelleSetzgeschwindigkeit fortf�hren*/
	if (enabled && isAutoModeActive && !sysJamPilotIsActive(jamPilot))
	{
		next = currentSetSpeed;
	}
	else {
		next = *nextSetSpeed;
	}

	/*Ausgabe*/
	*nextSetSpeed = next;

	return true;
}
