#ifndef guard_sysOverrideReturn_h
#define guard_sysOverrideReturn_h

#include "control/systemController/sysOutput.h"

/**\brief Update der Flag `overrideReturn` zur Verlangsamten R�ckkehr zur Setzgeschwindigkeit

Wenn `status == sysStatusOverride` ist, muss die Funktion die Flag `filter.overrideReturn` auf den Wert `true` setzen.
Wenn `status == sysStatusActive` ist UND mindestens eine der folgenden Bedingungen zutrifft:
 - Die Fahrzeuggeschwindigkeit `egoSpeed` f�llt unter die Setzgeschwindigkeit `setSpeed` plus die parametrierbare Toleranz `overrideReturnTolerance`.
 - Die Setzgeschwindigkeit `setSpeed` wird reduziert.
muss die Funktion die Flag `filter.overrideReturn` auf den Wert `false` setzen.
Wenn `status != sysStatusActive` UND `status != sysStatusOverride` ist, muss die Funktion die Flag `filter.overrideReturn` auf den Wert `false` setzen.
Sonst muss die Funktion den Wert der Flag `filter.overrideReturn` halten.

\ingroup systemController_step
*/
bool_T	sysUpdateOverrideReturn(INOUT		overrideReturnFilter_T	*filter,		/**<Filter zur Bestimmung der OVerride-Return-Flag*/
								IN const	sysStatus_T				 status,		/**<aktueller Systemstatus*/
								IN const	real32_T				 egoSpeed,		/**<aktuelle Fahrzeuggeschwindigkeit*/
								IN const	real32_T				 setSpeed		/**<aktuelle Setzgeschwindigkeit*/
								);

#endif
