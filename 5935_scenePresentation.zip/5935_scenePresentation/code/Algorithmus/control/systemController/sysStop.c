#include "systemController.h"
#include "common/systemControllerCommon/systemController_private.h"

#include "sysStop.h"

#include "common/systemControllerCommon/sysInfo.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"
#include "control/parameterSet/parameterSetCtrl.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysStop)


bool_T		  sysUpdateStop(MEMORY		stopFilter_T			*filter,
							IN	const	vehicleState_T			*vehicleState,
							IN	const	roadModelInfo_T			*roadModelInfo,
							IN	const	longControlStatus_T		*longControlStatus,
							IN	const	driverInputStatus_T		 resumeStatus,
							IN	const	sysStatus_T				 systemStatus,
							IN	const	bool_T					 newlyActivated,
							OUT			sysStopType_T			*stopInRange,
							OUT			bool_T					*takeoverRequest,
							OUT			real32_T				*stopSweepPosition,
							OUT			bool_T					*stopCanceled)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T		egoVelocity;
	real32_T		egoPosition;
	real32_T		infoPosition;
	real32_T		refPosition;

	real32_T		previewMax;
	real32_T		previewMin;
	real32_T		previewCand;
	real32_T		revertPosition;

	real32_T		holdPosition;
	real32_T		enterPosition;
	real32_T		leavePosition;

	real32_T		relShowPosition;
	sysStopType_T	inRange;

	bool_T			proximityEnter;
	bool_T			proximityHold;

	uint16_T		maxCount;
	uint16_T		index;
	
	*stopCanceled = false;

	/* Abfragen von Referenzposition und -Geschwindigkeit */
	vobsGetVelocity(vehicleState, &egoVelocity);
	vobsGetPosition(vehicleState, &egoPosition);

	sysRoadInfoGetRefPosition(roadModelInfo, &infoPosition);
	refPosition = min(infoPosition, egoPosition);


	/* Berechnen des zul�ssigen Fensters f�r den Vorausschauhorizont */
	previewMax		= refPosition + (egoVelocity * paramSet->systemController.stop.timeMax);
	previewMin		= refPosition + (egoVelocity * paramSet->systemController.stop.timeMin);

	previewMax		= max(previewMax, refPosition + paramSet->systemController.stop.distanceMin);
	previewMin		= max(previewMin, refPosition + paramSet->systemController.stop.distanceMin);

	previewCand		= longControlStatus->valid ? longControlStatus->stopPosition : previewMin;
	previewCand		= min(previewCand, previewMax);
	previewCand		= max(previewCand, previewMin);

	filter->showPosition	= max(filter->showPosition, previewCand);
	revertPosition			= filter->showPosition + paramSet->systemController.stop.revertThreshold;


	/* Berechnen des Fensters f�r die �bernahmeaufforderung */
	leavePosition	= refPosition - paramSet->systemController.stop.proximityLeave;
	enterPosition	= refPosition + paramSet->systemController.stop.proximityEnter;
	holdPosition	= refPosition + paramSet->systemController.stop.proximityHold;


	/* Bei Aktivierung der L�ngsregelung werden Stoppstellen in Fahrzeugn�he automatisch ger�umt */
	if(newlyActivated) {
		real32_T newSweepPosition;

		newSweepPosition = refPosition + paramSet->systemController.stop.initSweepLength;
		filter->sweepPosition = max(filter->sweepPosition, newSweepPosition);
	}


	/* Stoppstellen, die mehr als proximityLeave hinter der Referenzposition liegen, werden auf jeden Fall verworfen */
	filter->sweepPosition = max(filter->sweepPosition, leavePosition);


	/* Wenn wir im letzten Schritt bereits eine Stoppstelle gemeldet hatten, suchen wir jetzt bis zur revertPosition,
	   andernfalls bis zur showPosition */
	relShowPosition = (filter->lastInRange == sysStopNone) ? filter->showPosition : revertPosition;


	/* Befindet sich eine g�ltige Stoppstelle im Anzeigefenster? */
	sysRoadInfoGetMaxStopCount(&maxCount);
	inRange			= sysStopNone;
	proximityEnter	= false;
	proximityHold	= false;

	for(index = 0; index < maxCount; index++) {
		bool_T			valid;
		real32_T		position;
		sysStopType_T	type;

		diagFF(sysRoadInfoGetStop( roadModelInfo,
								   index,
								  &valid,
								  &position,
								  &type));

		if(   (position > filter->sweepPosition)
		   && (position < relShowPosition)
		   && (valid)) {
			/* Die erste Stoppstelle auf dem Horizont ist relevant */
			if(inRange == sysStopNone) {
				inRange = type;

				if(position < enterPosition) { proximityEnter = true; }
				if(position < holdPosition)  { proximityHold = true; }
			}
		}
	}


	/* Speichen der gefundenen Stoppstelle f�r den n�chsten Zeitschritt */
	filter->lastInRange = inRange;


	/* Wenn bei aktivem System und Stoppstelle in Reichweite "Resume" bet�tigt wird oder das System nicht aktiviert ist,
	   verschieben wir die Sweep-Position ans Ende des Anzeigefensters. */
	if( ((inRange != sysStopNone)
	      && ((systemStatus == sysStatusActive && resumeStatus == sysNewPressed)
	       || (systemStatus == sysStatusOverride)))
	    || !(systemStatus == sysStatusActive || systemStatus == sysStatusOverride)) 
	{
		*stopCanceled = true;
		filter->sweepPosition = relShowPosition;
	}


	/* Bei aktivem System setzen wir eine �bernahmeaufforderung, wenn wir in die N�he einer relevanten Stoppstelle kommen */
	if(   (systemStatus == sysStatusActive)
	   && (proximityEnter)) {
		filter->proximity	= true;

		/* Nur bei Stoppstellen wird eine �bernahmeaufforderung ausgel�st, bei 'Vorfahrt beachten' tun wir so, als h�tte
		   der Fahrer die Stelle bereits zur Kenntnis genommen. */
		filter->reacted		= (inRange == sysStopYield);
	}


	/* Wenn der Fahrer bei gesetzter �bernahmeaufforderung �bertritt, nehmen wir den Hinweis zur�ck,
	   verwerfen die Stoppstelle aber noch nicht, damit es nicht zu einem unerwarteten Beschleunigen kommt */
	if(   (systemStatus == sysStatusOverride)
	   && (filter->proximity)) {
		filter->reacted		= true;
	}


	/* Wenn L�ngsregelung deaktiviert wird oder die Stoppstelle verschwindet, l�schen wir die �bernahmeaufforderung */
	if(    !(systemStatus == sysStatusActive || systemStatus == sysStatusOverride)
		|| !(proximityHold)) {
		filter->proximity	= false;
	}


	/* Ausgabe */
	*stopInRange		= inRange;
	*stopSweepPosition	= filter->sweepPosition;
	*takeoverRequest	= filter->proximity && !filter->reacted;


	return true;
}
