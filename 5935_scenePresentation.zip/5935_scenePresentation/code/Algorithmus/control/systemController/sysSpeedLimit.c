#include "control/systemController/sysSpeedLimit.h"
#include "control/systemController/sysSpeedLimitStatic.h"
#include "control/systemController/sysPreconditions.h"
#include "common/systemControllerCommon/sysInfo.h"
#include "common/vehicleObserverCommon/vobsDataInterface.h"

#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysSpeedLimit)

#define MINSPEEDLIMITDELTA (0.1389f) /**< Minimales plausibles Delta zwischen Geschwindigkeitslimits (0,5 km/h in [m/s]) */

bool_T			   sysUpdateSpeedLimits(IN	const	pathRouterMemory_T		*pathRouterMemory,
										IN	const	roadModelInfo_T			*roadModelInfo,
										IN	const	longControlStatus_T		*longControlStatus,
										IN	const	systemStatus_T			*systemStatus,
										IN	const	velocityGrid_T			*velocityGrid,
										IN	const	vehicleState_T			*vehicleState,
										IN	const	vehicleInput_T			*vehicleInput,
										INOUT		sysControlLimits_T		*speedLimits,
										OUT			limitInfo_T				*tmpSpeedLimitInfo)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	uint8_T mapInvalidReason;
	bool_T isCurrentLimitChange, isNextLimitChange, isNewLimitPassed;
	bool_T isMapDataValid, isRoadDataOk, isSpeedLimitOk, actualMapStatus;
	real32_T oldCurrentLimit, oldNextLimit;
	bool_T oldCurrentLowered, oldNextLowered;

	diagFF(sysIsMapDataValid(pathRouterMemory, &mapInvalidReason, &isMapDataValid));
	diagFF(sysIsRoadDataOk(vehicleInput, vehicleState, pathRouterMemory, &mapInvalidReason, &isRoadDataOk));
	diagFF(sysIsSpeedLimitOk(roadModelInfo, velocityGrid,	&mapInvalidReason, &isSpeedLimitOk));
	
	actualMapStatus =    (isMapDataValid || paramSet->systemController.status.allowOnBadData)
					  && (isRoadDataOk   || paramSet->systemController.status.allowOnBadRoad)
					  && (isSpeedLimitOk || paramSet->systemController.status.allowOnBadLimit);

	oldCurrentLimit	= speedLimits->currentLimit.value;
	oldNextLimit	= speedLimits->nextLimit.value;
	oldCurrentLowered = speedLimits->currentLimit.lowered;
	oldNextLowered	= speedLimits->nextLimit.lowered;

	diagFF(sysUpdateCurrentLimit( roadModelInfo,
								  actualMapStatus,
								  systemStatus->mapStatus.status,
								  systemStatus->status,
								  velocityGrid,
								  &speedLimits->currentLimit));

	diagFF(sysUpdateNextLimit(&speedLimits->nextLimit,
							  &speedLimits->previewPosition,
							  &speedLimits->previewLock,
							   vehicleState,
							   roadModelInfo,
							   longControlStatus,
							   velocityGrid,
							   actualMapStatus,
							   systemStatus->mapStatus.status,
							   systemStatus->status));

	if(sysFloatsAreEqual(speedLimits->nextLimit.value, speedLimits->currentLimit.value)) {
		speedLimits->nextLimit.valid	= false;
		speedLimits->nextLimit.position	= 0.0f;
		speedLimits->nextLimit.value	= 0.0f;
		speedLimits->nextLimit.raw		= rawLimitInvalid;
	}

	/*Hat sich das aktuelle Limit ge�ndert?*/
	isCurrentLimitChange = !sysFloatsAreEqual(oldCurrentLimit, speedLimits->currentLimit.value);
	isCurrentLimitChange = (speedLimits->currentLimit.lowered && !oldCurrentLowered) || isCurrentLimitChange;
	isCurrentLimitChange = (!speedLimits->currentLimit.lowered && oldCurrentLowered) || isCurrentLimitChange;

	/*Hat sich das zuk�nftige Limit ge�ndert?*/
	isNextLimitChange    = !sysFloatsAreEqual(oldNextLimit, speedLimits->nextLimit.value);
	isNextLimitChange	 = (speedLimits->nextLimit.lowered && !oldNextLowered) || isNextLimitChange;
	isNextLimitChange	 = (!speedLimits->nextLimit.lowered && oldNextLowered) || isNextLimitChange;

	/*Wurde ein neues Limit passiert? Dazu: Ist zuk�nftige Limit das aktuelle geworden UND hat sich das aktuelle Limit dadurch ge�ndert?*/
	isNewLimitPassed	 = sysFloatsAreEqual(oldNextLimit, speedLimits->currentLimit.value);
	isNewLimitPassed	 = isNewLimitPassed && isCurrentLimitChange ? true : false;
	isNewLimitPassed	 = isNewLimitPassed && speedLimits->currentLimit.valid;

	tmpSpeedLimitInfo->isCurrentLimitChange = isCurrentLimitChange;
	tmpSpeedLimitInfo->isNextLimitChange	= isNextLimitChange;
	tmpSpeedLimitInfo->isNewLimitPassed		= isNewLimitPassed;

	return true;
}


static bool_T	  sysUpdateCurrentLimit(IN	const	roadModelInfo_T			*roadModelInfo,
										IN	const	bool_T					 actualMapStatus,
										IN	const	bool_T					 mapDataValid,
										IN	const	sysStatus_T				 status,
										IN	const	velocityGrid_T			*grid,
										INOUT		limitItem_T				*currentLimit)
{
	real32_T		egoPosition, limit;
	uint16_T		raw;
	bool_T			statusValid, limitValid;
	vobsSignUnit_T	unit;
	bool_T			lowered;


	/*Hole Referenzposition*/
	sysRoadInfoGetRefPosition(roadModelInfo, &egoPosition);

	/*Hole Tempolimits*/
	limitValid = sysRoadInfoGetLimit(roadModelInfo, egoPosition, &limit, &raw, &unit);
	if (grid->maxAutoSpeed < limit)
	{
		limit = grid->maxAutoSpeed;
		lowered = true;
	} else {
		limit = limit;
		lowered = false;
	}

	/*Systemstatus passend?*/
	statusValid = status != sysStatusNotAvailable  &&  status != sysStatusDisabled;
	
	if (actualMapStatus && statusValid && limitValid) {
		/*Limit setzen.*/
		currentLimit->valid		= true;
		currentLimit->position	= egoPosition;
		currentLimit->value		= limit;
		currentLimit->raw		= raw;
		currentLimit->unit		= unit;
		currentLimit->lowered	= lowered;
	}
	else if ((!mapDataValid || !statusValid) && (status != sysStatusOverride))
	{
		/*Limit ung�ltig setzen.*/
		currentLimit->valid		= false;
		currentLimit->position	= 0.0f;
		currentLimit->value		= 0.0f;
		currentLimit->raw		= rawLimitInvalid;
		currentLimit->unit		= signUnitUnknown;
		currentLimit->lowered	= false;
	}
	else
	{
		return true;
	}

	return true;
}


static bool_T	 sysUpdateNextLimit(INOUT		limitItem_T				*nextLimit,
									INOUT		real32_T				*previewPosition,
									INOUT		bool_T					*previewLock,
									IN	const	vehicleState_T			*vehicleState,
									IN	const	roadModelInfo_T			*roadModelInfo,
									IN	const	longControlStatus_T		*longControlStatus,
									IN	const	velocityGrid_T			*grid,
									IN	const	bool_T					 actualMapStatus,
									IN	const	bool_T					 mapDataValid,
									IN	const	sysStatus_T				 status)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	real32_T	egoPosition;
	real32_T	refPosition;
	real32_T	egoVelocity;

	real32_T	adjPreviewPos;
	real32_T	previewMax;
	real32_T	previewMin;
	real32_T	previewCand;
	real32_T	revertPosition;

	real32_T		limitValue;
	real32_T		limitPosition;
	uint16_T		limitRaw;
	vobsSignUnit_T	limitUnit;

	bool_T		statusValid;
	bool_T		limitValid;

	bool_T		validTrigger;
	bool_T		validHold;

	real32_T	posLockTrigger;
	real32_T	posLockHold;

	bool_T		lockTrigger;
	bool_T		lockHold;
	bool_T		lowered;
	
	const uint16_T oldRaw = nextLimit->raw;

	/* Hole Referenzposition und Geschwindigkeit */
	sysRoadInfoGetRefPosition(roadModelInfo, &refPosition);
	vobsGetPosition(vehicleState, &egoPosition);
	vobsGetVelocity(vehicleState, &egoVelocity);

	refPosition = min(refPosition, egoPosition);


	/* Hole Tempolimits */
	diagFF(sysRoadInfoGetNextLimit(	 roadModelInfo,
									 refPosition,
									&limitValid,
									&limitValue,
									&limitPosition,
									&limitRaw,
									&limitUnit));
	if (grid->maxAutoSpeed < limitValue)
	{
		limitValue = grid->maxAutoSpeed;
		lowered = true;
	} else {
		limitValue = limitValue;
		lowered = false;
	}

	/* Systemstatus passend? */
	statusValid	 = status == sysStatusActive || status == sysStatusOverride;


	/* Berechnen des zul�ssigen Fensters f�r den Vorausschauhorizont */
	previewMax		= refPosition + (egoVelocity * paramSet->systemController.limitPreview.timeMax);
	previewMin		= refPosition + (egoVelocity * paramSet->systemController.limitPreview.timeMin);

	previewMax		= max(previewMax, refPosition + paramSet->systemController.limitPreview.distanceMin);
	previewMin		= max(previewMin, refPosition + paramSet->systemController.limitPreview.distanceMin);

	adjPreviewPos	= min(longControlStatus->previewPosition, limitPosition) + paramSet->systemController.limitPreview.positionOffset;
	previewCand		= longControlStatus->valid ? adjPreviewPos : previewMin;
	previewCand		= min(previewCand, previewMax);
	previewCand		= max(previewCand, previewMin);

	previewCand		= max(previewCand, *previewPosition);


	/* Berechnen der Fensters f�r die R�ckhalteanfroderung ovn Vorausschauevents */
	posLockTrigger	= previewCand + (egoVelocity * paramSet->systemController.previewLock.timeTrigger);
	posLockHold		= posLockTrigger + paramSet->systemController.previewLock.revertThreshold;


	/* Zus�tzliche Hysteresedistanz f�r die R�cknahme bereits gemeldeter Limits */
	revertPosition	= previewCand + paramSet->systemController.limitPreview.revertThreshold;


	/* N�chstes Limit im Vorausschauhorizont? */
	validTrigger	= limitPosition < previewCand;
	validHold		= limitPosition < revertPosition;

	/*Limit darf nur festgehalten werden, wenn auch der Wert tats�chlich dem alten Limit entspricht*/
	validHold		= (limitRaw == oldRaw)  &&  validHold;

	/* N�chstes Limit im Lock-Horizont? */
	lockTrigger		= limitPosition < posLockTrigger;
	lockHold		= limitPosition < posLockHold;


	if(limitValid && actualMapStatus && statusValid && validTrigger) {
		/*Limit �bernehmen*/
		nextLimit->valid	= true;
		nextLimit->position	= limitPosition;
		nextLimit->value	= limitValue;
		nextLimit->raw		= limitRaw;
		nextLimit->unit		= limitUnit;
		nextLimit->lowered	= lowered;
	}
	else if(!limitValid || !mapDataValid || !statusValid || !validHold) {
		/*Limit ung�ltig machen*/
		nextLimit->valid	= false;
		nextLimit->position	= 0.0f;
		nextLimit->value	= 0.0f;
		nextLimit->raw		= rawLimitInvalid;
		nextLimit->unit		= signUnitUnknown;
		nextLimit->lowered	= false;;
	}
	else {
		/*Limit beibehalten (Zeit verdummen)*/
		nextLimit->valid	= nextLimit->valid;
		nextLimit->position	= nextLimit->position;
		nextLimit->value	= nextLimit->value;
		nextLimit->raw		= nextLimit->raw;
		nextLimit->unit		= nextLimit->unit;
		nextLimit->lowered	= nextLimit->lowered;
	}


	if(limitValid && mapDataValid && statusValid && lockTrigger) {
		*previewLock = true;
	}
	else if(!limitValid || !mapDataValid || !statusValid || !lockHold) {
		*previewLock = false;
	}
	else {
		*previewLock = *previewLock;
	}


	/* Wenn wir ein neues Limit ausgeben, nehmen wir die Halteanforderung auf jeden Fall zur�ck */
	if(nextLimit->valid) {
		*previewLock = false;
	}
	else {
		*previewLock = *previewLock;
	}


	/* Aktualisieren der Vorausschauposition */
	*previewPosition = previewCand;

	return true;
}


static bool_T		  sysFloatsAreEqual(IN	const	real32_T				 floatA,
										IN	const	real32_T				 floatB)
{
	const real32_T diff = floatA - floatB;
	return (fabsf(diff) < MINSPEEDLIMITDELTA) ? true : false;
}
