#ifndef guard_systemController_h
#define guard_systemController_h

#include "control/control.h"

#include "common/systemControllerCommon/systemController_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/pathRouterCommon/pathRouter_interface.h"
#include "control/inputCodec/inputCodec_interface.h"




/**\brief Initialisiert und aktualisiert den Aktivierungszustand und die Setzgeschwindigkeit des Systems Innodrive2

Die Funktion beinhaltet hierbei unter anderem folgende Funktionalit�ten:
- Initialisierung der Daten zu Laufzeitbeginn oder nach Fehler \ref sysInit()
- Zustandskontrolle L�ngsregelung(Aktivierung, Deaktivierung, �berdr�ckung Gaspedal) \ref sysEvalSystemStatus()
- Aktualisierung Setzgeschwindigkeit aufgrund gespeicherter Setzgeschwindigkeiten und �bernahme Tempolimits aus Karte(Fahrerbest�tigung oder Autoapply-Mode) \ref sysUpdateSetSpeedControl()
- Anpassung der Setzgeschwindigkeit aufgrund Fahreranforderungen driverInput.tipUp und driverInput.tipDown \ref systemController_input
- Verwaltung des AgroIndex (Charisma-Fahrprogramm) \ref sysOutput()
- Verwaltung der vergangenen und zuk�nftigen Setzgeschwindigkeit zur Weiterverabreitung im constraintMaster \ref sysOutput()

\spec SwMS_Innodrive2_Control_54

\ingroup systemController_step
*/
void			systemController(	IN	const	vehicleInput_T			*vehicleInput,			/**< Datenstruktur vehicleInput(hier: Fahrereingriffe driverInput, lateralControl.driverInput, velocityInfo) */
									IN	const	vehicleState_T			*vehicleState,			/**< Datenstruktur des Moduls vehicleObserver */
									IN	const	pathRouterMemory_T		*pathRouterMemory,		/**< Linearisierte Kartendaten */
									IN	const	roadModelInfo_T			*roadModelInfo,			/**< Struktur mit kurzem Horizont der Karteninformationen(PSD-Steigung, Kurvenkr�mmung, Tempolimits) */
									IN	const	longControlStatus_T		*longControlStatus,		/**< Statusr�ckmeldung der L�ngsregelung */
									INOUT		systemControlMemory_T	*memory,				/**< Interner Status des SystemController */
									OUT			systemControl_T			*systemControl,			/**< Fl�chtige Ausgangsdaten des SystemController */
									OUT			fodOutput_T				*fodOutput				/**< Ausgangsdaten f�r Funktion on Demand */
									);

#endif
