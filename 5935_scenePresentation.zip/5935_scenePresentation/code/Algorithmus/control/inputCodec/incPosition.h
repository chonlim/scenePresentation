#ifndef guard_incPosition_h
#define guard_incPosition_h

/**\brief �bertr�gt Informationen zur Positionierung auf der Fahrspur

Ersatzwerte
\spec SwMS_Innodrive2_Input_258

Signale
\spec SwMS_Innodrive2_Input_354
\spec SwMS_Innodrive2_Input_355
\spec SwMS_Innodrive2_Input_356
\spec SwMS_Innodrive2_Input_357

\ingroup incPosition
*/
void			 incGetPosition(IN	const	lapInput_T				*lap,
								OUT			positionInput_T			*position);


/**\brief Setzt Ersatzwerte f�r alle Signale

\spec SwMS_Innodrive2_Input_258

\ingroup incPosition
*/
void			incInitPosition(OUT			positionInput_T			*position);


/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incRoad
*/
void		incOverridePosition(OUT			positionInput_T			*position);


#endif
