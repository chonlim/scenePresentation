#include "inputCodec.h"
#include "inputCodec_private.h"

#include "incCamera.h"

#include "control/parameterSet/parameterSetCtrl.h"


void			   incGetCamera(IN	const	laneInput_T				*laneInput,
								OUT			cameraInput_T			*camera)
{
	uint16_T	index;

	uint8_T		bestLeft;
	uint8_T		bestRight;
	real32_T	distanceLeft;
	real32_T	distanceRight;


	bestLeft		=  INVALID_UINT8;
	bestRight		=  INVALID_UINT8;
	distanceLeft	= -INVALID_VALUE;
	distanceRight	=  INVALID_VALUE;


	/* Wir suchen nach den Linien, die links und rechts am n�chsten am Fahrzeug liegen */
	for(index = 0; index < (uint16_T)incNUMLANEBOUNDARIES; index++) {
		/* Die Linie liegt links von uns */
		if(laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeStartPositionY < 0.0f) {
			if(   (laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeStartPositionY > distanceLeft)
			   && (laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeValid)
			   && (laneInput->DeLaneBoundary[index].DeNumSegments > 0u)
			   && (index < laneInput->DeNumLaneBoundaries)) {
				distanceLeft	= laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeStartPositionY;
				bestLeft		= (uint8_T)index;
			}
		}
		else {
			if(   (laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeStartPositionY < distanceRight)
			   && (laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeValid)
			   && (laneInput->DeLaneBoundary[index].DeNumSegments > 0u)
			   && (index < laneInput->DeNumLaneBoundaries)) {
				distanceRight	= laneInput->DeLaneBoundary[index].DeLaneSegments[0].DeStartPositionY;
				bestRight		= (uint8_T)index;
			}
		}
	}

	if (laneInput->DeNumLaneBoundaries > 12u)
	{
		bestLeft		=  INVALID_UINT8;
		bestRight		=  INVALID_UINT8;
	}

	/* Gefundene Linien auf die interne Schnittstelle mappen */
	if(		bestLeft < (uint16_T)incNUMLANEBOUNDARIES
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeLength >= 0.0f
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeLength <= 50.0f
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeClothoidStartCurvature >= -0.03125f
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeClothoidStartCurvature <= 0.031219482421875f
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeClothoidCurvatureChange >= -0.0009765625
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeClothoidCurvatureChange <= 0.00097560882568359375f
		&&	laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeStartPositionY >= -8.0f)
	{
		camera->lineLeft.valid			= true;
		camera->lineLeft.curvature		= laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeClothoidStartCurvature;
		camera->lineLeft.curveRate		= laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeClothoidCurvatureChange;
		camera->lineLeft.length			= laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeLength;
		camera->lineLeft.distance		= laneInput->DeLaneBoundary[bestLeft].DeLaneSegments[0].DeStartPositionY;
	}
	else {
		camera->lineLeft.valid			= false;
		camera->lineLeft.curvature		= 0.0f;
		camera->lineLeft.curveRate		= 0.0f;
		camera->lineLeft.length			= 0.0f;
		camera->lineLeft.distance		= 0.0f;
	}


	if(		bestRight < (uint16_T)incNUMLANEBOUNDARIES
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeLength >= 0.0f
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeLength <= 50.0f
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeClothoidStartCurvature >= -0.03125f
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeClothoidStartCurvature <= 0.031219482421875f
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeClothoidCurvatureChange >= -0.0009765625
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeClothoidCurvatureChange <= 0.00097560882568359375f
		&&	laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeStartPositionY <= 7.9921875f)
	{
		camera->lineRight.valid			= true;
		camera->lineRight.curvature		= laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeClothoidStartCurvature;
		camera->lineRight.curveRate		= laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeClothoidCurvatureChange;
		camera->lineRight.length		= laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeLength;
		camera->lineRight.distance		= laneInput->DeLaneBoundary[bestRight].DeLaneSegments[0].DeStartPositionY;
	}
	else {
		camera->lineRight.valid			= false;
		camera->lineRight.curvature		= 0.0f;
		camera->lineRight.curveRate		= 0.0f;
		camera->lineRight.length		= 0.0f;
		camera->lineRight.distance		= 0.0f;
	}
}


void			 incInitCamera(OUT			cameraInput_T			*camera)
{
	camera->lineLeft.valid			= false;
	camera->lineLeft.curvature		= 0.0f;
	camera->lineLeft.curveRate		= 0.0f;
	camera->lineLeft.length			= 0.0f;
	camera->lineLeft.distance		= 0.0f;

	camera->lineRight.valid			= false;
	camera->lineRight.curvature		= 0.0f;
	camera->lineRight.curveRate		= 0.0f;
	camera->lineRight.length		= 0.0f;
	camera->lineRight.distance		= 0.0f;
}


void			incOverrideCamera(INOUT		cameraInput_T			*camera)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if (paramSet->inputCodec.camera.lineLeft.valid.override)
	{
		camera->lineLeft.valid = paramSet->inputCodec.camera.lineLeft.valid.value;
	}

	if (paramSet->inputCodec.camera.lineLeft.curvature.override)
	{
		camera->lineLeft.curvature = paramSet->inputCodec.camera.lineLeft.curvature.value;
	}

	if (paramSet->inputCodec.camera.lineLeft.curveRate.override)
	{
		camera->lineLeft.curveRate = paramSet->inputCodec.camera.lineLeft.curveRate.value;
	}

	if (paramSet->inputCodec.camera.lineLeft.length.override)
	{
		camera->lineLeft.length = paramSet->inputCodec.camera.lineLeft.length.value;
	}

	if (paramSet->inputCodec.camera.lineLeft.distance.override)
	{
		camera->lineLeft.distance = paramSet->inputCodec.camera.lineLeft.distance.value;
	}


	if (paramSet->inputCodec.camera.lineRight.valid.override)
	{
		camera->lineRight.valid = paramSet->inputCodec.camera.lineRight.valid.value;
	}

	if (paramSet->inputCodec.camera.lineRight.curvature.override)
	{
		camera->lineRight.curvature = paramSet->inputCodec.camera.lineRight.curvature.value;
	}

	if (paramSet->inputCodec.camera.lineRight.curveRate.override)
	{
		camera->lineRight.curveRate = paramSet->inputCodec.camera.lineRight.curveRate.value;
	}

	if (paramSet->inputCodec.camera.lineRight.length.override)
	{
		camera->lineRight.length = paramSet->inputCodec.camera.lineRight.length.value;
	}

	if (paramSet->inputCodec.camera.lineRight.distance.override)
	{
		camera->lineRight.distance = paramSet->inputCodec.camera.lineRight.distance.value;
	}
}
