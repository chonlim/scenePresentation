#ifndef guard_incPowertrain_h
#define guard_incPowertrain_h


/**\brief �bertr�gt Informationen zum Triebstrangzustand

Ersatzwerte
\spec SwMS_Innodrive2_Input_258

Signale
\spec SwMS_Innodrive2_Input_138
\spec SwMS_Innodrive2_Input_139
\spec SwMS_Innodrive2_Input_140
\spec SwMS_Innodrive2_Input_180
\spec SwMS_Innodrive2_Input_181
\spec SwMS_Innodrive2_Input_184
\spec SwMS_Innodrive2_Input_185
\spec SwMS_Innodrive2_Input_256
\spec SwMS_Innodrive2_Input_382
\spec SwMS_Innodrive2_Input_375
\spec SwMS_Innodrive2_Input_377

\ingroup incPowertrain
*/
void		   incGetPowertrain(IN	const	flexrayInput_T			*flexray,
								OUT			powertrainInput_T		*powertrain);


/**\brief Setzt Ersatzwerte f�r alle Signale

\spec SwMS_Innodrive2_Input_258

\ingroup incPowertrain
*/
void		  incInitPowertrain(OUT			powertrainInput_T		*powertrain);


/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incPowertrain
*/
void	  incOverridePowertrain(INOUT		powertrainInput_T		*powertrain);


#endif
