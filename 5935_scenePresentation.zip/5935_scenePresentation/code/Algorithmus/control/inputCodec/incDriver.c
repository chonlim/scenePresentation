#include "control/inputCodec/inputCodec.h"
#include "control/inputCodec/inputCodec_private.h"

#include "control/inputCodec/incDriver.h"
#include "control/inputCodec/incDriverStatic.h"

#include "control/parameterSet/parameterSetCtrl.h"

#include <Rte_Type.h>
#include <BusSignals_enums.h>
#include <BusSignals_status.h>


void			   incGetDriver(IN	const	flexrayInput_T			*flexray,
								OUT			driverInput_T			*driver)
{
	if((  (flexray->DeStatus_Motor20 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Motor20 == (uint8_T)PDUSTATE_NOT_UPDATED)
	   )
	   && (flexray->DeMO_Fahrpedalrohwert_01 >= DeFRInnoDriveIn_DeMO_Fahrpedalrohwert_01_RANGE_MIN)
	   && (flexray->DeMO_Fahrpedalrohwert_01 <= DeFRInnoDriveIn_DeMO_Fahrpedalrohwert_01_RANGE_MAX))
	{
		driver->accelerator = flexray->DeMO_Fahrpedalrohwert_01;
	}
	else {
		driver->accelerator = 0.0f;
		}


	if(   (flexray->DeStatus_ACC16 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_ACC16 == (uint8_T)PDUSTATE_NOT_UPDATED))
	{
		if (flexray->DeACC_vLimit1_PACC == DeFRInnoDriveIn_DeACC_vLimit1_PACC_DEFAULT) {
			driver->maxAutoSpeed = INVALID_VALUE;
		} else {
			driver->maxAutoSpeed = (real32_T)flexray->DeACC_vLimit1_PACC * KPH_TO_MPS;
		}

		driver->autoMode = (flexray->DeACC_Nutzung_VZ_PACC == DeFRInnoDriveIn_DeACC_Nutzung_VZ_PACC_RANGE_MIN /* Nutzung_VZ_aktiv */); /*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/

	}
	else {
		driver->maxAutoSpeed = INVALID_VALUE;
		driver->autoMode = false;
	}


	if(   (flexray->DeStatus_GRAACC01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_GRAACC01 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		driver->resume	= (flexray->DeGRA_Tip_Wiederaufnahme	== DeFRInnoDriveIn_DeGRA_Tip_Wiederaufnahme_RANGE_MAX	/* bet�tigt */); /*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
		driver->set		= (flexray->DeGRA_Tip_Setzen			== DeFRInnoDriveIn_DeGRA_Tip_Setzen_RANGE_MAX			/* bet�tigt */); /*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
		driver->tipDown	= (flexray->DeGRA_Tip_Runter			== DeFRInnoDriveIn_DeGRA_Tip_Runter_RANGE_MAX			/* bet�tigt */); /*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
		driver->tipUp	= (flexray->DeGRA_Tip_Hoch				== DeFRInnoDriveIn_DeGRA_Tip_Hoch_RANGE_MAX				/* bet�tigt */); /*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
	}
	else {
		driver->resume	= false;
		driver->set		= false;
		driver->tipDown	= false;
		driver->tipUp	= false;
	}


	if(   (flexray->DeStatus_TSK06 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_TSK06 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		driver->enabled	= (flexray->DeTSK_Hauptschalter_GRA_ACC	== DeFRInnoDriveIn_DeTSK_Hauptschalter_GRA_ACC_Cx2_Ein	/* Hauptschalter ein */);
	}
	else {
		driver->enabled	= false;
	}

	if(   (flexray->DeStatus_Kombi02 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Kombi02 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		if (flexray->DeKBI_aktive_Laengsfunktion	== DeFRInnoDriveIn_DeKBI_aktive_Laengsfunktion_Cx3_PACCh) {
			driver->selected = true;
		} else {
			driver->selected = false;
		}
	}
	else {
		driver->selected = false;
	}

	if(   (flexray->DeStatus_Kombi01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Kombi01 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		if		(flexray->DeKBI_Einheit_Tacho == 0x0u) { driver->displayUnit = dsplUnitKph; }
		else if (flexray->DeKBI_Einheit_Tacho == 0x1u) { driver->displayUnit = dsplUnitMph; }
		else										   { driver->displayUnit = dsplUnitMph; }
	}
	else {
		driver->displayUnit = dsplUnitMph;
	}


	if(   (flexray->DeStatus_Charisma08 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Charisma08 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		/* Mapping der "externen" auf die "internen" Fahrprogramme */
		if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx0_keine_Funktion)	{ driver->charisma = charismaNormal; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx1_Programm_1)	{ driver->charisma = charismaEconomy; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx2_Programm_2)	{ driver->charisma = charismaNormal; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx3_Programm_3)	{ driver->charisma = charismaDynamic; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx4_Programm_4)	{ driver->charisma = charismaEconomy; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx5_Programm_5)	{ driver->charisma = charismaNormal; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx6_Programm_6)	{ driver->charisma = charismaDynamic; }
		else if (flexray->DeCHA_Ziel_FahrPr_PACC == (uint8_T)DeFRInnoDriveIn_DeCHA_Ziel_FahrPr_PACC_Cx7_Programm_7)	{ driver->charisma = charismaDynamic; }
		else																										{ driver->charisma = charismaNormal; }
	}
	else {
		driver->charisma		= charismaNormal;
	}


	if(   (flexray->DeStatus_ACC12 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_ACC12 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		if(		flexray->DeACC_Gesetzte_Zeitluecke == DeFRInnoDriveIn_DeACC_Gesetzte_Zeitluecke_Cx1_Zeitluecke_1)	{ driver->followingGap = 0; }
		else if(flexray->DeACC_Gesetzte_Zeitluecke == DeFRInnoDriveIn_DeACC_Gesetzte_Zeitluecke_Cx2_Zeitluecke_2)	{ driver->followingGap = 1; }
		else if(flexray->DeACC_Gesetzte_Zeitluecke == DeFRInnoDriveIn_DeACC_Gesetzte_Zeitluecke_Cx3_Zeitluecke_3)	{ driver->followingGap = 2; }
		else if(flexray->DeACC_Gesetzte_Zeitluecke == DeFRInnoDriveIn_DeACC_Gesetzte_Zeitluecke_Cx4_Zeitluecke_4)	{ driver->followingGap = 3; }
		else if(flexray->DeACC_Gesetzte_Zeitluecke == DeFRInnoDriveIn_DeACC_Gesetzte_Zeitluecke_Cx5_Zeitluecke_5)	{ driver->followingGap = 4; }
		else																										{ driver->followingGap = 4; }
	}
	else {
		driver->followingGap = 4;
	}


	if(   (flexray->DeStatus_Blinkmodi02 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Blinkmodi02 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		if(     flexray->DeBM_links == DeFRInnoDriveIn_DeBM_links_RANGE_MAX)	{ driver->turnSignal = turnSignalLeft; }	/*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
		else if(flexray->DeBM_rechts == DeFRInnoDriveIn_DeBM_rechts_RANGE_MAX)	{ driver->turnSignal = turnSignalRight; }	/*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
		else																	{ driver->turnSignal = turnSignalNone; }

		if(flexray->DeBM_Autobahn == DeFRInnoDriveIn_DeBM_Autobahn_RANGE_MAX)	{ driver->signalLocked = false; }			/*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
		else																	{ driver->signalLocked = true; }
	}


	if(   (flexray->DeStatus_TSK08 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_TSK08 == (uint8_T)PDUSTATE_NOT_UPDATED)) 
	{
		if		(flexray->DeTSK_Einheit_vMax_Fahrerassistenz == 0x0u)	{ driver->vMaxUnit = dsplUnitKph; }
		else if (flexray->DeTSK_Einheit_vMax_Fahrerassistenz == 0x1u)	{ driver->vMaxUnit = dsplUnitMph; }
		else															{ driver->vMaxUnit = dsplUnitMph; }

		if (   (flexray->DeTSK_vMax_Fahrerassistenz >= DeFRInnoDriveIn_DeTSK_vMax_Fahrerassistenz_RANGE_MIN) /*lint !e685 !e568: (Warning -- Relational operator '>=' always evaluates to 'true' [MISRA 2012 Rule 14.3, required])*/
			&& (flexray->DeTSK_vMax_Fahrerassistenz <= DeFRInnoDriveIn_DeTSK_vMax_Fahrerassistenz_RANGE_MAX))
		{
			driver->vMaxRaw = flexray->DeTSK_vMax_Fahrerassistenz;
		} else {
			driver->vMaxRaw = 511;
		}
	}
#ifdef DeFRInnoDriveIn_DeSTP_Status_Cx0_STP_Init
	if(   (flexray->DeStatus_STP01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_STP01 == (uint8_T)PDUSTATE_NOT_UPDATED)) 
	{
		driver->stpStatus = incDrvGetStpStatus(flexray->DeSTP_Status);
	}
#endif

	driver->ignoreCountry = false;
}


static stpStatus_T	incDrvGetStpStatus(	IN const	uint8_T		DeSTP_Status)
{
	stpStatus_T status;

	switch (DeSTP_Status)
	{
	case DeFRInnoDriveIn_DeSTP_Status_Cx0_STP_Init:						{ status = stpStatusInit					; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx1_STP_Deaktiviert:				{ status = stpStatusInactive				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx2_Vorhalt:						{ status = stpStatusNotAssigned2			; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx3_STP_Nicht_Aktivierbar:		{ status = stpStatusNotAvailable			; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx4_Vorhalt:						{ status = stpStatusNotAssigned4			; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx5_STP_Aktivierbar:				{ status = stpStatusAvailable				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx6_STP_Aktiv:					{ status = stpStatusActive					; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx7_STP_Aktivierung:				{ status = stpStatusActivation				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx8_STP_Aktiv_ESK0:				{ status = stpStatusActiveEsc0				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_Cx9_STP_Aktiv_ESK1:				{ status = stpStatusActiveEsc1				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_CxA_STP_Aktiv_ESK2:				{ status = stpStatusActiveEsc2				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_CxB_STP_Aktiv_ESK3:				{ status = stpStatusActiveEsc3				; break; }
	case DeFRInnoDriveIn_DeSTP_Status_CxC_STP_Aktiv_Notlauf:			{ status = stpStatusEmergencyOperation		; break; }
	case DeFRInnoDriveIn_DeSTP_Status_CxD_STP_Aktiv_Stabiler_Zustand:	{ status = stpStatusStable					; break; }
	case DeFRInnoDriveIn_DeSTP_Status_CxE_STP_Aktiv_Uebernahme:			{ status = stpStatusActiveTakeover			; break; }
	case DeFRInnoDriveIn_DeSTP_Status_CxF_STP_Fehler:					{ status = stpStatusError					; break; }
	default :															{ status = stpStatusInit					; break; }
	}

	return status;
}

void			incGetDriverFoD(IN	const	fodInput_T				*fod,
								OUT			driverInput_T			*driver)
{
	if (fod->DeFoDActivation_InnoDrive2 == FOD_STATE_INIT) {
		driver->fodActivation	= false;
		driver->fodInitialized	= false;
	}
	else if (fod->DeFoDActivation_InnoDrive2 == FOD_STATE_ACTIVATED) {
		driver->fodActivation	= true;
		driver->fodInitialized	= true;
	}
	else if (fod->DeFoDActivation_InnoDrive2 == FOD_STATE_NOT_ACTIVATED) {
		driver->fodActivation	= false;
		driver->fodInitialized	= true;
	}
	else {
		driver->fodActivation	= false;
		driver->fodInitialized	= false;
	}

	if (!fod->DeFoDFunctionRelevant) {
		driver->fodActivation	= true;
	}
}


void			  incInitDriver(OUT			driverInput_T			*driver)
{
	driver->accelerator			= 0.0f;
	driver->autoMode			= false;
	driver->charisma			= charismaNormal;
	driver->displayUnit			= dsplUnitMph;
	driver->enabled				= false;
	driver->followingGap		= 4;
	driver->maxAutoSpeed		= INVALID_VALUE;
	driver->resume				= false;
	driver->set					= false;
	driver->selected			= false;
	driver->tipUp				= false;
	driver->tipDown				= false;
	driver->turnSignal			= turnSignalNone;
	driver->vMaxRaw				= 511;
	driver->vMaxUnit			= dsplUnitMph;
	driver->valid				= false;
	driver->signalLocked		= true;
	driver->ignoreCountry		= false;
	driver->fodActivation		= false;
	driver->fodInitialized		= false;
	driver->stpStatus			= stpStatusInit;
}


void		  incOverrideDriver(INOUT		driverInput_T			*driver)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if(paramSet->inputCodec.driver.valid.override) {
		driver->valid			= paramSet->inputCodec.driver.valid.value;
	}

	if(paramSet->inputCodec.driver.enabled.override) {
		driver->enabled			= paramSet->inputCodec.driver.enabled.value;
	}

	if(paramSet->inputCodec.driver.selected.override) {
		driver->selected		= paramSet->inputCodec.driver.selected.value;
	}

	if(paramSet->inputCodec.driver.tipUp.override) {
		driver->tipUp			= paramSet->inputCodec.driver.tipUp.value;
	}

	if(paramSet->inputCodec.driver.tipDown.override) {
		driver->tipDown			= paramSet->inputCodec.driver.tipDown.value;
	}

	if(paramSet->inputCodec.driver.enabled.override) {
		driver->enabled			= paramSet->inputCodec.driver.enabled.value;
	}

	if(paramSet->inputCodec.driver.set.override) {
		driver->set				= paramSet->inputCodec.driver.set.value;
	}

	if (paramSet->inputCodec.driver.maxAutoSpeed.override) {
		driver->maxAutoSpeed	= paramSet->inputCodec.driver.maxAutoSpeed.value;
	}

	if(paramSet->inputCodec.driver.resume.override) {
		driver->resume			= paramSet->inputCodec.driver.resume.value;
	}

	if(paramSet->inputCodec.driver.followingGap.override) {
		driver->followingGap	= paramSet->inputCodec.driver.followingGap.value;
	}

	if(paramSet->inputCodec.driver.charisma.override) {
		switch(paramSet->inputCodec.driver.charisma.value) {
			case 0:		driver->charisma = charismaNormal;		break;
			case 1:		driver->charisma = charismaDynamic;		break;
			case 2:		driver->charisma = charismaEconomy;		break;
			default:	driver->charisma = charismaNormal;		break;
		}
	}

	if(paramSet->inputCodec.driver.autoMode.override) {
		driver->autoMode		= paramSet->inputCodec.driver.autoMode.value;
	}

	if (paramSet->inputCodec.driver.turnSignal.override) {
		switch(paramSet->inputCodec.driver.turnSignal.value)
		{
			case 0:		driver->turnSignal = turnSignalNone;		break;
			case 1:		driver->turnSignal = turnSignalLeft;		break;
			case 2:		driver->turnSignal = turnSignalRight;		break;
			default:	driver->turnSignal = turnSignalNone;		break;
		}
	}
	
	if(paramSet->inputCodec.driver.signalLocked.override) {
		driver->signalLocked	= paramSet->inputCodec.driver.signalLocked.value;
	}

	if(paramSet->inputCodec.driver.accelerator.override) {
		driver->accelerator		= paramSet->inputCodec.driver.accelerator.value;
	}

	if(paramSet->inputCodec.driver.displayUnit.override) {
		driver->displayUnit		= (paramSet->inputCodec.driver.displayUnit.value) ? dsplUnitKph : dsplUnitMph;
	}
		
	if(paramSet->inputCodec.driver.vMaxRaw.override) {
		driver->vMaxRaw			= paramSet->inputCodec.driver.vMaxRaw.value;
	}
	
	if(paramSet->inputCodec.driver.vMaxUnit.override) {
		driver->vMaxUnit		= (paramSet->inputCodec.driver.vMaxUnit.value) ? dsplUnitKph : dsplUnitMph;
	}
	
	if(paramSet->inputCodec.driver.ignoreCountry.override) {
		driver->ignoreCountry	= paramSet->inputCodec.driver.ignoreCountry.value;
	}

	if(paramSet->inputCodec.driver.fodActivation.override) {
		driver->fodActivation	= paramSet->inputCodec.driver.fodActivation.value;
	}
	
	if(paramSet->inputCodec.driver.fodInitialized.override) {
		driver->fodInitialized	= paramSet->inputCodec.driver.fodInitialized.value;
	}

	if(paramSet->inputCodec.driver.stpStatus.override) {
		driver->stpStatus = incDrvGetStpStatus(paramSet->inputCodec.driver.stpStatus.value);
	}
}


void		 incCodingOvrDriver(INOUT		driverInput_T			*driver,
								IN	const	codingInput_T			*codingInput)
{
	/* Wenn das Bit 0 der "Curve Profile"-Codierung gesetzt ist, 
	   wird der "selected"-Wert hart auf true gesetzt. */
	driver->selected		= (codingInput->ID_Curve_Profile == 1u || codingInput->ID_Curve_Profile == 3u) ? true  : driver->selected;


	/* Wenn das Bit 1 der "Curve Profile"-Codierung gesetzt ist, 
	   wird der Auto-Modus hart mit 180 km/h maximaler �bernahmegeschwindigkeit aktiviert. */
	driver->autoMode		= (codingInput->ID_Curve_Profile == 2u || codingInput->ID_Curve_Profile == 3u) ? true  : driver->autoMode;
	driver->maxAutoSpeed	= (codingInput->ID_Curve_Profile == 2u || codingInput->ID_Curve_Profile == 3u) ? 50.0f : driver->maxAutoSpeed;


	/* Wenn das Bit 1 der "Speed Limit Profile"-Codierung gesetzt ist,
	   wird die Flag zum Ignorieren des L�ndercodes gesetzt. */
	driver->ignoreCountry	= (codingInput->ID_SpeedLimit_Profile == 2u || codingInput->ID_SpeedLimit_Profile == 3u) ? true : driver->ignoreCountry;
}
