#ifndef guard_inputCodec_private_h
#define guard_inputCodec_private_h

#include "control/inputCodec/inputCodec_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */


typedef enum _charismaMode {
	charismaNormal = 0,
	charismaDynamic = 1,
	charismaEconomy = 2
} charismaMode_T;

typedef enum _stpStatus {
	stpStatusInit = 0,
	stpStatusInactive = 1,
	stpStatusNotAssigned2 = 2,
	stpStatusNotAvailable = 3,
	stpStatusNotAssigned4 = 4,
	stpStatusAvailable = 5,
	stpStatusActive = 6,
	stpStatusActivation = 7,
	stpStatusActiveEsc0 = 8,
	stpStatusActiveEsc1 = 9,
	stpStatusActiveEsc2 = 10,
	stpStatusActiveEsc3 = 11,
	stpStatusEmergencyOperation = 12,
	stpStatusStable = 13,
	stpStatusActiveTakeover = 14,
	stpStatusError = 15
} stpStatus_T;

typedef enum _accStatus {
	accStatusInit = 0,
	accStatusAvailable = 1,
	accStatusActive = 2,
	accStatusOverride = 3,
	accStatusBrakeOnly = 4,
	accStatusErrorReversible = 5,
	accStatusErrorIrreversible = 6
} accStatus_T;



struct _flexrayInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	real32_T DeHAL_Radwinkel;            /**< Zusaetzlich durch die HAL gestellter Radwinkeloffset an der Hinterachse in Grad[deg] */
	real32_T DeKBI_angez_Geschw;         /**< Im Tacho angezeigte Geschwindigkeit inklusive der Voreilung[km/h] */
	uint8_T DeKBI_aktive_Laengsfunktion; /**< Auswahl, der vom Fahrer gewuenschten Laengsregelfunktion */
	uint8_T DeKBI_Einheit_Tacho;         /**< Information, ob es sich um Meilen- oder Kmh-Kombi handelt, Einheit des Tachos entspricht dem Zifferblatt, Groesse ist nicht veraenderlich */
	real32_T DeLWI_Lenkradwinkel;        /**< Lenkradwinkel: spezifizierte Interne Aufloesung des Sensors betraegt aber nur Schrittweite 0,5 Grad! Hinweis: MLB: Zusaetzlich gestellte Winkel bei Dynamiklenkung beachten !MQB: Nicht konstante Lenkuebersetzung bei Progressivlenkung beachten. Signal bei Progressivlenkung auf den Lenkhub bezogen.[deg] */
	real32_T DeMO_Fahrpedalrohwert_01;   /**< Stellung des Fahrpedales (Rohwert, ohne ueberlagerung durch GRA-Eingriffe etc.)[%] */
	real32_T DeSDF1_Obj_01_BeschlRelX;   /**< Relative Beschleunigung in x (m/s) Geschwindigkeiten beziehen sich immer auf den Objektmittelpunkt Messung in Radialrichtung[m/s] */
	real32_T DeSDF1_Obj_01_GeschwRelX;   /**< Relative Geschwindigkeit in x (m/s) Geschwindigkeiten beziehen sich immer auf den Objektmittelpunkt Messung in Radialrichtung[m/s] */
	real32_T DeSDF1_Obj_01_PositionX;    /**< Position des Objektes in x-Richtung (Referenzpunkt der 3D-Objektbox)[m] */
	real32_T DeTSK_Steigung_02;          /**< Steigung in % Berg. Das Signal dient der Anpassung der Sollbeschleunigung vom ACC Positive Werte bergauf; Negative Werte bergab[%] */
	uint16_T DeTSK_vMax_Fahrerassistenz; /**< maximale Sollgeschwindigkeit fuer GRA/ACC/Limiter Hinweis: Signal ist mit Signal TSK_Einheit_vMax_Fahrerassistenz zu interpretieren.  Das Signal wird abwechselnd in km/h und mph gesendet. */
	uint8_T DeTSK_Einheit_vMax_Fahrerassistenz; /**< Einheit zu Signal TSK_vMax_Fahrerassistenz 0:kmh, 1:mph */
	uint16_T DeLWI_Lenkradw_Geschw;      /**< Lenkradwinkelgeschwindigkeit Hinweis: Zusaetzlich gestellte Winkel bei Dynamiklenkung beachten ![deg/s] */
	int16_T DeMO_Mom_Ist_Summe;          /**< Einheitenloser Wert! Ist-Moment als Summe aus Verbrennungsmotor und E-Motor (bei Hybrid-Konzepten) incl. allen Eingriffen und Korrekturen; definiert als Kupplungsmoment an Kurbelwelle nach Abgriff der Nebenaggregate[1] */
	uint16_T DeESP_VL_Bremsmoment;       /**< Bremsmoment VL[Nm] */
	uint16_T DeESP_VR_Bremsmoment;       /**< Bremsmoment VR[Nm] */
	uint16_T DeESP_HL_Bremsmoment;       /**< Bremsmoment HL[Nm] */
	uint16_T DeESP_HR_Bremsmoment;       /**< Bremsmoment HR[Nm] */
	uint8_T DeACC_Gesetzte_Zeitluecke;   /**< Nur in ADR/ACC-Fahrzeugen: ACC Zusatzanzeige: 0 = aus / ungleich 0 = ein; angezeigte ADR-Zeitluecke wird auf 3 Bits begrenzt */
	uint8_T DeACC_Status_ACC;            /**< Status ACC-Funktion */
	uint8_T DeACC_vLimit1_PACC;          /**< Vom Fahrer einstellbare maximale Geschwindigkeit fuer die Funktion PACC/InnoDrive.[km/h] */
	uint8_T DeCHA_Ziel_FahrPr_PACC;      /**< Ungenutzt. MQB Anforderung Ziel-Fahrprogramm ACC */
	uint8_T DeGE_Fahrstufe;              /**< Fahrprogramm des Getriebes */
	uint8_T DeGE_Freilauf_Status;        /**< Freilauf-Status-Signal vom Frailauf-Master an aktive Freilauf-Teilnehmer. In diesem Signal zeigt der Freilauf-Master an, welchen aktuellen Status die Freilauf-Betriebsstrategie hat. */
	uint8_T DeGE_Zielgang;               /**< Zielgang */
	uint8_T DeMO_Fahrzeugtyp;            /**< Fahrzeugtyp: 0:Verbrenner 1:Hybrid 2:Elektro 3:Elektro+RangeExtender 4:Brennstoffzelle 5-7:reserviert */
	uint8_T DeMO_Faktor_Momente_02;      /**< Dieses Signal schaltet den Wertebereich aller Momente vom Motor, Getriebe, TSK, Bremse ... um!  */
	uint8_T DeMO_Code;                   /**< COde des verbauten Motors */
	uint8_T DeSDF1_Obj_01_ID;            /**< ID des Objektes */
	uint8_T DeTSK_Hauptschalter_GRA_ACC; /**< Stellung des GRA/ACC Hauptschalters. Das Signal wird auch bei Fehlerabschaltungen von GRA/ACC weiterhin bedient und ermoeglicht fuer ACC die Steuerung der ACC-Anzeige auch in Fehlerfaellen. */
	bool_T DeACC_Nutzung_VZ_PACC;        /**< Einstellung, ob Verkehrszeichen von der Funktion PACC/InnoDrive verarbeitet werden sollen. */
	bool_T DeACC_Regelung_durch_PACC;    /**< Das Signal gibt an, ob ACC aktuell aufgrund einer InnoDrive-Anforderung regelt oder die ACC-Regler dominant sind. */
	bool_T DeBM_Autobahn;                /**< Status Autobahnblinken */
	bool_T DeBM_links;                   /**< Richtungsblinken links */
	bool_T DeBM_rechts;                  /**< Richtungsblinken rechts */
	bool_T DeESP_QBit_HL_Bremsmoment;    /**< QBit Bremsmoment HL */
	bool_T DeESP_QBit_HR_Bremsmoment;    /**< QBit Bremsmoment HR */
	bool_T DeESP_QBit_VL_Bremsmoment;    /**< QBit Bremsmoment VL */
	bool_T DeESP_QBit_VR_Bremsmoment;    /**< QBit Bremsmoment VR */
	bool_T DeHAL_QBit_Radwinkel;         /**< QBit Radwinkel */
	bool_T DeHAL_VZ_Radwinkel;           /**< Lenkrichtung der HAL (0: positv: links, 1: negativ: rechts) */
	bool_T DeGRA_Tip_Hoch;               /**< Tippschalter Tip Up / Geschwindigkeit erhoehen */
	bool_T DeGRA_Tip_Runter;             /**< Tippschalter Tip Down / Geschwindigkeit reduzieren */
	bool_T DeGRA_Tip_Setzen;             /**< Tippschalter Set */
	bool_T DeGRA_Tip_Wiederaufnahme;     /**< Tippschalter Wiederaufnahme */
	bool_T DeLWI_VZ_Lenkradwinkel;       /**< Vorzeichen Lenkradwinkel (0: positv: links, 1: negativ: rechts) */
	bool_T DeLWI_VZ_Lenkradw_Geschw;     /**< Vorzeichen Lenkradwinkelgeschwindigkeit (0: positv: links, 1: negativ: rechts) */
	int16_T DeEM1_MaxDyn_Moment;         /**< maximal darstellbares Moment fuer eine im Funktionslastenheft definierte Dauer[Nm] */
	real32_T DeEM1_IstMoment;            /**< Momentanwert: E-Maschinen Moment der E-Maschine 1[Nm] */
	real32_T DeEM2_IstMoment;            /**< Momentanwert: E-Maschinen Moment der E-Maschine 2[Nm] */
	bool_T DeMO_HYB_VM_aktiv;            /**< Verbrennungsmotor aktiv (ab erster Einspritzung, auch bei Schubbetrieb */
	bool_T DeCHA_EV_LED;                 /**< Ansteuerung der LED am EV-Taster durch Charisma im PHEV */
	uint8_T DeEFP_NaesseLevel;           /**< Naesse-Level (0-6: Level, 7: Fehler) */
	bool_T DeEFP_NaesseLevel_Classifier; /**< Naesse-Level-Classifier (0: Sicher, 1: Unsicher) (so in K-Matrix!) */
	uint8_T DeEFP_Fahrbahnreibwert_dyn_Class; /**< Naesse-Level (0-6: Level, 7: Fehler) */
	uint8_T DeSTP_Status;                /**< Status der Funktion Staupilot */
	uint8_T DeStatus_ACC06;              /**< Signalstatus */
	uint8_T DeStatus_ACC12;              /**< Signalstatus */
	uint8_T DeStatus_ACC16;              /**< Signalstatus */
	uint8_T DeStatus_Blinkmodi02;        /**< Signalstatus */
	uint8_T DeStatus_Charisma03;         /**< Signalstatus */
	uint8_T DeStatus_Charisma08;         /**< Ungenutzt. Signalstatus */
	uint8_T DeStatus_ESP22;              /**< Signalstatus */
	uint8_T DeStatus_Getriebe11;         /**< Signalstatus */
	uint8_T DeStatus_Getriebe17;         /**< Signalstatus */
	uint8_T DeStatus_HAL01;              /**< Signalstatus */
	uint8_T DeStatus_GRAACC01;           /**< Signalstatus */
	uint8_T DeStatus_Kombi01;            /**< Signalstatus */
	uint8_T DeStatus_Kombi02;            /**< Signalstatus */
	uint8_T DeStatus_LWI01;              /**< Signalstatus */
	uint8_T DeStatus_MotorCode01;        /**< Signalstatus */
	uint8_T DeStatus_Motor11;            /**< Signalstatus */
	uint8_T DeStatus_Motor14;            /**< Signalstatus */
	uint8_T DeStatus_Motor16;            /**< Signalstatus */
	uint8_T DeStatus_Motor18;            /**< Signalstatus */
	uint8_T DeStatus_Motor20;            /**< Signalstatus */
	uint8_T DeStatus_Em1Hyb06;           /**< Signalstatus */
	uint8_T DeStatus_Em1Hyb12;           /**< Signalstatus */
	uint8_T DeStatus_SDF1Objekt01;       /**< Signalstatus */
	uint8_T DeStatus_TSK06;              /**< Signalstatus */
	uint8_T DeStatus_TSK08;              /**< Signalstatus */
	uint8_T DeStatus_Fahrwerk07;         /**< Signalstatus */
	uint8_T DeStatus_CSPH01;             /**< Signalstatus */
	uint8_T DeStatus_STP01;              /**< Signalstatus */
} ;                                      /**< Groesse der Struktur = 132 Bytes */

struct _emlInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	real32_T DeVelocityX;                /**< Vorzeichenbehaftete Geschwindigkeit des Fahrzeugs in x-Richtung des USK[m/s] */
	uint8_T DeVelocityXConf;             /**< 0=gueltiger Wert 1=BestGuess/Ersatzwert 2=Init 3=Fehler 4=Fehler in den Eingangsdaten */
	real32_T DeAccX;                     /**< Beschleunigung des Fahrzeugs in x-Richtung im Sensorkoordinatensystem[m/s^2] */
	uint8_T DeAccXConf;                  /**< Signalkonfidenz  0=gueltiger Wert 1=BestGuess/Ersatzwert 2=Init 3=Fehler 4=Fehler in den Eingangsdaten */
	real32_T DeAccY;                     /**< Beschleunigung des Fahrzeugs in y-Richtung im Sensorkoordinatensystem[m/s^2] */
	uint8_T DeAccYConf;                  /**< Signalkonfidenz  0=gueltiger Wert 1=BestGuess/Ersatzwert 2=Init 3=Fehler 4=Fehler in den Eingangsdaten */
	real32_T DeYawRate;                  /**< Drehrate des Objektes um die Hochachse/z-Achse des Fremdobjekts (Offset:-3.9998168945,Skalierung:0.0001220703125)[rad/s] */
	uint8_T DeYawRateConf;               /**< 0=gueltiger Wert 1=BestGuess/Ersatzwert 2=Init 3=Fehler 4=Fehler in den Eingangsdaten */
	real32_T DeHeading;                  /**< Fahrtrichtung (Kompass)[deg] */
	uint8_T DeHeadingConf;               /**< 0=gueltiger Wert 1=BestGuess/Ersatzwert 2=Init 3=Fehler 4=Fehler in den Eingangsdaten */
} ;                                      /**< Groesse der Struktur = 44 Bytes */

struct _obfObject {
	bool_T DataValidFlag;                /**< Noch Ungenutzt. 0=data corrupt, 1=data valid */
	real32_T DePositionX;                /**< Noch Ungenutzt. Position des Objektes in x-Richtung (Referenzpunkt der 3D-Objektbox)[m] */
	real32_T DePositionY;                /**< Noch Ungenutzt. Position des Objektes in y-Richtung (Referenzpunkt der 3D-Objektbox)[m] */
	real32_T DePositionZ;                /**< Noch Ungenutzt. Position der Unterkante des Objektes in z bzgl. des 3D Koordinatensystems  (Referenzpunkt der 3D-Objektbox). Anmerkung: Fahrzeuge knnen durch Bodenunebenheiten Z-Werte groesser/kleiner 0 erhalten!!![m] */
	real32_T DeVelocityX;                /**< Noch Ungenutzt. absolute Geschwindigkeit in x-Richtung. Geschwindigkeiten beziehen sich immer auf den Objektmittelpunkt.[m/s] */
	real32_T DeVelocityY;                /**< Noch Ungenutzt. absolute Geschwindigkeit in y-Richtung. Geschwindigkeiten beziehen sich immer auf den Objektmittelpunkt.[m/s] */
	real32_T DeAccX;                     /**< Noch Ungenutzt. absolute Beschleunigung in x-Richtung. Beschleunigungen beziehen sich immer auf den Objektmittelpunkt.[m/s^2] */
	real32_T DeAccY;                     /**< Noch Ungenutzt. absolute Beschleunigung in y-Richtung. Beschleunigungen beziehen sich immer auf den Objektmittelpunkt[m/s^2] */
	uint8_T DeClass;                     /**< Object Fusion Klasse */
} ;                                      /**< Groesse der Struktur = 36 Bytes */

struct _obfInput {
	uint8_T count;                       /**< Noch Ungenutzt. Anzahl der gespeicherten Objekten */
	obfObject_T objects[incNUMOBFOBJECTS]; /**< Noch Ungenutzt. Object Fusion Objekte */
} ;                                      /**< Groesse der Struktur = 724 Bytes */

struct _laneInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	uint8_T DeNumLaneBoundaries;         /**< Anzahl Spurbegrenzungen */
	struct _laneInput_DeLaneBoundary {
		uint8_T DeNumSegments;           /**< Ungenutzt. Anzahl Spurbegrenzungssegmente */
		struct _laneInput_DeLaneBoundary_DeLaneSegments {
			real32_T DeLength;           /**< Gemessenes und praediziertes bevorstehendes Ende des Linienobjektes[m] */
			real32_T DeLengthMeasured;   /**< Ungenutzt. Letzter gueltiger Messpunkt (im Bild) der linken Egospur vor dem Fahrzeug. Positive Werte bedeuten, dass letzter Messpunkt vor dem Fahrzeug lag. Negative Werte bedeuten, dass letzter Messpunkt hinter dem Fahrzeug liegt.[m] */
			real32_T DeClothoidStartCurvature; /**< Kruemmung des Linienobjektes[rad/m] */
			real32_T DeClothoidCurvatureChange; /**< Aenderung der Kruemmung des Linienobjektes[rad/m^2] */
			real32_T DeStartPositionX;   /**< Ungenutzt. Gemessener Beginn des Linienobjektes[m] */
			real32_T DeStartPositionY;   /**< Abstand des Linienobjektes in y-Richtung[m] */
			real32_T DeStartYawAngle;    /**< Ungenutzt. Gierwinkel zwischen Linienobjekt und Fahrzeug[rad] */
			real32_T DeQualityBegin;     /**< Standardabweichung am Anfang des Linien-Segmentes[m] */
			bool_T DeValid;              /**< Gültigkeit des Segments */
		} DeLaneSegments[incNUMLANESEGMENTS];
	} DeLaneBoundary[incNUMLANEBOUNDARIES];
} ;                                      /**< Groesse der Struktur = 2212 Bytes */

struct _vzeInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	uint8_T VZE_Verkehrszeichen_1;       /**< Das Signal spiegelt eines der Verkehrszeichen: Geschwindigkeitsgebot, ueberholverbot, Aufhebungszeichen wider. Wertebereich lt. Hashtabelle */
	uint8_T VZE_Hinweistext;             /**< ueber Index wird ein Hinweistext beschrieben, der durch das Kombi dargestellte werden soll. Wertebereich lt. Hashtabelle */
	bool_T VZE_Zeichen_01_Kamera;        /**< Das VZE-Tempolimit in Verkehrszeichen1 wurde von der Kamera erkannt. */
	bool_T VZE_Zeichen_01_Karte;         /**< Das VZE-Tempolimit in Verkehrszeichen1 stammt aus den Navigationskartendaten. */
	bool_T VZE_Zeichen_01_Gesetz;        /**< Das VZE-Tempolimit in Verkehrszeichen1  ist das gesetzlich geltende Tempolimit (je Land/Strassenklasse). */
	uint8_T VZE_Verkehrszeichen_6;       /**< Das Signal spiegelt eines der Verkehrszeichen: Geschwindigkeitsgebot, ueberholverbot, Aufhebungszeichen wider. Wertebereich lt. Hashtabelle */
	uint8_T VZE_Zeichen_06_Entfernung;   /**< In dem Signal wird die Entfernung zum Verkehrszeichen6 uebertragen[m] */
	uint8_T VZE_Zusatzschild_6;          /**< Zusatzsschild, das zu Verkehrszeichen 6 angezeigt werden soll. Wertebereich lt. Hashtabelle */
	bool_T VZE_Umweltinfo_Anhaengerbetrieb; /**< Info: Anhaengerbetrieb */
	bool_T VZE_Umweltinfo_Naesse;        /**< Info: Naesse */
	bool_T VZE_Umweltinfo_Nebel;         /**< Info: Nebel */
	uint8_T VZE_Anhaenger_Vmax;          /**< Skaliert: (10 + 10 * x)km/h, uebertragung der aus Kundeneinstellung und laenderspezifischen Regelungen (StVO, Rechtsprechung...) berechneten legalen Hoechstgeschwindigkeit fuer das Gespann. */
	uint8_T VZE_Verkehrszeichen_Einheit; /**< 0:km/h, 1:mph VZE_Verkehrszeichen_Einheit */
} ;                                      /**< Groesse der Struktur = 14 Bytes */

struct _lapInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	int8_T DeSDF2_Pos_Spurnummer;        /**< Spurnummer */
	uint8_T DeSDF2_Pos_AnzHauptspuren;   /**< Anzahl der Hauptspuren */
	uint8_T DeSDF2_Pos_Spurtype;         /**< Spurtyp */
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _codingInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	bool_T FW_HAL;                       /**< Verbauinfo Hinterachslenkung */
	uint8_T ID_Curve_Profile;            /**< Stellt das Fahrprofil für Kurvenfahrten ein */
	uint8_T ID_SpeedLimit_Profile;       /**< Stellt das Fahrprofil für Geschwindigkeitsbegrenzungen ein */
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _fodInput {
	bool_T DataValidFlag;                /**< 0=data corrupt, 1=data valid */
	bool_T DeFoDFunctionRelevant;        /**< Gibt an, ob FunctionOnDemand auszuwerten ist */
	uint8_T DeFoDActivation_InnoDrive2;  /**< Gibt an, ob InnoDrive2 über FunctionOnDemand einkodiert wurde */
} ;                                      /**< Groesse der Struktur = 3 Bytes */

typedef struct _dynamicsInput {
	real32_T velocity;                   /**< Fahrzeuggeschwindigkeit[m/s] */
	real32_T longAcceleration;           /**< Laengsbeschleunigung[m/s²] */
	real32_T latAcceleration;            /**< Querbeschleunigung[m/s²] */
	real32_T displayVelocity;            /**< Anzeigegeschwindigkeit[m/s] */
	real32_T yawRate;                    /**< Gierrate[rad/s] */
	real32_T heading;                    /**< Fahrtrichtung[deg] */
	bool_T headValid;                    /**< Gibt an, ob die Fahrtrichtung gueltig ist */
	real32_T wheelAngle;                 /**< Lenkradwinkel[rad] */
	real32_T wheelRate;                  /**< aenderungsrate des Lenkradwinkels[rad/s] */
	real32_T rearAngle;                  /**< Hinterachs-Lenkwinkel[rad] */
	bool_T rasPresent;                   /**< Gibt an, ob im Fahrzeug eine Hinterachslenkung verbaut ist */
	bool_T serviceBrakeEngaged;          /**< Gibt an, ob die Betriebsbremse aktiv ist */
	struct _dynamicsInput_brakeTorque {
		real32_T frontLeft;              /**< Bremsmoment vorne Links[Nm] */
		real32_T frontRight;             /**< Bremsmoment vorne Rechts[Nm] */
		real32_T rearLeft;               /**< Bremsmoment hinten Links[Nm] */
		real32_T rearRight;              /**< Bremsmoment hinten Rechts[Nm] */
	} brakeTorque;
} dynamicsInput_T;                       /**< Groesse der Struktur = 60 Bytes */

typedef struct _driverInput {
	bool_T valid;                        /**< Gibt an, ob gueltige Informationen vom Bedienhebel vorliegen */
	bool_T enabled;                      /**< Gibt an, ob das System ueber den Hauptschalter ausgewaehlt ist */
	bool_T selected;                     /**< Gibt an, ob Innodrive (PACCh) als aktive Laengsfunktion ausgewaehlt ist. */
	bool_T tipUp;                        /**< Bedienaktion 'Tip Hoch' */
	bool_T tipDown;                      /**< Bedienaktion 'Tip Runter' */
	bool_T set;                          /**< Bedienaktion 'Setzen' */
	bool_T resume;                       /**< Bedienaktion 'Wiederaufnahme' */
	uint8_T followingGap;                /**< Gesetzte Zeitluecke */
	charismaMode_T charisma;             /**< Fahrprogramm */
	bool_T autoMode;                     /**< Aktivierung der automatischen uebernahme von Geschwindigkeitsbeschraenkungen */
	real32_T maxAutoSpeed;               /**< Vom Fahrer einstellbare Freifahrtgeschwindigkeit. Tempolimits werden auf diesen Wert begrenzt.[m/s] */
	turnSignal_T turnSignal;             /**< Lenkstockhebel fuer Blinken (links/rechts) */
	bool_T signalLocked;                 /**< Wird gerastetes Blinken gemeldet? */
	real32_T accelerator;                /**< Fahrpedalrohwert[%] */
	displayUnit_T displayUnit;           /**< Einheit der Tachoanzeige km/h oder mph */
	uint16_T vMaxRaw;                    /**< Maximale Einregelbare Setzgeschwindigkeit ganzzahlig in der Einheit vMaxUnit (kmh/mph) */
	displayUnit_T vMaxUnit;              /**< Einheit der Maximale einregelbaren Setzgeschwindigkeit. Abwechselnd km/h oder mph */
	bool_T ignoreCountry;                /**< Kodierflag zum ignorieren des Länderkodes bei der Aktivierung */
	bool_T fodActivation;                /**< Aktivierung wird nicht über FoD unterdrückt. */
	bool_T fodInitialized;               /**< Fod ist nicht mehr im INIT-Status */
	stpStatus_T stpStatus;               /**< Status der Funktion Staupilot. */
} driverInput_T;                         /**< Groesse der Struktur = 52 Bytes */

typedef struct _accTarget {
	bool_T present;                      /**< Gibt an, ob ein relevantes ACC-Zielobjekt vorliegt */
	real32_T distance;                   /**< Abstand des ACC-Zielobjekts[m] */
	real32_T relVelocity;                /**< Relativgeschwindigkeit des ACC-Zielobjekts[m/s] */
	real32_T relAcceleration;            /**< Beschleunigung des ACC-Zielobjekts[m/s²] */
} accTarget_T;                           /**< Groesse der Struktur = 16 Bytes */

typedef struct _accInput {
	accStatus_T accStatus;               /**< Status des ACC-Systems */
	real32_T accAcceleration;            /**< Sollbeschleunigung des ACC-Mixers */
	bool_T systemRelevant;               /**< Gibt an, ob die InnoDrive-Längsregelung aktuell durch den Fahrer oder das ACC-System überstimmt wird */
	accTarget_T target;
} accInput_T;                            /**< Groesse der Struktur = 28 Bytes */

typedef struct _powertrainInput {
	uint8_T gear;                        /**< Aktuell eingelegter Gang bzw. Segeln. InitWerte gear und coastingPossible passend? */
	bool_T coastingPossible;             /**< Gibt an, ob eine Segelanforderung moeglich ist oder durch ein anderes System gesperrt wird */
	real32_T sumTorque;                  /**< Effektives Moment am Motorausgang[Nm] */
	real32_T eTorquePrimary;             /**< Antriebsmoment der E-Maschine 1[Nm] */
	real32_T eTorqueSecondary;           /**< Antriebsmoment der E-Maschine 2[Nm] */
	bool_T transmissionManual;           /**< Gibt an, ob sich das Getriebe in 'Manuell' befindet */
	real32_T maxTorqueElectric;          /**< Maximales Drehmoment des Elektromotors[Nm] */
	bool_T combustionEngineActive;       /**< Wahr, wenn der Verbrennungsmotor laeuft */
	bool_T ePowerSelected;               /**< Wahr, wenn der Elektro-Modus vom Fahrer aktiv gewaehlt wurde */
	bool_T hybridVehicle;                /**< Gibt an, ob vom Motor ein Hybridfahrzeug gemeldet wird */
	uint8_T motorCode;                   /**< Code des verbauten Motors */
} powertrainInput_T;                     /**< Groesse der Struktur = 28 Bytes */

typedef struct _cameraLine {
	bool_T valid;                        /**< Gültigkeit der Linie */
	real32_T curvature;                  /**< Kruemmung der Linie[1/m] */
	real32_T curveRate;                  /**< Kruemmungsaenderung der Linie[1/m²] */
	real32_T length;                     /**< Sichtweite der Linie[m] */
	real32_T distance;                   /**< Abstand der Linie zum Fahrzeug (negativ: links, positiv: rechts)[m] */
} cameraLine_T;                          /**< Groesse der Struktur = 20 Bytes */

typedef struct _cameraInput {
	cameraLine_T lineLeft;
	cameraLine_T lineRight;
} cameraInput_T;                         /**< Groesse der Struktur = 40 Bytes */

typedef struct _roadInput {
	real32_T slope;                      /**< Gemessene/geschaetzte Fahrbahnsteigung[1] */
	uint8_T wetnessLevel;                /**< Nässe Level (0-6) 7: Fehler[1] */
	uint8_T frictionLevel;               /**< Reibwert Level (0-6) 7: Fehler[1] */
} roadInput_T;                           /**< Groesse der Struktur = 8 Bytes */

typedef struct _signInput {
	bool_T valid;                        /**< Gibt an, ob gueltige Informationen von der VZE vorliegen */
	uint16_T limit;                      /**< Aktuelles Verkehrszeichen, das von der VZE gemeldet wird */
	uint8_T text;                        /**< Index eines Hinweistextes im Kombi. 0: Kein Hinweis */
	struct _signInput_predicted {
		bool_T valid;                    /**< Gibt an, ob ein gueltiges praediktives Verkehrszeichen von der VZE vorliegt */
		uint16_T limit;                  /**< Praediktives Verkehrszeichen, das von der VZE gemeldet wird */
		real32_T distance;               /**< Entfernung, in der das praediktive Verkehrszeichen von der VZE gemeldet wird[m] */
		uint8_T additionalInfo;          /**< Zusatzschild des praediktiven Verkehrszeichens, das von der VZE gemeldet wird */
	} predicted;
	struct _signInput_conditions {
		bool_T fog;                      /**< Gibt an, ob von der VZE die Umweltbedingung 'Nebel' gemeldet wird */
		bool_T wet;                      /**< Gibt an, ob von der VZE die Umweltbedingung 'Naesse' gemeldet wird */
		bool_T trailer;                  /**< Gibt an, ob von der VZE die Umweltbedingung 'Anhaengerbetrieb' gemeldet wird */
		real32_T trailerLimit;           /**< Maximal zulaessige Geschwindigkeit im Anhaengerbetrieb, die von der VZE gemeldet wird[m/s] */
		uint16_T trailerRaw;             /**< Maximal zulaessige Geschwindigkeit im Anhaengerbetrieb in der Einheit km/h[km/h] */
	} conditions;
} signInput_T;                           /**< Groesse der Struktur = 32 Bytes */

struct _positionInput {
	bool_T valid;                        /**< Gibt an, ob gültiger Informationen über Spuranzahl und -position von der SDF vorliegen */
	uint8_T laneCount;                   /**< Anzahl der Hauptspuren */
	int8_T lanePosition;                 /**< Spurnummer des Fahrzeugs */
	laneType_T laneType;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _vehicleInput {
	dynamicsInput_T dynamics;
	driverInput_T driver;
	accInput_T acc;
	powertrainInput_T powertrain;
	cameraInput_T camera;
	roadInput_T road;
	signInput_T sign;
	positionInput_T position;
} ;                                      /**< Groesse der Struktur = 256 Bytes */


/*lint -restore */

#endif
