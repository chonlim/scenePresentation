#ifndef guard_inputCodec_h
#define guard_inputCodec_h

#include "control/control.h"
#include "inputCodec_interface.h"

/**\brief Innere Eingangsschnittstelle.

�bertr�gt die Informationen, die aus den RTE-Eing�ngen gewonnen worden sind in die interne Eingangsstruktur `vehicleInput_T`.
Bei Fehlerhaften oder unbehandelten Signalewerten werden Ersatzwerte gesetzt.
Durch die Parameter  `paramterSetCtrl.inputCodec.xxx.yyy.value` k�nnen alle vehicleInput-Werte �berschreiben werden, sofern 
jeweils der Schalter `paramterSetCtrl.inputCodec.xxx.yyy.override` auf den Wert `true` gesetzt wird.

\spec SwMS_Innodrive2_Input_260

\ingroup inputCodec
*/
void		 inputCodec(IN	const	flexrayInput_T			*flexrayInput,
						IN	const	emlInput_T				*emlInput,
						IN	const	laneInput_T				*laneInput,
						IN	const	vzeInput_T				*vzeInput,
						IN	const	obfInput_T				*obfInput,
						IN	const	lapInput_T				*lapInput,
						IN	const	codingInput_T			*codingInput,
						IN	const	fodInput_T				*fodInput,
						OUT			vehicleInput_T			*vehicleInput);


#endif




