#ifndef guard_inputCodec_interface_h
#define guard_inputCodec_interface_h

#include "base.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define incNUMLANEBOUNDARIES 12          /**< Maximale Anzahl von Lane Boundaries in der laneInput-Struktur */
#define incNUMLANESEGMENTS 5             /**< Maximale Anzahl Segmenten in einer Lane Boundary */
#define incNUMOBFOBJECTS 20              /**< Maximale Anzahl von Object Fusion Objekten */
#define incWetnessLevelError 7           /**< Fehlerwert des Naesselevels */
#define incFrictionLevelError 7          /**< Fehlerwert des Reibwertlevels */




typedef enum _displayUnit {
	dsplUnitMph = 0,
	dsplUnitKph = 1
} displayUnit_T;

typedef enum _laneType {
	laneTypeMain =  0,                   /**< Hauptspur */
	laneTypeOffRampLeft =  1,            /**< Ausfahrt_Rampe_links */
	laneTypeOffRampRight =  2,           /**< Ausfahrt_Rampe_rechts */
	laneTypeHOV =  3,                    /**< HOV_Spur */
	laneTypeExpress =  4,                /**< Expressspur */
	laneTypeExitOnlyLeft =  5,           /**< Nur_Ausfahrt_links */
	laneTypeExitOnlyRight =  6,          /**< Nur_Ausfahrt_rechts */
	laneTypeExitCombinedLeft =  7,       /**< Kombinierte_Ausfahrt_links */
	laneTypeExitCombinedRight =  8,      /**< Kombinierte_Ausfahrt_rechts */
	laneTypeEnterOnlyLeft =  9,          /**< Nur_Auffahrt_links */
	laneTypeEnterOnlyRight = 10,         /**< Nur_Auffahrt_rechts */
	laneTypeEnterCombinedLeft = 11,      /**< Kombinierte_Auffahrt_links */
	laneTypeEnterCombinedRight = 12,     /**< Kombinierte_Auffahrt_rechts */
	laneTypeOnRampLeft = 13,             /**< Auffahrt_Rampe_links */
	laneTypeOnRampRight = 14,            /**< Auffahrt_Rampe_rechts */
	laneTypeUnknown = 15,                /**< Unbekannt */
	laneTypeInit = 16                    /**< Init */
} laneType_T;

typedef struct _flexrayInput flexrayInput_T;
typedef struct _emlInput emlInput_T;
typedef struct _obfObject obfObject_T;
typedef struct _obfInput obfInput_T;
typedef struct _laneInput laneInput_T;
typedef struct _vzeInput vzeInput_T;
typedef struct _lapInput lapInput_T;
typedef struct _codingInput codingInput_T;
typedef struct _fodInput fodInput_T;
typedef struct _positionInput positionInput_T;
typedef struct _vehicleInput vehicleInput_T;



/*lint -restore */

#endif
