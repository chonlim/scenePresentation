#include "inputCodec.h"
#include "inputCodec_private.h"

#include "control/parameterSet/parameterSetCtrl.h"

#include "incPosition.h"


void			 incGetPosition(IN	const	lapInput_T				*lap,
								OUT			positionInput_T			*position)
{
	/* �bertragen der Spuranzahl */
	position->laneCount		= lap->DeSDF2_Pos_AnzHauptspuren;


	/* �bertragen der Spurposition */
	if(     lap->DeSDF2_Pos_Spurnummer	==   0)  { position->lanePosition = -5; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   1)  { position->lanePosition = -4; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   2)  { position->lanePosition = -3; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   3)  { position->lanePosition = -2; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   4)  { position->lanePosition = -1; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   5)  { position->lanePosition =  0; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   6)  { position->lanePosition =  1; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   7)  { position->lanePosition =  2; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   8)  { position->lanePosition =  3; }
	else if(lap->DeSDF2_Pos_Spurnummer	==   9)  { position->lanePosition =  4; }
	else if(lap->DeSDF2_Pos_Spurnummer	==  10)  { position->lanePosition =  5; }
	else if(lap->DeSDF2_Pos_Spurnummer	==  11)  { position->lanePosition =  6; }
	else if(lap->DeSDF2_Pos_Spurnummer	==  12)  { position->lanePosition =  7; }
	else if(lap->DeSDF2_Pos_Spurnummer	==  13)  { position->lanePosition =  8; }
	else										 { position->lanePosition =  0; }


	/* �bertragen des Spurtyps */
	if(     lap->DeSDF2_Pos_Spurtype ==  0u) { position->laneType = laneTypeMain; }
	else if(lap->DeSDF2_Pos_Spurtype ==  1u) { position->laneType = laneTypeOffRampLeft; }
	else if(lap->DeSDF2_Pos_Spurtype ==  2u) { position->laneType = laneTypeOffRampRight; }
	else if(lap->DeSDF2_Pos_Spurtype ==  3u) { position->laneType = laneTypeHOV; }
	else if(lap->DeSDF2_Pos_Spurtype ==  4u) { position->laneType = laneTypeExpress; }
	else if(lap->DeSDF2_Pos_Spurtype ==  5u) { position->laneType = laneTypeExitOnlyLeft; }
	else if(lap->DeSDF2_Pos_Spurtype ==  6u) { position->laneType = laneTypeExitOnlyRight; }
	else if(lap->DeSDF2_Pos_Spurtype ==  7u) { position->laneType = laneTypeExitCombinedLeft	; }
	else if(lap->DeSDF2_Pos_Spurtype ==  8u) { position->laneType = laneTypeExitCombinedRight; }
	else if(lap->DeSDF2_Pos_Spurtype ==  9u) { position->laneType = laneTypeEnterOnlyLeft; }
	else if(lap->DeSDF2_Pos_Spurtype == 10u) { position->laneType = laneTypeEnterOnlyRight; }
	else if(lap->DeSDF2_Pos_Spurtype == 11u) { position->laneType = laneTypeEnterCombinedLeft; }
	else if(lap->DeSDF2_Pos_Spurtype == 12u) { position->laneType = laneTypeEnterCombinedRight; }
	else if(lap->DeSDF2_Pos_Spurtype == 13u) { position->laneType = laneTypeOnRampLeft; }
	else if(lap->DeSDF2_Pos_Spurtype == 14u) { position->laneType = laneTypeOnRampRight; }
	else if(lap->DeSDF2_Pos_Spurtype == 30u) { position->laneType = laneTypeUnknown; }
	else									 { position->laneType = laneTypeInit; }

	/* Liegen g�ltige Informationen �ber die Spuranzahl vor? */
	if(   (lap->DeSDF2_Pos_AnzHauptspuren	>  14u) /* Init */
	   || (lap->DeSDF2_Pos_AnzHauptspuren	==  0u)
	   || (lap->DeSDF2_Pos_Spurnummer		>   13) /* Init? */
	   || (lap->DeSDF2_Pos_Spurnummer		<    0)) /* Init? */
	{
		position->valid	= false;
		position->laneCount = 0u;
		position->laneType = laneTypeInit;
		position->lanePosition = 0;
	}
	else {
		position->valid	= true;
	}
}


void			incInitPosition(OUT			positionInput_T			*position)
{
	position->valid			= false;
	position->laneCount		= 0;
	position->lanePosition	= 0;
	position->laneType		= laneTypeInit;
}


void		incOverridePosition(OUT			positionInput_T			*position)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if(paramSet->inputCodec.position.valid.override) {
		position->valid			= paramSet->inputCodec.position.valid.value;
	}

	if(paramSet->inputCodec.position.laneCount.override) {
		position->laneCount		= paramSet->inputCodec.position.laneCount.value;
	}

	if(paramSet->inputCodec.position.lanePosition.override) {
		position->lanePosition	= paramSet->inputCodec.position.lanePosition.value;
	}

	if(paramSet->inputCodec.position.laneType.override) {
		if(     paramSet->inputCodec.position.laneType.value ==  0u) { position->laneType = laneTypeMain; }
		else if(paramSet->inputCodec.position.laneType.value ==  1u) { position->laneType = laneTypeOffRampLeft; }
		else if(paramSet->inputCodec.position.laneType.value ==  2u) { position->laneType = laneTypeOffRampRight; }
		else if(paramSet->inputCodec.position.laneType.value ==  3u) { position->laneType = laneTypeHOV; }
		else if(paramSet->inputCodec.position.laneType.value ==  4u) { position->laneType = laneTypeExpress; }
		else if(paramSet->inputCodec.position.laneType.value ==  5u) { position->laneType = laneTypeExitOnlyLeft; }
		else if(paramSet->inputCodec.position.laneType.value ==  6u) { position->laneType = laneTypeExitOnlyRight; }
		else if(paramSet->inputCodec.position.laneType.value ==  7u) { position->laneType = laneTypeExitCombinedLeft	; }
		else if(paramSet->inputCodec.position.laneType.value ==  8u) { position->laneType = laneTypeExitCombinedRight; }
		else if(paramSet->inputCodec.position.laneType.value ==  9u) { position->laneType = laneTypeEnterOnlyLeft; }
		else if(paramSet->inputCodec.position.laneType.value == 10u) { position->laneType = laneTypeEnterOnlyRight; }
		else if(paramSet->inputCodec.position.laneType.value == 11u) { position->laneType = laneTypeEnterCombinedLeft; }
		else if(paramSet->inputCodec.position.laneType.value == 12u) { position->laneType = laneTypeEnterCombinedRight; }
		else if(paramSet->inputCodec.position.laneType.value == 13u) { position->laneType = laneTypeOnRampLeft; }
		else if(paramSet->inputCodec.position.laneType.value == 14u) { position->laneType = laneTypeOnRampRight; }
		else if(paramSet->inputCodec.position.laneType.value == 15u) { position->laneType = laneTypeUnknown; }
		else														 { position->laneType = laneTypeInit; }
	}
}
