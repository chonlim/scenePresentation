#include "inputCodec.h"
#include "inputCodec_private.h"

#include "incDynamics.h"

#include <BusSignals_status.h>
#include <BusSignals_enums.h>

#include "control/parameterSet/parameterSetCtrl.h"


void	  incGetDynamicsFromEML(IN	const	emlInput_T				*eml,
								OUT			dynamicsInput_T			*dynamics)
{
	if(		(eml->DeAccYConf <= 1u) /* g�ltiger Wert */ 
		&&	(eml->DeAccY >= -661.0f)
		&&	(eml->DeAccY <=  661.0f))
	{
		dynamics->latAcceleration = eml->DeAccY;
	}
	else {
		dynamics->latAcceleration = 0.0f;
		}


	if(		(eml->DeAccXConf <= 1u) /* g�ltiger Wert */
		&&	(eml->DeAccX >= -661.0f)
		&&	(eml->DeAccX <=  661.0f))
	{
		dynamics->longAcceleration = eml->DeAccX;
	}
	else {
		dynamics->longAcceleration = 0.0f;
	}


	if(		(eml->DeHeadingConf <= 1u /* g�ltiger Wert */)
		&&	(eml->DeHeading >= 0.0f)
		&&	(eml->DeHeading <= 360.0f))
	{
		dynamics->heading	= eml->DeHeading;
		dynamics->headValid	= true;
	}
	else {
		dynamics->heading	= 0.0f;
		dynamics->headValid	= false;
	}

	if(		(eml->DeVelocityXConf <= 1u /* g�ltiger Wert */) 
		&&	(eml->DeVelocityX >= -192.0f)
		&&	(eml->DeVelocityX <=  192.0f))
	{
		dynamics->velocity = eml->DeVelocityX;
	} else {
		dynamics->velocity = INVALID_VALUE;
	}

	if(		(eml->DeYawRateConf <= 1u) /* g�ltiger Wert */
		&&	(eml->DeYawRate >= -6.8f)
		&&	(eml->DeYawRate <=  6.8f))
	{
		dynamics->yawRate = eml->DeYawRate;
	}
	else {
		dynamics->yawRate = 0.0f;
	}
}


void	   incGetDynamicsFromFR(IN	const	flexrayInput_T			*flexray,
								OUT			dynamicsInput_T			*dynamics)
{
	if((  (flexray->DeStatus_Kombi01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Kombi01 == (uint8_T)PDUSTATE_NOT_UPDATED)
	   )
	   && (flexray->DeKBI_angez_Geschw >= DeFRInnoDriveIn_DeKBI_angez_Geschw_RANGE_MIN)
	   && (flexray->DeKBI_angez_Geschw <= DeFRInnoDriveIn_DeKBI_angez_Geschw_RANGE_MAX))	
	{
		dynamics->displayVelocity = flexray->DeKBI_angez_Geschw / 3.6f; /* [km/h] -> [m/s] */
	} else {
		dynamics->displayVelocity = INVALID_VALUE;
	}

	if(   (flexray->DeStatus_ESP22 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_ESP22 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		dynamics->serviceBrakeEngaged =    ((real32_T)flexray->DeESP_HL_Bremsmoment > 0.0f)
										|| ((real32_T)flexray->DeESP_HR_Bremsmoment > 0.0f)
										|| ((real32_T)flexray->DeESP_VL_Bremsmoment > 0.0f)
										|| ((real32_T)flexray->DeESP_VR_Bremsmoment > 0.0f);

		/* Im Fehlerfall gehen wir von einer geschlossenen Bremse aus */
		if(   (flexray->DeESP_QBit_HL_Bremsmoment)
		   || (flexray->DeESP_QBit_HR_Bremsmoment)
		   || (flexray->DeESP_QBit_VL_Bremsmoment)
		   || (flexray->DeESP_QBit_VR_Bremsmoment)) {
			dynamics->serviceBrakeEngaged = true;
		}

		if ((flexray->DeESP_VL_Bremsmoment <= DeFRInnoDriveIn_DeESP_VL_Bremsmoment_RANGE_MAX)
		 && (!flexray->DeESP_QBit_VL_Bremsmoment))
		{
			dynamics->brakeTorque.frontLeft  = (real32_T)flexray->DeESP_VL_Bremsmoment;
		}
		if ((flexray->DeESP_VR_Bremsmoment <= DeFRInnoDriveIn_DeESP_VR_Bremsmoment_RANGE_MAX)
		 && (!flexray->DeESP_QBit_VR_Bremsmoment))
		{
			dynamics->brakeTorque.frontRight  = (real32_T)flexray->DeESP_VR_Bremsmoment;
		}
		if ((flexray->DeESP_HL_Bremsmoment <= DeFRInnoDriveIn_DeESP_HL_Bremsmoment_RANGE_MAX)
		 && (!flexray->DeESP_QBit_HL_Bremsmoment))
		{
			dynamics->brakeTorque.rearLeft  = (real32_T)flexray->DeESP_HL_Bremsmoment;
		}
		if ((flexray->DeESP_HR_Bremsmoment <= DeFRInnoDriveIn_DeESP_HR_Bremsmoment_RANGE_MAX)
		 && (!flexray->DeESP_QBit_HR_Bremsmoment))
		{
			dynamics->brakeTorque.rearRight  = (real32_T)flexray->DeESP_HR_Bremsmoment;
		}
	}


	if(   (flexray->DeStatus_LWI01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_LWI01 == (uint8_T)PDUSTATE_NOT_UPDATED))
	{
		if(		(flexray->DeLWI_Lenkradwinkel >= DeFRInnoDriveIn_DeLWI_Lenkradwinkel_RANGE_MIN)
			&&	(flexray->DeLWI_Lenkradwinkel <= DeFRInnoDriveIn_DeLWI_Lenkradwinkel_RANGE_MAX))
		{
			dynamics->wheelAngle	= (flexray->DeLWI_Lenkradwinkel * defPIf / 180.0f)
									* (flexray->DeLWI_VZ_Lenkradwinkel ? -1.0f : 1.0f);
		}
		else {
			dynamics->wheelAngle = 0.0f;
		}

		if(		(flexray->DeLWI_Lenkradw_Geschw >= DeFRInnoDriveIn_DeLWI_Lenkradw_Geschw_RANGE_MIN) /*lint !e685 !e568 K�nnte auch anders definiert sein: (Warning -- Relational operator '>=' always evaluates to 'true' [MISRA 2012 Rule 14.3, required])*/
			&&	(flexray->DeLWI_Lenkradw_Geschw <= DeFRInnoDriveIn_DeLWI_Lenkradw_Geschw_RANGE_MAX))
		{
			dynamics->wheelRate		= ((real32_T)flexray->DeLWI_Lenkradw_Geschw * defPIf / 180.0f)
									* (flexray->DeLWI_VZ_Lenkradw_Geschw ? -1.0f : 1.0f);
		}
		else {
			dynamics->wheelRate		= 0.0f;
		}
	}
	else {
		dynamics->wheelAngle	= 0.0f;
		dynamics->wheelRate		= 0.0f;
	}


	if(		(flexray->DeStatus_HAL01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   ||	(flexray->DeStatus_HAL01 == (uint8_T)PDUSTATE_NOT_UPDATED))
	{
		if(		!flexray->DeHAL_QBit_Radwinkel
			&&	(flexray->DeHAL_Radwinkel >= 0.0f)
			&&	(flexray->DeHAL_Radwinkel <= 10.19f))
		{
			dynamics->rearAngle		= (flexray->DeHAL_Radwinkel * defPIf / 180.0f)
									* (flexray->DeHAL_VZ_Radwinkel ? -1.0f : 1.0f);
		}
		else {
			dynamics->rearAngle		= 0.0f;
		}
	}
	else {
		dynamics->rearAngle		= 0.0f;
	}
}


void   incGetDynamicsFromCoding(IN	const	codingInput_T			*coding,
								OUT			dynamicsInput_T			*dynamics)
{
	dynamics->rasPresent = coding->FW_HAL ? true : false;
}


void			incInitDynamics(OUT			dynamicsInput_T			*dynamics)
{
	dynamics->displayVelocity		= INVALID_VALUE;
	dynamics->latAcceleration		= 0.0f;
	dynamics->longAcceleration		= 0.0f;
	dynamics->serviceBrakeEngaged	= false;
	dynamics->velocity				= INVALID_VALUE;
	dynamics->wheelAngle			= 0.0f;
	dynamics->wheelRate				= 0.0f;
	dynamics->yawRate				= 0.0f;
	dynamics->rearAngle				= 0.0f;
	dynamics->headValid				= false;
	dynamics->heading				= 0.0f;
	dynamics->rasPresent			= false;
	dynamics->brakeTorque.frontLeft	= INVALID_VALUE;
	dynamics->brakeTorque.frontRight= INVALID_VALUE;
	dynamics->brakeTorque.rearLeft	= INVALID_VALUE;
	dynamics->brakeTorque.rearRight	= INVALID_VALUE;
}


void		incOverrideDynamics(INOUT		dynamicsInput_T			*dynamics)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if (paramSet->inputCodec.dynamics.velocity.override)
	{
		dynamics->velocity = paramSet->inputCodec.dynamics.velocity.value;
	}

	if (paramSet->inputCodec.dynamics.longAcceleration.override)
	{
		dynamics->longAcceleration = paramSet->inputCodec.dynamics.longAcceleration.value;
	}

	if (paramSet->inputCodec.dynamics.latAcceleration.override)
	{
		dynamics->latAcceleration = paramSet->inputCodec.dynamics.latAcceleration.value;
	}

	if (paramSet->inputCodec.dynamics.displayVelocity.override)
	{
		dynamics->displayVelocity = paramSet->inputCodec.dynamics.displayVelocity.value;
	}

	if (paramSet->inputCodec.dynamics.yawRate.override)
	{
		dynamics->yawRate = paramSet->inputCodec.dynamics.yawRate.value;
	}

	if (paramSet->inputCodec.dynamics.heading.override)
	{
		dynamics->heading = paramSet->inputCodec.dynamics.heading.value;
	}

	if (paramSet->inputCodec.dynamics.headValid.override)
	{
		dynamics->headValid = paramSet->inputCodec.dynamics.headValid.value;
	}

	if (paramSet->inputCodec.dynamics.wheelAngle.override)
	{
		dynamics->wheelAngle = paramSet->inputCodec.dynamics.wheelAngle.value;
	}

	if (paramSet->inputCodec.dynamics.wheelRate.override)
	{
		dynamics->wheelRate = paramSet->inputCodec.dynamics.wheelRate.value;
	}

	if (paramSet->inputCodec.dynamics.rearAngle.override)
	{
		dynamics->rearAngle = paramSet->inputCodec.dynamics.rearAngle.value;
	}

	if (paramSet->inputCodec.dynamics.rasPresent.override)
	{
		dynamics->rasPresent = paramSet->inputCodec.dynamics.rasPresent.value;
	}

	if (paramSet->inputCodec.dynamics.serviceBrakeEngaged.override)
	{
		dynamics->serviceBrakeEngaged = paramSet->inputCodec.dynamics.serviceBrakeEngaged.value;
	}

	if (paramSet->inputCodec.dynamics.brakeTorque.frontLeft.override)
	{
		dynamics->brakeTorque.frontLeft = paramSet->inputCodec.dynamics.brakeTorque.frontLeft.value;
	}

	if (paramSet->inputCodec.dynamics.brakeTorque.frontRight.override)
	{
		dynamics->brakeTorque.frontRight = paramSet->inputCodec.dynamics.brakeTorque.frontRight.value;
	}
	
	if (paramSet->inputCodec.dynamics.brakeTorque.rearLeft.override)
	{
		dynamics->brakeTorque.rearLeft = paramSet->inputCodec.dynamics.brakeTorque.rearLeft.value;
	}

	if (paramSet->inputCodec.dynamics.brakeTorque.rearRight.override)
	{
		dynamics->brakeTorque.rearRight = paramSet->inputCodec.dynamics.brakeTorque.rearRight.value;
	}
}
