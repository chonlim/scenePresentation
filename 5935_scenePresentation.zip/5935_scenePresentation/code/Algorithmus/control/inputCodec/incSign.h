#ifndef guard_incSign_h
#define guard_incSign_h


/**\brief �bertr�gt Informationen aus der Verkehrszeichenerkennung

Signale
\spec SwMS_Innodrive2_Input_244
\spec SwMS_Innodrive2_Input_245
\spec SwMS_Innodrive2_Input_246
\spec SwMS_Innodrive2_Input_247
\spec SwMS_Innodrive2_Input_248
\spec SwMS_Innodrive2_Input_249
\spec SwMS_Innodrive2_Input_250
\spec SwMS_Innodrive2_Input_251
\spec SwMS_Innodrive2_Input_252
\spec SwMS_Innodrive2_Input_253
\spec SwMS_Innodrive2_Input_254
\spec SwMS_Innodrive2_Input_406

\ingroup incSign
*/
void				 incGetSign(IN	const	vzeInput_T				*vze,
								OUT			signInput_T				*sign);


/**\brief Setzt Ersatzwerte f�r alle Signale
\ingroup incSign
*/
void				incInitSign(OUT			signInput_T				*sign);


/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incSign
*/
void				incOverrideSign(INOUT	signInput_T				*sign);

#endif
