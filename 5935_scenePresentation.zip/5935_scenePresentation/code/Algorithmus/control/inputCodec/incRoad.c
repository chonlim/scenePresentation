#include "inputCodec.h"
#include "inputCodec_private.h"

#include "incRoad.h"

#include <BusSignals_status.h>
#include <BusSignals_enums.h>

#include "control/parameterSet/parameterSetCtrl.h"


void				 incGetRoad(IN	const	flexrayInput_T			*flexray,
								OUT			roadInput_T				*road)
{
	if((  (flexray->DeStatus_Motor16 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Motor16 == (uint8_T)PDUSTATE_NOT_UPDATED)
	   )
	   && (flexray->DeTSK_Steigung_02 >= DeFRInnoDriveIn_DeTSK_Steigung_02_RANGE_MIN)
	   && (flexray->DeTSK_Steigung_02 <= DeFRInnoDriveIn_DeTSK_Steigung_02_RANGE_MAX))
	{
		road->slope = flexray->DeTSK_Steigung_02 / 100.0f;
	} else {
		road->slope = INVALID_VALUE;
	}

	if((  (flexray->DeStatus_Fahrwerk07 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_Fahrwerk07 == (uint8_T)PDUSTATE_NOT_UPDATED)
	   )
	   && (flexray->DeEFP_NaesseLevel <= DeFRInnoDriveIn_DeEFP_NaesseLevel_RANGE_MAX)
	   && (!flexray->DeEFP_NaesseLevel_Classifier))
	{
		road->wetnessLevel = flexray->DeEFP_NaesseLevel;
	} else {
		road->wetnessLevel = incWetnessLevelError;
	}

#ifdef DeFRInnoDriveIn_DeEFP_Fahrbahnreibwert_dyn_Class_RANGE_MAX
	if((  (flexray->DeStatus_CSPH01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_CSPH01 == (uint8_T)PDUSTATE_NOT_UPDATED)
	   )
	   && (flexray->DeEFP_Fahrbahnreibwert_dyn_Class <= DeFRInnoDriveIn_DeEFP_Fahrbahnreibwert_dyn_Class_RANGE_MAX))
	{
		road->frictionLevel = flexray->DeEFP_Fahrbahnreibwert_dyn_Class;
	} else
#endif
	{
		road->frictionLevel = incFrictionLevelError;
	}
}


void				incInitRoad(OUT			roadInput_T				*road)
{
	road->slope			= INVALID_VALUE;
	road->wetnessLevel	= incWetnessLevelError;
	road->frictionLevel	= incFrictionLevelError;
}


void				incOverrideRoad(INOUT	roadInput_T				*road)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if (paramSet->inputCodec.road.slope.override)
	{
		road->slope = paramSet->inputCodec.road.slope.value;
	}

	if (paramSet->inputCodec.road.wetnessLevel.override)
	{
		road->wetnessLevel = paramSet->inputCodec.road.wetnessLevel.value;
	}
	
	if (paramSet->inputCodec.road.frictionLevel.override)
	{
		road->frictionLevel = paramSet->inputCodec.road.frictionLevel.value;
	}
}
