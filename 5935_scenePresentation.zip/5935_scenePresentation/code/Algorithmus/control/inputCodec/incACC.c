#include "control/inputCodec/inputCodec.h"
#include "control/inputCodec/inputCodec_private.h"

#include "control/inputCodec/incACC.h"
#include "control/inputCodec/inputCodec_private.h"

#include <BusSignals_enums.h>
#include <BusSignals_status.h>

#include "control/parameterSet/parameterSetCtrl.h"


void				  incGetACC(IN	const	flexrayInput_T			*flexray,
								OUT			accInput_T				*acc)
{
	if(   (flexray->DeStatus_ACC06 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_ACC06 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		/* Mapping des ACC-Status */
		if(     flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx0_ACC_OFF_Hauptschalter_aus)			{ acc->accStatus = accStatusInit; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx1_ACC_INIT)								{ acc->accStatus = accStatusInit; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx2_ACC_STANDBY)							{ acc->accStatus = accStatusAvailable; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx3_ACC_AKTIV_regelt)						{ acc->accStatus = accStatusActive; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx4_ACC_OVERRIDE)							{ acc->accStatus = accStatusOverride; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx5_ACC_Abschaltreaktion)					{ acc->accStatus = accStatusBrakeOnly; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx6_reversibler_Fehler_im_ACC_System)		{ acc->accStatus = accStatusErrorReversible; }
		else if(flexray->DeACC_Status_ACC == DeFRInnoDriveIn_DeACC_Status_ACC_Cx7_irreversibler_Fehler_im_ACC_System)	{ acc->accStatus = accStatusErrorIrreversible; }
		else																											{ acc->accStatus = accStatusInit; }
	}
	else {
		acc->accStatus				= accStatusInit;
	}


	acc->accAcceleration = INVALID_VALUE;


	if(   (flexray->DeStatus_ACC16 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_ACC16 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		if(flexray->DeACC_Regelung_durch_PACC == DeFRInnoDriveIn_DeACC_Regelung_durch_PACC_RANGE_MAX /* PACC gewinnt */) { /*lint !e9029 (Note -- Mismatched essential type categories for binary operator [MISRA 2012 Rule 10.4, required])*/
			acc->systemRelevant = true;
		}
		else {
			acc->systemRelevant = false;
		}
	}
	else {
		acc->systemRelevant = false;
	}


	if(   (flexray->DeStatus_SDF1Objekt01 == (uint8_T)PDUSTATE_IS_UPDATED)
	   || (flexray->DeStatus_SDF1Objekt01 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		/* Wird von der SDF ein Objekt gemeldet? */
		if(   (flexray->DeSDF1_Obj_01_ID == DeFRInnoDriveIn_DeSDF1_Obj_01_ID_Cx00_kein_Objekt_enthalten)
		   || (flexray->DeSDF1_Obj_01_ID == DeFRInnoDriveIn_DeSDF1_Obj_01_ID_CxFF_Init)
		   || (flexray->DeSDF1_Obj_01_PositionX < DeFRInnoDriveIn_DeSDF1_Obj_01_PositionX_RANGE_MIN)
		   || (flexray->DeSDF1_Obj_01_PositionX > DeFRInnoDriveIn_DeSDF1_Obj_01_PositionX_RANGE_MAX)
		   || (flexray->DeSDF1_Obj_01_GeschwRelX < DeFRInnoDriveIn_DeSDF1_Obj_01_GeschwRelX_RANGE_MIN)
		   || (flexray->DeSDF1_Obj_01_GeschwRelX > DeFRInnoDriveIn_DeSDF1_Obj_01_GeschwRelX_RANGE_MAX)
		   || (flexray->DeSDF1_Obj_01_BeschlRelX < -16.0f)
		   || (flexray->DeSDF1_Obj_01_BeschlRelX > 15.75f))
		{
			acc->target.present = false;
			acc->target.distance		= INVALID_VALUE;
			acc->target.relVelocity		= INVALID_VALUE;
			acc->target.relAcceleration	= INVALID_VALUE;
		}
		else {
			acc->target.present = true;
			acc->target.distance		= flexray->DeSDF1_Obj_01_PositionX;
			acc->target.relVelocity		= flexray->DeSDF1_Obj_01_GeschwRelX;
			acc->target.relAcceleration	= flexray->DeSDF1_Obj_01_BeschlRelX;
		}
	}
	else {
		acc->target.present			= false;
		acc->target.distance		= INVALID_VALUE;
		acc->target.relVelocity		= INVALID_VALUE;
		acc->target.relAcceleration	= INVALID_VALUE;
	}
}


void				  incInitACC(OUT		accInput_T				*acc)
{
	acc->accStatus				= accStatusInit;
	acc->accAcceleration		= INVALID_VALUE;
	acc->systemRelevant			= false;
	acc->target.present			= false;
	acc->target.distance		= INVALID_VALUE;
	acc->target.relVelocity		= INVALID_VALUE;
	acc->target.relAcceleration	= INVALID_VALUE;
}

void				  incOverrideACC(INOUT	accInput_T				*acc)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if(paramSet->inputCodec.acc.accStatus.override) {
		switch (paramSet->inputCodec.acc.accStatus.value)
		{
			case 0:		acc->accStatus = accStatusInit;				break;
			case 1:		acc->accStatus = accStatusAvailable;		break;
			case 2:		acc->accStatus = accStatusActive;			break;
			case 3:		acc->accStatus = accStatusOverride;			break;
			case 4:		acc->accStatus = accStatusBrakeOnly;		break;
			case 5:		acc->accStatus = accStatusErrorReversible;	break;
			case 6:		acc->accStatus = accStatusErrorIrreversible;break;
			default:	acc->accStatus = accStatusErrorIrreversible;break;
		}
	}

	if(paramSet->inputCodec.acc.systemRelevant.override) {
		acc->systemRelevant = paramSet->inputCodec.acc.systemRelevant.value;
	}

	if(paramSet->inputCodec.acc.accAcceleration.override) {
		acc->accAcceleration = paramSet->inputCodec.acc.accAcceleration.value;
	}

	if(paramSet->inputCodec.acc.target.present.override) {
		acc->target.present = paramSet->inputCodec.acc.target.present.value;
	}

	if(paramSet->inputCodec.acc.target.distance.override) {
		acc->target.distance = paramSet->inputCodec.acc.target.distance.value;
	}
	
	if (paramSet->inputCodec.acc.target.velocity.override) {
		acc->target.relVelocity = paramSet->inputCodec.acc.target.velocity.value;
	}

	if (paramSet->inputCodec.acc.target.acceleration.override) {
		acc->target.relAcceleration = paramSet->inputCodec.acc.target.acceleration.value;
	}
}
