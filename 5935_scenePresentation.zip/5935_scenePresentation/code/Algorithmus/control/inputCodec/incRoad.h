#ifndef guard_incRoad_h
#define guard_incRoad_h

/**\brief �bertr�gt Informationen zur Umgebung, die nicht explizit von der Kamera stammen

Ersatzwerte
\spec SwMS_Innodrive2_Input_258

Signale
\spec SwMS_Innodrive2_Input_243
\spec SwMS_Innodrive2_Input_1469
\spec SwMS_Innodrive2_Input_1470

\ingroup incRoad
*/
void				 incGetRoad(IN	const	flexrayInput_T			*flexray,
								OUT			roadInput_T				*road);


/**\brief Setzt Ersatzwerte f�r alle Signale

\spec SwMS_Innodrive2_Input_258

\ingroup incRoad
*/
void				incInitRoad(OUT			roadInput_T				*road);


/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incRoad
*/
void				incOverrideRoad(INOUT	roadInput_T				*road);

#endif
