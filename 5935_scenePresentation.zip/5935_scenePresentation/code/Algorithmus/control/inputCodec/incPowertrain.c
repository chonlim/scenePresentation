#include "control/inputCodec/inputCodec.h"
#include "control/inputCodec/inputCodec_private.h"

#include "control/inputCodec/incPowertrain.h"

#include "control/parameterSet/parameterSetCtrl.h"

#include <BusSignals_enums.h>
#include <BusSignals_status.h>


void		   incGetPowertrain(IN	const	flexrayInput_T			*flexray,
								OUT			powertrainInput_T		*powertrain)
{
	if (   (flexray->DeStatus_Getriebe11 == (uint8_T)PDUSTATE_IS_UPDATED)
		|| (flexray->DeStatus_Getriebe11 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		/* Die interne Gang-Z�hlung beginnt bei 0. Wenn kein g�ltiger Gang vorliegt, wird ersatzweise Segeln angenommen. */
		if (    flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx1_Gang_1) { powertrain->gear = 0; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx2_Gang_2) { powertrain->gear = 1; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx3_Gang_3) { powertrain->gear = 2; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx4_Gang_4) { powertrain->gear = 3; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx5_Gang_5) { powertrain->gear = 4; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx6_Gang_6) { powertrain->gear = 5; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_Cx7_Gang_7) { powertrain->gear = 6; }
		else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_CxB_Gang_8) { powertrain->gear = 7; }
		/*else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_CxC_Gang_9) { powertrain->gear = 8; }
		  else if(flexray->DeGE_Zielgang == DeFRInnoDriveIn_DeGE_Zielgang_CxD_Gang10) { powertrain->gear = 9; }*/
		else																		{ powertrain->gear = 0u; }

		/* Sicherstellen, dass es keine Kollision zwischen gearCoast und einem m�glichen Gang gibt */
		BUILD_BUG_ON(gearCoast <= 7);


		/* Befindet sich der W�hlhebel in der M-Gasse? */
		if(   (flexray->DeGE_Fahrstufe == DeFRInnoDriveIn_DeGE_Fahrstufe_CxE_Tipp_in_D)
		   || (flexray->DeGE_Fahrstufe == DeFRInnoDriveIn_DeGE_Fahrstufe_CxD_Tipp_in_S)) {
			powertrain->transmissionManual = true;
		}
		else {
			powertrain->transmissionManual = false;
		}
	}
	else {
		powertrain->gear				= 0u;
		powertrain->transmissionManual	= false;

	}


	if (   (flexray->DeStatus_Getriebe17 == (uint8_T)PDUSTATE_IS_UPDATED)
		|| (flexray->DeStatus_Getriebe17 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		/* Wenn das Getriebe Segeln meldet, spielt der aktuell eingelegte Gang keine Rolle */
		if(flexray->DeGE_Freilauf_Status == DeFRInnoDriveIn_DeGE_Freilauf_Status_Cx1_Freilauf_aktiv) {
			powertrain->gear = gearCoast;
		}

		/* Wenn wir aktiv regeln und kein Segeln anfordern, sind wir ein Verhinderer. Segeln ist also trotzdem m�glich, solange nicht
		   "> 1 Verhinderer" gemeldet wird. Wenn wir gerade nicht aktiv regeln, stimmt diese Annahme nicht - dann ist uns das Signal aber
		   auch egal... */
		if(   flexray->DeGE_Freilauf_Status == DeFRInnoDriveIn_DeGE_Freilauf_Status_Cx0_Freilauf_inaktiv_aber_moeglich
		   || flexray->DeGE_Freilauf_Status == DeFRInnoDriveIn_DeGE_Freilauf_Status_Cx1_Freilauf_aktiv
		   || flexray->DeGE_Freilauf_Status == DeFRInnoDriveIn_DeGE_Freilauf_Status_Cx2_Freilauf_nicht_moegl_1Verhinderer) {
			powertrain->coastingPossible = true;
		}
		else {
			powertrain->coastingPossible = false;
		}
	}
	else {
		powertrain->coastingPossible	= false;
		powertrain->gear				= 0;
	}


	if(     ((flexray->DeStatus_Motor11 == (uint8_T)PDUSTATE_IS_UPDATED)
	      || (flexray->DeStatus_Motor11 == (uint8_T)PDUSTATE_NOT_UPDATED))
	   &&   ((flexray->DeStatus_MotorCode01 == (uint8_T)PDUSTATE_IS_UPDATED)
		  || (flexray->DeStatus_MotorCode01 == (uint8_T)PDUSTATE_NOT_UPDATED))) {
		/* F�r das Motormoment ist zus�tzlich der "Faktor Momente" zu ber�cksichtigen */
		if (	(flexray->DeMO_Mom_Ist_Summe >= DeFRInnoDriveIn_DeMO_Mom_Ist_Summe_RANGE_MIN)
			&&	(flexray->DeMO_Mom_Ist_Summe <= DeFRInnoDriveIn_DeMO_Mom_Ist_Summe_RANGE_MAX)
			&&	(flexray->DeMO_Faktor_Momente_02 >= DeFRInnoDriveIn_DeMO_Faktor_Momente_02_RANGE_MIN)
			&&	(flexray->DeMO_Faktor_Momente_02 <= DeFRInnoDriveIn_DeMO_Faktor_Momente_02_RANGE_MAX))
		{
			powertrain->sumTorque = (real32_T)flexray->DeMO_Mom_Ist_Summe * (real32_T)flexray->DeMO_Faktor_Momente_02;
		} else {
			powertrain->sumTorque = 0.0f;
		}
	}
	else {
		powertrain->sumTorque = 0.0f;
	}

	if(     ((flexray->DeStatus_MotorCode01 == (uint8_T)PDUSTATE_IS_UPDATED)
		  || (flexray->DeStatus_MotorCode01 == (uint8_T)PDUSTATE_NOT_UPDATED))) {
		powertrain->motorCode = flexray->DeMO_Code;
	}
	else {
		powertrain->motorCode = 0u;
	}

	if(     ((flexray->DeStatus_Em1Hyb06 == (uint8_T)PDUSTATE_IS_UPDATED)
	      || (flexray->DeStatus_Em1Hyb06 == (uint8_T)PDUSTATE_NOT_UPDATED))
		  &&  flexray->DeEM1_MaxDyn_Moment <= DeFRInnoDriveIn_DeEM1_MaxDyn_Moment_RANGE_MAX
		  &&  flexray->DeEM1_MaxDyn_Moment >= DeFRInnoDriveIn_DeEM1_MaxDyn_Moment_RANGE_MIN)
	{
		powertrain->maxTorqueElectric = (real32_T)flexray->DeEM1_MaxDyn_Moment;
	}
	else {
		powertrain->maxTorqueElectric = INVALID_VALUE;
	}
	
	if(     ((flexray->DeStatus_Em1Hyb12 == (uint8_T)PDUSTATE_IS_UPDATED)
	      || (flexray->DeStatus_Em1Hyb12 == (uint8_T)PDUSTATE_NOT_UPDATED)))
	{
		if(		flexray->DeEM1_IstMoment <= DeFRInnoDriveIn_DeEM1_IstMoment_RANGE_MAX
		  &&	flexray->DeEM1_IstMoment >= DeFRInnoDriveIn_DeEM1_IstMoment_RANGE_MIN)
		{
			powertrain->eTorquePrimary = flexray->DeEM1_IstMoment;
		} else {
			powertrain->eTorquePrimary = 0.0f;
		}
		if(		flexray->DeEM2_IstMoment <= DeFRInnoDriveIn_DeEM2_IstMoment_RANGE_MAX
		  &&	flexray->DeEM2_IstMoment >= DeFRInnoDriveIn_DeEM2_IstMoment_RANGE_MIN)
		{
			powertrain->eTorqueSecondary = flexray->DeEM2_IstMoment;
		} else {
			powertrain->eTorqueSecondary = 0.0f;
		}
	} else {
		powertrain->eTorquePrimary = 0.0f;
		powertrain->eTorqueSecondary = 0.0f;
	}


	if(		 (flexray->DeStatus_Motor14 == (uint8_T)PDUSTATE_IS_UPDATED)
		  || (flexray->DeStatus_Motor14 == (uint8_T)PDUSTATE_NOT_UPDATED))
	{
		powertrain->combustionEngineActive = flexray->DeMO_HYB_VM_aktiv ? true : false;
	}
	else {
		powertrain->combustionEngineActive = flexray->DeMO_HYB_VM_aktiv ? true : true;
	}

	if(		 (flexray->DeStatus_Motor18 == (uint8_T)PDUSTATE_IS_UPDATED)
		  || (flexray->DeStatus_Motor18 == (uint8_T)PDUSTATE_NOT_UPDATED)) {
		powertrain->hybridVehicle = (flexray->DeMO_Fahrzeugtyp == DeFRInnoDriveIn_DeMO_Fahrzeugtyp_Cx1_Hybrid) ? true : false;
	}
	else {
		powertrain->hybridVehicle = false;
	}

	if(		 (flexray->DeStatus_Charisma03 == (uint8_T)PDUSTATE_IS_UPDATED)
		  || (flexray->DeStatus_Charisma03 == (uint8_T)PDUSTATE_NOT_UPDATED))
	{
		powertrain->ePowerSelected = flexray->DeCHA_EV_LED ? true : false;
	}
	else {
		powertrain->ePowerSelected = flexray->DeCHA_EV_LED ? false : false;
	}
}


void		  incInitPowertrain(OUT			powertrainInput_T		*powertrain)
{
	powertrain->coastingPossible		= false;
	powertrain->gear					= 0u;
	powertrain->sumTorque				= 0.0f;
	powertrain->eTorquePrimary			= 0.0f;
	powertrain->eTorqueSecondary		= 0.0f;
	powertrain->transmissionManual		= false;
	powertrain->hybridVehicle			= false;
	powertrain->combustionEngineActive	= true;
	powertrain->ePowerSelected			= false;
	powertrain->maxTorqueElectric		= INVALID_VALUE;
	powertrain->motorCode				= 0u;
}



void	  incOverridePowertrain(INOUT	powertrainInput_T		*powertrain)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if(paramSet->inputCodec.powertrain.gear.override) {
		powertrain->gear				= paramSet->inputCodec.powertrain.gear.value;
	}

	if(paramSet->inputCodec.powertrain.coastingPossible.override) {
		powertrain->coastingPossible	= paramSet->inputCodec.powertrain.coastingPossible.value;
	}

	if(paramSet->inputCodec.powertrain.sumTorque.override) {
		powertrain->sumTorque			= paramSet->inputCodec.powertrain.sumTorque.value;
	}

	if(paramSet->inputCodec.powertrain.transmissionManual.override) {
		powertrain->transmissionManual	= paramSet->inputCodec.powertrain.transmissionManual.value;
	}

	if(paramSet->inputCodec.powertrain.maxTorqueElectric.override) {
		powertrain->maxTorqueElectric	= paramSet->inputCodec.powertrain.maxTorqueElectric.value;
	}

	if(paramSet->inputCodec.powertrain.combustionEngineActive.override) {
		powertrain->combustionEngineActive = paramSet->inputCodec.powertrain.combustionEngineActive.value;
	}

	if(paramSet->inputCodec.powertrain.ePowerSelected.override) {
		powertrain->ePowerSelected		= paramSet->inputCodec.powertrain.ePowerSelected.value;
	}
	
	if (paramSet->inputCodec.powertrain.hybridVehicle.override) {
		powertrain->hybridVehicle= paramSet->inputCodec.powertrain.hybridVehicle.value;
	}

	if (paramSet->inputCodec.powertrain.eTorquePrimary.override) {
		powertrain->eTorquePrimary= paramSet->inputCodec.powertrain.eTorquePrimary.value;
	}
	
	if (paramSet->inputCodec.powertrain.eTorqueSecondary.override) {
		powertrain->eTorqueSecondary= paramSet->inputCodec.powertrain.eTorqueSecondary.value;
	}
	
	if (paramSet->inputCodec.powertrain.motorCode.override) {
		powertrain->motorCode= paramSet->inputCodec.powertrain.motorCode.value;
	}
}
