#ifndef guard_incDynamics_h
#define guard_incDynamics_h


/**\brief �bertr�gt Informationen zur Fahrdynamik aus dem EML

Ersatzwerte
\spec SwMS_Innodrive2_Input_259

Signale
\spec SwMS_Innodrive2_Input_230
\spec SwMS_Innodrive2_Input_231
\spec SwMS_Innodrive2_Input_232
\spec SwMS_Innodrive2_Input_235
\spec SwMS_Innodrive2_Input_238

\ingroup incDynamics
*/
void	  incGetDynamicsFromEML(IN	const	emlInput_T				*eml,
								OUT			dynamicsInput_T			*dynamics);


/**\brief �bertr�gt Informationen zur Fahrdynamik aus dem Flexray

Ersatzwerte
\spec SwMS_Innodrive2_Input_258

Signale
\spec SwMS_Innodrive2_Input_228
\spec SwMS_Innodrive2_Input_229
\spec SwMS_Innodrive2_Input_230
\spec SwMS_Innodrive2_Input_233
\spec SwMS_Innodrive2_Input_234
\spec SwMS_Innodrive2_Input_236
\spec SwMS_Innodrive2_Input_237
\spec SwMS_Innodrive2_Input_1462
\spec SwMS_Innodrive2_Input_1463
\spec SwMS_Innodrive2_Input_1464
\spec SwMS_Innodrive2_Input_1465

\ingroup incDynamics
*/
void	   incGetDynamicsFromFR(IN	const	flexrayInput_T			*flexray,
								OUT			dynamicsInput_T			*dynamics);


/**\brief �bertr�gt Informationen zur Fahrdynamik aus der Codierung

Ersatzwerte
\spec SwMS_Innodrive2_Input_258

Signale
\spec SwMS_Innodrive2_Input_379

\ingroup incDynamics
*/
void   incGetDynamicsFromCoding(IN	const	codingInput_T			*coding,
								OUT			dynamicsInput_T			*dynamics);


/**\brief Setzt Ersatzwerte f�r alle Signale

\spec SwMS_Innodrive2_Input_258
\spec SwMS_Innodrive2_Input_259

\ingroup incDynamics
*/
void			incInitDynamics(OUT			dynamicsInput_T			*dynamics);


/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incDynamics
*/
void			incOverrideDynamics(INOUT	dynamicsInput_T			*dynamics);

#endif
