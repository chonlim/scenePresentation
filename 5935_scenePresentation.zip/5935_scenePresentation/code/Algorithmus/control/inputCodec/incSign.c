#include "inputCodec.h"
#include "inputCodec_private.h"

#include "incSign.h"

#include "control/parameterSet/parameterSetCtrl.h"


void				 incGetSign(IN	const	vzeInput_T				*vze,
								OUT			signInput_T				*sign)
{
	/*aktuelles Limit*/
	if(   !vze->VZE_Zeichen_01_Gesetz 
	   && !vze->VZE_Zeichen_01_Kamera 
	   && !vze->VZE_Zeichen_01_Karte) {
		sign->valid	= false;
		sign->limit	= 0;
	}
	else {
		if(vze->VZE_Verkehrszeichen_1 > 0u && vze->VZE_Verkehrszeichen_1 <= 50u) {
			sign->valid	= true;
			sign->limit	= (uint16_T)vze->VZE_Verkehrszeichen_1 * (uint16_T)5;
		}
		else if(vze->VZE_Verkehrszeichen_1 > 50u && vze->VZE_Verkehrszeichen_1 < 100u) {
			sign->valid	= true;
			sign->limit	= ((uint16_T)vze->VZE_Verkehrszeichen_1 - (uint16_T)50) * (uint16_T)5;
		}
		else if(vze->VZE_Verkehrszeichen_1 == 104u) {
			sign->valid	= true;
			sign->limit	= INVALID_UINT16;
		}
		else {
			sign->valid	= false;
			sign->limit	= 0u;
		}
	}

	/*Hinweistext*/
	if (vze->VZE_Hinweistext <= 7u)
	{
		sign->text = vze->VZE_Hinweistext;
	} else {
		sign->text = 0u;
	}

	/*Zuk�nftiges Limit*/
	if(   (vze->VZE_Verkehrszeichen_6 == 0u)
	   || (vze->VZE_Zeichen_06_Entfernung < 1u)
	   || (vze->VZE_Zeichen_06_Entfernung > 127u))
	{
		sign->predicted.valid			= false;
		sign->predicted.limit			= 0u;
		sign->predicted.distance		= 0.0f;
		sign->predicted.additionalInfo	= 0u;
	}
	else {
		if(vze->VZE_Verkehrszeichen_6 <= 50u) {
			sign->predicted.valid	= true;
			sign->predicted.limit	= (uint16_T)vze->VZE_Verkehrszeichen_6 * (uint16_T)5;
		}
		else if(vze->VZE_Verkehrszeichen_6 < 100u) {
			sign->predicted.valid	= true;
			sign->predicted.limit	= ((uint16_T)vze->VZE_Verkehrszeichen_6 - (uint16_T)50) * (uint16_T)5;
		}
		else if(vze->VZE_Verkehrszeichen_6 == 104u) {
			sign->predicted.valid	= true;
			sign->predicted.limit	= INVALID_UINT16;
		}
		else {
			sign->predicted.valid	= false;
			sign->predicted.limit	= 0u;
		}

		/*Zusatzinfo*/
		sign->predicted.distance = sign->predicted.valid ? (real32_T)vze->VZE_Zeichen_06_Entfernung : 0.0f;
		
		if (	vze->VZE_Zusatzschild_6 >= 1u
			&&	vze->VZE_Zusatzschild_6 <= 15u)
		{
			sign->predicted.additionalInfo = vze->VZE_Zusatzschild_6;
		} else {
			sign->predicted.additionalInfo = 0u;
		}
	}

	/*Umweltbedingungen*/
	sign->conditions.fog			= vze->VZE_Umweltinfo_Nebel ? true : false;
	sign->conditions.wet			= vze->VZE_Umweltinfo_Naesse ? true : false;
	sign->conditions.trailer		= vze->VZE_Umweltinfo_Anhaengerbetrieb ? true : false;

	/* Berechnen der maximal zul�ssigen Geschwindigkeit im Anh�ngerbetrieb entsprechend der Codierung von
	   VZE_Anhaenger_Vmax (siehe Flexray-Matrix) 
	*/
	if (vze->VZE_Verkehrszeichen_Einheit == 0u) { 
		/*Einheit km/h*/
		uint16_T raw = 0u;
		switch (vze->VZE_Anhaenger_Vmax) {
			case 0	: raw =  10u; break;
			case 1	: raw =  20u; break;
			case 2	: raw =  30u; break;
			case 3	: raw =  40u; break;
			case 4	: raw =  50u; break;
			case 5	: raw =  60u; break;
			case 6	: raw =  70u; break;
			case 7	: raw =  80u; break;
			case 8	: raw =  90u; break;
			case 9	: raw = 100u; break;
			case 10	: raw = 110u; break;
			case 11	: raw = 120u; break;
			case 12	: raw = 130u; break;
			case 13	: raw = 140u; break;
			default	: raw =   0u; break;
		}

		sign->conditions.trailerRaw		= raw;
		sign->conditions.trailerLimit	= (real32_T)raw / 3.6f;
	} 
	else if (vze->VZE_Verkehrszeichen_Einheit == 1u) {
		/*Einheit mph*/
		uint16_T raw = 0u;
		switch (vze->VZE_Anhaenger_Vmax) {
			case 0	: raw =   0u; break;
			case 1	: raw =   0u; break;
			case 2	: raw =   0u; break;
			case 3	: raw =   0u; break;
			case 4	: raw =   0u; break;
			case 5	: raw =  35u; break;
			case 6	: raw =  45u; break;
			case 7	: raw =  50u; break;
			case 8	: raw =  55u; break;
			case 9	: raw =  60u; break;
			case 10	: raw =  70u; break;
			case 11	: raw =  75u; break;
			case 12	: raw =  80u; break;
			case 13	: raw =   0u; break;
			default	: raw =   0u; break;
		}

		sign->conditions.trailerRaw		= raw;
		sign->conditions.trailerLimit	= (real32_T)raw / 2.23694f;
	}
	else {
		/*Einheit unbekannt*/
		sign->conditions.trailerRaw		= 0u;
		sign->conditions.trailerLimit	= 0.0f;
	}

}


void				incInitSign(OUT			signInput_T				*sign)
{
	sign->valid		= false;
	sign->limit		= 0u;
	sign->text		= 0u;
	sign->predicted.valid			= false;
	sign->predicted.limit			= 0u;
	sign->predicted.distance		= 0.0f;
	sign->predicted.additionalInfo	= 0u;
	sign->conditions.fog         	= false;
	sign->conditions.wet         	= false;
	sign->conditions.trailer		= false;
	sign->conditions.trailerLimit	= 0.0f;
	sign->conditions.trailerRaw		= 0u; 
}


void				incOverrideSign(INOUT	signInput_T				*sign)
{
	const parameterSetCtrl_T *paramSet = prmGetParameterSetCtrl();

	if (paramSet->inputCodec.sign.valid.override)
	{
		sign->valid = paramSet->inputCodec.sign.valid.value;
	}

	if (paramSet->inputCodec.sign.limit.override)
	{
		sign->limit = paramSet->inputCodec.sign.limit.value;
	}
	
	if (paramSet->inputCodec.sign.text.override)
	{
		sign->text = paramSet->inputCodec.sign.text.value;
	}

	if (paramSet->inputCodec.sign.predicted.valid.override)
	{
		sign->predicted.valid = paramSet->inputCodec.sign.predicted.valid.value;
	}

	if (paramSet->inputCodec.sign.predicted.limit.override)
	{
		sign->predicted.limit = paramSet->inputCodec.sign.predicted.limit.value;
	}

	if (paramSet->inputCodec.sign.predicted.distance.override)
	{
		sign->predicted.distance = paramSet->inputCodec.sign.predicted.distance.value;
	}

	if (paramSet->inputCodec.sign.predicted.additionalInfo.override)
	{
		sign->predicted.additionalInfo = paramSet->inputCodec.sign.predicted.additionalInfo.value;
	}


	if (paramSet->inputCodec.sign.conditions.fog.override)
	{
		sign->conditions.fog = paramSet->inputCodec.sign.conditions.fog.value;
	}

	if (paramSet->inputCodec.sign.conditions.wet.override)
	{
		sign->conditions.wet = paramSet->inputCodec.sign.conditions.wet.value;
	}

	if (paramSet->inputCodec.sign.conditions.trailer.override)
	{
		sign->conditions.trailer = paramSet->inputCodec.sign.conditions.trailer.value;
	}

	if (paramSet->inputCodec.sign.conditions.trailerLimit.override)
	{
		sign->conditions.trailerLimit = paramSet->inputCodec.sign.conditions.trailerLimit.value;
	}

	if (paramSet->inputCodec.sign.conditions.trailerRaw.override)
	{
		sign->conditions.trailerRaw = paramSet->inputCodec.sign.conditions.trailerRaw.value;
	}
}
