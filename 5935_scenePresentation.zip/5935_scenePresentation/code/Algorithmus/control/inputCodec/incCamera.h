#ifndef guard_incCamera_h
#define guard_incCamera_h

/**\brief Informationen aus Kameradaten.

LineLeft
\spec SwMS_Innodrive2_Input_209
\spec SwMS_Innodrive2_Input_211
\spec SwMS_Innodrive2_Input_220
\spec SwMS_Innodrive2_Input_221
\spec SwMS_Innodrive2_Input_222
\spec SwMS_Innodrive2_Input_223

LineRight
\spec SwMS_Innodrive2_Input_208
\spec SwMS_Innodrive2_Input_214
\spec SwMS_Innodrive2_Input_224
\spec SwMS_Innodrive2_Input_225
\spec SwMS_Innodrive2_Input_226
\spec SwMS_Innodrive2_Input_227

\ingroup incCamera
*/
void			   incGetCamera(IN	const	laneInput_T				*laneInput,
								OUT			cameraInput_T			*camera);

/**\brief Setzt Ersatzwerte f�r alle Signale
\ingroup incCamera
*/
void			  incInitCamera(OUT			cameraInput_T			*camera);


/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incCamera
*/
void			incOverrideCamera(INOUT		cameraInput_T			*camera);

#endif
