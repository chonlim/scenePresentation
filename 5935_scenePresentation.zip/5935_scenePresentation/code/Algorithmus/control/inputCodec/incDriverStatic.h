#ifndef guard_incDriverStatic_h
#define guard_incDriverStatic_h

/**\brief �bertragung des Flexray-Werts auf den internen Wert.

\spec SwMS_Innodrive2_Input_1474	

\ingroup incDriver
*/
static stpStatus_T	incDrvGetStpStatus(	IN const	uint8_T		DeSTP_Status
										);

#endif
