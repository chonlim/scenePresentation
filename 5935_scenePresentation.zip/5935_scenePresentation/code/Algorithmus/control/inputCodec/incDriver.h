#ifndef guard_incDriver_h
#define guard_incDriver_h

/**\brief �bertr�gt Informationen zu Eingaben des Fahrers

Ersatzwerte
\spec SwMS_Innodrive2_Input_258

Signale
\spec SwMS_Innodrive2_Input_72"		
\spec SwMS_Innodrive2_Input_73"		
\spec SwMS_Innodrive2_Input_74"		
\spec SwMS_Innodrive2_Input_75"		
\spec SwMS_Innodrive2_Input_77"		
\spec SwMS_Innodrive2_Input_78"		
\spec SwMS_Innodrive2_Input_79"		
\spec SwMS_Innodrive2_Input_81"		
\spec SwMS_Innodrive2_Input_91"		
\spec SwMS_Innodrive2_Input_110		
\spec SwMS_Innodrive2_Input_111		
\spec SwMS_Innodrive2_Input_112		
\spec SwMS_Innodrive2_Input_113		
\spec SwMS_Innodrive2_Input_120		
\spec SwMS_Innodrive2_Input_219		
\spec SwMS_Innodrive2_Input_240		
\spec SwMS_Innodrive2_Input_366		
\spec SwMS_Innodrive2_Input_411		
\spec SwMS_Innodrive2_Input_1456	
\spec SwMS_Innodrive2_Input_1474	

\ingroup incDriver
*/
void			   incGetDriver(IN	const	flexrayInput_T			*flexray,
								OUT			driverInput_T			*driver);

/**\brief �bertr�gt Informationen zur Function On Demand Aktivierung

\spec SwMS_Innodrive2_Input_1456	
\spec SwMS_Innodrive2_Input_1483

\ingroup incDriver
*/
void			incGetDriverFoD(IN	const	fodInput_T				*fod,
								OUT			driverInput_T			*driver);

/**\brief Setzt Ersatzwerte f�r alle Signale

\spec SwMS_Innodrive2_Input_258

\ingroup incDriver
*/
void			  incInitDriver(OUT			driverInput_T			*driver);

/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incDriver
*/
void		  incOverrideDriver(INOUT		driverInput_T			*driver);


/**\brief �berschreibt Signale auf Basis der Codierung 

\spec SwMS_Innodrive2_Input_409

\ingroup incDriver */
void		 incCodingOvrDriver(INOUT		driverInput_T			*driver,
								IN	const	codingInput_T			*codingInput);


#endif
