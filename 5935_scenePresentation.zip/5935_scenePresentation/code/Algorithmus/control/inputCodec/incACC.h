#ifndef guard_incACC_h
#define guard_incACC_h

/**\brief �bertr�gt Informationen aus der ACC-Funktion

Ersatzwerte
\spec SwMS_Innodrive2_Input_258
\spec SwMS_Innodrive2_Input_259

Signale
\spec SwMS_Innodrive2_Input_188
\spec SwMS_Innodrive2_Input_189
\spec SwMS_Innodrive2_Input_197
\spec SwMS_Innodrive2_Input_193
\spec SwMS_Innodrive2_Input_191
\spec SwMS_Innodrive2_Input_195
\spec SwMS_Innodrive2_Input_223

\ingroup incACC
*/
void				  incGetACC(IN	const	flexrayInput_T			*flexray,
								OUT			accInput_T				*acc);

/**\brief Setzt Ersatzwerte f�r alle Signale

Ersatzwerte
\spec SwMS_Innodrive2_Input_258
\spec SwMS_Innodrive2_Input_259

\ingroup incACC
*/
void				  incInitACC(OUT		accInput_T				*acc);

/**\brief �berschreibt ausgew�hlte Signale

\spec SwMS_Innodrive2_Input_257

\ingroup incACC
*/
void				  incOverrideACC(INOUT	accInput_T				*acc);


#endif
