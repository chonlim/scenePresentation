#include "inputCodec.h"
#include "inputCodec_private.h"

#include "incPowertrain.h"
#include "incACC.h"
#include "incDynamics.h"
#include "incDriver.h"
#include "incCamera.h"
#include "incRoad.h"
#include "incSign.h"
#include "incPosition.h"


void		 inputCodec(IN	const	flexrayInput_T			*flexrayInput,
						IN	const	emlInput_T				*emlInput,
						IN	const	laneInput_T				*laneInput,
						IN	const	vzeInput_T				*vzeInput,
						IN	const	obfInput_T				*obfInput,
						IN	const	lapInput_T				*lapInput,
						IN	const	codingInput_T			*codingInput,
						IN	const	fodInput_T				*fodInput,
						OUT			vehicleInput_T			*vehicleInput)
{
	/**\todo	Unterdr�ckt den PCLint Fehler: error 522: (Warning -- Highest operation, operator '.', lacks side-effects [MISRA 2012 Rule 2.2, required])
				Dies wird deshalb gemacht, weil die OBF-Implementierung noch nicht vollst�ndig spezifiziert ist.*/
	if (obfInput->objects[0].DataValidFlag)
	{
	}


	/* Triebstrang */
	incInitPowertrain(&vehicleInput->powertrain);
	if(flexrayInput->DataValidFlag) {
		incGetPowertrain( flexrayInput,
						 &vehicleInput->powertrain);
	}

	incOverridePowertrain(&vehicleInput->powertrain);


	/* ACC */
	incInitACC(&vehicleInput->acc);

	if(flexrayInput->DataValidFlag) {
		incGetACC( flexrayInput,
				  &vehicleInput->acc);
	}

	incOverrideACC(&vehicleInput->acc);


	/* Dynamics */
	incInitDynamics(&vehicleInput->dynamics);

	if(flexrayInput->DataValidFlag) {
		incGetDynamicsFromFR( flexrayInput,
							 &vehicleInput->dynamics);
	}

	if(emlInput->DataValidFlag) {
		incGetDynamicsFromEML( emlInput,
							  &vehicleInput->dynamics);
	}

	if(codingInput->DataValidFlag) {
		incGetDynamicsFromCoding( codingInput,
								 &vehicleInput->dynamics);
	}

	incOverrideDynamics(&vehicleInput->dynamics);


	/* Driver */
	incInitDriver(&vehicleInput->driver);

	if(flexrayInput->DataValidFlag) {
		incGetDriver( flexrayInput,
					 &vehicleInput->driver);
	}

	if (fodInput->DataValidFlag) {
		incGetDriverFoD( fodInput,
						&vehicleInput->driver);
	}

	if(codingInput->DataValidFlag) {
		incCodingOvrDriver(&vehicleInput->driver, 
						    codingInput);
	}

	incOverrideDriver(&vehicleInput->driver);


	/* Camera */
	incInitCamera(&vehicleInput->camera);

	if(laneInput->DataValidFlag) {
		incGetCamera( laneInput,
					 &vehicleInput->camera);
	}

	incOverrideCamera(&vehicleInput->camera);

	
	/* Road */
	incInitRoad(&vehicleInput->road);

	if(flexrayInput->DataValidFlag) {
		incGetRoad( flexrayInput,
				   &vehicleInput->road);
	}

	incOverrideRoad(&vehicleInput->road);


	/* Sign */
	incInitSign(&vehicleInput->sign);

	if(vzeInput->DataValidFlag) {
		incGetSign( vzeInput,
				   &vehicleInput->sign);
	}

	incOverrideSign(&vehicleInput->sign);


	/* Position */
	incInitPosition(&vehicleInput->position);

	if(lapInput->DataValidFlag) {
		incGetPosition( lapInput,
					   &vehicleInput->position);
	}

	incOverridePosition(&vehicleInput->position);
}
