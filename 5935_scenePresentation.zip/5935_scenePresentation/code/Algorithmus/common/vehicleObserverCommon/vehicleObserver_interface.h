#ifndef guard_vehicleObserver_interface_h
#define guard_vehicleObserver_interface_h

#include "base.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define vobsINFOLIMITCOUNT 5u            /**< Maximale Anzahl von Karten-Geschwindigkeislimits, die an den vehicleObserver zurückgemeldet werden */
#define vobsINFOSLOPECOUNT 8u            /**< Maximale Anzahl von Karten-Steigungsattributen, die an den vehicleObserver zurückgemeldet werden */
#define gearCoast 8
#define rawLimitInvalid 0                /**< Einheitenloser Wert für ein ungültiges Verkehrszeichen */
#define rawLimitReleased 250             /**< Einheitenloser Wert für das Verkehrszeichen unbegrenzt/aufgehoben */




typedef enum _forceState {
	forceStateForward = 0,
	forceStateNeutral = 1,
	forceStateBackward = 2
} forceState_T;

typedef enum _simpleState {
	simpleStateOff = 0,
	simpleStateOn = 1,
	simpleStateEOF = 2
} simpleState_T;

typedef enum _driveMode {
	drvMdCombustion = 0,                 /**< Fahrt mit Verbrennungsmotor */
	drvMdElectricAuto = 1,               /**< Vom Fahrzeug automatisch veranlasste Fahrt mit Verbrennungsmotor */
	drvMdEpower = 2                      /**< Vom Fahrer aktiv angeforderte Fahrt mit Verbrennungsmotor */
} driveMode_T;

typedef enum _turnSignal {
	turnSignalNone = 0,
	turnSignalLeft = 1,
	turnSignalLeftOnly = 2,
	turnSignalRight = 3,
	turnSignalRightOnly = 4,
	turnSignalLockLeft = 5,
	turnSignalLockRight = 6,
	turnSignalLockBoth = 7
} turnSignal_T;

typedef enum _vobsSignUnit {
	signUnitUnknown = 0,                 /**< Verkehrszeichen-Einheit unbekannt */
	signUnitKMH = 1,                     /**< Verkehrszeichen-Einheit km/h */
	signUnitMPH = 2                      /**< Verkehrszeichen-Einheit mph */
} vobsSignUnit_T;

typedef enum _vobsTrafficDir {
	trafficDirUnknown = 0,               /**< Verkehrsrichtung unbekannt */
	trafficDirLeft = 1,                  /**< Linksverkehr */
	trafficDirRight = 2                  /**< Rechtsverkehr */
} vobsTrafficDir_T;

typedef struct _courageFilter courageFilter_T;
typedef struct _vobsMemory vobsMemory_T;
typedef struct _vehicleState vehicleState_T;
typedef struct _longControlInfo longControlInfo_T;
typedef struct _mapPathInfo mapPathInfo_T;


typedef struct _vmState {
	real32_T position;                   /**< Position[m] */
	real32_T velocity;                   /**< Geschwindigkeit[m/s] */
	real32_T acceleration;               /**< Beschleunigung[m/(s^2)] */
} vmState_T;                             /**< Beschreibt einen Systemzustand im Zustandsraum der Geschwindigkeitsplanung, Groesse der Struktur = 12 Bytes */

typedef struct _deviationState {
	real32_T engaged;                    /**< Zugkraftabweichung bei geschlossenem Triebstrang[N] */
	real32_T disengaged;                 /**< Zugkraftabweichung bei offenem Triebstrang[N] */
	bool_T gearLock;                     /**< Anforderung, die Gangschnittstelle wegen großer Abweichungen zwischen erwartetem und tatsächlichen Antriebsmomentenverlauf zu sperren */
	real32_T lockAccleration;            /**< Maximale Beschleunigung, die bei aktivem gearLock angefordert werden darf, um einen unharmonischen Übergang beim Sperren der Gangschnittstelle zu vermeiden[m/s²] */
} deviationState_T;                      /**< Groesse der Struktur = 16 Bytes */

typedef struct _checkState {
	struct _checkState_codeCheck {
		bool_T setDTC;                   /**< Die entsprechende DTC soll gesetzt werden. */
		bool_T failed;                   /**< Der vom Fahrzeug gemeldete Motorcode ist nicht in der Lister der erlaubten Codes. */
	} codeCheck;
	struct _checkState_velocityCheck {
		bool_T setDTC;                   /**< Die entsprechende DTC soll gesetzt werden. */
		bool_T failed;                   /**< Einer der Geschwindigkeitswerte ESP-Geschwindigkeit, ANzeigegeschwindigkeit wird durch den anderen ersetzt. */
	} velocityCheck;
	struct _checkState_controlCheck {
		bool_T setDTC;                   /**< Die entsprechende DTC soll gesetzt werden. */
		bool_T failed;                   /**< Es liegt keine gültige Trajektorienplanung aus dem Strategy-Task vor. */
	} controlCheck;
	struct _checkState_freeRideCheck {
		bool_T setDTC;                   /**< Die entsprechende DTC soll gesetzt werden. */
		bool_T failed;                   /**< Es liegt keine gültige Freifahrtgeschwindigkeit vor. */
	} freeRideCheck;
} checkState_T;                          /**< Groesse der Struktur = 8 Bytes */


/*lint -restore */

#endif
