/** \file vobsDataInterface.c
	\ingroup	vehicleObserver_api
*/
#include "common/common.h"
#include "vehicleObserver_private.h"
#include "vobsDataInterface.h"


void						vobsIsValid(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid)
{
	*valid = vehicleState->valid;
}


void						vobsGetTime(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*time)
{
	*time = (real32_T)vehicleState->tickCount * controlCYCLETIME;
}


void				   vobsGetTickCount(IN	const	vehicleState_T		*vehicleState,
										OUT			uint32_T			*ticks)
{
	*ticks = vehicleState->tickCount;
}


void					vobsGetPosition(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*position)
{
	*position	= vehicleState->velocity.position;
}


void					vobsGetVelocity(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*velocity)
{
	*velocity	= vehicleState->velocity.velocity;
}


void					 vobsGetVMState(IN	const	vehicleState_T		*vehicleState,
										OUT			vmState_T			*vmState)
{
	*vmState	= vehicleState->velocity;
}


void				 vobsGetSimpleState(IN	const	vehicleState_T		*vehicleState,
										OUT			simpleState_T		*simple)
{
	*simple		= vehicleState->powertrain.simple;
}


void			  vobsGetRawSimpleState(IN	const	vehicleState_T		*vehicleState,
										OUT			simpleState_T		*rawSimple)
{
	*rawSimple	= vehicleState->powertrain.rawSimple;
}


void					  vobsGetTorque(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*torque)
{
	*torque		= vehicleState->powertrain.torque;
}


void						vobsGetGear(IN	const	vehicleState_T		*vehicleState,
										OUT			uint8_T				*gear)
{
	*gear		= vehicleState->powertrain.gear;
}


void			 vobsIsCoastingPossible(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*coastingPossible)
{
	*coastingPossible = vehicleState->powertrain.coastingPossible;
}


void	 vobsGetMaxAccelerationElectric(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*maxAccelerationElectric)
{
	*maxAccelerationElectric = vehicleState->powertrain.maxAccelerationElectric;
}


void				   vobsGetDriveMode(IN	const	vehicleState_T		*vehicleState,
										OUT			driveMode_T			*driveMode)
{
	*driveMode = vehicleState->powertrain.driveMode;
}


void			  vobsGetDeviationState(IN	const	vehicleState_T		*vehicleState,
										OUT			deviationState_T	*deviation)
{
	*deviation	= vehicleState->deviation;
}


void					 vobsGetHeading(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid,
										OUT			real32_T			*heading)
{
	*valid		= vehicleState->heading.valid;
	*heading	= vehicleState->heading.heading;
}


void				  vobsGetTurnSignal(IN	const	vehicleState_T		*vehicleState,
										OUT			turnSignal_T		*turnSignal,
										OUT			bool_T				*confident,
										OUT			bool_T				*extendHold)
{
	*turnSignal	= vehicleState->turnSignal.turnSignal;
	*confident	= vehicleState->turnSignal.confident;
	*extendHold	= vehicleState->turnSignal.extendHold;
}

void				vobsGetTurnSignalPosition(IN  const	vehicleState_T	*vehicleState,
											  OUT		real32_T		*position)
{
	*position = vehicleState->turnSignal.position;
}

void					   vobsGetSlope(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*slope)
{
	*slope		= vehicleState->slope.slope;
}


void			   vobsGetTrafficTarget(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*present,
										OUT	OPT		real32_T			*position,
										OUT	OPT		real32_T			*velocity,
										OUT	OPT		real32_T			*acceleration)
{
	*present = vehicleState->traffic.present;
	if(NULL != position)		{ *position		= vehicleState->traffic.position; }
	if(NULL != velocity)		{ *velocity		= vehicleState->traffic.velocity; }
	if(NULL != acceleration)	{ *acceleration	= vehicleState->traffic.acceleration; }
}


void				vobsGetResDeviation(IN	const	deviationState_T	*deviationState,
										IN	const	simpleState_T		 simpleState,
										OUT			real32_T			*resDeviation)
{
	if(simpleStateOff == simpleState) {
		*resDeviation = deviationState->disengaged;
	}
	else {
		*resDeviation = deviationState->engaged;
	}
}


void				vobsGetTrqDeviation(IN	const	deviationState_T	*deviationState,
										IN	const	uint8_T				 gear,
										OUT			real32_T			*resDeviation)
{
	if((uint8_T)gearCoast == gear) {
		*resDeviation = deviationState->disengaged;
	}
	else {
		*resDeviation = deviationState->engaged;
	}
}


void					vobsGetGearLock(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*gearLock,
										OUT			real32_T			*lockAcceleration)
{
	*gearLock			= vehicleState->deviation.gearLock;
	*lockAcceleration	= vehicleState->deviation.lockAccleration;
}


void				   vobsGetCurvature(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*curvature,
										OUT			real32_T			*curveRate,
										OUT			real32_T			*horizon,
										OUT			real32_T			*confidence)
{
	*curvature	= vehicleState->curvature.curvature;
	*curveRate	= vehicleState->curvature.curveRate;
	*horizon	= vehicleState->curvature.horizon;
	*confidence	= vehicleState->curvature.confidence;
}


void						vobsGetSign(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid,
										OUT			real32_T			*position,
										OUT			real32_T			*velocity,
										OUT			uint16_T			*raw)
{
	*valid		= vehicleState->sign.current.valid;
	*position	= vehicleState->sign.current.position;
	*velocity	= vehicleState->sign.current.velocity;
	*raw		= vehicleState->sign.current.raw;
}


void			   vobsGetPredictedSign(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid,
										OUT			real32_T			*position,
										OUT			real32_T			*velocity,
										OUT			uint16_T			*raw)
{
	*valid		= vehicleState->sign.predicted.valid;
	*position	= vehicleState->sign.predicted.position;
	*velocity	= vehicleState->sign.predicted.velocity;
	*raw		= vehicleState->sign.predicted.raw;
}


void			  vobsGetSignConditions(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*fog,
										OUT			bool_T				*wet,
										OUT			bool_T				*trailer,
										OUT			real32_T			*trailerLimit,
										OUT			uint16_T			*trailerRaw)
{
	*fog			= vehicleState->sign.conditions.fog;
	*wet			= vehicleState->sign.conditions.wet;
	*trailer		= vehicleState->sign.conditions.trailer;
	*trailerLimit	= vehicleState->sign.conditions.trailerLimit;
	*trailerRaw		= vehicleState->sign.conditions.trailerRaw;
}


void					 vobsGetCourage(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*curvature,
										OUT			real32_T			*maxJerk,
										OUT			real32_T			*limitJerk,
										OUT			real32_T			*curveJerk,
										OUT			real32_T			*curtain)
{
	*curvature	= vehicleState->courage.curvatureFactor;
	*maxJerk	= vehicleState->courage.maxJerkFactor;
	*limitJerk	= vehicleState->courage.limitJerkFactor;
	*curveJerk	= vehicleState->courage.curveJerkFactor;
	*curtain	= vehicleState->courage.curtainFactor;
}


void			 vobsGetUnfilteredState(IN	const	vehicleState_T		*vehicleState,
										OUT OPT		real32_T			*rawVelocity,
										OUT OPT		real32_T			*displayVelocity,
										OUT OPT		real32_T			*longAcceleration,
										OUT OPT		real32_T			*latAcceleration,
										OUT OPT		real32_T			*accelerator)
{
	if(NULL != rawVelocity)			{ *rawVelocity		= vehicleState->unfiltered.velocity; }
	if(NULL != displayVelocity)		{ *displayVelocity	= vehicleState->unfiltered.displayVelocity; }
	if(NULL != longAcceleration)	{ *longAcceleration	= vehicleState->unfiltered.longAcceleration; }
	if(NULL != latAcceleration)		{ *latAcceleration	= vehicleState->unfiltered.latAcceleration; }
	if(NULL != accelerator)			{ *accelerator		= vehicleState->unfiltered.accelerator; }
}


void					vobsGetSteering(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*curvature,
										OUT			real32_T			*slowCurvature,
										OUT			real32_T			*predCurvature,
										OUT			real32_T			*predDistance)
{
	*curvature		= vehicleState->steering.curvature;
	*slowCurvature	= vehicleState->steering.slowCurvature;
	*predCurvature	= vehicleState->steering.predCurvature;
	*predDistance	= vehicleState->steering.predDistance;
}


void					 vobsGetVMaxRaw(IN const	vehicleState_T		*vehicleState,
										OUT	OPT		uint16_T			*vMaxRawKMH,
										OUT	OPT		uint16_T			*vMaxRawMPH)
{
	if (NULL != vMaxRawKMH) { *vMaxRawKMH = vehicleState->vMax.kmh; }
	if (NULL != vMaxRawMPH) { *vMaxRawMPH = vehicleState->vMax.mph; }
}


void					vobsGetAccBoost(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*accBoost)
{
	*accBoost = vehicleState->accBoost;
}


void			 vobsSetLongControlInfo(IN	const	bool_T				 valid,
										IN	const	real32_T			 acceleration,
										IN	const	bool_T				 gearValid,
										IN	const	uint8_T				 gear,
										OUT			longControlInfo_T	*longControlInfo)
{
	longControlInfo->valid				= valid;
	longControlInfo->acceleration		= acceleration;
	longControlInfo->gearValid			= gearValid;
	longControlInfo->gear				= gear;
}


void				 vobsSetMapPathInfo(IN	const	bool_T				 valid,
										IN	const	vobsSignUnit_T		 signUnit,
										IN	const	vobsTrafficDir_T	 trafficDirection,
										IN	const	real32_T			 curvature,
										IN	const	real32_T			 roundaboutTail,
										IN	const	uint32_T			 ageTicks,
										OUT			mapPathInfo_T		*mapPathInfo)
{
	mapPathInfo->valid				= valid;
	mapPathInfo->signUnit			= signUnit;
	mapPathInfo->trafficDirection	= trafficDirection;
	mapPathInfo->curvature			= curvature;
	mapPathInfo->roundaboutTail		= roundaboutTail;
	mapPathInfo->ageTicks			= ageTicks;

	mapPathInfo->limits.count		= 0;
	mapPathInfo->slopes.count		= 0;
}


void				vobsAddMapPathLimit(INOUT		mapPathInfo_T		*mapPathInfo,
										IN	const	bool_T				 valid,
										IN	const	real32_T			 position,
										IN	const	real32_T			 velocity)
{
	if(mapPathInfo->limits.count < (uint16_T)vobsINFOLIMITCOUNT) {
		mapPathInfo->limits.item[mapPathInfo->limits.count].position = position;
		mapPathInfo->limits.item[mapPathInfo->limits.count].velocity = velocity;
		mapPathInfo->limits.count += valid ? (uint16_T)1 : (uint16_T)0;
	}

}


void				vobsAddMapPathSlope(INOUT		mapPathInfo_T		*mapPathInfo,
										IN	const	bool_T				 valid,
										IN	const	real32_T			 position,
										IN	const	real32_T			 slope)
{
	if(mapPathInfo->slopes.count < (uint16_T)vobsINFOSLOPECOUNT) {
		mapPathInfo->slopes.item[mapPathInfo->slopes.count].position	= position;
		mapPathInfo->slopes.item[mapPathInfo->slopes.count].slope		= slope;
		mapPathInfo->slopes.count += valid ? (uint16_T)1 : (uint16_T)0;
	}

}
