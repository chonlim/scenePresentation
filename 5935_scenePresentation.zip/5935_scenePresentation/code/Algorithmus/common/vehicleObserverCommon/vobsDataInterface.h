#ifndef guard_vobsDataInterface_h
#define guard_vobsDataInterface_h

#include "vehicleObserver_interface.h"

/**\brief Ausgabe G�ltigkeit der Daten
\spec SwMS_Innodrive2_Input_368
\ingroup vehicleObserver_api
*/
void						vobsIsValid(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid
										);


/**\brief Ausgabe Laufzeit seit Programmstart
\spec SwMS_Innodrive2_Input_273
\ingroup vehicleObserver_api
*/
void						vobsGetTime(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*time
										);


/**\brief Ausgabe Anzahl Rechenzyklen seit Programmstart
\spec SwMS_Innodrive2_Input_273
\ingroup vehicleObserver_api
*/
void				   vobsGetTickCount(IN	const	vehicleState_T		*vehicleState,
										OUT			uint32_T			*ticks
										);

/**\brief Ausgabe Fahrzeugposition [m] Aus Anzeigegeschwindigkeit integriert. (monoton wachsend)
\spec SwMS_Innodrive2_Input_286
\ingroup vehicleObserver_api
*/
void					vobsGetPosition(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*position
										);


/**\brief Ausgabe Geschwindigkeit [m/s] aus Beschleunigung integriert.
\spec SwMS_Innodrive2_Input_281
\ingroup vehicleObserver_api
*/
void					vobsGetVelocity(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*velocity
										);


/**\brief Ausgabe Kinematischer (Position, Geschwindigkeit, Beschleunigung).
\spec SwMS_Innodrive2_Input_276
\ingroup vehicleObserver_api
*/
void					 vobsGetVMState(IN	const	vehicleState_T		*vehicleState,
										OUT			vmState_T			*vmState
										);


/**\brief Ausgabe Triebstrangstatus (Geschlossen / Offen) des L�ngsreglers
\spec SwMS_Innodrive2_Input_288
\ingroup vehicleObserver_api
*/
void				 vobsGetSimpleState(IN	const	vehicleState_T		*vehicleState,
										OUT			simpleState_T		*simple
										);


/**\brief Ausgabe tats�chlicher Triebstrangstatus (Geschlossen / Offen) des Fahrzeugs
\spec SwMS_Innodrive2_Input_291
\ingroup vehicleObserver_api
*/
void			  vobsGetRawSimpleState(IN	const	vehicleState_T		*vehicleState,
										OUT			simpleState_T		*rawSimple
										);


void					  vobsGetTorque(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*torque
										);


/**\brief Ausgabe Gang
\spec SwMS_Innodrive2_Input_289
\ingroup vehicleObserver_api
*/
void						vobsGetGear(IN	const	vehicleState_T		*vehicleState,
										OUT			uint8_T				*gear
										);


/**\brief Ausgabe Segelm�glichkeit
\spec SwMS_Innodrive2_Input_292
\ingroup vehicleObserver_api
*/
void			 vobsIsCoastingPossible(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*coastingPossible
										);

/**\brief Ausgabe Maximale Elektrische Beschleunigungsf�higkeit
\spec SwMS_Innodrive2_Input_133
\ingroup vehicleObserver_api
*/
void	 vobsGetMaxAccelerationElectric(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*maxAccelerationElectric);

/**\brief Ausgabe Fahrmodus (Verbrennung, Elektrisch, ePower (vomFahrer ausgew�hlt)
\spec SwMS_Innodrive2_Input_141
\ingroup vehicleObserver_api
*/
void				   vobsGetDriveMode(IN	const	vehicleState_T		*vehicleState,
										OUT			driveMode_T			*driveMode);

/**\brief Ausgabe Zugkraftabweichung
\spec SwMS_Innodrive2_Input_305
\ingroup vehicleObserver_api
*/
void			  vobsGetDeviationState(IN	const	vehicleState_T		*vehicleState,
										OUT			deviationState_T	*deviation
										);


/**\brief Ausgabe Fahrzeugausrichtung [0�-360�]
\spec SwMS_Innodrive2_Input_294
\ingroup vehicleObserver_api
*/
void					 vobsGetHeading(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid,
										OUT			real32_T			*heading
										);


/**\brief Ausgabe Abbiegeabsicht (Aus Blinker und Spurpositionierung)
\spec SwMS_Innodrive2_Input_346
\ingroup vehicleObserver_api
*/
void				  vobsGetTurnSignal(IN	const	vehicleState_T		*vehicleState,
										OUT			turnSignal_T		*turnSignal,
										OUT			bool_T				*confident,
										OUT			bool_T				*extendHold
										);

/**\brief Ausgabe der fr�hesten m�glichen Abbiegeposition
\spec SwMS_Innodrive2_Input_380
\ingroup vehicleObserver_api
*/
void		  vobsGetTurnSignalPosition(IN  const	vehicleState_T	*vehicleState,
										OUT			real32_T		*position
										);


/**\brief Ausgabe Stra�ensteigung [1]
\spec SwMS_Innodrive2_Input_321
\ingroup vehicleObserver_api
*/
void					   vobsGetSlope(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*slope
										);


/**\brief Ausgabe vorausfahrendes Fahrzeug
\spec SwMS_Innodrive2_Input_322
\ingroup vehicleObserver_api
*/
void			   vobsGetTrafficTarget(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*present,
										OUT	OPT		real32_T			*position,
										OUT	OPT		real32_T			*velocity,
										OUT	OPT		real32_T			*acceleration
										);


/**\brief Ausgabe Zugkraftabweichung zu Triebstrangzustand
\spec SwMS_Innodrive2_Input_305
\ingroup vehicleObserver_api
*/
void				vobsGetResDeviation(IN	const	deviationState_T	*deviationState,
										IN	const	simpleState_T		 simpleState,
										OUT			real32_T			*resDeviation
										);


/**\brief Ausgabe Zugkraftabweichung zu Gang (gearCoast entspricht Triebstrang offen)
\spec SwMS_Innodrive2_Input_305
\ingroup vehicleObserver_api
*/
void				vobsGetTrqDeviation(IN	const	deviationState_T	*deviationState,
										IN	const	uint8_T				 gear,
										OUT			real32_T			*resDeviation
										);


void					vobsGetGearLock(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*gearLock,
										OUT			real32_T			*lockAcceleration);


/**\brief Ausgabe Kurvenkr�mmung aufgrund Kameradaten
\spec SwMS_Innodrive2_Input_300
\ingroup vehicleObserver_api
*/
void				   vobsGetCurvature(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*curvature,
										OUT			real32_T			*curveRate,
										OUT			real32_T			*horizon,
										OUT			real32_T			*confidence
										);


/**\brief Ausgabe ungefilterte Eingangssignale
\spec SwMS_Innodrive2_Input_329
\ingroup vehicleObserver_api
*/
void			 vobsGetUnfilteredState(IN	const	vehicleState_T		*vehicleState,
										OUT OPT		real32_T			*rawVelocity,
										OUT OPT		real32_T			*displayVelocity,
										OUT OPT		real32_T			*longAcceleration,
										OUT OPT		real32_T			*latAcceleration,
										OUT OPT		real32_T			*accelerator
										);


/**\brief Ausgabe aktuelles gesetzliches Tempolimit aus Verkehrszeichenerkennung (VZE)
\spec SwMS_Innodrive2_Input_324
\ingroup vehicleObserver_api
*/
void						vobsGetSign(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid,
										OUT			real32_T			*position,
										OUT			real32_T			*velocity,
										OUT			uint16_T			*raw
										);


/**\brief Ausgabe pr�diziertes gesetzliches Tempolimit aus Verkehrszeichenerkennung (VZE)
\ingroup vehicleObserver_api
*/
void			   vobsGetPredictedSign(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*valid,
										OUT			real32_T			*position,
										OUT			real32_T			*velocity,
										OUT			uint16_T			*raw
										);


/**\brief Ausgabe einschr�nkende Bedingungen zu Verkehrszeichen
\spec SwMS_Innodrive2_Input_327
\ingroup vehicleObserver_api
*/
void			  vobsGetSignConditions(IN	const	vehicleState_T		*vehicleState,
										OUT			bool_T				*fog,
										OUT			bool_T				*wet,
										OUT			bool_T				*trailer,
										OUT			real32_T			*trailerLimit,
										OUT			uint16_T			*trailerRaw
										);


/**\brief Ausgabe Anpassungsfaktoren f�r Fahrdynamik
\spec SwMS_Innodrive2_Input_334
\ingroup vehicleObserver_api
*/
void					 vobsGetCourage(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*curvature,
										OUT			real32_T			*maxJerk,
										OUT			real32_T			*limitJerk,
										OUT			real32_T			*curveJerk,
										OUT			real32_T			*curtain
										);


/**\brief Ausgabe Kurvenkr�mmung aufgrund Lenkradwinkel
\spec SwMS_Innodrive2_Input_300
\ingroup vehicleObserver_api
*/
void					vobsGetSteering(IN	const	vehicleState_T		*vehicleState,
										OUT			real32_T			*curvature,
										OUT			real32_T			*slowCurvature,
										OUT			real32_T			*predCurvature,
										OUT			real32_T			*predDistance
										);

/**\brief Ausgabe der Maximal einregelbaren Setzgeschwindigkeit als ganzzahligen Rohwert.
\spec SwMS_Innodrive2_Input_331
\ingroup vehicleObserver_api
*/
void					 vobsGetVMaxRaw(IN const	vehicleState_T		*vehicleState,	/**<Ausgangsstruktur des vehicleObserver*/
										OUT	OPT		uint16_T			*vMaxRawKMH,	/**<Einheit der Geschwindigkeitsanzeige (kmh/mph)*/
										OUT	OPT		uint16_T			*vMaxRawMPH		/**<Maximal einregelbare Setzgeschwindigkeit [displayUnit]*/
										);

/**\brief Ausgabe Erkannte Acc-Boost-Funktion
\spec SwMS_Innodrive2_Input_1452
\ingroup vehicleObserver_api
*/
void					vobsGetAccBoost(IN	const	vehicleState_T		*vehicleState,	/**<Ausgangsstruktur des vehicleObserver*/
										OUT			bool_T				*accBoost		/**<Acc Boost Funktion aktiv*/
										);

/**\brief Eingabe R�ckschleife von Modul longController 
\spec SwMS_Innodrive2_Input_279
\spec SwMS_Innodrive2_Input_290 
\spec SwMS_Innodrive2_Input_291 
\ingroup vehicleObserver_api
*/
void			 vobsSetLongControlInfo(IN	const	bool_T				 valid,
										IN	const	real32_T			 acceleration,
										IN	const	bool_T				 gearValid,
										IN	const	uint8_T				 gear,
										OUT			longControlInfo_T	*longControlInfo
										);


/**\brief Eingabe R�ckschleife von Modul pathRouter 
\spec SwMS_Innodrive2_PSD_163
\ingroup vehicleObserver_api
*/
void				 vobsSetMapPathInfo(IN	const	bool_T				 valid,
										IN	const	vobsSignUnit_T		 signUnit,
										IN	const	vobsTrafficDir_T	 trafficDirection,
										IN	const	real32_T			 curvature,
										IN	const	real32_T			 roundaboutTail,
										IN	const	uint32_T			 ageTicks,
										OUT			mapPathInfo_T		*mapPathInfo
										);

/**\brief Eingabe R�ckschleife Tempolimits von Modul pathRouter 
\spec SwMS_Innodrive2_Input_324
\spec SwMS_Innodrive2_Input_334
\spec SwMS_Innodrive2_PSD_184
\ingroup vehicleObserver_api
*/
void				vobsAddMapPathLimit(INOUT		mapPathInfo_T		*mapPathInfo,
										IN	const	bool_T				 valid,
										IN	const	real32_T			 position,
										IN	const	real32_T			 velocity
										);

/**\brief Eingabe R�ckschleife Tempolimits von Modul pathRouter 
\spec SwMS_Innodrive2_PSD_185
\ingroup vehicleObserver_api
*/
void				vobsAddMapPathSlope(INOUT		mapPathInfo_T		*mapPathInfo,
										IN	const	bool_T				 valid,
										IN	const	real32_T			 position,
										IN	const	real32_T			 slope
										);


#endif
