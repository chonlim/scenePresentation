#ifndef guard_vehicleObserver_private_h
#define guard_vehicleObserver_private_h

#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */




typedef struct _vobsFilter {
	real32_T input[2];                   /**< Historie der Input-Samples des Filters */
	real32_T output[2];                  /**< Historie der Output-Samples des Filters */
} vobsFilter_T;                          /**< Groesse der Struktur = 16 Bytes */

typedef struct _velocityFilter {
	real32_T position;                   /**< Gefahrene Strecke seit der Initialisierung[m] */
	real32_T velocity;                   /**< Angenommene Fahrzeuggeschwindigkeit[m/s] */
	real32_T anchorDisplay;              /**< Notwendig für Erkennung der Änderung der Displaygeschwindigkeit[m/s] */
	real32_T anchorRaw;                  /**< Dient der Korrektur der Displaygeschwindigkeit um die höher aufgelöste Rohgeschwindigkeit[m/s] */
} velocityFilter_T;                      /**< Groesse der Struktur = 16 Bytes */

typedef struct _deviationFilter {
	real32_T modelVelocity;              /**< Modellgeschwindigkeit der Zugkraftfehlerschätzung[m/s] */
	struct _deviationFilter_deviation {
		real32_T engaged;                /**< Zugkraftabweichung bei geschlossenem Triebstrang[N] */
		real32_T disengaged;             /**< Zugkraftabweichung bei offenem Triebstrang[N] */
	} deviation;
	struct _deviationFilter_gearLock {
		real32_T torqueDeviation;        /**< Akkumulierte Abweichung zwischen erwartetem und tatsächlichem Verlauf des Antriebsmoments[Ns] */
		bool_T locked;                   /**< Gibt an, ob aktuell eine Sperranforderung für die Gangschnittstelle ausgegeben wird */
		real32_T acceleration;           /**< Maximal zulässige Sollbeschleunigung bei aktivem gearLock[m/s²] */
	} gearLock;
} deviationFilter_T;                     /**< Groesse der Struktur = 24 Bytes */

typedef struct _headingFilter {
	real32_T heading;                    /**< Angenommene Fahrtrichtung des Fahrzeugs[°] */
	uint32_T invalidCount;               /**< Gibt an, seit wievielen Rechenzyklen das GPS-Heading-Signal ungültig ist */
	bool_T valid;                        /**< Gibt an, ob die angenommene Fahrtrichtung zumindest einmal mit einer gültigen Kartenreferenz abgeglichen wurde */
} headingFilter_T;                       /**< Groesse der Struktur = 12 Bytes */

typedef struct _steeringFilter {
	vobsFilter_T angleRate;              /**< Tiefpassfilter für die Lenkradwinkel-Geschwindigkeit */
	vobsFilter_T slowAngle;              /**< Tiefpassfilter für den nachlaufenden Lenkradwinkel */
} steeringFilter_T;                      /**< Groesse der Struktur = 32 Bytes */

typedef struct _curvatureFilter {
	vobsFilter_T curvature;              /**< Tiefpassfilter für die Fahrbahnkrümmung */
	vobsFilter_T curveRate;              /**< Tiefpassfilter für die Krümmungsänderung */
	vobsFilter_T horizon;                /**< Tiefpassfilter für den Horizont der Spurinformationen */
	vobsFilter_T confidence;             /**< Tiefpassfilter für die Verlässlichkeit der Spurinformationen */
} curvatureFilter_T;                     /**< Groesse der Struktur = 64 Bytes */

typedef struct _turnSignalFilter {
	turnSignal_T turnSignal;             /**< Zustand der Blinken-Eingabe im letzten Zeitschritt */
	real32_T turnPosition;               /**< Position der nächsten möglichen Abzweigung */
	uint16_T turnTicks;                  /**< Anzahl der Zeitschritte, seit denen das Blinksignal unverändert anliegt */
	uint16_T holdTicks;                  /**< Anzahl der Zeitschritte, nachdem das Blinksignal eine Wert ungleich turnSignalNone angenommen hat */
	uint16_T lockRightTicks;             /**< Anzahl der Zeitschritte, nachdem das Fahrzeug bei gesetztem Blinker auf die rechte Spur gewechselt ist. */
	uint16_T lockLeftTicks;              /**< Anzahl der Zeitschritte, nachdem das Fahrzeug bei gesetztem Blinker auf die linke Spur gewechselt ist. */
} turnSignalFilter_T;                    /**< Groesse der Struktur = 16 Bytes */

typedef struct _trafficFilter {
	uint16_T rampFilter;                 /**< Zustand der Offset-Rampe für die ACC-Übergabe */
	vobsFilter_T acceleration;           /**< Tiefpassfilter für die Beschleunigung des Zielfahrzeugs */
} trafficFilter_T;                       /**< Groesse der Struktur = 20 Bytes */

typedef struct _signFilter {
	bool_T valid;                        /**< Gibt an, ob im letzten Zeitschritt gültige Informationen von der VZE vorgelegen haben */
	uint16_T limit;                      /**< Letztes von der VZE gemeldetes Verkehrszeichen (ohne Einheit) */
	vobsSignUnit_T unit;                 /**< Einheit des zuletzt gemeldeten Verkehrszeichens */
	real32_T position;                   /**< Längsposition, an der das gemeldete Verkehrszeichen zuletzt geändert wurde[m] */
	real32_T velocity;                   /**< Letzte von der VZE gemeldetes zulässige Höchstgeschwindigkeit[m/s] */
} signFilter_T;                          /**< Groesse der Struktur = 16 Bytes */

typedef struct _vobsWidthFilter {
	bool_T lastValid;                    /**< Wurde im letzten Zeitschritt eine Fahrbahnmarkierung gemessen? */
	vobsFilter_T avgDistance;            /**< Durchschnittlicher Abstand von der rechten bzw. linken Seitenlinie */
	real32_T maxDistance;                /**< Maximaler Abstand von der rechen bzw. linken Steitenlinie[m] */
	real32_T minDistance;                /**< Minimaler Abstand von der rechten bzw. linken Seitenlinie[m] */
	real32_T confidence;                 /**< Konfidenz der berechneten Fahrbahnbreite[m] */
} vobsWidthFilter_T;                     /**< Groesse der Struktur = 32 Bytes */

typedef struct _vobsLimitFilter {
	bool_T valid;                        /**< Gibt an, ob der Filter gültige Daten enthält */
	uint16_T holdTicks;                  /**< Anzahl der Zeitschritte, über die die Werte bisher gehalten wurden[20ms] */
	real32_T knownMax;                   /**< Maximales bekanntes Geschwindigkeitslimit im letzten Zeitschritt[m/s] */
	real32_T knownMin;                   /**< Minimales bekanntes Geschwindigkeitslimit im letzten Zeitschritt[m/s] */
} vobsLimitFilter_T;                     /**< Groesse der Struktur = 12 Bytes */

struct _courageFilter {
	vobsWidthFilter_T widthLeft;
	vobsWidthFilter_T widthRight;
	vobsLimitFilter_T limitFilter;
	real32_T curvatureFactor;            /**< Anpassungsfaktor für die zulässige Querbeschleunigung[n/a] */
	real32_T limitJerkFactor;            /**< Anpassungsfaktor für den zulässigen Ruck in Reaktion auf Speed Limits[n/a] */
	real32_T curveJerkFactor;            /**< Anpassungsfaktor für den zulässigen Ruck in Reaktion auf Kurven[n/a] */
	real32_T maxJerkFactor;              /**< Anpassungsfaktor für den maximal zulässigen Ruck[n/a] */
	real32_T curtainFactor;              /**< Anpassungsfaktor für das Anheben der zulässigen Geschwindigkeit beim Verlassen von Kreisverkehren[n/a] */
} ;                                      /**< Groesse der Struktur = 96 Bytes */

typedef struct _vMaxFilter {
	struct _vMaxFilter_kmh {
		uint16_T value;                  /**< Maximale Setzgeschwindigkeit Für displayUnit kmh[kmh] */
		bool_T valid;                    /**< Signal wurde bereits einmal empfangen */
	} kmh;
	struct _vMaxFilter_mph {
		uint16_T value;                  /**< Maximale Setzgeschwindigkeit Für displayUnit mph[mph] */
		bool_T valid;                    /**< Signal wurde bereits einmal empfangen */
	} mph;
} vMaxFilter_T;                          /**< Groesse der Struktur = 8 Bytes */

typedef struct _checkFilter {
	struct _checkFilter_codeCheck {
		uint16_T count;                  /**< Anzahl der Rechenzyklen seit letzter Änderung des failed-Zustands */
		bool_T failed;                   /**< Der vom Fahrzeug gemeldete Motorcode ist nicht in der Lister der erlaubten Codes. */
		bool_T initialized;              /**< Initialisiert */
	} codeCheck;
	struct _checkFilter_velocityCheck {
		uint16_T count;                  /**< Anzahl der Rechenzyklen seit letzter Änderung des failed-Zustands */
		bool_T failed;                   /**< Einer der Geschwindigkeitswerte ESP-Geschwindigkeit, ANzeigegeschwindigkeit wird durch den anderen ersetzt. */
		bool_T initialized;              /**< Initialisiert */
	} velocityCheck;
	struct _checkFilter_controlCheck {
		uint16_T count;                  /**< Anzahl der Rechenzyklen seit letzter Änderung des failed-Zustands */
		bool_T failed;                   /**< Es liegt keine gültige Trajektorienplanung aus dem Strategy-Task vor. */
		bool_T initialized;              /**< Initialisiert */
	} controlCheck;
	struct _checkFilter_freeRideCheck {
		uint16_T count;                  /**< Anzahl der Rechenzyklen seit letzter Änderung des failed-Zustands */
		bool_T failed;                   /**< Es liegt keine gültige Freifahrtgeschwindigkeit vor. */
		bool_T initialized;              /**< Initialisiert */
	} freeRideCheck;
} checkFilter_T;                         /**< Groesse der Struktur = 16 Bytes */

typedef struct _accBoostFilter {
	uint16_T holdTicks;                  /**< Zählt die control-Zeitschritte, die die resume-Taste bereits gehalten wurde.[0.02s] */
} accBoostFilter_T;                      /**< Groesse der Struktur = 2 Bytes */

typedef struct _lockCoastFilter {
	uint32_T waitTicks;                  /**< Zählt die control-Zeitschritte, die das Bremsmoment höher als ein Grenzwert ist.[0.02s] */
	uint32_T lockTicks;                  /**< Zählt die control-Zeitschritte, die das Segeln gesperrt ist.[0.02s] */
	bool_T lockCoast;                    /**< Sperrt die Segelanforderung */
} lockCoastFilter_T;                     /**< Groesse der Struktur = 12 Bytes */

struct _vobsMemory {
	uint32_T tickCount;                  /**< Anzahl der Zeitschritte seit der Initialisierung[1] */
	velocityFilter_T velocityFilter;
	deviationFilter_T deviationFilter;
	headingFilter_T headingFilter;
	steeringFilter_T steeringFilter;
	curvatureFilter_T curvatureFilter;
	turnSignalFilter_T turnSignalFilter;
	trafficFilter_T trafficFilter;
	signFilter_T signFilter;
	courageFilter_T courageFilter;
	vMaxFilter_T vMaxFilter;
	checkFilter_T checkFilter;
	accBoostFilter_T accBoostFilter;
	lockCoastFilter_T lockCoastFilter;
} ;                                      /**< Groesse der Struktur = 340 Bytes */

typedef struct _powertrainState {
	uint8_T gear;                        /**< Angenommener Gang */
	simpleState_T simple;                /**< Angenommener vereinfachter Triebstrangzustand */
	simpleState_T rawSimple;             /**< Tatsächlicher aktueller vereinfachter Triebstrangzustand */
	real32_T torque;                     /**< Aktuelles Antriebsmoment[Nm] */
	bool_T coastingPossible;             /**< Gibt an, ob Segeln aktuell möglich ist */
	real32_T maxAccelerationElectric;    /**< Abschätzung der maximalen Beschleunigung mit E-Motor[m/s^2] */
	driveMode_T driveMode;               /**< Fahrmodus */
} powertrainState_T;                     /**< Groesse der Struktur = 28 Bytes */

typedef struct _headingState {
	bool_T valid;                        /**< Gibt an, die Fahrtrichtung mindestens einmal mit einer gültigen Kartenreferent abgeglichen wurde */
	real32_T heading;                    /**< Angenommene Fahrtrichtung des Fahrzeugs[°] */
} headingState_T;                        /**< Groesse der Struktur = 8 Bytes */

typedef struct _steeringState {
	real32_T curvature;                  /**< Aktuelle Bahnkrümmung, die sich aus dem Lenkradwinkel ergibt[1/m] */
	real32_T predCurvature;              /**< Prädizierte Bahnkrümmung, die sich aus dem Lenkradwinkel und der Lenkwinkeländerung ergibt[1/m] */
	real32_T predDistance;               /**< Abstand der prädizierten Bahnkrümmung zur aktuellen Fahrzeugposition[m] */
	real32_T slowCurvature;              /**< Bahnkrümmung, die sich aus dem nachlaufenden Lenkradwinkel ergibt[1/m] */
} steeringState_T;                       /**< Groesse der Struktur = 16 Bytes */

typedef struct _curvatureState {
	real32_T curvature;                  /**< Über die Spurerkennung ermittelte Fahrbahnkrümmung an der Fahrzeugposition[1/m] */
	real32_T curveRate;                  /**< Über die Spurerkennung ermittlete Krümmungsänderung der Fahrbahn an der Fahrzeugposition[1/m²] */
	real32_T horizon;                    /**< Aktueller Horizont der Spurerkennung[m] */
	real32_T confidence;                 /**< Verlässlichkeit der Spurerkennung[1] */
} curvatureState_T;                      /**< Groesse der Struktur = 16 Bytes */

typedef struct _turnSignalState {
	turnSignal_T turnSignal;             /**< Aktuelle Eingabe vom Lenkstockhebel */
	real32_T position;                   /**< Position der nächsten möglichen Abzweigung */
	bool_T confident;                    /**< Gibt an, ob verlässlich von gerastetem Blinken ausgegangen werden kann */
	bool_T extendHold;                   /**< Wird eine applizierbare Zeitspane nach einem turnSignal != turnSignalNone - Ereignis auf true gehalten */
} turnSignalState_T;                     /**< Groesse der Struktur = 12 Bytes */

typedef struct _slopeState {
	real32_T slope;                      /**< Gemessene Fahrbahnsteigung an der Fahrzeugposition[1] */
} slopeState_T;                          /**< Groesse der Struktur = 4 Bytes */

typedef struct _trafficState {
	bool_T present;                      /**< Gibt an, ob ein relevantes ACC-Zielobjekt vorliegt */
	real32_T position;                   /**< Längsposition des ACC-Zielobjekts[m] */
	real32_T velocity;                   /**< Geschwindigkeit des ACC-Zielobjekts[m/s] */
	real32_T acceleration;               /**< Beschleunigung des ACC-Zielobjekts[m/s²] */
} trafficState_T;                        /**< Groesse der Struktur = 16 Bytes */

typedef struct _unfilteredState {
	real32_T velocity;                   /**< Ungefilterte Geschwindigkeit[m/s] */
	real32_T displayVelocity;            /**< Ungefilterte Anzeigegeschwindigkeit[m/s] */
	real32_T longAcceleration;           /**< Ungefilterte Längsbeschleunigung vom ESP-Sensor[m/s²] */
	real32_T latAcceleration;            /**< Ungefilterte Querbeschleunigung vom ESP-Sensor[m/s²] */
	real32_T accelerator;                /**< Fahrpedalrohwert[1/100] */
} unfilteredState_T;                     /**< Groesse der Struktur = 20 Bytes */

typedef struct _signState {
	struct _signState_current {
		bool_T valid;                    /**< Gibt an, ob im letzten Zeitschritt gültige Informationen von der VZE vorgelegen haben */
		real32_T position;               /**< Längsposition, an der das gemeldete Verkehrszeichen zuletzt geändert wurde[m] */
		real32_T velocity;               /**< Letzte von der VZE gemeldete zulässige Höchstgeschwidigkeit[m/s] */
		uint16_T raw;                    /**< Zulässige Höchstgeschwindigkeit in der lokal gültigen Einheit[n/a] */
	} current;
	struct _signState_predicted {
		bool_T valid;                    /**< Gibt an, ob im letzten Zeitschritt ein gültiges prädiktives Verkehrszeichen von der VZE vorgelegen hat */
		real32_T position;               /**< Längsposition, für die das prädiktive Verkehrszeichen gemeldete wurde[m] */
		real32_T velocity;               /**< Prädiktiv von der VZE gemeldete zulässige Höchstgeschwidigkeit[m/s] */
		uint16_T raw;                    /**< Zulässige prädiktive Höchstgeschwindigkeit in der lokal gültigen Einheit[n/a] */
	} predicted;
	struct _signState_conditions {
		bool_T fog;                      /**< Gibt an, ob von der VZE die Umweltbedingung 'Nebel' gemeldet wird */
		bool_T wet;                      /**< Gibt an, ob von der VZE die Umweltbedingung 'Nässe' gemeldet wird */
		bool_T trailer;                  /**< Gibt an, ob von der VZE die Umweltbedingung 'Anhängerbetrieb' gemeldet wird */
		real32_T trailerLimit;           /**< Maximal zulässige Geschwindigkeit im Anhängerbetrieb, die von der VZE gemeldet wird[m/s] */
		uint16_T trailerRaw;             /**< Einheitenlose maximal zulässige Geschwindigkeit im Anhängerbetrieb in der lokalen Einheit (km/h oder mph)[n/a] */
	} conditions;
} signState_T;                           /**< Groesse der Struktur = 44 Bytes */

typedef struct _courageState {
	real32_T curvatureFactor;            /**< Anpassungsfaktor für die zulässige Querbeschleunigung[n/a] */
	real32_T limitJerkFactor;            /**< Anpassungsfaktor für den zulässigen Ruck in Reaktion auf Speed Limits[n/a] */
	real32_T curveJerkFactor;            /**< Anpassungsfaktor für den zulässigen Ruck in Reaktion auf Kurven[n/a] */
	real32_T maxJerkFactor;              /**< Anpassungsfaktor für den maximal zulässigen Ruck[n/a] */
	real32_T curtainFactor;              /**< Anpassungsfaktor für zulässige Geschwindigkeit beim Verlassen des Kreisverkehrs[n/a] */
} courageState_T;                        /**< Groesse der Struktur = 20 Bytes */

typedef struct _vMax {
	uint16_T kmh;                        /**< Maximale Setzgeschwindigkeit Für displayUnit km/h[km/h] */
	uint16_T mph;                        /**< Maximale Setzgeschwindigkeit Für displayUnit mph[mph] */
} vMax_T;                                /**< Groesse der Struktur = 4 Bytes */

struct _vehicleState {
	bool_T valid;
	uint32_T tickCount;                  /**< Anzahl der Control-Zeitschritte seit der Initialisierung der Funktion[1] */
	vmState_T velocity;
	powertrainState_T powertrain;
	deviationState_T deviation;
	headingState_T heading;
	steeringState_T steering;
	curvatureState_T curvature;
	courageState_T courage;
	turnSignalState_T turnSignal;
	slopeState_T slope;
	trafficState_T traffic;
	unfilteredState_T unfiltered;
	signState_T sign;
	vMax_T vMax;
	bool_T accBoost;                     /**< Die Boost-Funktion des ACC ist aktiv. */
} ;                                      /**< Groesse der Struktur = 228 Bytes */

struct _longControlInfo {
	bool_T valid;
	real32_T acceleration;
	bool_T gearValid;
	uint8_T gear;
} ;                                      /**< Groesse der Struktur = 12 Bytes */

typedef struct _pathInfoLimit {
	real32_T position;                   /**< Position der Geschwindigkeitsbeschränkung[m] */
	real32_T velocity;                   /**< Zulässige Geschwindigkeit[m/s] */
} pathInfoLimit_T;                       /**< Groesse der Struktur = 8 Bytes */

typedef struct _pathInfoSlope {
	real32_T position;                   /**< Position des Steigungsattributs[m] */
	real32_T slope;                      /**< Steigung[1] */
} pathInfoSlope_T;                       /**< Groesse der Struktur = 8 Bytes */

struct _mapPathInfo {
	bool_T valid;                        /**< Gibt an, ob eine gültige Fahrtrichtung aus der Karte vorliegt */
	vobsSignUnit_T signUnit;             /**< Einheit der Beschilderung für Verkehrszeichen an der aktuellen Fahrzeugposition */
	vobsTrafficDir_T trafficDirection;   /**< Verkehrsrichtung an der aktuellen Fahrzeugposition */
	real32_T curvature;                  /**< Fahrbahnkrümmung an der aktuellen Fahrzeugposition[1/m] */
	real32_T roundaboutTail;             /**< Wegstrecke, die bereits im Kreisverkehr zurückgelegt wurde bzw. 0, wenn aktuell kein Kreisverkehr durchfahren wird[m] */
	uint32_T ageTicks;                   /**< Anzahl der Control-Zeitschritte, in denen durchgängig ein gültiger PSD-Baum vorgelegen hat[20ms] */
	struct _mapPathInfo_limits {
		uint16_T count;                  /**< Anzahl gültiger Geschwindigkeitslimits[n/a] */
		pathInfoLimit_T item[vobsINFOLIMITCOUNT];
	} limits;
	struct _mapPathInfo_slopes {
		uint16_T count;                  /**< Anzahl gültiger Steigungsattribute[n/a] */
		pathInfoSlope_T item[vobsINFOSLOPECOUNT];
	} slopes;
} ;                                      /**< Groesse der Struktur = 136 Bytes */


/*lint -restore */

#endif
