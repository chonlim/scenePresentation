#ifndef guard_swcComm_interface_h
#define guard_swcComm_interface_h

#include "base.h"
#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/systemControllerCommon/systemController_private.h"
#include "common/longStabTriggerCommon/longStabTrigger_private.h"
#include "common/longTorquePlannerCommon/longTorquePlanner_private.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "common/strategyReporterCommon/strategyReporter_private.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define comCONTROLBUFFERSIZE 295u        /**< Größe des Debug-Buffers in der pemControl-Struktur */
#define comSTRATEGYBUFFERSIZE 856u       /**< Größe des Debug-Buffers in der pemPlanning-Struktur */






typedef struct _pemPlanning {
	bool_T dataValidFlag;                /**< 0=data corrupt, 1=data valid */
	roadModelInfo_T roadModelInfo;
	longTorque_T longTorque;
	strategyReport_T strategyReport;
	struct _pemPlanning_debug {
		struct _pemPlanning_debug_times {
			real32_T start;
			real32_T longStabScheduler;
			real32_T roadProcessor;
			real32_T constraintMaster;
			real32_T longStabPlanner;
			real32_T longTorquePlanner;
			real32_T longPathPlanner;
			real32_T end;
		} times;
		struct _pemPlanning_debug_data {
			uint16_T index;              /**< Index des aktuellen Datenpakets */
			uint16_T count;              /**< Anzahl der Pakete im aktuellen Debug-Datensatz */
			uint16_T size;               /**< Anzahl der belegten Bytes in diesem Paket des Debug-Buffers */
			uint8_T buffer[comSTRATEGYBUFFERSIZE]; /**< Debug-Daten */
		} data;
		bool_T stabilizationRun;         /**< Gibt an, ob die Stabilisierungsebene in diesem Zyklus aufgerufen wurde */
		bool_T strategyRun;              /**< gibt an, ob die Strategieebene in diesm Zyklus aufgerufen wurde */
	} debug;
} pemPlanning_T;                         /**< Groesse der Struktur = 1400 Bytes */

typedef struct _pemControl {
	bool_T dataValidFlag;                /**< 0=data corrupt, 1=data valid */
	vehicleState_T vehicleState;
	systemControl_T systemControl;
	mapPath_T mapPath;
	longTrigger_T longTrigger;
	struct _pemControl_debug {
		struct _pemControl_debug_times {
			real32_T start;
			real32_T inputCodec;
			real32_T vehicleObserver;
			real32_T pathRouter;
			real32_T systemController;
			real32_T longController;
			real32_T longStabTrigger;
			real32_T displayController;
			real32_T driverObserver;
			real32_T driverPredictor;
			real32_T outputCodec;
			real32_T end;
		} times;
		struct _pemControl_debug_data {
			uint16_T index;              /**< Index des aktuellen Datenpakets */
			uint16_T count;              /**< Anzahl der Pakete im aktuellen Debug-Datensatz */
			uint16_T size;               /**< Anzahl der belegten Bytes in diesem Paket des Debug-Buffers */
			uint8_T buffer[comCONTROLBUFFERSIZE]; /**< Debug-Daten */
		} data;
	} debug;
} pemControl_T;                          /**< Groesse der Struktur = 1468 Bytes */


/*lint -restore */

#endif
