#include "common/swcCommunication/PpPemPlanning.h"

/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteInConvert_pemPlanning(const Dt_RECORD_PemPlanning *p_theSrcData, pemPlanning_T *p_theDestData)
{
	uint32_T uiArrIdx;
#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
	memset(p_theDestData, 0, sizeof(pemPlanning_T));
#endif

	/*check the size of the received data*/
	BUILD_BUG_ON((uint32_T)(0 + comSTRATEGYBUFFERSIZE) > sizeof(p_theSrcData->debug_data_buffer));

	p_theDestData->roadModelInfo.egoPosition = p_theSrcData->roadModelInfo_egoPosition;
	p_theDestData->roadModelInfo.limit.item[0].value = p_theSrcData->roadModelInfo_limit_item_0_value;
	p_theDestData->roadModelInfo.limit.item[0].position = p_theSrcData->roadModelInfo_limit_item_0_position;
	p_theDestData->roadModelInfo.limit.item[1].value = p_theSrcData->roadModelInfo_limit_item_1_value;
	p_theDestData->roadModelInfo.limit.item[1].position = p_theSrcData->roadModelInfo_limit_item_1_position;
	p_theDestData->roadModelInfo.limit.item[2].value = p_theSrcData->roadModelInfo_limit_item_2_value;
	p_theDestData->roadModelInfo.limit.item[2].position = p_theSrcData->roadModelInfo_limit_item_2_position;
	p_theDestData->roadModelInfo.limit.item[3].value = p_theSrcData->roadModelInfo_limit_item_3_value;
	p_theDestData->roadModelInfo.limit.item[3].position = p_theSrcData->roadModelInfo_limit_item_3_position;
	p_theDestData->roadModelInfo.limit.item[4].value = p_theSrcData->roadModelInfo_limit_item_4_value;
	p_theDestData->roadModelInfo.limit.item[4].position = p_theSrcData->roadModelInfo_limit_item_4_position;
	p_theDestData->roadModelInfo.limit.item[5].value = p_theSrcData->roadModelInfo_limit_item_5_value;
	p_theDestData->roadModelInfo.limit.item[5].position = p_theSrcData->roadModelInfo_limit_item_5_position;
	p_theDestData->roadModelInfo.stop.item[0].position = p_theSrcData->roadModelInfo_stop_item_0_position;
	p_theDestData->roadModelInfo.stop.item[0].type = p_theSrcData->roadModelInfo_stop_item_0_type;
	p_theDestData->roadModelInfo.stop.item[1].position = p_theSrcData->roadModelInfo_stop_item_1_position;
	p_theDestData->roadModelInfo.stop.item[1].type = p_theSrcData->roadModelInfo_stop_item_1_type;
	p_theDestData->roadModelInfo.stop.item[2].position = p_theSrcData->roadModelInfo_stop_item_2_position;
	p_theDestData->roadModelInfo.stop.item[2].type = p_theSrcData->roadModelInfo_stop_item_2_type;
	p_theDestData->roadModelInfo.stop.item[3].position = p_theSrcData->roadModelInfo_stop_item_3_position;
	p_theDestData->roadModelInfo.stop.item[3].type = p_theSrcData->roadModelInfo_stop_item_3_type;
	p_theDestData->longTorque.segment[0].time = p_theSrcData->longTorque_segment_0_time;
	p_theDestData->longTorque.segment[0].vm.position = p_theSrcData->longTorque_segment_0_vm_position;
	p_theDestData->longTorque.segment[0].vm.velocity = p_theSrcData->longTorque_segment_0_vm_velocity;
	p_theDestData->longTorque.segment[0].vm.acceleration = p_theSrcData->longTorque_segment_0_vm_acceleration;
	p_theDestData->longTorque.segment[0].limits.minAcceleration = p_theSrcData->longTorque_segment_0_limits_minAcceleration;
	p_theDestData->longTorque.segment[0].limits.maxAcceleration = p_theSrcData->longTorque_segment_0_limits_maxAcceleration;
	p_theDestData->longTorque.segment[1].time = p_theSrcData->longTorque_segment_1_time;
	p_theDestData->longTorque.segment[1].vm.position = p_theSrcData->longTorque_segment_1_vm_position;
	p_theDestData->longTorque.segment[1].vm.velocity = p_theSrcData->longTorque_segment_1_vm_velocity;
	p_theDestData->longTorque.segment[1].vm.acceleration = p_theSrcData->longTorque_segment_1_vm_acceleration;
	p_theDestData->longTorque.segment[1].limits.minAcceleration = p_theSrcData->longTorque_segment_1_limits_minAcceleration;
	p_theDestData->longTorque.segment[1].limits.maxAcceleration = p_theSrcData->longTorque_segment_1_limits_maxAcceleration;
	p_theDestData->longTorque.segment[2].time = p_theSrcData->longTorque_segment_2_time;
	p_theDestData->longTorque.segment[2].vm.position = p_theSrcData->longTorque_segment_2_vm_position;
	p_theDestData->longTorque.segment[2].vm.velocity = p_theSrcData->longTorque_segment_2_vm_velocity;
	p_theDestData->longTorque.segment[2].vm.acceleration = p_theSrcData->longTorque_segment_2_vm_acceleration;
	p_theDestData->longTorque.segment[2].limits.minAcceleration = p_theSrcData->longTorque_segment_2_limits_minAcceleration;
	p_theDestData->longTorque.segment[2].limits.maxAcceleration = p_theSrcData->longTorque_segment_2_limits_maxAcceleration;
	p_theDestData->longTorque.segment[3].time = p_theSrcData->longTorque_segment_3_time;
	p_theDestData->longTorque.segment[3].vm.position = p_theSrcData->longTorque_segment_3_vm_position;
	p_theDestData->longTorque.segment[3].vm.velocity = p_theSrcData->longTorque_segment_3_vm_velocity;
	p_theDestData->longTorque.segment[3].vm.acceleration = p_theSrcData->longTorque_segment_3_vm_acceleration;
	p_theDestData->longTorque.segment[3].limits.minAcceleration = p_theSrcData->longTorque_segment_3_limits_minAcceleration;
	p_theDestData->longTorque.segment[3].limits.maxAcceleration = p_theSrcData->longTorque_segment_3_limits_maxAcceleration;
	p_theDestData->longTorque.segment[4].time = p_theSrcData->longTorque_segment_4_time;
	p_theDestData->longTorque.segment[4].vm.position = p_theSrcData->longTorque_segment_4_vm_position;
	p_theDestData->longTorque.segment[4].vm.velocity = p_theSrcData->longTorque_segment_4_vm_velocity;
	p_theDestData->longTorque.segment[4].vm.acceleration = p_theSrcData->longTorque_segment_4_vm_acceleration;
	p_theDestData->longTorque.segment[4].limits.minAcceleration = p_theSrcData->longTorque_segment_4_limits_minAcceleration;
	p_theDestData->longTorque.segment[4].limits.maxAcceleration = p_theSrcData->longTorque_segment_4_limits_maxAcceleration;
	p_theDestData->longTorque.segment[5].time = p_theSrcData->longTorque_segment_5_time;
	p_theDestData->longTorque.segment[5].vm.position = p_theSrcData->longTorque_segment_5_vm_position;
	p_theDestData->longTorque.segment[5].vm.velocity = p_theSrcData->longTorque_segment_5_vm_velocity;
	p_theDestData->longTorque.segment[5].vm.acceleration = p_theSrcData->longTorque_segment_5_vm_acceleration;
	p_theDestData->longTorque.segment[5].limits.minAcceleration = p_theSrcData->longTorque_segment_5_limits_minAcceleration;
	p_theDestData->longTorque.segment[5].limits.maxAcceleration = p_theSrcData->longTorque_segment_5_limits_maxAcceleration;
	p_theDestData->longTorque.preview.curve.type = p_theSrcData->longTorque_preview_curve_type;
	p_theDestData->longTorque.preview.curve.position = p_theSrcData->longTorque_preview_curve_position;
	p_theDestData->longTorque.preview.curve.velocity = p_theSrcData->longTorque_preview_curve_velocity;
	p_theDestData->longTorque.preview.curve.acceleration = p_theSrcData->longTorque_preview_curve_acceleration;
	p_theDestData->longTorque.preview.limit.acceleration = p_theSrcData->longTorque_preview_limit_acceleration;
	p_theDestData->longTorque.preview.limit.position = p_theSrcData->longTorque_preview_limit_position;
	p_theDestData->longTorque.preview.stop.acceleration = p_theSrcData->longTorque_preview_stop_acceleration;
	p_theDestData->longTorque.preview.stop.position = p_theSrcData->longTorque_preview_stop_position;
	p_theDestData->longTorque.curveReach.reachVelocity = p_theSrcData->longTorque_curveReach_reachVelocity;
	p_theDestData->longTorque.curveReach.curveVelocity = p_theSrcData->longTorque_curveReach_curveVelocity;
	p_theDestData->strategyReport.aliveCounter = p_theSrcData->strategyReport_aliveCounter;
	p_theDestData->debug.times.start = p_theSrcData->debug_times_start;
	p_theDestData->debug.times.longStabScheduler = p_theSrcData->debug_times_longStabScheduler;
	p_theDestData->debug.times.roadProcessor = p_theSrcData->debug_times_roadProcessor;
	p_theDestData->debug.times.constraintMaster = p_theSrcData->debug_times_constraintMaster;
	p_theDestData->debug.times.longStabPlanner = p_theSrcData->debug_times_longStabPlanner;
	p_theDestData->debug.times.longTorquePlanner = p_theSrcData->debug_times_longTorquePlanner;
	p_theDestData->debug.times.longPathPlanner = p_theSrcData->debug_times_longPathPlanner;
	p_theDestData->debug.times.end = p_theSrcData->debug_times_end;
	p_theDestData->roadModelInfo.limit.count = p_theSrcData->roadModelInfo_limit_count;
	p_theDestData->roadModelInfo.limit.item[0].raw = p_theSrcData->roadModelInfo_limit_item_0_raw;
	p_theDestData->roadModelInfo.limit.item[1].raw = p_theSrcData->roadModelInfo_limit_item_1_raw;
	p_theDestData->roadModelInfo.limit.item[2].raw = p_theSrcData->roadModelInfo_limit_item_2_raw;
	p_theDestData->roadModelInfo.limit.item[3].raw = p_theSrcData->roadModelInfo_limit_item_3_raw;
	p_theDestData->roadModelInfo.limit.item[4].raw = p_theSrcData->roadModelInfo_limit_item_4_raw;
	p_theDestData->roadModelInfo.limit.item[5].raw = p_theSrcData->roadModelInfo_limit_item_5_raw;
	p_theDestData->roadModelInfo.stop.count = p_theSrcData->roadModelInfo_stop_count;
	p_theDestData->longTorque.count = p_theSrcData->longTorque_count;
	p_theDestData->strategyReport.count = p_theSrcData->strategyReport_count;

	BUILD_BUG_ON((uint32_T)srpREPORTCOUNT != sizeof(p_theSrcData->strategyReport_item) / sizeof(p_theSrcData->strategyReport_item[0]));
	for( uiArrIdx = 0; uiArrIdx < (uint32_T)srpREPORTCOUNT; uiArrIdx++)
	{
		p_theDestData->strategyReport.item[uiArrIdx] = p_theSrcData->strategyReport_item[uiArrIdx]; 
	}
	p_theDestData->debug.data.index = p_theSrcData->debug_data_index;
	p_theDestData->debug.data.count = p_theSrcData->debug_data_count;
	p_theDestData->debug.data.size = p_theSrcData->debug_data_size;
	p_theDestData->dataValidFlag = p_theSrcData->dataValidFlag;
	p_theDestData->longTorque.valid = p_theSrcData->longTorque_valid;
	p_theDestData->longTorque.segment[0].gear = p_theSrcData->longTorque_segment_0_gear;
	p_theDestData->longTorque.segment[0].fm = p_theSrcData->longTorque_segment_0_fm;
	p_theDestData->longTorque.segment[1].gear = p_theSrcData->longTorque_segment_1_gear;
	p_theDestData->longTorque.segment[1].fm = p_theSrcData->longTorque_segment_1_fm;
	p_theDestData->longTorque.segment[2].gear = p_theSrcData->longTorque_segment_2_gear;
	p_theDestData->longTorque.segment[2].fm = p_theSrcData->longTorque_segment_2_fm;
	p_theDestData->longTorque.segment[3].gear = p_theSrcData->longTorque_segment_3_gear;
	p_theDestData->longTorque.segment[3].fm = p_theSrcData->longTorque_segment_3_fm;
	p_theDestData->longTorque.segment[4].gear = p_theSrcData->longTorque_segment_4_gear;
	p_theDestData->longTorque.segment[4].fm = p_theSrcData->longTorque_segment_4_fm;
	p_theDestData->longTorque.segment[5].gear = p_theSrcData->longTorque_segment_5_gear;
	p_theDestData->longTorque.segment[5].fm = p_theSrcData->longTorque_segment_5_fm;
	p_theDestData->longTorque.preview.stop.valid = p_theSrcData->longTorque_preview_stop_valid;
	p_theDestData->longTorque.curveReach.valid = p_theSrcData->longTorque_curveReach_valid;

	for(uiArrIdx = 0; uiArrIdx < (uint32_T)comSTRATEGYBUFFERSIZE; uiArrIdx++)
	{
		p_theDestData->debug.data.buffer[uiArrIdx] = p_theSrcData->debug_data_buffer[uiArrIdx]; 
	}
	p_theDestData->debug.stabilizationRun = p_theSrcData->debug_stabilizationRun;
	p_theDestData->debug.strategyRun = p_theSrcData->debug_strategyRun;

	/* The complete structure length is: 1236 Bytes.*/

	return true;
}
/*lint -restore */

#if !defined INNODRIVE_ZFAS_SWC_BUILD
/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e529 (Warning -- Symbol 'uiArrIdx' (line 1309) not subsequently referenced)*/
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteCheckBounds_pemPlanning(const pemPlanning_T *p_theDestData)
{

#if !defined INNODRIVE_ZFAS_SWC_BUILD
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.egoPosition > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.egoPosition < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[0].value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[0].value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[0].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[0].position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[1].value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[1].value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[1].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[1].position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[2].value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[2].value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[2].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[2].position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[3].value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[3].value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[3].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[3].position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[4].value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[4].value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[4].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[4].position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[5].value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[5].value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[5].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.limit.item[5].position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[0].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[0].position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->roadModelInfo.stop.item[0].type > (Dt_UINT32_1_0)sysStopYield) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[1].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[1].position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->roadModelInfo.stop.item[1].type > (Dt_UINT32_1_0)sysStopYield) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[2].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[2].position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->roadModelInfo.stop.item[2].type > (Dt_UINT32_1_0)sysStopYield) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[3].position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->roadModelInfo.stop.item[3].position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->roadModelInfo.stop.item[3].type > (Dt_UINT32_1_0)sysStopYield) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].time > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].time < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].vm.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].vm.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].vm.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].vm.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].vm.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].vm.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].limits.minAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].limits.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].limits.maxAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[0].limits.maxAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].time > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].time < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].vm.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].vm.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].vm.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].vm.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].vm.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].vm.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].limits.minAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].limits.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].limits.maxAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[1].limits.maxAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].time > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].time < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].vm.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].vm.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].vm.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].vm.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].vm.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].vm.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].limits.minAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].limits.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].limits.maxAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[2].limits.maxAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].time > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].time < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].vm.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].vm.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].vm.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].vm.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].vm.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].vm.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].limits.minAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].limits.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].limits.maxAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[3].limits.maxAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].time > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].time < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].vm.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].vm.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].vm.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].vm.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].vm.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].vm.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].limits.minAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].limits.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].limits.maxAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[4].limits.maxAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].time > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].time < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].vm.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].vm.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].vm.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].vm.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].vm.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].vm.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].limits.minAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].limits.minAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].limits.maxAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.segment[5].limits.maxAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->longTorque.preview.curve.type > (Dt_UINT32_1_0)constraintRoundabout) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.curve.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.curve.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.curve.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.curve.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.curve.acceleration > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.curve.acceleration < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.limit.acceleration > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.limit.acceleration < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.limit.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.limit.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.stop.acceleration > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.stop.acceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.stop.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.preview.stop.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.curveReach.reachVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.curveReach.reachVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.curveReach.curveVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->longTorque.curveReach.curveVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.count > (Dt_UINT16_1_0)sysINFOLIMITCOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.item[0].raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.item[1].raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.item[2].raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.item[3].raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.item[4].raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.limit.item[5].raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->roadModelInfo.stop.count > (Dt_UINT16_1_0)sysINFOSTOPCOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->longTorque.count > (Dt_UINT16_1_0)lntqOUTDISTANCE) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->strategyReport.count > (Dt_UINT16_1_0)srpREPORTCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->dataValidFlag > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->longTorque.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[0].gear > (Dt_UINT8_1_0)100u) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[0].fm > (Dt_UINT8_1_0)forceStateBackward) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[1].gear > (Dt_UINT8_1_0)100u) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[1].fm > (Dt_UINT8_1_0)forceStateBackward) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[2].gear > (Dt_UINT8_1_0)100u) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[2].fm > (Dt_UINT8_1_0)forceStateBackward) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[3].gear > (Dt_UINT8_1_0)100u) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[3].fm > (Dt_UINT8_1_0)forceStateBackward) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[4].gear > (Dt_UINT8_1_0)100u) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[4].fm > (Dt_UINT8_1_0)forceStateBackward) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[5].gear > (Dt_UINT8_1_0)100u) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.segment[5].fm > (Dt_UINT8_1_0)forceStateBackward) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->longTorque.preview.stop.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->longTorque.curveReach.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->debug.stabilizationRun > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->debug.strategyRun > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/

#endif


	return true;
}
/*lint -restore */

#endif
/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e641	"(Warning -- Converting enum to int)" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that */
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteOutConvert_pemPlanning(const pemPlanning_T *p_theSrcData, Dt_RECORD_PemPlanning *p_theDestData)
{
	uint32_T uiArrIdx;
	/*check the size of the received data*/
	BUILD_BUG_ON((uint32_T)(0 + comSTRATEGYBUFFERSIZE) > sizeof(p_theDestData->debug_data_buffer));

	p_theDestData->roadModelInfo_egoPosition = p_theSrcData->roadModelInfo.egoPosition;
	p_theDestData->roadModelInfo_limit_item_0_value = p_theSrcData->roadModelInfo.limit.item[0].value;
	p_theDestData->roadModelInfo_limit_item_0_position = p_theSrcData->roadModelInfo.limit.item[0].position;
	p_theDestData->roadModelInfo_limit_item_1_value = p_theSrcData->roadModelInfo.limit.item[1].value;
	p_theDestData->roadModelInfo_limit_item_1_position = p_theSrcData->roadModelInfo.limit.item[1].position;
	p_theDestData->roadModelInfo_limit_item_2_value = p_theSrcData->roadModelInfo.limit.item[2].value;
	p_theDestData->roadModelInfo_limit_item_2_position = p_theSrcData->roadModelInfo.limit.item[2].position;
	p_theDestData->roadModelInfo_limit_item_3_value = p_theSrcData->roadModelInfo.limit.item[3].value;
	p_theDestData->roadModelInfo_limit_item_3_position = p_theSrcData->roadModelInfo.limit.item[3].position;
	p_theDestData->roadModelInfo_limit_item_4_value = p_theSrcData->roadModelInfo.limit.item[4].value;
	p_theDestData->roadModelInfo_limit_item_4_position = p_theSrcData->roadModelInfo.limit.item[4].position;
	p_theDestData->roadModelInfo_limit_item_5_value = p_theSrcData->roadModelInfo.limit.item[5].value;
	p_theDestData->roadModelInfo_limit_item_5_position = p_theSrcData->roadModelInfo.limit.item[5].position;
	p_theDestData->roadModelInfo_stop_item_0_position = p_theSrcData->roadModelInfo.stop.item[0].position;
	p_theDestData->roadModelInfo_stop_item_0_type = p_theSrcData->roadModelInfo.stop.item[0].type;
	p_theDestData->roadModelInfo_stop_item_1_position = p_theSrcData->roadModelInfo.stop.item[1].position;
	p_theDestData->roadModelInfo_stop_item_1_type = p_theSrcData->roadModelInfo.stop.item[1].type;
	p_theDestData->roadModelInfo_stop_item_2_position = p_theSrcData->roadModelInfo.stop.item[2].position;
	p_theDestData->roadModelInfo_stop_item_2_type = p_theSrcData->roadModelInfo.stop.item[2].type;
	p_theDestData->roadModelInfo_stop_item_3_position = p_theSrcData->roadModelInfo.stop.item[3].position;
	p_theDestData->roadModelInfo_stop_item_3_type = p_theSrcData->roadModelInfo.stop.item[3].type;
	p_theDestData->longTorque_segment_0_time = p_theSrcData->longTorque.segment[0].time;
	p_theDestData->longTorque_segment_0_vm_position = p_theSrcData->longTorque.segment[0].vm.position;
	p_theDestData->longTorque_segment_0_vm_velocity = p_theSrcData->longTorque.segment[0].vm.velocity;
	p_theDestData->longTorque_segment_0_vm_acceleration = p_theSrcData->longTorque.segment[0].vm.acceleration;
	p_theDestData->longTorque_segment_0_limits_minAcceleration = p_theSrcData->longTorque.segment[0].limits.minAcceleration;
	p_theDestData->longTorque_segment_0_limits_maxAcceleration = p_theSrcData->longTorque.segment[0].limits.maxAcceleration;
	p_theDestData->longTorque_segment_1_time = p_theSrcData->longTorque.segment[1].time;
	p_theDestData->longTorque_segment_1_vm_position = p_theSrcData->longTorque.segment[1].vm.position;
	p_theDestData->longTorque_segment_1_vm_velocity = p_theSrcData->longTorque.segment[1].vm.velocity;
	p_theDestData->longTorque_segment_1_vm_acceleration = p_theSrcData->longTorque.segment[1].vm.acceleration;
	p_theDestData->longTorque_segment_1_limits_minAcceleration = p_theSrcData->longTorque.segment[1].limits.minAcceleration;
	p_theDestData->longTorque_segment_1_limits_maxAcceleration = p_theSrcData->longTorque.segment[1].limits.maxAcceleration;
	p_theDestData->longTorque_segment_2_time = p_theSrcData->longTorque.segment[2].time;
	p_theDestData->longTorque_segment_2_vm_position = p_theSrcData->longTorque.segment[2].vm.position;
	p_theDestData->longTorque_segment_2_vm_velocity = p_theSrcData->longTorque.segment[2].vm.velocity;
	p_theDestData->longTorque_segment_2_vm_acceleration = p_theSrcData->longTorque.segment[2].vm.acceleration;
	p_theDestData->longTorque_segment_2_limits_minAcceleration = p_theSrcData->longTorque.segment[2].limits.minAcceleration;
	p_theDestData->longTorque_segment_2_limits_maxAcceleration = p_theSrcData->longTorque.segment[2].limits.maxAcceleration;
	p_theDestData->longTorque_segment_3_time = p_theSrcData->longTorque.segment[3].time;
	p_theDestData->longTorque_segment_3_vm_position = p_theSrcData->longTorque.segment[3].vm.position;
	p_theDestData->longTorque_segment_3_vm_velocity = p_theSrcData->longTorque.segment[3].vm.velocity;
	p_theDestData->longTorque_segment_3_vm_acceleration = p_theSrcData->longTorque.segment[3].vm.acceleration;
	p_theDestData->longTorque_segment_3_limits_minAcceleration = p_theSrcData->longTorque.segment[3].limits.minAcceleration;
	p_theDestData->longTorque_segment_3_limits_maxAcceleration = p_theSrcData->longTorque.segment[3].limits.maxAcceleration;
	p_theDestData->longTorque_segment_4_time = p_theSrcData->longTorque.segment[4].time;
	p_theDestData->longTorque_segment_4_vm_position = p_theSrcData->longTorque.segment[4].vm.position;
	p_theDestData->longTorque_segment_4_vm_velocity = p_theSrcData->longTorque.segment[4].vm.velocity;
	p_theDestData->longTorque_segment_4_vm_acceleration = p_theSrcData->longTorque.segment[4].vm.acceleration;
	p_theDestData->longTorque_segment_4_limits_minAcceleration = p_theSrcData->longTorque.segment[4].limits.minAcceleration;
	p_theDestData->longTorque_segment_4_limits_maxAcceleration = p_theSrcData->longTorque.segment[4].limits.maxAcceleration;
	p_theDestData->longTorque_segment_5_time = p_theSrcData->longTorque.segment[5].time;
	p_theDestData->longTorque_segment_5_vm_position = p_theSrcData->longTorque.segment[5].vm.position;
	p_theDestData->longTorque_segment_5_vm_velocity = p_theSrcData->longTorque.segment[5].vm.velocity;
	p_theDestData->longTorque_segment_5_vm_acceleration = p_theSrcData->longTorque.segment[5].vm.acceleration;
	p_theDestData->longTorque_segment_5_limits_minAcceleration = p_theSrcData->longTorque.segment[5].limits.minAcceleration;
	p_theDestData->longTorque_segment_5_limits_maxAcceleration = p_theSrcData->longTorque.segment[5].limits.maxAcceleration;
	p_theDestData->longTorque_preview_curve_type = p_theSrcData->longTorque.preview.curve.type;
	p_theDestData->longTorque_preview_curve_position = p_theSrcData->longTorque.preview.curve.position;
	p_theDestData->longTorque_preview_curve_velocity = p_theSrcData->longTorque.preview.curve.velocity;
	p_theDestData->longTorque_preview_curve_acceleration = p_theSrcData->longTorque.preview.curve.acceleration;
	p_theDestData->longTorque_preview_limit_acceleration = p_theSrcData->longTorque.preview.limit.acceleration;
	p_theDestData->longTorque_preview_limit_position = p_theSrcData->longTorque.preview.limit.position;
	p_theDestData->longTorque_preview_stop_acceleration = p_theSrcData->longTorque.preview.stop.acceleration;
	p_theDestData->longTorque_preview_stop_position = p_theSrcData->longTorque.preview.stop.position;
	p_theDestData->longTorque_curveReach_reachVelocity = p_theSrcData->longTorque.curveReach.reachVelocity;
	p_theDestData->longTorque_curveReach_curveVelocity = p_theSrcData->longTorque.curveReach.curveVelocity;
	p_theDestData->strategyReport_aliveCounter = p_theSrcData->strategyReport.aliveCounter;
	p_theDestData->debug_times_start = p_theSrcData->debug.times.start;
	p_theDestData->debug_times_longStabScheduler = p_theSrcData->debug.times.longStabScheduler;
	p_theDestData->debug_times_roadProcessor = p_theSrcData->debug.times.roadProcessor;
	p_theDestData->debug_times_constraintMaster = p_theSrcData->debug.times.constraintMaster;
	p_theDestData->debug_times_longStabPlanner = p_theSrcData->debug.times.longStabPlanner;
	p_theDestData->debug_times_longTorquePlanner = p_theSrcData->debug.times.longTorquePlanner;
	p_theDestData->debug_times_longPathPlanner = p_theSrcData->debug.times.longPathPlanner;
	p_theDestData->debug_times_end = p_theSrcData->debug.times.end;
	p_theDestData->roadModelInfo_limit_count = p_theSrcData->roadModelInfo.limit.count;
	p_theDestData->roadModelInfo_limit_item_0_raw = p_theSrcData->roadModelInfo.limit.item[0].raw;
	p_theDestData->roadModelInfo_limit_item_1_raw = p_theSrcData->roadModelInfo.limit.item[1].raw;
	p_theDestData->roadModelInfo_limit_item_2_raw = p_theSrcData->roadModelInfo.limit.item[2].raw;
	p_theDestData->roadModelInfo_limit_item_3_raw = p_theSrcData->roadModelInfo.limit.item[3].raw;
	p_theDestData->roadModelInfo_limit_item_4_raw = p_theSrcData->roadModelInfo.limit.item[4].raw;
	p_theDestData->roadModelInfo_limit_item_5_raw = p_theSrcData->roadModelInfo.limit.item[5].raw;
	p_theDestData->roadModelInfo_stop_count = p_theSrcData->roadModelInfo.stop.count;
	p_theDestData->longTorque_count = p_theSrcData->longTorque.count;
	p_theDestData->strategyReport_count = p_theSrcData->strategyReport.count;

	BUILD_BUG_ON((uint32_T)srpREPORTCOUNT != sizeof(p_theSrcData->strategyReport.item) / sizeof(p_theSrcData->strategyReport.item[0]));
	for( uiArrIdx = 0; uiArrIdx < (uint32_T)srpREPORTCOUNT; uiArrIdx++)
	{
		p_theDestData->strategyReport_item[uiArrIdx] = p_theSrcData->strategyReport.item[uiArrIdx]; 
	}
	p_theDestData->debug_data_index = p_theSrcData->debug.data.index;
	p_theDestData->debug_data_count = p_theSrcData->debug.data.count;
	p_theDestData->debug_data_size = p_theSrcData->debug.data.size;
	p_theDestData->dataValidFlag = p_theSrcData->dataValidFlag;
	p_theDestData->longTorque_valid = p_theSrcData->longTorque.valid;
	p_theDestData->longTorque_segment_0_gear = p_theSrcData->longTorque.segment[0].gear;
	p_theDestData->longTorque_segment_0_fm = p_theSrcData->longTorque.segment[0].fm;
	p_theDestData->longTorque_segment_1_gear = p_theSrcData->longTorque.segment[1].gear;
	p_theDestData->longTorque_segment_1_fm = p_theSrcData->longTorque.segment[1].fm;
	p_theDestData->longTorque_segment_2_gear = p_theSrcData->longTorque.segment[2].gear;
	p_theDestData->longTorque_segment_2_fm = p_theSrcData->longTorque.segment[2].fm;
	p_theDestData->longTorque_segment_3_gear = p_theSrcData->longTorque.segment[3].gear;
	p_theDestData->longTorque_segment_3_fm = p_theSrcData->longTorque.segment[3].fm;
	p_theDestData->longTorque_segment_4_gear = p_theSrcData->longTorque.segment[4].gear;
	p_theDestData->longTorque_segment_4_fm = p_theSrcData->longTorque.segment[4].fm;
	p_theDestData->longTorque_segment_5_gear = p_theSrcData->longTorque.segment[5].gear;
	p_theDestData->longTorque_segment_5_fm = p_theSrcData->longTorque.segment[5].fm;
	p_theDestData->longTorque_preview_stop_valid = p_theSrcData->longTorque.preview.stop.valid;
	p_theDestData->longTorque_curveReach_valid = p_theSrcData->longTorque.curveReach.valid;

	for(uiArrIdx = 0; uiArrIdx < (uint32_T)comSTRATEGYBUFFERSIZE; uiArrIdx++)
	{
		p_theDestData->debug_data_buffer[uiArrIdx] = p_theSrcData->debug.data.buffer[uiArrIdx]; 
	}
	p_theDestData->debug_stabilizationRun = p_theSrcData->debug.stabilizationRun;
	p_theDestData->debug_strategyRun = p_theSrcData->debug.strategyRun;

	/* The complete structure length is: 1236 Bytes.*/

	return true;
}
/*lint -restore */

