#include "common/swcCommunication/PpPemControl.h"

/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteInConvert_pemControl(const Dt_RECORD_PemControl *p_theSrcData, pemControl_T *p_theDestData)
{
	uint32_T uiArrIdx;
#if defined(ID2_DEBUG_CROSS_ACCESS) && defined(_MSC_VER)
	memset(p_theDestData, 0, sizeof(pemControl_T));
#endif

	/*check the size of the received data*/
	BUILD_BUG_ON((uint32_T)(0 + comCONTROLBUFFERSIZE) > sizeof(p_theSrcData->debug_data_buffer));

	p_theDestData->vehicleState.tickCount = p_theSrcData->vehicleState_tickCount;
	p_theDestData->vehicleState.velocity.position = p_theSrcData->vehicleState_velocity_position;
	p_theDestData->vehicleState.velocity.velocity = p_theSrcData->vehicleState_velocity_velocity;
	p_theDestData->vehicleState.velocity.acceleration = p_theSrcData->vehicleState_velocity_acceleration;
	p_theDestData->vehicleState.powertrain.simple = p_theSrcData->vehicleState_powertrain_simple;
	p_theDestData->vehicleState.powertrain.rawSimple = p_theSrcData->vehicleState_powertrain_rawSimple;
	p_theDestData->vehicleState.powertrain.torque = p_theSrcData->vehicleState_powertrain_torque;
	p_theDestData->vehicleState.powertrain.maxAccelerationElectric = p_theSrcData->vehicleState_powertrain_maxAccelerationElectric;
	p_theDestData->vehicleState.powertrain.driveMode = p_theSrcData->vehicleState_powertrain_driveMode;
	p_theDestData->vehicleState.deviation.engaged = p_theSrcData->vehicleState_deviation_engaged;
	p_theDestData->vehicleState.deviation.disengaged = p_theSrcData->vehicleState_deviation_disengaged;
	p_theDestData->vehicleState.deviation.lockAccleration = p_theSrcData->vehicleState_deviation_lockAccleration;
	p_theDestData->vehicleState.heading.heading = p_theSrcData->vehicleState_heading_heading;
	p_theDestData->vehicleState.steering.curvature = p_theSrcData->vehicleState_steering_curvature;
	p_theDestData->vehicleState.steering.predCurvature = p_theSrcData->vehicleState_steering_predCurvature;
	p_theDestData->vehicleState.steering.predDistance = p_theSrcData->vehicleState_steering_predDistance;
	p_theDestData->vehicleState.steering.slowCurvature = p_theSrcData->vehicleState_steering_slowCurvature;
	p_theDestData->vehicleState.curvature.curvature = p_theSrcData->vehicleState_curvature_curvature;
	p_theDestData->vehicleState.curvature.curveRate = p_theSrcData->vehicleState_curvature_curveRate;
	p_theDestData->vehicleState.curvature.horizon = p_theSrcData->vehicleState_curvature_horizon;
	p_theDestData->vehicleState.curvature.confidence = p_theSrcData->vehicleState_curvature_confidence;
	p_theDestData->vehicleState.courage.curvatureFactor = p_theSrcData->vehicleState_courage_curvatureFactor;
	p_theDestData->vehicleState.courage.limitJerkFactor = p_theSrcData->vehicleState_courage_limitJerkFactor;
	p_theDestData->vehicleState.courage.curveJerkFactor = p_theSrcData->vehicleState_courage_curveJerkFactor;
	p_theDestData->vehicleState.courage.maxJerkFactor = p_theSrcData->vehicleState_courage_maxJerkFactor;
	p_theDestData->vehicleState.courage.curtainFactor = p_theSrcData->vehicleState_courage_curtainFactor;
	p_theDestData->vehicleState.turnSignal.turnSignal = p_theSrcData->vehicleState_turnSignal_turnSignal;
	p_theDestData->vehicleState.turnSignal.position = p_theSrcData->vehicleState_turnSignal_position;
	p_theDestData->vehicleState.slope.slope = p_theSrcData->vehicleState_slope_slope;
	p_theDestData->vehicleState.traffic.position = p_theSrcData->vehicleState_traffic_position;
	p_theDestData->vehicleState.traffic.velocity = p_theSrcData->vehicleState_traffic_velocity;
	p_theDestData->vehicleState.traffic.acceleration = p_theSrcData->vehicleState_traffic_acceleration;
	p_theDestData->vehicleState.unfiltered.velocity = p_theSrcData->vehicleState_unfiltered_velocity;
	p_theDestData->vehicleState.unfiltered.displayVelocity = p_theSrcData->vehicleState_unfiltered_displayVelocity;
	p_theDestData->vehicleState.unfiltered.longAcceleration = p_theSrcData->vehicleState_unfiltered_longAcceleration;
	p_theDestData->vehicleState.unfiltered.latAcceleration = p_theSrcData->vehicleState_unfiltered_latAcceleration;
	p_theDestData->vehicleState.unfiltered.accelerator = p_theSrcData->vehicleState_unfiltered_accelerator;
	p_theDestData->vehicleState.sign.current.position = p_theSrcData->vehicleState_sign_current_position;
	p_theDestData->vehicleState.sign.current.velocity = p_theSrcData->vehicleState_sign_current_velocity;
	p_theDestData->vehicleState.sign.predicted.position = p_theSrcData->vehicleState_sign_predicted_position;
	p_theDestData->vehicleState.sign.predicted.velocity = p_theSrcData->vehicleState_sign_predicted_velocity;
	p_theDestData->vehicleState.sign.conditions.trailerLimit = p_theSrcData->vehicleState_sign_conditions_trailerLimit;
	p_theDestData->systemControl.status = p_theSrcData->systemControl_status;
	p_theDestData->systemControl.displayError = p_theSrcData->systemControl_displayError;
	p_theDestData->systemControl.mode = p_theSrcData->systemControl_mode;
	p_theDestData->systemControl.previewPosition = p_theSrcData->systemControl_previewPosition;
	p_theDestData->systemControl.previousSetSpeed.value = p_theSrcData->systemControl_previousSetSpeed_value;
	p_theDestData->systemControl.previousSetSpeed.position = p_theSrcData->systemControl_previousSetSpeed_position;
	p_theDestData->systemControl.currentSetSpeed.value = p_theSrcData->systemControl_currentSetSpeed_value;
	p_theDestData->systemControl.currentSetSpeed.position = p_theSrcData->systemControl_currentSetSpeed_position;
	p_theDestData->systemControl.nextSetSpeed.value = p_theSrcData->systemControl_nextSetSpeed_value;
	p_theDestData->systemControl.nextSetSpeed.position = p_theSrcData->systemControl_nextSetSpeed_position;
	p_theDestData->systemControl.toleranceFactor = p_theSrcData->systemControl_toleranceFactor;
	p_theDestData->systemControl.stopSweepPosition = p_theSrcData->systemControl_stopSweepPosition;
	p_theDestData->systemControl.stopInRange = p_theSrcData->systemControl_stopInRange;
	p_theDestData->mapPath.headingCorrection = p_theSrcData->mapPath_headingCorrection;
	p_theDestData->mapPath.positionZero = p_theSrcData->mapPath_positionZero;
	p_theDestData->mapPath.info.gpsInfo.latitude = p_theSrcData->mapPath_info_gpsInfo_latitude;
	p_theDestData->mapPath.info.gpsInfo.longitude = p_theSrcData->mapPath_info_gpsInfo_longitude;
	p_theDestData->mapPath.info.curvatureRing.curvature[0].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_0_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[1].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_1_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[2].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_2_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[3].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_3_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[4].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_4_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[5].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_5_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[6].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_6_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[7].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_7_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[8].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_8_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[9].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_9_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[10].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_10_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[11].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_11_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[12].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_12_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[13].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_13_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[14].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_14_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[15].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_15_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[16].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_16_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[17].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_17_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[18].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_18_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[19].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_19_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[20].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_20_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[21].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_21_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[22].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_22_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[23].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_23_curvature;
	p_theDestData->mapPath.info.curvatureRing.curvature[24].curvature = p_theSrcData->mapPath_info_curvatureRing_curvature_24_curvature;
	p_theDestData->longTrigger.priorityTick = p_theSrcData->longTrigger_priorityTick;
	p_theDestData->systemControl.fodStatus = p_theSrcData->reserved_uint32_00;
	p_theDestData->debug.times.start = p_theSrcData->debug_times_start;
	p_theDestData->debug.times.inputCodec = p_theSrcData->debug_times_inputCodec;
	p_theDestData->debug.times.vehicleObserver = p_theSrcData->debug_times_vehicleObserver;
	p_theDestData->debug.times.pathRouter = p_theSrcData->debug_times_pathRouter;
	p_theDestData->debug.times.systemController = p_theSrcData->debug_times_systemController;
	p_theDestData->debug.times.longController = p_theSrcData->debug_times_longController;
	p_theDestData->debug.times.longStabTrigger = p_theSrcData->debug_times_longStabTrigger;
	p_theDestData->debug.times.displayController = p_theSrcData->debug_times_displayController;
	p_theDestData->debug.times.driverObserver = p_theSrcData->debug_times_driverObserver;
	p_theDestData->debug.times.driverPredictor = p_theSrcData->debug_times_driverPredictor;
	p_theDestData->debug.times.outputCodec = p_theSrcData->debug_times_outputCodec;
	p_theDestData->debug.times.end = p_theSrcData->debug_times_end;
	p_theDestData->vehicleState.sign.current.raw = p_theSrcData->vehicleState_sign_current_raw;
	p_theDestData->vehicleState.sign.predicted.raw = p_theSrcData->vehicleState_sign_predicted_raw;
	p_theDestData->vehicleState.sign.conditions.trailerRaw = p_theSrcData->vehicleState_sign_conditions_trailerRaw;
	p_theDestData->vehicleState.vMax.kmh = p_theSrcData->vehicleState_vMax_kmh;
	p_theDestData->vehicleState.vMax.mph = p_theSrcData->vehicleState_vMax_mph;
	p_theDestData->systemControl.errorTicks = p_theSrcData->systemControl_errorTicks;
	p_theDestData->systemControl.distIndex = p_theSrcData->systemControl_distIndex;
	p_theDestData->systemControl.previousSetSpeed.raw = p_theSrcData->systemControl_previousSetSpeed_raw;
	p_theDestData->systemControl.currentSetSpeed.raw = p_theSrcData->systemControl_currentSetSpeed_raw;
	p_theDestData->systemControl.nextSetSpeed.raw = p_theSrcData->systemControl_nextSetSpeed_raw;
	p_theDestData->systemControl.previewLimit = p_theSrcData->systemControl_previewLimit;
	p_theDestData->mapPath.info.gpsInfo.heading = p_theSrcData->mapPath_info_gpsInfo_heading;
	p_theDestData->mapPath.info.gpsInfo.altitude = p_theSrcData->mapPath_info_gpsInfo_altitude;
	p_theDestData->mapPath.info.gpsInfo.position = p_theSrcData->mapPath_info_gpsInfo_position;
	p_theDestData->mapPath.info.systemAttributes.countryCode = p_theSrcData->mapPath_info_systemAttributes_countryCode;
	p_theDestData->mapPath.info.distance = p_theSrcData->mapPath_info_distance;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[0].position = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_0_position;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[1].position = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_1_position;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[2].position = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_2_position;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[3].position = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_3_position;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[4].position = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_4_position;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[5].position = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_5_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[0].position = p_theSrcData->mapPath_info_curvatureRing_curvature_0_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[1].position = p_theSrcData->mapPath_info_curvatureRing_curvature_1_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[2].position = p_theSrcData->mapPath_info_curvatureRing_curvature_2_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[3].position = p_theSrcData->mapPath_info_curvatureRing_curvature_3_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[4].position = p_theSrcData->mapPath_info_curvatureRing_curvature_4_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[5].position = p_theSrcData->mapPath_info_curvatureRing_curvature_5_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[6].position = p_theSrcData->mapPath_info_curvatureRing_curvature_6_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[7].position = p_theSrcData->mapPath_info_curvatureRing_curvature_7_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[8].position = p_theSrcData->mapPath_info_curvatureRing_curvature_8_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[9].position = p_theSrcData->mapPath_info_curvatureRing_curvature_9_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[10].position = p_theSrcData->mapPath_info_curvatureRing_curvature_10_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[11].position = p_theSrcData->mapPath_info_curvatureRing_curvature_11_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[12].position = p_theSrcData->mapPath_info_curvatureRing_curvature_12_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[13].position = p_theSrcData->mapPath_info_curvatureRing_curvature_13_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[14].position = p_theSrcData->mapPath_info_curvatureRing_curvature_14_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[15].position = p_theSrcData->mapPath_info_curvatureRing_curvature_15_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[16].position = p_theSrcData->mapPath_info_curvatureRing_curvature_16_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[17].position = p_theSrcData->mapPath_info_curvatureRing_curvature_17_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[18].position = p_theSrcData->mapPath_info_curvatureRing_curvature_18_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[19].position = p_theSrcData->mapPath_info_curvatureRing_curvature_19_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[20].position = p_theSrcData->mapPath_info_curvatureRing_curvature_20_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[21].position = p_theSrcData->mapPath_info_curvatureRing_curvature_21_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[22].position = p_theSrcData->mapPath_info_curvatureRing_curvature_22_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[23].position = p_theSrcData->mapPath_info_curvatureRing_curvature_23_position;
	p_theDestData->mapPath.info.curvatureRing.curvature[24].position = p_theSrcData->mapPath_info_curvatureRing_curvature_24_position;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[0].angle = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_0_angle;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[0].position = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_0_position;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[1].angle = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_1_angle;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[1].position = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_1_position;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[2].angle = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_2_angle;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[2].position = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_2_position;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[3].angle = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_3_angle;
	p_theDestData->mapPath.info.branchAngleRing.branchAngle[3].position = p_theSrcData->mapPath_info_branchAngleRing_branchAngle_3_position;
	p_theDestData->mapPath.info.slopeRing.slope[0].slope = p_theSrcData->mapPath_info_slopeRing_slope_0_slope;
	p_theDestData->mapPath.info.slopeRing.slope[0].position = p_theSrcData->mapPath_info_slopeRing_slope_0_position;
	p_theDestData->mapPath.info.slopeRing.slope[1].slope = p_theSrcData->mapPath_info_slopeRing_slope_1_slope;
	p_theDestData->mapPath.info.slopeRing.slope[1].position = p_theSrcData->mapPath_info_slopeRing_slope_1_position;
	p_theDestData->mapPath.info.slopeRing.slope[2].slope = p_theSrcData->mapPath_info_slopeRing_slope_2_slope;
	p_theDestData->mapPath.info.slopeRing.slope[2].position = p_theSrcData->mapPath_info_slopeRing_slope_2_position;
	p_theDestData->mapPath.info.slopeRing.slope[3].slope = p_theSrcData->mapPath_info_slopeRing_slope_3_slope;
	p_theDestData->mapPath.info.slopeRing.slope[3].position = p_theSrcData->mapPath_info_slopeRing_slope_3_position;
	p_theDestData->mapPath.info.slopeRing.slope[4].slope = p_theSrcData->mapPath_info_slopeRing_slope_4_slope;
	p_theDestData->mapPath.info.slopeRing.slope[4].position = p_theSrcData->mapPath_info_slopeRing_slope_4_position;
	p_theDestData->mapPath.info.slopeRing.slope[5].slope = p_theSrcData->mapPath_info_slopeRing_slope_5_slope;
	p_theDestData->mapPath.info.slopeRing.slope[5].position = p_theSrcData->mapPath_info_slopeRing_slope_5_position;
	p_theDestData->mapPath.info.slopeRing.slope[6].slope = p_theSrcData->mapPath_info_slopeRing_slope_6_slope;
	p_theDestData->mapPath.info.slopeRing.slope[6].position = p_theSrcData->mapPath_info_slopeRing_slope_6_position;
	p_theDestData->mapPath.info.slopeRing.slope[7].slope = p_theSrcData->mapPath_info_slopeRing_slope_7_slope;
	p_theDestData->mapPath.info.slopeRing.slope[7].position = p_theSrcData->mapPath_info_slopeRing_slope_7_position;
	p_theDestData->mapPath.info.slopeRing.slope[8].slope = p_theSrcData->mapPath_info_slopeRing_slope_8_slope;
	p_theDestData->mapPath.info.slopeRing.slope[8].position = p_theSrcData->mapPath_info_slopeRing_slope_8_position;
	p_theDestData->mapPath.info.slopeRing.slope[9].slope = p_theSrcData->mapPath_info_slopeRing_slope_9_slope;
	p_theDestData->mapPath.info.slopeRing.slope[9].position = p_theSrcData->mapPath_info_slopeRing_slope_9_position;
	p_theDestData->mapPath.info.slopeRing.slope[10].slope = p_theSrcData->mapPath_info_slopeRing_slope_10_slope;
	p_theDestData->mapPath.info.slopeRing.slope[10].position = p_theSrcData->mapPath_info_slopeRing_slope_10_position;
	p_theDestData->mapPath.info.slopeRing.slope[11].slope = p_theSrcData->mapPath_info_slopeRing_slope_11_slope;
	p_theDestData->mapPath.info.slopeRing.slope[11].position = p_theSrcData->mapPath_info_slopeRing_slope_11_position;
	p_theDestData->mapPath.info.slopeRing.slope[12].slope = p_theSrcData->mapPath_info_slopeRing_slope_12_slope;
	p_theDestData->mapPath.info.slopeRing.slope[12].position = p_theSrcData->mapPath_info_slopeRing_slope_12_position;
	p_theDestData->mapPath.info.slopeRing.slope[13].slope = p_theSrcData->mapPath_info_slopeRing_slope_13_slope;
	p_theDestData->mapPath.info.slopeRing.slope[13].position = p_theSrcData->mapPath_info_slopeRing_slope_13_position;
	p_theDestData->mapPath.info.slopeRing.slope[14].slope = p_theSrcData->mapPath_info_slopeRing_slope_14_slope;
	p_theDestData->mapPath.info.slopeRing.slope[14].position = p_theSrcData->mapPath_info_slopeRing_slope_14_position;
	p_theDestData->mapPath.info.slopeRing.slope[15].slope = p_theSrcData->mapPath_info_slopeRing_slope_15_slope;
	p_theDestData->mapPath.info.slopeRing.slope[15].position = p_theSrcData->mapPath_info_slopeRing_slope_15_position;
	p_theDestData->mapPath.info.slopeRing.slope[16].slope = p_theSrcData->mapPath_info_slopeRing_slope_16_slope;
	p_theDestData->mapPath.info.slopeRing.slope[16].position = p_theSrcData->mapPath_info_slopeRing_slope_16_position;
	p_theDestData->mapPath.info.slopeRing.slope[17].slope = p_theSrcData->mapPath_info_slopeRing_slope_17_slope;
	p_theDestData->mapPath.info.slopeRing.slope[17].position = p_theSrcData->mapPath_info_slopeRing_slope_17_position;
	p_theDestData->mapPath.info.slopeRing.slope[18].slope = p_theSrcData->mapPath_info_slopeRing_slope_18_slope;
	p_theDestData->mapPath.info.slopeRing.slope[18].position = p_theSrcData->mapPath_info_slopeRing_slope_18_position;
	p_theDestData->mapPath.info.slopeRing.slope[19].slope = p_theSrcData->mapPath_info_slopeRing_slope_19_slope;
	p_theDestData->mapPath.info.slopeRing.slope[19].position = p_theSrcData->mapPath_info_slopeRing_slope_19_position;
	p_theDestData->mapPath.info.slopeRing.slope[20].slope = p_theSrcData->mapPath_info_slopeRing_slope_20_slope;
	p_theDestData->mapPath.info.slopeRing.slope[20].position = p_theSrcData->mapPath_info_slopeRing_slope_20_position;
	p_theDestData->mapPath.info.slopeRing.slope[21].slope = p_theSrcData->mapPath_info_slopeRing_slope_21_slope;
	p_theDestData->mapPath.info.slopeRing.slope[21].position = p_theSrcData->mapPath_info_slopeRing_slope_21_position;
	p_theDestData->mapPath.info.slopeRing.slope[22].slope = p_theSrcData->mapPath_info_slopeRing_slope_22_slope;
	p_theDestData->mapPath.info.slopeRing.slope[22].position = p_theSrcData->mapPath_info_slopeRing_slope_22_position;
	p_theDestData->mapPath.info.slopeRing.slope[23].slope = p_theSrcData->mapPath_info_slopeRing_slope_23_slope;
	p_theDestData->mapPath.info.slopeRing.slope[23].position = p_theSrcData->mapPath_info_slopeRing_slope_23_position;
	p_theDestData->mapPath.info.slopeRing.slope[24].slope = p_theSrcData->mapPath_info_slopeRing_slope_24_slope;
	p_theDestData->mapPath.info.slopeRing.slope[24].position = p_theSrcData->mapPath_info_slopeRing_slope_24_position;
	p_theDestData->mapPath.info.slopeRing.slope[25].slope = p_theSrcData->mapPath_info_slopeRing_slope_25_slope;
	p_theDestData->mapPath.info.slopeRing.slope[25].position = p_theSrcData->mapPath_info_slopeRing_slope_25_position;
	p_theDestData->mapPath.info.slopeRing.slope[26].slope = p_theSrcData->mapPath_info_slopeRing_slope_26_slope;
	p_theDestData->mapPath.info.slopeRing.slope[26].position = p_theSrcData->mapPath_info_slopeRing_slope_26_position;
	p_theDestData->mapPath.info.slopeRing.slope[27].slope = p_theSrcData->mapPath_info_slopeRing_slope_27_slope;
	p_theDestData->mapPath.info.slopeRing.slope[27].position = p_theSrcData->mapPath_info_slopeRing_slope_27_position;
	p_theDestData->mapPath.info.slopeRing.slope[28].slope = p_theSrcData->mapPath_info_slopeRing_slope_28_slope;
	p_theDestData->mapPath.info.slopeRing.slope[28].position = p_theSrcData->mapPath_info_slopeRing_slope_28_position;
	p_theDestData->mapPath.info.slopeRing.slope[29].slope = p_theSrcData->mapPath_info_slopeRing_slope_29_slope;
	p_theDestData->mapPath.info.slopeRing.slope[29].position = p_theSrcData->mapPath_info_slopeRing_slope_29_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[0].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_0_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[1].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_1_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[2].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_2_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[3].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_3_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[4].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_4_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[5].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_5_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[6].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_6_position;
	p_theDestData->mapPath.info.builtUpRing.builtUp[7].position = p_theSrcData->mapPath_info_builtUpRing_builtUp_7_position;
	p_theDestData->mapPath.info.streetClassRing.streetClass[0].position = p_theSrcData->mapPath_info_streetClassRing_streetClass_0_position;
	p_theDestData->mapPath.info.streetClassRing.streetClass[1].position = p_theSrcData->mapPath_info_streetClassRing_streetClass_1_position;
	p_theDestData->mapPath.info.streetClassRing.streetClass[2].position = p_theSrcData->mapPath_info_streetClassRing_streetClass_2_position;
	p_theDestData->mapPath.info.streetClassRing.streetClass[3].position = p_theSrcData->mapPath_info_streetClassRing_streetClass_3_position;
	p_theDestData->mapPath.info.rampRing.ramp[0].position = p_theSrcData->mapPath_info_rampRing_ramp_0_position;
	p_theDestData->mapPath.info.rampRing.ramp[1].position = p_theSrcData->mapPath_info_rampRing_ramp_1_position;
	p_theDestData->mapPath.info.rampRing.ramp[2].position = p_theSrcData->mapPath_info_rampRing_ramp_2_position;
	p_theDestData->mapPath.info.rampRing.ramp[3].position = p_theSrcData->mapPath_info_rampRing_ramp_3_position;
	p_theDestData->mapPath.info.rampRing.ramp[4].position = p_theSrcData->mapPath_info_rampRing_ramp_4_position;
	p_theDestData->mapPath.info.rampRing.ramp[5].position = p_theSrcData->mapPath_info_rampRing_ramp_5_position;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[0].position = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_0_position;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[1].position = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_1_position;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[2].position = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_2_position;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[3].position = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_3_position;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[4].position = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_4_position;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[5].position = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_5_position;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[0].position = p_theSrcData->mapPath_info_roundaboutRing_roundabout_0_position;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[1].position = p_theSrcData->mapPath_info_roundaboutRing_roundabout_1_position;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[2].position = p_theSrcData->mapPath_info_roundaboutRing_roundabout_2_position;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[3].position = p_theSrcData->mapPath_info_roundaboutRing_roundabout_3_position;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[4].position = p_theSrcData->mapPath_info_roundaboutRing_roundabout_4_position;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[5].position = p_theSrcData->mapPath_info_roundaboutRing_roundabout_5_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_0_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_1_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_2_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_3_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_4_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_5_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_6_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_7_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_8_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_9_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_10_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_11_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_12_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_13_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_14_position;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].position = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_15_position;
	p_theDestData->debug.data.index = p_theSrcData->debug_data_index;
	p_theDestData->debug.data.count = p_theSrcData->debug_data_count;
	p_theDestData->debug.data.size = p_theSrcData->debug_data_size;
	p_theDestData->dataValidFlag = p_theSrcData->dataValidFlag;
	p_theDestData->vehicleState.valid = p_theSrcData->vehicleState_valid;
	p_theDestData->vehicleState.powertrain.gear = p_theSrcData->vehicleState_powertrain_gear;
	p_theDestData->vehicleState.powertrain.coastingPossible = p_theSrcData->vehicleState_powertrain_coastingPossible;
	p_theDestData->vehicleState.deviation.gearLock = p_theSrcData->vehicleState_deviation_gearLock;
	p_theDestData->vehicleState.heading.valid = p_theSrcData->vehicleState_heading_valid;
	p_theDestData->vehicleState.turnSignal.confident = p_theSrcData->vehicleState_turnSignal_confident;
	p_theDestData->vehicleState.turnSignal.extendHold = p_theSrcData->vehicleState_turnSignal_extendHold;
	p_theDestData->vehicleState.traffic.present = p_theSrcData->vehicleState_traffic_present;
	p_theDestData->vehicleState.sign.current.valid = p_theSrcData->vehicleState_sign_current_valid;
	p_theDestData->vehicleState.sign.predicted.valid = p_theSrcData->vehicleState_sign_predicted_valid;
	p_theDestData->vehicleState.sign.conditions.fog = p_theSrcData->vehicleState_sign_conditions_fog;
	p_theDestData->vehicleState.sign.conditions.wet = p_theSrcData->vehicleState_sign_conditions_wet;
	p_theDestData->vehicleState.sign.conditions.trailer = p_theSrcData->vehicleState_sign_conditions_trailer;
	p_theDestData->vehicleState.accBoost = p_theSrcData->vehicleState_accBoost;
	p_theDestData->systemControl.isAutoModeActive = p_theSrcData->systemControl_isAutoModeActive;
	p_theDestData->systemControl.dsplLimitEventsActive = p_theSrcData->systemControl_dsplLimitEventsActive;
	p_theDestData->systemControl.setDisplayValid = p_theSrcData->systemControl_setDisplayValid;
	p_theDestData->systemControl.previewLock = p_theSrcData->systemControl_previewLock;
	p_theDestData->systemControl.stopTakeover = p_theSrcData->systemControl_stopTakeover;
	p_theDestData->systemControl.overrideReturn = p_theSrcData->systemControl_overrideReturn;
	p_theDestData->systemControl.unsuccessfulActivation = p_theSrcData->systemControl_unsuccessfulActivation;
	p_theDestData->systemControl.showHint = p_theSrcData->systemControl_showHint;
	p_theDestData->mapPath.valid = p_theSrcData->mapPath_valid;
	p_theDestData->mapPath.lowExecutionTime = p_theSrcData->mapPath_lowExecutionTime;
	p_theDestData->mapPath.positionResetCount = p_theSrcData->mapPath_positionResetCount;
	p_theDestData->mapPath.rerouteCount = p_theSrcData->mapPath_rerouteCount;
	p_theDestData->mapPath.info.systemAttributes.qualityGeometry = p_theSrcData->mapPath_info_systemAttributes_qualityGeometry;
	p_theDestData->mapPath.info.systemAttributes.speedLimitUnit = p_theSrcData->mapPath_info_systemAttributes_speedLimitUnit;
	p_theDestData->mapPath.info.systemAttributes.trafficDirection = p_theSrcData->mapPath_info_systemAttributes_trafficDirection;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[0].value = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_0_value;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[0].codedInfo = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_0_codedInfo;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[1].value = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_1_value;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[1].codedInfo = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_1_codedInfo;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[2].value = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_2_value;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[2].codedInfo = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_2_codedInfo;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[3].value = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_3_value;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[3].codedInfo = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_3_codedInfo;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[4].value = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_4_value;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[4].codedInfo = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_4_codedInfo;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[5].value = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_5_value;
	p_theDestData->mapPath.info.speedLimitRing.speedLimit[5].codedInfo = p_theSrcData->mapPath_info_speedLimitRing_speedLimit_5_codedInfo;
	p_theDestData->mapPath.info.speedLimitRing.count = p_theSrcData->mapPath_info_speedLimitRing_count;
	p_theDestData->mapPath.info.curvatureRing.curvature[0].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_0_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[0].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_0_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[1].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_1_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[1].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_1_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[2].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_2_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[2].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_2_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[3].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_3_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[3].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_3_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[4].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_4_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[4].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_4_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[5].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_5_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[5].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_5_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[6].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_6_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[6].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_6_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[7].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_7_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[7].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_7_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[8].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_8_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[8].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_8_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[9].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_9_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[9].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_9_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[10].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_10_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[10].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_10_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[11].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_11_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[11].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_11_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[12].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_12_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[12].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_12_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[13].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_13_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[13].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_13_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[14].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_14_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[14].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_14_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[15].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_15_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[15].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_15_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[16].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_16_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[16].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_16_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[17].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_17_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[17].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_17_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[18].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_18_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[18].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_18_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[19].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_19_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[19].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_19_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[20].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_20_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[20].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_20_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[21].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_21_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[21].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_21_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[22].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_22_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[22].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_22_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[23].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_23_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[23].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_23_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.curvature[24].segmentId = p_theSrcData->mapPath_info_curvatureRing_curvature_24_segmentId;
	p_theDestData->mapPath.info.curvatureRing.curvature[24].endOfConstantSegmentMissing = p_theSrcData->mapPath_info_curvatureRing_curvature_24_endOfConstantSegmentMissing;
	p_theDestData->mapPath.info.curvatureRing.count = p_theSrcData->mapPath_info_curvatureRing_count;
	p_theDestData->mapPath.info.branchAngleRing.count = p_theSrcData->mapPath_info_branchAngleRing_count;
	p_theDestData->mapPath.info.slopeRing.count = p_theSrcData->mapPath_info_slopeRing_count;
	p_theDestData->mapPath.info.builtUpRing.builtUp[0].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_0_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[1].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_1_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[2].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_2_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[3].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_3_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[4].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_4_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[5].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_5_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[6].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_6_builtUp;
	p_theDestData->mapPath.info.builtUpRing.builtUp[7].builtUp = p_theSrcData->mapPath_info_builtUpRing_builtUp_7_builtUp;
	p_theDestData->mapPath.info.builtUpRing.count = p_theSrcData->mapPath_info_builtUpRing_count;
	p_theDestData->mapPath.info.streetClassRing.count = p_theSrcData->mapPath_info_streetClassRing_count;
	p_theDestData->mapPath.info.streetClassRing.streetClass[0].type = p_theSrcData->mapPath_info_streetClassRing_streetClass_0_type;
	p_theDestData->mapPath.info.streetClassRing.streetClass[1].type = p_theSrcData->mapPath_info_streetClassRing_streetClass_1_type;
	p_theDestData->mapPath.info.streetClassRing.streetClass[2].type = p_theSrcData->mapPath_info_streetClassRing_streetClass_2_type;
	p_theDestData->mapPath.info.streetClassRing.streetClass[3].type = p_theSrcData->mapPath_info_streetClassRing_streetClass_3_type;
	p_theDestData->mapPath.info.rampRing.count = p_theSrcData->mapPath_info_rampRing_count;
	p_theDestData->mapPath.info.rampRing.ramp[0].type = p_theSrcData->mapPath_info_rampRing_ramp_0_type;
	p_theDestData->mapPath.info.rampRing.ramp[1].type = p_theSrcData->mapPath_info_rampRing_ramp_1_type;
	p_theDestData->mapPath.info.rampRing.ramp[2].type = p_theSrcData->mapPath_info_rampRing_ramp_2_type;
	p_theDestData->mapPath.info.rampRing.ramp[3].type = p_theSrcData->mapPath_info_rampRing_ramp_3_type;
	p_theDestData->mapPath.info.rampRing.ramp[4].type = p_theSrcData->mapPath_info_rampRing_ramp_4_type;
	p_theDestData->mapPath.info.rampRing.ramp[5].type = p_theSrcData->mapPath_info_rampRing_ramp_5_type;
	p_theDestData->mapPath.info.rightOfWayRing.count = p_theSrcData->mapPath_info_rightOfWayRing_count;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[0].type = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_0_type;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[1].type = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_1_type;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[2].type = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_2_type;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[3].type = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_3_type;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[4].type = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_4_type;
	p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[5].type = p_theSrcData->mapPath_info_rightOfWayRing_rightOfWayControl_5_type;
	p_theDestData->mapPath.info.roundaboutRing.count = p_theSrcData->mapPath_info_roundaboutRing_count;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[0].roundabout = p_theSrcData->mapPath_info_roundaboutRing_roundabout_0_roundabout;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[1].roundabout = p_theSrcData->mapPath_info_roundaboutRing_roundabout_1_roundabout;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[2].roundabout = p_theSrcData->mapPath_info_roundaboutRing_roundabout_2_roundabout;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[3].roundabout = p_theSrcData->mapPath_info_roundaboutRing_roundabout_3_roundabout;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[4].roundabout = p_theSrcData->mapPath_info_roundaboutRing_roundabout_4_roundabout;
	p_theDestData->mapPath.info.roundaboutRing.roundabout[5].roundabout = p_theSrcData->mapPath_info_roundaboutRing_roundabout_5_roundabout;
	p_theDestData->mapPath.info.laneSituationRing.count = p_theSrcData->mapPath_info_laneSituationRing_count;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_0_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_0_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_0_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_0_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_1_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_1_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_1_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_1_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_2_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_2_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_2_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_2_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_3_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_3_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_3_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_3_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_4_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_4_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_4_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_4_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_5_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_5_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_5_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_5_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_6_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_6_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_6_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_6_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_7_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_7_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_7_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_7_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_8_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_8_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_8_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_8_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_9_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_9_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_9_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_9_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_10_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_10_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_10_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_10_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_11_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_11_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_11_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_11_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_12_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_12_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_12_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_12_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_13_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_13_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_13_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_13_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_14_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_14_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_14_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_14_turnLanesRight;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].forwardLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_15_forwardLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].oppositeLanes = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_15_oppositeLanes;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].turnLanesLeft = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_15_turnLanesLeft;
	p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].turnLanesRight = p_theSrcData->mapPath_info_laneSituationRing_laneSituation_15_turnLanesRight;

	for(uiArrIdx = 0; uiArrIdx < (uint32_T)comCONTROLBUFFERSIZE; uiArrIdx++)
	{
		p_theDestData->debug.data.buffer[uiArrIdx] = p_theSrcData->debug_data_buffer[uiArrIdx]; 
	}

	/* The complete structure length is: 1211 Bytes.*/

	return true;
}
/*lint -restore */

#if !defined INNODRIVE_ZFAS_SWC_BUILD
/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e529 (Warning -- Symbol 'uiArrIdx' (line 1309) not subsequently referenced)*/
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteCheckBounds_pemControl(const pemControl_T *p_theDestData)
{

#if !defined INNODRIVE_ZFAS_SWC_BUILD
	if((Dt_FLOAT32)p_theDestData->vehicleState.velocity.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.velocity.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.velocity.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.velocity.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.velocity.acceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.velocity.acceleration < (Dt_FLOAT32)-10.f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->vehicleState.powertrain.simple > (Dt_UINT32_1_0)simpleStateEOF) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->vehicleState.powertrain.rawSimple > (Dt_UINT32_1_0)simpleStateEOF) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.powertrain.torque > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.powertrain.torque < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.powertrain.maxAccelerationElectric > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.powertrain.maxAccelerationElectric < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->vehicleState.powertrain.driveMode > (Dt_UINT32_1_0)drvMdEpower) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.deviation.engaged > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.deviation.engaged < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.deviation.disengaged > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.deviation.disengaged < (Dt_FLOAT32)-10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.deviation.lockAccleration > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.deviation.lockAccleration < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.heading.heading > (Dt_FLOAT32)360.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.heading.heading < (Dt_FLOAT32)-360.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.curvature > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.curvature < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.predCurvature > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.predCurvature < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.predDistance > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.predDistance < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.slowCurvature > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.steering.slowCurvature < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.curvature > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.curvature < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.curveRate > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.curveRate < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.horizon > (Dt_FLOAT32)10000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.horizon < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.confidence > (Dt_FLOAT32)1.1f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.curvature.confidence < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.curvatureFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.curvatureFactor < (Dt_FLOAT32)-1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.limitJerkFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.limitJerkFactor < (Dt_FLOAT32)-1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.curveJerkFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.curveJerkFactor < (Dt_FLOAT32)-1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.maxJerkFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.maxJerkFactor < (Dt_FLOAT32)-1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.curtainFactor > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.courage.curtainFactor < (Dt_FLOAT32)-1.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->vehicleState.turnSignal.turnSignal > (Dt_UINT32_1_0)turnSignalLockBoth) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.turnSignal.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.turnSignal.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.slope.slope > (Dt_FLOAT32)1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.slope.slope < (Dt_FLOAT32)-1.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.traffic.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.traffic.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.traffic.velocity > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.traffic.velocity < (Dt_FLOAT32)-343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.traffic.acceleration > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.traffic.acceleration < (Dt_FLOAT32)-100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.displayVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.displayVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.longAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.longAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.latAcceleration > (Dt_FLOAT32)10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.latAcceleration < (Dt_FLOAT32)-10.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.accelerator > (Dt_FLOAT32)200.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.unfiltered.accelerator < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.current.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.current.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.current.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.current.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.predicted.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.predicted.position < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.predicted.velocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.predicted.velocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.conditions.trailerLimit > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->vehicleState.sign.conditions.trailerLimit < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->systemControl.status > (Dt_UINT32_1_0)sysStatusOverride) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->systemControl.displayError > (Dt_UINT32_1_0)sysErrorAccIrreversible) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->systemControl.mode > (Dt_UINT32_1_0)sysModeEconomy) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.previewPosition > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.previewPosition < (Dt_FLOAT32)0.0) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.previousSetSpeed.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.previousSetSpeed.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.previousSetSpeed.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.previousSetSpeed.position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.currentSetSpeed.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.currentSetSpeed.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.currentSetSpeed.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.currentSetSpeed.position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.nextSetSpeed.value > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.nextSetSpeed.value < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.nextSetSpeed.position > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.nextSetSpeed.position < (Dt_FLOAT32)-INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.toleranceFactor > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.toleranceFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.stopSweepPosition > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->systemControl.stopSweepPosition < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->systemControl.stopInRange > (Dt_UINT32_1_0)sysStopYield) { return false; }
	if((Dt_FLOAT32)p_theDestData->mapPath.headingCorrection > (Dt_FLOAT32)360.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->mapPath.headingCorrection < (Dt_FLOAT32)-360.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->mapPath.positionZero > (Dt_FLOAT32)INVALID_VALUE) { return false; }
	if((Dt_FLOAT32)p_theDestData->mapPath.positionZero < (Dt_FLOAT32)-1000.0f) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.gpsInfo.latitude > (Dt_UINT32_1_0)1800000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.gpsInfo.longitude > (Dt_UINT32_1_0)3600000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[0].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[1].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[2].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[3].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[4].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[5].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[6].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[7].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[8].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[9].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[10].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[11].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[12].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[13].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[14].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[15].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[16].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[17].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[18].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[19].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[20].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[21].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[22].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[23].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[24].curvature > (Dt_UINT32_1_0)3000000000u) { return false; }
	if((Dt_UINT32_1_0)p_theDestData->systemControl.fodStatus > (Dt_UINT32_1_0)sysFodStatusActive) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleState.sign.current.raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleState.sign.predicted.raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->vehicleState.sign.conditions.trailerRaw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemControl.distIndex > (Dt_UINT16_1_0)7) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemControl.previousSetSpeed.raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemControl.currentSetSpeed.raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemControl.nextSetSpeed.raw > (Dt_UINT16_1_0)256) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->systemControl.previewLimit > (Dt_UINT16_1_0)327) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.gpsInfo.heading > (Dt_UINT16_1_0)36000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.gpsInfo.position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.systemAttributes.countryCode > (Dt_UINT16_1_0)INVALID_UINT8) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.distance > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.speedLimitRing.speedLimit[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.speedLimitRing.speedLimit[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.speedLimitRing.speedLimit[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.speedLimitRing.speedLimit[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.speedLimitRing.speedLimit[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.speedLimitRing.speedLimit[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[6].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[7].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[8].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[9].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[10].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[11].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[12].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[13].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[14].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[15].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[16].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[17].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[18].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[19].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[20].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[21].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[22].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[23].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[24].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[0].angle > (Dt_UINT16_1_0)36000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[1].angle > (Dt_UINT16_1_0)36000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[2].angle > (Dt_UINT16_1_0)36000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[3].angle > (Dt_UINT16_1_0)36000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.branchAngleRing.branchAngle[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[6].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[7].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[8].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[9].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[10].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[11].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[12].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[13].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[14].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[15].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[16].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[17].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[18].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[19].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[20].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[21].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[22].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[23].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[24].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[25].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[26].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[27].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[28].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.slopeRing.slope[29].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[6].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[7].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rampRing.ramp[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rampRing.ramp[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rampRing.ramp[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rampRing.ramp[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rampRing.ramp[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rampRing.ramp[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].position > (Dt_UINT16_1_0)10000) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->dataValidFlag > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.powertrain.gear > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.powertrain.coastingPossible > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.deviation.gearLock > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.heading.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.turnSignal.confident > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.turnSignal.extendHold > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.traffic.present > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.sign.current.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.sign.predicted.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.sign.conditions.fog > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.sign.conditions.wet > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.sign.conditions.trailer > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->vehicleState.accBoost > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.isAutoModeActive > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.dsplLimitEventsActive > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.setDisplayValid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.previewLock > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.stopTakeover > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.overrideReturn > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.unsuccessfulActivation > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->systemControl.showHint > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.lowExecutionTime > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.systemAttributes.speedLimitUnit > (Dt_UINT8_1_0)2) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.systemAttributes.trafficDirection > (Dt_UINT8_1_0)2) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.speedLimitRing.count > (Dt_UINT8_1_0)mapINFOSPEEDLIMITCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[0].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[1].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[2].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[3].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[4].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[5].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[6].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[7].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[8].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[9].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[10].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[11].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[12].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[13].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[14].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[15].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[16].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[17].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[18].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[19].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[20].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[21].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[22].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[23].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.curvature[24].endOfConstantSegmentMissing > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.curvatureRing.count > (Dt_UINT8_1_0)mapINFOCURVATURECOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.branchAngleRing.count > (Dt_UINT8_1_0)mapINFOBRANCHANGLECOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.slopeRing.count > (Dt_UINT8_1_0)mapINFOSLOPECOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[0].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[1].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[2].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[3].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[4].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[5].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[6].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.builtUp[7].builtUp > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.builtUpRing.count > (Dt_UINT8_1_0)mapINFOBUILTUPAREACOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.streetClassRing.count > (Dt_UINT8_1_0)mapINFOSTREETCLASSCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[0].type > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[1].type > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[2].type > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.streetClassRing.streetClass[3].type > (Dt_UINT8_1_0)7) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.count > (Dt_UINT8_1_0)mapINFORAMPCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.ramp[0].type > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.ramp[1].type > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.ramp[2].type > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.ramp[3].type > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.ramp[4].type > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rampRing.ramp[5].type > (Dt_UINT8_1_0)4) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.count > (Dt_UINT8_1_0)mapINFORIGHTOFWAYCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[0].type > (Dt_UINT8_1_0)13) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[1].type > (Dt_UINT8_1_0)13) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[2].type > (Dt_UINT8_1_0)13) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[3].type > (Dt_UINT8_1_0)13) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[4].type > (Dt_UINT8_1_0)13) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.rightOfWayRing.rightOfWayControl[5].type > (Dt_UINT8_1_0)13) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.count > (Dt_UINT8_1_0)mapINFOROUNDABOUTCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[0].roundabout > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[1].roundabout > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[2].roundabout > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[3].roundabout > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[4].roundabout > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.roundaboutRing.roundabout[5].roundabout > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.count > (Dt_UINT8_1_0)mapINFOLANESITUATIONCOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[0].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[1].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[2].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[3].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[4].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[5].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[6].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[7].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[8].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[9].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[10].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[11].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[12].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[13].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[14].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].forwardLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].oppositeLanes > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].turnLanesLeft > (Dt_UINT8_1_0)100) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->mapPath.info.laneSituationRing.laneSituation[15].turnLanesRight > (Dt_UINT8_1_0)100) { return false; }

#endif


	return true;
}
/*lint -restore */

#endif
/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e641	"(Warning -- Converting enum to int)" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that */
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteOutConvert_pemControl(const pemControl_T *p_theSrcData, Dt_RECORD_PemControl *p_theDestData)
{
	uint32_T uiArrIdx;
	/*check the size of the received data*/
	BUILD_BUG_ON((uint32_T)(0 + comCONTROLBUFFERSIZE) > sizeof(p_theDestData->debug_data_buffer));

	p_theDestData->vehicleState_tickCount = p_theSrcData->vehicleState.tickCount;
	p_theDestData->vehicleState_velocity_position = p_theSrcData->vehicleState.velocity.position;
	p_theDestData->vehicleState_velocity_velocity = p_theSrcData->vehicleState.velocity.velocity;
	p_theDestData->vehicleState_velocity_acceleration = p_theSrcData->vehicleState.velocity.acceleration;
	p_theDestData->vehicleState_powertrain_simple = p_theSrcData->vehicleState.powertrain.simple;
	p_theDestData->vehicleState_powertrain_rawSimple = p_theSrcData->vehicleState.powertrain.rawSimple;
	p_theDestData->vehicleState_powertrain_torque = p_theSrcData->vehicleState.powertrain.torque;
	p_theDestData->vehicleState_powertrain_maxAccelerationElectric = p_theSrcData->vehicleState.powertrain.maxAccelerationElectric;
	p_theDestData->vehicleState_powertrain_driveMode = p_theSrcData->vehicleState.powertrain.driveMode;
	p_theDestData->vehicleState_deviation_engaged = p_theSrcData->vehicleState.deviation.engaged;
	p_theDestData->vehicleState_deviation_disengaged = p_theSrcData->vehicleState.deviation.disengaged;
	p_theDestData->vehicleState_deviation_lockAccleration = p_theSrcData->vehicleState.deviation.lockAccleration;
	p_theDestData->vehicleState_heading_heading = p_theSrcData->vehicleState.heading.heading;
	p_theDestData->vehicleState_steering_curvature = p_theSrcData->vehicleState.steering.curvature;
	p_theDestData->vehicleState_steering_predCurvature = p_theSrcData->vehicleState.steering.predCurvature;
	p_theDestData->vehicleState_steering_predDistance = p_theSrcData->vehicleState.steering.predDistance;
	p_theDestData->vehicleState_steering_slowCurvature = p_theSrcData->vehicleState.steering.slowCurvature;
	p_theDestData->vehicleState_curvature_curvature = p_theSrcData->vehicleState.curvature.curvature;
	p_theDestData->vehicleState_curvature_curveRate = p_theSrcData->vehicleState.curvature.curveRate;
	p_theDestData->vehicleState_curvature_horizon = p_theSrcData->vehicleState.curvature.horizon;
	p_theDestData->vehicleState_curvature_confidence = p_theSrcData->vehicleState.curvature.confidence;
	p_theDestData->vehicleState_courage_curvatureFactor = p_theSrcData->vehicleState.courage.curvatureFactor;
	p_theDestData->vehicleState_courage_limitJerkFactor = p_theSrcData->vehicleState.courage.limitJerkFactor;
	p_theDestData->vehicleState_courage_curveJerkFactor = p_theSrcData->vehicleState.courage.curveJerkFactor;
	p_theDestData->vehicleState_courage_maxJerkFactor = p_theSrcData->vehicleState.courage.maxJerkFactor;
	p_theDestData->vehicleState_courage_curtainFactor = p_theSrcData->vehicleState.courage.curtainFactor;
	p_theDestData->vehicleState_turnSignal_turnSignal = p_theSrcData->vehicleState.turnSignal.turnSignal;
	p_theDestData->vehicleState_turnSignal_position = p_theSrcData->vehicleState.turnSignal.position;
	p_theDestData->vehicleState_slope_slope = p_theSrcData->vehicleState.slope.slope;
	p_theDestData->vehicleState_traffic_position = p_theSrcData->vehicleState.traffic.position;
	p_theDestData->vehicleState_traffic_velocity = p_theSrcData->vehicleState.traffic.velocity;
	p_theDestData->vehicleState_traffic_acceleration = p_theSrcData->vehicleState.traffic.acceleration;
	p_theDestData->vehicleState_unfiltered_velocity = p_theSrcData->vehicleState.unfiltered.velocity;
	p_theDestData->vehicleState_unfiltered_displayVelocity = p_theSrcData->vehicleState.unfiltered.displayVelocity;
	p_theDestData->vehicleState_unfiltered_longAcceleration = p_theSrcData->vehicleState.unfiltered.longAcceleration;
	p_theDestData->vehicleState_unfiltered_latAcceleration = p_theSrcData->vehicleState.unfiltered.latAcceleration;
	p_theDestData->vehicleState_unfiltered_accelerator = p_theSrcData->vehicleState.unfiltered.accelerator;
	p_theDestData->vehicleState_sign_current_position = p_theSrcData->vehicleState.sign.current.position;
	p_theDestData->vehicleState_sign_current_velocity = p_theSrcData->vehicleState.sign.current.velocity;
	p_theDestData->vehicleState_sign_predicted_position = p_theSrcData->vehicleState.sign.predicted.position;
	p_theDestData->vehicleState_sign_predicted_velocity = p_theSrcData->vehicleState.sign.predicted.velocity;
	p_theDestData->vehicleState_sign_conditions_trailerLimit = p_theSrcData->vehicleState.sign.conditions.trailerLimit;
	p_theDestData->systemControl_status = p_theSrcData->systemControl.status;
	p_theDestData->systemControl_displayError = p_theSrcData->systemControl.displayError;
	p_theDestData->systemControl_mode = p_theSrcData->systemControl.mode;
	p_theDestData->systemControl_previewPosition = p_theSrcData->systemControl.previewPosition;
	p_theDestData->systemControl_previousSetSpeed_value = p_theSrcData->systemControl.previousSetSpeed.value;
	p_theDestData->systemControl_previousSetSpeed_position = p_theSrcData->systemControl.previousSetSpeed.position;
	p_theDestData->systemControl_currentSetSpeed_value = p_theSrcData->systemControl.currentSetSpeed.value;
	p_theDestData->systemControl_currentSetSpeed_position = p_theSrcData->systemControl.currentSetSpeed.position;
	p_theDestData->systemControl_nextSetSpeed_value = p_theSrcData->systemControl.nextSetSpeed.value;
	p_theDestData->systemControl_nextSetSpeed_position = p_theSrcData->systemControl.nextSetSpeed.position;
	p_theDestData->systemControl_toleranceFactor = p_theSrcData->systemControl.toleranceFactor;
	p_theDestData->systemControl_stopSweepPosition = p_theSrcData->systemControl.stopSweepPosition;
	p_theDestData->systemControl_stopInRange = p_theSrcData->systemControl.stopInRange;
	p_theDestData->mapPath_headingCorrection = p_theSrcData->mapPath.headingCorrection;
	p_theDestData->mapPath_positionZero = p_theSrcData->mapPath.positionZero;
	p_theDestData->mapPath_info_gpsInfo_latitude = p_theSrcData->mapPath.info.gpsInfo.latitude;
	p_theDestData->mapPath_info_gpsInfo_longitude = p_theSrcData->mapPath.info.gpsInfo.longitude;
	p_theDestData->mapPath_info_curvatureRing_curvature_0_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[0].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_1_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[1].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_2_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[2].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_3_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[3].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_4_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[4].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_5_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[5].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_6_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[6].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_7_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[7].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_8_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[8].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_9_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[9].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_10_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[10].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_11_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[11].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_12_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[12].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_13_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[13].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_14_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[14].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_15_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[15].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_16_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[16].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_17_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[17].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_18_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[18].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_19_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[19].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_20_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[20].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_21_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[21].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_22_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[22].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_23_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[23].curvature;
	p_theDestData->mapPath_info_curvatureRing_curvature_24_curvature = p_theSrcData->mapPath.info.curvatureRing.curvature[24].curvature;
	p_theDestData->longTrigger_priorityTick = p_theSrcData->longTrigger.priorityTick;
	p_theDestData->reserved_uint32_00 = p_theSrcData->systemControl.fodStatus;
	p_theDestData->debug_times_start = p_theSrcData->debug.times.start;
	p_theDestData->debug_times_inputCodec = p_theSrcData->debug.times.inputCodec;
	p_theDestData->debug_times_vehicleObserver = p_theSrcData->debug.times.vehicleObserver;
	p_theDestData->debug_times_pathRouter = p_theSrcData->debug.times.pathRouter;
	p_theDestData->debug_times_systemController = p_theSrcData->debug.times.systemController;
	p_theDestData->debug_times_longController = p_theSrcData->debug.times.longController;
	p_theDestData->debug_times_longStabTrigger = p_theSrcData->debug.times.longStabTrigger;
	p_theDestData->debug_times_displayController = p_theSrcData->debug.times.displayController;
	p_theDestData->debug_times_driverObserver = p_theSrcData->debug.times.driverObserver;
	p_theDestData->debug_times_driverPredictor = p_theSrcData->debug.times.driverPredictor;
	p_theDestData->debug_times_outputCodec = p_theSrcData->debug.times.outputCodec;
	p_theDestData->debug_times_end = p_theSrcData->debug.times.end;
	p_theDestData->vehicleState_sign_current_raw = p_theSrcData->vehicleState.sign.current.raw;
	p_theDestData->vehicleState_sign_predicted_raw = p_theSrcData->vehicleState.sign.predicted.raw;
	p_theDestData->vehicleState_sign_conditions_trailerRaw = p_theSrcData->vehicleState.sign.conditions.trailerRaw;
	p_theDestData->vehicleState_vMax_kmh = p_theSrcData->vehicleState.vMax.kmh;
	p_theDestData->vehicleState_vMax_mph = p_theSrcData->vehicleState.vMax.mph;
	p_theDestData->systemControl_errorTicks = p_theSrcData->systemControl.errorTicks;
	p_theDestData->systemControl_distIndex = p_theSrcData->systemControl.distIndex;
	p_theDestData->systemControl_previousSetSpeed_raw = p_theSrcData->systemControl.previousSetSpeed.raw;
	p_theDestData->systemControl_currentSetSpeed_raw = p_theSrcData->systemControl.currentSetSpeed.raw;
	p_theDestData->systemControl_nextSetSpeed_raw = p_theSrcData->systemControl.nextSetSpeed.raw;
	p_theDestData->systemControl_previewLimit = p_theSrcData->systemControl.previewLimit;
	p_theDestData->mapPath_info_gpsInfo_heading = p_theSrcData->mapPath.info.gpsInfo.heading;
	p_theDestData->mapPath_info_gpsInfo_altitude = p_theSrcData->mapPath.info.gpsInfo.altitude;
	p_theDestData->mapPath_info_gpsInfo_position = p_theSrcData->mapPath.info.gpsInfo.position;
	p_theDestData->mapPath_info_systemAttributes_countryCode = p_theSrcData->mapPath.info.systemAttributes.countryCode;
	p_theDestData->mapPath_info_distance = p_theSrcData->mapPath.info.distance;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_0_position = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[0].position;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_1_position = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[1].position;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_2_position = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[2].position;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_3_position = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[3].position;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_4_position = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[4].position;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_5_position = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[5].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_0_position = p_theSrcData->mapPath.info.curvatureRing.curvature[0].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_1_position = p_theSrcData->mapPath.info.curvatureRing.curvature[1].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_2_position = p_theSrcData->mapPath.info.curvatureRing.curvature[2].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_3_position = p_theSrcData->mapPath.info.curvatureRing.curvature[3].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_4_position = p_theSrcData->mapPath.info.curvatureRing.curvature[4].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_5_position = p_theSrcData->mapPath.info.curvatureRing.curvature[5].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_6_position = p_theSrcData->mapPath.info.curvatureRing.curvature[6].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_7_position = p_theSrcData->mapPath.info.curvatureRing.curvature[7].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_8_position = p_theSrcData->mapPath.info.curvatureRing.curvature[8].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_9_position = p_theSrcData->mapPath.info.curvatureRing.curvature[9].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_10_position = p_theSrcData->mapPath.info.curvatureRing.curvature[10].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_11_position = p_theSrcData->mapPath.info.curvatureRing.curvature[11].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_12_position = p_theSrcData->mapPath.info.curvatureRing.curvature[12].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_13_position = p_theSrcData->mapPath.info.curvatureRing.curvature[13].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_14_position = p_theSrcData->mapPath.info.curvatureRing.curvature[14].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_15_position = p_theSrcData->mapPath.info.curvatureRing.curvature[15].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_16_position = p_theSrcData->mapPath.info.curvatureRing.curvature[16].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_17_position = p_theSrcData->mapPath.info.curvatureRing.curvature[17].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_18_position = p_theSrcData->mapPath.info.curvatureRing.curvature[18].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_19_position = p_theSrcData->mapPath.info.curvatureRing.curvature[19].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_20_position = p_theSrcData->mapPath.info.curvatureRing.curvature[20].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_21_position = p_theSrcData->mapPath.info.curvatureRing.curvature[21].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_22_position = p_theSrcData->mapPath.info.curvatureRing.curvature[22].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_23_position = p_theSrcData->mapPath.info.curvatureRing.curvature[23].position;
	p_theDestData->mapPath_info_curvatureRing_curvature_24_position = p_theSrcData->mapPath.info.curvatureRing.curvature[24].position;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_0_angle = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[0].angle;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_0_position = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[0].position;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_1_angle = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[1].angle;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_1_position = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[1].position;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_2_angle = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[2].angle;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_2_position = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[2].position;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_3_angle = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[3].angle;
	p_theDestData->mapPath_info_branchAngleRing_branchAngle_3_position = p_theSrcData->mapPath.info.branchAngleRing.branchAngle[3].position;
	p_theDestData->mapPath_info_slopeRing_slope_0_slope = p_theSrcData->mapPath.info.slopeRing.slope[0].slope;
	p_theDestData->mapPath_info_slopeRing_slope_0_position = p_theSrcData->mapPath.info.slopeRing.slope[0].position;
	p_theDestData->mapPath_info_slopeRing_slope_1_slope = p_theSrcData->mapPath.info.slopeRing.slope[1].slope;
	p_theDestData->mapPath_info_slopeRing_slope_1_position = p_theSrcData->mapPath.info.slopeRing.slope[1].position;
	p_theDestData->mapPath_info_slopeRing_slope_2_slope = p_theSrcData->mapPath.info.slopeRing.slope[2].slope;
	p_theDestData->mapPath_info_slopeRing_slope_2_position = p_theSrcData->mapPath.info.slopeRing.slope[2].position;
	p_theDestData->mapPath_info_slopeRing_slope_3_slope = p_theSrcData->mapPath.info.slopeRing.slope[3].slope;
	p_theDestData->mapPath_info_slopeRing_slope_3_position = p_theSrcData->mapPath.info.slopeRing.slope[3].position;
	p_theDestData->mapPath_info_slopeRing_slope_4_slope = p_theSrcData->mapPath.info.slopeRing.slope[4].slope;
	p_theDestData->mapPath_info_slopeRing_slope_4_position = p_theSrcData->mapPath.info.slopeRing.slope[4].position;
	p_theDestData->mapPath_info_slopeRing_slope_5_slope = p_theSrcData->mapPath.info.slopeRing.slope[5].slope;
	p_theDestData->mapPath_info_slopeRing_slope_5_position = p_theSrcData->mapPath.info.slopeRing.slope[5].position;
	p_theDestData->mapPath_info_slopeRing_slope_6_slope = p_theSrcData->mapPath.info.slopeRing.slope[6].slope;
	p_theDestData->mapPath_info_slopeRing_slope_6_position = p_theSrcData->mapPath.info.slopeRing.slope[6].position;
	p_theDestData->mapPath_info_slopeRing_slope_7_slope = p_theSrcData->mapPath.info.slopeRing.slope[7].slope;
	p_theDestData->mapPath_info_slopeRing_slope_7_position = p_theSrcData->mapPath.info.slopeRing.slope[7].position;
	p_theDestData->mapPath_info_slopeRing_slope_8_slope = p_theSrcData->mapPath.info.slopeRing.slope[8].slope;
	p_theDestData->mapPath_info_slopeRing_slope_8_position = p_theSrcData->mapPath.info.slopeRing.slope[8].position;
	p_theDestData->mapPath_info_slopeRing_slope_9_slope = p_theSrcData->mapPath.info.slopeRing.slope[9].slope;
	p_theDestData->mapPath_info_slopeRing_slope_9_position = p_theSrcData->mapPath.info.slopeRing.slope[9].position;
	p_theDestData->mapPath_info_slopeRing_slope_10_slope = p_theSrcData->mapPath.info.slopeRing.slope[10].slope;
	p_theDestData->mapPath_info_slopeRing_slope_10_position = p_theSrcData->mapPath.info.slopeRing.slope[10].position;
	p_theDestData->mapPath_info_slopeRing_slope_11_slope = p_theSrcData->mapPath.info.slopeRing.slope[11].slope;
	p_theDestData->mapPath_info_slopeRing_slope_11_position = p_theSrcData->mapPath.info.slopeRing.slope[11].position;
	p_theDestData->mapPath_info_slopeRing_slope_12_slope = p_theSrcData->mapPath.info.slopeRing.slope[12].slope;
	p_theDestData->mapPath_info_slopeRing_slope_12_position = p_theSrcData->mapPath.info.slopeRing.slope[12].position;
	p_theDestData->mapPath_info_slopeRing_slope_13_slope = p_theSrcData->mapPath.info.slopeRing.slope[13].slope;
	p_theDestData->mapPath_info_slopeRing_slope_13_position = p_theSrcData->mapPath.info.slopeRing.slope[13].position;
	p_theDestData->mapPath_info_slopeRing_slope_14_slope = p_theSrcData->mapPath.info.slopeRing.slope[14].slope;
	p_theDestData->mapPath_info_slopeRing_slope_14_position = p_theSrcData->mapPath.info.slopeRing.slope[14].position;
	p_theDestData->mapPath_info_slopeRing_slope_15_slope = p_theSrcData->mapPath.info.slopeRing.slope[15].slope;
	p_theDestData->mapPath_info_slopeRing_slope_15_position = p_theSrcData->mapPath.info.slopeRing.slope[15].position;
	p_theDestData->mapPath_info_slopeRing_slope_16_slope = p_theSrcData->mapPath.info.slopeRing.slope[16].slope;
	p_theDestData->mapPath_info_slopeRing_slope_16_position = p_theSrcData->mapPath.info.slopeRing.slope[16].position;
	p_theDestData->mapPath_info_slopeRing_slope_17_slope = p_theSrcData->mapPath.info.slopeRing.slope[17].slope;
	p_theDestData->mapPath_info_slopeRing_slope_17_position = p_theSrcData->mapPath.info.slopeRing.slope[17].position;
	p_theDestData->mapPath_info_slopeRing_slope_18_slope = p_theSrcData->mapPath.info.slopeRing.slope[18].slope;
	p_theDestData->mapPath_info_slopeRing_slope_18_position = p_theSrcData->mapPath.info.slopeRing.slope[18].position;
	p_theDestData->mapPath_info_slopeRing_slope_19_slope = p_theSrcData->mapPath.info.slopeRing.slope[19].slope;
	p_theDestData->mapPath_info_slopeRing_slope_19_position = p_theSrcData->mapPath.info.slopeRing.slope[19].position;
	p_theDestData->mapPath_info_slopeRing_slope_20_slope = p_theSrcData->mapPath.info.slopeRing.slope[20].slope;
	p_theDestData->mapPath_info_slopeRing_slope_20_position = p_theSrcData->mapPath.info.slopeRing.slope[20].position;
	p_theDestData->mapPath_info_slopeRing_slope_21_slope = p_theSrcData->mapPath.info.slopeRing.slope[21].slope;
	p_theDestData->mapPath_info_slopeRing_slope_21_position = p_theSrcData->mapPath.info.slopeRing.slope[21].position;
	p_theDestData->mapPath_info_slopeRing_slope_22_slope = p_theSrcData->mapPath.info.slopeRing.slope[22].slope;
	p_theDestData->mapPath_info_slopeRing_slope_22_position = p_theSrcData->mapPath.info.slopeRing.slope[22].position;
	p_theDestData->mapPath_info_slopeRing_slope_23_slope = p_theSrcData->mapPath.info.slopeRing.slope[23].slope;
	p_theDestData->mapPath_info_slopeRing_slope_23_position = p_theSrcData->mapPath.info.slopeRing.slope[23].position;
	p_theDestData->mapPath_info_slopeRing_slope_24_slope = p_theSrcData->mapPath.info.slopeRing.slope[24].slope;
	p_theDestData->mapPath_info_slopeRing_slope_24_position = p_theSrcData->mapPath.info.slopeRing.slope[24].position;
	p_theDestData->mapPath_info_slopeRing_slope_25_slope = p_theSrcData->mapPath.info.slopeRing.slope[25].slope;
	p_theDestData->mapPath_info_slopeRing_slope_25_position = p_theSrcData->mapPath.info.slopeRing.slope[25].position;
	p_theDestData->mapPath_info_slopeRing_slope_26_slope = p_theSrcData->mapPath.info.slopeRing.slope[26].slope;
	p_theDestData->mapPath_info_slopeRing_slope_26_position = p_theSrcData->mapPath.info.slopeRing.slope[26].position;
	p_theDestData->mapPath_info_slopeRing_slope_27_slope = p_theSrcData->mapPath.info.slopeRing.slope[27].slope;
	p_theDestData->mapPath_info_slopeRing_slope_27_position = p_theSrcData->mapPath.info.slopeRing.slope[27].position;
	p_theDestData->mapPath_info_slopeRing_slope_28_slope = p_theSrcData->mapPath.info.slopeRing.slope[28].slope;
	p_theDestData->mapPath_info_slopeRing_slope_28_position = p_theSrcData->mapPath.info.slopeRing.slope[28].position;
	p_theDestData->mapPath_info_slopeRing_slope_29_slope = p_theSrcData->mapPath.info.slopeRing.slope[29].slope;
	p_theDestData->mapPath_info_slopeRing_slope_29_position = p_theSrcData->mapPath.info.slopeRing.slope[29].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_0_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[0].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_1_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[1].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_2_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[2].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_3_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[3].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_4_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[4].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_5_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[5].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_6_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[6].position;
	p_theDestData->mapPath_info_builtUpRing_builtUp_7_position = p_theSrcData->mapPath.info.builtUpRing.builtUp[7].position;
	p_theDestData->mapPath_info_streetClassRing_streetClass_0_position = p_theSrcData->mapPath.info.streetClassRing.streetClass[0].position;
	p_theDestData->mapPath_info_streetClassRing_streetClass_1_position = p_theSrcData->mapPath.info.streetClassRing.streetClass[1].position;
	p_theDestData->mapPath_info_streetClassRing_streetClass_2_position = p_theSrcData->mapPath.info.streetClassRing.streetClass[2].position;
	p_theDestData->mapPath_info_streetClassRing_streetClass_3_position = p_theSrcData->mapPath.info.streetClassRing.streetClass[3].position;
	p_theDestData->mapPath_info_rampRing_ramp_0_position = p_theSrcData->mapPath.info.rampRing.ramp[0].position;
	p_theDestData->mapPath_info_rampRing_ramp_1_position = p_theSrcData->mapPath.info.rampRing.ramp[1].position;
	p_theDestData->mapPath_info_rampRing_ramp_2_position = p_theSrcData->mapPath.info.rampRing.ramp[2].position;
	p_theDestData->mapPath_info_rampRing_ramp_3_position = p_theSrcData->mapPath.info.rampRing.ramp[3].position;
	p_theDestData->mapPath_info_rampRing_ramp_4_position = p_theSrcData->mapPath.info.rampRing.ramp[4].position;
	p_theDestData->mapPath_info_rampRing_ramp_5_position = p_theSrcData->mapPath.info.rampRing.ramp[5].position;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_0_position = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[0].position;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_1_position = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[1].position;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_2_position = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[2].position;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_3_position = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[3].position;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_4_position = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[4].position;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_5_position = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[5].position;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_0_position = p_theSrcData->mapPath.info.roundaboutRing.roundabout[0].position;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_1_position = p_theSrcData->mapPath.info.roundaboutRing.roundabout[1].position;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_2_position = p_theSrcData->mapPath.info.roundaboutRing.roundabout[2].position;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_3_position = p_theSrcData->mapPath.info.roundaboutRing.roundabout[3].position;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_4_position = p_theSrcData->mapPath.info.roundaboutRing.roundabout[4].position;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_5_position = p_theSrcData->mapPath.info.roundaboutRing.roundabout[5].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_0_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[0].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_1_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[1].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_2_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[2].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_3_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[3].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_4_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[4].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_5_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[5].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_6_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[6].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_7_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[7].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_8_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[8].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_9_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[9].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_10_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[10].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_11_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[11].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_12_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[12].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_13_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[13].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_14_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[14].position;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_15_position = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[15].position;
	p_theDestData->debug_data_index = p_theSrcData->debug.data.index;
	p_theDestData->debug_data_count = p_theSrcData->debug.data.count;
	p_theDestData->debug_data_size = p_theSrcData->debug.data.size;
	p_theDestData->dataValidFlag = p_theSrcData->dataValidFlag;
	p_theDestData->vehicleState_valid = p_theSrcData->vehicleState.valid;
	p_theDestData->vehicleState_powertrain_gear = p_theSrcData->vehicleState.powertrain.gear;
	p_theDestData->vehicleState_powertrain_coastingPossible = p_theSrcData->vehicleState.powertrain.coastingPossible;
	p_theDestData->vehicleState_deviation_gearLock = p_theSrcData->vehicleState.deviation.gearLock;
	p_theDestData->vehicleState_heading_valid = p_theSrcData->vehicleState.heading.valid;
	p_theDestData->vehicleState_turnSignal_confident = p_theSrcData->vehicleState.turnSignal.confident;
	p_theDestData->vehicleState_turnSignal_extendHold = p_theSrcData->vehicleState.turnSignal.extendHold;
	p_theDestData->vehicleState_traffic_present = p_theSrcData->vehicleState.traffic.present;
	p_theDestData->vehicleState_sign_current_valid = p_theSrcData->vehicleState.sign.current.valid;
	p_theDestData->vehicleState_sign_predicted_valid = p_theSrcData->vehicleState.sign.predicted.valid;
	p_theDestData->vehicleState_sign_conditions_fog = p_theSrcData->vehicleState.sign.conditions.fog;
	p_theDestData->vehicleState_sign_conditions_wet = p_theSrcData->vehicleState.sign.conditions.wet;
	p_theDestData->vehicleState_sign_conditions_trailer = p_theSrcData->vehicleState.sign.conditions.trailer;
	p_theDestData->vehicleState_accBoost = p_theSrcData->vehicleState.accBoost;
	p_theDestData->systemControl_isAutoModeActive = p_theSrcData->systemControl.isAutoModeActive;
	p_theDestData->systemControl_dsplLimitEventsActive = p_theSrcData->systemControl.dsplLimitEventsActive;
	p_theDestData->systemControl_setDisplayValid = p_theSrcData->systemControl.setDisplayValid;
	p_theDestData->systemControl_previewLock = p_theSrcData->systemControl.previewLock;
	p_theDestData->systemControl_stopTakeover = p_theSrcData->systemControl.stopTakeover;
	p_theDestData->systemControl_overrideReturn = p_theSrcData->systemControl.overrideReturn;
	p_theDestData->systemControl_unsuccessfulActivation = p_theSrcData->systemControl.unsuccessfulActivation;
	p_theDestData->systemControl_showHint = p_theSrcData->systemControl.showHint;
	p_theDestData->mapPath_valid = p_theSrcData->mapPath.valid;
	p_theDestData->mapPath_lowExecutionTime = p_theSrcData->mapPath.lowExecutionTime;
	p_theDestData->mapPath_positionResetCount = p_theSrcData->mapPath.positionResetCount;
	p_theDestData->mapPath_rerouteCount = p_theSrcData->mapPath.rerouteCount;
	p_theDestData->mapPath_info_systemAttributes_qualityGeometry = p_theSrcData->mapPath.info.systemAttributes.qualityGeometry;
	p_theDestData->mapPath_info_systemAttributes_speedLimitUnit = p_theSrcData->mapPath.info.systemAttributes.speedLimitUnit;
	p_theDestData->mapPath_info_systemAttributes_trafficDirection = p_theSrcData->mapPath.info.systemAttributes.trafficDirection;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_0_value = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[0].value;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_0_codedInfo = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[0].codedInfo;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_1_value = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[1].value;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_1_codedInfo = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[1].codedInfo;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_2_value = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[2].value;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_2_codedInfo = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[2].codedInfo;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_3_value = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[3].value;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_3_codedInfo = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[3].codedInfo;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_4_value = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[4].value;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_4_codedInfo = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[4].codedInfo;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_5_value = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[5].value;
	p_theDestData->mapPath_info_speedLimitRing_speedLimit_5_codedInfo = p_theSrcData->mapPath.info.speedLimitRing.speedLimit[5].codedInfo;
	p_theDestData->mapPath_info_speedLimitRing_count = p_theSrcData->mapPath.info.speedLimitRing.count;
	p_theDestData->mapPath_info_curvatureRing_curvature_0_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[0].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_0_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[0].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_1_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[1].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_1_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[1].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_2_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[2].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_2_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[2].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_3_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[3].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_3_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[3].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_4_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[4].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_4_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[4].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_5_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[5].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_5_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[5].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_6_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[6].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_6_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[6].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_7_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[7].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_7_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[7].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_8_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[8].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_8_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[8].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_9_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[9].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_9_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[9].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_10_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[10].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_10_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[10].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_11_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[11].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_11_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[11].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_12_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[12].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_12_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[12].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_13_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[13].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_13_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[13].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_14_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[14].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_14_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[14].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_15_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[15].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_15_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[15].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_16_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[16].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_16_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[16].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_17_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[17].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_17_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[17].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_18_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[18].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_18_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[18].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_19_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[19].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_19_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[19].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_20_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[20].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_20_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[20].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_21_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[21].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_21_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[21].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_22_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[22].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_22_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[22].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_23_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[23].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_23_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[23].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_curvature_24_segmentId = p_theSrcData->mapPath.info.curvatureRing.curvature[24].segmentId;
	p_theDestData->mapPath_info_curvatureRing_curvature_24_endOfConstantSegmentMissing = p_theSrcData->mapPath.info.curvatureRing.curvature[24].endOfConstantSegmentMissing;
	p_theDestData->mapPath_info_curvatureRing_count = p_theSrcData->mapPath.info.curvatureRing.count;
	p_theDestData->mapPath_info_branchAngleRing_count = p_theSrcData->mapPath.info.branchAngleRing.count;
	p_theDestData->mapPath_info_slopeRing_count = p_theSrcData->mapPath.info.slopeRing.count;
	p_theDestData->mapPath_info_builtUpRing_builtUp_0_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[0].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_1_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[1].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_2_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[2].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_3_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[3].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_4_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[4].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_5_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[5].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_6_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[6].builtUp;
	p_theDestData->mapPath_info_builtUpRing_builtUp_7_builtUp = p_theSrcData->mapPath.info.builtUpRing.builtUp[7].builtUp;
	p_theDestData->mapPath_info_builtUpRing_count = p_theSrcData->mapPath.info.builtUpRing.count;
	p_theDestData->mapPath_info_streetClassRing_count = p_theSrcData->mapPath.info.streetClassRing.count;
	p_theDestData->mapPath_info_streetClassRing_streetClass_0_type = p_theSrcData->mapPath.info.streetClassRing.streetClass[0].type;
	p_theDestData->mapPath_info_streetClassRing_streetClass_1_type = p_theSrcData->mapPath.info.streetClassRing.streetClass[1].type;
	p_theDestData->mapPath_info_streetClassRing_streetClass_2_type = p_theSrcData->mapPath.info.streetClassRing.streetClass[2].type;
	p_theDestData->mapPath_info_streetClassRing_streetClass_3_type = p_theSrcData->mapPath.info.streetClassRing.streetClass[3].type;
	p_theDestData->mapPath_info_rampRing_count = p_theSrcData->mapPath.info.rampRing.count;
	p_theDestData->mapPath_info_rampRing_ramp_0_type = p_theSrcData->mapPath.info.rampRing.ramp[0].type;
	p_theDestData->mapPath_info_rampRing_ramp_1_type = p_theSrcData->mapPath.info.rampRing.ramp[1].type;
	p_theDestData->mapPath_info_rampRing_ramp_2_type = p_theSrcData->mapPath.info.rampRing.ramp[2].type;
	p_theDestData->mapPath_info_rampRing_ramp_3_type = p_theSrcData->mapPath.info.rampRing.ramp[3].type;
	p_theDestData->mapPath_info_rampRing_ramp_4_type = p_theSrcData->mapPath.info.rampRing.ramp[4].type;
	p_theDestData->mapPath_info_rampRing_ramp_5_type = p_theSrcData->mapPath.info.rampRing.ramp[5].type;
	p_theDestData->mapPath_info_rightOfWayRing_count = p_theSrcData->mapPath.info.rightOfWayRing.count;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_0_type = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[0].type;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_1_type = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[1].type;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_2_type = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[2].type;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_3_type = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[3].type;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_4_type = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[4].type;
	p_theDestData->mapPath_info_rightOfWayRing_rightOfWayControl_5_type = p_theSrcData->mapPath.info.rightOfWayRing.rightOfWayControl[5].type;
	p_theDestData->mapPath_info_roundaboutRing_count = p_theSrcData->mapPath.info.roundaboutRing.count;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_0_roundabout = p_theSrcData->mapPath.info.roundaboutRing.roundabout[0].roundabout;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_1_roundabout = p_theSrcData->mapPath.info.roundaboutRing.roundabout[1].roundabout;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_2_roundabout = p_theSrcData->mapPath.info.roundaboutRing.roundabout[2].roundabout;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_3_roundabout = p_theSrcData->mapPath.info.roundaboutRing.roundabout[3].roundabout;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_4_roundabout = p_theSrcData->mapPath.info.roundaboutRing.roundabout[4].roundabout;
	p_theDestData->mapPath_info_roundaboutRing_roundabout_5_roundabout = p_theSrcData->mapPath.info.roundaboutRing.roundabout[5].roundabout;
	p_theDestData->mapPath_info_laneSituationRing_count = p_theSrcData->mapPath.info.laneSituationRing.count;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_0_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[0].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_0_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[0].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_0_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[0].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_0_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[0].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_1_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[1].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_1_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[1].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_1_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[1].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_1_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[1].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_2_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[2].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_2_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[2].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_2_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[2].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_2_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[2].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_3_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[3].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_3_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[3].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_3_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[3].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_3_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[3].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_4_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[4].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_4_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[4].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_4_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[4].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_4_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[4].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_5_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[5].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_5_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[5].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_5_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[5].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_5_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[5].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_6_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[6].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_6_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[6].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_6_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[6].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_6_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[6].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_7_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[7].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_7_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[7].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_7_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[7].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_7_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[7].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_8_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[8].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_8_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[8].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_8_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[8].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_8_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[8].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_9_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[9].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_9_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[9].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_9_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[9].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_9_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[9].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_10_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[10].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_10_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[10].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_10_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[10].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_10_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[10].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_11_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[11].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_11_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[11].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_11_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[11].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_11_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[11].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_12_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[12].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_12_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[12].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_12_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[12].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_12_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[12].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_13_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[13].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_13_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[13].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_13_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[13].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_13_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[13].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_14_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[14].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_14_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[14].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_14_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[14].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_14_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[14].turnLanesRight;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_15_forwardLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[15].forwardLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_15_oppositeLanes = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[15].oppositeLanes;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_15_turnLanesLeft = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[15].turnLanesLeft;
	p_theDestData->mapPath_info_laneSituationRing_laneSituation_15_turnLanesRight = p_theSrcData->mapPath.info.laneSituationRing.laneSituation[15].turnLanesRight;

	for(uiArrIdx = 0; uiArrIdx < (uint32_T)comCONTROLBUFFERSIZE; uiArrIdx++)
	{
		p_theDestData->debug_data_buffer[uiArrIdx] = p_theSrcData->debug.data.buffer[uiArrIdx]; 
	}

	/* The complete structure length is: 1211 Bytes.*/

	return true;
}
/*lint -restore */

