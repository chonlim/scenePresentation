#ifndef guard_PpDspemControl_h
#define guard_PpDspemControl_h

#include "base.h"
#include "common/swcCommunication/swcComm_interface.h"


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"

#else
#include "Rte_Type.h"
#endif


/*lint -save */
/*lint -e18	 "Error -- Symbol 'ccc' redeclared(origin, strong) conflicts with line aa, file xxx, module yyy[MISRA 2012 Rule 8.2, required])" */
#ifdef __cplusplus
extern "C" {
#endif

	bool_T rteOutConvert_pemControl(const pemControl_T *p_theSrcData, Dt_RECORD_PemControl *p_theDestData);
#if !defined INNODRIVE_ZFAS_SWC_BUILD
	bool_T rteCheckBounds_pemControl(const pemControl_T *p_theDestData);
#endif
	bool_T rteInConvert_pemControl(const Dt_RECORD_PemControl *p_theSrcData, pemControl_T *p_theDestData);

#ifdef __cplusplus
}
#endif
/*lint -restore */

#endif
