#ifndef guard_PpDspemPlanning_h
#define guard_PpDspemPlanning_h

#include "base.h"
#include "common/swcCommunication/swcComm_interface.h"


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"

#else
#include "Rte_Type.h"
#endif


/*lint -save */
/*lint -e18	 "Error -- Symbol 'ccc' redeclared(origin, strong) conflicts with line aa, file xxx, module yyy[MISRA 2012 Rule 8.2, required])" */
#ifdef __cplusplus
extern "C" {
#endif

	bool_T rteOutConvert_pemPlanning(const pemPlanning_T *p_theSrcData, Dt_RECORD_PemPlanning *p_theDestData);
#if !defined INNODRIVE_ZFAS_SWC_BUILD
	bool_T rteCheckBounds_pemPlanning(const pemPlanning_T *p_theDestData);
#endif
	bool_T rteInConvert_pemPlanning(const Dt_RECORD_PemPlanning *p_theSrcData, pemPlanning_T *p_theDestData);

#ifdef __cplusplus
}
#endif
/*lint -restore */

#endif
