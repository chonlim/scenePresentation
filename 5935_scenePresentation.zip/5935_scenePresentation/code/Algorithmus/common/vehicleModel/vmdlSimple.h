#ifndef guard_vmdlSimple_h
#define guard_vmdlSimple_h

#include "vmdlResistance.h"
#include "vmdlSimpleTypes.h"


bool_T				   vmdlSmpGetLimits(IN	const	simpleModel_T			*simpleModel,
										IN	const	resistanceModel_T		*resistanceModel,
										IN	const	singleTrackModel_T		*singleTrackModel,
										IN	const	gearBoxModel_T			*gearBoxModel,
										IN	const	resistanceFactors_T		*resFactors,
										IN	const	deviationState_T		*deviationState,
										OUT			real32_T				*maxAcceleration,
										OUT			real32_T				*minAcceleration,
										OUT			real32_T				*coastMaxAcceleration,
										OUT			real32_T				*coastMinAcceleration,
										OUT			simpleOffset_T			*simpleOffset
										);


bool_T				   vmdlSmpPreSelect(IN	const	simpleModel_T			*simpleModel,
										IN	const	real32_T				 velocity,
										IN	const	simpleOffset_T			*offset,
										OUT			simplePowerPreSel_T		*preSel
										);


bool_T					vmdlSmpGetPower(IN	const	resistanceModel_T		*resistanceModel,
										IN	const	simpleModel_T			*simpleModel,
										IN	const	simplePowerPreSel_T		*preSel,
										IN	const	simpleState_T			 simpleState,
										IN	const	real32_T				 acceleration,
										OUT			real32_T				*simplePower
										);

#endif
