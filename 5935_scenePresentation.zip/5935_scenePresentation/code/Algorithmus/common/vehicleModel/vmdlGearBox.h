#ifndef guard_vmdlGearBox_h
#define guard_vmdlGearBox_h


/** \brief	Berechnet die Fahrzeugbeschleunigung, die sich aus einem Antriebsmoment ergibt */
bool_T		 vmdlGBTorqueToAcceleration(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	real32_T			 torque,			/**< Antriebsmoment [Nm] */
										IN	const	real32_T			 resistance,		/**< Fahrwiderstandskraft [N] */
										IN	const	real32_T			 velocity,			/**< Fahrzeuggeschwindigkeit [m/s] */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*acceleration		/**< Fahrzeugbeschleunigung */
										);


/** \brief	Berechnet das f�r eine Fahrzeugbeschleunigung notwendige Antriebsmoment */
bool_T		 vmdlGBAccelerationToTorque(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	real32_T			 acceleration,		/**< Fahrzeugbeschleunigung */
										IN	const	real32_T			 resistance,		/**< Fahrwiderstandskraft [N] */
										IN	const	real32_T			 velocity,			/**< Fahrzeuggeschwindigkeit [m/s] */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*torque,			/**< Antriebsmoment [Nm] */
										OUT			real32_T			*omega				/**< Drehzahl, die sich aus Gang und Geschwindigkeit ergibt [rad/s] */
										);


/** \brief	Ruft die Getriebe�bersetzung in einem gegebenen Gang ab */
bool_T		 vmdlGBGetTransmissionRatio(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*transRatio			/**< Getriebe�bersetzung [1/1] */
										);


/** \brief	Berechnet die Drehzahl, die sich aus Geschwindigkeit und eingelegtem Gang ergibt */
bool_T					 vmdlGBGetOmega(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	real32_T			 velocity,			/**< Fahrzeuggeschwindigkeit [m/s] */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*omega				/**< Drehzahl, die sich aus Gang und Geschwindigkeit ergibt [rad/s] */
										);


/** \brief	Berechnet, welche G�nge bei der gegeben Geschwindigkeit den Drehzahlgrenzen gen�gen */
bool_T				vmdlGBGetMinMaxGear(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	real32_T			 velocity,			/**< Fahrzeuggeschwindigkeit [m/s] */
										OUT			gear_T				*minGear,			/**< minimal m�glicher Gang */
										OUT			gear_T				*maxGear			/**< maximal m�glicher Gang */
										);


/** \brief	Gibt die im Getriebemodell hinterlegte Anzahl der G�nge zur�ck */
bool_T				  vmdlGBGetNumGears(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										OUT			uint8_T				*numGears			/**< Anzahl der G�nge */
										);


/** \brief	Gibt an, ob Segen bei einer gegebenen Geschwindigkeit m�glich ist */
void		   vmdlGBIsCoastingPossible(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	real32_T			 velocity,			/**< Fahrzeuggeschwindigkeit [m/s] */
										OUT			bool_T				*possible			/**< Ist Segeln m�glich? */
										);


/* \brief	Gibt den Offset zur�ck, mit dem eine �bersetzungsanforderung ans Getriebebelegt werden soll */
void			 vmdlGBGetRequestOffset(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										OUT			real32_T			*requestOffset		/**< Offset f�r die Wunsch�bersetzung */
										);


/** \brief	Gibt zur�ck, ob das Ausgeben eine g�ltigen Wunsch�bersetzung lt. Fahrzeugmodell zul�ssig ist */
void		 vmdlGBIsGearRequestAllowed(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										OUT			bool_T				*requestAllowed		/**< Gibt an, ob eine Ganganforderung zul�ssig ist */
										);


/** \brief	Berechnet aus dem Moment von VKM, prim�rer und sekund�rer E-Maschine ein virtuelles Gesamtantriebsmoment */
bool_T			   vmdlGBGetTotalTorque(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	real32_T			 sumTorque,			/**< Vom Motor gemeldetes Summenmoment aus VKM und EM1 [Nm] */
										IN	const	real32_T			 eTorquePrimary,	/**< Antriebsmoment der E-Maschine 1 [Nm] */
										IN	const	real32_T			 eTorqueSecondary,	/**< Antriebsmoment der E-Maschine 2 [Nm] */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*torque				/**< �quivalentes Gesamtantriebsmoment [Nm] */
										);


#endif
