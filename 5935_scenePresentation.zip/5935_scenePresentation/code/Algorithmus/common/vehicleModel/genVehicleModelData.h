#ifndef guardVehicleModelData
#define guardVehicleModelData

#include "Strsafe.h"
#include <algorithm>
#include <sstream>
#include <string>

#include "base.h"
#include "control/controlTask/iccExports.h"
#include "common/vehicleModel/vehicleModel_private.h"
class genVmdlData
{
public:

	bool_T getVehicleModelData(const vehicleModel_T *p_theSrcData, std::string strElementName, std::string *strInit)
	{
		uint32_T uiIdx = 0;
		char cArguments[MAX_PATH];
		if ("resistance_mass" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->resistance.mass); *strInit = cArguments;  return true; }
		if ("resistance_coastingCoefficients_a" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->resistance.coastingCoefficients.a); *strInit = cArguments;  return true; }
		if ("resistance_coastingCoefficients_b" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->resistance.coastingCoefficients.b); *strInit = cArguments;  return true; }
		if ("resistance_coastingCoefficients_c" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->resistance.coastingCoefficients.c); *strInit = cArguments;  return true; }
		if ("singleTrack_mass" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.mass); *strInit = cArguments;  return true; }
		if ("singleTrack_length" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.length); *strInit = cArguments;  return true; }
		if ("singleTrack_steeringRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.steeringRatio); *strInit = cArguments;  return true; }
		if ("singleTrack_steeringRatioRAS" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.steeringRatioRAS); *strInit = cArguments;  return true; }
		if ("singleTrack_eg" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.eg); *strInit = cArguments;  return true; }
		if ("singleTrack_egRAS" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.egRAS); *strInit = cArguments;  return true; }
		if ("singleTrack_lengthFront" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.lengthFront); *strInit = cArguments;  return true; }
		if ("singleTrack_lengthRear" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.lengthRear); *strInit = cArguments;  return true; }
		if ("singleTrack_cR" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.cR); *strInit = cArguments;  return true; }
		if ("singleTrack_cF" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->singleTrack.cF); *strInit = cArguments;  return true; }
		if ("gearBox_requestOffset" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.requestOffset); *strInit = cArguments;  return true; }
		if ("gearBox_iDiff" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.iDiff); *strInit = cArguments;  return true; }
		if ("gearBox_wheelRadius" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.wheelRadius); *strInit = cArguments;  return true; }
		if ("gearBox_auxDiff" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.auxDiff); *strInit = cArguments;  return true; }
		if ("gearBox_auxRadius" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.auxRadius); *strInit = cArguments;  return true; }
		if ("gearBox_minOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.minOmega); *strInit = cArguments;  return true; }
		if ("gearBox_maxOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.maxOmega); *strInit = cArguments;  return true; }
		if ("gearBox_coasting_minVelocity" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.coasting.minVelocity); *strInit = cArguments;  return true; }
		if ("gearBox_coasting_maxVelocity" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.coasting.maxVelocity); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[0].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[1].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[2].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[3].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[4].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[5].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[6].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_transmissionRatio" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].transmissionRatio); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_invInertia" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].invInertia); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.omega.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.omega.max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_drag_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.drag.min); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_drag_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->gearBox.gear[7].dragMap.drag.factor); *strInit = cArguments;  return true; }
		if ("engine_thrustLine_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.thrustLine.omega.min); *strInit = cArguments;  return true; }
		if ("engine_thrustLine_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.thrustLine.omega.max); *strInit = cArguments;  return true; }
		if ("engine_thrustLine_torque_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.thrustLine.torque.min); *strInit = cArguments;  return true; }
		if ("engine_thrustLine_torque_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.thrustLine.torque.factor); *strInit = cArguments;  return true; }
		if ("engine_torqueRate_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.torqueRate.omega.min); *strInit = cArguments;  return true; }
		if ("engine_torqueRate_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.torqueRate.omega.max); *strInit = cArguments;  return true; }
		if ("engine_torqueRate_rate_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.torqueRate.rate.min); *strInit = cArguments;  return true; }
		if ("engine_torqueRate_rate_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.torqueRate.rate.factor); *strInit = cArguments;  return true; }
		if ("engine_minRefTorque_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.minRefTorque.omega.min); *strInit = cArguments;  return true; }
		if ("engine_minRefTorque_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.minRefTorque.omega.max); *strInit = cArguments;  return true; }
		if ("engine_minRefTorque_torque_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.minRefTorque.torque.min); *strInit = cArguments;  return true; }
		if ("engine_minRefTorque_torque_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.minRefTorque.torque.factor); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_omega_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.omega.min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_omega_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.omega.max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[0].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[0].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[1].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[1].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[2].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[2].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[3].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[3].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[4].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[4].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[5].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[5].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[6].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[6].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[7].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[7].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[8].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[8].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[9].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[9].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[10].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[10].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[11].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[11].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_12_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[12].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_12_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[12].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_13_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[13].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_13_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[13].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_14_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[14].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_14_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[14].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_15_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[15].min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_torque_15_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.torque[15].max); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_power_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.power.min); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_power_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.consumptionMap.power.factor); *strInit = cArguments;  return true; }
		if ("engine_torqueReserve_absolute" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.torqueReserve.absolute); *strInit = cArguments;  return true; }
		if ("engine_torqueReserve_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.torqueReserve.factor); *strInit = cArguments;  return true; }
		if ("engine_thrustPower" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.thrustPower); *strInit = cArguments;  return true; }
		if ("engine_cutoffMinOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.cutoffMinOmega); *strInit = cArguments;  return true; }
		if ("engine_ePowerAccelOffset" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->engine.ePowerAccelOffset); *strInit = cArguments;  return true; }
		if ("simple_powerMap_velocity_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.velocity.min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_velocity_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.velocity.max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_0_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[0].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_0_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[0].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_1_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[1].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_1_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[1].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_2_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[2].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_2_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[2].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_3_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[3].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_3_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[3].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_4_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[4].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_4_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[4].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_5_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[5].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_5_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[5].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_6_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[6].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_6_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[6].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_7_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[7].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_7_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[7].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_8_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[8].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_8_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[8].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_9_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[9].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_9_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[9].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_10_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[10].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_10_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[10].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_11_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[11].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_11_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[11].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_12_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[12].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_12_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[12].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_13_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[13].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_13_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[13].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_14_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[14].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_14_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[14].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_15_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[15].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_15_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[15].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_16_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[16].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_16_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[16].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_17_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[17].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_17_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[17].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_18_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[18].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_18_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[18].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_19_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[19].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_19_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[19].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_20_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[20].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_20_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[20].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_21_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[21].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_21_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[21].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_22_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[22].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_22_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[22].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_23_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[23].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_23_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[23].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_24_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[24].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_24_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[24].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_25_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[25].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_25_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[25].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_26_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[26].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_26_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[26].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_27_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[27].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_27_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[27].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_28_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[28].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_28_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[28].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_29_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[29].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_29_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[29].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_30_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[30].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_30_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[30].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_31_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[31].min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_force_31_max" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.force[31].max); *strInit = cArguments;  return true; }
		if ("simple_powerMap_power_min" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.power.min); *strInit = cArguments;  return true; }
		if ("simple_powerMap_power_factor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.powerMap.power.factor); *strInit = cArguments;  return true; }
		if ("simple_idlePower" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.idlePower); *strInit = cArguments;  return true; }
		if ("simple_coastLimit" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->simple.coastLimit); *strInit = cArguments;  return true; }
		if ("misc_curveFactor" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%.10f", p_theSrcData->misc.curveFactor); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[0].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_0_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[0].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[1].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_1_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[1].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[2].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_2_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[2].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[3].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_3_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[3].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[4].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_4_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[4].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[5].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_5_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[5].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[6].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_6_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[6].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[7].dragMap.numOmega); *strInit = cArguments;  return true; }
		if ("gearBox_gear_7_dragMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[7].dragMap.numTorque); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.consumptionMap.numOmega); *strInit = cArguments;  return true; }
		if ("engine_consumptionMap_numTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.consumptionMap.numTorque); *strInit = cArguments;  return true; }
		if ("simple_powerMap_numVelocity" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->simple.powerMap.numVelocity); *strInit = cArguments;  return true; }
		if ("simple_powerMap_numForce" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->simple.powerMap.numForce); *strInit = cArguments;  return true; }
		if ("bufferSize" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->bufferSize); *strInit = cArguments;  return true; }
		if ("valid" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%i", p_theSrcData->valid); *strInit = cArguments;  return true; }
		if ("gearBox_numGears" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.numGears); *strInit = cArguments;  return true; }
		if ("gearBox_requestAllowed" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%i", p_theSrcData->gearBox.requestAllowed); *strInit = cArguments;  return true; }
		if ("gearBox_useSumTorque" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%i", p_theSrcData->gearBox.useSumTorque); *strInit = cArguments;  return true; }
		if ("gearBox_coasting_possible" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%i", p_theSrcData->gearBox.coasting.possible); *strInit = cArguments;  return true; }

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_0_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[0].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[0].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_1_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[1].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[1].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_2_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[2].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[2].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_3_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[3].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[3].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_4_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[4].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[4].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_5_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[5].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[5].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_6_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[6].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[6].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "gearBox_gear_7_dragMap_drag_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[7].dragMap.drag.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlDRAGCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->gearBox.gear[7].dragMap.drag.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}
		if ("engine_thrustLine_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.thrustLine.numOmega); *strInit = cArguments;  return true; }

		sprintf_s(cArguments, MAX_PATH, "engine_thrustLine_torque_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.thrustLine.torque.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlTHRUSTTORQUECOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.thrustLine.torque.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}
		if ("engine_torqueRate_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.torqueRate.numOmega); *strInit = cArguments;  return true; }

		sprintf_s(cArguments, MAX_PATH, "engine_torqueRate_rate_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.torqueRate.rate.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlTORQUERATECOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.torqueRate.rate.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}
		if ("engine_minRefTorque_numOmega" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.minRefTorque.numOmega); *strInit = cArguments;  return true; }

		sprintf_s(cArguments, MAX_PATH, "engine_minRefTorque_torque_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.minRefTorque.torque.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlREFTORQUECOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.minRefTorque.torque.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "engine_consumptionMap_power_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.consumptionMap.power.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlCONSPOWERCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->engine.consumptionMap.power.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "simple_powerMap_power_data");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->simple.powerMap.power.data[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlSIMPLEPOWERCOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->simple.powerMap.power.data[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}

		sprintf_s(cArguments, MAX_PATH, "misc_codeList_code");
		if (cArguments == strElementName)
		{
			sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->misc.codeList.code[0]);
			*strInit = *strInit + "[" + cArguments;
			for( uiIdx = 1 ; uiIdx < vmdlCODECOUNT; uiIdx++)
			{
				sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->misc.codeList.code[uiIdx]);
				*strInit = *strInit + "," + cArguments;
			}
			*strInit = *strInit + "]";
			return true;
		}
		if ("misc_codeList_count" == strElementName){ sprintf_s(cArguments, MAX_PATH,"%u", p_theSrcData->misc.codeList.count); *strInit = cArguments;  return true; }
		return false;
	};
};
#endif

