#ifndef guard_vmdlSingleTrack_h
#define guard_vmdlSingleTrack_h


/** \brief	Berechnet die Fahrwiderstandskraft, die bei einer Kurvenfahrt aus der Fliehkraft ergibt */
void			  vmdlSgTrGetCurveForce(IN	const	singleTrackModel_T		*singleTrack,			/**< interne Datenstruktur des Einspurmodells */
										IN	const	real32_T				 forceY,				/**< Fliehkraft [N] */
										OUT			real32_T				*curveForce				/**< Fahrwiderstandskraft [N] */
										);


/**	 \brief	Berechnet die Bahnkr�mmung, die sich aus Fahrzeuggeschwindigkeit und Lenkradwinkel ergibt */
bool_T		   vmdlSgTrWheelToCurvature(IN	const	singleTrackModel_T		*singleTrack,			/**< interne Datenstruktur des Einspurmodells */
										IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
										IN	const	real32_T				 wheelAngle,			/**< Lenkradwinkel [rad] */
										IN	const	real32_T				 rearAngle,				/**< Hinterachs-Lenkwinkel [rad] */
										IN	const	bool_T					 rasPresent,			/**< Ist eine Hinterachslenkung verbaut? */
										OUT			real32_T				*curvature				/**< Bahnkr�mmung [1/m] */
										);


#endif
