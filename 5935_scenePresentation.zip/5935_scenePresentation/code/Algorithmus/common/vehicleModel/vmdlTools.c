#include "common/common.h"
#include "vehicleModel_private.h"

#include "vmdlTools.h"
#include "vmdlResistance.h"
#include "vmdlResistanceTypes.h"
#include "vmdlGearBox.h"
#include "vmdlSingleTrack.h"
#include "vmdlSimple.h"
#include "vmdlEngine.h"
#include "vmdlMisc.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vmdlTools)


bool_T	  vmdlGetTorqueAcceleration(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 velocity,
									IN	const	gear_T					 gear,
									IN	const	real32_T				 torque,
									IN	const	real32_T				 resDeviation,
									OUT			real32_T				*acceleration)
{
	resistanceFactors_T	resFactors;
	real32_T			resForce;


	/* Berechnen der Fahrwiderstandskraft */
	vmdlResGetResistanceFactors( velocity,
								 curvature,
								 slope,
								&resFactors);

	vmdlResGetResistanceForce(&vehicleModel->resistance,
							  &vehicleModel->singleTrack,
							  &resFactors,
							   resDeviation,
							  &resForce);

	diagFNaN(resForce);


	/* Berechnen der resultierenden Beschleunigung */
	diagFF(vmdlGBTorqueToAcceleration(&vehicleModel->gearBox,
									   torque,
									   resForce,
									   velocity,
									   gear,
									   acceleration));

	return true;
}


bool_T	   vmdlGetEpowerAccelOffset(IN	const	vehicleModel_T			*vehicleModel,
									OUT			real32_T				*offset)
{
	*offset = vehicleModel->engine.ePowerAccelOffset;
	return true;
}


bool_T	  vmdlGetAccelerationTorque(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 acceleration,
									IN	const	real32_T				 resistance,
									IN	const	real32_T				 velocity,
									IN	const	gear_T					 gear,
									OUT			real32_T				*torque,
									OUT			real32_T				*omega)
{
	/* Berechnen der resultierenden Beschleunigung */
	diagFF(vmdlGBAccelerationToTorque(&vehicleModel->gearBox,
									   acceleration,
									   resistance,
									   velocity,
									   gear,
									   torque,
									   omega));


	return true;
}


bool_T				   vmdlGetOmega(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 velocity,
									IN	const	gear_T					 gear,
									OUT			real32_T				*omega)
{
	diagFF(vmdlGBGetOmega(&vehicleModel->gearBox,
						   velocity,
						   gear,
						   omega));

	return true;
}


bool_T		 vmdlGetResistanceForce(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 velocity,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									IN	const	real32_T				 resDeviation,
									OUT			real32_T				*resistance)
{
	resistanceFactors_T	resFactors;


	/* Berechnen der Fahrwiderstandskraft */
	vmdlResGetResistanceFactors( velocity,
								 curvature,
								 slope,
								&resFactors);

	vmdlResGetResistanceForce(&vehicleModel->resistance,
							  &vehicleModel->singleTrack,
							  &resFactors,
							   resDeviation,
							   resistance);

	diagFNaN(*resistance);


	return true;
}


bool_T	   vmdlGetSteeringCurvature(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 wheelAngle,
									IN	const	real32_T				 rearAngle,
									IN	const	real32_T				 velocity,
									IN	const	bool_T					 rasPresent,
									OUT			real32_T				*curvature)
{
	diagFF(vmdlSgTrWheelToCurvature(&vehicleModel->singleTrack,
									 velocity,
									 wheelAngle,
									 rearAngle,
									 rasPresent,
									 curvature));

	return true;
}


bool_T	   vmdlGetTransmissionRatio(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	gear_T					 gear,
									OUT			real32_T				*ratio)
{
	diagFF(vmdlGBGetTransmissionRatio(&vehicleModel->gearBox,
									   gear,
									   ratio));

	return true;
}


void	   vmdlGetGearRequestOffset(IN	const	vehicleModel_T			*vehicleModel,
									OUT			real32_T				*requestOffset)
{
	vmdlGBGetRequestOffset(&vehicleModel->gearBox, requestOffset);
}


void	   vmdlIsGearRequestAllowed(IN	const	vehicleModel_T			*vehicleModel,
									OUT			bool_T					*requestAllowed)
{
	vmdlGBIsGearRequestAllowed(&vehicleModel->gearBox, requestAllowed);
}


bool_T	  vmdlGetAccelerationLimits(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	deviationState_T		*deviationState,
									IN	const	real32_T				 velocity,
									IN	const	real32_T				 curvature,
									IN	const	real32_T				 slope,
									OUT			real32_T				*maxAcceleration,
									OUT			real32_T				*minAcceleration,
									OUT			real32_T				*coastMaxAcceleration,
									OUT			real32_T				*coastMinAcceleration,
									OUT			simpleOffset_T			*simpleOffset)
{
	resistanceFactors_T	resFactors;


	/* Fahrwiderstandsfaktoren abrufen */
	vmdlResGetResistanceFactors( velocity,
								 curvature,
								 slope,
								&resFactors);


	/* Beschleunigungslimits abrufen */
	diagFF(vmdlSmpGetLimits(&vehicleModel->simple,
							&vehicleModel->resistance,
							&vehicleModel->singleTrack,
							&vehicleModel->gearBox,
							&resFactors,
							 deviationState,
							 maxAcceleration,
							 minAcceleration,
							 coastMaxAcceleration,
							 coastMinAcceleration,
							 simpleOffset));


	return true;
}


bool_T	   vmdlPreSelectSimplePower(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 velocity,
									IN	const	simpleOffset_T			*offset,
									OUT			simplePowerPreSel_T		*preSel)
{
	diagFF(vmdlSmpPreSelect(&vehicleModel->simple,
							 velocity,
							 offset,
							 preSel));

	return true;
}


bool_T			 vmdlGetSimplePower(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	simplePowerPreSel_T		*preSel,
									IN	const	simpleState_T			 simpleState,
									IN	const	real32_T				 acceleration,
									OUT			real32_T				*simplePower)
{
	diagFF(vmdlSmpGetPower(&vehicleModel->resistance,
						   &vehicleModel->simple,
						    preSel,
							simpleState,
							acceleration,
							simplePower));

	return true;
}


bool_T			  vmdlGetMinMaxGear(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 velocity,
									OUT			gear_T					*minGear,
									OUT			gear_T					*maxGear)
{
	diagFF(vmdlGBGetMinMaxGear(&vehicleModel->gearBox,
							    velocity,
							    minGear,
							    maxGear));

	return true;
}


bool_T				vmdlGetNumGears(IN	const	vehicleModel_T			*vehicleModel,
									OUT			uint8_T					*numGears)
{
	diagFF(vmdlGBGetNumGears(&vehicleModel->gearBox, numGears));

	return true;
}


void		 vmdlIsCoastingPossible(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 velocity,
									OUT			bool_T					*possible)
{
	vmdlGBIsCoastingPossible(&vehicleModel->gearBox,
							  velocity,
							  possible);
}


bool_T			   vmdlGetMaxTorque(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 omega,
									OUT			real32_T				*maxTorque)
{
	diagFF(vmdlEngGetMaxTorque(&vehicleModel->engine,
							    omega,
							    maxTorque));

	return true;
}


bool_T			vmdlGetMinRefTorque(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 omega,
									OUT			real32_T				*minRefTorque)
{
	diagFF(vmdlEngGetMinRefTorque(&vehicleModel->engine,
								   omega,
								   minRefTorque));

	return true;
}


bool_T		   vmdlGetMaxTorqueRate(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 omega,
									OUT			real32_T				*maxTorqueRate)
{
	diagFF(vmdlEngGetMaxTorqueRate(&vehicleModel->engine,
								    omega,
									maxTorqueRate));

	return true;
}


void		 vmdlApplyTorqueReserve(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 maxTorque,
									OUT			real32_T				*limitTorque)
{
	vmdlEngApplyReserve(&vehicleModel->engine,
						 maxTorque,
						 limitTorque);
}


bool_T			   vmdlGetFuelPower(IN	const	vehicleModel_T			*vehicleModel,
									IN	const	real32_T				 omega,
									IN	const	real32_T				 torque,
									OUT			real32_T				*fuelPower)
{
	diagFF(vmdlEngGetPower(&vehicleModel->engine,
						    omega,
						    torque,
						    fuelPower));

	return true;
}


bool_T			  vmdlGetWheelPower(IN	const	vehicleModel_T		*vehicleModel,
									IN	const	real32_T			 velocity,
									IN	const	real32_T			 acceleration,
									IN	const	real32_T			 curvature,
									IN	const	real32_T			 slope,
									IN	const	real32_T			 resistanceDeviation,
									OUT			real32_T			*wheelPower)
{
	real32_T resistanceForce, totalForce;

	/* Berechnen der Fahrwiderstandskraft */
	diagFF(vmdlGetResistanceForce(	 vehicleModel,
									 velocity,
									 curvature,
									 slope,
									 resistanceDeviation,
									&resistanceForce));

	/*Gesamte Kraft*/
	totalForce = vehicleModel->resistance.mass * acceleration + resistanceForce;

	/*Gesamte Leistung*/
	*wheelPower = totalForce * velocity;

	return true;
}


void			 vmdlGetCurveFactor(IN	const	vehicleModel_T		*vehicleModel,
									OUT			real32_T			*factor)
{
	vmdlMsGetCurveFactor(&vehicleModel->misc,
						  factor);
}


/** \brief	Berechnet aus dem Moment prim�ren und sekund�ren Maschine ein virtuelles Gesamtantriebsmoment der prim�ren Maschine */
bool_T			 vmdlGetTotalTorque(IN	const	vehicleModel_T		*vehicleModel,
									IN	const	real32_T			 sumTorque,
									IN	const	real32_T			 eTorquePrimary,
									IN	const	real32_T			 eTorqueSecondary,
									IN	const	gear_T				 gear,
									OUT			real32_T			*torque)
{
	diagFF(vmdlGBGetTotalTorque(&vehicleModel->gearBox,
								 sumTorque,
								 eTorquePrimary,
								 eTorqueSecondary,
								 gear,
								 torque));


	return true;
}


bool_T	vmdlGetMaxAccelerationForWheelPower(IN	const	vehicleModel_T		*vehicleModel,
											IN	const	real32_T			 maxWheelPower,
											IN	const	real32_T			 curvature,
											IN	const	real32_T			 slope,
											IN	const	real32_T			 resistanceDeviation,
											IN	const	real32_T			 currentVelocity,
											IN	const	real32_T			 currentAcceleration,
											IN	const	real32_T			 deltaT,
											INOUT		real32_T			*maxAcceleration
											)
{
	diagFF(vmdlResGetMaxAccelerationForWheelPower(vehicleModel,
												  maxWheelPower,
												  curvature,
												  slope,
												  resistanceDeviation,
												  currentVelocity,
												  currentAcceleration,
												  deltaT,
												  maxAcceleration));
	return true;
}


void				   vmdlIsMotorCodeValid(IN	const	vehicleModel_T		*vehicleModel,
											IN	const	uint8_T				 motorCode,
											OUT			bool_T				*valid)
{
	vmdlMsIsMotorCodeValid(vehicleModel,
						   motorCode,
						   valid);
}
