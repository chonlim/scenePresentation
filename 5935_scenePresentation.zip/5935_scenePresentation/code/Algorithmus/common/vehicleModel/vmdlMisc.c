#include "common/common.h"
#include "vehicleModel_private.h"
#include "vmdlMisc.h"


void		   vmdlMsGetCurveFactor(IN	const	miscModel_T				*misc,
									OUT			real32_T				*factor)
{
	*factor = misc->curveFactor;
}


void		 vmdlMsIsMotorCodeValid(IN	const	vehicleModel_T		*vehicleModel,
									IN	const	uint8_T				 motorCode,
									OUT			bool_T				*valid)
{
	uint8_T i;
	bool_T result;

	/*Motorcode suchen*/
	result = false;
	for (i = 0u; i < (uint8_T)vmdlCODECOUNT; i++)
	{
		if (	motorCode == vehicleModel->misc.codeList.code[i]
			&&	i < vehicleModel->misc.codeList.count)
		{
			result = true;
		}
	}

	/*Ausgabe*/
	if (vehicleModel->misc.codeList.count == 0u) {
		*valid = true;
	} else {
		*valid = result;
	}
}
