#ifndef guard_vmdlEngine_h
#define guard_vmdlEngine_h


/** \brief	Gibt das maximal m�gliche Antriebsmoment bei der gegebenen Geschwindigkeit aus */
bool_T			vmdlEngGetMaxTorque(IN	const	engineModel_T			*engine,			/**< interne Datenstruktur der Antriebsmodells */
									IN	const	real32_T				 omega,				/**< Drehlzahl [rad/s] */
									OUT			real32_T				*maxTorque			/**< Maximalmoment [Nm] */
									);


/** \brief	Zieht die Hochschaltreserve vom maximal m�glichen Antriebsmoment ab */
void			vmdlEngApplyReserve(IN	const	engineModel_T			*engine,			/**< interne Datenstruktur des Antriebsmodells */
									IN	const	real32_T				 maxTorque,			/**< maximal m�gliches Antriebsmoment [Nm] */
									OUT			real32_T				*limitTorque		/**< maximal m�gliches Moment abz�glich der Hochschaltreserve [Nm] */
									);


/** \brief	Ruft die f�r eine Drehzahl, Drehmoment-Kombination erforderliche Eingangsleistung aus dem Verbrauchskennfeld ab */
bool_T			    vmdlEngGetPower(IN	const	engineModel_T			*engine,			/**< interne Datenstruktur des Antriebsmodells */
									IN	const	real32_T				 omega,				/**< Motordrehzahl [rad/s] */
									IN	const	real32_T				 torque,			/**< Antriebsmoment [Nm] */
									OUT			real32_T				*fuelPower			/**< Eingangsleistung [W] */
									);


/** \brief	Gibt das minimale Referenzmoment f�r die dynamische Momentengrenze zur�ck */
bool_T		 vmdlEngGetMinRefTorque(IN	const	engineModel_T			*engine,			/**< interne Datenstruktur des Antriebsmodells */
									IN	const	real32_T				 omega,				/**< Motordrehzahl [rad/s] */
									OUT			real32_T				*minRefTorque		/**< minimales Referenzmoment [Nm] */
									);


/** \brief	Gibt die drehzahlabh�ngig maximal zul�ssige Anpassrate f�r das Antriebsmoment zur�ck */
bool_T		vmdlEngGetMaxTorqueRate(IN	const	engineModel_T			*engine,			/**< interne Datenstruktur des Antriebsmodells */
									IN	const	real32_T				 omega,				/**< Motordrehzahl [rad/s] */
									OUT			real32_T				*maxTorqueRate		/**< maximale �nderungsrate des Antriebsmoments [Nm/s] */
									);




#endif
