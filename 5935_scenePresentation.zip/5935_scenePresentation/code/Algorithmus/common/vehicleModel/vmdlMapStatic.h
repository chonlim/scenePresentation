#ifndef guard_vmdlMapStatic_h
#define guard_vmdlMapStatic_h


static bool_T	  vmdlMapPreSelInitAxis(IN	const	mapAxis_T			*axis,
										IN	const	uint16_T			 count,
										IN	const	uint8_T				*dataPtr,
										OUT			axisPreSel_T		*preSel
										);



static bool_T	vmdlMapPreSelInterpAxis(IN	const	axisPreSel_T		*preSel,
										IN	const	real32_T			 y,
										OUT			real32_T			*value
										);


#endif
