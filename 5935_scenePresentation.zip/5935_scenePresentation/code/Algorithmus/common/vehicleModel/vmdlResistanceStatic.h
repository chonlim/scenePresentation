#ifndef guard_vmdlResistanceStatic_h
#define guard_vmdlResistanceStatic_h


/** \brief	Berechnet die Fahrwiderstandskraft, die sich f�r die gegebene Geschwindigkeit aus den ABC-Koeffizienten ergibt */
static void		vmdlResGetVelocityForce(IN	const	resistanceModel_T		*resistance,			/**< interne Datenstruktur des Fahrwiderstandsmodells */
										IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
										OUT			real32_T				*velocityForce			/**< Widerstandskraft [N] */
										);


/** \brief	Berechnet die Fahrwiderstandskraft, die sich f�r die gegebene Geschwindigkeit aus der Bahnkr�mmung ergibt */
static void		   vmdlResGetCurveForce(IN	const	singleTrackModel_T		*singleTrack,			/**< interne Datenstruktur des Einspurmodells */
										IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
										IN	const	real32_T				 curvature,				/**< Bahnkr�mmung [1/m] */
										OUT			real32_T				*curveForce				/**< Kurvenwiderstand [N] */
										);


/** \brief	Berechent die Fahrwiderstandskraft, die sich aus der gegebenen Steigung ergibt. */
static void		   vmdlResGetSlopeForce(IN	const	resistanceModel_T		*resistance,			/**< interne Datenstruktur des Fahrwiderstandsmodells */
										IN	const	real32_T				 slope,					/**< Steigung [1/1] */
										OUT			real32_T				*force					/**< Steigungswiderstand [N] */
										);


#endif
