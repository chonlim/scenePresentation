#include "common/common.h"
#include "vehicleModel_private.h"
#include "vmdlMap.h"
#include "vmdlMapTypes.h"
#include "vmdlMapStatic.h"


#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vmdlMap)


bool_T				 vmdlMapInterpolate(IN	const	mapAxis_T			*xAxis,
										IN	const	mapAxis_T			*yAxes,
										IN	const	uint16_T			 xCount,
										IN	const	uint16_T			 yCount,
										IN	const	real32_T			 x,
										IN	const	real32_T			 y,
										IN	const	uint8_T				*data,
										OUT			real32_T			*value)
{
	mapPreSel_T preSel;

	/* Vorauswahl der richtigen Kennfeld-Spalten */
	diagFF(vmdlMapPreSelInit( xAxis,
							  yAxes,
							  xCount,
							  yCount,
							  x,
							  data,
							 &preSel));

	/* Interpolation */
	diagFF(vmdlMapPreSelInterpolate(&preSel,
									 y,
									 value));


	return true;
}


bool_T				  vmdlMapLineInterp(IN	const	mapAxis_T			*axis,
										IN	const	uint16_T			 count,
										IN	const	real32_T			 x,
										IN	const	uint8_T				*dataPtr,
										OUT			real32_T			*value)
{
	axisPreSel_T preSel;


	/* Vorauswahl */
	diagFF(vmdlMapPreSelInitAxis(axis,
								 count,
								 dataPtr,
								 &preSel));


	/* Interpolation */
	diagFF(vmdlMapPreSelInterpAxis(&preSel,
								    x,
								    value));


	return true;
}



bool_T				  vmdlMapGetInvStep(IN	const	mapAxis_T			*axis,
										IN	const	uint16_T			 count,
										OUT			real32_T			*invStep)
{
	diagFF(axis->max > axis->min);
	diagFF(count > 1u);

	*invStep = ((real32_T)count - 1.0f) / (axis->max - axis->min);

	return true;
}


bool_T			 vmdlMapInterpolateAxis(IN	const	mapAxis_T			*axis,
										IN	const	real32_T			 invStep,
										IN	const	uint16_T			 count,
										IN	const	real32_T			 value,
										OUT			uint16_T			*index,
										OUT			real32_T			*delta)
{
	real32_T adjusted;
	real32_T stepped;
	uint16_T truncated;

	diagFF(count > 1u);


	/* Abfrage auf den Bereich [min max] eingrenzen */
	adjusted = value;
	adjusted = max(adjusted, axis->min);
	adjusted = min(adjusted, axis->max);


	/* Index berechnen */
	stepped  = (adjusted - axis->min) * invStep;
	truncated = (uint16_T)stepped;

	/* Ausgabe */
	*index	= (uint16_T)min(truncated, (count - 2u));
	*delta	= stepped - (real32_T)*index;


	return true;
}


bool_T				  vmdlMapPreSelInit(IN	const	mapAxis_T			*xAxis,
										IN	const	mapAxis_T			*yAxes,
										IN	const	uint16_T			 xCount,
										IN	const	uint16_T			 yCount,
										IN	const	real32_T			 xValue,
										IN	const	uint8_T				*data,
										OUT			mapPreSel_T			*preSel)
{
	uint16_T xIndex;
	real32_T xDelta;
	real32_T xInvStep;


	/* Interpolation auf der X-Achse */
	diagFF(vmdlMapGetInvStep( xAxis,
							  xCount,
							 &xInvStep));

	diagFF(vmdlMapInterpolateAxis( xAxis,
								   xInvStep,
								   xCount,
								   xValue,
								  &xIndex,
								  &xDelta));

	diagFF(xIndex + 1u < xCount);


	/* Indizes berechnen, die sich aus der X-Achse ergeben */
	preSel->factor[0]	= 1.0f - xDelta;
	preSel->factor[1]	= xDelta;

	diagFF(vmdlMapPreSelInitAxis(&yAxes[xIndex],
								  yCount,
								 &data[yCount * (xIndex)],
								 &preSel->axis[0]));

	diagFF(vmdlMapPreSelInitAxis(&yAxes[xIndex+1u],
								  yCount,
								 &data[yCount * (xIndex+1u)],
								 &preSel->axis[1]));


	return true;
}


bool_T		   vmdlMapPreSelInterpolate(IN	const	mapPreSel_T			*preSel,
										IN	const	real32_T			 y,
										OUT			real32_T			*value)
{
	real32_T part[2];

	/* Lineare Interpolation auf beiden Achsen */
	diagFF(vmdlMapPreSelInterpAxis(&preSel->axis[0], y, &part[0]));
	diagFF(vmdlMapPreSelInterpAxis(&preSel->axis[1], y, &part[1]));


	/* Verechnen der Zwischenergebnisse */
	*value = ((part[0] * preSel->factor[0]) + (part[1] * preSel->factor[1]));


	return true;
}


static bool_T	  vmdlMapPreSelInitAxis(IN	const	mapAxis_T			*axis,
										IN	const	uint16_T			 count,
										IN	const	uint8_T				*dataPtr,
										OUT			axisPreSel_T		*preSel)
{
	preSel->axis	= axis;
	preSel->count	= count;
	preSel->dataPtr	= dataPtr;

	diagFF(vmdlMapGetInvStep( axis,
							  count,
							 &preSel->invStep));

	return true;
}


static bool_T	vmdlMapPreSelInterpAxis(IN	const	axisPreSel_T		*preSel,
										IN	const	real32_T			 y,
										OUT			real32_T			*value)
{
	uint16_T index;
	real32_T offset;


	/* Berechnen von Index und Offset f�r die Interpolation */
	diagFF(vmdlMapInterpolateAxis( preSel->axis,
								   preSel->invStep,
								   preSel->count,
								   y,
								  &index,
								  &offset));

	diagFF(index + 1u < preSel->count);


	/* Interpolation */
	*value = ((real32_T)preSel->dataPtr[index]    * (real32_T)preSel->dataPtr[index])    * (1.0f - offset)
		   + ((real32_T)preSel->dataPtr[index+1u] * (real32_T)preSel->dataPtr[index+1u]) * (offset);

	*value /= 65025.0f;


	return true;
}

