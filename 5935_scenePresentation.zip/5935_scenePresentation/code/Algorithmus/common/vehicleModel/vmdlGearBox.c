#include "common/common.h"
#include "vehicleModel_private.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "vmdlGearBox.h"
#include "vmdlGearBoxStatic.h"
#include "vmdlMap.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vmdlGearBox)


bool_T		 vmdlGBTorqueToAcceleration(IN	const	gearBoxModel_T		*gearBox,
										IN	const	real32_T			 torque,
										IN	const	real32_T			 resistance,
										IN	const	real32_T			 velocity,
										IN	const	gear_T				 gear,
										OUT			real32_T			*acceleration)
{
	real32_T	invInertia;
	real32_T	drag;
	real32_T	ratio;
	real32_T	omega;
	real32_T	resTorque;


	/* Gesamt�bersetzungsverh�ltnis abfragen */
	diagFF(vmdlGBGetOverallRatio( gearBox,
								  gear,
								 &ratio));

	omega		= (velocity   * ratio);
	resTorque	= (resistance / ratio);


	/* �quivalente Fahrzeugtr�gheit im gegebenen Gang abfragen */
	diagFF(vmdlGBGetInvInertia( gearBox,
							    gear,
							   &invInertia));


	/* Getriebeverlustmoment abfragen */
	diagFF(vmdlGBGetTorqueLoss( gearBox,
							    gear,
							    torque,
							    omega,
							   &drag));


	*acceleration = ((torque - drag)- resTorque) * invInertia;


	return true;
}


bool_T		 vmdlGBAccelerationToTorque(IN	const	gearBoxModel_T		*gearBox,
										IN	const	real32_T			 acceleration,
										IN	const	real32_T			 resistance,
										IN	const	real32_T			 velocity,
										IN	const	gear_T				 gear,
										OUT			real32_T			*torque,
										OUT			real32_T			*omega)
{
	real32_T	invInertia;
	real32_T	drag;
	real32_T	ratio;
	real32_T	lcOmega;
	real32_T	resTorque;
	real32_T	idealTorque;


	/* Gesamt�bersetzungsverh�ltnis abfragen */
	diagFF(vmdlGBGetOverallRatio( gearBox,
								  gear,
								 &ratio));

	lcOmega		= (velocity   * ratio);
	resTorque	= (resistance / ratio);


	/* �quivalente Fahrzeugtr�gheit im gegebenen Gang abfragen */
	diagFF(vmdlGBGetInvInertia( gearBox,
							    gear,
							   &invInertia));


	idealTorque = acceleration / invInertia + resTorque;


	/* Getriebeverlustmoment abfragen */
	diagFF(vmdlGBGetTorqueLoss( gearBox,
							    gear,
							    idealTorque,
							    lcOmega,
							   &drag));


	*torque = idealTorque + drag;
	*omega	= lcOmega;

	return true;

}


bool_T		 vmdlGBGetTransmissionRatio(IN	const	gearBoxModel_T		*gearBox,
										IN	const	gear_T				 gear,
										OUT			real32_T			*transRatio)
{
	diagFF(gearBox->numGears <= (uint8_T)gearEOF);
	diagFF(gear < gearBox->numGears || gear == (gear_T)gearCoast);
	diagFF(gearBox->numGears > 0u);

	/* Berechnen der Getriebe�bersetzung. Im Segeln wird ersatzweise mit dem h�chsten Gang gerechnet. */
	*transRatio = gearBox->gear[(gear == (gear_T)gearCoast) ? (gearBox->numGears - 1u) : gear].transmissionRatio * gearBox->iDiff;

	return true;
}


bool_T					 vmdlGBGetOmega(IN	const	gearBoxModel_T		*gearBox,
										IN	const	real32_T			 velocity,
										IN	const	gear_T				 gear,
										OUT			real32_T			*omega)
{
	real32_T	ratio;
	real32_T	lcOmega;
	

	/* Gesamt�bersetzungsverh�ltnis abfragen */
	diagFF(vmdlGBGetOverallRatio( gearBox,
								  gear,
								 &ratio));

	lcOmega		= (velocity   * ratio);

	*omega	= lcOmega;


	return true;

}


static bool_T	  vmdlGBGetOverallRatio(IN	const	gearBoxModel_T		*gearBox,
										IN	const	gear_T				 gear,
										OUT			real32_T			*ratio)
{
	real32_T	gearRatio;


	/* Abrufen der Getriebe�bersetzung */
	diagFF(vmdlGBGetTransmissionRatio( gearBox,
									   gear,
									  &gearRatio));


	/* Berechnen der Gesamt�bersetzung */
	*ratio = gearRatio / gearBox->wheelRadius;
	diagFF(*ratio > 0.0f);

	return true;
}


static void			  vmdlGBGetAuxRatio(IN	const	gearBoxModel_T		*gearBox,
										OUT			real32_T			*ratio)
{
	real32_T	auxRatio;

	/* Berechnen der sekund�ren Gesamt�bersetzung */
	if (gearBox->auxRadius == 0.0f) {
		auxRatio	= gearBox->auxDiff * gearBox->auxRadius;
	} else {
		auxRatio	= gearBox->auxDiff / gearBox->auxRadius;
	}

	*ratio		= auxRatio;
}


static bool_T	    vmdlGBGetInvInertia(IN	const	gearBoxModel_T		*gearBox,
										IN	const	gear_T				 gear,
										OUT			real32_T			*invInertia)
{
	diagFF(gear < gearBox->numGears || gear == (gear_T)gearCoast);
	diagFF(gearBox->numGears > 0u);

	/* Abfragen der �quivalenten Tr�gheit. Im Segeln wird ersatzweise mit dem h�chsten Gang gerechnet */
	*invInertia = gearBox->gear[(gear == (gear_T)gearCoast) ? (gearBox->numGears - 1u) : gear].invInertia;

	return true;
}


static bool_T		vmdlGBGetTorqueLoss(IN	const	gearBoxModel_T		*gearBox,
										IN	const	gear_T				 gear,
										IN	const	real32_T			 torque,
										IN	const	real32_T			 omega,
										OUT			real32_T			*torqueLoss)
{
	uint8_T adjGear;

	diagFF(gear < (gear_T)gearBox->numGears || gear == (gear_T)gearCoast);


	/* Im Segeln wird ersatzweise mit dem h�chsten m�glichen Gang gerechnet */
	adjGear = (uint8_T)((gear == (gear_T)gearCoast) ? (gearBox->numGears - 1u) : (gear));


	/* Getriebeverlustmoment berechnen */
	diagFF(vmdlGBInterpolateDrag(&gearBox->gear[adjGear].dragMap,
								  torque,
								  omega,
								  torqueLoss));


	return true;
}


static bool_T	  vmdlGBInterpolateDrag(IN	const	dragMap_T			*map,
										IN	const	real32_T			 torque,
										IN	const	real32_T			 omega,
										OUT			real32_T			*drag)
{
	real32_T scaled;


	/* Daten des Kennfelds an die allgemeine Interpolationsfunktion weitergeben */
	diagFF(vmdlMapInterpolate(&map->omega,
							   map->torque,
							   map->numOmega,
							   map->numTorque,
							   omega,
							   torque,
							   map->drag.data,
							  &scaled));


	/* Umrechnen des [0 1]-skalierten Werts in das Verlustmoment */
	*drag = map->drag.min + (map->drag.factor * scaled);


	return true;
}


bool_T				vmdlGBGetMinMaxGear(IN	const	gearBoxModel_T		*gearBox,
										IN	const	real32_T			 velocity,
										OUT			gear_T				*minGear,
										OUT			gear_T				*maxGear)
{
	uint8_T		gear;
	uint8_T		gearMin;
	uint8_T		gearMax;
	real32_T	factor;


	gearMin	= INVALID_UINT8;
	gearMax	= 0;


	/* Berechnen der Umrechnungsfaktors Gang�bersetzung -> Drehzahl */
	factor	= (velocity * gearBox->iDiff / gearBox->wheelRadius);


	/* Pr�fen, welche G�nge die Drehzahlgrenze nicht verletzen */
	for(gear = 0; gear < (uint8_T)(gearValues_T)gearEOF; gear++) {
		bool_T		canGear;
		real32_T	omega;

		canGear	= true;
		omega	= gearBox->gear[gear].transmissionRatio * factor;

		/* Im ersten Gang ist eine Unterschreitung der Drehzahlgrenze zul�ssig */
		if(omega < gearBox->minOmega && gear != 0u) {
			canGear = false;
		}

		/* Im h�chsten Gang ist eine �berschreitung der Drehzahlgrenze zul�ssig */
		if(omega > gearBox->maxOmega && gear + 1u != gearBox->numGears) {
			canGear = false;
		}

		if(gear >= gearBox->numGears) {
			canGear = false;
		}

		if(canGear) {
			gearMin = min(gearMin, gear);
			gearMax = max(gearMax, gear);
		}
	}

	diagFF(gearMax >= gearMin);


	/* Ausgabe */
	*minGear = gearMin;
	*maxGear = gearMax;


	return true;
}


bool_T				  vmdlGBGetNumGears(IN	const	gearBoxModel_T		*gearBox,
										OUT			uint8_T				*numGears)
{
	diagFF(gearBox->numGears > 0u);
	diagFF(gearBox->numGears <= (uint8_T)gearEOF);

	*numGears = gearBox->numGears;

	return true;
}


void		   vmdlGBIsCoastingPossible(IN	const	gearBoxModel_T		*gearBox,
										IN	const	real32_T			 velocity,
										OUT			bool_T				*possible)
{
	*possible = gearBox->coasting.possible;

	if(velocity < gearBox->coasting.minVelocity) {
		*possible = false;
	}

	if(velocity > gearBox->coasting.maxVelocity) {
		*possible = false;
	}
}


void			 vmdlGBGetRequestOffset(IN	const	gearBoxModel_T		*gearBox,
										OUT			real32_T			*requestOffset)
{
	*requestOffset = gearBox->requestOffset;
}


void		 vmdlGBIsGearRequestAllowed(IN	const	gearBoxModel_T		*gearBox,
										OUT			bool_T				*requestAllowed)
{
	*requestAllowed = gearBox->requestAllowed;
}


bool_T			   vmdlGBGetTotalTorque(IN	const	gearBoxModel_T		*gearBox,
										IN	const	real32_T			 sumTorque,
										IN	const	real32_T			 eTorquePrimary,
										IN	const	real32_T			 eTorqueSecondary,
										IN	const	gear_T				 gear,
										OUT			real32_T			*torque)
{
	real32_T	ratio;
	real32_T	primTorque;
	real32_T	auxTorque;
	real32_T	auxRatio;
	real32_T	equivTorque;


	/* Auswahl des relevanten Werts f�r das Prim�r-Moment */
	primTorque	= gearBox->useSumTorque ? sumTorque : eTorquePrimary;
	auxTorque	= gearBox->useSumTorque ? 0.0f      : eTorqueSecondary;


	/* Gesamt�bersetzungsverh�ltnis abfragen */
	diagFF(vmdlGBGetOverallRatio( gearBox,
								  gear,
								 &ratio));


	/* Das Moment der sekund�ren E-Maschine wird in ein �quivalentes Moment der prim�ren Maschine umgerechnet */
	vmdlGBGetAuxRatio(gearBox, &auxRatio);
	equivTorque	= (auxTorque * auxRatio / ratio);


	*torque		= (primTorque + equivTorque);


	return true;
}
