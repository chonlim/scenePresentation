#ifndef guard_vmdlTools_h
#define guard_vmdlTools_h

#include "vmdlSimpleTypes.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/vehicleModel/vehicleModel_interface.h"


/** \brief	Berechnet die Beschleunigung, die sich bei den gegebenen Fahrzeug- und Umgebungsbedingungen aus dem Motormoment ergibt 

\spec SwMS_Innodrive2_Model_60
*/
bool_T	  vmdlGetTorqueAcceleration(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 curvature,				/**< Bahnkr�mmung des Fahrzeugs [1/m] */
									IN	const	real32_T				 slope,					/**< Fahrbahnsteigung [1/1] */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	gear_T					 gear,					/**< eingelegter Gang */
									IN	const	real32_T				 torque,				/**< Motormoment [Nm] */
									IN	const	real32_T				 resDeviation,			/**< Zugkraftabweichung [N] */
									OUT			real32_T				*acceleration			/**< Beschleunigung [m/s�] */
									);

/** \brief	Gibt den Sicherheitsoffset auf die maximale Beschleunigung des E-Motors aus 

\spec SwMS_Innodrive2_Model_61
*/
bool_T	   vmdlGetEpowerAccelOffset(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									OUT			real32_T				*offset					/**< Beschleunigungsoffset [m/s^2]*/
									);

/** \brief	Berechnet das Antriebsmoment, das sich bei den gegebenen Fahrzeug- und Umgebungsbedingungen aus der geforderten Beschleunigung ergibt 

\spec SwMS_Innodrive2_Model_62
*/
bool_T	  vmdlGetAccelerationTorque(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 acceleration,			/**< Beschleunigung [m/s�] */
									IN	const	real32_T				 resistance,			/**< Fahrwiderstandskraft [N] */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	gear_T					 gear,					/**< eingelegter Gang */
									OUT			real32_T				*torque,				/**< Motormoment [Nm] */
									OUT			real32_T				*omega					/**< Motordrehzahl [rad/s] */
									);


/** \brief	Berechnet die Drehzahl, die sich aus Geschwindigkeit und eingelegtem Gang ergibt 

\spec SwMS_Innodrive2_Model_63
*/
bool_T				   vmdlGetOmega(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	gear_T					 gear,					/**< eingelegter Gang */
									OUT			real32_T				*omega					/**< Drehzahl, die sich aus Gang und Geschwindigkeit ergibt [rad/s] */
									);


/** \brief	Berechnet die Fahrwiderstandskraft, das sich aus den gegebenen Fahrzeug- und Umgebungsbedingungen ergibt 

\spec SwMS_Innodrive2_Model_64
*/
bool_T		 vmdlGetResistanceForce(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	real32_T				 curvature,				/**< Bahnkr�mmung des Fahrzeugs [1/m] */
									IN	const	real32_T				 slope,					/**< Fahrbahnsteigung [1/1] */
									IN	const	real32_T				 resDeviation,			/**< Zugkraftabweichung [N] */
									OUT			real32_T				*resistance				/**< Fahrwiderstandskraft [N] */
									);


/** \brief	Berechnet die Bahnkr�mmung, die sich bei einer gegebenen Fahrzeuggeschwindigkeit aus dem Lenkwinkel ergibt 

\spec SwMS_Innodrive2_Model_65
*/
bool_T	   vmdlGetSteeringCurvature(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 wheelAngle,			/**< Lenkradwinkel [rad] (positv: links, negativ: rechts) */
									IN	const	real32_T				 rearAngle,				/**< Hinterachs-Lenkwinkel [rad] (positv: links, negativ: rechts)*/
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	bool_T					 rasPresent,			/**< Ist eine Hinterachslenkung verbaut? */
									OUT			real32_T				*curvature				/**< Bahnkr�mmung [1/m] */
									);


/** \brief	Gibt das �bersetzungsverh�ltnis des Getriebes in einem Gang zur�ck 

\spec SwMS_Innodrive2_Model_66
*/
bool_T	   vmdlGetTransmissionRatio(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	gear_T					 gear,					/**< eingelegter Gang */
									OUT			real32_T				*ratio					/**< �bersetzungsverh�ltnis [1/1] */
									);


/* \brief	Gibt den Offset zur�ck, mit dem eine �bersetzungsanforderung ans Getriebebelegt werden soll 

\spec SwMS_Innodrive2_Model_67
*/
void	   vmdlGetGearRequestOffset(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Getriebemodells */
									OUT			real32_T				*requestOffset			/**< Offset f�r die Wunsch�bersetzung */
									);


/** \brief	Gibt zur�ck, ob das Ausgeben eine g�ltigen Wunsch�bersetzung lt. Fahrzeugmodell zul�ssig ist 

\spec SwMS_Innodrive2_Model_68
*/
void	   vmdlIsGearRequestAllowed(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									OUT			bool_T					*requestAllowed			/**< ist eine Ganganforderung zul�ssig? */
									);


/** \brief	Berechnet die Beschleunigungsgrenzen des vereinfachten Fahrzeug- und Triebstrangmodells 

\spec SwMS_Innodrive2_Model_69
*/
bool_T	  vmdlGetAccelerationLimits(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	deviationState_T		*deviationState,		/**< interne Datenstruktur der Zugkraftfehlersch�tzung */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	real32_T				 curvature,				/**< Bahnkr�mmung [1/m] */
									IN	const	real32_T				 slope,					/**< Fahrbahnsteigung [1/1] */
									OUT			real32_T				*maxAcceleration,		/**< maximal m�gliche Beschleunigung [m/s�] */
									OUT			real32_T				*minAcceleration,		/**< minimal m�gliche Beschleunigung [m/s�] */
									OUT			real32_T				*coastMaxAcceleration,	/**< Maximale Beschleunigung bei ge�ffnetem Triebstrang [m/s�] */
									OUT			real32_T				*coastMinAcceleration,	/**< Minimale Beschleunigung bei ge�ffnetem Triebstrang [m/s�] */
									OUT			simpleOffset_T			*simpleOffset			/**< Zugkraftoffset f�r den Zugriff auf das simplePower-Kennfeld */
									);


/** \brief	F�hrt eine Vorauswahl f�r einen vereinfachten sp�teren Zugriff auf das simplePower-Kennfeld durch 

\spec SwMS_Innodrive2_Model_70
*/
bool_T	   vmdlPreSelectSimplePower(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur der Fahrzeugmodells */
									IN	const	real32_T				 velocity,				/**< Geschwindigkeit, f�r die die Abfrage durchgef�hrt werden soll [m/s] */
									IN	const	simpleOffset_T			*offset,				/**< Zugkraftoffset f�r den Zugriff auf das simplePower-Kennfeld */
									OUT			simplePowerPreSel_T		*preSel					/**< interne Datenstruktur der Vorauswahl */
									);


/** \brief	Ruft vorausgew�hlte Daten aus dem simplePower-Kennfeld ab 

\spec SwMS_Innodrive2_Model_71
*/
bool_T			 vmdlGetSimplePower(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur der Fahrzeugmodells */
									IN	const	simplePowerPreSel_T		*preSel,				/**< interne Datenstruktur der Vorauswahl */
									IN	const	simpleState_T			 simpleState,			/**< Triebstrangzustand, f�r den die Abfrage ausgef�hrt wird */
									IN	const	real32_T				 acceleration,			/**< Beschleunigung, f�r die die Abfrage ausgef�hrt wird [m/s�] */
									OUT			real32_T				*simplePower			/**< vom Motor geforderte Leistung lt. simplePower-Kennfeld */
									);


/** \brief	Gibt den f�r eine Geschwindigkeit minimal und maximal m�glichen Gang zur�ck 

\spec SwMS_Innodrive2_Model_72
*/
bool_T			  vmdlGetMinMaxGear(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									OUT			gear_T					*minGear,				/**< minimal m�glicher Gang */
									OUT			gear_T					*maxGear				/**< maximal m�glicher Gang */
									);


/** \brief	Gibt die im Getriebemodell hinterlegte Anzahl der G�nge zur�ck 

\spec SwMS_Innodrive2_Model_73
*/
bool_T			    vmdlGetNumGears(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									OUT			uint8_T					*numGears				/**< Anzahl der G�nge */
									);


/** \brief	Gibt an, ob Segen bei einer gegebenen Geschwindigkeit m�glich ist 

\spec SwMS_Innodrive2_Model_74
*/
void		 vmdlIsCoastingPossible(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
									OUT			bool_T					*possible				/**< ist Segeln m�glich? */
									);


/** \brief	Gibt das bei einer gegebenen Drehzahl maximal m�gliche Antriebsmoment zur�ck 

\spec SwMS_Innodrive2_Model_75
*/
bool_T			   vmdlGetMaxTorque(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 omega,					/**< Motordrehzahl [rad/s] */
									OUT			real32_T				*maxTorque				/**< maximal m�gliches Antriebsmoment [Nm] */
									);


/** \brief	Gibt das minimale Referenzmoment f�r die dynamische Momentengrenze zur�ck 

\spec SwMS_Innodrive2_Model_76
*/
bool_T			vmdlGetMinRefTorque(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzuegmodells */
									IN	const	real32_T				 omega,					/**< Motordrehzahl [rad/s] */
									OUT			real32_T				*minRefTorque			/**< minimales Referenzmoment [Nm] */
									);


/** \brief	Gibt die drehzahlabh�ngig maximal zul�ssige Anpassrate f�r das Antriebsmoment zur�ck 

\spec SwMS_Innodrive2_Model_77
*/
bool_T		   vmdlGetMaxTorqueRate(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzuegmodells */
									IN	const	real32_T				 omega,					/**< Motordrehzahl [rad/s] */
									OUT			real32_T				*maxTorqueRate			/**< maximale �nderungsrate des Antriebsmoments [Nm/s] */
									);


/** \brief	Zieht die Hochschaltreserve vom maximal m�glichen Antriebsmoment ab 

\spec SwMS_Innodrive2_Model_78
*/
void		 vmdlApplyTorqueReserve(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 maxTorque,				/**< maximal m�gliches Antriebsmoment [Nm] */
									OUT			real32_T				*limitTorque			/**< maximal m�gliches Moment abz�glich der Hochschaltreserve [Nm] */
									);


/** \brief	Ruft die f�r eine Drehzahl, Drehmoment-Kombination erforderliche Eingangsleistung aus dem Verbrauchskennfeld ab 

\spec SwMS_Innodrive2_Model_79
*/
bool_T			   vmdlGetFuelPower(IN	const	vehicleModel_T			*vehicleModel,			/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T				 omega,					/**< Motordrehzahl [rad/s] */
									IN	const	real32_T				 torque,				/**< Antriebsmoment [Nm] */
									OUT			real32_T				*fuelPower				/**< Eingangsleistung [W] */
									);


/**	\brief	Berechnet die Radleistung, die sich aus Geschwindigkeit, Beschleunigung, Kurvenkr�mmung, Steigung und Modellfehler ergibt. 

\spec SwMS_Innodrive2_Model_80
*/
bool_T			  vmdlGetWheelPower(IN	const	vehicleModel_T		*vehicleModel,				/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T			 velocity,					/**< Fahrzeuggeschwindigkeit [m/s] */
									IN	const	real32_T			 acceleration,				/**< Beschleunigung [m/s�] */
									IN	const	real32_T			 curvature,					/**< Bahnkr�mmung [1/m] */
									IN	const	real32_T			 slope,						/**< Fahrbahnsteigung [1/1] */
									IN	const	real32_T			 resistanceDeviation,		/**< Zugkraftabweichung [N] */
									OUT			real32_T			*wheelPower					/**< Radleistung [W] */
									);


/**	\brief	Gibt den Anpassfaktor f�r zul�ssige Querbeschleunigungen zur�ck, der im Fahrzeugmodell hinterlegt ist 

\spec SwMS_Innodrive2_Model_81
*/
void			 vmdlGetCurveFactor(IN	const	vehicleModel_T		*vehicleModel,				/**< interne Datenstruktur des Fahrzeugmodells */
									OUT			real32_T			*factor						/**< Anpassfaktor f�r zul�ssige Querbeschleunigungen [1/1] */
									);


/** \brief	Berechnet aus dem Moment von VKM, prim�rer und sekund�rer E-Maschine ein virtuelles Gesamtantriebsmoment 

\spec SwMS_Innodrive2_Model_82
*/
bool_T			 vmdlGetTotalTorque(IN	const	vehicleModel_T		*vehicleModel,				/**< interne Datenstruktur des Fahrzeugmodells */
									IN	const	real32_T			 sumTorque,					/**< Vom Motor gemeldetes Summenmoment aus VKM und EM1 [Nm] */
									IN	const	real32_T			 eTorquePrimary,			/**< Antriebsmoment der E-Maschine 1 [Nm] */
									IN	const	real32_T			 eTorqueSecondary,			/**< Antriebsmoment der E-Maschine 2 [Nm] */
									IN	const	gear_T				 gear,						/**< eingelegter Gang */
									OUT			real32_T			*torque						/**< �quivalentes Gesamtantriebsmoment [Nm] */
									);


/**	\brief	Berechnet eine maximal zul�ssige Beschleunigung a_max, die maximal zul�ssig ist damit die Radleistung �wheelPower� nicht �berschritten wird.
			Alle eingesetzten Gleichungen basieren auf den Bewegungsgleichungen aus dem driverPredictor und aus der Radleistungsberechnung aus dem vehicleModel.
			Die hergeleitete Gleichung f�hrt auf eine Ungleichung 3. grades, die mit dem Newton-Verfahren berechnet wird. Dazu werden pro Aufruf zwei Newton-Schritte
			berechnet, welche zum einen eine recht hohe Genauigkeit und zum anderen eine gute Laufzeit erreichen.


\spec SwMS_Innodrive2_Model_83
*/
bool_T	vmdlGetMaxAccelerationForWheelPower(IN	const	vehicleModel_T		*vehicleModel,				/**< Fahrzeugmodell */
											IN	const	real32_T			 maxWheelPower,				/**< maximal zul�ssige Radleistung [W] */
											IN	const	real32_T			 curvature,					/**< Bahnkr�mmung [1/m] */
											IN	const	real32_T			 slope,						/**< Steigung [1/1] */
											IN	const	real32_T			 resistanceDeviation,		/**< Fahrwiderstand [N?] */
											IN	const	real32_T			 currentVelocity,			/**< aktuelle Geschwingigkeit [m/s] */
											IN	const	real32_T			 currentAcceleration,		/**< aktuelle Beschleunigung [m/s^2] */
											IN	const	real32_T			 deltaT,					/**< Zeitschrittweite [s] */
											INOUT		real32_T			*maxAcceleration			/**< maximal ermittelte Beschleunigung [m/s�] */
											);


/**\brief Gibt `valid = true` aus, wenn der `motorCode` in der Liste erlaubter Motorcodes f�r dieses Fahrzeugmodell abgelegt ist.
Ist keine Liste hinterlegt (`count = 0`), wird jeder beliebige `motorCode` als g�ltig ausgewertet.


\spec SwMS_Innodrive2_Model_51
*/
void				   vmdlIsMotorCodeValid(IN	const	vehicleModel_T		*vehicleModel,				/**< Fahrzeugmodell */
											IN	const	uint8_T				 motorCode,					/**< Motorcode*/
											OUT			bool_T				*valid						/**< true, wenn der Motorcode erlaubt ist.*/
											);	

#endif
