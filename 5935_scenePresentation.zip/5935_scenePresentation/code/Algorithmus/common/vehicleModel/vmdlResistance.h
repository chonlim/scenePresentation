#ifndef guard_vmdlResistance_h
#define guard_vmdlResistance_h

#include "common/vehicleObserverCommon/vehicleObserver_interface.h"

typedef struct resistanceFactors_tag resistanceFactors_T;


/** \brief	Berechnet die Fahrwiderstandskraft, die sich aus den gegebenen Fahrzeug- und Umgebungsbedingungen ergibt */
void		  vmdlResGetResistanceForce(IN	const	resistanceModel_T		*resistance,			/**< interne Datenstruktur des Fahrwiderstandsmodells */
										IN	const	singleTrackModel_T		*singleTrack,			/**< interne Datenstruktur des Einspurmodells */
										IN	const	resistanceFactors_T		*factors,				/**< interne Datenstruktur der Fahrwiderstandsfaktoren */
										IN	const	real32_T				 deviation,				/**< Zugkraftabweichung [N] */
										OUT			real32_T				*resForce				/**< Fahrwiderstandskraft [N] */
										);


/** \brief	Berechnet die Fahrwiderstandskraft, die sich aus den gegebenen Fahrzeug- und Umgebungsbedingungen f�r offenen und geschlossenen Triebstrang ergeben. */
void		 vmdlResGetResistanceForces(IN	const	resistanceModel_T		*resistance,			/**< interne Datenstruktur des Fahrwiderstandsmodells */
										IN	const	singleTrackModel_T		*singleTrack,			/**< interne Datenstruktur des Einspurmodells */
										IN	const	resistanceFactors_T		*factors,				/**< interne Datenstruktur der Fahrwiderstandsfaktoren */
										IN	const	deviationState_T		*deviationState,		/**< Datenstruktur der Zugkraftfehlersch�tzung */
										OUT			real32_T				*resForceOn,			/**< Fahrwiderstand bei geschlossenem Triebstrang */
										OUT			real32_T				*resForceOff			/**< Fahrwiderstand bei offenem Triebstrang */
										);


/** \brief	Erstellt die resistanceFactors-Struktur zur Beschreibung der Fahrwiderstandseinfl�sse */
void		vmdlResGetResistanceFactors(IN	const	real32_T				 velocity,				/**< Fahrzeuggeschwindigkeit [m/s] */
										IN	const	real32_T				 curvature,				/**< Bahnkr�mmung [1/m] */
										IN	const	real32_T				 slope,					/**< Steigung [1/1] */
										OUT			resistanceFactors_T		*factors				/**< interne Datenstruktur der Fahrwiderstandsfaktoren */
										);


/** \brief	Rechnet eine effektive Zugkraft in eine Fahrzeugbeschleunigung um */
void			 vmdlResGetAcceleration(IN	const	resistanceModel_T		*resistance,			/**< interne Datenstruktur des Fahrwiderstandsmodells */
										IN	const	simpleOffset_T			 offset,				/**< Fahrwiderstandsoffset f�r den Zugriff auf das simplePower-Offset */
										IN	const	real32_T				 force,					/**< effektive Zugkraft [N] */
										OUT			real32_T				*acceleration			/**< Fahrzeugbeschleunigung [m/s�] */
										);


/** \brief	Berechnet aus einer Beschleunigung die notwendige effektive Zugkraft */
void					vmdlResGetForce(IN	const	resistanceModel_T		*resistance,			/**< interne Datenstruktur des Fahrwiderstandsmodells */
										IN	const	simpleOffset_T			 offset,				/**< Fahrwiderstandsoffset f�r den Zugriff auf das simplePower-Offset */
										IN	const	real32_T				 acceleration,			/**< Fahrzeugbeschleunigung [m/s�] */
										OUT			real32_T				*force					/**< erforderliche Zugkraft [N] */
										);


/**	\brief	Berechnet eine maximal zul�ssige Beschleunigung a_max, die maximal zul�ssig ist damit die Radleistung �wheelPower� nicht �berschritten wird.
			Alle eingesetzten Gleichungen basieren auf den Bewegungsgleichungen aus dem driverPredictor und aus der Radleistungsberechnung aus dem vehicleModel.
			Die hergeleitete Gleichung f�hrt auf eine Ungleichung 3. grades, die mit dem Newton-Verfahren berechnet wird. Dazu werden pro Aufruf zwei Newton-Schritte
			berechnet, welche zum einen eine recht hohe Genauigkeit und zum anderen eine gute Laufzeit erreichen.
*/
bool_T	vmdlResGetMaxAccelerationForWheelPower(IN	const	vehicleModel_T		*vehicleModel,				/**< Fahrzeugmodell */
											IN	const	real32_T			 maxWheelPower,				/**< maximal zul�ssige Radleistung [W] */
											IN	const	real32_T			 curvature,					/**< Bahnkr�mmung [1/m] */
											IN	const	real32_T			 slope,						/**< Steigung [1/1] */
											IN	const	real32_T			 resistanceDeviation,		/**< Fahrwiderstand [N?] */
											IN	const	real32_T			 currentVelocity,			/**< aktuelle Geschwingigkeit [m/s] */
											IN	const	real32_T			 currentAcceleration,		/**< aktuelle Beschleunigung [m/s^2] */
											IN	const	real32_T			 deltaT,					/**< Zeitschrittweite [s] */
											INOUT		real32_T			*maxAcceleration			/**< maximal ermittelte Beschleunigung [m/s�] */
											);

#endif
