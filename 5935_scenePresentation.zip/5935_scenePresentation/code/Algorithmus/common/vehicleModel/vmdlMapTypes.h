#ifndef guard_vmdlMapTypes_h
#define guard_vmdlMapTypes_h



typedef struct axisPreSel_tag {
	const mapAxis_T	*axis;
	const uint8_T	*dataPtr;
	real32_T		 invStep;
	uint16_T			 count;
} axisPreSel_T;


typedef struct mapPreSel_tag {
	axisPreSel_T	axis[2];
	real32_T		factor[2];
} mapPreSel_T;


#endif
