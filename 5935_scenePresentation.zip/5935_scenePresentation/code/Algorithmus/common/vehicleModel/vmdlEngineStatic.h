#ifndef guard_vmdlEngineStatic_h
#define guard_vmdlEngineStatic_h


static bool_T	 vmdlEngGetThrustTorque(IN	const	engineModel_T			*engine,
										IN	const	real32_T				 omega,
										OUT			real32_T				*torque
										);


#endif
