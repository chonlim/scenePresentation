#include "common/common.h"
#include "vehicleModel_private.h"
#include "vmdlEngine.h"
#include "vmdlEngineStatic.h"
#include "vmdlMap.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vmdlEngine)


bool_T				vmdlEngGetMaxTorque(IN	const	engineModel_T			*engine,
										IN	const	real32_T				 omega,
										OUT			real32_T				*maxTorque)
{
	real32_T invStep;
	uint16_T index;
	real32_T offset;


	/* Interpolation auf der Drehzahl-Achse */
	diagFF(vmdlMapGetInvStep(&engine->consumptionMap.omega,
							  engine->consumptionMap.numOmega,
							 &invStep));

	diagFF(vmdlMapInterpolateAxis(&engine->consumptionMap.omega,
								   invStep,
								   engine->consumptionMap.numOmega,
								   omega,
								  &index,
								  &offset));

	diagFF(index + 1u < engine->consumptionMap.numOmega);


	/* Ausgabe */
	*maxTorque = engine->consumptionMap.torque[index].max   * (1.0f - offset)
			   + engine->consumptionMap.torque[index+1u].max * (offset);


	return true;
}


void				vmdlEngApplyReserve(IN	const	engineModel_T			*engine,
										IN	const	real32_T				 maxTorque,
										OUT			real32_T				*limitTorque)
{
	*limitTorque = (maxTorque * engine->torqueReserve.factor) - engine->torqueReserve.absolute;
}


bool_T				    vmdlEngGetPower(IN	const	engineModel_T			*engine,
										IN	const	real32_T				 omega,
										IN	const	real32_T				 torque,
										OUT			real32_T				*fuelPower)
{
	real32_T scaled;
	real32_T mapPower;
	real32_T thrustTorque;

	/* Verbrauchskennfeld abfragen */
	diagFF(vmdlMapInterpolate(&engine->consumptionMap.omega,
							   engine->consumptionMap.torque,
							   engine->consumptionMap.numOmega,
							   engine->consumptionMap.numTorque,
							   omega,
							   torque,
							   engine->consumptionMap.power.data,
							  &scaled));

	mapPower = engine->consumptionMap.power.min + (scaled * engine->consumptionMap.power.factor);


	/* Schleppmoment abfragen */
	diagFF(vmdlEngGetThrustTorque( engine,
								   omega,
								  &thrustTorque));


	/* Unterhalb des Schleppmoments wird mit der Schubleistung gerechnet, ansonsten mit der Zugleistung */
	*fuelPower = (torque <= thrustTorque && omega >= engine->cutoffMinOmega) ? engine->thrustPower : mapPower;


	return true;
}


static bool_T	 vmdlEngGetThrustTorque(IN	const	engineModel_T			*engine,
										IN	const	real32_T				 omega,
										OUT			real32_T				*torque)
{
	real32_T scaled;

	/* Abfragen der Kennlinie */
	diagFF(vmdlMapLineInterp(&engine->thrustLine.omega,
							  engine->thrustLine.numOmega,
							  omega,
							  engine->thrustLine.torque.data,
							 &scaled));

	*torque = engine->thrustLine.torque.min + (scaled * engine->thrustLine.torque.factor);


	return true;
}


bool_T		 vmdlEngGetMinRefTorque(IN	const	engineModel_T			*engine,
									IN	const	real32_T				 omega,
									OUT			real32_T				*minRefTorque)
{
	real32_T scaled;

	/* Abfragen der Kennlinie */
	diagFF(vmdlMapLineInterp(&engine->minRefTorque.omega,
							  engine->minRefTorque.numOmega,
							  omega,
							  engine->minRefTorque.torque.data,
							 &scaled));

	*minRefTorque = engine->minRefTorque.torque.min + (scaled * engine->minRefTorque.torque.factor);


	return true;
}


bool_T		vmdlEngGetMaxTorqueRate(IN	const	engineModel_T			*engine,
									IN	const	real32_T				 omega,
									OUT			real32_T				*maxTorqueRate)
{
	real32_T scaled;

	/* Abfragen der Kennlinie */
	diagFF(vmdlMapLineInterp(&engine->torqueRate.omega,
							  engine->torqueRate.numOmega,
							  omega,
							  engine->torqueRate.rate.data,
							 &scaled));

	*maxTorqueRate = engine->torqueRate.rate.min + (scaled * engine->torqueRate.rate.factor);


	return true;
}

