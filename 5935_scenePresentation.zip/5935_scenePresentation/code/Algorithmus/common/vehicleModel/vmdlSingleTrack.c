#include "common/common.h"
#include "vehicleModel_private.h"
#include "vmdlSingleTrack.h"


void			  vmdlSgTrGetCurveForce(IN	const	singleTrackModel_T		*singleTrack,
										IN	const	real32_T				 forceY,
										OUT			real32_T				*curveForce)
{
	real32_T forceX;

	forceX = (forceY * singleTrack->mass)
		   * (  ((singleTrack->lengthRear  / singleTrack->length) * (singleTrack->cR * forceY))
		      + ((singleTrack->lengthFront / singleTrack->length) * (singleTrack->cF * forceY)));

	*curveForce = forceX;

	/* Wir rechnen hier nur Schrott! */
	*curveForce = 0.0f;
}


bool_T		   vmdlSgTrWheelToCurvature(IN	const	singleTrackModel_T		*singleTrack,
										IN	const	real32_T				 velocity,
										IN	const	real32_T				 wheelAngle,
										IN	const	real32_T				 rearAngle,
										IN	const	bool_T					 rasPresent,
										OUT			real32_T				*curvature)
{
	real32_T	a11;
	real32_T	a12;
	real32_T	b11;
	real32_T	b12;
	real32_T	a21;
	real32_T	a22;
	real32_T	b21;
	real32_T	b22;

	real32_T	adjVelocity = max(velocity, 0.1f);

	real32_T	steeringRatio;
	real32_T	eg;

	a11 = (singleTrack->cR * singleTrack->lengthRear / adjVelocity) - ((singleTrack->cF *singleTrack->lengthFront / adjVelocity) + (singleTrack->mass * adjVelocity));
	a12 = singleTrack->cR + singleTrack->cF;
	b11 = singleTrack->cF;
	b12 = singleTrack->cR;
	a21 = (singleTrack->cF * singleTrack->lengthFront * singleTrack->lengthFront / adjVelocity) + (singleTrack->cR * singleTrack->lengthRear * singleTrack->lengthRear / adjVelocity);
	a22 = (singleTrack->cR *singleTrack->lengthRear) - (singleTrack->cF * singleTrack->lengthFront);
	b21 = -singleTrack->lengthFront * singleTrack->cF;
	b22 =  singleTrack->lengthRear * singleTrack->cR;

	eg				= (rasPresent) ? singleTrack->egRAS : singleTrack->eg;
	steeringRatio	= (rasPresent) ? singleTrack->steeringRatioRAS : singleTrack->steeringRatio;

	if(eg != 0.0f) {
		*curvature	= (wheelAngle / steeringRatio)
					/ (singleTrack->length + (velocity*velocity) * eg);
	}
	else {
		*curvature = ((wheelAngle / steeringRatio) * (b21*a12/a22-b11) + rearAngle * (b22*a12/a22-b12)) 
					 / ((a11-a21*a12/a22) * adjVelocity);
	}

	return true;
}
