#ifndef guard_vmdlSimpleTypes_h
#define guard_vmdlSimpleTypes_h

#include "vmdlMapTypes.h"


typedef struct simplePowerPreSel_tag {
	mapPreSel_T		map;
	simpleOffset_T	offset;
} simplePowerPreSel_T;


#endif
