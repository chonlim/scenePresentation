#ifndef __vehicleModeladtfProp_h_
#define __vehicleModeladtfProp_h_

#include <stdio.h>
#include <string.h>
#include "Algorithmus/common/vehicleModel/vehicleModel_private.h"

/*lint -save */
/*lint -e10 	"Expecting 'String'  -- String is the expected token" */
/*lint -e40 	"Undeclared identifier 'Name'*/
/*lint -e49 	"Expected a type  -- Only types are allowed within prototypes */ 
/*lint -e63 	"Expected an lvalue  -- Assignment expects its first operand to be an lvalue (sprintf) */ 
/*lint -e64 	"Type mismatch (Context) (TypeDiff) (sprintf) */
/*lint -e91 	"Line exceeds Integer characters (use +linebuf) */
/*lint -e119	"Too many arguments for prototype (callback function) */
/*lint -e129	"declaration expected, identifier 'Symbol' ignored (callback function) */
/*lint -e132	"Expected function definition */
/*lint -e402	"static function 'Symbol' (Location) not defined */
/*lint -e409	"Expecting a pointer or array (callback function) */
/*lint -e506	"Constant value Boolean (param Schleifenz�hler = min( 4, MAX_LOOPCNT))*/
/*lint -e516	"arg. type conflict */
/*lint -e522	"Expected void type, assignment, increment or decrement (bool_T)*/
/*lint -e525	"Negative indentation from Location*/
/*lint -e534	"Ignoring return value of function 'Symbol' (sprintf)*/
/*lint -e562	"variable 'Symbol' depends on order of evaluation*/
/*lint -e746	"call to function 'Name' not made in the presence of a prototype */ 
/*lint -e774	"Boolean within 'if' always evaluates to True  */ 
/*lint -e808	"No explicit type given symbol 'Symbol' given, assumed int (char_T) */ 
/*lint -e830	"Location cited in prior message*/
/*lint -e912	"Implicit binary conversion from Type to Type min() */
/*lint -e917	"Prototype coercion (Context) Type to Type*/
/*lint -e918	"Prototype coercion (Context) of pointers*/
/*lint -e960	"Violates MISRA Required Rule Name, String*/

#define MAX_PROPERTY   1024
#define MAX_LOOPCNT    10

#include "base.h"

/*------------------------------Start Get/SetPropertyBool Sektion--------------------------------*/



static bool_T busProp_gearValues_int32_T( gearValues_T *gearValues, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T *strFriendlyName, int32_T iValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_gearValues_real64_T( gearValues_T *gearValues, real64_T(cbFunc(const void *pThisPtr, const char_T *strProperty, const char_T *strFriendlyName, real64_T fValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_gearValues_bool_T( gearValues_T *gearValues, bool_T(cbFunc(const void *pThisPtr, const char_T *strProperty, const char_T *strFriendlyName, bool_T fValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_mapAxis_bool_T (mapAxis_T *mapAxis, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_resistanceModel_bool_T (resistanceModel_T *resistanceModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_singleTrackModel_bool_T (singleTrackModel_T *singleTrackModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dragMap_bool_T (dragMap_T *dragMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_gearBoxModel_bool_T (gearBoxModel_T *gearBoxModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_thrustLine_bool_T (thrustLine_T *thrustLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_rateLine_bool_T (rateLine_T *rateLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_minRefLine_bool_T (minRefLine_T *minRefLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_consumptionMap_bool_T (consumptionMap_T *consumptionMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_engineModel_bool_T (engineModel_T *engineModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_simplePowerMap_bool_T (simplePowerMap_T *simplePowerMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_simpleModel_bool_T (simpleModel_T *simpleModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_miscModel_bool_T (miscModel_T *miscModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_vehicleModel_bool_T (vehicleModel_T *vehicleModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );


/*! \brief busPropArray_dragMaptorque_bool_T (mapAxis_T *torque, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlTORQUECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_dragMaptorque_bool_T) */ 
static bool_T busPropArray_dragMaptorque_bool_T (mapAxis_T *torque, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlTORQUECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_bool_T (&torque[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_gearBoxModelgear_bool_T (_gearBoxModel::_gearBoxModel_gear *gearBoxModel, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( gearEOF, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_gearBoxModelgear_bool_T) */ 
static bool_T busPropArray_gearBoxModelgear_bool_T (_gearBoxModel::_gearBoxModel_gear *gearBoxModel, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( gearEOF, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]::%sdragMap", strBaseProperty, i, ""); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; busProp_dragMap_bool_T ( &gearBoxModel[i].dragMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );} };
	}
	return bRet;
}


/*! \brief busPropArray_consumptionMaptorque_bool_T (mapAxis_T *torque, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlCONSTORQUECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_consumptionMaptorque_bool_T) */ 
static bool_T busPropArray_consumptionMaptorque_bool_T (mapAxis_T *torque, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlCONSTORQUECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_bool_T (&torque[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_simplePowerMapforce_bool_T (mapAxis_T *force, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlSIMPLEFORCECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_simplePowerMapforce_bool_T) */ 
static bool_T busPropArray_simplePowerMapforce_bool_T (mapAxis_T *force, bool_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, bool_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlSIMPLEFORCECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_bool_T (&force[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_gearValues_int32_T() */ 
/*lint --e{528} suppress f() not referencedbusProp_gearValues_int32_T( gearValues_T *gearValues, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T *strFriendlyName, int32_T iValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_gearValues_int32_T( gearValues_T *gearValues, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T *strFriendlyName, int32_T iValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_gearValues_real64_T() */ 
/*lint --e{528} suppress f() not referencedbusProp_gearValues_real64_T( gearValues_T *gearValues, real64_T(cbFunc(const void *pThisPtr, const char_T *strProperty, const char_T *strFriendlyName, real64_T fValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_gearValues_real64_T( gearValues_T *gearValues, real64_T(cbFunc(const void *pThisPtr, const char_T *strProperty, const char_T *strFriendlyName, real64_T fValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_gearValues_bool_T() */ 
/*lint --e{528} suppress f() not referencedbusProp_gearValues_bool_T( gearValues_T *gearValues, bool_T(cbFunc(const void *pThisPtr, const char_T *strProperty, const char_T *strFriendlyName, bool_T fValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_gearValues_bool_T( gearValues_T *gearValues, bool_T(cbFunc(const void *pThisPtr, const char_T *strProperty, const char_T *strFriendlyName, bool_T fValue)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_mapAxis_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_mapAxis_bool_T (mapAxis_T *mapAxis, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_mapAxis_bool_T (mapAxis_T *mapAxis, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_resistanceModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_resistanceModel_bool_T (resistanceModel_T *resistanceModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_resistanceModel_bool_T (resistanceModel_T *resistanceModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_singleTrackModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_singleTrackModel_bool_T (singleTrackModel_T *singleTrackModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_singleTrackModel_bool_T (singleTrackModel_T *singleTrackModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dragMap_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dragMap_bool_T (dragMap_T *dragMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dragMap_bool_T (dragMap_T *dragMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_bool_T ( &dragMap->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque");busPropArray_dragMaptorque_bool_T (&dragMap->torque[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_gearBoxModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_gearBoxModel_bool_T (gearBoxModel_T *gearBoxModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_gearBoxModel_bool_T (gearBoxModel_T *gearBoxModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "requestAllowed");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->requestAllowed = (bool_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->requestAllowed));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "useSumTorque");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->useSumTorque = (bool_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->useSumTorque));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coasting::possible");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->coasting.possible = (bool_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->coasting.possible));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gear");bRet = busPropArray_gearBoxModelgear_bool_T (&gearBoxModel->gear[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged );};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_thrustLine_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_thrustLine_bool_T (thrustLine_T *thrustLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_thrustLine_bool_T (thrustLine_T *thrustLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_bool_T ( &thrustLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_rateLine_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_rateLine_bool_T (rateLine_T *rateLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_rateLine_bool_T (rateLine_T *rateLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_bool_T ( &rateLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_minRefLine_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_minRefLine_bool_T (minRefLine_T *minRefLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_minRefLine_bool_T (minRefLine_T *minRefLine, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_bool_T ( &minRefLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_consumptionMap_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_consumptionMap_bool_T (consumptionMap_T *consumptionMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_consumptionMap_bool_T (consumptionMap_T *consumptionMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_bool_T ( &consumptionMap->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque");busPropArray_consumptionMaptorque_bool_T (&consumptionMap->torque[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_engineModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_engineModel_bool_T (engineModel_T *engineModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_engineModel_bool_T (engineModel_T *engineModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "thrustLine");busProp_thrustLine_bool_T ( &engineModel->thrustLine, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torqueRate");busProp_rateLine_bool_T ( &engineModel->torqueRate, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "minRefTorque");busProp_minRefLine_bool_T ( &engineModel->minRefTorque, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "consumptionMap");busProp_consumptionMap_bool_T ( &engineModel->consumptionMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_simplePowerMap_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_simplePowerMap_bool_T (simplePowerMap_T *simplePowerMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_simplePowerMap_bool_T (simplePowerMap_T *simplePowerMap, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "velocity");busProp_mapAxis_bool_T ( &simplePowerMap->velocity, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "force");busPropArray_simplePowerMapforce_bool_T (&simplePowerMap->force[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_simpleModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_simpleModel_bool_T (simpleModel_T *simpleModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_simpleModel_bool_T (simpleModel_T *simpleModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "powerMap");busProp_simplePowerMap_bool_T ( &simpleModel->powerMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_miscModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_miscModel_bool_T (miscModel_T *miscModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_miscModel_bool_T (miscModel_T *miscModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_vehicleModel_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_vehicleModel_bool_T (vehicleModel_T *vehicleModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_vehicleModel_bool_T (vehicleModel_T *vehicleModel, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "valid");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; vehicleModel->valid = (bool_T)(cbFunc(pFilterObject, strProperty, strName, vehicleModel->valid));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "resistance");busProp_resistanceModel_bool_T ( &vehicleModel->resistance, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "singleTrack");busProp_singleTrackModel_bool_T ( &vehicleModel->singleTrack, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gearBox");busProp_gearBoxModel_bool_T ( &vehicleModel->gearBox, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "engine");busProp_engineModel_bool_T ( &vehicleModel->engine, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "simple");busProp_simpleModel_bool_T ( &vehicleModel->simple, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "misc");busProp_miscModel_bool_T ( &vehicleModel->misc, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*------------------------------Ende Get/SetPropertyBool Sektion--------------------------------*/

/*------------------------------Start Get/SetPropertyInt Sektion--------------------------------*/



static bool_T busProp_mapAxis_int32_T (mapAxis_T *mapAxis, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_resistanceModel_int32_T (resistanceModel_T *resistanceModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_singleTrackModel_int32_T (singleTrackModel_T *singleTrackModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dragMap_int32_T (dragMap_T *dragMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_gearBoxModel_int32_T (gearBoxModel_T *gearBoxModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_thrustLine_int32_T (thrustLine_T *thrustLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_rateLine_int32_T (rateLine_T *rateLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_minRefLine_int32_T (minRefLine_T *minRefLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_consumptionMap_int32_T (consumptionMap_T *consumptionMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_engineModel_int32_T (engineModel_T *engineModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_simplePowerMap_int32_T (simplePowerMap_T *simplePowerMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_simpleModel_int32_T (simpleModel_T *simpleModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_miscModel_int32_T (miscModel_T *miscModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_vehicleModel_int32_T (vehicleModel_T *vehicleModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );


/*! \brief busPropArray_dragMaptorque_int32_T (mapAxis_T *torque, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlTORQUECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_dragMaptorque_int32_T) */ 
static bool_T busPropArray_dragMaptorque_int32_T (mapAxis_T *torque, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlTORQUECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_int32_T (&torque[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_dragMapdragdata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlDRAGCOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_dragMapdragdata_int32_T) */ 
static bool_T busPropArray_dragMapdragdata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlDRAGCOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*! \brief busPropArray_gearBoxModelgear_int32_T (_gearBoxModel::_gearBoxModel_gear *gearBoxModel, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( gearEOF, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_gearBoxModelgear_int32_T) */ 
static bool_T busPropArray_gearBoxModelgear_int32_T (_gearBoxModel::_gearBoxModel_gear *gearBoxModel, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( gearEOF, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]::%sdragMap", strBaseProperty, i, ""); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; busProp_dragMap_int32_T ( &gearBoxModel[i].dragMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );} };
	}
	return bRet;
}


/*! \brief busPropArray_thrustLinetorquedata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlTHRUSTTORQUECOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_thrustLinetorquedata_int32_T) */ 
static bool_T busPropArray_thrustLinetorquedata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlTHRUSTTORQUECOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*! \brief busPropArray_rateLineratedata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlTORQUERATECOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_rateLineratedata_int32_T) */ 
static bool_T busPropArray_rateLineratedata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlTORQUERATECOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*! \brief busPropArray_minRefLinetorquedata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlREFTORQUECOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_minRefLinetorquedata_int32_T) */ 
static bool_T busPropArray_minRefLinetorquedata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlREFTORQUECOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*! \brief busPropArray_consumptionMaptorque_int32_T (mapAxis_T *torque, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlCONSTORQUECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_consumptionMaptorque_int32_T) */ 
static bool_T busPropArray_consumptionMaptorque_int32_T (mapAxis_T *torque, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlCONSTORQUECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_int32_T (&torque[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_consumptionMappowerdata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlCONSPOWERCOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_consumptionMappowerdata_int32_T) */ 
static bool_T busPropArray_consumptionMappowerdata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlCONSPOWERCOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*! \brief busPropArray_simplePowerMapforce_int32_T (mapAxis_T *force, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlSIMPLEFORCECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_simplePowerMapforce_int32_T) */ 
static bool_T busPropArray_simplePowerMapforce_int32_T (mapAxis_T *force, int32_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, int32_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlSIMPLEFORCECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_int32_T (&force[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_simplePowerMappowerdata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlSIMPLEPOWERCOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_simplePowerMappowerdata_int32_T) */ 
static bool_T busPropArray_simplePowerMappowerdata_int32_T (uint8_T *data, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlSIMPLEPOWERCOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*! \brief busPropArray_miscModelcodeListcode_int32_T (uint8_T *code, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlCODECOUNT, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_miscModelcodeListcode_int32_T) */ 
static bool_T busPropArray_miscModelcodeListcode_int32_T (uint8_T *code, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlCODECOUNT, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; code[i] = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, code[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_mapAxis_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_mapAxis_int32_T (mapAxis_T *mapAxis, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_mapAxis_int32_T (mapAxis_T *mapAxis, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_resistanceModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_resistanceModel_int32_T (resistanceModel_T *resistanceModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_resistanceModel_int32_T (resistanceModel_T *resistanceModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_singleTrackModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_singleTrackModel_int32_T (singleTrackModel_T *singleTrackModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_singleTrackModel_int32_T (singleTrackModel_T *singleTrackModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dragMap_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dragMap_int32_T (dragMap_T *dragMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dragMap_int32_T (dragMap_T *dragMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dragMap->numOmega = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, dragMap->numOmega));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numTorque");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dragMap->numTorque = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, dragMap->numTorque));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_int32_T ( &dragMap->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque");busPropArray_dragMaptorque_int32_T (&dragMap->torque[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "drag::data");bRet = busPropArray_dragMapdragdata_int32_T (&dragMap->drag.data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_gearBoxModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_gearBoxModel_int32_T (gearBoxModel_T *gearBoxModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_gearBoxModel_int32_T (gearBoxModel_T *gearBoxModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numGears");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->numGears = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->numGears));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gear");bRet = busPropArray_gearBoxModelgear_int32_T (&gearBoxModel->gear[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged );};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_thrustLine_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_thrustLine_int32_T (thrustLine_T *thrustLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_thrustLine_int32_T (thrustLine_T *thrustLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; thrustLine->numOmega = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, thrustLine->numOmega));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_int32_T ( &thrustLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque::data");bRet = busPropArray_thrustLinetorquedata_int32_T (&thrustLine->torque.data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_rateLine_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_rateLine_int32_T (rateLine_T *rateLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_rateLine_int32_T (rateLine_T *rateLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; rateLine->numOmega = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, rateLine->numOmega));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_int32_T ( &rateLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "rate::data");bRet = busPropArray_rateLineratedata_int32_T (&rateLine->rate.data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_minRefLine_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_minRefLine_int32_T (minRefLine_T *minRefLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_minRefLine_int32_T (minRefLine_T *minRefLine, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; minRefLine->numOmega = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, minRefLine->numOmega));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_int32_T ( &minRefLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque::data");bRet = busPropArray_minRefLinetorquedata_int32_T (&minRefLine->torque.data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_consumptionMap_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_consumptionMap_int32_T (consumptionMap_T *consumptionMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_consumptionMap_int32_T (consumptionMap_T *consumptionMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; consumptionMap->numOmega = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, consumptionMap->numOmega));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numTorque");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; consumptionMap->numTorque = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, consumptionMap->numTorque));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_int32_T ( &consumptionMap->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque");busPropArray_consumptionMaptorque_int32_T (&consumptionMap->torque[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "power::data");bRet = busPropArray_consumptionMappowerdata_int32_T (&consumptionMap->power.data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_engineModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_engineModel_int32_T (engineModel_T *engineModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_engineModel_int32_T (engineModel_T *engineModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "thrustLine");busProp_thrustLine_int32_T ( &engineModel->thrustLine, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torqueRate");busProp_rateLine_int32_T ( &engineModel->torqueRate, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "minRefTorque");busProp_minRefLine_int32_T ( &engineModel->minRefTorque, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "consumptionMap");busProp_consumptionMap_int32_T ( &engineModel->consumptionMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_simplePowerMap_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_simplePowerMap_int32_T (simplePowerMap_T *simplePowerMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_simplePowerMap_int32_T (simplePowerMap_T *simplePowerMap, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numVelocity");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; simplePowerMap->numVelocity = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, simplePowerMap->numVelocity));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "numForce");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; simplePowerMap->numForce = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, simplePowerMap->numForce));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "velocity");busProp_mapAxis_int32_T ( &simplePowerMap->velocity, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "force");busPropArray_simplePowerMapforce_int32_T (&simplePowerMap->force[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "power::data");bRet = busPropArray_simplePowerMappowerdata_int32_T (&simplePowerMap->power.data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_simpleModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_simpleModel_int32_T (simpleModel_T *simpleModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_simpleModel_int32_T (simpleModel_T *simpleModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "powerMap");busProp_simplePowerMap_int32_T ( &simpleModel->powerMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_miscModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_miscModel_int32_T (miscModel_T *miscModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_miscModel_int32_T (miscModel_T *miscModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "codeList::code");bRet = busPropArray_miscModelcodeListcode_int32_T (&miscModel->codeList.code[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "codeList::count");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; miscModel->codeList.count = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, miscModel->codeList.count));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_vehicleModel_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_vehicleModel_int32_T (vehicleModel_T *vehicleModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_vehicleModel_int32_T (vehicleModel_T *vehicleModel, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "checksumCrc32");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; vehicleModel->checksumCrc32 = (uint32_T)(cbFunc(pFilterObject, strProperty, strName, vehicleModel->checksumCrc32));}; strProperty[0] = 0;strName[0] = 0;};
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "resistance");busProp_resistanceModel_int32_T ( &vehicleModel->resistance, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "singleTrack");busProp_singleTrackModel_int32_T ( &vehicleModel->singleTrack, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gearBox");busProp_gearBoxModel_int32_T ( &vehicleModel->gearBox, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "engine");busProp_engineModel_int32_T ( &vehicleModel->engine, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "simple");busProp_simpleModel_int32_T ( &vehicleModel->simple, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "misc");busProp_miscModel_int32_T ( &vehicleModel->misc, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "bufferSize");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; vehicleModel->bufferSize = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, vehicleModel->bufferSize));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*------------------------------Ende Get/SetPropertyInt Sektion--------------------------------*/

/*------------------------------Start Get/SetPropertyFloat Sektion--------------------------------*/



static bool_T busProp_mapAxis_real64_T (mapAxis_T *mapAxis, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_resistanceModel_real64_T (resistanceModel_T *resistanceModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_singleTrackModel_real64_T (singleTrackModel_T *singleTrackModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dragMap_real64_T (dragMap_T *dragMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_gearBoxModel_real64_T (gearBoxModel_T *gearBoxModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_thrustLine_real64_T (thrustLine_T *thrustLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_rateLine_real64_T (rateLine_T *rateLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_minRefLine_real64_T (minRefLine_T *minRefLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_consumptionMap_real64_T (consumptionMap_T *consumptionMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_engineModel_real64_T (engineModel_T *engineModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_simplePowerMap_real64_T (simplePowerMap_T *simplePowerMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_simpleModel_real64_T (simpleModel_T *simpleModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_miscModel_real64_T (miscModel_T *miscModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_vehicleModel_real64_T (vehicleModel_T *vehicleModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );


/*! \brief busPropArray_dragMaptorque_real64_T (mapAxis_T *torque, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlTORQUECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_dragMaptorque_real64_T) */ 
static bool_T busPropArray_dragMaptorque_real64_T (mapAxis_T *torque, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlTORQUECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_real64_T (&torque[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_gearBoxModelgear_real64_T (_gearBoxModel::_gearBoxModel_gear *gearBoxModel, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( gearEOF, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_gearBoxModelgear_real64_T) */ 
static bool_T busPropArray_gearBoxModelgear_real64_T (_gearBoxModel::_gearBoxModel_gear *gearBoxModel, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( gearEOF, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]::%stransmissionRatio", strBaseProperty, i, ""); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel[i].transmissionRatio = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel[i].transmissionRatio));}; strProperty[0] = 0;};
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]::%sinvInertia", strBaseProperty, i, ""); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel[i].invInertia = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel[i].invInertia));}; strProperty[0] = 0;};
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]::%sdragMap", strBaseProperty, i, ""); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; busProp_dragMap_real64_T ( &gearBoxModel[i].dragMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );} };
	}
	return bRet;
}


/*! \brief busPropArray_consumptionMaptorque_real64_T (mapAxis_T *torque, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlCONSTORQUECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_consumptionMaptorque_real64_T) */ 
static bool_T busPropArray_consumptionMaptorque_real64_T (mapAxis_T *torque, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlCONSTORQUECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_real64_T (&torque[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*! \brief busPropArray_simplePowerMapforce_real64_T (mapAxis_T *force, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( vmdlSIMPLEFORCECOUNT, MAX_LOOPCNT )
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_simplePowerMapforce_real64_T) */ 
static bool_T busPropArray_simplePowerMapforce_real64_T (mapAxis_T *force, real64_T(cbFunc(const void* filterObj, const char_T* baseProp, const char_T* changedProp, real64_T)), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( vmdlSIMPLEFORCECOUNT, MAX_LOOPCNT ); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		busProp_mapAxis_real64_T (&force[i], cbFunc, pFilterObject, pstrBaseProperty, pstrPropertyChanged );
	}
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_mapAxis_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_mapAxis_real64_T (mapAxis_T *mapAxis, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_mapAxis_real64_T (mapAxis_T *mapAxis, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; mapAxis->min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, mapAxis->min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "max");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; mapAxis->max = (real32_T)(cbFunc(pFilterObject, strProperty, strName, mapAxis->max));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_resistanceModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_resistanceModel_real64_T (resistanceModel_T *resistanceModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_resistanceModel_real64_T (resistanceModel_T *resistanceModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "mass");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; resistanceModel->mass = (real32_T)(cbFunc(pFilterObject, strProperty, strName, resistanceModel->mass));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coastingCoefficients::a");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; resistanceModel->coastingCoefficients.a = (real32_T)(cbFunc(pFilterObject, strProperty, strName, resistanceModel->coastingCoefficients.a));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coastingCoefficients::b");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; resistanceModel->coastingCoefficients.b = (real32_T)(cbFunc(pFilterObject, strProperty, strName, resistanceModel->coastingCoefficients.b));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coastingCoefficients::c");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; resistanceModel->coastingCoefficients.c = (real32_T)(cbFunc(pFilterObject, strProperty, strName, resistanceModel->coastingCoefficients.c));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_singleTrackModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_singleTrackModel_real64_T (singleTrackModel_T *singleTrackModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_singleTrackModel_real64_T (singleTrackModel_T *singleTrackModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "mass");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->mass = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->mass));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "length");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->length = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->length));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "steeringRatio");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->steeringRatio = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->steeringRatio));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "steeringRatioRAS");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->steeringRatioRAS = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->steeringRatioRAS));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "eg");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->eg = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->eg));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "egRAS");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->egRAS = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->egRAS));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "lengthFront");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->lengthFront = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->lengthFront));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "lengthRear");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->lengthRear = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->lengthRear));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "cR");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->cR = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->cR));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "cF");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; singleTrackModel->cF = (real32_T)(cbFunc(pFilterObject, strProperty, strName, singleTrackModel->cF));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dragMap_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dragMap_real64_T (dragMap_T *dragMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dragMap_real64_T (dragMap_T *dragMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_real64_T ( &dragMap->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque");busPropArray_dragMaptorque_real64_T (&dragMap->torque[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "drag::min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dragMap->drag.min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dragMap->drag.min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "drag::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dragMap->drag.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dragMap->drag.factor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_gearBoxModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_gearBoxModel_real64_T (gearBoxModel_T *gearBoxModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_gearBoxModel_real64_T (gearBoxModel_T *gearBoxModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "requestOffset");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->requestOffset = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->requestOffset));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "iDiff");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->iDiff = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->iDiff));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "wheelRadius");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->wheelRadius = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->wheelRadius));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "auxDiff");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->auxDiff = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->auxDiff));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "auxRadius");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->auxRadius = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->auxRadius));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "minOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->minOmega = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->minOmega));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "maxOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->maxOmega = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->maxOmega));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coasting::minVelocity");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->coasting.minVelocity = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->coasting.minVelocity));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coasting::maxVelocity");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; gearBoxModel->coasting.maxVelocity = (real32_T)(cbFunc(pFilterObject, strProperty, strName, gearBoxModel->coasting.maxVelocity));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gear");bRet = busPropArray_gearBoxModelgear_real64_T (&gearBoxModel->gear[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged );};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_thrustLine_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_thrustLine_real64_T (thrustLine_T *thrustLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_thrustLine_real64_T (thrustLine_T *thrustLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_real64_T ( &thrustLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque::min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; thrustLine->torque.min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, thrustLine->torque.min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; thrustLine->torque.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, thrustLine->torque.factor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_rateLine_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_rateLine_real64_T (rateLine_T *rateLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_rateLine_real64_T (rateLine_T *rateLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_real64_T ( &rateLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "rate::min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; rateLine->rate.min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, rateLine->rate.min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "rate::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; rateLine->rate.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, rateLine->rate.factor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_minRefLine_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_minRefLine_real64_T (minRefLine_T *minRefLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_minRefLine_real64_T (minRefLine_T *minRefLine, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_real64_T ( &minRefLine->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque::min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; minRefLine->torque.min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, minRefLine->torque.min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; minRefLine->torque.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, minRefLine->torque.factor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_consumptionMap_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_consumptionMap_real64_T (consumptionMap_T *consumptionMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_consumptionMap_real64_T (consumptionMap_T *consumptionMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "omega");busProp_mapAxis_real64_T ( &consumptionMap->omega, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torque");busPropArray_consumptionMaptorque_real64_T (&consumptionMap->torque[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "power::min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; consumptionMap->power.min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, consumptionMap->power.min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "power::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; consumptionMap->power.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, consumptionMap->power.factor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_engineModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_engineModel_real64_T (engineModel_T *engineModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_engineModel_real64_T (engineModel_T *engineModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "thrustLine");busProp_thrustLine_real64_T ( &engineModel->thrustLine, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torqueRate");busProp_rateLine_real64_T ( &engineModel->torqueRate, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "minRefTorque");busProp_minRefLine_real64_T ( &engineModel->minRefTorque, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "consumptionMap");busProp_consumptionMap_real64_T ( &engineModel->consumptionMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torqueReserve::absolute");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; engineModel->torqueReserve.absolute = (real32_T)(cbFunc(pFilterObject, strProperty, strName, engineModel->torqueReserve.absolute));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torqueReserve::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; engineModel->torqueReserve.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, engineModel->torqueReserve.factor));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "thrustPower");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; engineModel->thrustPower = (real32_T)(cbFunc(pFilterObject, strProperty, strName, engineModel->thrustPower));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "cutoffMinOmega");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; engineModel->cutoffMinOmega = (real32_T)(cbFunc(pFilterObject, strProperty, strName, engineModel->cutoffMinOmega));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "ePowerAccelOffset");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; engineModel->ePowerAccelOffset = (real32_T)(cbFunc(pFilterObject, strProperty, strName, engineModel->ePowerAccelOffset));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_simplePowerMap_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_simplePowerMap_real64_T (simplePowerMap_T *simplePowerMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_simplePowerMap_real64_T (simplePowerMap_T *simplePowerMap, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "velocity");busProp_mapAxis_real64_T ( &simplePowerMap->velocity, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "force");busPropArray_simplePowerMapforce_real64_T (&simplePowerMap->force[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "power::min");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; simplePowerMap->power.min = (real32_T)(cbFunc(pFilterObject, strProperty, strName, simplePowerMap->power.min));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "power::factor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; simplePowerMap->power.factor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, simplePowerMap->power.factor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_simpleModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_simpleModel_real64_T (simpleModel_T *simpleModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_simpleModel_real64_T (simpleModel_T *simpleModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "powerMap");busProp_simplePowerMap_real64_T ( &simpleModel->powerMap, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "idlePower");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; simpleModel->idlePower = (real32_T)(cbFunc(pFilterObject, strProperty, strName, simpleModel->idlePower));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coastLimit");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; simpleModel->coastLimit = (real32_T)(cbFunc(pFilterObject, strProperty, strName, simpleModel->coastLimit));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_miscModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_miscModel_real64_T (miscModel_T *miscModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_miscModel_real64_T (miscModel_T *miscModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "curveFactor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; miscModel->curveFactor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, miscModel->curveFactor));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_vehicleModel_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_vehicleModel_real64_T (vehicleModel_T *vehicleModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_vehicleModel_real64_T (vehicleModel_T *vehicleModel, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "resistance");busProp_resistanceModel_real64_T ( &vehicleModel->resistance, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "singleTrack");busProp_singleTrackModel_real64_T ( &vehicleModel->singleTrack, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gearBox");busProp_gearBoxModel_real64_T ( &vehicleModel->gearBox, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "engine");busProp_engineModel_real64_T ( &vehicleModel->engine, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "simple");busProp_simpleModel_real64_T ( &vehicleModel->simple, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "misc");busProp_miscModel_real64_T ( &vehicleModel->misc, cbFunc, pFilterObject, strProperty, pstrPropertyChanged );
	return bRet;
}


/*------------------------------Ende Get/SetPropertyFloat Sektion--------------------------------*/


/*lint -restore */

#endif
