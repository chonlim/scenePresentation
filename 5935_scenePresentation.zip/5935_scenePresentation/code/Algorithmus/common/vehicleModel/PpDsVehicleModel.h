#ifndef guard_PpDsvehicleModel_h
#define guard_PpDsvehicleModel_h

#include "base.h"
#include "common/vehicleModel/vehicleModel_private.h"


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#include "FastProject/rteInterfaceCtrl/Rte_Type.h"
#else
#include "Rte_Type.h"
#endif


/*lint -save */
/*lint -e18	 "Error -- Symbol 'ccc' redeclared(origin, strong) conflicts with line aa, file xxx, module yyy[MISRA 2012 Rule 8.2, required])" */
#ifdef __cplusplus
extern "C" {
#endif

	bool_T rteCheckBounds_vehicleModel(const vehicleModel_T *p_theDestData);
	bool_T rteInConvert_vehicleModel(const Dt_RECORD_InnoDriveControlVehicleModel *p_theSrcData, vehicleModel_T *p_theDestData);

#ifdef __cplusplus
}
#endif
/*lint -restore */

#endif
