#ifndef _vmdlEPT_H_
#define _vmdlEPT_H_

#include "strategy/strategy.h"

#ifdef __cplusplus
extern "C" {
#endif

		
	bool_T				 vmdlGetEPTPresence(		IN	const	vehicleModel_T		*vehicleModel,
													OUT			bool_T				*eptPresent);


	real32_T		 vmdlGetBatteryCapacity(		IN	const	vehicleModel_T		*vehicleModel);


	real32_T vmdlGetOverallBatteryCapacity(			IN	const	vehicleModel_T		*vehicleModel);


	bool_T					  vmdlEPTUpdate(		IN	const	vehicleModel_T		*vehicleModel,
													IN	const	real32_T			 initialSOC,
													IN	const	real32_T			 eTorque,
													IN	const	real32_T			 omega,
													IN	const	real32_T			 deltaTime,
													OUT	OPT		real32_T			*batteryPower,
													OUT	OPT		real32_T			*finalSOC);


	bool_T				  vmdlEPTPowerToSOC(		IN	const	vehicleModel_T		*vehicleModel,
													IN	const	real32_T			 initialSOC,
													IN	const	real32_T			 ePower,
													IN	const	real32_T			 deltaTime,
													OUT			real32_T			*finalSOC);


	bool_T				  vmdlEPTSOCToPower(		IN	const	vehicleModel_T		*vehicleModel,
													IN	const	real32_T			 initialSOC,
													IN	const	real32_T			 finalSOC,
													IN	const	real32_T			 deltaTime,
													OUT			real32_T			*ePower);


#ifdef __cplusplus
}
#endif


#endif
