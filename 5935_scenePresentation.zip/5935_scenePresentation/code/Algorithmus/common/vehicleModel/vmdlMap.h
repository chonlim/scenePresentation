#ifndef guard_vmdlMap_h
#define guard_vmdlMap_h

#include "vmdlMapTypes.h"


/** \brief	Ermittelt den auf [0 1] skalierten Offset, der sich f�r einen X- und Y-Wert aus dem Festkomma-Kennfeld ergibt */
bool_T				 vmdlMapInterpolate(IN	const	mapAxis_T			*xAxis,			/**< Datenstruktur der X-Achse des Kennfelds */
										IN	const	mapAxis_T			*yAxes,			/**< Datenstrukturen der Y-Achsen des Kennfelds */
										IN	const	uint16_T			 xCount,		/**< Anzahl g�ltiger Elemente auf der X-Achse */
										IN	const	uint16_T			 yCount,		/**< Anzahl g�ltiger Elemente auf der Y-Achse */
										IN	const	real32_T			 x,				/**< X-Wert, f�r den das Kennfeld abgefragt wird */
										IN	const	real32_T			 y,				/**< Y-Wert, f�r den das Kennfeld abgefragt wird */
										IN	const	uint8_T				*data,			/**< Datenreihe zur Darstellung der Z-Achse des Kennfelds */
										OUT			real32_T			*value			/**< Ergebis der Interpolation im Bereich [0 1] */
										);


/** \brief	Ermittelt den auf [0 1] skalierten Offset, der sich f�r einen X-Wert aus der Festkomma-Kennlinie ergibt */
bool_T				  vmdlMapLineInterp(IN	const	mapAxis_T			*axis,			/**< Datenstruktur der Kennlinien-Achse */
										IN	const	uint16_T			 count,			/**< Anzahl g�ltiger Elemente auf der Achse */
										IN	const	real32_T			 x,				/**< X-Wert, f�r den die Kennlinie abgefragt wird */
										IN	const	uint8_T				*dataPtr,		/**< Datenreihe zur Darstellung der Kennlinie */
										OUT			real32_T			*value			/**< Ergebis der Interpolation im Bereich [0 1] */
										);


/** \brief	Berechnet die inverse Schrittweite auf einer Kennfeld-Achse */
bool_T				  vmdlMapGetInvStep(IN	const	mapAxis_T			*axis,			/**< Datenstruktur der Kennfeld-Achse */
										IN	const	uint16_T			 count,			/**< Anzahl g�ltiger Elemente */
										OUT			real32_T			*invStep		/**< inverse Schrittweite */
										);


/** \brief	Berechnet den Index des ersten Elements sowie die Gewichtung zweier Achsen f�r die lineare Interpolation in einem Kennfeld */
bool_T			 vmdlMapInterpolateAxis(IN	const	mapAxis_T			*axis,			/**< Datenstruktur der Kennfeld-Achse */
										IN	const	real32_T			 invStep,		/**< inverse Schrittweite */
										IN	const	uint16_T			 count,			/**< Anzahl g�ltiger Elemente */
										IN	const	real32_T			 value,			/**< Wert, der auf der Achse gesucht wird */
										OUT			uint16_T			*index,			/**< Index der ersten relevanten Achse */
										OUT			real32_T			*delta			/**< Lineare Verschiebung zwischen beiden Achsen */
										);


/** \brief	F�hrt eine Vorauswahl der X-Achse f�r den sp�teren Zugriff auf ein Kennfeld aus */
bool_T				  vmdlMapPreSelInit(IN	const	mapAxis_T			*xAxis,			/**< Datenstruktur der X-Achse des Kennfelds */
										IN	const	mapAxis_T			*yAxes,			/**< Datenstrukturen der Y-Achsen des Kennfelds */
										IN	const	uint16_T			 xCount,		/**< Anzahl g�ltiger Elemente auf der X-Achse */
										IN	const	uint16_T			 yCount,		/**< Anzahl g�ltiger Elemente auf der Y-Achse */
										IN	const	real32_T			 xValue,		/**< X-Wert, f�r den das Kennfeld abgefragt wird */
										IN	const	uint8_T				*data,			/**< Datenreihe zur Darstellung der Z-Achse des Kennfelds */
										OUT			mapPreSel_T			*preSel			/**< interne Datenstruktur der Vorauswahl */
										);


/** \brief	Interpoliert auf den vorausgew�hlten Achsen eines Kennfelds */
bool_T		   vmdlMapPreSelInterpolate(IN	const	mapPreSel_T			*preSel,		/**< interne Datenstruktur der Vorauswahl */
										IN	const	real32_T			 y,				/**< Y-Wert, f�r den das Kennfeld abgefragt wird */
										OUT			real32_T			*value			/**< Ergebis der Interpolation im Bereich [0 1] */
										);


#endif
