#ifndef guard_vmdlResistanceTypes_h
#define guard_vmdlResistanceTypes_h


struct resistanceFactors_tag {
	real32_T	velocity;
	real32_T	curvature;
	real32_T	slope;
};


#endif
