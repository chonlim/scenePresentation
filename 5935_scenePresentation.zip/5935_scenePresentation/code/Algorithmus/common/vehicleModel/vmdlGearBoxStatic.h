#ifndef guard_vmdlGearBoxStatic_h
#define guard_vmdlGearBoxStatic_h


/** \brief	Gibt das Gesamt�bersetzungsverh�ltnis (Geschwindigkeit -> Drehzahl) in einem gegebenen Gang zur�ck */
static bool_T	  vmdlGBGetOverallRatio(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*ratio				/**< Gesamt�bersetzungsverh�ltnis [1/m] */
										);


/** \brief	Gibt das Gesamt�bersetzungsverh�ltnis (Geschwindigkeit -> Drehzahl) f�r die sekund�re E-Maschine zur�ck */
static void			  vmdlGBGetAuxRatio(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										OUT			real32_T			*ratio				/**< Gesamt�bersetzungsverh�ltnis [1/m] */
										);


/** \brief	Ruft die �quivalente Gesamttr�gheit des Fahrzeugs im angegebenen Gang ab */
static bool_T	    vmdlGBGetInvInertia(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										OUT			real32_T			*invInertia			/**< �quivalente Fahrzeugtr�gheit [m/(Nms)] */
										);


/** \brief	Berechnet das Verlustmoment im Getriebe, das sich im angegebenen Gang aus Eingangsmoment und -drehzahl ergibt */
static bool_T		vmdlGBGetTorqueLoss(IN	const	gearBoxModel_T		*gearBox,			/**< interne Datenstruktur des Getriebemodells */
										IN	const	gear_T				 gear,				/**< eingelegter Gang */
										IN	const	real32_T			 torque,			/**< Antriebsmoment [Nm] */
										IN	const	real32_T			 omega,				/**< Motordrehzahl [rad/s] */
										OUT			real32_T			*torqueLoss			/**< Verlustmoment [Nm] */
										);


/** \brief	F�hrt eine Interpolation auf dem Getriebeverlustkennfeld durch */
static bool_T	  vmdlGBInterpolateDrag(IN	const	dragMap_T			*map,				/**< Datenstruktur des Verlustkennfelds */
										IN	const	real32_T			 torque,			/**< Antriebsmoment [Nm] */
										IN	const	real32_T			 omega,				/**< Motordrehzahl [rad/s] */
										OUT			real32_T			*drag				/**< Verlustmoment [Nm] */
										);


#endif
