#include "common/vehicleModel/PpDsVehicleModel.h"

#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#define Log_AddMsg(ID, Group, Option, ...)
#else
#include "Log.h"
#endif


/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteInConvert_vehicleModel(const Dt_RECORD_InnoDriveControlVehicleModel *p_theSrcData, vehicleModel_T *p_theDestData)
{
	uint32_T uiArrIdx;
	p_theDestData->checksumCrc32                          = p_theSrcData->DeData.checksumCrc32;
	if( vehicleModelCrc32 != p_theDestData->checksumCrc32)
	{
		Log_AddMsg(SWCID_CtApInnoDriveControl, LOG_GROUP_1, LOG_ERROR, "Checksum error!! Include=%d, Dataset=%d", vehicleModelCrc32, p_theDestData->checksumCrc32);
		return false;
	}

	p_theDestData->resistance.mass                        = p_theSrcData->DeData.resistance_mass;
	p_theDestData->resistance.coastingCoefficients.a      = p_theSrcData->DeData.resistance_coastingCoefficients_a;
	p_theDestData->resistance.coastingCoefficients.b      = p_theSrcData->DeData.resistance_coastingCoefficients_b;
	p_theDestData->resistance.coastingCoefficients.c      = p_theSrcData->DeData.resistance_coastingCoefficients_c;
	p_theDestData->singleTrack.mass                       = p_theSrcData->DeData.singleTrack_mass;
	p_theDestData->singleTrack.length                     = p_theSrcData->DeData.singleTrack_length;
	p_theDestData->singleTrack.steeringRatio              = p_theSrcData->DeData.singleTrack_steeringRatio;
	p_theDestData->singleTrack.steeringRatioRAS           = p_theSrcData->DeData.singleTrack_steeringRatioRAS;
	p_theDestData->singleTrack.eg                         = p_theSrcData->DeData.singleTrack_eg;
	p_theDestData->singleTrack.egRAS                      = p_theSrcData->DeData.singleTrack_egRAS;
	p_theDestData->singleTrack.lengthFront                = p_theSrcData->DeData.singleTrack_lengthFront;
	p_theDestData->singleTrack.lengthRear                 = p_theSrcData->DeData.singleTrack_lengthRear;
	p_theDestData->singleTrack.cR                         = p_theSrcData->DeData.singleTrack_cR;
	p_theDestData->singleTrack.cF                         = p_theSrcData->DeData.singleTrack_cF;
	p_theDestData->gearBox.requestOffset                  = p_theSrcData->DeData.gearBox_requestOffset;
	p_theDestData->gearBox.iDiff                          = p_theSrcData->DeData.gearBox_iDiff;
	p_theDestData->gearBox.wheelRadius                    = p_theSrcData->DeData.gearBox_wheelRadius;
	p_theDestData->gearBox.auxDiff                        = p_theSrcData->DeData.gearBox_auxDiff;
	p_theDestData->gearBox.auxRadius                      = p_theSrcData->DeData.gearBox_auxRadius;
	p_theDestData->gearBox.minOmega                       = p_theSrcData->DeData.gearBox_minOmega;
	p_theDestData->gearBox.maxOmega                       = p_theSrcData->DeData.gearBox_maxOmega;
	p_theDestData->gearBox.coasting.minVelocity           = p_theSrcData->DeData.gearBox_coasting_minVelocity;
	p_theDestData->gearBox.coasting.maxVelocity           = p_theSrcData->DeData.gearBox_coasting_maxVelocity;
	p_theDestData->gearBox.gear[0].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_0_transmissionRatio;
	p_theDestData->gearBox.gear[0].invInertia             = p_theSrcData->DeData.gearBox_gear_0_invInertia;
	p_theDestData->gearBox.gear[0].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_0_dragMap_omega_min;
	p_theDestData->gearBox.gear[0].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_0_dragMap_omega_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[0].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[0].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_0_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[0].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_0_dragMap_drag_min;
	p_theDestData->gearBox.gear[0].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_0_dragMap_drag_factor;
	p_theDestData->gearBox.gear[1].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_1_transmissionRatio;
	p_theDestData->gearBox.gear[1].invInertia             = p_theSrcData->DeData.gearBox_gear_1_invInertia;
	p_theDestData->gearBox.gear[1].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_1_dragMap_omega_min;
	p_theDestData->gearBox.gear[1].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_1_dragMap_omega_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[1].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[1].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_1_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[1].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_1_dragMap_drag_min;
	p_theDestData->gearBox.gear[1].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_1_dragMap_drag_factor;
	p_theDestData->gearBox.gear[2].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_2_transmissionRatio;
	p_theDestData->gearBox.gear[2].invInertia             = p_theSrcData->DeData.gearBox_gear_2_invInertia;
	p_theDestData->gearBox.gear[2].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_2_dragMap_omega_min;
	p_theDestData->gearBox.gear[2].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_2_dragMap_omega_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[2].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[2].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_2_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[2].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_2_dragMap_drag_min;
	p_theDestData->gearBox.gear[2].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_2_dragMap_drag_factor;
	p_theDestData->gearBox.gear[3].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_3_transmissionRatio;
	p_theDestData->gearBox.gear[3].invInertia             = p_theSrcData->DeData.gearBox_gear_3_invInertia;
	p_theDestData->gearBox.gear[3].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_3_dragMap_omega_min;
	p_theDestData->gearBox.gear[3].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_3_dragMap_omega_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[3].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[3].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_3_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[3].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_3_dragMap_drag_min;
	p_theDestData->gearBox.gear[3].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_3_dragMap_drag_factor;
	p_theDestData->gearBox.gear[4].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_4_transmissionRatio;
	p_theDestData->gearBox.gear[4].invInertia             = p_theSrcData->DeData.gearBox_gear_4_invInertia;
	p_theDestData->gearBox.gear[4].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_4_dragMap_omega_min;
	p_theDestData->gearBox.gear[4].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_4_dragMap_omega_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[4].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[4].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_4_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[4].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_4_dragMap_drag_min;
	p_theDestData->gearBox.gear[4].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_4_dragMap_drag_factor;
	p_theDestData->gearBox.gear[5].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_5_transmissionRatio;
	p_theDestData->gearBox.gear[5].invInertia             = p_theSrcData->DeData.gearBox_gear_5_invInertia;
	p_theDestData->gearBox.gear[5].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_5_dragMap_omega_min;
	p_theDestData->gearBox.gear[5].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_5_dragMap_omega_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[5].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[5].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_5_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[5].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_5_dragMap_drag_min;
	p_theDestData->gearBox.gear[5].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_5_dragMap_drag_factor;
	p_theDestData->gearBox.gear[6].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_6_transmissionRatio;
	p_theDestData->gearBox.gear[6].invInertia             = p_theSrcData->DeData.gearBox_gear_6_invInertia;
	p_theDestData->gearBox.gear[6].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_6_dragMap_omega_min;
	p_theDestData->gearBox.gear[6].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_6_dragMap_omega_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[6].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[6].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_6_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[6].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_6_dragMap_drag_min;
	p_theDestData->gearBox.gear[6].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_6_dragMap_drag_factor;
	p_theDestData->gearBox.gear[7].transmissionRatio      = p_theSrcData->DeData.gearBox_gear_7_transmissionRatio;
	p_theDestData->gearBox.gear[7].invInertia             = p_theSrcData->DeData.gearBox_gear_7_invInertia;
	p_theDestData->gearBox.gear[7].dragMap.omega.min      = p_theSrcData->DeData.gearBox_gear_7_dragMap_omega_min;
	p_theDestData->gearBox.gear[7].dragMap.omega.max      = p_theSrcData->DeData.gearBox_gear_7_dragMap_omega_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[0].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_0_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[0].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_0_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[1].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_1_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[1].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_1_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[2].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_2_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[2].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_2_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[3].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_3_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[3].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_3_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[4].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_4_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[4].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_4_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[5].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_5_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[5].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_5_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[6].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_6_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[6].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_6_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[7].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_7_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[7].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_7_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[8].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_8_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[8].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_8_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[9].min  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_9_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[9].max  = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_9_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[10].min = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_10_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[10].max = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_10_max;
	p_theDestData->gearBox.gear[7].dragMap.torque[11].min = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_11_min;
	p_theDestData->gearBox.gear[7].dragMap.torque[11].max = p_theSrcData->DeData.gearBox_gear_7_dragMap_torque_11_max;
	p_theDestData->gearBox.gear[7].dragMap.drag.min       = p_theSrcData->DeData.gearBox_gear_7_dragMap_drag_min;
	p_theDestData->gearBox.gear[7].dragMap.drag.factor    = p_theSrcData->DeData.gearBox_gear_7_dragMap_drag_factor;
	p_theDestData->engine.thrustLine.omega.min            = p_theSrcData->DeData.engine_thrustLine_omega_min;
	p_theDestData->engine.thrustLine.omega.max            = p_theSrcData->DeData.engine_thrustLine_omega_max;
	p_theDestData->engine.thrustLine.torque.min           = p_theSrcData->DeData.engine_thrustLine_torque_min;
	p_theDestData->engine.thrustLine.torque.factor        = p_theSrcData->DeData.engine_thrustLine_torque_factor;
	p_theDestData->engine.torqueRate.omega.min            = p_theSrcData->DeData.engine_torqueRate_omega_min;
	p_theDestData->engine.torqueRate.omega.max            = p_theSrcData->DeData.engine_torqueRate_omega_max;
	p_theDestData->engine.torqueRate.rate.min             = p_theSrcData->DeData.engine_torqueRate_rate_min;
	p_theDestData->engine.torqueRate.rate.factor          = p_theSrcData->DeData.engine_torqueRate_rate_factor;
	p_theDestData->engine.minRefTorque.omega.min          = p_theSrcData->DeData.engine_minRefTorque_omega_min;
	p_theDestData->engine.minRefTorque.omega.max          = p_theSrcData->DeData.engine_minRefTorque_omega_max;
	p_theDestData->engine.minRefTorque.torque.min         = p_theSrcData->DeData.engine_minRefTorque_torque_min;
	p_theDestData->engine.minRefTorque.torque.factor      = p_theSrcData->DeData.engine_minRefTorque_torque_factor;
	p_theDestData->engine.consumptionMap.omega.min        = p_theSrcData->DeData.engine_consumptionMap_omega_min;
	p_theDestData->engine.consumptionMap.omega.max        = p_theSrcData->DeData.engine_consumptionMap_omega_max;
	p_theDestData->engine.consumptionMap.torque[0].min    = p_theSrcData->DeData.engine_consumptionMap_torque_0_min;
	p_theDestData->engine.consumptionMap.torque[0].max    = p_theSrcData->DeData.engine_consumptionMap_torque_0_max;
	p_theDestData->engine.consumptionMap.torque[1].min    = p_theSrcData->DeData.engine_consumptionMap_torque_1_min;
	p_theDestData->engine.consumptionMap.torque[1].max    = p_theSrcData->DeData.engine_consumptionMap_torque_1_max;
	p_theDestData->engine.consumptionMap.torque[2].min    = p_theSrcData->DeData.engine_consumptionMap_torque_2_min;
	p_theDestData->engine.consumptionMap.torque[2].max    = p_theSrcData->DeData.engine_consumptionMap_torque_2_max;
	p_theDestData->engine.consumptionMap.torque[3].min    = p_theSrcData->DeData.engine_consumptionMap_torque_3_min;
	p_theDestData->engine.consumptionMap.torque[3].max    = p_theSrcData->DeData.engine_consumptionMap_torque_3_max;
	p_theDestData->engine.consumptionMap.torque[4].min    = p_theSrcData->DeData.engine_consumptionMap_torque_4_min;
	p_theDestData->engine.consumptionMap.torque[4].max    = p_theSrcData->DeData.engine_consumptionMap_torque_4_max;
	p_theDestData->engine.consumptionMap.torque[5].min    = p_theSrcData->DeData.engine_consumptionMap_torque_5_min;
	p_theDestData->engine.consumptionMap.torque[5].max    = p_theSrcData->DeData.engine_consumptionMap_torque_5_max;
	p_theDestData->engine.consumptionMap.torque[6].min    = p_theSrcData->DeData.engine_consumptionMap_torque_6_min;
	p_theDestData->engine.consumptionMap.torque[6].max    = p_theSrcData->DeData.engine_consumptionMap_torque_6_max;
	p_theDestData->engine.consumptionMap.torque[7].min    = p_theSrcData->DeData.engine_consumptionMap_torque_7_min;
	p_theDestData->engine.consumptionMap.torque[7].max    = p_theSrcData->DeData.engine_consumptionMap_torque_7_max;
	p_theDestData->engine.consumptionMap.torque[8].min    = p_theSrcData->DeData.engine_consumptionMap_torque_8_min;
	p_theDestData->engine.consumptionMap.torque[8].max    = p_theSrcData->DeData.engine_consumptionMap_torque_8_max;
	p_theDestData->engine.consumptionMap.torque[9].min    = p_theSrcData->DeData.engine_consumptionMap_torque_9_min;
	p_theDestData->engine.consumptionMap.torque[9].max    = p_theSrcData->DeData.engine_consumptionMap_torque_9_max;
	p_theDestData->engine.consumptionMap.torque[10].min   = p_theSrcData->DeData.engine_consumptionMap_torque_10_min;
	p_theDestData->engine.consumptionMap.torque[10].max   = p_theSrcData->DeData.engine_consumptionMap_torque_10_max;
	p_theDestData->engine.consumptionMap.torque[11].min   = p_theSrcData->DeData.engine_consumptionMap_torque_11_min;
	p_theDestData->engine.consumptionMap.torque[11].max   = p_theSrcData->DeData.engine_consumptionMap_torque_11_max;
	p_theDestData->engine.consumptionMap.torque[12].min   = p_theSrcData->DeData.engine_consumptionMap_torque_12_min;
	p_theDestData->engine.consumptionMap.torque[12].max   = p_theSrcData->DeData.engine_consumptionMap_torque_12_max;
	p_theDestData->engine.consumptionMap.torque[13].min   = p_theSrcData->DeData.engine_consumptionMap_torque_13_min;
	p_theDestData->engine.consumptionMap.torque[13].max   = p_theSrcData->DeData.engine_consumptionMap_torque_13_max;
	p_theDestData->engine.consumptionMap.torque[14].min   = p_theSrcData->DeData.engine_consumptionMap_torque_14_min;
	p_theDestData->engine.consumptionMap.torque[14].max   = p_theSrcData->DeData.engine_consumptionMap_torque_14_max;
	p_theDestData->engine.consumptionMap.torque[15].min   = p_theSrcData->DeData.engine_consumptionMap_torque_15_min;
	p_theDestData->engine.consumptionMap.torque[15].max   = p_theSrcData->DeData.engine_consumptionMap_torque_15_max;
	p_theDestData->engine.consumptionMap.power.min        = p_theSrcData->DeData.engine_consumptionMap_power_min;
	p_theDestData->engine.consumptionMap.power.factor     = p_theSrcData->DeData.engine_consumptionMap_power_factor;
	p_theDestData->engine.torqueReserve.absolute          = p_theSrcData->DeData.engine_torqueReserve_absolute;
	p_theDestData->engine.torqueReserve.factor            = p_theSrcData->DeData.engine_torqueReserve_factor;
	p_theDestData->engine.thrustPower                     = p_theSrcData->DeData.engine_thrustPower;
	p_theDestData->engine.cutoffMinOmega                  = p_theSrcData->DeData.engine_cutoffMinOmega;
	p_theDestData->engine.ePowerAccelOffset               = p_theSrcData->DeData.engine_ePowerAccelOffset;
	p_theDestData->simple.powerMap.velocity.min           = p_theSrcData->DeData.simple_powerMap_velocity_min;
	p_theDestData->simple.powerMap.velocity.max           = p_theSrcData->DeData.simple_powerMap_velocity_max;
	p_theDestData->simple.powerMap.force[0].min           = p_theSrcData->DeData.simple_powerMap_force_0_min;
	p_theDestData->simple.powerMap.force[0].max           = p_theSrcData->DeData.simple_powerMap_force_0_max;
	p_theDestData->simple.powerMap.force[1].min           = p_theSrcData->DeData.simple_powerMap_force_1_min;
	p_theDestData->simple.powerMap.force[1].max           = p_theSrcData->DeData.simple_powerMap_force_1_max;
	p_theDestData->simple.powerMap.force[2].min           = p_theSrcData->DeData.simple_powerMap_force_2_min;
	p_theDestData->simple.powerMap.force[2].max           = p_theSrcData->DeData.simple_powerMap_force_2_max;
	p_theDestData->simple.powerMap.force[3].min           = p_theSrcData->DeData.simple_powerMap_force_3_min;
	p_theDestData->simple.powerMap.force[3].max           = p_theSrcData->DeData.simple_powerMap_force_3_max;
	p_theDestData->simple.powerMap.force[4].min           = p_theSrcData->DeData.simple_powerMap_force_4_min;
	p_theDestData->simple.powerMap.force[4].max           = p_theSrcData->DeData.simple_powerMap_force_4_max;
	p_theDestData->simple.powerMap.force[5].min           = p_theSrcData->DeData.simple_powerMap_force_5_min;
	p_theDestData->simple.powerMap.force[5].max           = p_theSrcData->DeData.simple_powerMap_force_5_max;
	p_theDestData->simple.powerMap.force[6].min           = p_theSrcData->DeData.simple_powerMap_force_6_min;
	p_theDestData->simple.powerMap.force[6].max           = p_theSrcData->DeData.simple_powerMap_force_6_max;
	p_theDestData->simple.powerMap.force[7].min           = p_theSrcData->DeData.simple_powerMap_force_7_min;
	p_theDestData->simple.powerMap.force[7].max           = p_theSrcData->DeData.simple_powerMap_force_7_max;
	p_theDestData->simple.powerMap.force[8].min           = p_theSrcData->DeData.simple_powerMap_force_8_min;
	p_theDestData->simple.powerMap.force[8].max           = p_theSrcData->DeData.simple_powerMap_force_8_max;
	p_theDestData->simple.powerMap.force[9].min           = p_theSrcData->DeData.simple_powerMap_force_9_min;
	p_theDestData->simple.powerMap.force[9].max           = p_theSrcData->DeData.simple_powerMap_force_9_max;
	p_theDestData->simple.powerMap.force[10].min          = p_theSrcData->DeData.simple_powerMap_force_10_min;
	p_theDestData->simple.powerMap.force[10].max          = p_theSrcData->DeData.simple_powerMap_force_10_max;
	p_theDestData->simple.powerMap.force[11].min          = p_theSrcData->DeData.simple_powerMap_force_11_min;
	p_theDestData->simple.powerMap.force[11].max          = p_theSrcData->DeData.simple_powerMap_force_11_max;
	p_theDestData->simple.powerMap.force[12].min          = p_theSrcData->DeData.simple_powerMap_force_12_min;
	p_theDestData->simple.powerMap.force[12].max          = p_theSrcData->DeData.simple_powerMap_force_12_max;
	p_theDestData->simple.powerMap.force[13].min          = p_theSrcData->DeData.simple_powerMap_force_13_min;
	p_theDestData->simple.powerMap.force[13].max          = p_theSrcData->DeData.simple_powerMap_force_13_max;
	p_theDestData->simple.powerMap.force[14].min          = p_theSrcData->DeData.simple_powerMap_force_14_min;
	p_theDestData->simple.powerMap.force[14].max          = p_theSrcData->DeData.simple_powerMap_force_14_max;
	p_theDestData->simple.powerMap.force[15].min          = p_theSrcData->DeData.simple_powerMap_force_15_min;
	p_theDestData->simple.powerMap.force[15].max          = p_theSrcData->DeData.simple_powerMap_force_15_max;
	p_theDestData->simple.powerMap.force[16].min          = p_theSrcData->DeData.simple_powerMap_force_16_min;
	p_theDestData->simple.powerMap.force[16].max          = p_theSrcData->DeData.simple_powerMap_force_16_max;
	p_theDestData->simple.powerMap.force[17].min          = p_theSrcData->DeData.simple_powerMap_force_17_min;
	p_theDestData->simple.powerMap.force[17].max          = p_theSrcData->DeData.simple_powerMap_force_17_max;
	p_theDestData->simple.powerMap.force[18].min          = p_theSrcData->DeData.simple_powerMap_force_18_min;
	p_theDestData->simple.powerMap.force[18].max          = p_theSrcData->DeData.simple_powerMap_force_18_max;
	p_theDestData->simple.powerMap.force[19].min          = p_theSrcData->DeData.simple_powerMap_force_19_min;
	p_theDestData->simple.powerMap.force[19].max          = p_theSrcData->DeData.simple_powerMap_force_19_max;
	p_theDestData->simple.powerMap.force[20].min          = p_theSrcData->DeData.simple_powerMap_force_20_min;
	p_theDestData->simple.powerMap.force[20].max          = p_theSrcData->DeData.simple_powerMap_force_20_max;
	p_theDestData->simple.powerMap.force[21].min          = p_theSrcData->DeData.simple_powerMap_force_21_min;
	p_theDestData->simple.powerMap.force[21].max          = p_theSrcData->DeData.simple_powerMap_force_21_max;
	p_theDestData->simple.powerMap.force[22].min          = p_theSrcData->DeData.simple_powerMap_force_22_min;
	p_theDestData->simple.powerMap.force[22].max          = p_theSrcData->DeData.simple_powerMap_force_22_max;
	p_theDestData->simple.powerMap.force[23].min          = p_theSrcData->DeData.simple_powerMap_force_23_min;
	p_theDestData->simple.powerMap.force[23].max          = p_theSrcData->DeData.simple_powerMap_force_23_max;
	p_theDestData->simple.powerMap.force[24].min          = p_theSrcData->DeData.simple_powerMap_force_24_min;
	p_theDestData->simple.powerMap.force[24].max          = p_theSrcData->DeData.simple_powerMap_force_24_max;
	p_theDestData->simple.powerMap.force[25].min          = p_theSrcData->DeData.simple_powerMap_force_25_min;
	p_theDestData->simple.powerMap.force[25].max          = p_theSrcData->DeData.simple_powerMap_force_25_max;
	p_theDestData->simple.powerMap.force[26].min          = p_theSrcData->DeData.simple_powerMap_force_26_min;
	p_theDestData->simple.powerMap.force[26].max          = p_theSrcData->DeData.simple_powerMap_force_26_max;
	p_theDestData->simple.powerMap.force[27].min          = p_theSrcData->DeData.simple_powerMap_force_27_min;
	p_theDestData->simple.powerMap.force[27].max          = p_theSrcData->DeData.simple_powerMap_force_27_max;
	p_theDestData->simple.powerMap.force[28].min          = p_theSrcData->DeData.simple_powerMap_force_28_min;
	p_theDestData->simple.powerMap.force[28].max          = p_theSrcData->DeData.simple_powerMap_force_28_max;
	p_theDestData->simple.powerMap.force[29].min          = p_theSrcData->DeData.simple_powerMap_force_29_min;
	p_theDestData->simple.powerMap.force[29].max          = p_theSrcData->DeData.simple_powerMap_force_29_max;
	p_theDestData->simple.powerMap.force[30].min          = p_theSrcData->DeData.simple_powerMap_force_30_min;
	p_theDestData->simple.powerMap.force[30].max          = p_theSrcData->DeData.simple_powerMap_force_30_max;
	p_theDestData->simple.powerMap.force[31].min          = p_theSrcData->DeData.simple_powerMap_force_31_min;
	p_theDestData->simple.powerMap.force[31].max          = p_theSrcData->DeData.simple_powerMap_force_31_max;
	p_theDestData->simple.powerMap.power.min              = p_theSrcData->DeData.simple_powerMap_power_min;
	p_theDestData->simple.powerMap.power.factor           = p_theSrcData->DeData.simple_powerMap_power_factor;
	p_theDestData->simple.idlePower                       = p_theSrcData->DeData.simple_idlePower;
	p_theDestData->simple.coastLimit                      = p_theSrcData->DeData.simple_coastLimit;
	p_theDestData->misc.curveFactor                       = p_theSrcData->DeData.misc_curveFactor;
	p_theDestData->gearBox.gear[0].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_0_dragMap_numOmega;
	p_theDestData->gearBox.gear[0].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_0_dragMap_numTorque;
	p_theDestData->gearBox.gear[1].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_1_dragMap_numOmega;
	p_theDestData->gearBox.gear[1].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_1_dragMap_numTorque;
	p_theDestData->gearBox.gear[2].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_2_dragMap_numOmega;
	p_theDestData->gearBox.gear[2].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_2_dragMap_numTorque;
	p_theDestData->gearBox.gear[3].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_3_dragMap_numOmega;
	p_theDestData->gearBox.gear[3].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_3_dragMap_numTorque;
	p_theDestData->gearBox.gear[4].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_4_dragMap_numOmega;
	p_theDestData->gearBox.gear[4].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_4_dragMap_numTorque;
	p_theDestData->gearBox.gear[5].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_5_dragMap_numOmega;
	p_theDestData->gearBox.gear[5].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_5_dragMap_numTorque;
	p_theDestData->gearBox.gear[6].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_6_dragMap_numOmega;
	p_theDestData->gearBox.gear[6].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_6_dragMap_numTorque;
	p_theDestData->gearBox.gear[7].dragMap.numOmega       = p_theSrcData->DeData.gearBox_gear_7_dragMap_numOmega;
	p_theDestData->gearBox.gear[7].dragMap.numTorque      = p_theSrcData->DeData.gearBox_gear_7_dragMap_numTorque;
	p_theDestData->engine.consumptionMap.numOmega         = p_theSrcData->DeData.engine_consumptionMap_numOmega;
	p_theDestData->engine.consumptionMap.numTorque        = p_theSrcData->DeData.engine_consumptionMap_numTorque;
	p_theDestData->simple.powerMap.numVelocity            = p_theSrcData->DeData.simple_powerMap_numVelocity;
	p_theDestData->simple.powerMap.numForce               = p_theSrcData->DeData.simple_powerMap_numForce;
	p_theDestData->bufferSize                             = p_theSrcData->DeData.bufferSize;
	p_theDestData->valid                                  = p_theSrcData->DeData.valid;
	p_theDestData->gearBox.numGears                       = p_theSrcData->DeData.gearBox_numGears;
	p_theDestData->gearBox.requestAllowed                 = p_theSrcData->DeData.gearBox_requestAllowed;
	p_theDestData->gearBox.useSumTorque                   = p_theSrcData->DeData.gearBox_useSumTorque;
	p_theDestData->gearBox.coasting.possible              = p_theSrcData->DeData.gearBox_coasting_possible;

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_0_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_0_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[0].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_0_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_1_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_1_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[1].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_1_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_2_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_2_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[2].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_2_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_3_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_3_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[3].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_3_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_4_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_4_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[4].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_4_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_5_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_5_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[5].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_5_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_6_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_6_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[6].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_6_dragMap_drag_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlDRAGCOUNT != sizeof(p_theSrcData->DeData.gearBox_gear_7_dragMap_drag_data) / sizeof(p_theSrcData->DeData.gearBox_gear_7_dragMap_drag_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlDRAGCOUNT; uiArrIdx++)
	{
		p_theDestData->gearBox.gear[7].dragMap.drag.data[uiArrIdx] = p_theSrcData->DeData.gearBox_gear_7_dragMap_drag_data[uiArrIdx]; 
	}
	p_theDestData->engine.thrustLine.numOmega             = p_theSrcData->DeData.engine_thrustLine_numOmega;

	BUILD_BUG_ON((uint32_T)vmdlTHRUSTTORQUECOUNT != sizeof(p_theSrcData->DeData.engine_thrustLine_torque_data) / sizeof(p_theSrcData->DeData.engine_thrustLine_torque_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlTHRUSTTORQUECOUNT; uiArrIdx++)
	{
		p_theDestData->engine.thrustLine.torque.data[uiArrIdx] = p_theSrcData->DeData.engine_thrustLine_torque_data[uiArrIdx]; 
	}
	p_theDestData->engine.torqueRate.numOmega             = p_theSrcData->DeData.engine_torqueRate_numOmega;

	BUILD_BUG_ON((uint32_T)vmdlTORQUERATECOUNT != sizeof(p_theSrcData->DeData.engine_torqueRate_rate_data) / sizeof(p_theSrcData->DeData.engine_torqueRate_rate_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlTORQUERATECOUNT; uiArrIdx++)
	{
		p_theDestData->engine.torqueRate.rate.data[uiArrIdx] = p_theSrcData->DeData.engine_torqueRate_rate_data[uiArrIdx]; 
	}
	p_theDestData->engine.minRefTorque.numOmega           = p_theSrcData->DeData.engine_minRefTorque_numOmega;

	BUILD_BUG_ON((uint32_T)vmdlREFTORQUECOUNT != sizeof(p_theSrcData->DeData.engine_minRefTorque_torque_data) / sizeof(p_theSrcData->DeData.engine_minRefTorque_torque_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlREFTORQUECOUNT; uiArrIdx++)
	{
		p_theDestData->engine.minRefTorque.torque.data[uiArrIdx] = p_theSrcData->DeData.engine_minRefTorque_torque_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlCONSPOWERCOUNT != sizeof(p_theSrcData->DeData.engine_consumptionMap_power_data) / sizeof(p_theSrcData->DeData.engine_consumptionMap_power_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlCONSPOWERCOUNT; uiArrIdx++)
	{
		p_theDestData->engine.consumptionMap.power.data[uiArrIdx] = p_theSrcData->DeData.engine_consumptionMap_power_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlSIMPLEPOWERCOUNT != sizeof(p_theSrcData->DeData.simple_powerMap_power_data) / sizeof(p_theSrcData->DeData.simple_powerMap_power_data[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlSIMPLEPOWERCOUNT; uiArrIdx++)
	{
		p_theDestData->simple.powerMap.power.data[uiArrIdx] = p_theSrcData->DeData.simple_powerMap_power_data[uiArrIdx]; 
	}

	BUILD_BUG_ON((uint32_T)vmdlCODECOUNT != sizeof(p_theSrcData->DeData.misc_codeList_code) / sizeof(p_theSrcData->DeData.misc_codeList_code[0]));
	for( uiArrIdx = 0 ; uiArrIdx < (uint32_T)vmdlCODECOUNT; uiArrIdx++)
	{
		p_theDestData->misc.codeList.code[uiArrIdx] = p_theSrcData->DeData.misc_codeList_code[uiArrIdx]; 
	}
	p_theDestData->misc.codeList.count                    = p_theSrcData->DeData.misc_codeList_count;

	/* The complete structure length is: 4440 Bytes.*/

	return true;
}
/*lint -restore */

/*lint -save */
/*lint -e9034	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]" */
/*lint -e64	"(Error -- Type mismatch (assignment) (int/enum) [MISRA 2012 Rule 1.3, required], [MISRA 2012 Rule 8.4, required])" */
/* e9034 comment: bool_T and Dt_Bool have the same base type (unsigned char) but lint do not recognize that" */
/*lint -e529 (Warning -- Symbol 'uiArrIdx' (line 1309) not subsequently referenced)*/
/*lint -e835	"Note -- A zero has been given as left argument to operator '+'" */
bool_T rteCheckBounds_vehicleModel(const vehicleModel_T *p_theDestData)
{

#if !defined INNODRIVE_ZFAS_SWC_BUILD
	if((Dt_FLOAT32)p_theDestData->resistance.coastingCoefficients.a > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->resistance.coastingCoefficients.a < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->resistance.coastingCoefficients.b > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->resistance.coastingCoefficients.b < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->resistance.coastingCoefficients.c > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->resistance.coastingCoefficients.c < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.eg > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.eg < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.egRAS > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.egRAS < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.requestOffset > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.requestOffset < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.iDiff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.iDiff < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.auxDiff > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.auxDiff < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.auxRadius > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.auxRadius < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.minOmega > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.minOmega < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.maxOmega > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.maxOmega < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.coasting.minVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.coasting.minVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.coasting.maxVelocity > (Dt_FLOAT32)343.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.coasting.maxVelocity < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].transmissionRatio > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].transmissionRatio < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.drag.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.drag.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.drag.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].dragMap.drag.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.torque.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.torque.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.torque.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustLine.torque.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.rate.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.rate.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.rate.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueRate.rate.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.torque.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.torque.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.torque.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.minRefTorque.torque.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.omega.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.omega.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.omega.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.omega.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[12].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[12].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[12].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[12].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[13].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[13].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[13].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[13].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[14].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[14].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[14].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[14].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[15].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[15].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[15].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.torque[15].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.power.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.power.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.power.factor > (Dt_FLOAT32)1.0E8f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.consumptionMap.power.factor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueReserve.absolute > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueReserve.absolute < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueReserve.factor > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.torqueReserve.factor < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustPower > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.thrustPower < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.cutoffMinOmega > (Dt_FLOAT32)1.0E10f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.cutoffMinOmega < (Dt_FLOAT32)-1.0E10f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.ePowerAccelOffset > (Dt_FLOAT32)1.0E2f) { return false; }
	if((Dt_FLOAT32)p_theDestData->engine.ePowerAccelOffset < (Dt_FLOAT32)-1.0E2f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.velocity.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.velocity.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.velocity.max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.velocity.max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[0].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[0].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[0].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[0].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[1].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[1].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[1].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[1].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[2].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[2].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[2].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[2].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[3].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[3].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[3].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[3].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[4].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[4].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[4].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[4].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[5].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[5].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[5].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[5].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[6].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[6].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[6].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[6].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[7].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[7].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[7].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[7].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[8].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[8].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[8].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[8].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[9].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[9].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[9].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[9].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[10].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[10].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[10].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[10].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[11].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[11].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[11].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[11].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[12].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[12].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[12].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[12].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[13].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[13].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[13].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[13].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[14].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[14].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[14].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[14].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[15].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[15].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[15].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[15].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[16].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[16].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[16].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[16].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[17].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[17].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[17].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[17].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[18].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[18].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[18].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[18].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[19].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[19].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[19].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[19].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[20].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[20].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[20].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[20].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[21].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[21].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[21].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[21].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[22].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[22].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[22].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[22].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[23].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[23].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[23].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[23].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[24].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[24].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[24].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[24].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[25].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[25].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[25].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[25].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[26].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[26].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[26].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[26].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[27].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[27].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[27].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[27].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[28].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[28].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[28].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[28].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[29].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[29].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[29].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[29].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[30].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[30].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[30].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[30].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[31].min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[31].min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[31].max > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.force[31].max < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.power.min > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.power.min < (Dt_FLOAT32)-1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.power.factor > (Dt_FLOAT32)1.0E8f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.powerMap.power.factor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.idlePower > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.idlePower < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.coastLimit > (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->simple.coastLimit < (Dt_FLOAT32)-1.0E2f) { return false; }
	if((Dt_FLOAT32)p_theDestData->misc.curveFactor > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->misc.curveFactor < (Dt_FLOAT32)0.0f) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->valid > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->gearBox.requestAllowed > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->gearBox.useSumTorque > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/
	if((Dt_UINT8_1_0)p_theDestData->gearBox.coasting.possible > 1u) { return false; } /*lint !e9030 (advisory) comment: Cast zum Grenzwertcheck*/

#endif

	if((Dt_FLOAT32)p_theDestData->resistance.mass > (Dt_FLOAT32)10.0E3f) { return false; }
	if((Dt_FLOAT32)p_theDestData->resistance.mass < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.mass > (Dt_FLOAT32)10.0E3f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.mass < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.length > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.length < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.steeringRatio > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.steeringRatio < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.steeringRatioRAS > (Dt_FLOAT32)1000.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.steeringRatioRAS < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.lengthFront > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.lengthFront < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.lengthRear > (Dt_FLOAT32)100.0f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.lengthRear < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.cR > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.cR < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.cF > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->singleTrack.cF < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.wheelRadius > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.wheelRadius < (Dt_FLOAT32)0.001f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[0].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[1].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[2].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[3].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[4].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[5].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[6].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].invInertia > (Dt_FLOAT32)1.0E6f) { return false; }
	if((Dt_FLOAT32)p_theDestData->gearBox.gear[7].invInertia < (Dt_FLOAT32)1.0E-6f) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[0].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[0].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[1].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[1].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[2].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[2].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[3].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[3].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[4].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[4].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[5].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[5].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[6].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[6].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[7].dragMap.numOmega > (Dt_UINT16_1_0)vmdlTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->gearBox.gear[7].dragMap.numTorque > (Dt_UINT16_1_0)(vmdlDRAGCOUNT / vmdlTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->engine.consumptionMap.numOmega > (Dt_UINT16_1_0)vmdlCONSTORQUECOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->engine.consumptionMap.numTorque > (Dt_UINT16_1_0)(vmdlCONSPOWERCOUNT / vmdlCONSTORQUECOUNT)) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->simple.powerMap.numVelocity > (Dt_UINT16_1_0)vmdlSIMPLEPOWERCOUNT) { return false; }
	if((Dt_UINT16_1_0)p_theDestData->simple.powerMap.numForce > (Dt_UINT16_1_0)(vmdlSIMPLEPOWERCOUNT / vmdlSIMPLEFORCECOUNT)) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->gearBox.numGears > (Dt_UINT8_1_0)gearEOF) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->gearBox.numGears < (Dt_UINT8_1_0)1) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->engine.thrustLine.numOmega > (Dt_UINT8_1_0)vmdlTHRUSTTORQUECOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->engine.torqueRate.numOmega > (Dt_UINT8_1_0)vmdlTORQUERATECOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->engine.minRefTorque.numOmega > (Dt_UINT8_1_0)vmdlREFTORQUECOUNT) { return false; }
	if((Dt_UINT8_1_0)p_theDestData->misc.codeList.count > (Dt_UINT8_1_0)vmdlCODECOUNT) { return false; }

	return true;
}
/*lint -restore */

