#ifndef guard_vmdlMisc_h
#define guard_vmdlMisc_h


/** \brief	Gibt den Anpassfaktor f�r zul�ssige Querbeschleunigungen zur�ck, der im Fahrzeugmodell hinterlegt ist */
void		   vmdlMsGetCurveFactor(IN	const	miscModel_T				*misc,					/**< interne Datenstruktur des Restmodells */
									OUT			real32_T				*factor					/**< Anpassfaktor f�r die zul�ssige Querbeschleunigung [1] */
									);


/**\brief Gibt `valid = true` aus, wenn der `motorCode` in der Liste erlaubter Motorcodes f�r dieses Fahrzeugmodell abgelegt ist.
Ist keine Liste hinterlegt (`count = 0`), wird jeder beliebige `motorCode` als g�ltig ausgewertet.
*/
void		 vmdlMsIsMotorCodeValid(IN	const	vehicleModel_T		*vehicleModel,				/**< Fahrzeugmodell */
									IN	const	uint8_T				 motorCode,					/**< Motorcode*/
									OUT			bool_T				*valid						/**< true, wenn der Motorcode erlaubt ist.*/
									);


#endif
