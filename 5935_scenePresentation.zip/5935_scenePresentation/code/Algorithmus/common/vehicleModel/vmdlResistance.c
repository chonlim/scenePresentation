#include "common/common.h"
#include "vehicleModel_private.h"
#include "vmdlResistance.h"
#include "vmdlResistanceStatic.h"
#include "vmdlResistanceTypes.h"
#include "vmdlSingleTrack.h"

#include "common/vehicleObserverCommon/vobsDataInterface.h"

#define vmdlGRAVITY				(9.810000f)


void		  vmdlResGetResistanceForce(IN	const	resistanceModel_T		*resistance,
										IN	const	singleTrackModel_T		*singleTrack,
										IN	const	resistanceFactors_T		*factors,
										IN	const	real32_T				 deviation,
										OUT			real32_T				*resForce)
{
	real32_T curveForce;
	real32_T velocityForce;
	real32_T slopeForce;


	vmdlResGetCurveForce( singleTrack,
						  factors->velocity,
						  factors->curvature,
						 &curveForce);

	vmdlResGetVelocityForce( resistance,
							 factors->velocity,
							&velocityForce);

	vmdlResGetSlopeForce( resistance,
						  factors->slope,
						 &slopeForce);


	/* Ausgabe */
	*resForce = curveForce + velocityForce + slopeForce + deviation;
}


void		 vmdlResGetResistanceForces(IN	const	resistanceModel_T		*resistance,
										IN	const	singleTrackModel_T		*singleTrack,
										IN	const	resistanceFactors_T		*factors,
										IN	const	deviationState_T		*deviationState,
										OUT			real32_T				*resForceOn,
										OUT			real32_T				*resForceOff)
{
	real32_T curveForce;
	real32_T velocityForce;
	real32_T slopeForce;
	real32_T resDevOn;
	real32_T resDevOff;


	/* Zugkraftabweichung abfragen */
	vobsGetResDeviation(deviationState,	simpleStateOn,	&resDevOn);
	vobsGetResDeviation(deviationState,	simpleStateOff,	&resDevOff);


	vmdlResGetCurveForce( singleTrack,
						  factors->velocity,
						  factors->curvature,
						 &curveForce);

	vmdlResGetVelocityForce( resistance,
							 factors->velocity,
							&velocityForce);

	vmdlResGetSlopeForce( resistance,
						  factors->slope,
						 &slopeForce);


	/* Ausgabe */
	*resForceOn  = curveForce + velocityForce + slopeForce + resDevOn;
	*resForceOff = curveForce + velocityForce + slopeForce + resDevOff;
}


void		vmdlResGetResistanceFactors(IN	const	real32_T				 velocity,
										IN	const	real32_T				 curvature,
										IN	const	real32_T				 slope,
										OUT			resistanceFactors_T		*factors)
{
	factors->velocity	= velocity;
	factors->curvature	= curvature;
	factors->slope		= slope;
}


void			 vmdlResGetAcceleration(IN	const	resistanceModel_T		*resistance,
										IN	const	simpleOffset_T			 offset,
										IN	const	real32_T				 force,
										OUT			real32_T				*acceleration)
{
	*acceleration = (force - offset) / resistance->mass;
}


void					vmdlResGetForce(IN	const	resistanceModel_T		*resistance,
										IN	const	simpleOffset_T			 offset,
										IN	const	real32_T				 acceleration,
										OUT			real32_T				*force)
{
	*force = (acceleration * resistance->mass) + offset;
}


static void		   vmdlResGetCurveForce(IN	const	singleTrackModel_T		*singleTrack,
										IN	const	real32_T				 velocity,
										IN	const	real32_T				 curvature,
										OUT			real32_T				*curveForce)
{
	real32_T forceY;


	/* Berechnen der Fliehkraft */
	forceY = curvature * velocity;


	/* Berechnen der Fahrwiderstandskraft */
	vmdlSgTrGetCurveForce( singleTrack,
						   forceY,
						   curveForce);
}


static void		   vmdlResGetSlopeForce(IN	const	resistanceModel_T		*resistance,
										IN	const	real32_T				 slope,
										OUT			real32_T				*force)
{
	*force = resistance->mass * vmdlGRAVITY * slope;
}


static void		vmdlResGetVelocityForce(IN	const	resistanceModel_T		*resistance,
										IN	const	real32_T				 velocity,
										OUT			real32_T				*velocityForce)
{
	*velocityForce = (resistance->coastingCoefficients.a)
				   + ((resistance->coastingCoefficients.b)
				      + (resistance->coastingCoefficients.c * velocity)) * velocity;
}


bool_T	vmdlResGetMaxAccelerationForWheelPower(	IN	const	vehicleModel_T		*vehicleModel,
												IN	const	real32_T			 maxWheelPower,
												IN	const	real32_T			 curvature,
												IN	const	real32_T			 slope,
												IN	const	real32_T			 resistanceDeviation,
												IN	const	real32_T			 currentVelocity,
												IN	const	real32_T			 currentAcceleration,
												IN	const	real32_T			 deltaT,
												INOUT		real32_T			*maxAcceleration)
{
	/* Koeffizienten des Polynoms */
	real32_T a;
	real32_T b;
	real32_T c;
	real32_T d;

	/* aktueller Schritt des Newton Verfahrens */
	uint8_T step;
	real32_T x;

	/* vehicleModel Zwischenergebnisse */
	real32_T curveForce;
	real32_T slopeForce;
	resistanceFactors_T	resFactors;

	/* Zwischenergebnisse berechnen */
	real32_T e;
	real32_T deltaT2 = deltaT * deltaT;
	real32_T deltaT3 = deltaT2 * deltaT;
	real32_T z = currentVelocity + deltaT * currentAcceleration * 0.5f;
	real32_T z_z_CoeC_plus_z_CoeB = z * (z * vehicleModel->resistance.coastingCoefficients.c + vehicleModel->resistance.coastingCoefficients.b);
	/*real32_T z_CoeC = z * vehicleModel->resistance.coastingCoefficients.c;
	real32_T z_CoeC_deltaT_half = z_CoeC * deltaT * 0.5f;
	real32_T z_CoeC_deltaT_half_plus_mass = z_CoeC_deltaT_half + vehicleModel->resistance.mass;*/

	vmdlResGetResistanceFactors(currentVelocity,
								curvature,
								slope,
								&resFactors);

	vmdlResGetCurveForce(	&vehicleModel->singleTrack,
							resFactors.velocity,
							resFactors.curvature,
							&curveForce);

	vmdlResGetSlopeForce(	&vehicleModel->resistance,
							resFactors.slope,
							&slopeForce);


	e = vehicleModel->resistance.coastingCoefficients.a + curveForce + slopeForce + resistanceDeviation;
		
	a = deltaT3 * vehicleModel->resistance.coastingCoefficients.c * 0.125f;
	b = deltaT2 * 0.25f * (3.0f * z * vehicleModel->resistance.coastingCoefficients.c + vehicleModel->resistance.coastingCoefficients.b)
		+ deltaT*vehicleModel->resistance.mass*0.5f;
		/*deltaT2 * z_CoeC * 0.25f
		+ z_CoeC_deltaT_half
		+ deltaT * vehicleModel->resistance.coastingCoefficients.b * 0.5f
		+ z_CoeC_deltaT_half_plus_mass;*/
	c = z * z * vehicleModel->resistance.coastingCoefficients.c * 1.5f * deltaT
		+ z * (vehicleModel->resistance.coastingCoefficients.b * deltaT + vehicleModel->resistance.mass)
		+ e * deltaT * 0.5f;
	d = z * (e + z_z_CoeC_plus_z_CoeB) - maxWheelPower;

	/* Newton Verfahren berechnen */
	x = *maxAcceleration;
	for (step = 0; step < 2u; step++)
	{
		real32_T xSq;
		real32_T fx;
		real32_T dfx_dx;

		xSq = x * x;
		fx = a * xSq * x + b * xSq + c * x + d;
		dfx_dx = 3.0f * a * xSq + 2.0f * b * x + c;
		x = x - fx / dfx_dx;
		if (dfx_dx == 0.0f) {
			x = *maxAcceleration;
		} else {
			*maxAcceleration = x;
		}
	}

	return true;
}
