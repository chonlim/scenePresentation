#include "common/common.h"
#include "vehicleModel_private.h"
#include "vmdlSimple.h"
#include "vmdlSimpleTypes.h"
#include "vmdlResistance.h"
#include "vmdlResistanceTypes.h"
#include "vmdlMap.h"
#include "vmdlGearBox.h"


#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_vmdlSimple)


bool_T				   vmdlSmpGetLimits(IN	const	simpleModel_T			*simpleModel,
										IN	const	resistanceModel_T		*resistanceModel,
										IN	const	singleTrackModel_T		*singleTrackModel,
										IN	const	gearBoxModel_T			*gearBoxModel,
										IN	const	resistanceFactors_T		*resFactors,
										IN	const	deviationState_T		*deviationState,
										OUT			real32_T				*maxAcceleration,
										OUT			real32_T				*minAcceleration,
										OUT			real32_T				*coastMaxAcceleration,
										OUT			real32_T				*coastMinAcceleration,
										OUT			simpleOffset_T			*simpleOffset)
{
	real32_T	resistanceOn;
	real32_T	resistanceOff;

	real32_T	invStep;
	uint16_T	indexVelocity;
	real32_T	deltaVelocity;
	real32_T	forceMax;
	real32_T	forceMin;

	real32_T	aCoastMax;
	real32_T	aCoastMin;
	real32_T	aMax;
	real32_T	aMin;


	/* Abfragen der Fahrwiderst�nde bei offenem und geschlossenem Triebstrang */
	vmdlResGetResistanceForces( resistanceModel,
							    singleTrackModel,
							    resFactors,
							    deviationState,
							   &resistanceOn,
							   &resistanceOff);


	/* Berechnen der Beschleunigung bei offenem Triebstrang */
	diagFF(vmdlGBTorqueToAcceleration( gearBoxModel,
									   0.0f,
									   resistanceOff,
									   resFactors->velocity,
									   gearCoast,
									  &aCoastMax));


	/* Berechnen der minimal zul�ssigen Beschleunigung bei offenem Triebstrang */
	aCoastMin = aCoastMax + simpleModel->coastLimit;


	/* Maximal und minimal m�gliche "Motorbeschleunigung" berechnen */
	diagFF(vmdlMapGetInvStep(&simpleModel->powerMap.velocity,
							  simpleModel->powerMap.numVelocity,
							 &invStep));

	diagFF(vmdlMapInterpolateAxis(&simpleModel->powerMap.velocity,
								   invStep,
								   simpleModel->powerMap.numVelocity,
								   resFactors->velocity,
								  &indexVelocity,
								  &deltaVelocity));

	forceMax = (1.0f - deltaVelocity) * simpleModel->powerMap.force[indexVelocity].max
			 + (deltaVelocity)        * simpleModel->powerMap.force[indexVelocity+1u].max;

	forceMin = (1.0f - deltaVelocity) * simpleModel->powerMap.force[indexVelocity].min
			 + (deltaVelocity)        * simpleModel->powerMap.force[indexVelocity+1u].min;


	vmdlResGetAcceleration( resistanceModel,
						    resistanceOn,
						    forceMax,
						   &aMax);

	vmdlResGetAcceleration( resistanceModel,
						    resistanceOn,
						    forceMin,
						   &aMin);


	/* Ausgabe */
	*maxAcceleration		= aMax;
	*minAcceleration		= aMin;
	*coastMaxAcceleration	= aCoastMax;
	*coastMinAcceleration	= aCoastMin;
	*simpleOffset			= resistanceOn;


	return true;
}


bool_T				   vmdlSmpPreSelect(IN	const	simpleModel_T			*simpleModel,
										IN	const	real32_T				 velocity,
										IN	const	simpleOffset_T			*offset,
										OUT			simplePowerPreSel_T		*preSel)
{
	/* Vorauswahl des Kennfelds */
	diagFF(vmdlMapPreSelInit(&simpleModel->powerMap.velocity,
							  simpleModel->powerMap.force,
							  simpleModel->powerMap.numVelocity,
							  simpleModel->powerMap.numForce,
							  velocity,
							  simpleModel->powerMap.power.data,
							 &preSel->map));


	/* Ablegen des Offset */
	preSel->offset = *offset;


	return true;
}


bool_T					vmdlSmpGetPower(IN	const	resistanceModel_T		*resistanceModel,
										IN	const	simpleModel_T			*simpleModel,
										IN	const	simplePowerPreSel_T		*preSel,
										IN	const	simpleState_T			 simpleState,
										IN	const	real32_T				 acceleration,
										OUT			real32_T				*simplePower)
{
	real32_T force;
	real32_T scaled;
	real32_T mapPower;


	/* Berechnen der erforderlichen Zugkraft */
	vmdlResGetForce( resistanceModel,
					 preSel->offset,
					 acceleration,
					&force);


	/* Interpolation auf dem skalierten Kennfeld */
	diagFF(vmdlMapPreSelInterpolate(&preSel->map,
									 force,
									&scaled));

	mapPower = simpleModel->powerMap.power.min + (scaled * simpleModel->powerMap.power.factor);


	/* Bei geschlossenem Triebstrang ist das Kennfelds relevant, andernfalls die idlePower */
	*simplePower = (simpleStateOn == simpleState) ? mapPower : simpleModel->idlePower;


	return true;
}
