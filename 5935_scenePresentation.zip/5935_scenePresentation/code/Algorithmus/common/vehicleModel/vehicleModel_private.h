#ifndef guard_vehicleModel_private_h
#define guard_vehicleModel_private_h

#include "common/vehicleModel/vehicleModel_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define vmdlTORQUECOUNT 12               /**< Maximale Anzahl gueltiger Eingangsmoment-Datenpunkte */
#define vmdlDRAGCOUNT 144                /**< Maximale Anzahl gueltiger Verlustmoment-Datenpunkte */
#define vmdlTHRUSTTORQUECOUNT 16         /**< Maximale Anzahl gueltiger Schleppmoment-Datenpunkte */
#define vmdlTORQUERATECOUNT 16           /**< Maximale Anzahl gueltiger Anpassraten-Datenpunkte */
#define vmdlREFTORQUECOUNT 16            /**< Maximale Anzahl gueltiger Referenzmomenten-Datenpunkte */
#define vmdlCONSTORQUECOUNT 16           /**< Maximale Anzahl gueltiger Drehmoment-Datenpunkte im Verbrauchskennfeld */
#define vmdlCONSPOWERCOUNT 256           /**< Maximale Anzahl gueltiger Leistungs-Datenpunkte im Verbrauchskennfeld */
#define vmdlSIMPLEFORCECOUNT 32          /**< Maximale Anzahl gueltiger Geschwindigkeits-Datenpunkte im vereinfachten Leistungskennfeld */
#define vmdlSIMPLEPOWERCOUNT 1024        /**< Maximale Anzahl gueltiger Leistungs-Datenpunkte im vereinfachten Leistungskennfeld */
#define vmdlCODECOUNT 5                  /**< Maximale Anzahl gueltiger Motorcodes */



typedef struct _resistanceModel {
	real32_T mass;                       /**< Fahrzeugmasse[kg] */
	struct _resistanceModel_coastingCoefficients {
		real32_T a;                      /**< Konstanter Anteil des Fahrwiderstands[N] */
		real32_T b;                      /**< v-abhaengiger Anteil des Fahrwiderstands[Ns/m] */
		real32_T c;                      /**< v^2-abhaengiger Anteil des Fahrwiderstands[Ns²/m²] */
	} coastingCoefficients;
} resistanceModel_T;                     /**< Groesse der Struktur = 16 Bytes */

typedef struct _singleTrackModel {
	real32_T mass;                       /**< Masse des Fahrzeugs[kg] */
	real32_T length;                     /**< Radstand[m] */
	real32_T steeringRatio;              /**< Lenkuebersetzung[1] */
	real32_T steeringRatioRAS;           /**< Lenkuebersetzung bei verbauter Hinterachslenkung[1] */
	real32_T eg;                         /**< Eigenlenkgradient[1] */
	real32_T egRAS;                      /**< Eigenlenkgradient bei verbauter Hinterachslenkung[1] */
	real32_T lengthFront;                /**< Abstand der Vorderachse vom Fahrzeugschwerpunkt[m] */
	real32_T lengthRear;                 /**< Abstand der Hinterachse vom Fahrzeugschwerpunkt[m] */
	real32_T cR;                         /**< Seitenkraftbeiwerte Vorderachse[N/rad] */
	real32_T cF;                         /**< Seitenkraftbeiwerte Hinterachse[N/rad] */
} singleTrackModel_T;                    /**< Groesse der Struktur = 40 Bytes */

typedef struct _dragMap {
	uint16_T numOmega;                   /**< Anzahl gueltiger Elemente auf der Drehzahl-Achse */
	uint16_T numTorque;                  /**< Anzahl gueltiger Elemente auf der Drehmoment-Achse */
	mapAxis_T omega;                     /**< Drehzahl-Achse des Kennfelds[rad/s] */
	mapAxis_T torque[vmdlTORQUECOUNT];   /**< Drehmoment-Achse des Kennfelds[Nm] */
	struct _dragMap_drag {
		real32_T min;                    /**< Minimales Verlustmoment[Nm] */
		real32_T factor;                 /**< Differenz zwischen minimalem und maximalem Verlustmoment[Nm] */
		uint8_T data[vmdlDRAGCOUNT];
	} drag;
} dragMap_T;                             /**< Groesse der Struktur = 260 Bytes */

typedef struct _gearBoxModel {
	uint8_T numGears;                    /**< Anzahl moeglicher Gaenge */
	bool_T requestAllowed;               /**< Sind Ganganforderungen zulaessig? */
	bool_T useSumTorque;                 /**< Gibt an, ob das vom Motor gemeldete Summenmoment als Antriebsmoment herangezogen werden soll */
	real32_T requestOffset;              /**< Offset fuer Uebersetzungsanforderungen ans Getriebe[1] */
	real32_T iDiff;                      /**< Uebersetzungsverhaeltnis des Hinterachsdifferenzials[1] */
	real32_T wheelRadius;                /**< Radius der angetriebenen Raeder[m] */
	real32_T auxDiff;                    /**< Uebersetzungsverhaeltnis des Vorderachsdifferenzials[1] */
	real32_T auxRadius;                  /**< Radius der Vorderräder[m] */
	real32_T minOmega;                   /**< Minimal moegliche Motordrehzahl[rad/s] */
	real32_T maxOmega;                   /**< Maximal moegliche Motordrehzahl[rad/s] */
	struct _gearBoxModel_coasting {
		bool_T possible;                 /**< Gibt an, ob Segeln prinzipiell moeglich ist */
		real32_T minVelocity;            /**< Minimale Geschwindigkeit fuer Segeln[m/s] */
		real32_T maxVelocity;            /**< Maximale Geschwindigkeit fuer Segeln[m/s] */
	} coasting;
	struct _gearBoxModel_gear {
		real32_T transmissionRatio;      /**< uebersetzungsverhaeltnis des Gangs[1] */
		real32_T invInertia;             /**< Invertierte aequivalente Traegheit des Fahrzeugs in diesem Gang[m/Nms] */
		dragMap_T dragMap;               /**< Verlustkennfeld des Gangs */
	} gear[gearEOF];
} gearBoxModel_T;                        /**< Groesse der Struktur = 2188 Bytes */

typedef struct _thrustLine {
	uint8_T numOmega;                    /**< Anzahl gueltiger Drehzahl-Datenpunkte */
	mapAxis_T omega;                     /**< Drehzahl-Achse der Kennlinie[rad/s] */
	struct _thrustLine_torque {
		real32_T min;                    /**< Minimales Schleppmoment[Nm] */
		real32_T factor;                 /**< Differenz zwischen minimalem und maximalem Schleppmoment[Nm] */
		uint8_T data[vmdlTHRUSTTORQUECOUNT];
	} torque;
} thrustLine_T;                          /**< Groesse der Struktur = 36 Bytes */

typedef struct _rateLine {
	uint8_T numOmega;                    /**< Anzahl gueltiger Drehzahl-Datenpunkte */
	mapAxis_T omega;                     /**< Drehzahl-Achse der Kennlinie[rad/s] */
	struct _rateLine_rate {
		real32_T min;                    /**< Minimale zulaessige Anpassrate des Antriebsmoments[Nm/s] */
		real32_T factor;                 /**< Differenz zwischen minimaler und maximaler zulaessiger Anpassrate des Antriebsmoments[Nm/s] */
		uint8_T data[vmdlTORQUERATECOUNT];
	} rate;
} rateLine_T;                            /**< Groesse der Struktur = 36 Bytes */

typedef struct _minRefLine {
	uint8_T numOmega;                    /**< Anzahl gueltiger Drehzahl-Datenpunkte */
	mapAxis_T omega;                     /**< Drehzahl-Achse der Kennlinie[rad/s] */
	struct _minRefLine_torque {
		real32_T min;                    /**< Minimales Referenzmoment[Nm] */
		real32_T factor;                 /**< Differenz zwischen minimalem und maximalem Referenzmoment[Nm] */
		uint8_T data[vmdlREFTORQUECOUNT];
	} torque;
} minRefLine_T;                          /**< Groesse der Struktur = 36 Bytes */

typedef struct _consumptionMap {
	uint16_T numOmega;                   /**< Anzahl gueltiger Datenpunkte auf der Omega-Achse */
	uint16_T numTorque;                  /**< Anzahl gueltiger Datenpunkte auf der Drehmoment-Achse */
	mapAxis_T omega;                     /**< Drehzahl-Achse des Kennfelds[rad/s] */
	mapAxis_T torque[vmdlCONSTORQUECOUNT]; /**< Drehmoment-Achse des Kennfelds[Nm] */
	struct _consumptionMap_power {
		real32_T min;                    /**< Minimales Eingangsleistung[W] */
		real32_T factor;                 /**< Differenz zwischen minimaler und maximaler Eingangsleistung[W] */
		uint8_T data[vmdlCONSPOWERCOUNT];
	} power;
} consumptionMap_T;                      /**< Groesse der Struktur = 404 Bytes */

typedef struct _engineModel {
	thrustLine_T thrustLine;             /**< Kennlinie des drehzahlabhaengigen Schleppmoments */
	rateLine_T torqueRate;               /**< Kennlinie der drehzahlabhaengigen zulaessigen Anpassrate des Antriebsmoments */
	minRefLine_T minRefTorque;           /**< Kennlinie der drehzahlabhaengigen zulaessigen Anpassrate des Antriebsmoments */
	consumptionMap_T consumptionMap;     /**< Kennfeld des Verbrauchs in Abhaengigkeit von Drehzahl und Drehmoment */
	struct _engineModel_torqueReserve {
		real32_T absolute;               /**< Absoluter Momentenvorhalt beim Hochschalten[Nm] */
		real32_T factor;                 /**< Multiplikationsfaktor fuer den relativen Momentvorhalten beim Hochschalten[1] */
	} torqueReserve;
	real32_T thrustPower;                /**< Eingangsleistung im Schubbetrieb[W] */
	real32_T cutoffMinOmega;             /**< Minimaldrehzahl fuer Schubabschaltung[rad/s] */
	real32_T ePowerAccelOffset;          /**< Sicherheitsoffset auf maximal mögliche Beschleunigung des E-Motors[m/s^2] */
} engineModel_T;                         /**< Groesse der Struktur = 532 Bytes */

typedef struct _simplePowerMap {
	uint16_T numVelocity;                /**< Anzahl gueltiger Datenpunkte auf der Geschwindigkeits-Achse */
	uint16_T numForce;                   /**< Anzahl gueltiger Datenpunkte auf der Zugkraft-Achse */
	mapAxis_T velocity;                  /**< Geschwindigkeits-Achse des Kennfelds */
	mapAxis_T force[vmdlSIMPLEFORCECOUNT]; /**< Zugkraft-Achse des Kennfelds */
	struct _simplePowerMap_power {
		real32_T min;                    /**< Minimale Eingangsleistung[W] */
		real32_T factor;                 /**< Differenz zwischen minimaler und maximaler Eingangsleistung im Kennfeld[W] */
		uint8_T data[vmdlSIMPLEPOWERCOUNT];
	} power;
} simplePowerMap_T;                      /**< Groesse der Struktur = 1300 Bytes */

typedef struct _simpleModel {
	simplePowerMap_T powerMap;           /**< Vereinfachtes Leistungskennfeld */
	real32_T idlePower;                  /**< Leistungsbedarf bei geoeffnetem Triebstrang[W] */
	real32_T coastLimit;                 /**< Maximale negative Beschleunigung, die bei geöffnetem Triebstrang über die Betriebsbremse gestellt werden darf[m/s²] */
} simpleModel_T;                         /**< Groesse der Struktur = 1308 Bytes */

typedef struct _miscModel {
	real32_T curveFactor;                /**< Fahrzeugspezifische Anpassung der zulaessigen Querbeschleunigung[1] */
	struct _miscModel_codeList {
		uint8_T code[vmdlCODECOUNT];     /**< Liste gueltiger Motorcodes */
		uint8_T count;                   /**< Anzahl gueltiger Motorcodes */
	} codeList;
} miscModel_T;                           /**< Groesse der Struktur = 12 Bytes */

struct _vehicleModel {
	bool_T valid;                        /**< Gibt an, ob das Fahrzeugmodell gueltig ist */
	uint32_T checksumCrc32;              /**< Berechnung der crc ueber alle Variablennamen zur Verifikation der Struktur */
	resistanceModel_T resistance;        /**< Fahrwiderstandsmodell */
	singleTrackModel_T singleTrack;      /**< Einspurmodell */
	gearBoxModel_T gearBox;              /**< Getriebemodell */
	engineModel_T engine;                /**< Antriebsmodell */
	simpleModel_T simple;                /**< Vereinfachtes Energiebedarfmodell */
	miscModel_T misc;                    /**< Restmodell */
	uint16_T bufferSize;                 /**< Groesse des debugBuffers */
} ;                                      /**< Groesse der Struktur = 4460 Bytes */


/*lint -restore */

#endif
