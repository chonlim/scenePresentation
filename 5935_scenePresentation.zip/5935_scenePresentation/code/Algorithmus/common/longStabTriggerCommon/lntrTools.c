#include "lntrTools.h"
#include "common/longStabTriggerCommon/longStabTrigger_private.h"


void		lntrGetPriorityTick(IN	const	longTrigger_T		*longTrigger,
								OUT			uint32_T			*priorityTick)
{
	*priorityTick = longTrigger->priorityTick;
}
