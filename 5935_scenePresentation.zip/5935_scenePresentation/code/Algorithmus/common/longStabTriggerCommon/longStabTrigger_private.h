#ifndef guard_longStabTrigger_private_h
#define guard_longStabTrigger_private_h

#include "common/longStabTriggerCommon/longStabTrigger_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */




struct _triggerMemory {
	uint32_T priorityTick;               /**< Tick-Count zum Zeitpunkt der letzten Prio-Anforderung für die Stabilisierungsebene */
	bool_T trafficPresent;               /**< Ist aktuell ein Zielfahrzeug */
	uint8_T rerouteCount;                /**< Letzter bekannter Reroute-Count */
	uint8_T posResetCount;               /**< Letzter bekannter Position-Reset-Count */
	bool_T autoMode;                     /**< Letzter bekannter AutoMode-Zustand */
	real32_T setVelocity;                /**< Aktuelle Setzgeschwindigkeit[m/s] */
	real32_T setPosition;                /**< Gültigkeitsbeginn der aktuellen Setzgeschwindigkeit[m] */
	sysLongMode_T longMode;              /**< Letzter bekannter Charisma-Zustand */
} ;                                      /**< Groesse der Struktur = 20 Bytes */

struct _longTrigger {
	uint32_T priorityTick;               /**< Tick-Count zum Zeitpunkt der letzten Prio-Anforderung für die Stabilisierungsebene */
} ;                                      /**< Groesse der Struktur = 4 Bytes */


/*lint -restore */

#endif
