#ifndef guard_longStabTrigger_interface_h
#define guard_longStabTrigger_interface_h

#include "base.h"
#include "common/systemControllerCommon/systemController_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef struct _triggerMemory triggerMemory_T;
typedef struct _longTrigger longTrigger_T;



/*lint -restore */

#endif
