#ifndef guard_lntrTools_h
#define guard_lntrTools_h

#include "common/common.h"
#include "common/longStabTriggerCommon/longStabTrigger_interface.h"


void		lntrGetPriorityTick(IN	const	longTrigger_T		*longTrigger,
								OUT			uint32_T			*priorityTick);


#endif
