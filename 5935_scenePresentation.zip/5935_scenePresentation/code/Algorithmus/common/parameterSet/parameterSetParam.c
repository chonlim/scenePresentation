#include "parameterSet.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_parameterSetParam)


bool_T				 prmInterpolate(IN	const	real32_T		*vectorX,
									IN	const	real32_T		*vectorY,
									IN	const	uint16_T		 count,
									IN	const	uint16_T		 maxCount,
									IN	const	real32_T		 x,
									OUT			real32_T		*y)
{
	uint16_T	index;
	real32_T	xAdj;

	real32_T	delta;
	real32_T	value;


	/* Sicherstellen, dass wir g�ltige Werte bekommen haben */
	diagFF(count > 0u);
	diagFF(count <= maxCount);


	/* Einschr�nken der Suche auf den zul�ssigen Bereich */
	xAdj	= x;
	xAdj	= max(xAdj, vectorX[0]);
	xAdj	= min(xAdj, vectorX[count-1u]);


	/* Suche nach dem relevanten Segment */
	for(index = 0; index < (uint16_T)(count - 1u); index++) {
		if(vectorX[index+1u] >= xAdj) {
			break; 
		}
	}


	/* Interpolation */
	delta	= (xAdj - vectorX[index]) / (vectorX[index+1u] - vectorX[index]);
	value	= vectorY[index] + delta * (vectorY[index+1u] - vectorY[index]);


	/* Wenn es nur einen Datenpunkt gibt, haben wir auch nichts zu interpolieren */
	if(count == 1u) {
		value = vectorY[0];
	}


	diagFNaN(value);


	/* "Verbrennen" der �bersch�ssigen Rechenzeit */
	for(; index < (uint16_T)(maxCount - 1u); index++) {
		if(vectorX[index+1u] >= xAdj) {
			continue;
		}
	}


	/* Ausgabe */
	*y	= value;


	return true;
}
