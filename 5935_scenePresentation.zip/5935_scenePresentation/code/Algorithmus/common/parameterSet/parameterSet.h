#ifndef guard_parameterSet_h
#define guard_parameterSet_h

#include "common/common.h"


/** \brief	F�hrt eine lineare Interpolation auf einer Parameter-Kennlinie durch 
\spec SwMS_Innodrive2_Model_59
*/
bool_T				 prmInterpolate(IN	const	real32_T		*vectorX,		/**< Zeiger auf den X-Vektor der Kennlinie */
									IN	const	real32_T		*vectorY,		/**< Zeiger auf den Y-Vektor der Kennlinie */
									IN	const	uint16_T		 count,			/**< Anzahl g�ltiger Datenpunkte in der Kennlinie */
									IN	const	uint16_T		 maxCount,		/**< Maximale Anzahl m�glicher g�ltiger Datenpunkte (erforderlich f�r konstante Laufzeit) */
									IN	const	real32_T		 x,				/**< X-Wert, f�r den die Kennlinie abgefragt werden soll */
									OUT			real32_T		*y				/**< Y-Wert, der sich aus der Kennlinie ergibt */
									);


/** \} */

#endif

