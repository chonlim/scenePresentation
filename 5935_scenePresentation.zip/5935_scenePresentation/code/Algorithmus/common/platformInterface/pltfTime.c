#include "pltfTime.h"

#if !defined(INNODRIVE_ZFAS_SWC_BUILD) 
#pragma warning(disable : 4668)
#pragma warning(disable : 4255)

#include <intrin.h>
#pragma intrinsic(__rdtsc)

#endif

#ifdef __CTC__
#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
#endif
static real32_T	(*ptrADTFGetStreamTime)(void);
static real64_T	(*ptrADTFGetHighPerfTime)(void);
static real64_T	(*ptrClockGetStreamTime)(void);
#ifdef __CTC__
#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
#endif


/*! Registriert die `adtfGetStreamTime`-Funktion in der DLL. */
/*lint -esym(765,pltfRegisterGetStreamTimeCallback)*/
/*lint -esym(759,pltfRegisterGetStreamTimeCallback)*/
/*lint -esym(714,pltfRegisterGetStreamTimeCallback)*/
void	pltfRegisterGetStreamTimeCallback(real32_T	(*adtfGetStreamTime)(void))
{
	ptrADTFGetStreamTime = adtfGetStreamTime;
}
				  

/*! Registriert die `_clock->GetStreamTime()`-Funktion in der DLL. */
/*lint -esym(765,pltfRegisterClockGetStreamTime)*/
/*lint -esym(759,pltfRegisterClockGetStreamTime)*/
/*lint -esym(714,pltfRegisterClockGetStreamTime)*/
void	pltfRegisterClockGetStreamTime(real64_T(*clockGetStreamTime)(void))
{
	ptrClockGetStreamTime = clockGetStreamTime;
}


/*! L�cht den Verweis auf _clock->GetStreamTime() */
/*lint -esym(765,pltfUnregisterClockGetStreamTime)*/
/*lint -esym(759,pltfUnregisterClockGetStreamTime)*/
/*lint -esym(714,pltfUnregisterClockGetStreamTime)*/
void pltfUnregisterClockGetStreamTime(void)
{
	ptrClockGetStreamTime = NULL;
}
			  

/*! Registriert die `adtfGetHighPerfTime`-Funktion in der DLL. */
/*lint -esym(765,pltfRegisterGetHighPerfTimeCallback)*/
/*lint -esym(759,pltfRegisterGetHighPerfTimeCallback)*/
/*lint -esym(714,pltfRegisterGetHighPerfTimeCallback)*/
void	pltfRegisterGetHighPerfTimeCallback(real64_T	(*adtfGetHighPerfTime)(void))
{
	ptrADTFGetHighPerfTime = adtfGetHighPerfTime;
}


#if defined(PLATFORM_MATLAB)
real32_T globalFirstTimeStamp;

real32_T pltfGetCurrentTime(void)
{
	LARGE_INTEGER	liPerfCounter;
	LARGE_INTEGER	liPerfFrequency;

	double			fPerfCounter;
	double			fPerfFrequency;
	double			fTime;

	QueryPerformanceCounter(&liPerfCounter);
	QueryPerformanceFrequency(&liPerfFrequency);

	fPerfCounter	= (real32_T)liPerfCounter.QuadPart;
	fPerfFrequency	= (real32_T)liPerfFrequency.QuadPart;

	if(globalFirstTimeStamp == 0)
	{
		globalFirstTimeStamp = (real32_T)fPerfCounter / fPerfFrequency;
		return 0.0f;
	}


	fTime = (fPerfCounter / fPerfFrequency) - globalFirstTimeStamp;

	return (real32_T)fTime;
}
#else
/*! Gibt die Zeit in Sekunden seit "Einschalten des Steuerger�tes" zur�ck. */
/*! \warning Nicht verwenden, wenn man nicht sehr genau wei�, was man tut! */
/*lint -esym(759,pltfGetCurrentTime)*/
/*lint -esym(765,pltfGetCurrentTime)*/
/*lint -esym(714,pltfGetCurrentTime)*/
real32_T pltfGetCurrentTime(void)
{
	if (NULL != ptrClockGetStreamTime) {
		return (real32_T)(ptrClockGetStreamTime() / 1000000.0);
	}
	else if (NULL != ptrADTFGetStreamTime) {
		return ptrADTFGetStreamTime();
	}
	else {
		return 0.0f;
	}
}

/*! Gibt die aktuelle Zeit des High Performance-Counters in Sekunden zur�ck. */
/*! \warning Nicht verwenden, wenn man nicht sehr genau wei�, was man tut! */
/*lint -esym(765, pltfGetHighPerfTime) */
real64_T pltfGetHighPerfTime(void)
{
	if (NULL != ptrADTFGetHighPerfTime) { return ptrADTFGetHighPerfTime(); }
	
	return 0.0;
}


#if !defined(INNODRIVE_ZFAS_SWC_BUILD) 
uint64_T pltfGetProcessorCycles(void)
{
	return __rdtsc();
}
#else
uint64_T pltfGetProcessorCycles(void){
    return 0;
}
#endif

#endif
