#include "pltfDiag.h"

#ifndef INNODRIVE_ZFAS_SWC_BUILD
#include <stdio.h>
#endif

#ifdef __CTC__
#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
#endif
static void		(*ptrAdtfLogInfo)(const char_T *message);
static void		(*ptrAdtfLogWarning)(const char_T *message);
static void		(*ptrAdtfLogError)(const char_T *message);
static void		(*ptrErrorCallback)(void *userData, const diagModule_T module, const uint32_T line);
static void		(*ptrErrorUserData);
	#ifdef __CTC__
#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"
#endif

/*lint -efunc(9090, diagGetModuleName) (Note -- unconditional break missing from switch case [MISRA 2012 Rule 16.3, required])*/
/*lint -efunc(9077, diagGetModuleName) 9077: (Note -- missing unconditional break from final switch case [MISRA 2012 Rule 16.1, required], [MISRA 2012 Rule 16.3, required])*/
/*lint -esym(757,diagGetModuleName) 757: (Info -- external 'diagGetModuleName(diagModule_T)' (line 27, file pltfDiag.c) could be made static[MISRA 2012 Rule 8.7, advisory] */
/*lint -esym(759,diagGetModuleName) 759: (Info -- header declaration for symbol 'diagGetModuleName(diagModule_T)' defined at (line 27, file pltfDiag.c) could be moved from header to module)*/
/*lint -esym(765,diagGetModuleName)*/
/*lint -esym(714,diagGetModuleName)*/
/*return statt break*/
const char_T* diagGetModuleName(IN	const	diagModule_T		 module)
{
	switch(module) {
		case diagModule_ctmCurvature:		return "ctmCurvature";
		case diagModule_ctmDynamic:			return "ctmDynamic";
		case diagModule_ctmList:			return "ctmList";
		case diagModule_ctmObject:			return "ctmObject";
		case diagModule_ctmPrepare:			return "ctmPrepare";
		case diagModule_ctmSpeedLimit:		return "ctmSpeedLimit";
		case diagModule_ctmStatic:			return "ctmStatic";
		case diagModule_ctmSteering:		return "ctmSteering";
		case diagModule_ctmStop:			return "ctmStop";
		case diagModule_ctmTools:			return "ctmTools";
		case diagModule_ctmTraffic:			return "ctmTraffic";
		case diagModule_dobsDataInterface:	return "dobsDataInterface";
		case diagModule_dobsDynamicSet:		return "dobsDynamicSet";
		case diagModule_dobsVelocitySet:	return "dobsVelocitySet";
		case diagModule_dprdConstraints:	return "dprdConstraints";
		case diagModule_dprdDataInterface:	return "dprdDataInterface";
		case diagModule_dprdEnvironment:	return "dprdEnvironment";
		case diagModule_dprdOutput:			return "dprdOutput";
		case diagModule_dprdParameters:		return "dprdParameters";
		case diagModule_dprdStep:			return "dprdStep";
		case diagModule_dprdTrajectory:		return "dprdTrajectory";
		case diagModule_driverObserver:		return "driverObserver";
		case diagModule_lnclStep:			return "lnclStep";
		case diagModule_lnplLimits:			return "lnplLimits";
		case diagModule_lnplPrepare:		return "lnplPrepare";
		case diagModule_lnplTransition:		return "lnplTransition";
		case diagModule_lnptCore:			return "lnptCore";
		case diagModule_lnptLimits:			return "lnptLimits";
		case diagModule_lnptMemory:			return "lnptMemory";
		case diagModule_lnptSchedule:		return "lnptSchedule";
		case diagModule_lnptStateBoxes:		return "lnptStateBoxes";
		case diagModule_lnptStatePlane:		return "lnptStatePlane";
		case diagModule_lnptTools:			return "lnptTools";
		case diagModule_lnstCore:			return "lnstCore";
		case diagModule_lnstReference:		return "lnstReference";
		case diagModule_lnstTools:			return "lnstTools";
		case diagModule_lntqCore:			return "lntqCore";
		case diagModule_lntqLimits:			return "lntqLimits";
		case diagModule_lntqPrepare:		return "lntqPrepare";
		case diagModule_lntqTools:			return "lntqTools";
		case diagModule_outputCodec:		return "outputCodec";
		case diagModule_parameterSetParam:	return "parameterSetParam";
		case diagModule_pathRouter:			return "pathRouter";
		case diagModule_prtAttributes:		return "prtAttributes";
		case diagModule_prtDataInterface:	return "prtDataInterface";
		case diagModule_prtHeading:			return "prtHeading";
		case diagModule_prtInfo:			return "prtInfo";
		case diagModule_prtLoopBack:		return "prtLoopBack";
		case diagModule_prtPositionFilter:	return "prtPositionFilter";
		case diagModule_prtPrepare:			return "prtPrepare";
		case diagModule_prtRouteFilter:		return "prtRouteFilter";
		case diagModule_prtTools:			return "prtTools";
		case diagModule_prtTurnFilter:		return "prtTurnFilter";
		case diagModule_rprCrvMatching:		return "rprCrvMatching";
		case diagModule_rprCrvPulling:		return "rprCrvPulling";
		case diagModule_rprCrvSmoothing:	return "rprCrvSmoothing";
		case diagModule_rprCurvatures:		return "rprCurvatures";
		case diagModule_rprSlopes:			return "rprSlopes";
		case diagModule_rprSpeedLimits:		return "rprSpeedLimits";
		case diagModule_rprStep:			return "rprStep";
		case diagModule_rprStops:			return "rprStops";
		case diagModule_rprTools:			return "rprTools";
		case diagModule_sysAutoMode_obsolete:	return "obsolete (sysAutoMode)";
		case diagModule_sysDriverInput:		return "sysDriverInput";
		case diagModule_sysInfo:			return "sysInfo";
		case diagModule_sysManualMode_obsolete:	return "obsolete (sysManualMode)";
		case diagModule_sysOutput:			return "sysOutput";
		case diagModule_sysPermanentMode:	return "sysPermanentMode";
		case diagModule_sysSetSpeed:		return "sysSetSpeed";
		case diagModule_sysSpeedCheck:		return "sysSpeedCheck";
		case diagModule_sysSpeedLimit:		return "sysSpeedLimit";
		case diagModule_sysStatus:			return "sysStatus";
		case diagModule_sysStop:			return "sysStop";
		case diagModule_sysVelocityGrid:	return "sysVelocityGrid";
		case diagModule_systemController:	return "systemController";
		case diagModule_vmdlEngine:			return "vmdlEngine";
		case diagModule_vmdlGearBox:		return "vmdlGearBox";
		case diagModule_vmdlMap:			return "vmdlMap";
		case diagModule_vmdlSimple:			return "vmdlSimple";
		case diagModule_vmdlTools:			return "vmdlTools";
		case diagModule_vobsCourage:		return "vobsCourage";
		case diagModule_vobsCurvature:		return "vobsCurvature";
		case diagModule_vobsDeviation:		return "vobsDeviation";
		case diagModule_vobsHeading:		return "vobsHeading";
		case diagModule_vobsPowertrain:		return "vobsPowertrain";
		case diagModule_vobsSlope:			return "vobsSlope";
		case diagModule_vobsSteering:		return "vobsSteering";
		case diagModule_vobsStep:			return "vobsStep";
		case diagModule_vobsVelocity:		return "vobsVelocity";
		case diagModule_vobsVMax:			return "vobsVMax";
		case diagModule_Unknown:			return "Unknown";
		case diagModule_Info:				return "Info";
		default:							return "?_?_?";
	}
}

/*lint -efunc(9090, diagGetInfoText) (Note -- unconditional break missing from switch case [MISRA 2012 Rule 16.3, required])*/
/*lint -efunc(9077, diagGetInfoText) 9077: (Note -- missing unconditional break from final switch case [MISRA 2012 Rule 16.1, required], [MISRA 2012 Rule 16.3, required])*/
/*lint -esym(759,diagGetInfoText)*/
/*lint -esym(765,diagGetInfoText)*/
/*lint -esym(714,diagGetInfoText)*/
const char_T*		diagGetInfoText(IN	const	diagInfo_T			 info)
{
	switch(info) {
		case diagInfo_sysReasonMapMemory:					return "sysReasonMapMemory";
		case diagInfo_sysReasonRoadInfo:					return "sysReasonRoadInfo";
		case diagInfo_sysReasonSpeedLimit:					return "sysReasonSpeedLimit";
		case diagInfo_sysReasonCountryCode:					return "sysReasonCountryCode";
		case diagInfo_sysReasonStreetClass:					return "sysReasonStreetClass";
		case diagInfo_sysReasonStrategy:					return "sysReasonStrategy";
		case diagInfo_sysReasonACCinBOM:					return "sysReasonACCinBOM";
		case diagInfo_sysReasonACCerrorReversible:			return "sysReasonACCerrorReversible";
		case diagInfo_sysReasonACCerrorIrreversible:		return "sysReasonACCerrorIrreversible";
		case diagInfo_sysReasonACCDeactivation:				return "sysReasonACCDeactivation";
		case diagInfo_sysStatusDisabled:					return "sysStatusDisabled";
		case diagInfo_sysStatusEnabled:						return "sysStatusEnabled";
		case diagInfo_sysStatusNotAvailable:				return "sysStatusNotAvailable";
		case diagInfo_sysStatusAvailable:					return "sysStatusAvailable";
		case diagInfo_sysStatusActive:						return "sysStatusActive";
		case diagInfo_sysStatusOverride:					return "sysStatusOverride";
		case diagInfo_sysStatusBrakeOnlyMode:				return "sysStatusBrakeOnlyMode";
		case diagInfo_prtCopySegment:						return "prtCopySegment";
		case diagInfo_prtOutputBuffer:						return "prtOutputBuffer";
		case diagInfo_vobsFailDTC_MotorCode_46005:			return "vobsFailDTC_MotorCode_46005";
		case diagInfo_vobsFailDTC_LongControlInvalid_46003:	return "vobsFailDTC_LongControlInvalid_46003";
		case diagInfo_vobsFailDTC_ReplaceVelocity_46006:	return "vobsFailDTC_ReplaceVelocity_46006";
		case diagInfo_vobsFailDTC_AccFreeRideSpeed_46007:	return "vobsFailDTC_AccFreeRideSpeed_46007";
		case diagInfo_vobsPassDTC_MotorCode_46005:			return "vobsPassDTC_MotorCode_46005";
		case diagInfo_vobsPassDTC_LongControlInvalid_46003:	return "vobsPassDTC_LongControlInvalid_46003";
		case diagInfo_vobsPassDTC_ReplaceVelocity_46006:	return "vobsPassDTC_ReplaceVelocity_46006";
		case diagInfo_vobsPassDTC_AccFreeRideSpeed_46007:	return "vobsPassDTC_AccFreeRideSpeed_46007";
		default:											return "?_?_?";
	}
}


void				diagReportError(IN	const	diagModule_T		 module,
									IN	const	uint32_T			 line)
{
#ifndef INNODRIVE_ZFAS_SWC_BUILD
	char_T message[128];

	(void)sprintf_s(message, 128, "Error in module %s in line %i.", diagGetModuleName(module), line);
	diagLogError(message);
#endif

	if(NULL != ptrErrorCallback) {
		ptrErrorCallback(ptrErrorUserData, module, line);
	}
}


void				 diagReportInfo(IN	const	diagInfo_T			 info)
{
	if(NULL != ptrErrorCallback) {
		ptrErrorCallback(ptrErrorUserData, diagModule_Info, (uint32_T)info);
	}
}


/*lint -esym(759,diagRegisterLogCallbacks)*/
/*lint -esym(765,diagRegisterLogCallbacks)*/
/*lint -esym(714,diagRegisterLogCallbacks)*/
void	   diagRegisterLogCallbacks(void(*infoCallback)(const char_T *cStr),
									void(*warningCallback)(const char_T *cStr),
									void(*errorCallback)(const char_T *cStr))
{
	ptrAdtfLogInfo		= infoCallback;
	ptrAdtfLogWarning	= warningCallback;
	ptrAdtfLogError		= errorCallback;
}


/*lint -esym(759,diagLogInfo)*/
/*lint -esym(765,diagLogInfo)*/
/*lint -esym(714,diagLogInfo)*/
void					diagLogInfo(IN	const	char_T				*message)
{
	if (NULL != ptrAdtfLogInfo) { ptrAdtfLogInfo(message); }
}

/*lint -esym(759,diagLogWarning)*/
/*lint -esym(765,diagLogWarning)*/
/*lint -esym(714,diagLogWarning)*/
void				 diagLogWarning(IN	const	char_T				*message)
{
	if (NULL != ptrAdtfLogWarning) { ptrAdtfLogWarning(message); }
}


/*lint -esym(759,diagLogError)*/
/*lint -esym(765,diagLogError)*/
/*lint -esym(714,diagLogError)*/
void				   diagLogError(IN	const	char_T				*message)
{
	if (NULL != ptrAdtfLogError) { ptrAdtfLogError(message); }
}


void	  diagRegisterErrorCallback(void(*errorCallback)(void *userData, const diagModule_T module, const uint32_T line), 
									INOUT		void				*userData)
{
	ptrErrorCallback	= errorCallback;
	ptrErrorUserData	= userData;
}


void	diagUnregisterErrorCallback(void)
{
	ptrErrorCallback = NULL;
}
