#ifndef guard_pltfTime_h
#define guard_pltfTime_h

#include "base.h"


real32_T	pltfGetCurrentTime(void);
real64_T	pltfGetHighPerfTime(void);
uint64_T	pltfGetProcessorCycles(void);

void		pltfRegisterGetStreamTimeCallback(real32_T(*adtfGetStreamTime)(void));
void		pltfRegisterGetHighPerfTimeCallback(real64_T(*adtfGetHighPerfTime)(void));
void		pltfRegisterClockGetStreamTime(real64_T(*clockGetStreamTime)(void));
void		pltfUnregisterClockGetStreamTime(void);


#endif
