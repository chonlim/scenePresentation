#ifndef guard_pltfDiag_h
#define guard_pltfDiag_h

#include "common/common.h"
#include "common/platformInterface/pltfDiagTypes.h"


void				diagReportError(IN	const	diagModule_T		 module,
									IN	const	uint32_T			 line
									);


void				 diagReportInfo(IN	const	diagInfo_T			 info
									);


void				 diagLogWarning(IN	const	char_T				*message
									);


void				   diagLogError(IN	const	char_T				*message
									);


void				    diagLogInfo(IN	const	char_T				*message
									);


void	   diagRegisterLogCallbacks(void(*infoCallback)(const char_T *cStr),
									void(*warningCallback)(const char_T *cStr),
									void(*errorCallback)(const char_T *cStr)
									);


void	  diagRegisterErrorCallback(void(*errorCallback)(void *userData, const diagModule_T module, const uint32_T line),
									INOUT		void				*userData);


void	diagUnregisterErrorCallback(void);


const char_T*	  diagGetModuleName(IN	const	diagModule_T		 module
									);


const char_T*		diagGetInfoText(IN	const	diagInfo_T			 info
									);


/*lint -esym(9003, diagCurrentModule) (Note -- could define variableat block scope [MISRA 2012 Rule 8.9, advisory])*/
/*lint -emacro(777, diagFNaN) (Testing floats for equality)*/
/*lint -emacro(527, diagFUnreachable) (Unreachable code)*/
/*lint -save*/
/*lint -e9026 Function-like macro, defined [MISRA 2012 Directive 4.9, advisory]*/
#define diagDeclareModule(MODULE)	static const diagModule_T diagCurrentModule = MODULE;

#define diagFF(CONDITION)			{ if(!(CONDITION)) { diagReportError(diagCurrentModule, __LINE__); return false; } }
#define diagFNaN(VAR)				{ if((VAR)!=(VAR)) { diagReportError(diagCurrentModule, __LINE__); return false; } }
#define diagFUnreachable()			{ diagReportError(diagCurrentModule, __LINE__); return false; }
/*lint -restore*/

#endif
