/**	\file
	\brief	Implementiert �ffentliche Funktionen f�r dne Zugriff auf die Momentenplanung */
#include "lntqTools.h"
#include "longTorquePlanner_private.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_lntqTools)


void					lntqIsValid(IN	const	longTorque_T		*longTorque,
									OUT			bool_T				*valid)
{
	*valid = longTorque->valid;
}


bool_T		  lntqGetPredictedState(IN	const	longTorque_T		*longTorque,
									IN	const	real32_T			 time,
									OUT	OPT		vmState_T			*vmState,
									OUT	OPT		bool_T				*coast,
									OUT	OPT		uint8_T				*nextGear,
									OUT	OPT		forceState_T		*fmState,
									OUT	OPT		real32_T			*maxAcceleration,
									OUT	OPT		real32_T			*minAcceleration)
{
	uint16_T		index;

	real32_T		s1, v1, a1;
	real32_T		aMax, aMin;
	real32_T		deltaTime, delta;

	uint8_T			gear = gearCoast;
	bool_T			c1;
	forceState_T	fm1;


	/* Enth�lt die Strategie g�ltige Werte? */
	diagFF(longTorque->valid);


	/* Ist die angegebene Anzahl von Datenpunkten plausibel? */
	diagFF(longTorque->count <= (uint16_T)lntqOUTDISTANCE);
	diagFF(longTorque->count > 0u);


	/* 1. Schritt: Suche nach dem Segment, das die gesuchte Position einschlie�t */
	for(index = 0; index < (uint16_T)lntqOUTDISTANCE - 1u; index++) {
		/* Diese Abfrage ist relevant, um die Rechenzeit, die in Schritt 3 anf�llt, zu "spiegeln" */
		if(longTorque->segment[index+1u].gear != (uint8_T)gearCoast && gear == (uint8_T)gearCoast) {
			gear = longTorque->segment[index+1u].gear;
		}

		/* Wenn das n�chste Segment hinter unserem Abfragezeitpunkt beginnt, haben wir das richtige gefunden */
		if(longTorque->segment[index+1u].time >= time) {
			break;
		}
		else {
			continue;
		}
	}


	/* Wenn wir hier die Anzahl g�ltiger Segmente �berschritten haben, ist etwas schiefgegangen */
	diagFF(index+1u < longTorque->count);
	diagFF(index+1u < (uint16_T)lntqOUTDISTANCE);


	/* 2. Schritt: Interpolation der Daten auf dem relevanten Segment */
	deltaTime	= time - longTorque->segment[index].time;

	delta		= deltaTime / (longTorque->segment[index+1u].time - longTorque->segment[index].time);

	a1			= longTorque->segment[index].vm.acceleration 
				+ (longTorque->segment[index+1u].vm.acceleration - longTorque->segment[index].vm.acceleration) * delta;

	aMax		= longTorque->segment[index].limits.maxAcceleration 
				+ (longTorque->segment[index+1u].limits.maxAcceleration - longTorque->segment[index].limits.maxAcceleration) * delta;

	aMin		= longTorque->segment[index].limits.minAcceleration
				+ (longTorque->segment[index+1u].limits.minAcceleration - longTorque->segment[index].limits.minAcceleration) * delta;

	v1			= longTorque->segment[index].vm.velocity 
				+ 0.5f * (longTorque->segment[index].vm.acceleration + a1) * deltaTime;

	s1			= longTorque->segment[index].vm.position 
				+ longTorque->segment[index].vm.velocity  * deltaTime
				+ (longTorque->segment[index].vm.acceleration / 3.0f + a1 / 6.0f) * deltaTime * deltaTime;

	gear		= longTorque->segment[index+1u].gear;
	c1			= (gear == (uint8_T)gearCoast) ? true : false;

	switch(longTorque->segment[index+1u].fm) {
		case (uint8_T)forceStateForward:
			fm1 = forceStateForward;
			break;

		case (uint8_T)forceStateNeutral:
			fm1 = forceStateNeutral;
			break;

		case (uint8_T)forceStateBackward:
			fm1 = forceStateBackward;
			break;

		default:
			diagFUnreachable();
	} /*lint !e9077*/


	/* 3. Schritt: Restliche Segmente abfragen, um �bersch�ssige Rechenzeit zu "verbrennen" */
	for(; index < (uint16_T)lntqOUTDISTANCE - 1u; index++) {
		
		if(longTorque->segment[index+1u].gear != (uint8_T)gearCoast && gear == (uint8_T)gearCoast) {
			gear = longTorque->segment[index+1u].gear;
		}

		if(longTorque->segment[index+1u].time >= time) {
			continue;
		}
		else {
			continue;
		}
	}


	/* 4. Schritt: Relevante Ausgabewerte belegen */
	if(NULL != vmState) {
		vmState->position		= s1;
		vmState->velocity		= v1;
		vmState->acceleration	= a1;
	}

	if(NULL != nextGear) {
		*nextGear				= gear;
	}

	if(NULL != coast) {
		*coast					= c1;
	}

	if(NULL != fmState) {
		*fmState				= fm1;
	}

	if(NULL != maxAcceleration){
		*maxAcceleration		= aMax;
	}

	if(NULL != minAcceleration) {
		*minAcceleration		= aMin;
	}

	return true;
}


bool_T	   lntqGetDisplayConstraint(IN	const	longTorque_T		*longTorque,
									OUT			displayConstraint_T	*type,
									OUT			real32_T			*position,
									OUT			real32_T			*velocity,
									OUT			real32_T			*acceleration)
{
	diagFF(longTorque->valid);

	*type			= longTorque->preview.curve.type;
	*position		= longTorque->preview.curve.position;
	*velocity		= longTorque->preview.curve.velocity;
	*acceleration	= longTorque->preview.curve.acceleration;

	return true;
}


bool_T			  lntqGetCurveReach(IN	const	longTorque_T		*longTorque,
									OUT			bool_T				*valid,
									OUT			real32_T			*reachVelocity,
									OUT			real32_T			*curveVelocity)
{
	diagFF(longTorque->valid);

	*valid			= longTorque->curveReach.valid;
	*reachVelocity	= longTorque->curveReach.reachVelocity;
	*curveVelocity	= longTorque->curveReach.curveVelocity;

	return true;
}


void			lntqGetStopPosition(IN	const	longTorque_T		*longTorque,
									OUT			real32_T			*position)
{
	if(   (longTorque->valid)
	   && (longTorque->preview.stop.acceleration < longTorque->preview.limit.acceleration)
	   && (longTorque->preview.stop.valid)) {
		*position = longTorque->preview.stop.position;
	}
	else {
		*position = -INVALID_VALUE;
	}
}



bool_T	   lntqGetLimitAcceleration(IN	const	longTorque_T		*longTorque,
									OUT			real32_T			*acceleration)
{
	diagFF(longTorque->valid);

	*acceleration	= longTorque->preview.limit.acceleration;

	return true;
}


void		 lntqGetPreviewPosition(IN	const	longTorque_T		*longTorque,
									OUT			real32_T			*previewPosition)
{
	if(!longTorque->valid) {
		*previewPosition = -INVALID_VALUE;
	}
	else {
		*previewPosition =  longTorque->preview.limit.position;
	}
}


bool_T			 lntqGetMaxPlanTime(IN	const	longTorque_T		*longTorque,
									OUT			real32_T			*time)
{
	/* Enth�lt die Strategie g�ltige Werte? */
	diagFF(longTorque->valid);


	/* Ist die angegebene Anzahl von Datenpunkten plausibel? */
	diagFF(longTorque->count <= (uint16_T)lntqOUTDISTANCE);
	diagFF(longTorque->count > 0u);


	*time = longTorque->segment[longTorque->count-1u].time;

	return true;
}
