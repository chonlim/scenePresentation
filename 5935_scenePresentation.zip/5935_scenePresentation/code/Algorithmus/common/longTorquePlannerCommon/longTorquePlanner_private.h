#ifndef guard_longTorquePlanner_private_h
#define guard_longTorquePlanner_private_h

#include "common/longTorquePlannerCommon/longTorquePlanner_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */




typedef struct _longPreview {
	struct _longPreview_curve {
		displayConstraint_T type;
		real32_T position;               /**< Position der relevanten Einschränkung[m] */
		real32_T velocity;               /**< Maximal zulässige Geschwindigkeit der relevanten Einschränkung[m/s] */
		real32_T acceleration;           /**< Maximal zulässige Beschleunigung aufgrund der relevanten Einschränkung[m/s²] */
	} curve;
	struct _longPreview_limit {
		real32_T acceleration;           /**< Maximal zulässige Beschleunigung aufgrund der aktuellen und zukünftigen Setzgeschwindigkeit[m/s²] */
		real32_T position;               /**< Position des relevanten Geschwindigkeitslimits[m] */
	} limit;
	struct _longPreview_stop {
		bool_T valid;                    /**< Gibt an, ob eine gültige Stoppstellen-Einschränkung ausgewertet wurde */
		real32_T acceleration;           /**< Maximal zulässige Beschleunigung aufgrund von Stoppstellen[m/s²] */
		real32_T position;               /**< Position der relevanten Stoppstellen-Eisnchränkung[m] */
	} stop;
} longPreview_T;                         /**< Groesse der Struktur = 36 Bytes */

typedef struct _longCurveReach {
	bool_T valid;                        /**< Gibt an, ob für die Position des relevanten Krümmungs-Einschränkung eine voraussichtliche Geschwindigkeit ermittelt wurde */
	real32_T reachVelocity;              /**< Geschwindigkeit, die an der Position der relevanten Einschränkung laut aktueller Planung voraussichtlich erreicht wird[m/s] */
	real32_T curveVelocity;              /**< Zulässige Geschwindigkeit der relevanten Krümmungs-Einschränkung[m/s] */
} longCurveReach_T;                      /**< Groesse der Struktur = 12 Bytes */

struct _longTorque {
	bool_T valid;                        /**< Gültigkeits-Flag für den Rest der Datenstruktur */
	uint16_T count;                      /**< Anzahl der Segmente, die gültige Daten enthalten */
	struct _longTorque_segment {
		real32_T time;                   /**< Zeit[s] */
		vmState_T vm;                    /**< Bewegungszustand */
		uint8_T gear;                    /**< Gang */
		uint8_T fm;                      /**< Zugkraftzustand */
		struct _longTorque_segment_limits {
			real32_T minAcceleration;    /**< Minimal zulässige Beschleunigung[m/(s^2)] */
			real32_T maxAcceleration;    /**< Maximal zulässige Beschleunigung[m/(s^2)] */
		} limits;                        /**< Beschleunigungsgrenzen, die sich aus den Geschwindigkeits-Randbedinungen ergeben */
	} segment[lntqOUTDISTANCE];          /**< Zeitschritte der geplanten Zustandstrajektorie */
	longPreview_T preview;
	longCurveReach_T curveReach;
} ;                                      /**< Groesse der Struktur = 220 Bytes */


/*lint -restore */

#endif
