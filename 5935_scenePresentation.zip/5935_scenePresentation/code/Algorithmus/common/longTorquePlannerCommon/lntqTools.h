/**	\file
	\brief		Deklariert �ffentliche Funktionen f�r dne Zugriff auf die Momentenplanung */
/**	\ingroup	lntqTools
	\{ */
#ifndef guard_lntqTools_h
#define guard_lntqTools_h


#include "common/common.h"
#include "longTorquePlanner_interface.h"


/** \brief	Gibt an, ob longTorque g�ltig ist */
void					lntqIsValid(IN	const	longTorque_T		*longTorque,			/**< Interne Datenstruktur der Momentenplanung */
									OUT			bool_T				*valid					/**< G�ltigkeit der Momentenplanung */
									);


/** \brief	Gibt den f�r den Zeitpunkt time von der Momentenplanung vorgesehenen Fahrzeugzustand zur�ck 
\spec SW_AS_Innodrive2_379 (Bewegungsmodell)
*/
bool_T		  lntqGetPredictedState(IN	const	longTorque_T		*longTorque,			/**< interne Datenstruktur der Momentenplanung */
									IN	const	real32_T			 time,					/**< Zeitpunkt, zu dem die Strategie abgefragt werden soll */
									OUT	OPT		vmState_T			*vmState,				/**< geplanter Bewegungszustand */
									OUT	OPT		bool_T				*coast,					/**< Ist Segeln geplant? */
									OUT	OPT		uint8_T				*nextGear,				/**< Geplanter Gang, bzw. im Fall einer Segelanforderung der Gang, der als n�chstes eingelegt werden soll */
									OUT	OPT		forceState_T		*fmState,				/**< geplanter Zugkraftzustand */
									OUT	OPT		real32_T			*maxAcceleration,		/**< maximal zul�sige Beschleunigung */
									OUT	OPT		real32_T			*minAcceleration		/**< minimal zul�ssige Beschleunigung */
									);


/** \brief	Gibt die relevante Geschwindigkeitseinschr�nkung zum Zeitpunkt der Momentenplanung zur�ck */
bool_T	   lntqGetDisplayConstraint(IN	const	longTorque_T		*longTorque,			/**< interne Datenstruktur der Momentenplanung */
									OUT			displayConstraint_T	*type,					/**< Art der relevanten Einschr�nkung */
									OUT			real32_T			*position,				/**< Position der relevanten Einschr�nkung */
									OUT			real32_T			*velocity,				/**< Vorausschaugeschwindigkeit f�r die relevante Einschr�nkung */
									OUT			real32_T			*acceleration			/**< Maximal zul�ssige Beschleunigung aufgrund der relevanten Einschr�nkung */
									);


/** \brief	Gibt die Geschwindigkeit aus, mit der die relevante Geschwindigkeitseinschr�nkung voraussichtlich erreicht wird */
bool_T			  lntqGetCurveReach(IN	const	longTorque_T		*longTorque,			/**< interne Datenstruktur der Momentenplanung */
									OUT			bool_T				*valid,					/**< Gibt an, ob eine g�ltige voraussichtliche Geschwindigkeit vorliegt */
									OUT			real32_T			*reachVelocity,			/**< Voraussichtliche Geschwindigkeit, mit der die Einschr�nkung erreicht wird [m/s] */
									OUT			real32_T			*curveVelocity			/**< Relevante zul�ssige Geschwindigkeit [m/s] */
									);


/** \brief	Fragt die maximal zul�ssige Geschwindigkeit ab, die aufgrund der Setzgeschwindigkeit aktuell zul�ssig ist */
bool_T	   lntqGetLimitAcceleration(IN	const	longTorque_T		*longTorque,			/**< interne Datenstruktur der Momentenplanung */
									OUT			real32_T			*acceleration			/**< Maximal zul�ssige Beschleunigung */
									);


/** \brief	Fragt die Position der aktuell relevanten Stoppstelle ab */
void			lntqGetStopPosition(IN	const	longTorque_T		*longTorque,			/**< intere Datenstruktur der Momentenplanung */
									OUT			real32_T			*position				/**< Position der relevanten Stoppstelle */
									);


/** \brief	Gibt die Position des relevanten Speed Limits zum Zeitpunkt der Momentenplanung zur�ck */
void		 lntqGetPreviewPosition(IN	const	longTorque_T		*longTorque,			/**< interne Datenstruktur der Momentenplanung */
									OUT			real32_T			*previewPosition		/**< Position der relevanten Speed Limit-Einschr�nkung */
									);


/** \brief	Gibt den sp�testen Zeitpunkt zur�ck, f�r den die Momentenplanung abgefragt werden kann. */
bool_T			 lntqGetMaxPlanTime(IN	const	longTorque_T		*longTorque,			/**< interne Datenstruktur der Momentenplanung */
									OUT			real32_T			*time					/**< sp�tester Zeitpunkt, f�r den eine g�ltige Planung vorliegt */
									);


#endif
/** \} */
