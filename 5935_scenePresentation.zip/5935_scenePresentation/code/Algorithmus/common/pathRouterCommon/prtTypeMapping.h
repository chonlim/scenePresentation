/** \brief Einbinden der Header mit den Definitionen der EHR-Datentypen

Einbinden der Header mit den Definitionen der EHR-Datentypen
Die R�ckabedaten der PsdEhr- bzw. der RG-Api-FUnktionen werden mit den in den unten aufgelisteten Headern definierten Enums (PsdEhr_...Values_t) interpretiert.
*/

#ifndef PRTTYPEMAPPING_H
#define PRTTYPEMAPPING_H


#include "Lib/EHR/PSD_EHR/include/psd_ehr_definition_generic_attributes.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_access_types.h"
#include "Lib/EHR/PSD_EHR/include/psd_ehr_core_status_types.h"


#endif
