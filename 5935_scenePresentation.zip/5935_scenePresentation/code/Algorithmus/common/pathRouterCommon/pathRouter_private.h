#ifndef guard_pathRouter_private_h
#define guard_pathRouter_private_h

#include "common/pathRouterCommon/pathRouter_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
#include "common/psdWrapperCommon/psdWrapper_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define METER_TO_PSDDISTANCE 100

typedef enum _mapInitFlag {
	mapRouteInvalid = 0,
	newMapRoute = 1,
	mapPathInvalid = 2,
	mapPathInitialized = 3,
	mapPathComplete = 4
} mapInitFlag_T;

typedef enum _mapChangeFlag {
	noChange = 0,                        /**< Keine Aenderung der mapRoute */
	changeMapRouteNew = 1,               /**< Neu ab Wurzelsegment aufgebaut */
	changeMapRouteInvalid = 2,           /**< Ungueltige Route */
	changeMapRouteUpdated = 3,           /**< Segmente angehaelngt oder weggefallen */
	changeMapRouteRerouted = 4           /**< Aenderung durch Blinker oder Neupositionierung bei gleichem Wurzelsegment */
} mapChangeFlag_T;

typedef enum _branchOptions {
	branchOptionNone = 0,                /**< Binary 000: Keine Abbiegemöglichkeit */
	branchOptionLeft = 1,                /**< Binary 001: Abbiegemöglichkeit nach links */
	branchOptionRight = 2,               /**< Binary 010: Abbiegemöglichkeit nach rechts */
	branchOptionRoute = 4                /**< Binary 100: SP und MPP unterscheiden sich */
} branchOptions_T;

typedef uint8_T ringId_T; 


struct _mapGpsInfo {
	psdLatitude_T latitude;
	psdLongitude_T longitude;
	psdHeading_T heading;
	uint8_T offset;
	psdAltitude_T altitude;
	ringId_T segmentRingId;
} ;                                      /**< Groesse der Struktur = 16 Bytes */

struct _infoGpsInfo {
	psdLatitude_T latitude;
	psdLongitude_T longitude;
	psdHeading_T heading;
	psdAltitude_T altitude;
	uint16_T position;
} ;                                      /**< Groesse der Struktur = 16 Bytes */

struct _mapRawVehiclePosition {
	bool_T valid;                        /**< Gültigkeit der virtuellen Position und des PsdBaum insgesamt */
	uint8_T remainingLength;             /**< Distanz vom Fahrzeug bis zum Ende des Segments[m] */
	psdSegmentId_T segmentId;            /**< Segment auf dem sich das Fahrzeug befindet[1] */
	real32_T inhibitTime;                /**< Zeit die zwischen Positionsbestimmung und Ausgabe der psdPosition vergangen ist[s] */
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _mapPositionFilter {
	bool_T isInitialized;
	uint8_T resetCount;
	mapRawVehiclePosition_T rootSegment;
	mapRawVehiclePosition_T rawPosition;
	real32_T vehicleDistance;            /**< Fahrzeugposition lautKarte relativ zur Pfadwurzel in Metern[m] */
	real32_T vehDistCorrection;          /**< Korrektur der Fahrzeugposition wird Schrittweise in die rawPosition zurueckgeschleift[m] */
	real32_T longPosition;               /**< Streng monoton wachsende Fahrzeugposition vom vehicleObserver[m] */
} ;                                      /**< Groesse der Struktur = 32 Bytes */

struct _mapGpsRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	mapGpsInfo_T gpsInfo[mapPATHGPSCOUNT];
} ;                                      /**< Groesse der Struktur = 68 Bytes */

struct _speedLimit {
	uint8_T offset;
	ringId_T segmentRingId;
	psdSpeedLimitValue_T value;
	psdSpeedLimitUnit_T unit;
	bool_T constraintTrailer;            /**< Gilt die Geschwindigkeitsbeschränkung nur für Fahzeuge mit Anhänger? */
	bool_T constraintWet;                /**< Gilt die Geschwindigkeitsbeschränkung nur bei Nässe? */
	bool_T constraintFog;                /**< Gilt die Geschwindigkeitsbeschränkung nur bei Nebel? */
	bool_T constraintTime;               /**< Ist die Geschwindigkeitsbeschränkung zeitlich begrenzt? */
	bool_T constraintLane;               /**< Gilt die Geschwindigkeitsbeschränkung nur für bestimmte Fahrspuren? */
	bool_T variableSign;                 /**< Ergibt sich das Geschwindigkeitslimits aus einem variablen Verkehrszeichen? */
} ;                                      /**< Groesse der Struktur = 10 Bytes */

struct _infoSpeedLimit {
	uint16_T position;
	psdSpeedLimitValue_T value;
	uint8_T codedInfo;                   /**< Codierte Informationen über Einschränkungen und Einheit der Geschwindigkeitsbeschränkung */
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _mapSpeedLimitRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	speedLimit_T speedLimit[mapPATHSPEEDLIMITCOUNT];
} ;                                      /**< Groesse der Struktur = 103 Bytes */

struct _curvature {
	psdCurvature_T curvature;
	uint8_T offset;
	ringId_T segmentRingId;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _infoCurvature {
	psdCurvature_T curvature;
	uint16_T position;
	uint8_T segmentId;
	bool_T endOfConstantSegmentMissing;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _mapCurvatureRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	curvature_T curvature[mapPATHCURVATURECOUNT];
} ;                                      /**< Groesse der Struktur = 516 Bytes */

struct _branchAngle {
	uint8_T offset;
	psdAngle_T angle;
	ringId_T segmentRingId;
} ;                                      /**< Groesse der Struktur = 6 Bytes */

struct _infoBranchAngle {
	psdAngle_T angle;
	uint16_T position;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _mapBranchAngleRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	branchAngle_T branchAngle[mapPATHBRANCHANGLECOUNT];
} ;                                      /**< Groesse der Struktur = 130 Bytes */

struct _slope {
	uint8_T offset;
	psdSlope_T slope;
	ringId_T segmentRingId;
} ;                                      /**< Groesse der Struktur = 6 Bytes */

struct _infoSlope {
	psdSlope_T slope;
	uint16_T position;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _infoBuiltUp {
	bool_T builtUp;
	uint16_T position;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _mapSlopeRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	slope_T slope[mapPATHSLOPECOUNT];
} ;                                      /**< Groesse der Struktur = 772 Bytes */

struct _builtUpArea {
	uint8_T offset;
	ringId_T segmentRingId;
	bool_T type;
} ;                                      /**< Groesse der Struktur = 3 Bytes */

struct _mapBuiltUpRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	builtUpArea_T builtUpArea[mapPATHBUILTUPAREACOUNT];
} ;                                      /**< Groesse der Struktur = 66 Bytes */

struct _laneSituation {
	uint8_T offset;
	ringId_T segmentRingId;
	uint8_T forwardLanes;
	uint8_T turnLanesLeft;
	uint8_T turnLanesRight;
	uint8_T oppositeLanes;
} ;                                      /**< Groesse der Struktur = 6 Bytes */

struct _dynamicEvent {
	uint8_T offset;
	ringId_T segmentRingId;
	prtDynamicEventValues_T type;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _mapLaneSituationRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	laneSituation_T laneSituation[mapPATHLANESITUATIONCOUNT];
} ;                                      /**< Groesse der Struktur = 195 Bytes */

struct _infoLaneSituation {
	uint16_T position;
	uint8_T forwardLanes;
	uint8_T oppositeLanes;
	uint8_T turnLanesLeft;
	uint8_T turnLanesRight;
} ;                                      /**< Groesse der Struktur = 6 Bytes */

struct _streetClass {
	ringId_T segmentRingId;
	uint8_T offset;
	prtStreetClassValues_T type;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _ramp {
	ringId_T segmentRingId;
	uint8_T offset;
	prtRampValues_T type;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _mapDynamicEventRing {
	bool_T debugMsgLock;
	ringId_T start;
	ringId_T count;
	dynamicEvent_T dynamicEvent[mapPATHDYNAMICEVENTCOUNT];
} ;                                      /**< Groesse der Struktur = 172 Bytes */

struct _rightOfWayControl {
	ringId_T segmentRingId;
	uint8_T offset;
	prtRightOfWayControlValues_T type;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _streetSituation {
	ringId_T segmentRingId;
	uint8_T offset;
	prtStreetSituationValues_T type;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _trafficDirection {
	ringId_T segmentRingId;
	uint8_T offset;
	vobsTrafficDir_T trafficDirection;
} ;                                      /**< Groesse der Struktur = 8 Bytes */

struct _countryCode {
	ringId_T segmentRingId;
	uint8_T offset;
	psdCountryCode_T countryCode;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _speedLimitUnit {
	ringId_T segmentRingId;
	uint8_T offset;
	psdSpeedLimitUnit_T speedLimitUnit;
} ;                                      /**< Groesse der Struktur = 3 Bytes */

struct _qualityGeometry {
	ringId_T segmentRingId;
	uint8_T offset;
	uint8_T qualityGeometry;
} ;                                      /**< Groesse der Struktur = 3 Bytes */

struct _infoStreetClass {
	uint16_T position;
	uint8_T type;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _infoRamp {
	uint16_T position;
	uint8_T type;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _infoRightOfWayControl {
	uint16_T position;
	uint8_T type;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _infoRoundabout {
	uint16_T position;
	bool_T roundabout;
} ;                                      /**< Groesse der Struktur = 4 Bytes */

struct _mapStreetClassRing {
	bool_T debugMsgLock;
	streetClass_T streetClass[mapPATHRAMPCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 176 Bytes */

struct _mapRampRing {
	bool_T debugMsgLock;
	ramp_T ramp[mapPATHSTREETCLASSCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 176 Bytes */

struct _mapRightOfWayRing {
	bool_T debugMsgLock;
	rightOfWayControl_T rightOfWayControl[mapPATHRIGHTOFWAYCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 264 Bytes */

struct _mapStreetSituationRing {
	bool_T debugMsgLock;
	streetSituation_T streetSituation[mapPATHSTREETSITUATIONCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 104 Bytes */

struct _mapTrafficDirectionRing {
	bool_T debugMsgLock;
	trafficDirection_T trafficDirection[mapPATHTRAFFICDIRECTIONCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 24 Bytes */

struct _mapCountryCodeRing {
	bool_T debugMsgLock;
	countryCode_T countryCode[mapPATHCOUNTRYCODECOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 12 Bytes */

struct _mapSpeedLimitUnitRing {
	bool_T debugMsgLock;
	speedLimitUnit_T speedLimitUnit[mapPATHSPEEDLIMITUNITCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 9 Bytes */

struct _mapQualityGeometryRing {
	bool_T debugMsgLock;
	qualityGeometry_T qualityGeometry[mapPATHQUALITYGEOMETRYCOUNT];
	ringId_T count;
	ringId_T start;
} ;                                      /**< Groesse der Struktur = 66 Bytes */

struct _mapSegmentRing {
	ringId_T start;
	ringId_T count;
	struct _mapSegmentRing_segment {
		psdSegmentId_T segmentId;
		uint16_T startDistance;
		uint8_T length;
		psdRampValue_T rampValue;
		ringId_T gpsRingEnd;             /**< Erster index nach letzter valider Id */
		ringId_T speedLimitEnd;          /**< Erster index nach letzter valider Id */
		ringId_T onlineSpeedEnd;         /**< Erster index nach letzter valider Id */
		ringId_T curvatureEnd;           /**< Erster index nach letzter valider Id */
		ringId_T branchAngleEnd;         /**< Erster index nach letzter valider Id */
		ringId_T slopeEnd;               /**< Erster index nach letzter valider Id */
		ringId_T builtUpAreaEnd;         /**< Erster index nach letzter valider Id */
		ringId_T laneSituationEnd;       /**< Erster index nach letzter valider Id */
		ringId_T streetClassEnd;         /**< Erster index nach letzter valider Id */
		ringId_T rampEnd;                /**< Erster index nach letzter valider Id */
		ringId_T dynamicEventEnd;        /**< Erster index nach letzter valider Id */
		ringId_T rightOfWayEnd;          /**< Erster index nach letzter valider Id */
		ringId_T streetSituationEnd;     /**< Erster index nach letzter valider Id */
		ringId_T trafficDirectionEnd;    /**< Erster index nach letzter valider Id */
		ringId_T countryCodeEnd;         /**< Erster index nach letzter valider Id */
		ringId_T speedLimitUnitEnd;      /**< Erster index nach letzter valider Id */
		ringId_T qualityGeometryEnd;     /**< Erster index nach letzter valider Id */
	} segment[mapMAXROUTELENGTH];
} ;                                      /**< Groesse der Struktur = 506 Bytes */

struct _mapRoute {
	uint8_T segmentCount;
	uint8_T segmentStart;
	psdSegment_T segment[mapMAXROUTELENGTH];
	branchOptions_T branch[mapMAXROUTELENGTH];
	uint8_T rerouteCount;
	uint8_T smallestAngles[mapMAXROUTELENGTH];
} ;                                      /**< Groesse der Struktur = 932 Bytes */

struct _mapRouteMemory {
	bool_T completed;
	turnSignal_T lastTurnSignal;
	bool_T lastConfident;
	bool_T lastUseRouting;
	psdChangeCount_T lastChangeCount;
	uint8_T checkBranchesIndex;
	mapRoute_T mapRoute;
} ;                                      /**< Groesse der Struktur = 948 Bytes */

struct _mapSystemAttributes {
	uint8_T qualityGeometry;
	psdCountryCode_T countryCode;
	psdSpeedLimitUnit_T speedLimitUnit;
	uint8_T trafficDirection;
} ;                                      /**< Groesse der Struktur = 6 Bytes */

struct _mapHeadingFilter {
	bool_T isInitialized;
	real32_T reference;
	real32_T correction;
	mapRawVehiclePosition_T rawPosition;
} ;                                      /**< Groesse der Struktur = 20 Bytes */

typedef struct _mapHoldFilter {
	uint32_T holdTicks;                  /**< Control-Tasks seit der letzten gueltigen mapPath Abfrage[n/a] */
	real32_T holdDistance;               /**< Wegstrecke  die seit der letzten gueltigen mapPath Abfrage zurueckgelegt wurde[m] */
	real32_T holdHeadDeviation;          /**< Integral des Produkts aus Wegstrecke und Heading Abweichung seit der letzten gueltigen mapPath Abfrage[mGrad] */
} mapHoldFilter_T;                       /**< Groesse der Struktur = 12 Bytes */

typedef struct _mapTurnFilter {
	uint32_T holdTicks;                  /**< Control-Tasks seit der letzten Rücksetzung[n/a] */
	real32_T holdDistance;               /**< Wegstrecke  die seit der letzten Rücksetzung zurueckgelegt wurde[m] */
	real32_T holdHeadDeviation;          /**< Integral des Produkts aus Wegstrecke und Heading Abweichung seit der letzten Rücksetzung[mGrad] */
	real32_T segmentStartRef;            /**< holdDistance am letzten Segmentwechsel[m] */
	mapRawVehiclePosition_T virtualPosition; /**< Gefilterte PSD-Position */
} mapTurnFilter_T;                       /**< Groesse der Struktur = 24 Bytes */

typedef struct _mapAgeFilter {
	uint32_T ageTicks;                   /**< Control-Tasks seit dem letzten Baum-Reset[n/a] */
} mapAgeFilter_T;                        /**< Groesse der Struktur = 4 Bytes */

struct _mapPathMemory {
	psdTreeConfiguration_T treeConfig;
	mapSegmentRing_T segmentRing;
	mapGpsRing_T gpsRing;
	mapSpeedLimitRing_T speedLimitRing;
	mapSpeedLimitRing_T onlineSpeedRing;
	mapCurvatureRing_T curvatureRing;
	mapBranchAngleRing_T branchAngleRing;
	mapSlopeRing_T slopeRing;
	mapBuiltUpRing_T builtUpRing;
	mapLaneSituationRing_T laneSituationRing;
	mapStreetClassRing_T streetClassRing;
	mapRampRing_T rampRing;
	mapDynamicEventRing_T dynamicEventRing;
	mapRightOfWayRing_T rightOfWayRing;
	mapStreetSituationRing_T streetSituationRing;
	mapTrafficDirectionRing_T trafficDirectionRing;
	mapCountryCodeRing_T countryCodeRing;
	mapSpeedLimitUnitRing_T speedLimitUnitRing;
	mapQualityGeometryRing_T qualityGeometryRing;
	uint16_T distance;
	mapSystemAttributes_T systemAttributes;
	ringId_T unfinishedSegment;
	psdAttributeIndex_T nextAttribute;
	psdAttributeIndex_T nextSpeedLimit;
	real32_T positionZero;
} ;                                      /**< Groesse der Struktur = 3504 Bytes */

struct _infoSpeedLimitRing {
	infoSpeedLimit_T speedLimit[mapINFOSPEEDLIMITCOUNT];
	ringId_T count;
} ;                                      /**< Groesse der Struktur = 26 Bytes */

struct _infoCurvatureRing {
	infoCurvature_T curvature[mapINFOCURVATURECOUNT];
	ringId_T count;
} ;                                      /**< Groesse der Struktur = 204 Bytes */

struct _infoBranchAngleRing {
	infoBranchAngle_T branchAngle[mapINFOBRANCHANGLECOUNT];
	ringId_T count;
} ;                                      /**< Groesse der Struktur = 18 Bytes */

struct _infoSlopeRing {
	infoSlope_T slope[mapINFOSLOPECOUNT];
	ringId_T count;
} ;                                      /**< Groesse der Struktur = 122 Bytes */

struct _infoBuiltUpRing {
	infoBuiltUp_T builtUp[mapINFOBUILTUPAREACOUNT];
	ringId_T count;
} ;                                      /**< Groesse der Struktur = 34 Bytes */

struct _infoStreetClassRing {
	ringId_T count;
	infoStreetClass_T streetClass[mapINFOSTREETCLASSCOUNT];
} ;                                      /**< Groesse der Struktur = 18 Bytes */

struct _infoRampRing {
	ringId_T count;
	infoRamp_T ramp[mapINFORAMPCOUNT];
} ;                                      /**< Groesse der Struktur = 26 Bytes */

struct _infoRightOfWayRing {
	ringId_T count;
	infoRightOfWayControl_T rightOfWayControl[mapINFORIGHTOFWAYCOUNT];
} ;                                      /**< Groesse der Struktur = 26 Bytes */

struct _infoRoundaboutRing {
	ringId_T count;
	infoRoundabout_T roundabout[mapINFOROUNDABOUTCOUNT];
} ;                                      /**< Groesse der Struktur = 26 Bytes */

struct _infoLaneSituationRing {
	ringId_T count;
	infoLaneSituation_T laneSituation[mapINFOLANESITUATIONCOUNT];
} ;                                      /**< Groesse der Struktur = 98 Bytes */

struct _mapInfo {
	infoGpsInfo_T gpsInfo;
	mapSystemAttributes_T systemAttributes;
	uint16_T distance;
	infoSpeedLimitRing_T speedLimitRing;
	infoCurvatureRing_T curvatureRing;
	infoBranchAngleRing_T branchAngleRing;
	infoSlopeRing_T slopeRing;
	infoBuiltUpRing_T builtUpRing;
	infoStreetClassRing_T streetClassRing;
	infoRampRing_T rampRing;
	infoRightOfWayRing_T rightOfWayRing;
	infoRoundaboutRing_T roundaboutRing;
	infoLaneSituationRing_T laneSituationRing;
} ;                                      /**< Groesse der Struktur = 624 Bytes */

struct _mapPath {
	bool_T valid;                        /**< Pfad ist Gültig */
	bool_T lowExecutionTime;             /**< Kürzere Ausführungszeit in diesem Rechentakt */
	real32_T headingCorrection;          /**< Ausrichtungskorrektur */
	real32_T positionZero;               /**< Position der Pfadwurzel im Fahrzeugkoordinatensystem */
	uint8_T positionResetCount;          /**< Zählt die Rücksetzungen des PositionFilter */
	uint8_T rerouteCount;                /**< Zählt die Neuaufbauten der Route */
	mapInfo_T info;                      /**< Linearisierte und ausgedünnte Streckendaten */
} ;                                      /**< Groesse der Struktur = 640 Bytes */

struct _pathRouterMemory {
	bool_T valid;
	mapPath_T lastMapPath;
	mapPositionFilter_T positionFilter;
	mapHeadingFilter_T headingFilter;
	mapHoldFilter_T holdFilter;
	mapTurnFilter_T turnFilter;
	mapAgeFilter_T ageFilter;
	mapPathMemory_T mapPathMemory;
	mapRouteMemory_T mapRouteMemory;
	mapInitFlag_T initFlag;
} ;                                      /**< Groesse der Struktur = 5192 Bytes */


/*lint -restore */

#endif
