#include "common/pathRouterCommon/prtDataInterface.h"
#include "common/pathRouterCommon/prtDataInterfaceStatic.h"
#include "common/pathRouterCommon/pathRouter_private.h"
#include "common/pathRouterCommon/prtTypeMapping.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_prtDataInterface)


#define		prtLIMITCODEDUNIT					  3u
#define		prtLIMITCODEDCONSTRAINTTRAILER		  4u
#define		prtLIMITCODEDCONSTRAINTWET			  8u
#define		prtLIMITCODEDCONSTRAINTFOG			 16u
#define		prtLIMITCODEDCONSTRAINTTIME			 32u
#define		prtLIMITCODEDCONSTRAINTLANE			 64u
#define		prtLIMITCODEDVARIABLESIGN			128u


static real32_T			   prtScalePosition(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 position)
{
	return ((real32_T)position + mapPath->positionZero);
}


bool_T				prtGetCurvatureIterator(IN	const	mapPath_T				*mapPath,
								OUT			curvatureIterator_T		*iterator)
{
	/* Es muss mindestens ein Kr�mmungswert verf�gbar sein, damit wir arbeiten k�nnen */
	diagFF(mapPath->info.curvatureRing.count > 0u);

	iterator->path		= mapPath;
	iterator->valid		= true;
	iterator->index		= 0;
	iterator->second	= false;

	return true;
}


bool_T		prtGetNextCurvature(INOUT		curvatureIterator_T		*iterator,
								OUT			bool_T					*valid,
								OUT			real32_T				*position,
								OUT			real32_T				*curvature)
{
	real32_T	outPos;
	real32_T	outCurvature;
	bool_T		outValid;
	psdCurvature_T	rawCurvature;

	outValid		= iterator->valid;


	/* Wenn an dieser Stelle ein konstaner Kr�mmungspunkt ausgelassen wurde und den St�tzpunkt nicht schon zum zweiten
	   Mal verarbeiten, m�ssen wir zun�chst einen Punkt mit der aktuellen Position aber der letzten Kr�mmung anlegen. */
	diagFF(iterator->index < (ringId_T)mapINFOCURVATURECOUNT);
	if(iterator->path->info.curvatureRing.curvature[iterator->index].endOfConstantSegmentMissing && !iterator->second) {
		diagFF(iterator->index > 0u);
		rawCurvature = iterator->path->info.curvatureRing.curvature[iterator->index-1u].curvature;
	}
	else {
		diagFF(iterator->index < iterator->path->info.curvatureRing.count);
		rawCurvature = iterator->path->info.curvatureRing.curvature[iterator->index].curvature;
	}


	/* Umrechnen der Position */
	outPos		= prtScalePosition(iterator->path, iterator->path->info.curvatureRing.curvature[iterator->index].position);

	/* Umrechnen der Position */
	outCurvature	= (real32_T)PSD_EHR_CURVATURE_OFFSET 
					+ (real32_T)PSD_EHR_CURVATURE_FACTOR * (real32_T)rawCurvature;


	/* Wir schieben den Index weiter, wenn dieses Element nur f�r einen St�tzpunkt relevant ist oder wir es schon zum zweiten Mal sehen... */
	if(   !iterator->path->info.curvatureRing.curvature[iterator->index].endOfConstantSegmentMissing
	   ||  iterator->second) {
		iterator->second = false;
		iterator->index++;

		/* Wenn das Ende der Liste erreicht ist, fangen wir von vorne an, markieren den Iterator aber als ung�ltig. */
		if(iterator->index == iterator->path->info.curvatureRing.count) {
			iterator->index	= 0;
			iterator->valid	= false;
		}
	}
	/* Wenn das Ende dieses Segments nicht �bertragen wird, m�ssen wir den Eintrag zwei Mal anschauen... */
	else {
		iterator->second	= true;
	}


	/* Ausgabe */
	*valid		= outValid;
	*position	= outPos;
	*curvature	= outCurvature;


	return true;
}


bool_T			   prtGetRoundaboutIterator(IN	const	mapPath_T				*mapPath,
											OUT			roundaboutIterator_T	*iterator)
{
	diagFF(mapPath->info.roundaboutRing.count > 0u);

	iterator->path			= mapPath;
	iterator->index			= 0;
	iterator->roundabout	= false;
	iterator->position		= 0.0f;

	return true;
}


bool_T					  prtIsRoundaboutAt(INOUT		roundaboutIterator_T	*iterator,
											IN	const	real32_T				 position,
											IN	const	bool_T					 searchInclusive,
											OUT			bool_T					*roundabout,
											OUT	OPT		real32_T				*tail)
{
	diagFF(iterator->path->info.roundaboutRing.count <= (ringId_T)mapINFOROUNDABOUTCOUNT);

	while(   (searchInclusive
		       ? (position >= prtScalePosition(iterator->path, iterator->path->info.roundaboutRing.roundabout[iterator->index % (ringId_T)mapINFOROUNDABOUTCOUNT].position))
			   : (position >  prtScalePosition(iterator->path, iterator->path->info.roundaboutRing.roundabout[iterator->index % (ringId_T)mapINFOROUNDABOUTCOUNT].position)))
			  && (iterator->index < iterator->path->info.roundaboutRing.count)) {
		iterator->roundabout	= iterator->path->info.roundaboutRing.roundabout[iterator->index % (ringId_T)mapINFOROUNDABOUTCOUNT].roundabout;
		iterator->position		= prtScalePosition(iterator->path, iterator->path->info.roundaboutRing.roundabout[iterator->index % (ringId_T)mapINFOROUNDABOUTCOUNT].position);
		iterator->index++;
	}

	*roundabout	= iterator->roundabout;
	if(NULL != tail)		{ *tail			= position - iterator->position; }

	return true;
}


static bool_T				uint8ToRampType(IN const	uint8_T					 typeIn,
											OUT			prtRampValues_T			*typeOut)
{
	switch (typeIn)
	{
	case 0u: *typeOut = prtRampTwoWay;	break;
	case 1u: *typeOut = prtRampUp;		break;
	case 2u: *typeOut = prtRampDown;	break;
	case 3u: *typeOut = prtRampOneWay;	break;
	case 4u: *typeOut = prtRampInit;	break;
	default: diagFUnreachable();
	} /*lint !e9077*/
	return true;
}


static bool_T			uint8ToStreetClass(IN const	uint8_T						 classIn,
										   OUT		prtStreetClassValues_T		*classOut)
{
	switch (classIn)
	{
	case 0u: *classOut = prtStreetClassMisc;		break;
	case 1u: *classOut = prtStreetClassLocal;		break;
	case 2u: *classOut = prtStreetClassDistrict;	break;
	case 3u: *classOut = prtStreetClassCountry;		break;
	case 4u: *classOut = prtStreetClassFederal;		break;
	case 5u: *classOut = prtStreetClassHighway;		break;
	case 6u: *classOut = prtStreetClassInit;		break;
	case 7u: *classOut = prtStreetClassInit;		break;
	default: diagFUnreachable();
	} /*lint !e9077*/
	return true;
}

static bool_T			uint8ToROWC(IN const	uint8_T							 rowcIn,
									OUT			prtRightOfWayControlValues_T	*rowcOut)
{
	switch (rowcIn)
	{
	case  0u: *rowcOut = prtRowcNone;							break;
	case  1u: *rowcOut = prtRowcStopSign;						break;
	case  2u: *rowcOut = prtRowcGiveRightOfWay;					break;
	case  3u: *rowcOut = prtRowcRightOfWayBegin;				break;
	case  4u: *rowcOut = prtRowcRightOfWayEnd;					break;
	case  5u: *rowcOut = prtRowcReducedTrafficAreaEntry;		break;
	case  6u: *rowcOut = prtRowcReducedTrafficAreaLeaving;		break;
	case  7u: *rowcOut = prtRowcLeftYields;						break;
	case  8u: *rowcOut = prtRowcRoundabout;						break;
	case  9u: *rowcOut = prtRowcNoInfo;							break;
	case 10u: *rowcOut = prtRowcIntersectionWithStraightPath;	break;
	case 11u: *rowcOut = prtRowcIntersectionNoStraightPath;		break;
	case 12u: *rowcOut = prtRowcTrafficLight;					break;
	case 13u: *rowcOut = prtRowcTrafficLightWithGreenArrow;		break;
	default: diagFUnreachable();
	} /*lint !e9077*/

	return true;
}

static bool_T	  uint8ToTrafficDir(IN const	uint8_T							 dirIn,
									OUT			vobsTrafficDir_T				*dirOut)
{
	switch (dirIn)
	{
	case  0u: *dirOut = trafficDirUnknown;	break;
	case  1u: *dirOut = trafficDirLeft;		break;
	case  2u: *dirOut = trafficDirRight;	break;
	default: diagFUnreachable();
	} /*lint !e9077*/

	return true;
}


bool_T					prtGetClassIterator(IN	const	mapPath_T				*mapPath,
											OUT			classIterator_T			*iterator)
{
	diagFF(mapPath->info.streetClassRing.count > 0u);

	iterator->path			= mapPath;
	iterator->index			= 0;
	iterator->streetClass	= mapPath->info.streetClassRing.streetClass[0].type;

	return true;
}


bool_T						  prtGetClassAt(INOUT		classIterator_T			*iterator,
											IN	const	real32_T				 position,
											OUT			prtStreetClassValues_T	*streetClass)
{
	diagFF(iterator->path->info.streetClassRing.count <= (ringId_T)mapINFOSTREETCLASSCOUNT);

	while((position >= prtScalePosition(iterator->path, iterator->path->info.streetClassRing.streetClass[iterator->index % (ringId_T)mapINFOSTREETCLASSCOUNT].position))
		  && (iterator->index < iterator->path->info.streetClassRing.count)) {
		iterator->streetClass	= iterator->path->info.streetClassRing.streetClass[iterator->index % (ringId_T)mapINFOSTREETCLASSCOUNT].type;
		iterator->index++;
	}

	diagFF(uint8ToStreetClass(iterator->streetClass, streetClass));

	return true;
}


bool_T				  prtGetBuiltUpIterator(IN	const	mapPath_T				*mapPath,
											OUT			builtUpIterator_T		*iterator)
{
	diagFF(mapPath->info.builtUpRing.count > 0u);

	iterator->path			= mapPath;
	iterator->index			= 0;
	iterator->builtUp		= mapPath->info.builtUpRing.builtUp[0].builtUp;

	return true;
}


bool_T					prtGetBuiltUpAreaAt(INOUT		builtUpIterator_T		*iterator,
											IN	const	real32_T				 position,
											OUT			bool_T					*builtUp)
{
	diagFF(iterator->path->info.builtUpRing.count <= (ringId_T)mapINFOBUILTUPAREACOUNT);

	while((position >= prtScalePosition(iterator->path, iterator->path->info.builtUpRing.builtUp[iterator->index % (ringId_T)mapINFOBUILTUPAREACOUNT].position))
		  && (iterator->index < iterator->path->info.builtUpRing.count)) {
		iterator->builtUp	= iterator->path->info.builtUpRing.builtUp[iterator->index % (ringId_T)mapINFOBUILTUPAREACOUNT].builtUp;
		iterator->index++;
	}

	*builtUp = iterator->builtUp;

	return true;
}


bool_T					 prtGetLaneIterator(IN	const	mapPath_T				*mapPath,
											OUT			laneIterator_T			*iterator)
{
	diagFF(mapPath->info.laneSituationRing.count > 0u);

	iterator->path			= mapPath;
	iterator->index			= 0;
	iterator->forwardLanes	= mapPath->info.laneSituationRing.laneSituation[0].forwardLanes;

	return true;
}


bool_T				   prtGetForwardLanesAt(INOUT		laneIterator_T			*iterator,
											IN	const	real32_T				 position,
											OUT			uint16_T				*forwardLanes)
{
	diagFF(iterator->path->info.laneSituationRing.count <= (ringId_T)mapINFOLANESITUATIONCOUNT);

	while((position >= prtScalePosition(iterator->path, iterator->path->info.laneSituationRing.laneSituation[iterator->index % (ringId_T)mapINFOLANESITUATIONCOUNT].position))
		  && (iterator->index < iterator->path->info.laneSituationRing.count)) {
		iterator->forwardLanes	= iterator->path->info.laneSituationRing.laneSituation[iterator->index % (ringId_T)mapINFOLANESITUATIONCOUNT].forwardLanes;
		iterator->index++;
	}

	*forwardLanes = iterator->forwardLanes;

	return true;
}


bool_T					 prtGetRampIterator(IN	const	mapPath_T				*mapPath,
											OUT			rampIterator_T			*iterator)
{
	prtRampValues_T rampType;
	diagFF(uint8ToRampType(mapPath->info.rampRing.ramp[0].type, &rampType));

	diagFF(mapPath->info.rampRing.count > 0u);

	iterator->path			= mapPath;
	iterator->index			= 0;
	iterator->rampUp		= (rampType == prtRampUp)   ? true : false;
	iterator->rampDown		= (rampType == prtRampDown) ? true : false;

	return true;
}


bool_T						 prtGetNextRamp(INOUT		rampIterator_T			*iterator,
											OUT			bool_T					*valid,
											OUT			real32_T				*position,
											OUT			prtRampValues_T			*type)
{	
	volatile uint16_T index;

	if (iterator->index < iterator->path->info.rampRing.count)
	{
		index = iterator->index;
		*valid = true;
	} else {
		index = iterator->index - 1u;
		*valid = false;
	}

	diagFF(index < (uint16_T)mapINFORAMPCOUNT);
	*position = prtScalePosition(iterator->path, iterator->path->info.rampRing.ramp[index].position);
	diagFF(uint8ToRampType(iterator->path->info.rampRing.ramp[index].type, type));
	
	if (*valid)
	{
		iterator->index = index + 1u;
	} else {
		index = iterator->index;
	}

	iterator->rampUp	= (*type == prtRampUp)		? true : false;
	iterator->rampDown	= (*type == prtRampDown)	? true : false;

	return true;
}


bool_T						    prtIsRampAt(INOUT		rampIterator_T			*iterator,
											IN	const	real32_T				 position,
											OUT			bool_T					*rampUp,
											OUT			bool_T					*rampDown)
{
	diagFF(iterator->path->info.rampRing.count <= (ringId_T)mapINFORAMPCOUNT);

	while(   (position >= prtScalePosition(iterator->path, iterator->path->info.rampRing.ramp[iterator->index % (ringId_T)mapINFORAMPCOUNT].position))
		  && (iterator->index < iterator->path->info.rampRing.count)) {
		prtRampValues_T rampType;
		diagFF(uint8ToRampType(iterator->path->info.rampRing.ramp[iterator->index % (ringId_T)mapINFORAMPCOUNT].type, &rampType));
		iterator->rampUp	= (rampType == prtRampUp)   ? true : false;
		iterator->rampDown	= (rampType == prtRampDown) ? true : false;
		iterator->index++;
	}

	*rampUp		= iterator->rampUp;
	*rampDown	= iterator->rampDown;

	return true;
}


void				   prtGetMaxBranchCount(OUT			uint16_T				*maxCount)
{
	*maxCount = mapINFOBRANCHANGLECOUNT;
}


bool_T						   prtGetStatus(IN const	mapPath_T				*mapPath)
{
	return mapPath->valid;
}


uint8_T			   prtGetPositionResetCount(IN const	mapPath_T				*mapPath)
{
	return mapPath->positionResetCount;
}


uint8_T					 prtGetRerouteCount(IN const	mapPath_T				*mapPath)
{
	return mapPath->rerouteCount;
}


prtSpeedLimitUnit_T    prtGetSpeedLimitUnit(IN	const	mapPath_T				*mapPath)
{
	prtSpeedLimitUnit_T retVal;

	switch (mapPath->info.systemAttributes.speedLimitUnit)
	{
	case (psdSpeedLimitUnit_T)PSD_EHR_ATTRIBUTE_SYSTEM_UNIT_SPEED_KMH:	retVal = prtSpeedLimitUnitKMH; break;
	case (psdSpeedLimitUnit_T)PSD_EHR_ATTRIBUTE_SYSTEM_UNIT_SPEED_MPH:	retVal = prtSpeedLimitUnitMPH; break;
	default:															retVal = prtSpeedLimitUnitUnknown; break;
	}
	return retVal;
}


bool_T						  prtGetBaseGps(IN	const	mapPath_T				*mapPath,
											OUT			prtBaseGPS_T			*baseGPS)
{
	if (!mapPath->valid)
	{
		baseGPS->altitude	= INVALID_VALUE;
		baseGPS->latitude	= INVALID_VALUE64;
		baseGPS->longitude	= INVALID_VALUE64;
		baseGPS->heading	= INVALID_VALUE;
		baseGPS->position	= INVALID_VALUE;
		return false;
	} 
	else 
	{
		const infoGpsInfo_T *gpsInfo = &mapPath->info.gpsInfo;

		baseGPS->altitude	= gpsInfo->altitude == (psdAltitude_T)PSD_EHR_ALTITUDE_VALUE_INVALID	? INVALID_VALUE		: 
								(real32_T)PSD_EHR_ALTITUDE_OFFSET  + (real32_T)PSD_EHR_ALTITUDE_FACTOR  * (real32_T)gpsInfo->altitude;
		baseGPS->latitude	=	PSD_EHR_LATITUDE_OFFSET  +			 PSD_EHR_LATITUDE_FACTOR			* (real64_T)gpsInfo->latitude;
		baseGPS->longitude	=	PSD_EHR_LONGITUDE_OFFSET +			 PSD_EHR_LONGITUDE_FACTOR			* (real64_T)gpsInfo->longitude;
		baseGPS->heading	= gpsInfo->heading == (psdHeading_T)PSD_EHR_HEADING_VALUE_INVALID		? INVALID_VALUE		: 
								(real32_T)PSD_EHR_HEADING_OFFSET + (real32_T)PSD_EHR_HEADING_FACTOR		* (real32_T)gpsInfo->heading;	/*lint !e835 (Info -- A zero has been given as left argument to operator '+')*/
		baseGPS->position	= prtScalePosition(mapPath, gpsInfo->position);
		return true;
	}
}


real32_T			prtGetHeadingCorrection(IN	const	mapPath_T				*mapPath)
{
	return mapPath->headingCorrection;
}


real32_T					 prtGetDistance(IN	const	mapPath_T				*mapPath)
{
	return prtScalePosition(mapPath, mapPath->info.distance);
}


uint16_T			  prtGetSpeedLimitCount(IN	const	mapPath_T				*mapPath)
{
	return mapPath->info.speedLimitRing.count;
}


uint16_T			 prtGetBranchAngleCount(IN	const	mapPath_T				*mapPath)
{
	return mapPath->info.branchAngleRing.count;
}


uint16_T				   prtGetSlopeCount(IN	const	mapPath_T				*mapPath)
{
	return mapPath->info.slopeRing.count;
}


uint16_T	   prtGetRightOfWayControlCount(IN	const	mapPath_T				*mapPath)
{
	return mapPath->info.rightOfWayRing.count;
}


uint16_T	prtGetMaxRightOfWayControlCount(void)
{
	return mapINFORIGHTOFWAYCOUNT;
}


bool_T					   prtGetSpeedLimit(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 index,
											OUT			prtSpeedLimit_T			*speedLimit)
{
	diagFF(mapPath->info.speedLimitRing.count <= (ringId_T)mapINFOSPEEDLIMITCOUNT);
	if (index >= mapPath->info.speedLimitRing.count)	{
		speedLimit->limit				= INVALID_VALUE;
		speedLimit->position			= INVALID_VALUE;
		speedLimit->constraintFog		= false;
		speedLimit->constraintTime		= false;
		speedLimit->constraintLane		= false;
		speedLimit->constraintTrailer	= false;
		speedLimit->constraintWet		= false;
		speedLimit->variableSign		= false;
		speedLimit->raw					= rawLimitInvalid;
		return false;
	}
	else
	{
		psdSpeedLimitUnit_T	unit;

		prtDecodeLimitInfo( mapPath->info.speedLimitRing.speedLimit[index].codedInfo,
						   &unit,
						   &speedLimit->constraintTrailer,
						   &speedLimit->constraintWet,
						   &speedLimit->constraintFog,
						   &speedLimit->constraintTime,
						   &speedLimit->constraintLane,
						   &speedLimit->variableSign);

		speedLimit->raw			= mapPath->info.speedLimitRing.speedLimit[index].value;
		speedLimit->position	= prtScalePosition(mapPath, mapPath->info.speedLimitRing.speedLimit[index].position);

		if(unit == (psdSpeedLimitUnit_T)prtSpeedLimitUnitKMH) 
		{
			speedLimit->limit = (real32_T)speedLimit->raw * KPH_TO_MPS;
		} else {
			speedLimit->limit = (real32_T)speedLimit->raw * MPH_TO_MPS;
		}

		return true;
	}
}


bool_T					 prtEncodeLimitInfo(IN	const	psdSpeedLimitUnit_T		 unit,
											IN	const	bool_T					 constraintTrailer,
											IN	const	bool_T					 constraintWet,
											IN	const	bool_T					 constraintFog,
											IN	const	bool_T					 constraintTime,
											IN	const	bool_T					 constraintLane,
											IN	const	bool_T					 variableSign,
											OUT			uint8_T					*coded)
{
	diagFF(((uint8_T)unit & prtLIMITCODEDUNIT) == (uint8_T)unit);

	*coded =   (unit & prtLIMITCODEDUNIT)
			 | (constraintTrailer	? prtLIMITCODEDCONSTRAINTTRAILER	: 0u)
			 | (constraintWet		? prtLIMITCODEDCONSTRAINTWET		: 0u)
			 | (constraintFog		? prtLIMITCODEDCONSTRAINTFOG		: 0u)
			 | (constraintTime		? prtLIMITCODEDCONSTRAINTTIME		: 0u)
			 | (constraintLane		? prtLIMITCODEDCONSTRAINTLANE		: 0u)
			 | (variableSign		? prtLIMITCODEDVARIABLESIGN			: 0u);

	return true;
}


static void				 prtDecodeLimitInfo(IN	const	uint8_T					 coded,
											OUT			psdSpeedLimitUnit_T		*unit,
											OUT			bool_T					*constraintTrailer,
											OUT			bool_T					*constraintWet,
											OUT			bool_T					*constraintFog,
											OUT			bool_T					*constraintTime,
											OUT			bool_T					*constraintLane,
											OUT			bool_T					*variableSign)
{
	*unit				= (coded & prtLIMITCODEDUNIT);
	*constraintTrailer	= (coded & prtLIMITCODEDCONSTRAINTTRAILER)	!= 0u ? true : false;
	*constraintWet		= (coded & prtLIMITCODEDCONSTRAINTWET)		!= 0u ? true : false;
	*constraintFog		= (coded & prtLIMITCODEDCONSTRAINTFOG)		!= 0u ? true : false;
	*constraintTime		= (coded & prtLIMITCODEDCONSTRAINTTIME)		!= 0u ? true : false;
	*constraintLane		= (coded & prtLIMITCODEDCONSTRAINTLANE)		!= 0u ? true : false;
	*variableSign		= (coded & prtLIMITCODEDVARIABLESIGN)		!= 0u ? true : false;
}


bool_T					  prtGetBranchAngle(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 index,
											OUT			prtBranchAngle_T		*branchAngle)
{
	diagFF(mapPath->info.branchAngleRing.count <= (ringId_T)mapINFOBRANCHANGLECOUNT);
	if (index >= mapPath->info.branchAngleRing.count)
	{
		branchAngle->angle = INVALID_VALUE;
		branchAngle->position = INVALID_VALUE;
		return false;
	}
	else {
		branchAngle->angle = (real32_T)PSD_EHR_BRANCHANGLE_OFFSET + (real32_T)PSD_EHR_BRANCHANGLE_FACTOR * (real32_T)mapPath->info.branchAngleRing.branchAngle[index].angle;
		branchAngle->position = prtScalePosition(mapPath, mapPath->info.branchAngleRing.branchAngle[index].position);
		return true;
	}
}


bool_T							prtGetSlope(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 index,
											OUT			prtSlope_T				*slope)
{
	diagFF(mapPath->info.slopeRing.count <= (ringId_T)mapINFOSLOPECOUNT);
	if (index >= mapPath->info.slopeRing.count)
	{
		slope->known		= false;
		slope->slope = INVALID_VALUE;
		slope->position = INVALID_VALUE;
		return false;
	}
	else if (mapPath->info.slopeRing.slope[index].slope == (psdSlope_T)PSD_EHR_SLOPE_VALUE_UNKNOWN)
	{
		slope->known		= false;
		slope->slope		= INVALID_VALUE;
		slope->position		= prtScalePosition(mapPath, mapPath->info.slopeRing.slope[index].position);
		return true;
	}
	else
	{
		/*Skalierung und Umwandlung von Prozent zu Verh�ltnis*/
		slope->known		= true;
		slope->slope		= ((real32_T)PSD_EHR_SLOPE_OFFSET + (real32_T)PSD_EHR_SLOPE_FACTOR * (real32_T)mapPath->info.slopeRing.slope[index].slope) / 100.0f;
		slope->position		= prtScalePosition(mapPath, mapPath->info.slopeRing.slope[index].position);
		return true;
	}
}


bool_T					  prtGetStreetClass(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 index,
											OUT			prtStreetClass_T		*streetClass)
{
	diagFF(mapPath->info.streetClassRing.count <= (ringId_T)mapINFOSTREETCLASSCOUNT);
	if (index >= mapPath->info.streetClassRing.count)
	{
		streetClass->type = prtStreetClassInit;
		streetClass->position = INVALID_VALUE;
		return false;
	}
	else
	{
		diagFF(uint8ToStreetClass(mapPath->info.streetClassRing.streetClass[index].type, &streetClass->type));
		streetClass->position = prtScalePosition(mapPath, mapPath->info.streetClassRing.streetClass[index].position);
		return true;
	}
}


bool_T				prtGetRightOfWayControl(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 index,
											OUT			prtRightOfWayControl_T	*rightOfWayControl)
{
	diagFF(mapPath->info.rightOfWayRing.count <= (ringId_T)mapINFORIGHTOFWAYCOUNT);
	if (index >= mapPath->info.rightOfWayRing.count)
	{
		rightOfWayControl->type = prtRowcNoInfo;
		rightOfWayControl->position = INVALID_VALUE;
		return false;
	}
	else
	{
		diagFF(uint8ToROWC(mapPath->info.rightOfWayRing.rightOfWayControl[index].type, &rightOfWayControl->type));
		rightOfWayControl->position = prtScalePosition(mapPath, mapPath->info.rightOfWayRing.rightOfWayControl[index].position);
		return true;
	}
}


bool_T					prtGetLaneSituation(IN	const	mapPath_T				*mapPath,
											IN	const	uint16_T				 index,
											OUT			prtLaneSituation_T		*laneSituation)
{
	diagFF(mapPath->info.laneSituationRing.count <= (ringId_T)mapINFOLANESITUATIONCOUNT);
	if (index >= mapPath->info.laneSituationRing.count)
	{
		laneSituation->forwardLanes   = INVALID_UINT8;
		laneSituation->oppositeLanes  = INVALID_UINT8;
		laneSituation->turnLanesLeft  = INVALID_UINT8;
		laneSituation->turnLanesRight = INVALID_UINT8;
		laneSituation->position = INVALID_VALUE;
		return false;
	}
	else
	{
		laneSituation->forwardLanes = mapPath->info.laneSituationRing.laneSituation[index].forwardLanes;
		laneSituation->oppositeLanes = mapPath->info.laneSituationRing.laneSituation[index].oppositeLanes;
		laneSituation->turnLanesLeft = mapPath->info.laneSituationRing.laneSituation[index].turnLanesLeft;
		laneSituation->turnLanesRight = mapPath->info.laneSituationRing.laneSituation[index].turnLanesRight;
		laneSituation->position = prtScalePosition(mapPath, mapPath->info.laneSituationRing.laneSituation[index].position);
		return true;
	}
}


bool_T				 prtGetTrafficDirection(IN	const	mapPath_T				*mapPath,
											OUT			vobsTrafficDir_T		*trafficDirection)
{
	diagFF(uint8ToTrafficDir(mapPath->info.systemAttributes.trafficDirection, trafficDirection));
	return true;
}
