#ifndef guard_prtDataInterfaceStatic_h
#define guard_prtDataInterfaceStatic_h

#include "pathRouter_private.h"



/** \brief Rechnet den Ganzzahligen Wert `position` in den physikalischen Wert relativ zur Fahrzeugposition um. 
\ingroup pathRouter_api
*/
static real32_T				  prtScalePosition(	IN const mapPath_T						*mapPath,					/**<fl�chtige Pfaddaten*/
												IN const uint16_T						 position  					/**<Ganzzahlige Position*/
								);

/**\brief �bertr�gt Rampentyp von uint8_T in den Enum-Wert
\ingroup pathRouter_api
*/
static bool_T				uint8ToRampType(IN const	uint8_T						 typeIn,					/**<Eingang Rampentyp*/
											OUT			prtRampValues_T				*typeOut					/**<Ausgang Rampentyp*/
								);


/**\brief �bertr�gt Stra�enklasse von uint8_T in den Enum-Wert
\ingroup pathRouter_api
*/
static bool_T			 uint8ToStreetClass(IN const	uint8_T						 classIn,					/**<Eingang Stra�enklasse*/
											OUT			prtStreetClassValues_T		*classOut					/**<Ausgang Stra�enklasse*/
									);


/**\brief �bertr�gt Vorfahrtsregelung von uint8_T in den Enum-Wert
\ingroup pathRouter_api
*/
static bool_T					uint8ToROWC(IN const	uint8_T							 rowcIn,				/**<Eingang Vorfahrtsregelung*/
											OUT			prtRightOfWayControlValues_T	*rowcOut				/**<Ausgang Vorfahrtsregelung*/
											);


static void				 prtDecodeLimitInfo(IN	const	uint8_T							 coded,
											OUT			psdSpeedLimitUnit_T				*unit,
											OUT			bool_T							*constraintTrailer,
											OUT			bool_T							*constraintWet,
											OUT			bool_T							*constraintFog,
											OUT			bool_T							*constraintTime,
											OUT			bool_T							*constraintLane,
											OUT			bool_T							*variableSign
								);

#endif
