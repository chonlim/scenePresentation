#ifndef guard_prtDataInterfaceTypes_h
#define guard_prtDataInterfaceTypes_h

#include "common/common.h"
#include "common/pathRouterCommon/pathRouter_interface.h"


typedef struct curvatureIterator_tag {
	const mapPath_T		*path;			/**< Zeiger auf die Struktur, deren Daten abgefragt werden */
	uint16_T			 index;			/**< Aktueller Index in der Liste */
	bool_T				 second;		/**< Gibt an, ob der aktuelle Kr�mmungswert zum zweiten Mal "angefahren" wird */
	bool_T				 valid;			/**< Gibt an, ob die Ergebnisse noch g�ltig sind oder die Suche bereits "�bergelaufen" ist */
} curvatureIterator_T;


typedef struct roundaboutIterator_tag {
	const mapPath_T		*path;			/**< Zeiger auf die Struktur, deren Daten abgefragt werden */
	uint16_T			 index;			/**< Aktueller Index der Kreisverkehrsliste*/
	bool_T				 roundabout;	/**< Sind wir aktuell im Kreisverkehr? */
	real32_T			 position;		/**< Wo lag das letzte Kreisverkehrs-Attribut? */
} roundaboutIterator_T;


typedef struct rampIterator_tag {
	const mapPath_T		*path;			/**< Zeiger auf die Struktur, deren Daten abgefragt werden */
	uint16_T			 index;			/**< Stra�enklassenliste */
	bool_T				 rampUp;		/**< Befinden wir uns aktuell auf einer Auffahrt? */
	bool_T				 rampDown;		/**< Befinden wir uns aktuell auf einer Abfahrt? */
} rampIterator_T;


#endif
