#ifndef guard_prtDataInterface_h
#define guard_prtDataInterface_h

#include "common/common.h"
#include "pathRouter_interface.h"
#include "common/pathRouterCommon/prtDataInterfaceTypes.h"
#include "common/pathRouterCommon/pathRouter_interface.h"
#include "common/psdWrapperCommon/psdWrapper_interface.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"


typedef struct classIterator_tag {
	const mapPath_T		*path;			/**< Zeiger auf die Struktur, deren Daten abgefragt werden */
	uint16_T			 index;			/**< Aktueller Index der Stra�enklassenliste */
	uint8_T				 streetClass;	/**< Auf welcher Stra�enklasse befinden wir uns aktuell? */
} classIterator_T;


typedef struct builtUpIterator_tag {
	const mapPath_T		*path;			/**< Zeiger auf die Struktur, deren Daten abgefragt werden */
	uint16_T			 index;			/**< Aktueller Index in der BuiltUp-Area-Liste*/
	bool_T				 builtUp;		/**< Auf welcher Stra�enklasse befinden wir uns aktuell? */
} builtUpIterator_T;


typedef struct laneIterator_tag {
	const mapPath_T		*path;			/**< Zeiger auf die Struktur, deren Daten abgefragt werden */
	uint16_T			 index;			/**< Aktueller Index in der laneSituation-Liste */
	uint16_T			 forwardLanes;	/**< Anzahl der Fahrspuren in Fahrtrichtung */
} laneIterator_T;


/**	\brief		Erstellt einen Iterator, um die im mapPath hinterlegten Kr�mmungswerte auszulesen
\spec SwMS_Innodrive2_PSD_83
\ingroup	pathRouter_api
*/
bool_T				prtGetCurvatureIterator(IN	const	mapPath_T				*mapPath,			/**< interne Datenstruktur der linearisierten Streckendaten */
											OUT			curvatureIterator_T		*iterator			/**< interne Datenstruktur des Iterators */
											);


/**	\brief		Fragt den n�chsten Kr�mmungswert des Iterators ab
	\details	Die Abfrage kann beliebig oft wiederholt werden. Nachdem das Ende der Liste erreicht ist, wird wieder vom Beginn aus gesucht, die Ergebnisse
				werden aber als ung�ltig (valid == false) markiert 
	\spec SwMS_Innodrive2_PSD_86
	\ingroup pathRouter_api
*/
bool_T					prtGetNextCurvature(INOUT		curvatureIterator_T		*iterator,			/**< interne Datenstruktur des Iterators */
											OUT			bool_T					*valid,				/**< Gibt an, ob der Kr�mmungswert noch g�ltig ist oder die Suche bereits �bergelaufen ist */
											OUT			real32_T				*position,			/**< Position des Kr�mmungsst�tzpunktes [m] */
											OUT			real32_T				*curvature			/**< Kr�mmungswert [1/m] */
											);


/**\brief Erstellt einen Iterator, um die im mapPath hinterlegten Kreisverkehre auszulesen
\spec SwMS_Innodrive2_PSD_101
\ingroup	pathRouter_api
*/
bool_T			   prtGetRoundaboutIterator(IN	const	mapPath_T				*mapPath,			/**< interne Datenstruktur der linearisierten Streckendaten */
											OUT			roundaboutIterator_T	*iterator			/**< interne Datenstruktur des Iterators */
											);

/**\brief Gibt an, ob die �bergebene `position` auf in einem Kreisverkehr liegt.
\spec SwMS_Innodrive2_PSD_102
\ingroup pathRouter_api
*/
bool_T					  prtIsRoundaboutAt(INOUT		roundaboutIterator_T	*iterator,			/**< interne Datenstruktur des Iterators */
											IN	const	real32_T				 position,			/**< Position des Kr�mmungsst�tzpunktes [m] */
											IN	const	bool_T					 searchInclusive,	/**< Wenn wahr, wird der Flie�kommavergleich der Position mit "gr�er/gleich" statt "echt gr��er" ausgef�hrt*/
											OUT			bool_T					*roundabout,		/**< Wahr, wenn ein Kreisverkehr an der `position` vorliegt.*/
											OUT	OPT		real32_T				*tail				/**< Strecke Kreisverkehrsposition - Fahrzeugposition */
											);


/**\brief Erstellt einen Iterator, um die im mapPath hinterlegten Rampenwerte auszulesen
\ingroup	pathRouter_api
*/
bool_T					 prtGetRampIterator(IN	const	mapPath_T				*mapPath,			/**< interne Datenstruktur der linearisierten Streckendaten */
											OUT			rampIterator_T			*iterator			/**< interne Datenstruktur des Iterators */
											);


/**	\brief		Fragt die n�chste Rampenklasse des Iterators ab
	\details	Die Abfrage kann beliebig oft wiederholt werden. Nachdem das Ende der Liste erreicht ist, werden die Ergebnisse als ung�ltig (valid == false) markiert 
\ingroup pathRouter_api
*/
bool_T						 prtGetNextRamp(INOUT		rampIterator_T			*iterator,			/**< interne Datenstruktur des Iterators */
											OUT			bool_T					*valid,				/**< Gibt an, ob der Wert noch g�ltig ist oder die Suche bereits �bergelaufen ist */
											OUT			real32_T				*position,			/**< Position der Rampenklasse [m] */
											OUT			prtRampValues_T			*type				/**< Rampenklasse */
											);

/**\brief Gibt an, ob die �bergebene `position` auf einer Auf- oder Abfahrt auf/von einer Autobahn/Schnellstra�e liegt.
Die Funktion soll TRUE zur�ckgeben, wenn das PSD "ramp"-Attribut des entsprechenden Segments auf PSD_EHR_RAMP_UP_ONE_WAY oder RAMP_DOWN_ONE_WAY steht, andernfalls FALSE.
\ingroup pathRouter_api
*/
bool_T							prtIsRampAt(INOUT		rampIterator_T			*iterator,			/**< interne Datenstruktur des Iterators */
											IN	const	real32_T				 position,			/**< Abfrageposition [m] */
											OUT			bool_T					*rampUp,			/**< Wahr, wenn an der `position` eine Auffahrt vorliegt*/
											OUT			bool_T					*rampDown			/**< Wahr, wenn an der `position` eine Abfahrt vorliegt*/
											);


/**\brief Erstellt einen Iterator, um die im mapPath hinterlegten Rampenwerte auszulesen
\ingroup	pathRouter_api
*/
bool_T					prtGetClassIterator(IN	const	mapPath_T				*mapPath,			/**< interne Datenstruktur der linearisierten Streckendaten */
											OUT			classIterator_T			*iterator			/**< interne Datenstruktur des Iterators */
											);


/**	\brief		Gibt die Stra�enklasse zur�ck, auf der die `position` liegt.
	\ingroup	pathRouter_api
*/
bool_T						  prtGetClassAt(INOUT		classIterator_T			*iterator,			/**< interne Datenstruktur des Iterators */
											IN	const	real32_T				 position,			/**< Abfrageposition [m] */
											OUT			prtStreetClassValues_T	*streetClass		/**< Stra�enklasse an der angegebenen Position */
											);


/**\brief Erstellt einen Iterator, um die im mapPath hinterlegten Built Up Area-Werte auszulesen
\ingroup	pathRouter_api
*/
bool_T				  prtGetBuiltUpIterator(IN	const	mapPath_T				*mapPath,			/**< interne Datenstruktur der linearisierten Streckendaten */
											OUT			builtUpIterator_T		*iterator			/**< interne Datenstruktur des Iterators */
											);


/**	\brief		Fragt das Bebauungs-Flag an `position` ab
	\ingroup	pathRouter_api
*/
bool_T					prtGetBuiltUpAreaAt(INOUT		builtUpIterator_T		*iterator,			/**< interne Datenstruktur des Iterators */
											IN	const	real32_T				 position,			/**< Abfrageposition [m] */
											OUT			bool_T					*builtUp			/**< Bebauungs-Flag an der angegebenen Position */
											);


/**\brief Erstellt einen Iterator, um die Anzahl der Fahrspuren auszulesen
\ingroup	pathRouter_api
*/
bool_T					 prtGetLaneIterator(IN	const	mapPath_T				*mapPath,			/**< interne Datenstruktur der linearisierten Streckendaten */
											OUT			laneIterator_T			*iterator			/**< interne Datenstruktur des Iterators */
											);


/**	\brief		Fragt die Anzahl der Fahrspuren in Fahrtrichtung an 'position' ab
	\ingroup	pathRouter_api
*/
bool_T				   prtGetForwardLanesAt(INOUT		laneIterator_T			*iterator,			/**< interne Datenstruktur des Iterators */
											IN	const	real32_T				 position,			/**< Abfrageposition [m] */
											OUT			uint16_T				*forwardLanes		/**< Anzalh der Fahrspuren an der angegebenen Position */
											);


/**	\brief	Fragt die maximal m�gliche Anzahl von Abbiegewinkeln im mapPath ab 
\spec SwMS_Innodrive2_PSD_81
\ingroup pathRouter_api
*/
void				   prtGetMaxBranchCount(OUT			uint16_T				*maxCount			/**< maximal m�gliche Anzahl von Abbiegewinkeln */
											);


/** \brief Gibt Status (false: ung�ltig, true: g�ltig) des mapPath zur�ck.
\spec SwMS_Innodrive2_PSD_72
\ingroup pathRouter_api
*/
bool_T						   prtGetStatus(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);


/**	\brief Gibt die Zahl der Resets des Positionsfilters nach der letzten Neu-Initialisierung zur�ck.
\spec SwMS_Innodrive2_PSD_77
\ingroup pathRouter_api
*/
uint8_T			   prtGetPositionResetCount(IN	const	mapPath_T			*mapPath		/**<Struktur der linearisierten Streckendaten*/
											);


/**	\brief Gibt die Zahl der Reroutings der mapRoute Neu-Initialisierung zur�ck.
\spec SwMS_Innodrive2_PSD_78
\ingroup pathRouter_api
*/
uint8_T					 prtGetRerouteCount(IN	const	mapPath_T			*mapPath		/**<Struktur der linearisierten Streckendaten*/
											);


/** \brief Gibt die Einheit der Tempolimits zur�ck.
\ingroup pathRouter_api
*/
prtSpeedLimitUnit_T	   prtGetSpeedLimitUnit(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);

/** \brief Gibt die GPS-Daten des mapPath zur�ck.
\spec SwMS_Innodrive2_PSD_75
\ingroup pathRouter_api
*/
bool_T						  prtGetBaseGps(IN	const		mapPath_T		*mapPath,		/**<Struktur der linearisierten Streckendaten*/
											OUT				prtBaseGPS_T	*baseGPS  		/**<GPS-Koordinaten inklusive H�he und position*/
											);


/** \brief Gibt die Heading-Korrektur zur�ck.

Wenn die aus der Karte erhaltene Heading eine Unstetigkeit aufweist, wird diese hier als Korrektur ausgegeben.
Die Korrektur wird mit einem parametrierbaren Gradienten pro Zeitschritt wieder auf Null zur�ckgesetzt.
Bei ung�ltigen Kartendaten ist die Korrektur Null.
\spec SwMS_Innodrive2_PSD_76
\ingroup pathRouter_api
*/
real32_T			prtGetHeadingCorrection(IN	const		mapPath_T		*mapPath		/**<Struktur der linearisierten Streckendaten*/
											);


/** \brief Gibt die Streckenl�nge des mapPaths in Meter von der Egoposition bis zur letzten verzeichneten Curvature zur�ck.
\spec SwMS_Innodrive2_PSD_74
\ingroup pathRouter_api
*/
real32_T					 prtGetDistance(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);


/** \brief Gibt die Zahl der gespeicherten Tempolimits zur�ck.
\spec SwMS_Innodrive2_PSD_109
\spec SwMS_Innodrive2_PSD_109
\ingroup pathRouter_api
*/
uint16_T			  prtGetSpeedLimitCount(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);


/** \brief Gibt die Zahl der gespeicherten Abzweigungswinkel zur�ck.
\spec SwMS_Innodrive2_PSD_80
\ingroup pathRouter_api
*/
uint16_T			 prtGetBranchAngleCount(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);


/** \brief Gibt die Zahl der gespeicherten Steigungen zur�ck.
\spec SwMS_Innodrive2_PSD_106
\ingroup pathRouter_api
*/
uint16_T				   prtGetSlopeCount(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);


/** \brief Gibt die Zahl der gespeicherten Vorfahrtsregelungen (au�er Ampeln) zur�ck.
\spec SwMS_Innodrive2_PSD_99
\ingroup pathRouter_api
*/
uint16_T	   prtGetRightOfWayControlCount(IN	const	mapPath_T			*mapPath  		/**<Struktur der linearisierten Streckendaten*/
											);


/**	\brief		Gibt die maximale Anzahl von Vorfahrtsregelungen zur�ck 
	\ingroup	pathRouter_api */
uint16_T	prtGetMaxRightOfWayControlCount(void);


/** \brief Gibt Position und Wert (in [m/s]) des SpeedLimit mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Die Zahl der abgelegten Elemente kann mit \ref prtGetSpeedLimitCount() abgefragt werden.

\spec SwMS_Innodrive2_PSD_108
\ingroup pathRouter_api
*/
bool_T					   prtGetSpeedLimit(IN	const	mapPath_T			*mapPath,		/**<Struktur der linearisierten Streckendaten*/
											IN	const	uint16_T			 index,			/**<Array-Index*/
											OUT			prtSpeedLimit_T		*speedLimit  	/**<SpeedLimit am angegeben index*/
											);


bool_T					 prtEncodeLimitInfo(IN	const	psdSpeedLimitUnit_T		 unit,
											IN	const	bool_T					 constraintTrailer,
											IN	const	bool_T					 constraintWet,
											IN	const	bool_T					 constraintFog,
											IN	const	bool_T					 constraintTime,
											IN	const	bool_T					 constraintLane,
											IN	const	bool_T					 variableSign,
											OUT			uint8_T					*coded
											);


/** \brief Gibt Position und Wert in Grad des BranchAngle mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Die Zahl der abgelegten Elemente kann mit \ref prtGetBranchAngleCount() abgefragt werden.
	
\spec SwMS_Innodrive2_PSD_79
\ingroup pathRouter_api
*/
bool_T					  prtGetBranchAngle(IN	const	mapPath_T			*mapPath,		/**<Struktur der linearisierten Streckendaten*/
											IN	const	uint16_T			 index,			/**<Array-Index*/
											OUT			prtBranchAngle_T	*branchAngle  	/**<BranchAngle am angegeben index*/
											);

/** \brief Gibt Position und Wert der Slope mit dem angegebenen index aus.

Ein Steigung mit dem WERT PSD_EHR_SLOPE_UNKNOWN wir als Steigung g�ltige Steigung mit 
g�ltiger position und dem slope-Wert INVALID_VALUE ausgegeben.
R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Die Zahl der abgelegten Elemente kann mit \ref prtGetSlopeCount() abgefragt werden.
	
\spec SwMS_Innodrive2_PSD_105
\ingroup pathRouter_api
*/
bool_T							prtGetSlope(IN	const	mapPath_T			*mapPath,		/**< Struktur der linearisierten Streckendaten*/
											IN	const	uint16_T			 index,			/**< Array-Index*/
											OUT			prtSlope_T			*slope  		/**< Slope am angegeben index*/
											);


/** \brief Gibt Position und Wert der Stra�enklasse mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Zur Abfrage soll der \ref prtGetClassIterator() verwendet werden.

\spec SwMS_Innodrive2_PSD_113
\ingroup pathRouter_api
*/
bool_T					  prtGetStreetClass(IN	const	mapPath_T				*mapPath,				/**<Struktur der linearisierten Streckendaten*/
											IN	const	uint16_T				 index,					/**<Array-Index*/
											OUT			prtStreetClass_T		*streetClass			/**<rightOfWayControl am angegeben index*/
											);


/** \brief Gibt Position und Wert der RightOfWayControl mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Die Zahl der abgelegten Elemente kann mit \ref prtGetRightOfWayControlCount() abgefragt werden.

\spec SwMS_Innodrive2_PSD_98
\ingroup pathRouter_api
*/
bool_T				prtGetRightOfWayControl(IN	const	mapPath_T				*mapPath,				/**<Struktur der linearisierten Streckendaten*/
											IN	const	uint16_T				 index,					/**<Array-Index*/
											OUT			prtRightOfWayControl_T	*rightOfWayControl  	/**<rightOfWayControl am angegeben index*/
											);


/** \brief GibtPosition und Spuren(Vorw�rts, Gegenverkehr, Linksabbiegen, Rechtsabbiegen) mit dem angegebenen index aus.

R�ckgabewert ist falsch, wenn an der Stelle index kein Element abgelegt ist.
Zur Abfrage soll der \ref prtGetLaneIterator() verwendet werden.

\spec SwMS_Innodrive2_PSD_90
\ingroup pathRouter_api
*/
bool_T					prtGetLaneSituation(IN	const	mapPath_T				*mapPath,				/**<Struktur der linearisierten Streckendaten*/
											IN	const	uint16_T				 index,					/**<Array-Index*/
											OUT			prtLaneSituation_T		*laneSituation			/**<Spursituation am angegeben index*/
											);


/** \brief Gibt die Verkehrsrichtung (Linksverkehr/Rechtsverkehr) an der Fahrzeugposition aus
\spec SwMS_Innodrive2_PSD_186
\ingroup pathRouter_api
*/
bool_T				 prtGetTrafficDirection(IN	const	mapPath_T				*mapPath,				/**<Struktur der linearisierten Streckendaten*/
											OUT			vobsTrafficDir_T		*trafficDirection		/**<Verkehrsrichtung an Fahrzeugposition*/
											);


#endif
