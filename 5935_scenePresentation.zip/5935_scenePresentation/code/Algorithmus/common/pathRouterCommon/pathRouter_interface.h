#ifndef guard_pathRouter_interface_h
#define guard_pathRouter_interface_h

#include "base.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define mapPATHGPSCOUNT 4
#define mapPATHSPEEDLIMITCOUNT 10
#define mapPATHCURVATURECOUNT 64
#define mapPATHBRANCHANGLECOUNT 21
#define mapPATHSLOPECOUNT 128
#define mapPATHBUILTUPAREACOUNT 21
#define mapPATHLANESITUATIONCOUNT 32
#define mapPATHRIGHTOFWAYCOUNT 32
#define mapPATHSTREETSITUATIONCOUNT 12
#define mapPATHDYNAMICEVENTCOUNT 21
#define mapPATHONLINESPEEDCOUNT 10
#define mapMAXROUTELENGTH 21
#define mapPATHSTREETCLASSCOUNT 21
#define mapPATHRAMPCOUNT 21
#define mapPATHTRAFFICDIRECTIONCOUNT 2
#define mapPATHCOUNTRYCODECOUNT 2
#define mapPATHSPEEDLIMITUNITCOUNT 2
#define mapPATHQUALITYGEOMETRYCOUNT 21
#define mapINFOSPEEDLIMITCOUNT 6
#define mapINFOCURVATURECOUNT 25
#define mapINFOBRANCHANGLECOUNT 4
#define mapINFOSLOPECOUNT 30
#define mapINFOBUILTUPAREACOUNT 8
#define mapINFOLANESITUATIONCOUNT 16
#define mapINFOSTREETCLASSCOUNT 4
#define mapINFORAMPCOUNT 6
#define mapINFORIGHTOFWAYCOUNT 6
#define mapINFOROUNDABOUTCOUNT 6




typedef enum _prtSpeedLimitUnit {
	prtSpeedLimitUnitKMH = 0,
	prtSpeedLimitUnitMPH = 1,
	prtSpeedLimitUnitUnknown = 2
} prtSpeedLimitUnit_T;

typedef enum _prtStreetClassValues {
	prtStreetClassMisc = 0,              /**< Rest_Feldweg_Schotterweg_Privatweg */
	prtStreetClassLocal = 1,             /**< Ortsstrasse */
	prtStreetClassDistrict = 2,          /**< Kreisstrasse */
	prtStreetClassCountry = 3,           /**< Landstrasse */
	prtStreetClassFederal = 4,           /**< Bundesstrasse */
	prtStreetClassHighway = 5,           /**< Autobahn */
	prtStreetClassInit = 7               /**< Init */
} prtStreetClassValues_T;

typedef enum _prtRampValues {
	prtRampTwoWay = 0,                   /**< Strasse mit Gegenverkehr */
	prtRampUp = 1,                       /**< Auffahrt Einbahnstrasse */
	prtRampDown = 2,                     /**< Abfahrt Einbahnstrasse */
	prtRampOneWay = 3,                   /**< Einbahnstrasse inklusive autobahnaehnliche */
	prtRampInit = 4                      /**< Initialwert */
} prtRampValues_T;

typedef enum _prtDynamicEventValues {
	prtDynamicEventNone = 0,
	prtDynamicEventHighwayRampUp = 1,
	prtDynamicEventLaneAccretion = 2
} prtDynamicEventValues_T;

typedef enum _prtRightOfWayControlValues {
	prtRowcNone = 0,
	prtRowcStopSign = 1,
	prtRowcGiveRightOfWay = 2,
	prtRowcRightOfWayBegin = 3,
	prtRowcRightOfWayEnd = 4,
	prtRowcReducedTrafficAreaEntry = 5,
	prtRowcReducedTrafficAreaLeaving = 6,
	prtRowcLeftYields = 7,
	prtRowcRoundabout = 8,
	prtRowcNoInfo = 9,
	prtRowcIntersectionWithStraightPath = 10,
	prtRowcIntersectionNoStraightPath = 11,
	prtRowcTrafficLight = 12,
	prtRowcTrafficLightWithGreenArrow = 13
} prtRightOfWayControlValues_T;

typedef enum _prtStreetSituationValues {
	prtStreetSituationRoundabout = 1
} prtStreetSituationValues_T;

typedef struct _mapGpsInfo mapGpsInfo_T;
typedef struct _infoGpsInfo infoGpsInfo_T;
typedef struct _mapRawVehiclePosition mapRawVehiclePosition_T;
typedef struct _mapPositionFilter mapPositionFilter_T;
typedef struct _mapGpsRing mapGpsRing_T;
typedef struct _speedLimit speedLimit_T;
typedef struct _infoSpeedLimit infoSpeedLimit_T;
typedef struct _mapSpeedLimitRing mapSpeedLimitRing_T;
typedef struct _curvature curvature_T;
typedef struct _infoCurvature infoCurvature_T;
typedef struct _mapCurvatureRing mapCurvatureRing_T;
typedef struct _branchAngle branchAngle_T;
typedef struct _infoBranchAngle infoBranchAngle_T;
typedef struct _mapBranchAngleRing mapBranchAngleRing_T;
typedef struct _slope slope_T;
typedef struct _infoSlope infoSlope_T;
typedef struct _infoBuiltUp infoBuiltUp_T;
typedef struct _mapSlopeRing mapSlopeRing_T;
typedef struct _builtUpArea builtUpArea_T;
typedef struct _mapBuiltUpRing mapBuiltUpRing_T;
typedef struct _laneSituation laneSituation_T;
typedef struct _dynamicEvent dynamicEvent_T;
typedef struct _mapLaneSituationRing mapLaneSituationRing_T;
typedef struct _infoLaneSituation infoLaneSituation_T;
typedef struct _streetClass streetClass_T;
typedef struct _ramp ramp_T;
typedef struct _mapDynamicEventRing mapDynamicEventRing_T;
typedef struct _rightOfWayControl rightOfWayControl_T;
typedef struct _streetSituation streetSituation_T;
typedef struct _trafficDirection trafficDirection_T;
typedef struct _countryCode countryCode_T;
typedef struct _speedLimitUnit speedLimitUnit_T;
typedef struct _qualityGeometry qualityGeometry_T;
typedef struct _infoStreetClass infoStreetClass_T;
typedef struct _infoRamp infoRamp_T;
typedef struct _infoRightOfWayControl infoRightOfWayControl_T;
typedef struct _infoRoundabout infoRoundabout_T;
typedef struct _mapStreetClassRing mapStreetClassRing_T;
typedef struct _mapRampRing mapRampRing_T;
typedef struct _mapRightOfWayRing mapRightOfWayRing_T;
typedef struct _mapStreetSituationRing mapStreetSituationRing_T;
typedef struct _mapTrafficDirectionRing mapTrafficDirectionRing_T;
typedef struct _mapCountryCodeRing mapCountryCodeRing_T;
typedef struct _mapSpeedLimitUnitRing mapSpeedLimitUnitRing_T;
typedef struct _mapQualityGeometryRing mapQualityGeometryRing_T;
typedef struct _mapSegmentRing mapSegmentRing_T;
typedef struct _mapRoute mapRoute_T;
typedef struct _mapRouteMemory mapRouteMemory_T;
typedef struct _mapSystemAttributes mapSystemAttributes_T;
typedef struct _mapHeadingFilter mapHeadingFilter_T;
typedef struct _mapPathMemory mapPathMemory_T;
typedef struct _infoSpeedLimitRing infoSpeedLimitRing_T;
typedef struct _infoCurvatureRing infoCurvatureRing_T;
typedef struct _infoBranchAngleRing infoBranchAngleRing_T;
typedef struct _infoSlopeRing infoSlopeRing_T;
typedef struct _infoBuiltUpRing infoBuiltUpRing_T;
typedef struct _infoStreetClassRing infoStreetClassRing_T;
typedef struct _infoRampRing infoRampRing_T;
typedef struct _infoRightOfWayRing infoRightOfWayRing_T;
typedef struct _infoRoundaboutRing infoRoundaboutRing_T;
typedef struct _infoLaneSituationRing infoLaneSituationRing_T;
typedef struct _mapInfo mapInfo_T;
typedef struct _mapPath mapPath_T;
typedef struct _pathRouterMemory pathRouterMemory_T;


typedef struct _prtSpeedLimit {
	real32_T limit;
	uint16_T raw;
	real32_T position;
	bool_T constraintTrailer;            /**< Gilt die Geschwindigkeitsbeschränkung nur für Fahzeuge mit Anhänger? */
	bool_T constraintWet;                /**< Gilt die Geschwindigkeitsbeschränkung nur bei Nässe? */
	bool_T constraintFog;                /**< Gilt die Geschwindigkeitsbeschränkung nur bei Nebel? */
	bool_T constraintTime;               /**< Gilt die Geschwindigkeitsbeschränkung nur yu bestimmten Zeiten? */
	bool_T constraintLane;               /**< Gilt die Geschwindigkeitsbeschränkung nur auf bestimmten Fahrspuren? */
	bool_T variableSign;                 /**< Ergibt sich das Geschwindigkeitslimits aus einem variablen Verkehrszeichen? */
} prtSpeedLimit_T;                       /**< Groesse der Struktur = 20 Bytes */

typedef struct _prtBranchAngle {
	real32_T angle;
	real32_T position;
} prtBranchAngle_T;                      /**< Groesse der Struktur = 8 Bytes */

typedef struct _prtSlope {
	bool_T known;
	real32_T slope;
	real32_T position;
} prtSlope_T;                            /**< Groesse der Struktur = 12 Bytes */

typedef struct _prtBuiltUpArea {
	bool_T type;
	real32_T position;
} prtBuiltUpArea_T;                      /**< Groesse der Struktur = 8 Bytes */

typedef struct _prtLaneSituation {
	uint8_T forwardLanes;
	uint8_T turnLanesLeft;
	uint8_T turnLanesRight;
	uint8_T oppositeLanes;
	real32_T position;
} prtLaneSituation_T;                    /**< Groesse der Struktur = 8 Bytes */

typedef struct _prtStreetClass {
	prtStreetClassValues_T type;
	real32_T position;
} prtStreetClass_T;                      /**< Groesse der Struktur = 8 Bytes */

typedef struct _prtDynamicEvent {
	prtDynamicEventValues_T type;
	real32_T position;
} prtDynamicEvent_T;                     /**< Groesse der Struktur = 8 Bytes */

typedef struct _prtRightOfWayControl {
	prtRightOfWayControlValues_T type;
	real32_T position;
} prtRightOfWayControl_T;                /**< Groesse der Struktur = 8 Bytes */

typedef struct _prtBaseGPS {
	real32_T heading;
	real64_T latitude;
	real64_T longitude;
	real32_T altitude;
	real32_T position;
} prtBaseGPS_T;                          /**< Groesse der Struktur = 32 Bytes */


/*lint -restore */

#endif
