#ifndef guard_psdWrapper_interface_h
#define guard_psdWrapper_interface_h

#include "base.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define psdMAXCHILDRENCOUNT 5




typedef uint16_T psdAltitude_T; 
typedef uint16_T psdAngle_T; 
typedef uint16_T psdAttributeIndex_T; 
typedef uint16_T psdAttributeValue_T; 
typedef uint16_T psdChangeCount_T; 
typedef uint16_T psdCountryCode_T; 
typedef uint16_T psdHeading_T; 
typedef uint16_T psdInhibitTime_T; 
typedef uint16_T psdLength_T; 
typedef uint16_T psdSlope_T; 
typedef uint16_T psdSpeedLimitId_T; 
typedef uint16_T psdSpeedLimitIndex_T; 
typedef uint32_T psdCurvature_T; 
typedef uint32_T psdLatitude_T; 
typedef uint32_T psdLongitude_T; 
typedef uint8_T psdAttributeType_T; 
typedef uint8_T psdCompleteFlag_T; 
typedef uint8_T psdLongitudinalError_T; 
typedef uint8_T psdNoPassingSign_T; 
typedef uint8_T psdPositionLane_T; 
typedef uint8_T psdQualityMapMatching_T; 
typedef uint8_T psdRampValue_T; 
typedef uint8_T psdSegmentId_T; 
typedef uint8_T psdSpeedLimitConstraintHour_T; 
typedef uint8_T psdSpeedLimitConstraintLane_T; 
typedef uint8_T psdSpeedLimitConstraintLegalAddition_T; 
typedef uint8_T psdSpeedLimitConstraintLegalStreetClass_T; 
typedef uint8_T psdSpeedLimitConstraintTrailer_T; 
typedef uint8_T psdSpeedLimitConstraintWeather_T; 
typedef uint8_T psdSpeedLimitConstraintWeekDay_T; 
typedef uint8_T psdSpeedLimitOrigin_T; 
typedef uint8_T psdSpeedLimitScope_T; 
typedef uint8_T psdSpeedLimitSource_T; 
typedef uint8_T psdSpeedLimitType_T; 
typedef uint8_T psdSpeedLimitUnit_T; 
typedef uint8_T psdSpeedLimitValue_T; 
typedef uint8_T psdStatus_T; 
typedef uint8_T psdStreetClass_T; 
typedef uint8_T psdVariableMessageSignType_T; 
typedef uint8_T psdVariableMessageSign_T; 


typedef struct _psdTreeConfiguration {
	uint32_T configurationFlags1;
	uint32_T configurationFlags2;
	uint16_T maxAttributes;
	uint16_T maxSpeedLimits;
	uint16_T maxSegments;
	uint8_T treeVersionMajor;
	uint8_T treeVersionMinor;
} psdTreeConfiguration_T;                /**< Groesse der Struktur = 16 Bytes */

typedef struct _psdSystemData {
	bool_T isRoutingActive;
	psdQualityMapMatching_T qualityMapMatching;
	bool_T isRoutingChanged;
} psdSystemData_T;                       /**< Groesse der Struktur = 3 Bytes */

typedef struct _psdPosition {
	psdLength_T length;
	psdInhibitTime_T inhibitTime;
	psdSegmentId_T id;
	psdPositionLane_T lane;
	psdLongitudinalError_T longitudinalError;
	bool_T isLocationUnique;
} psdPosition_T;                         /**< Groesse der Struktur = 8 Bytes */

typedef struct _psdGpsPosition {
	psdLatitude_T latitude;
	psdLongitude_T longitude;
	psdHeading_T heading;
	psdAltitude_T altitude;
	psdSegmentId_T referenceSegment;
} psdGpsPosition_T;                      /**< Groesse der Struktur = 16 Bytes */

typedef struct _psdSegment {
	struct _psdSegment_geometry {
		psdCurvature_T curvatureStart;
		psdCurvature_T curvatureEnd;
		psdLength_T length;
		psdAngle_T branchAngle;
	} geometry;
	struct _psdSegment_attributes {
		uint8_T lanes;
		uint8_T streetClass;
		uint8_T ramp;
		bool_T isMostProbablePath;
		bool_T isStraightestPath;
		bool_T isADASQuality;
		bool_T isBuiltUpArea;
	} attributes;
	psdAttributeIndex_T attributeIndex;
	psdSpeedLimitId_T speedLimitIndex;
	psdSegmentId_T id;
	psdSegmentId_T parentId;
	psdSegmentId_T identity;
	psdCompleteFlag_T completeFlags;
	psdSegmentId_T childSegments[psdMAXCHILDRENCOUNT];
	uint8_T childCount;
} psdSegment_T;                          /**< Groesse der Struktur = 36 Bytes */

typedef struct _psdAttribute {
	psdAttributeIndex_T nextAttribute;
	psdLength_T offset;
	psdAttributeValue_T value;
	psdAttributeType_T type;
} psdAttribute_T;                        /**< Groesse der Struktur = 8 Bytes */

typedef struct _psdSpeedLimit {
	psdSpeedLimitIndex_T nextSpeedLimit;
	psdLength_T offset;
	psdSpeedLimitType_T type;
	psdSpeedLimitSource_T source;
	psdSpeedLimitValue_T speedLimitLower;
	psdSpeedLimitValue_T speedLimitUpper;
	psdSpeedLimitUnit_T speedLimitUnit;
	psdSpeedLimitConstraintLane_T constraintLane;
	psdSpeedLimitConstraintTrailer_T constraintTrailer;
	psdSpeedLimitConstraintWeather_T constraintWeather;
	psdSpeedLimitConstraintWeekDay_T constraintWeekDayStart;
	psdSpeedLimitConstraintWeekDay_T constraintWeekDayEnd;
	psdSpeedLimitConstraintHour_T constraintHourStart;
	psdSpeedLimitConstraintHour_T constraintHourEnd;
	psdSpeedLimitConstraintLegalStreetClass_T constraintLegalStreetClass;
	psdSpeedLimitConstraintLegalAddition_T constraintLegalAddition;
	psdVariableMessageSign_T variableMessageSign;
	psdVariableMessageSignType_T variableMessageSignType;
	psdNoPassingSign_T noPassingSign;
} psdSpeedLimit_T;                       /**< Groesse der Struktur = 22 Bytes */


/*lint -restore */

#endif
