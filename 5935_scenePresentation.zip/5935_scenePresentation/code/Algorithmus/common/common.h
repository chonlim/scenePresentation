#ifndef guard_common_h
#define guard_common_h

#include "base.h"


#endif
