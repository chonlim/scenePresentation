#ifndef guard_strategyReporter_private_h
#define guard_strategyReporter_private_h

#include "common/strategyReporterCommon/strategyReporter_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define srpREPORTCOUNT 16



struct _strategyReport {
	uint32_T aliveCounter;               /**< Alive-Zähler, der mit jedem Strategy-Task erhöht wird */
	uint16_T count;                      /**< Anzahl gültiger Einträge in der Meldungsliste */
	uint16_T item[srpREPORTCOUNT];       /**< Codierte Meldungen für die Ausgabe über PACC02_Durchschnittsgeschw */
} ;                                      /**< Groesse der Struktur = 40 Bytes */


/*lint -restore */

#endif
