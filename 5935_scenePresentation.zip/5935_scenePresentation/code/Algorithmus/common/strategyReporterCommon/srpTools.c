#include "srpTools.h"
#include "strategyReporter_private.h"


void				srpGetErrorCode(IN	const	strategyReport_T	*strategyReport,
									IN	const	uint16_T			 index,
									OUT			uint16_T			*coded)
{
	if (index < (uint16_T)srpREPORTCOUNT) {
		*coded = index < strategyReport->count ? strategyReport->item[index] : 0u;
	} else {
		*coded = 0u;
	}
}


void			   srpGetErrorCount(IN	const	strategyReport_T	*strategyReport,
									OUT			uint16_T			*count)
{
	*count = strategyReport->count;
}


void			   srpGetAliveCount(IN	const	strategyReport_T	*strategyReport,
									OUT			uint32_T			*aliveCount)
{
	*aliveCount = strategyReport->aliveCounter;
}
