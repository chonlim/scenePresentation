#ifndef guard_srpTools_h
#define guard_srpTools_h

#include "common/common.h"
#include "common/strategyReporterCommon/strategyReporter_interface.h"


void				srpGetErrorCode(IN	const	strategyReport_T	*strategyReport,
									IN	const	uint16_T			 index,
									OUT			uint16_T			*coded
									);


void			   srpGetErrorCount(IN	const	strategyReport_T	*strategyReport,
									OUT			uint16_T			*count
									);


void			   srpGetAliveCount(IN	const	strategyReport_T	*strategyReport,
									OUT			uint32_T			*aliveCount
									);

#endif
