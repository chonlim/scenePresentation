#ifndef guard_sysInfo_h
#define guard_sysInfo_h

#include "common/common.h"
#include "common/systemControllerCommon/systemController_interface.h"


/**	\brief	Initialisiert die roadModelInfo-Struktur f�r die R�ckmeldung von Geschwindigkeitslimits an den systemController 
\ingroup	systemController_API
*/
void				sysRoadInfoInit(IN	const	real32_T				 egoPosition,	/**< Fahrzeugposition zum Zeitpunkt der Generierung des roadModels */
									OUT			roadModelInfo_T			*info			/**< interne roadModelInfo-Struktur */
									);


/**	\brief	F�gt ein neues Geschwindigkeitslimits f�r roadModelInfo-Struktur hinzu 
\ingroup	systemController_API
*/
void			sysRoadInfoAddLimit(INOUT		roadModelInfo_T			*info,			/**< interne roadModelInfo-Struktur */
									IN	const	bool_T					 valid,			/**< Gibt an, ob ein g�ltiges Limits hinzugef�gt oder nur Rechenzeit "verdummt" werden soll */
									IN	const	real32_T				 position,		/**< Position, ab der das Geschwindigkeitslimit g�ltig ist */
									IN	const	real32_T				 limit,			/**< Zul�ssige H�chstgeschwindigkeit */
									IN	const	uint16_T				 raw			/**< Einheitenloser Wert f�r die Anzeige */
									);


/**	\brief	F�gt der roadModelInfo-Struktur eine neue Stoppstelle hinzu 
\ingroup	systemController_API
*/
void			 sysRoadInfoAddStop(INOUT		roadModelInfo_T			*info,
									IN	const	bool_T					 valid,
									IN	const	real32_T				 position,
									IN	const	sysStopType_T			 type
									);


/**	\brief	Fragt ab, ob die roadModelInfo-Struktur g�ltige Daten enth�lt 
\ingroup	systemController_API
*/
void			 sysRoadInfoIsValid(IN	const	roadModelInfo_T			*info,			/**< interne roadModelInfo-Struktur */
									OUT			bool_T					*valid			/**< Gibt an, ob die Struktur g�ltige Daten enth�lt */
									);


/**	\brief	Gibt die Fahrzeugposition zum Zeitpunkt der Erstellung der `roadModelInfo`-Struktur aus.
Da der Control-Task in k�rzeren Takten rechnet als der Strategy-Task und da eine Limit-Position im Strategy-Task vom Modul `roadModel`
bei der Fusion von Kamera- und Kartendaten ver�ndert werden kann (Limits werden bis zum Erkennen nach vorne geschoben), muss die �berpr�fung,
wann ein Tempolimit passiert worden ist, anhand der Fahrzeugposition des Strategy-Tasks erfolgen, die hier als `referencePosition` ausgegeben wird.
\ingroup	systemController_API
*/
void	  sysRoadInfoGetRefPosition(IN	const	roadModelInfo_T			*info,				/**< interne roadModelInfo-Struktur */
									OUT			real32_T				*referencePosition	/**< Fahrzeugposition zum Zeitpunkt der Erstellung*/
									);

/**	\brief	Fragt das g�ltige Geschwindigkeitslimit ab 
\ingroup	systemController_API
*/
bool_T			sysRoadInfoGetLimit(IN	const	roadModelInfo_T			*info,			/**< interne roadModelInfo-Struktur */
									IN	const	real32_T				 position,		/**< Position, an der das Geschwindigkeitslimit abgefragt wird */
									OUT			real32_T				*limit,			/**< G�ltiges Geschwindigkeitlimit */
									OUT			uint16_T				*raw,			/**< Rohwert (in km/h oder mph) des Geschwindigkeitslimits*/
									OUT	OPT		vobsSignUnit_T			*unit			/**< Einheit des Geschiwndigkeitslimits*/
									);


/**	\brief	Fragt das n�chste g�ltige Geschwindigkeitslimit ab einer Position ab 
\ingroup	systemController_API
*/
bool_T		sysRoadInfoGetNextLimit(IN	const	roadModelInfo_T			*info,			/**< interne roadModelInfo-Struktur */
									IN	const	real32_T				 position,		/**< Position, ab das n�chste Limit gesucht werden soll */
									OUT			bool_T					*limitValid,	/**< Gibt an, ob ein g�ltige Limit gefunden wurde */
									OUT			real32_T				*limitValue,	/**< Zul�ssige H�chstgeschwindigkeit des n�chsten Limits */
									OUT			real32_T				*limitPosition,	/**< Position des n�chsten Limits */
									OUT			uint16_T				*limitRaw,		/**< Einheitenloser Wert des n�chsten Limits */
									OUT			vobsSignUnit_T			*unit			/**< Einheit des Geschiwndigkeitslimits*/
									);


/**	\brief	Fragt die maximale Anzahl g�ltiger Stoppstellen in der roadModelInfo-Struktur ab
\ingroup	systemController_API */
void	 sysRoadInfoGetMaxStopCount(OUT			uint16_T				*maxCount		/**< maximale Anzahl g�ltiger Stoppstellen */
									);


/**	\brief	Fragt die Position einer Stoppstelle in der roadModelInfo-Struktur ab */
bool_T			 sysRoadInfoGetStop(IN	const	roadModelInfo_T			*info,			/**< interne roadModelInfo-Struktur */
									IN	const	uint16_T				 index,			/**< Index der Stoppstelle, die abgefragt werden soll */
									OUT			bool_T					*valid,			/**< Gibt an, ob der abgefragte Eintrag g�ltig ist */
									OUT			real32_T				*position,		/**< Position der Stoppstelle [m] */
									OUT			sysStopType_T			*type			/**< Art der Stoppstelle */
									);


#endif
