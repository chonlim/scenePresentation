#include "common/systemControllerCommon/sysTools.h"
#include "common/systemControllerCommon/systemController_private.h"



void		sysGetLongControlStatus(IN	const	systemControl_T				*systemControl,
									OUT			sysStatus_T					*status)
{
	*status = systemControl->status;
}

void				sysGetFodStatus(IN	const	systemControl_T				*systemControl,
									OUT			sysFodStatus_T				*fodStatus)
{
	*fodStatus = systemControl->fodStatus;
}

void			 sysGetDisplayError(IN	const	systemControl_T			*systemControl,
									OUT			sysDisplayError_T		*displayError)
{
	*displayError = systemControl->displayError;
}

void		  sysGetTakeoverRequest(IN	const	systemControl_T			*systemControl,
									OUT			bool_T					*request)
{
	*request =    (systemControl->status == sysStatusBrakeOnlyMode) 
			   || (systemControl->stopTakeover);
}


void			  sysGetDisplayAuto(IN	const	systemControl_T				*systemControl,
									OUT			bool_T						*displayAuto)
{
	*displayAuto = systemControl->isAutoModeActive;
}

void sysGetDisplayLimitEventsActive(IN	const	systemControl_T				*systemControl,
									OUT			bool_T						*dsplLimitEventsActive)
{
	*dsplLimitEventsActive = systemControl->dsplLimitEventsActive;
}


void				sysGetLongMode(	IN const	systemControl_T				*systemControl,
									OUT			sysLongMode_T				*mode)
{
	*mode = systemControl->mode;
}


void				sysGetDistIndex(IN	const	systemControl_T				*systemControl,
									OUT			uint16_T					*distIndex)
{
	*distIndex = systemControl->distIndex;
}


void			 sysGetLastSetSpeed(IN	const	systemControl_T				*systemControl,
									OUT			real32_T					*position,
									OUT			real32_T					*velocity)
{
	*position	= systemControl->previousSetSpeed.position;
	*velocity	= systemControl->previousSetSpeed.value;
}


void		  sysGetCurrentSetSpeed(IN	const	systemControl_T				*systemControl,
									OUT			real32_T					*position,
									OUT			real32_T					*velocity)
{
	*position	= systemControl->currentSetSpeed.position;
	*velocity	= systemControl->currentSetSpeed.value;
}


void			 sysGetNextSetSpeed(IN	const	systemControl_T				*systemControl,
									OUT			real32_T					*position,
									OUT			real32_T					*velocity,
									OUT			bool_T						*valid)
{
	*position	= systemControl->nextSetSpeed.position;
	*velocity	= systemControl->nextSetSpeed.value;
	*valid		= systemControl->nextSetSpeed.position != -INVALID_VALUE ? true : false;
}


void		   sysIsSetDisplayValid(IN	const	systemControl_T				*systemControl,
									OUT			bool_T						*setDisplayValid)
{
	*setDisplayValid = systemControl->setDisplayValid;
}


void			 sysGetAutoModeInfo(IN	const	systemControl_T				*systemControl,
									OUT	OPT		bool_T						*autoMode,
									OUT	OPT		real32_T					*previewPosition)
{
	if(NULL != autoMode)		{ *autoMode			= systemControl->isAutoModeActive; }
	if(NULL != previewPosition)	{ *previewPosition	= systemControl->previewPosition; }
}


void		  sysGetToleranceFactor(IN	const	systemControl_T				*systemControl,
									OUT			real32_T					*toleranceFactor)
{
	*toleranceFactor = systemControl->toleranceFactor;
}


void			 sysGetPreviewLimit(IN	const	systemControl_T				*systemControl,
									OUT			uint16_T					*previewLimit,
									OUT			bool_T						*previewLock)
{
	*previewLimit	= systemControl->previewLimit;
	*previewLock	= systemControl->previewLock;
}


void			   sysGetStopOutput(IN	const	systemControl_T				*systemControl,
									OUT			sysStopType_T				*stopInRange)
{
	*stopInRange		= systemControl->stopInRange;
}


void		sysGetStopSweepPosition(IN	const	systemControl_T				*systemControl,
									OUT			real32_T					*stopSweepPosition)
{
	*stopSweepPosition = systemControl->stopSweepPosition;
}


void		   sysGetOverrideReturn(IN	const	systemControl_T				*systemControl,
									OUT			bool_T						*overrideReturn)
{
	*overrideReturn = systemControl->overrideReturn;
}


void		sysSetLongControlStatus(IN	const	bool_T						 valid,
									IN	const	real32_T					 previewPosition,
									IN	const	real32_T					 stopPosition,
									OUT			longControlStatus_T			*status)
{
	status->valid			= valid;
	status->previewPosition	= previewPosition;
	status->stopPosition	= stopPosition;
}

void		   sysGetUnsuccessfulActivation(IN	const	systemControl_T				*systemControl,
											OUT			bool_T						*unsuccessfulActivation)
{
	*unsuccessfulActivation = systemControl->unsuccessfulActivation;
}

void		   sysGetShowHint(IN	const	systemControl_T				*systemControl,
							  OUT			bool_T						*showHint)
{
	*showHint = systemControl->showHint;
}

void		   sysGetErrorTicks(IN	const	systemControl_T				*systemControl,
								OUT			uint16_T					*errorTicks)
{
	*errorTicks = systemControl->errorTicks;
}
