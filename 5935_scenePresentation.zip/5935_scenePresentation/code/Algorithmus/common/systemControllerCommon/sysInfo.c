#include "common/systemControllerCommon/sysInfo.h"
#include "common/systemControllerCommon/sysInfoStatic.h"
#include "common/systemControllerCommon/systemController_private.h"
#include <math.h> /*lint -esym(9045, struct _exception)*/

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_sysInfo)


void				sysRoadInfoInit(IN	const	real32_T				 egoPosition,
									OUT			roadModelInfo_T			*info)
{
	info->egoPosition	= egoPosition;
	info->limit.count	= 0;
	info->stop.count	= 0;
}


void			sysRoadInfoAddLimit(INOUT		roadModelInfo_T			*info,
									IN	const	bool_T					 valid,
									IN	const	real32_T				 position,
									IN	const	real32_T				 limit,
									IN	const	uint16_T				 raw)
{
	if(info->limit.count < (uint16_T)sysINFOLIMITCOUNT && valid) {
		info->limit.item[info->limit.count].position	= position;
		info->limit.item[info->limit.count].value		= limit;
		info->limit.item[info->limit.count].raw			= raw;
		info->limit.count++;
	}
}


void			 sysRoadInfoAddStop(INOUT		roadModelInfo_T			*info,
									IN	const	bool_T					 valid,
									IN	const	real32_T				 position,
									IN	const	sysStopType_T			 type)
{
	if(info->stop.count < (uint16_T)sysINFOSTOPCOUNT && valid) {
		info->stop.item[info->stop.count].position	= position;
		info->stop.item[info->stop.count].type		= type;
		info->stop.count++;
	}
}


void			 sysRoadInfoIsValid(IN	const	roadModelInfo_T			*info,
									OUT			bool_T					*valid)
{
	*valid = info->limit.count > 0u ? true : false;
}


void	  sysRoadInfoGetRefPosition(IN	const	roadModelInfo_T			*info,
									OUT			real32_T				*referencePosition)
{
	*referencePosition = info->egoPosition;
}


bool_T			sysRoadInfoGetLimit(IN	const	roadModelInfo_T			*info,
									IN	const	real32_T				 position,
									OUT			real32_T				*limit,
									OUT			uint16_T				*raw,
									OUT	OPT		vobsSignUnit_T			*unit)
{
	uint16_T	index;


	/* Sicherstellen, dass die Liste zumindest ein Element enth�lt */
	if(info->limit.count == 0u) {
		return false;
	}


	/* Suche nach dem Segment, das die gesuchte Position enth�lt */
	for(index = 0u; index+1u < (uint16_T)sysINFOLIMITCOUNT; index++) {
		if(index+1u == info->limit.count || info->limit.item[index+1u].position >= position) {
			break;
		}
		else {
			continue;
		}
	}


	/* Ausgabe */
	diagFF(index < info->limit.count);
	if (info->limit.item[index].raw == (uint16_T)rawLimitInvalid){
		return false;
	}


	*limit	= info->limit.item[index].value;
	*raw	= info->limit.item[index].raw;
	if (NULL != unit) { diagFF(sysRoadInfoGetUnit(*limit, *raw, unit)); }


	/* "Verbrennen" der restlichen Rechenzeit */
	for(; index+1u < (uint16_T)sysINFOLIMITCOUNT; index++) {
		if(info->limit.item[index+1u].position < position || index + 1u == info->limit.count) {
			continue;
		}
		else {
			continue;
		}
	}


	return true;
}


bool_T		sysRoadInfoGetNextLimit(IN	const	roadModelInfo_T			*info,
									IN	const	real32_T				 position,
									OUT			bool_T					*limitValid,
									OUT			real32_T				*limitValue,
									OUT			real32_T				*limitPosition,
									OUT			uint16_T				*limitRaw,
									OUT			vobsSignUnit_T			*unit)
{
	uint16_T	index;

	/* Suche nach dem Segment, das die gesuchte Position enth�lt */
	for(index = 0; index < (uint16_T)sysINFOLIMITCOUNT; index++) {
		if(info->limit.item[index].position >= position || index == info->limit.count) {
			break;
		}
		else {
			continue;
		}
	}


	/* Ausgabe */
	if(		info->limit.count > 0u
	   &&	info->limit.count <= (uint16_T)sysINFOLIMITCOUNT
	   &&	index < (uint16_T)sysINFOLIMITCOUNT
	   &&	index < info->limit.count) 
	{
		*limitValid		= true;
		*limitValue		= info->limit.item[index].value;
		*limitPosition	= info->limit.item[index].position;
		*limitRaw		= info->limit.item[index].raw;
		diagFF(sysRoadInfoGetUnit(*limitValue, *limitRaw, unit)); 
	}
	else 
	{
		*limitValid		= false;
		*limitValue		= info->limit.item[0].value;
		*limitPosition	= info->limit.item[0].position;
		*limitRaw		= info->limit.item[0].raw;
		*unit		= signUnitUnknown;
	}

	/* "Verbrennen" der restlichen Rechenzeit */
	for(; index < (uint16_T)sysINFOLIMITCOUNT; index++) {
		if(info->limit.item[index].position >= position || index == info->limit.count) {
			continue;
		}
		else {
			continue;
		}
	}

	return true;
}


void	 sysRoadInfoGetMaxStopCount(OUT			uint16_T				*maxCount)
{
	*maxCount = sysINFOSTOPCOUNT;
}


bool_T			 sysRoadInfoGetStop(IN	const	roadModelInfo_T			*info,
									IN	const	uint16_T				 index,
									OUT			bool_T					*valid,
									OUT			real32_T				*position,
									OUT			sysStopType_T			*type)
{
	diagFF(index < (uint16_T)sysINFOSTOPCOUNT);

	*valid		= index < info->stop.count;

	*position	= info->stop.item[index].position;
	*type		= info->stop.item[index].type;

	return true;
}


static bool_T	 sysRoadInfoGetUnit(IN	const	real32_T				 limit,
									IN	const	uint16_T				 raw,
									OUT			vobsSignUnit_T			*unit)
{
	const real32_T diffUnitKph = limit / (real32_T)raw - KPH_TO_MPS;
	const real32_T diffUnitMph = limit / (real32_T)raw - MPH_TO_MPS;
	diagFNaN(diffUnitKph);
	diagFNaN(diffUnitMph);

	if		(fabsf(diffUnitKph) < ROUNDING_ERROR)	{ *unit = signUnitKMH; }
	else if (fabsf(diffUnitMph) < ROUNDING_ERROR)	{ *unit = signUnitMPH; }
	else											{ *unit = signUnitUnknown;  }

	return true;
}
