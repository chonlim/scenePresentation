#ifndef guard_systemController_private_h
#define guard_systemController_private_h

#include "common/systemControllerCommon/systemController_interface.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */

#define sysINFOLIMITCOUNT 6
#define sysINFOSTOPCOUNT 4

typedef enum _sysActivation {
	sysAcvnNone = 0,                     /**< Keine Aktivierung */
	sysAcvnResume = 1,                   /**< Aktivierung durch Resume/Wiederaufnahme */
	sysAcvnSet = 2                       /**< Keine Aktivierung Set/Setzen */
} sysActivation_T;

typedef enum _driverInputStatus {
	sysCanceled = 0,                     /**< Abbruchbedingung erkannt */
	sysNotPressed = 1,                   /**< Taste nicht betaetigt */
	sysNewPressed = 2,                   /**< Taste einmal betaetigt */
	sysPressed = 3,                      /**< Taste betaetigt, wenn nicht NewPressed und noch nicht LongPressed */
	sysLongPressed = 4,                  /**< Taste gehalten (Wird periodisch fuer je einen Rechenzyklus angenommen) */
	sysHeld = 5,                         /**< Taste betaetigt, wenn bereits einmal LongPressed angenommen wurde */
	sysReleased = 6,                     /**< Taste nach einfachem Druck losgelassen (Für einen Zyklus) */
	sysWaitDouble = 7,                   /**< Warten auf zweiten Teil eines Doppelklicks */
	sysNewDouble = 8,                    /**< Doppelklick erkannt */
	sysDoublePressed = 9,                /**< Taste betätigt nach Doppelklick */
	sysDoubleReleased = 10               /**< Taste nach Doppelklick losgelassen (Für einen Zyklus) */
} driverInputStatus_T;



typedef struct _limitItem {
	bool_T valid;                        /**< Geschwindigkeitsbegrenzung gueltig */
	real32_T value;                      /**< Wert der Geschwindigkeitsbegrenzung[m/s] */
	real32_T position;                   /**< Position der Geschwindigkeitsbegrenzung[m] */
	uint16_T raw;                        /**< Einheitenloser Rohwert des kommenden Verkehrszeichens fuer die Anzeige[n/a] */
	vobsSignUnit_T unit;                 /**< Einheit des Tempolimits */
	bool_T lowered;                      /**< Durch maxAutoSpeed eingeschränkt */
} limitItem_T;                           /**< Groesse der Struktur = 24 Bytes */

typedef struct _lastSetSpeed {
	real32_T bufferedSetSpeed;           /**< Wert der gepufferten Setzgeschwindigkeit[m/s] */
	uint16_T counter;                    /**< Zaehlt rueckwaerts. Steht der Counter auf 0 ist der LastSetSpeed ungueltig. */
} lastSetSpeed_T;                        /**< Groesse der Struktur = 8 Bytes */

typedef struct _permanentMode {
	bool_T setSpeedManipulated;          /**< Im Konzept vereinfachter Offset wurde die Setzgeschwindigkeit vom Fahrer manipuliert. */
	bool_T autoNextLimit;                /**< Im Konzept vereinfachter Offset wurde die zukünftige Setzgeschwindigkeit automatisch vom Tempolimit zzgl. Offset uebernommen. */
	real32_T currentSetSpeed;            /**< Aktuelle Setzgeschwindigkeit[m/s] */
	real32_T nextSetSpeed;               /**< Zukuenftige Setzgeschwindigkeit bei vom Fahrer bestaetigtem Tempolimit[m/s] */
	lastSetSpeed_T lastSetSpeed;         /**< Letzte Setzgeschwindigkeiten zur Wiederherstellung per Bedienaktion Resume */
} permanentMode_T;                       /**< Groesse der Struktur = 20 Bytes */

typedef struct _sysControlLimits {
	limitItem_T currentLimit;            /**< aktuelles Tempolimit */
	limitItem_T nextLimit;               /**< zukuenftiges Tempolimit */
	real32_T previewPosition;            /**< Aktuelle Vorausschauposition fuer kommende Geschwindigkeitsbeschraenkungen[m] */
	bool_T previewLock;                  /**< Anforderung fuer das Zurueckhalten neuer Vorausschauevents */
} sysControlLimits_T;                    /**< Groesse der Struktur = 56 Bytes */

typedef struct _longPressCycleCount {
	uint8_T initial;                     /**< Anzahl Rechenzyklen zur ersten Erkennung einer gehaltenen Taste */
	uint8_T periodic;                    /**< Anzahl Rechenzyklen zur wiederholten Erkennung einer gehaltenen Taste */
	uint8_T waitDouble;                  /**< Anzahl Rechenzyklen für die Erkennung eines Doppelklicks */
} longPressCycleCount_T;                 /**< Groesse der Struktur = 3 Bytes */

typedef struct _sysDriverInput {
	driverInputStatus_T status;          /**< Zustand */
	uint8_T debounceCounter;             /**< Zaehler zur Erkennung einer gehaltenen Taste */
} sysDriverInput_T;                      /**< Groesse der Struktur = 8 Bytes */

typedef struct _driverInputList {
	longPressCycleCount_T longPressCycleCount; /**< Anzahlen der Rechenzyklen zur Erkennung einer gehaltenen Taste */
	sysDriverInput_T tipUp;              /**< Bedienaktion Tip Hoch */
	sysDriverInput_T tipDown;            /**< Bedienaktion Tip Runter */
	sysDriverInput_T set;                /**< Bedienaktion Setzen */
	sysDriverInput_T resume;             /**< Bedienaktion Wiederaufnahme */
} driverInputList_T;                     /**< Groesse der Struktur = 36 Bytes */

typedef struct _setSpeedControl {
	bool_T isAutoModeActive;             /**< Automatische Uebernahme gesetzlicher Tempolimits aktiv */
	driverInputList_T driverInputs;      /**< Fahrer-Bedienaktionen zur Aktivierung und Setzgeschwindigkeitsverstellung */
	sysControlLimits_T limits;           /**< Tempolimits von roadModelInfo */
	permanentMode_T permanentMode;       /**< Setzgeschwindigkeitbei Übernahme von Tempolimits mit einem einstellbaren permanent Offset */
} setSpeedControl_T;                     /**< Groesse der Struktur = 116 Bytes */

typedef struct _boolDebounce {
	bool_T status;                       /**< Entprellter Wahrheitswer */
	uint16_T debounceCounter;            /**< Entprellzaehler */
	uint16_T debounceMaxCount;           /**< Anzahl Rechenzyklen zur Entprellung */
} boolDebounce_T;                        /**< Groesse der Struktur = 6 Bytes */

typedef struct _sysMapStatus {
	bool_T status;                       /**< UND-Verknuepfung der drei folgenden unterschiedlich entprellten Karten-Stati */
	boolDebounce_T mapValidStatus;       /**< Entprellter Zustand gueltige Kartendaten */
	boolDebounce_T roadDataStatus;       /**< Entprellter Zustand gueltige Straßenklasse und Laendercode */
	boolDebounce_T strategyStatus;       /**< Entprellter Zustand gueltige Strategie (longTorque) */
	boolDebounce_T speedLimitStatus;     /**< Entprellter Zustand gueltiges Tempolimit */
} sysMapStatus_T;                        /**< Groesse der Struktur = 26 Bytes */

typedef struct _sysJamPilotStatus {
	bool_T active;                       /**< Funktion Staupilot aktiv genug, dass Innodrive die Bedienung sperrt */
} sysJamPilotStatus_T;                   /**< Groesse der Struktur = 1 Bytes */

typedef struct _systemStatus {
	sysStatus_T status;                  /**< Aktivierungszustand System Innodrive2 */
	sysMapStatus_T mapStatus;            /**< Entprellter Karten-Status */
	boolDebounce_T overrideStatus;       /**< Entprellter Zustand Fahrpedalueberdrueckung */
	boolDebounce_T activationStatus;     /**< Entprellter Zustand Aktivierung (Set/Resume) */
	sysJamPilotStatus_T jamPilot;        /**< Status der Funktion Staupilot */
	sysActivation_T lastAcvnAction;      /**< Letzte Bedienhandlung zur aktivierung */
} systemStatus_T;                        /**< Groesse der Struktur = 48 Bytes */

typedef struct _speedInfo {
	real32_T value;                      /**< Wert der Geschwindigkeitsbegrenzung[m/s] */
	real32_T position;                   /**< Position der Geschwindigkeitsbegrenzung[m] */
	uint16_T raw;                        /**< Einheitenloser Rohwert des kommenden Verkehrszeichens fuer die Anzeige[n/a] */
} speedInfo_T;                           /**< Groesse der Struktur = 12 Bytes */

typedef struct _setSpeedFilter {
	speedInfo_T currentSetSpeed;         /**< Setzgeschwindigkeit aus dem vorigen Rechentakt */
	speedInfo_T previousSetSpeed;        /**< Setzgeschwindigkeit vor letzter Aenderung der Setzgeschwindigkeit */
	bool_T showHint;                     /**< Flag, das signalisiert ob der Geschwindigkeitshinweis gerade angezeigt werden darf */
} setSpeedFilter_T;                      /**< Groesse der Struktur = 28 Bytes */

typedef struct _stopFilter {
	real32_T sweepPosition;              /**< Position, bis zu der Stoppstellen vom Fahrer freigegeben wurden[m] */
	real32_T showPosition;               /**< Position, ab der Stoppstellen angezeigt werden[m] */
	sysStopType_T lastInRange;           /**< Art der Stoppstelle, die im letzten Zeitschritt angezeigt wurde */
	bool_T proximity;                    /**< Befinden wir uns aktell in der Naehe einer Stoppstelle? */
	bool_T reacted;                      /**< Hat der Fahrer auf unsere Uebernahmeaufforderung reagiert? */
} stopFilter_T;                          /**< Groesse der Struktur = 16 Bytes */

typedef struct _overrideReturnFilter {
	real32_T setSpeed;                   /**< Setzgeschwindigkeit[m/s] */
	bool_T overrideReturn;               /**< Ist wahr waehrend der Rueckkehr von Fahrpedalueberdrueckung zu alter Setzgeschwindigkeit */
} overrideReturnFilter_T;                /**< Groesse der Struktur = 8 Bytes */

struct _systemControlMemory {
	bool_T init;                         /**< Daten Initialisiert */
	uint16_T errorTicks;                 /**< Restanzeigedauer eines internen Fehlers[20ms] */
	systemStatus_T systemStatus;         /**< Daten zum Aktivierungszustand */
	setSpeedControl_T setSpeedControl;   /**< Daten zur Setzgeschwindigkeitsverstellung */
	setSpeedFilter_T setSpeedFilter;     /**< Filter zur Ausgabe der previousSetSpeed */
	speedCheckFilter_T speedCheckFilter; /**< Filter zur Ueberwachung der Setzgeschwindigkeit */
	stopFilter_T stopFilter;             /**< Filter fuer die Anzeige und Bedienung der Laengsregelung auf Stoppstellen */
	overrideReturnFilter_T overrideReturnFilter; /**< Filter fuer die Rueckkehr von Fahrpedalueberdrueckung zu alter Setzgeschwindigkeit */
} ;                                      /**< Groesse der Struktur = 224 Bytes */

struct _systemControl {
	uint16_T errorTicks;                 /**< Restanzeigedauer eines internen Fehlers[20ms] */
	sysStatus_T status;                  /**< Aktivierungsstaus */
	sysFodStatus_T fodStatus;            /**< Function on Demand Status */
	sysDisplayError_T displayError;      /**< Aktivierungsstaus */
	sysLongMode_T mode;                  /**< Charisma-Fahrprogramm */
	uint16_T distIndex;                  /**< Abstandsindex */
	real32_T previewPosition;            /**< Position, bis zu der im AutoMode Setzgeschwindigkeiten fuer die Vorausplanung beruecksichtigt werden */
	bool_T isAutoModeActive;             /**< AutoMode aktiv */
	speedInfo_T previousSetSpeed;        /**< Setzgeschwindigkeit vor letzter Aenderung der Setzgeschwindigkeit */
	speedInfo_T currentSetSpeed;         /**< Aktuelle Setzgeschwindigkeit */
	speedInfo_T nextSetSpeed;            /**< Zukuenftige Setzgeschwindigkeit */
	bool_T dsplLimitEventsActive;        /**< Gibt an, ob angezeigte Tempolimit-Events Aktiv (blau) oder inaktive (grau) angezeigt werden sollen. */
	bool_T setDisplayValid;              /**< Gibt an, ob dem Fahrer eine gültige Setzgeschwindigkeit oder '---' angezeigt werden soll */
	uint16_T previewLimit;               /**< Vorausschau-Geschwindigkeitslimit fuer die Anzeige[n/a] */
	bool_T previewLock;                  /**< Anforderung fuer das Zurueckhalten von Vorausschauevents */
	real32_T toleranceFactor;            /**< Faktor fuer die Reduktion der zulaessigen Beschleunigungsabweichung bei einem Ueberschreiten der Setzgeschwindigkeit */
	real32_T stopSweepPosition;          /**< Position, bis zu der Stoppstellen vom Fahrer freigegeben wurden[m] */
	sysStopType_T stopInRange;           /**< Praesenz und Art der naechsten Stoppstelle im Bedien- und Anzeigebereich der Funktion */
	bool_T stopTakeover;                 /**< Uebernahmeaufforderung von der Stoppstellen-Funktion */
	bool_T overrideReturn;               /**< Ist wahr waehrend der Rueckkehr von Fahrpedalueberdrueckung zu alter Setzgeschwindigkeit */
	bool_T unsuccessfulActivation;       /**< Ist wahr, wenn der Fahrer versucht das System mit Set oder Resume zu aktivieren, eine Aktivierung jedoch nicht moeglich ist */
	bool_T showHint;                     /**< Flag, das signalisiert ob der Geschwindigkeitshinweis gerade angezeigt werden darf */
} ;                                      /**< Groesse der Struktur = 92 Bytes */

struct _longControlStatus {
	bool_T valid;                        /**< Rueckmeldung vom longController, ob die Laengsregelung verfuegbar ist */
	real32_T previewPosition;            /**< Rueckmeldung vom longController ueber die Position des relevanten naechsten Geschwindigkeitslimits[m] */
	real32_T stopPosition;               /**< Rueckmeldung vom longController ueber die Position der relevanten Stoppstelle[m] */
} ;                                      /**< Groesse der Struktur = 12 Bytes */

typedef struct _stopInfo {
	real32_T position;                   /**< Position der Stoppstelle[m] */
	sysStopType_T type;                  /**< Art der Stoppstelle */
} stopInfo_T;                            /**< Groesse der Struktur = 8 Bytes */

struct _roadModelInfo {
	real32_T egoPosition;                /**< Interne Fahrzeugposition zum Zeitpunkt der Generierung des roadModels[m] */
	struct _roadModelInfo_limit {
		uint16_T count;                  /**< Anzahl gueltiger Tempolimits in der Liste */
		speedInfo_T item[sysINFOLIMITCOUNT]; /**< Vom roadProcessor gesetztes Tempolimit */
	} limit;
	struct _roadModelInfo_stop {
		uint16_T count;                  /**< Anzahl gueltiger Stoppstellen in der Liste */
		stopInfo_T item[sysINFOSTOPCOUNT]; /**< Stoppstellen-Eintraege aus dem roadModel */
	} stop;
} ;                                      /**< Groesse der Struktur = 116 Bytes */


/*lint -restore */

#endif
