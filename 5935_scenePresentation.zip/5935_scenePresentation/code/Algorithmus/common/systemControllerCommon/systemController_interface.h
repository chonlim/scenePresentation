#ifndef guard_systemController_interface_h
#define guard_systemController_interface_h

#include "base.h"
#include "common/vehicleObserverCommon/vehicleObserver_interface.h"
/*lint -save */
/*lint -e621	"Warning -- Identifier clash" */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e833	"Info --  Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





typedef enum _sysStatus {
	sysStatusDisabled = 0,               /**< Vom Fahrer ausgeschaltet */
	sysStatusNotAvailable = 1,           /**< Nicht aktivierbar */
	sysStatusBrakeOnlyMode = 2,          /**< Vom System Innodrive2 erkannter Sicherheitszustand */
	sysStatusAvailable = 3,              /**< Durch Set/Resume aktivierbar */
	sysStatusActive = 4,                 /**< System Regelt die Geschwindigkeit */
	sysStatusOverride = 5                /**< Fahrpedalueberdrueckung */
} sysStatus_T;

typedef enum _sysFodStatus {
	sysFodStatusInit = 0,                /**< Initialzustand - Nicht initialisiert */
	sysFodStatusNotActive = 1,           /**< Initialisiert und nicht Aktiviert */
	sysFodStatusActive = 2               /**< Initialisiert und Aktiviert */
} sysFodStatus_T;

typedef enum _sysDisplayError {
	sysErrorNone = 0,                    /**< Kein Fehler erkannt */
	sysErrorStrategy = 1,                /**< Keine gültige Strategieplanung vorhanden */
	sysErrorSpeedLimit = 2,              /**< Aktuelles Tempolimit zu niedrig */
	sysErrorStreetClass = 3,             /**< Aktuelle Straßenklasse nicht freigegeben */
	sysErrorMapData = 4,                 /**< Keine gültigen Kartendaten */
	sysErrorRoadInfo = 5,                /**< Keine gültigen Straßendaten aus Strategy-Task */
	sysErrorCountryCode = 6,             /**< Aktuelles Land in Länderliste nicht freigegeben */
	sysErrorAccInBom = 7,                /**< ACC-System im Brake Only Modus */
	sysErrorAccReversible = 8,           /**< Reversibler Fehler im ACC-System */
	sysErrorAccIrreversible = 9          /**< Irreversibler Fehler im ACC-System */
} sysDisplayError_T;

typedef enum _sysLongMode {
	sysModeNormal = 0,                   /**< Charisma-Fahrprogram Stardard */
	sysModeDynamic = 1,                  /**< Charisma-Fahrprogram Dynamisch */
	sysModeEconomy = 2                   /**< Charisma-Fahrprogram Oekonomisch */
} sysLongMode_T;

typedef enum _sysStopType {
	sysStopNone = 0,                     /**< Keine Stoppstelle */
	sysStopStop = 1,                     /**< Stoppstelle */
	sysStopYield = 2                     /**< Vorfahrt beachten */
} sysStopType_T;

typedef struct _systemControlMemory systemControlMemory_T;
typedef struct _systemControl systemControl_T;
typedef struct _longControlStatus longControlStatus_T;
typedef struct _roadModelInfo roadModelInfo_T;


typedef struct _speedCheckFilter {
	uint16_T overSpeedTicks;             /**< Anzahl der Zeitschritte, in der die Setzgeschwindigkeit bei aktiver Laengsregelung ueberschritten wurde */
} speedCheckFilter_T;                    /**< Groesse der Struktur = 2 Bytes */

typedef struct _fodOutput {
	bool_T dataValidFlag;                /**< 0=data corrupt, 1=data valid */
	uint8_T DeFoDReadyToRun;             /**< InnoDrive kan prinzipiell aktiviert werden.[n/a] */
} fodOutput_T;                           /**< Groesse der Struktur = 2 Bytes */


/*lint -restore */

#endif
