#ifndef guard_sysInfoStatic_h
#define guard_sysInfoStatic_h

#include "common/systemControllerCommon/systemController_interface.h"

/**\brief Berechnet aus Limit-Wert und Rowhwert die Einheit des Tempolimits.
\ingroup	systemController_API
*/
static bool_T	 sysRoadInfoGetUnit(IN	const	real32_T				 limit,
									IN	const	uint16_T				 raw,
									OUT			vobsSignUnit_T			*unit
									);

#endif
