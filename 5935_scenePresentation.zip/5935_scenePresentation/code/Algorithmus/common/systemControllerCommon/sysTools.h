#ifndef guard_sysTools_h
#define guard_sysTools_h

#include "common/common.h"
#include "common/systemControllerCommon/systemController_interface.h"


	/** \brief Gibt den Aktivierungsstatus der L�ngsregelfunktion aus.
	\ingroup	systemController_API
	*/
	void		sysGetLongControlStatus(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			sysStatus_T					*status					/**< Aktivierungszustand Innodrive 2*/
										);
	
	/** \brief Gibt den Function on Demand Status der L�ngsregelfunktion aus.
	\spec SW_AS_Innodrive2_742
	\ingroup	systemController_API
	*/
	void				sysGetFodStatus(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			sysFodStatus_T				*fodStatus	   			/**< Function on Demand Status Innodrive 2*/
										);

	/** \brief Gibt im sysStatusNotAvailable den Grund f�r die Nichtverf�gbarkeit aus.
	In allen Stati au�er sysStatusNotAvailable wir der Wert sysNoError ausgegeben.
	
	\spec SW_AS_Innodrive2_119
	\spec SW_AS_Innodrive2_592
	\ingroup	systemController_API
	*/
	void			 sysGetDisplayError(IN	const	systemControl_T			*systemControl,				/**< Interne Datenstrukur der Systemsteuerung */
										OUT			sysDisplayError_T		*displayError				/**< Grund f�r die Nichtverf�gbarkeit*/
										);

	/** \brief Soll eine �bernahmeaufforderung im Display angezeigt werden?
	\spec SW_AS_Innodrive2_49
	\ingroup	systemController_API
	*/
	void		  sysGetTakeoverRequest(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			bool_T						*request				/**< �bernahmeaufforderung */
										);

	/** \brief Soll im Display "AUTO" statt der Setzgeschwindigkeit angezeigt werden?
	\spec SW_AS_Innodrive2_595
	\spec SW_AS_Innodrive2_596
	\ingroup	systemController_API
	*/
	void			  sysGetDisplayAuto(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			bool_T						*displayAuto			/**< Anzeige "AUTO" */
										);

	/** \brief Soll im Display "AUTO" statt der Setzgeschwindigkeit angezeigt werden?
	\spec SW_AS_Innodrive2_595
	\spec SW_AS_Innodrive2_596
	\ingroup	systemController_API
	*/
	void sysGetDisplayLimitEventsActive(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			bool_T						*dsplLimitEventsActive	/**< Anzeige "Event_aktiv f�r Tempolimits" */
										);

	/** \brief Gibt das aktuelle Charisma-Fahrprogramm zur Auswahl der Dynamikparameter und Kostenfaktoren im strategy-Task aus.
	\ingroup	systemController_API
	*/
	void				sysGetLongMode(	IN const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			sysLongMode_T				*mode					/**< aktuelle Charisma-Fahrprogramm */
										);

	/**\brief Gibt einen Index f�r den Einzuregelnden Abstand auf das Vorderfahrzeug aus.
	\ingroup	systemController_API
	*/
	void				sysGetDistIndex(IN	const	systemControl_T				*systemControl,
										OUT			uint16_T					*distIndex
										);



	/**	\brief	Ruft die zuletzt verworfene Setzgeschwindigkeit f�r die L�ngsregelung ab 
	\ingroup	systemController_API
	*/
	void			 sysGetLastSetSpeed(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			real32_T					*position,				/**< Position, ab der die letzte Setzgeschwindigkeit g�ltig war */
										OUT			real32_T					*velocity				/**< Letzte Setzgeschwindigkeit */
										);


	/**	\brief	Ruft die Setzgeschwindigkeit ab, auf die die L�ngsregelung aktuell regeln soll 
	\spec SW_AS_Innodrive2_59
	\ingroup	systemController_API
	*/
	void		  sysGetCurrentSetSpeed(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstrukur der Systemsteuerung */
										OUT			real32_T					*position,				/**< Position, ab der die aktuelle Setzgeschwindigkeit wurde */
										OUT			real32_T					*velocity				/**< Aktuelle Setzgeschwindigkeit */
										);


	/**	\brief	Ruft die n�chste Setzgeschwindigkeit ab, die aktuell vom Fahrer bedient wird und auf die in Zukunft geregelt werden soll 
	\ingroup	systemController_API
	*/
	void			 sysGetNextSetSpeed(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstruktur der Systemsteuerung */
										OUT			real32_T					*position,				/**< Position, ab die n�chste Setzgeschwindigkeit g�ltig wird */
										OUT			real32_T					*velocity,				/**< N�chste Setzgeschwindigkeit, die aktuell vom Fahrer bedient wird */
										OUT			bool_T						*valid					/**< Gibt an, ob die n�chste Setzgeschwindigkeit aktuell f�r die Regelung relevant ist */
										);


	/**	\brief	Fragt ab, ob die aktuelle Setzgeschwindigkeit dem Fahrer angezeigt werden soll (andernfalls: '---')
	\spec SW_AS_Innodrive2_59
	\ingroup	systemController_API
	*/
	void		   sysIsSetDisplayValid(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstruktur der Systemsteuerung */
										OUT			bool_T						*setDisplayValid		/**< Soll die Setzgeschwindigkeit angezeigt werden? */
										);


	/**	\brief	Ruft Informationen �ber den Status der automatischen �bernahme von Speed Limits in der L�ngsregelung ab 
	\ingroup	systemController_API
	*/
	void			 sysGetAutoModeInfo(IN	const	systemControl_T				*systemControl,			/**< Interne Datenstruktur der Systemsteuerung */
										OUT			bool_T						*autoMode,				/**< Gibt an, ob der autoMode aktiviert ist */
										OUT			real32_T					*previewPosition		/**< Position, ab der Speed Limits f�r die Vorausplanung ber�cksichtigt werden */
										);


	void		  sysGetToleranceFactor(IN	const	systemControl_T				*systemControl,
										OUT			real32_T					*toleranceFactor
										);


	/** \brief	Erstellt eine longControlStatus-Struktur, die den Status der L�ngsregelung an den systemController zur�ckmeldet 
	\ingroup	systemController_API
	*/
	void		sysSetLongControlStatus(IN	const	bool_T						 valid,					/**< Liegt eine g�ltige Anforderung der L�ngsregelung vor? */
										IN	const	real32_T					 previewPosition,		/**< Position der relevaten zul�ssigen H�chstgeschwindigkeit */
										IN	const	real32_T					 stopPosition,			/**< Position der relevanten Stoppstelle */
										OUT			longControlStatus_T			*status					/**< interne Status-Datenstruktur der systemController */
										);


	/**	\brief		Fragt den Wert f�r die Vorausschau-Anzeige von Geschwindigkeitslimits ab
		\ingroup	systemController_API */
	void			 sysGetPreviewLimit(IN	const	systemControl_T				*systemControl,			/**< interne Datenstruktur der Systemsteuerung */
										OUT			uint16_T					*previewLimit,			/**< Anzeigewert f�r das vorausliegende Geschwindigkeitslimit */
										OUT			bool_T						*previewLock			/**< Anforderung f�r das Zur�ckhalten anderer Vorausschauevents */
										);


	/**	\brief		Fragt die Anzeigegr��en der Stoppstellen-Funktion im systemController ab 
	
	\ingroup	systemController_API
	*/
	void			   sysGetStopOutput(IN	const	systemControl_T				*systemControl,			/**< interne Datenstruktur der Systemsteuerung */
										OUT			sysStopType_T				*stopInRange			/**< Gibt an, ob und welche Stoppstelle dem Fahrer angezeigt werden soll */
										);


	/**	\brief		Fragt ab, ob f�r die Regelung auf die aktuelle Setzgeschwindigkeit reduzierte Gradienten gefordert werden
	
	\ingroup	systemController_API
	*/
	void		   sysGetOverrideReturn(IN	const	systemControl_T				*systemControl,			/**< interne Datenstruktur der Systemsteuerung */
										OUT			bool_T						*overrideReturn			/**< Soll mit reduzierter Verz�gergung auf die Setzgeschwindigkeit geregelt werden? */
										);



	/**	\brief		Fragt die Freigabeposition f�r Stoppstellen ab 
	
	\ingroup	systemController_API
	*/
	void		sysGetStopSweepPosition(IN	const	systemControl_T				*systemControl,			/**< interne Datenstruktur der Systemsteuerung */
										OUT			real32_T					*stopSweepPosition		/**< Position, bis zu der Stoppstellen vom Fahrer freigegeben wurden */
										);

	/**	\brief		Fragt ab ob eine Aktivierung des Systems fehlgeschlagen ist 
	
	\ingroup	systemController_API
	*/
	void   sysGetUnsuccessfulActivation(IN	const	systemControl_T				*systemControl,				/**< interne Datenstruktur der Systemsteuerung */
										OUT			bool_T						*unsuccessfulActivation		/**< Ist 1, wenn das System nicht aktiviert werden konnte */
										);
	

	/**	\brief		Zeigt an ob ein Hinweis im Kombi angezeigt werden darf 
	\spec SW_AS_Innodrive2_675
	\ingroup	systemController_API
	*/
	void				 sysGetShowHint(IN	const	systemControl_T				*systemControl,			/**< interne Datenstruktur der Systemsteuerung */
										OUT			bool_T						*showHint				/**< Flag, das signalisiert ob der Geschwindigkeitshinweis gerade angezeigt werden darf */
		);
	
	/**	\brief		Fragt ab ob es vor kurzem einen internen Fehler im systemController gab
	\spec SW_AS_Innodrive2_726
	\ingroup	systemController_API
	*/
	void		   sysGetErrorTicks(IN	const	systemControl_T				*systemControl,				/**< interne Datenstruktur der Systemsteuerung */
									OUT			uint16_T					*errorTicks					/**< Restanzeigedauer eines internen Fehlers[20ms] */
									);				


#endif
