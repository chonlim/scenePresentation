#ifndef __CANCODECPRIVATE2_0_HEADER__
#define __CANCODECPRIVATE2_0_HEADER__

#pragma pack(push, 8)
typedef struct
{
    tBool QGW_Schnittstelle_freigegeben; // signal=QGW_Status.QGW_Schnittstelle_freigegeben;
    tBool QGW_Anforderung_Schnittstelle; // signal=QGW_Status.QGW_Anforderung_Schnittstelle;
    tBool QGW_Schnittstelle_aktiv; // signal=QGW_Status.QGW_Schnittstelle_aktiv;
    tBool QGW_Momenteneingriff_aktiv; // signal=QGW_Status.QGW_Momenteneingriff_aktiv;
    tBool QGW_Kommunikation_OK; // signal=QGW_Status.QGW_Kommunikation_OK;
    tBool QGW_Freigabe_moeglich; // signal=QGW_Status.QGW_Freigabe_moeglich;
    tBool QGW_Schnittstelle_Bedingungen_OK; // signal=QGW_Status.QGW_Schnittstelle_Bedingungen_OK;
    tBool QGW_Befehl_Freigabe; // signal=QGW_Status.QGW_Befehl_Freigabe;
    tBool QGW_Befehl_Aktivieren; // signal=QGW_Status.QGW_Befehl_Aktivieren;
    tBool QGW_Befehl_Abbrechen; // signal=QGW_Status.QGW_Befehl_Abbrechen;
    tBool QGW_Anforderung_Momenteneingriff; // signal=QGW_Status.QGW_Anforderung_Momenteneingriff;
} tQGW_Status;


typedef struct
{
    tUInt8 MODE_STAT_FFP; // signal=STATUS_FFP.MODE_STAT_FFP;
    tUInt8 CHKSM_STAT_FFP; // signal=STATUS_FFP.CHKSM_STAT_FFP;
    tFloat64 ANGLE_ACTUAL_STAT_FFP; // signal=STATUS_FFP.ANGLE_ACTUAL_STAT_FFP;
    tUInt8 ALIVE_STAT_FFP; // signal=STATUS_FFP.ALIVE_STAT_FFP;
    tFloat64 THERM_SPARE_STAT_FFP; // signal=STATUS_FFP.THERM_SPARE_STAT_FFP;
    tUInt8 CURREQ_STAT_FFP; // signal=STATUS_FFP.CURREQ_STAT_FFP;
    tFloat64 CURRENT_ACTUAL_FFP; // signal=STATUS_FFP.CURRENT_ACTUAL_FFP;
} tSTATUS_FFP;


typedef struct
{
    tFloat64 DME_SysOpmESto_rRelSoc_VW; // signal=DME_SOC.DME_SysOpmESto_rRelSoc_VW;
    tFloat64 DME_SysOpmESto_rSocMin_VW; // signal=DME_SOC.DME_SysOpmESto_rSocMin_VW;
    tFloat64 DME_SysOpmESto_rSocMax_VW; // signal=DME_SOC.DME_SysOpmESto_rSocMax_VW;
} tDME_SOC;


typedef struct
{
    tUInt8 DME_DrvModSwt_noModReq_VW; // signal=DME_HMode.DME_DrvModSwt_noModReq_VW;
} tDME_HMode;


typedef struct
{
    tInt16 DME_CoPOM_MapNoChk; // signal=DME_trqElM.DME_CoPOM_MapNoChk;
    tFloat64 DME_CoPOM_trqElMCh1; // signal=DME_trqElM.DME_CoPOM_trqElMCh1;
} tDME_trqElM;


typedef struct
{
    tUInt8 DME_Byp_stEcuGlobal; // signal=DME_Control.DME_Byp_stEcuGlobal;
} tDME_Control;


typedef struct
{
    tUInt8 APW_VZE; // signal=connectedAPW.APW_VZE;
    tBool APW_Valid_VZE; // signal=connectedAPW.APW_Valid_VZE;
    tBool APW_Valid_mueLow; // signal=connectedAPW.APW_Valid_mueLow;
    tBool APW_Valid_NG; // signal=connectedAPW.APW_Valid_NG;
    tUInt8 APW_mueLow; // signal=connectedAPW.APW_mueLow;
    tUInt8 APW_Naessegrad; // signal=connectedAPW.APW_Naessegrad;
} tconnectedAPW;


typedef struct
{
    tUInt8 MFL_Tastencode_1; // signal=MFL_Tasten_Kon_01.MFL_Tastencode_1;
    tUInt8 MFL_Tastencode_2; // signal=MFL_Tasten_Kon_01.MFL_Tastencode_2;
    tUInt8 MFL_Eventcode_1; // signal=MFL_Tasten_Kon_01.MFL_Eventcode_1;
    tUInt8 MFL_Eventcode_2; // signal=MFL_Tasten_Kon_01.MFL_Eventcode_2;
    tUInt8 MFL_Marke; // signal=MFL_Tasten_Kon_01.MFL_Marke;
    tUInt8 MFL_Variante; // signal=MFL_Tasten_Kon_01.MFL_Variante;
} tMFL_Tasten_Kon_01;


typedef struct
{
    tBool IDT_TipUp; // signal=IDT_01.IDT_TipUp;
    tUInt8 IDT_Counter; // signal=IDT_01.IDT_Counter;
    tBool IDT_TipDown; // signal=IDT_01.IDT_TipDown;
    tBool IDT_GearValid; // signal=IDT_01.IDT_GearValid;
} tIDT_01;


typedef struct
{
    tUInt8 IDC_01_CRC; // signal=IDC_01.IDC_01_CRC;
    tUInt8 IDC_01_BZ; // signal=IDC_01.IDC_01_BZ;
    tBool IDC_01_thermoValid; // signal=IDC_01.IDC_01_thermoValid;
    tUInt8 IDC_01_rSpoilerPosition; // signal=IDC_01.IDC_01_rSpoilerPosition;
    tBool IDC_01_heatRequest; // signal=IDC_01.IDC_01_heatRequest;
    tBool IDC_01_aeroValid; // signal=IDC_01.IDC_01_aeroValid;
} tIDC_01;


typedef struct
{
    tInt8 ID_HMI_Status_ID; // signal=ID_HMI_01.ID_HMI_Status_ID;
    tUInt8 ID_HMI_CRC; // signal=ID_HMI_01.ID_HMI_CRC;
    tUInt8 ID_HMI_BZ; // signal=ID_HMI_01.ID_HMI_BZ;
    tUInt8 ID_HMI_warning; // signal=ID_HMI_01.ID_HMI_warning;
    tFloat64 ID_HMI_Traffic_Velocity; // signal=ID_HMI_01.ID_HMI_Traffic_Velocity;
    tUInt16 ID_HMI_Traffic_Distance; // signal=ID_HMI_01.ID_HMI_Traffic_Distance;
    tUInt16 ID_HMI_Setspeed; // signal=ID_HMI_01.ID_HMI_Setspeed;
    tUInt8 ID_HMI_ACCBars; // signal=ID_HMI_01.ID_HMI_ACCBars;
} tID_HMI_01;


typedef struct
{
    tBool IDQ_AlternativerEingriff; // signal=IDQ_01.IDQ_AlternativerEingriff;
    tBool IDQ_VZ_Lenkmoment; // signal=IDQ_01.IDQ_VZ_Lenkmoment;
    tUInt8 IDQ_Status; // signal=IDQ_01.IDQ_Status;
    tBool IDQ_Freigabe_Lenkmoment; // signal=IDQ_01.IDQ_Freigabe_Lenkmoment;
    tFloat64 IDQ_Lenkmoment; // signal=IDQ_01.IDQ_Lenkmoment;
    tUInt8 IDQ_01_CRC; // signal=IDQ_01.IDQ_01_CRC;
    tUInt8 IDQ_01_BZ; // signal=IDQ_01.IDQ_01_BZ;
} tIDQ_01;


typedef struct
{
    tInt8 LKRD_LED2; // signal=Lenkrad_LED.LKRD_LED2;
    tInt8 LKRD_LED1; // signal=Lenkrad_LED.LKRD_LED1;
} tLenkrad_LED;


typedef struct
{
    tFloat64 STIFFNESS_RQBAS_FFP; // signal=ID_AFFP_01.STIFFNESS_RQBAS_FFP;
    tUInt8 MOD_EXT_RQBAS_FFP; // signal=ID_AFFP_01.MOD_EXT_RQBAS_FFP;
    tUInt8 JITTER; // signal=ID_AFFP_01.JITTER;
    tUInt8 CHKSM_RQBAS_FFP; // signal=ID_AFFP_01.CHKSM_RQBAS_FFP;
    tFloat64 ANGLE_DESIRED_RQBAS_FFP; // signal=ID_AFFP_01.ANGLE_DESIRED_RQBAS_FFP;
    tFloat64 FORCE_MAX_RQBAS_FFP; // signal=ID_AFFP_01.FORCE_MAX_RQBAS_FFP;
    tFloat64 FORCE_MIN_RQBAS_FFP; // signal=ID_AFFP_01.FORCE_MIN_RQBAS_FFP;
    tUInt8 FUNC_RQBAS_FFP; // signal=ID_AFFP_01.FUNC_RQBAS_FFP;
    tUInt8 ALIVE_RQBAS_FFP; // signal=ID_AFFP_01.ALIVE_RQBAS_FFP;
} tID_AFFP_01;


typedef struct
{
    tUInt8 IDL_01_engine_StartRequest; // signal=IDL_01.IDL_01_engine_StartRequest;
    tUInt16 IDL_01_eTorque; // signal=IDL_01.IDL_01_eTorque;
    tBool IDL_01_hybridValid; // signal=IDL_01.IDL_01_hybridValid;
    tBool IDL_01_gearValid; // signal=IDL_01.IDL_01_gearValid;
    tUInt8 IDL_01_targetGear; // signal=IDL_01.IDL_01_targetGear;
    tBool IDL_01_SOMValid; // signal=IDL_01.IDL_01_SOMValid;
    tBool IDL_01_coastRequest; // signal=IDL_01.IDL_01_coastRequest;
    tBool IDL_01_longValid; // signal=IDL_01.IDL_01_longValid;
    tUInt8 IDL_01_CRC; // signal=IDL_01.IDL_01_CRC;
    tUInt8 IDL_01_BZ; // signal=IDL_01.IDL_01_BZ;
    tFloat32 IDL_01_acceleration; // signal=IDL_01.IDL_01_acceleration;
    tInt16 IDL_01_totalTorque; // signal=IDL_01.IDL_01_totalTorque;
    tBool IDL_01_holdVehicle; // signal=IDL_01.IDL_01_holdVehicle;
} tIDL_01;

#pragma pack(pop)

#endif // __CANCODECPRIVATE2_0_HEADER__
