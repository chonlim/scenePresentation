#ifndef guard_comFilter_h
#define guard_comFilter_h

#include "comFilterTypes.h"


#ifdef __cplusplus
extern "C" {
#endif

	void	comFilterGetOutput(IN	const	comFilter_T				*filter,
								OUT			real32_T				*outputValue);

	bool_T	    comFilterUpdate(MEMORY		comFilter_T				*filter,
								IN	const	real32_T				 inputSample,
								INOUT		real32_T				*outputValue);


	bool_T		 comLowPassInit(MEMORY		comFilter_T				*lowPass,
								IN	const	real32_T				 deltaTime,
								IN	const	real32_T				 cutoffFreq);

	bool_T		comFilterSetMem(MEMORY		comFilter_T				*filter,
								IN	const	real32_T				 initValue);


#ifdef __cplusplus
}
#endif

#endif
