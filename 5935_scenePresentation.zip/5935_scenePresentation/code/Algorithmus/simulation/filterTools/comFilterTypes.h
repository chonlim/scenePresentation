#ifndef guard_comFilterTypes_h
#define guard_comFilterTypes_h

#include "common/common.h"


typedef struct _comFilter {
	struct _com_flt_coeff {
		real32_T a[2];
		real32_T b[2];
	} coeff;
	struct _com_flt_memory {
		real32_T input[2];
		real32_T output[2];
	} memory;
} comFilter_T;


#endif
