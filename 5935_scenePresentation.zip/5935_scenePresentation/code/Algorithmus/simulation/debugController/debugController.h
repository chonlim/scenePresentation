#ifndef guard_debugController_h
#define guard_debugController_h

#include "simulation/simulation.h"

#include "control/controlTask/controlTask_interface.h"
#include "common/vehicleModel/vehicleModel_interface.h"
#include "debugController_interface.h"

#ifdef __cplusplus
extern "C" {
#endif


	void		debugController(MEMORY		debugFilter_T			*debugFilter,
								IN	const	vehicleModel_T			*vehicleModel,
								IN	const	vehicleInput_T			*vehicleInput,
								IN	const	flexrayOutput_T			*flexrayOutput,
								OUT			debugControl_T			*debugControl
								);


#ifdef __cplusplus
}
#endif


#endif