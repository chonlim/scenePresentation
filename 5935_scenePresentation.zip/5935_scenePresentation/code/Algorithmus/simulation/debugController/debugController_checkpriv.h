#ifndef guard_debugControllercheckpriv_h
#define guard_debugControllercheckpriv_h


/*! \brief File der Min/Max Pr�ffunktionen, generiert aus  debugController.ifxml
           generated code

*/
#include <string.h>
#include "common/common.h"
#include "simulation/debugController/debugController_private.h"
#include "simulation/debugController/debugController_checkfunct.h"

/*lint -save */
/*lint -e545 	"Warning -- Suspicious use of &" */
/*lint -e568 	"Warning -- non-negative quantity is never less than zero" */
/*lint -e685 	"Warning -- Relational operator '<' always evaluates to 'false'*/
/*lint -e715 	"Symbol 'XXX' not referenced)" */
/*lint -e818 	"Pointer parameter 'XXX' could be declared as pointing to const*/
/*lint -e9034 	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]*/
/*lint -e9087	"(Note -- cast performed between a pointer to object type and a pointer to a different object type[MISRA 2012 Rule 11.3, required])" */
/* e9087 comment: memcpy want a void* as parameter, so we must do this cast" */
/*lint -e9030	"Note -- Impermissible cast; cannot cast from 'essentially Boolean' to 'essentially unsigned' [MISRA 2012 Rule 10.5, advisory]" */
/* e9030 comment: the type cast (bool_T)true is generated in the same way than (real32_t)0.0f but boolean is not allowed to cast" */
#include "simulation/filterTools/comFilterTypes.h"


/*------------------------------Start Value Initialilsierungs Sektion--------------------------------*/


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#pragma warning( disable : 4100)
#endif



static void busInit_dbgDelay (dbgDelay_T* dbgDelay );
static void busInit_dbgVelocityFilter (dbgVelocityFilter_T* dbgVelocityFilter );
static void busInit_dbgTorqueFilter (dbgTorqueFilter_T* dbgTorqueFilter );
static void busInit_debugFilter (debugFilter_T* debugFilter );
static void busInit_debugControl (debugControl_T* debugControl );

#ifdef __CTC__

#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif

static uint8_T dbgDelayIsInit = 0;
static dbgDelay_T mydbgDelay;

#ifdef __CTC__

#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif


#ifdef __CTC__

#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif

static uint8_T dbgVelocityFilterIsInit = 0;
static dbgVelocityFilter_T mydbgVelocityFilter;

#ifdef __CTC__

#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif


#ifdef __CTC__

#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif

static uint8_T dbgTorqueFilterIsInit = 0;
static dbgTorqueFilter_T mydbgTorqueFilter;

#ifdef __CTC__

#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif


#ifdef __CTC__

#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif

static uint8_T debugFilterIsInit = 0;
static debugFilter_T mydebugFilter;

#ifdef __CTC__

#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif


#ifdef __CTC__

#define CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif

static uint8_T debugControlIsInit = 0;
static debugControl_T mydebugControl;

#ifdef __CTC__

#define CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
#include "MemMap.h"

#endif



/*lint -esym(715,dbgDelay) */
/*lint -esym(818,dbgDelay) */
/*lint -esym(621,busInit_dbgDelay*/ 
static void busInit_dbgDelay (dbgDelay_T* dbgDelay )
{
	if( dbgDelayIsInit == (uint8_T)0 )
	{
		dbgDelayIsInit = 1;
		memset (dbgDelay, 0, sizeof(dbgDelay_T));
		memcpy((void*)&mydbgDelay, (void*)dbgDelay, sizeof(dbgDelay_T ));
	}
	else
	{
		memcpy((void*)dbgDelay, (void*)&mydbgDelay, sizeof(dbgDelay_T ));
	}
}

/*lint -esym(715,dbgVelocityFilter) */
/*lint -esym(818,dbgVelocityFilter) */
/*lint -esym(621,busInit_dbgVelocityFilter*/ 
static void busInit_dbgVelocityFilter (dbgVelocityFilter_T* dbgVelocityFilter )
{
	if( dbgVelocityFilterIsInit == (uint8_T)0 )
	{
		dbgVelocityFilterIsInit = 1;
		memset (dbgVelocityFilter, 0, sizeof(dbgVelocityFilter_T));
		memcpy((void*)&mydbgVelocityFilter, (void*)dbgVelocityFilter, sizeof(dbgVelocityFilter_T ));
	}
	else
	{
		memcpy((void*)dbgVelocityFilter, (void*)&mydbgVelocityFilter, sizeof(dbgVelocityFilter_T ));
	}
}

/*lint -esym(715,dbgTorqueFilter) */
/*lint -esym(818,dbgTorqueFilter) */
/*lint -esym(621,busInit_dbgTorqueFilter*/ 
static void busInit_dbgTorqueFilter (dbgTorqueFilter_T* dbgTorqueFilter )
{
	if( dbgTorqueFilterIsInit == (uint8_T)0 )
	{
		dbgTorqueFilterIsInit = 1;
		memset (dbgTorqueFilter, 0, sizeof(dbgTorqueFilter_T));
		memcpy((void*)&mydbgTorqueFilter, (void*)dbgTorqueFilter, sizeof(dbgTorqueFilter_T ));
	}
	else
	{
		memcpy((void*)dbgTorqueFilter, (void*)&mydbgTorqueFilter, sizeof(dbgTorqueFilter_T ));
	}
}

/*lint -esym(715,debugFilter) */
/*lint -esym(818,debugFilter) */
/*lint -esym(621,busInit_debugFilter*/ 
static void busInit_debugFilter (debugFilter_T* debugFilter )
{
	if( debugFilterIsInit == (uint8_T)0 )
	{
		debugFilterIsInit = 1;
		memset (debugFilter, 0, sizeof(debugFilter_T));
		memcpy((void*)&mydebugFilter, (void*)debugFilter, sizeof(debugFilter_T ));
	}
	else
	{
		memcpy((void*)debugFilter, (void*)&mydebugFilter, sizeof(debugFilter_T ));
	}
}

/*lint -esym(715,debugControl) */
/*lint -esym(818,debugControl) */
/*lint -esym(621,busInit_debugControl*/ 
static void busInit_debugControl (debugControl_T* debugControl )
{
	if( debugControlIsInit == (uint8_T)0 )
	{
		debugControlIsInit = 1;
		memset (debugControl, 0, sizeof(debugControl_T));
		memcpy((void*)&mydebugControl, (void*)debugControl, sizeof(debugControl_T ));
	}
	else
	{
		memcpy((void*)debugControl, (void*)&mydebugControl, sizeof(debugControl_T ));
	}
}


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#pragma warning( default : 4100)
#endif

/*------------------------------Ende Initialilsierungs Sektion--------------------------------*/
/*lint -restore */

#endif
