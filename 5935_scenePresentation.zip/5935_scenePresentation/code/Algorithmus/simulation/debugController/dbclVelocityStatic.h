#ifndef guard_dbclVelocityStatic_h
#define guard_dbclVelocityStatic_h


static bool_T		  dbclDelayPush(MEMORY		dbgDelay_T				*delay,
									IN	const	real32_T				 value
									);


static bool_T		  dbclDelayInit(MEMORY		dbgDelay_T				*delay
									);


static bool_T	  dbclDelayGetCount(IN	const	dbgDelay_T				*delay,
									OUT			uint16_T				*count
									);


static bool_T	  dbclDelayGetValue(IN	const	dbgDelay_T				*delay,
									IN	const	uint16_T				 steps,
									OUT			real32_T				*value
									);


static bool_T	 dbclDelayAddOffset(MEMORY		dbgDelay_T				*delay,
									IN	const	real32_T				 offset
									);


#endif
