#ifndef guard_debugController_private_h
#define guard_debugController_private_h

#include "simulation/debugController/debugController_interface.h"
#include "simulation/filterTools/comFilterTypes.h"
/*lint -save */
/*lint -e631	"Warning -- tag '_longPreview::_longPreview_curve' defined differently" */
/*lint -e770	"Warning -- Identifier clash" */
/*lint -e760	"Info -- Redundant macro defined identically" */
/*lint -e761	"Info -- Redundant typedef 'XXXXXXX_T' previously declared at ...." */
/*lint -e833	"Info -- Symbol is typed differently (strong) in another module" */
/*lint -e9058	"Note -- tag unused outside of typedefs [MISRA 2012 Rule 2.4, advisory]" */





struct _dbgDelay {
	real32_T data[25];
	uint16_T index;
	uint16_T count;
};    /**< Groesse der Struktur = 104 Bytes */



struct _dbgVelocityFilter {
	bool_T init;
	dbgDelay_T velocityDelay;
	dbgDelay_T unfilteredDelay;
	real32_T resistanceDeviation;
	real32_T rawVelocity;
	real32_T filteredVelocity;
};    /**< Groesse der Struktur = 16 Bytes */



struct _dbgTorqueFilter {
	struct _dbgTorqueFilter_torqueLowPass {
		bool_T relevant;
		comFilter_T filter;
	} torqueLowPass;
	struct _dbgTorqueFilter_state {
		real32_T rampFactor;
		uint8_T gear;
		real32_T acceleration;
		real32_T torque;
	} state;
};    /**< Groesse der Struktur = 20 Bytes */



struct _debugFilter {
	uint8_T watchdogCounter;
	dbgVelocityFilter_T velocity;
	dbgTorqueFilter_T torque;
};



struct _debugControl {
	uint8_T watchdogCounter; /**< Watchdog-Zähler; wird in jedem Rechenschritt erhöht (im Bereich [1 15]) */
	bool_T valid; /**< Gibt an, ob die Anforderung für Sollbeschleunigung und -moment gültig ist */
	real32_T acceleration; /**< Sollbeschleunigung[m/s²] */
	real32_T totalTorque; /**< Momentenanforderung; ein negatives Moment wird als Brems-, eine Null als Segel-/Schubanforderung interpretiert[Nm] */
	uint8_T gearValid; /**< Gibt an, ob die Ganganfoderung gültig ist */
	uint8_T gear; /**< Sollgang */
	bool_T coastRequest; /**< Auswahl von Schub bzw. Segeln */
	bool_T coastValid; /**< Gibt an, ob eine gültige Segelanforderung vorliegt */
};    /**< Groesse der Struktur = 16 Bytes */




/*lint -restore */

#endif
