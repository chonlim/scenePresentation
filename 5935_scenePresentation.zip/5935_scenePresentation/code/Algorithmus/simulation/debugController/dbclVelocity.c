#include "debugController.h"
#include "debugController_private.h"

#include "dbclVelocity.h"
#include "dbclVelocityStatic.h"

#include <memory.h>
#include "simulation/parameterSet/parameterSetSimu.h"

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_Unknown)


bool_T			 dbclVelocityFilter(MEMORY		dbgVelocityFilter_T		*filter,
									IN	const	bool_T					 active,
									IN	const	bool_T					 relevant,
									IN	const	real32_T				 acceleration,
									IN	const	real32_T				 deltaTime,
									IN	const	real32_T				 unfilteredVelocity)
{
	const parameterSetSimu_T *paramSet = prmGetParameterSetSimu();

	real32_T	outerDelta;
	real32_T	innerDelta;
	real32_T	relevantDelta;
	uint16_T	relevantCount;
	real32_T	deviationDelta;
	uint16_T	n;
	real32_T	reference;

	/* Initialisieren der Filter mit Default-Werten */
	if(!filter->init || !active) {
		filter->init				= true;
		filter->filteredVelocity	= unfilteredVelocity;
		filter->resistanceDeviation	= 0.0f;

		diagFF(dbclDelayInit(&filter->velocityDelay));
		diagFF(dbclDelayInit(&filter->unfilteredDelay));
	}

	filter->rawVelocity			= unfilteredVelocity;

	/* Ohne aktive L�ngsregelung gibt es f�r uns hier nichts zu tun. */
	if(!active) {
		return true;
	}

	/* Pr�diktionsschritt */
	filter->filteredVelocity	+= acceleration * deltaTime;

	/* Aktuelle Geschwindigkeit in den Ringspeicher schieben */
	diagFF(dbclDelayPush(&filter->velocityDelay,		 filter->filteredVelocity));
	diagFF(dbclDelayPush(&filter->unfilteredDelay,		 filter->rawVelocity));

	/* Wie viele Punkte der Historie wollen wir auswerten? */
	diagFF(dbclDelayGetCount(&filter->velocityDelay, &relevantCount));
	relevantCount	= min(relevantCount, paramSet->debugController.velocityFilter.delayCount);

	outerDelta	= INVALID_VALUE;
	innerDelta	= INVALID_VALUE;

	/* Aufgrund comDelay25Push(&filter->velocityDelay) gilt immer implizite Annahme relevantCount > 0 */
	diagFF(dbclDelayGetValue(&filter->unfilteredDelay, (uint16_T) (relevantCount - 1), &reference));

	reference	= unfilteredVelocity;
	
	for(n = 0; n < relevantCount; n++) {
		real32_T	outer, inner;
		real32_T	value;

		diagFF(dbclDelayGetValue(&filter->velocityDelay, n, &value));

		outer	= reference - value;
		if(outer >= 0.0f) { outer = max(0.0f, outer - paramSet->debugController.velocityFilter.outer.tolerance.max); }
		if(outer <  0.0f) { outer = min(0.0f, outer - paramSet->debugController.velocityFilter.outer.tolerance.min); }
		outer	*= paramSet->debugController.velocityFilter.outer.factor;

		if(fastfabsf(outer) < fastfabsf(outerDelta)) {
			outerDelta = outer;
		}

		inner	= reference - value;
		if(inner >= 0.0f) { inner = max(0.0f, inner - paramSet->debugController.velocityFilter.inner.tolerance.max); }
		if(inner <  0.0f) { inner = min(0.0f, inner - paramSet->debugController.velocityFilter.inner.tolerance.min); }
		inner	*= paramSet->debugController.velocityFilter.inner.factor;

		if(fastfabsf(inner) < fastfabsf(innerDelta)) {
			innerDelta = inner;
		}
	}

	/* Updateschritt */
	relevantDelta				 = innerDelta + outerDelta;
	filter->filteredVelocity	+= relevantDelta;

	diagFF(dbclDelayAddOffset(&filter->velocityDelay, relevantDelta));

	if(paramSet->global.killDisturbance) {
		filter->filteredVelocity	= unfilteredVelocity;
		deviationDelta				= 0.0f;
	}

	filter->filteredVelocity	 = max(filter->filteredVelocity, 0.0f);

	/* Update der resistanceDeviation nur bei Moment >= 0 */
	if(relevant) {
		deviationDelta	= -relevantDelta * paramSet->debugController.velocityFilter.deviation.factor;
	}
	else {
		deviationDelta	= 0.0f;
	}

	deviationDelta	= min(deviationDelta, paramSet->debugController.velocityFilter.deviation.rate.max * deltaTime);
	deviationDelta	= max(deviationDelta, paramSet->debugController.velocityFilter.deviation.rate.min * deltaTime);

	filter->resistanceDeviation	+= deviationDelta;
	filter->resistanceDeviation	*= paramSet->debugController.velocityFilter.deviation.trickle;

	return true;
}


static bool_T		  dbclDelayPush(MEMORY		dbgDelay_T				*delay,
									IN	const	real32_T				 value)
{
	uint16_T	size = (uint16_T)(sizeof(delay->data) / sizeof(delay->data[0]));

	if(delay->count != (uint16_T)0U) {
		delay->index	+= (uint16_T)1U;
		delay->index	%= size;
	}

	delay->data[delay->index]	= value;

	if(delay->count != size) { delay->count++; }

	return true;
}


static bool_T		  dbclDelayInit(MEMORY		dbgDelay_T				*delay)
{
	memset(delay, 0, sizeof(*delay));

	return true;
}


static bool_T	  dbclDelayGetCount(IN	const	dbgDelay_T				*delay,
									OUT			uint16_T				*count)
{
	*count = delay->count;

	return true;
}


static bool_T	  dbclDelayGetValue(IN	const	dbgDelay_T				*delay,
									IN	const	uint16_T				 steps,
									OUT			real32_T				*value)
{
	uint16_T forward;
	uint16_T offset;

	diagFF(delay->count > 0);
	diagFF(steps < delay->count);

	forward	= (delay->count - steps);
	offset	= (delay->index + forward) % delay->count;

	*value = delay->data[offset];

	return true;
}


static bool_T	 dbclDelayAddOffset(MEMORY		dbgDelay_T				*delay,
									IN	const	real32_T				 offset)
{
	uint16_T step;
	uint16_T forward;
	uint16_T index;

	for(step = 0U; step < delay->count; step++) {
		forward				 = (delay->count - step);
		index				 = (delay->index + forward) % delay->count;
		delay->data[index]	+= offset;
	}

	return true;
}
