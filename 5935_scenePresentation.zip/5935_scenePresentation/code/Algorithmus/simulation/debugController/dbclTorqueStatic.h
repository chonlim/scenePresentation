#ifndef guard_dbclTorqueStatic_h
#define guard_dbclTorqueStatic_h


static bool_T		dbclGetResistanceTorque(IN	const	vehicleModel_T			*vehicleModel,			/*!< Eingangs-Struktur vehicleModel*/
											IN	const	real32_T				 curvature,				/*!< Kurvenkr�mmung */
											IN	const	real32_T				 slope,					/*!< Steigung */
											IN	const	real32_T				 resistanceDeviation,	/*!< berechnete Abweichung Fahrwiderstand */
											IN	const	real32_T				 velocity,				/*!< aktuelle Geschwindigkeit */
											IN	const	uint8_T					 gear,					/*!< aktuelle Gang */
											OUT			real32_T				*resistanceTorque		/**< \todo TBD */
											);


static bool_T			   dbclGetMaxTorque(IN	const	uint8_T					 gear,					/*!< aktueller Gang */
											OUT			real32_T				*maxTorque				/**< \todo TBD */
											);


static bool_T	  dbclGetActualAcceleration(IN	const	vehicleModel_T			*vehicleModel,			/*!< Eingangs-Struktur vehicleModel*/
											IN	const	real32_T				 resistanceTorque,		/*!< aktuelles Fahrwiderstandsmoment */
											IN	const	real32_T				 velocity,				/*!< aktuelle Geschwindigkeit */
											IN	const	uint8_T					 gear,					/*!< aktueller Gang */
											IN	const	real32_T				 accelerationRequest,	/*!< Sollbeschleunigung */
											IN	const	real32_T				 rampFactor,			/*!< Faktor f�r Einrampen des Sollmoments durch systemController */
											IN	const	real32_T				 maxTorque,				/*!< maximales Moment */
											OUT			real32_T				*accelerationActual		/**< \todo TBD */
											);


static bool_T	 dbclGetLimitedAcceleration(IN	const	real32_T				 jerkPositive,			/**< \todo TBD */
											IN	const	real32_T				 jerkNegative,			/**< \todo TBD */
											IN	const	real32_T				 lastAcceleration,		/*!< letzte Beschleunigung */
											IN	const	real32_T				 targetAcceleration,	/*!< Zielbeschleunigung */
											OUT			real32_T				*nextAcceleration		/**< \todo TBD */
											);


#endif
