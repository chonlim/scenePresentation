#ifndef guard_dbclStep_h
#define guard_dbclStep_h


#ifdef __cplusplus
extern "C" {
#endif


	bool_T					   dbclUpdateTorque(MEMORY		dbgTorqueFilter_T		*filter,
												IN	const	vehicleModel_T			*vehicleModel,
												IN	const	flexrayOutput_T			*flexrayOutput,
												IN	const	real32_T				 velocity,
												IN	const	real32_T				 slope,
												IN	const	uint8_T					 gear,
												IN	const	real32_T				 resDeviation,
												IN	const	real32_T				 deltaTime,
												OUT			real32_T				*torque,
												OUT			real32_T				*acceleration
												);


#ifdef __cplusplus
}
#endif


#endif
