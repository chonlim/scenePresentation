#ifndef  guard_debugControllercheckfunc_h
#define  guard_debugControllercheckfunc_h


/*! \brief File der Min/Max Pr�ffunktionen, generiert aus  debugController.ifxml
           generated code

*/
#include <string.h>
#include "common/common.h"
#include "simulation/debugController/debugController_interface.h"

/*lint -save */
/*lint -e545 	"Warning -- Suspicious use of &" */
/*lint -e568 	"Warning -- non-negative quantity is never less than zero" */
/*lint -e685 	"Warning -- Relational operator '<' always evaluates to 'false'*/
/*lint -e715 	"Symbol 'XXX' not referenced)" */
/*lint -e818 	"Pointer parameter 'XXX' could be declared as pointing to const*/
/*lint -e9034 	"Note -- Expression assigned to a narrower or different essential type [MISRA 2012 Rule 10.3, required]*/
/*lint -e9087	"(Note -- cast performed between a pointer to object type and a pointer to a different object type[MISRA 2012 Rule 11.3, required])" */
/* e9087 comment: memcpy want a void* as parameter, so we must do this cast" */
/*lint -e9030	"Note -- Impermissible cast; cannot cast from 'essentially Boolean' to 'essentially unsigned' [MISRA 2012 Rule 10.5, advisory]" */
/* e9030 comment: the type cast (bool_T)true is generated in the same way than (real32_t)0.0f but boolean is not allowed to cast" */


/*------------------------------Start Value Initialilsierungs Sektion--------------------------------*/


#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#pragma warning( disable : 4100)
#endif






#if !defined(INNODRIVE_ZFAS_SWC_BUILD)
#pragma warning( default : 4100)
#endif

/*------------------------------Ende Initialilsierungs Sektion--------------------------------*/
/*lint -restore */

#endif
