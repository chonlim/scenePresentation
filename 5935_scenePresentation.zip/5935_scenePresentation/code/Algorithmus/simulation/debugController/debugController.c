#include "debugController.h"
#include "debugController_private.h"

#include "dbclVelocity.h"
#include "dbclTorque.h"
#include "dbclOutput.h"

#include <memory.h>

#include <BusSignals_enums.h>


void		debugController(MEMORY		debugFilter_T			*debugFilter,
							IN	const	vehicleModel_T			*vehicleModel,
							IN	const	vehicleInput_T			*vehicleInput,
							IN	const	flexrayOutput_T			*flexrayOutput,
							OUT			debugControl_T			*debugControl)
{
	real32_T	torque;
	real32_T	acceleration;
	bool_T		success = true;


	/* internen Watchdog-Z�hler aktualisieren */
	debugFilter->watchdogCounter %= 15;
	debugFilter->watchdogCounter +=  1;


	/* Update der Momentenberechnung */
	if(!dbclUpdateTorque(&debugFilter->torque,
						  vehicleModel,
						  flexrayOutput,
						  vehicleInput->dynamics.velocity,
						  vehicleInput->road.slope,
						  vehicleInput->powertrain.gear,
						  debugFilter->velocity.resistanceDeviation,
						  controlCYCLETIME,
						 &torque,
						 &acceleration)) {
		success = false;
	}


	/* Update des Geschwindigkeitsfilters */
	if(!dbclVelocityFilter(&debugFilter->velocity,
						    flexrayOutput->DePACC02_Systemstatus == DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt,
							torque >= 0.0f,
							acceleration,
							controlCYCLETIME,
						    vehicleInput->dynamics.velocity)) {
		success = false;
	}


	/* Update der Ausgangsschnittstelle */
	if(!dbclGetOutput(vehicleModel,
					  flexrayOutput,
					  acceleration,
					  torque,
					  debugFilter->watchdogCounter,
					  debugControl)) {
		success = false;
	}


	if(!success) {
		/* Im Fehlerfall wird das Modul komplett zur�ckgesetzt */
		memset(debugFilter, 0, sizeof(*debugFilter));
		memset(debugControl, 0, sizeof(*debugControl));
	}
}
