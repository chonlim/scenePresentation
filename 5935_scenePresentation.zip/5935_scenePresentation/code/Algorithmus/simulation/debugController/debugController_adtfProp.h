#ifndef __debugControlleradtfProp_h_
#define __debugControlleradtfProp_h_

#include <stdio.h>
#include <string.h>
#include "simulation/debugController/debugController_private.h"

/*lint -save */
/*lint -e10 	"Expecting 'String'  -- String is the expected token" */
/*lint -e40 	"Undeclared identifier 'Name'*/
/*lint -e49 	"Expected a type  -- Only types are allowed within prototypes */ 
/*lint -e63 	"Expected an lvalue  -- Assignment expects its first operand to be an lvalue (sprintf) */ 
/*lint -e64 	"Type mismatch (Context) (TypeDiff) (sprintf) */
/*lint -e91 	"Line exceeds Integer characters (use +linebuf) */
/*lint -e119	"Too many arguments for prototype (callback function) */
/*lint -e129	"declaration expected, identifier 'Symbol' ignored (callback function) */
/*lint -e132	"Expected function definition */
/*lint -e402	"static function 'Symbol' (Location) not defined */
/*lint -e409	"Expecting a pointer or array (callback function) */
/*lint -e506	"Constant value Boolean (param Schleifenz�hler = min( 4, MAX_LOOPCNT))*/
/*lint -e516	"arg. type conflict */
/*lint -e522	"Expected void type, assignment, increment or decrement (bool_T)*/
/*lint -e525	"Negative indentation from Location*/
/*lint -e534	"Ignoring return value of function 'Symbol' (sprintf)*/
/*lint -e562	"variable 'Symbol' depends on order of evaluation*/
/*lint -e746	"call to function 'Name' not made in the presence of a prototype */ 
/*lint -e774	"Boolean within 'if' always evaluates to True  */ 
/*lint -e808	"No explicit type given symbol 'Symbol' given, assumed int (char_T) */ 
/*lint -e830	"Location cited in prior message*/
/*lint -e912	"Implicit binary conversion from Type to Type min() */
/*lint -e917	"Prototype coercion (Context) Type to Type*/
/*lint -e918	"Prototype coercion (Context) of pointers*/
/*lint -e960	"Violates MISRA Required Rule Name, String*/

#define MAX_PROPERTY   1024
#define MAX_LOOPCNT    10

#include "simulation/filterTools/comFilterTypes.h"

/*------------------------------Start Get/SetPropertyBool Sektion--------------------------------*/



static bool_T busProp_dbgDelay_bool_T (dbgDelay_T *dbgDelay, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dbgVelocityFilter_bool_T (dbgVelocityFilter_T *dbgVelocityFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dbgTorqueFilter_bool_T (dbgTorqueFilter_T *dbgTorqueFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_debugFilter_bool_T (debugFilter_T *debugFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_debugControl_bool_T (debugControl_T *debugControl, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgDelay_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgDelay_bool_T (dbgDelay_T *dbgDelay, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgDelay_bool_T (dbgDelay_T *dbgDelay, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgVelocityFilter_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgVelocityFilter_bool_T (dbgVelocityFilter_T *dbgVelocityFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgVelocityFilter_bool_T (dbgVelocityFilter_T *dbgVelocityFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "init");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgVelocityFilter->init = (bool_T)(cbFunc(pFilterObject, strProperty, strName, dbgVelocityFilter->init));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgTorqueFilter_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgTorqueFilter_bool_T (dbgTorqueFilter_T *dbgTorqueFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgTorqueFilter_bool_T (dbgTorqueFilter_T *dbgTorqueFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "torqueLowPass::relevant");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgTorqueFilter->torqueLowPass.relevant = (bool_T)(cbFunc(pFilterObject, strProperty, strName, dbgTorqueFilter->torqueLowPass.relevant));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_debugFilter_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_debugFilter_bool_T (debugFilter_T *debugFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_debugFilter_bool_T (debugFilter_T *debugFilter, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_debugControl_bool_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_debugControl_bool_T (debugControl_T *debugControl, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_debugControl_bool_T (debugControl_T *debugControl, bool_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, bool_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "valid");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->valid = (bool_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->valid));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coastRequest");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->coastRequest = (bool_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->coastRequest));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "coastValid");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->coastValid = (bool_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->coastValid));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*------------------------------Ende Get/SetPropertyBool Sektion--------------------------------*/

/*------------------------------Start Get/SetPropertyInt Sektion--------------------------------*/



static bool_T busProp_dbgDelay_int32_T (dbgDelay_T *dbgDelay, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dbgVelocityFilter_int32_T (dbgVelocityFilter_T *dbgVelocityFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dbgTorqueFilter_int32_T (dbgTorqueFilter_T *dbgTorqueFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_debugFilter_int32_T (debugFilter_T *debugFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_debugControl_int32_T (debugControl_T *debugControl, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgDelay_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgDelay_int32_T (dbgDelay_T *dbgDelay, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgDelay_int32_T (dbgDelay_T *dbgDelay, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "index");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgDelay->index = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, dbgDelay->index));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "count");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgDelay->count = (uint16_T)(cbFunc(pFilterObject, strProperty, strName, dbgDelay->count));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgVelocityFilter_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgVelocityFilter_int32_T (dbgVelocityFilter_T *dbgVelocityFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgVelocityFilter_int32_T (dbgVelocityFilter_T *dbgVelocityFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgTorqueFilter_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgTorqueFilter_int32_T (dbgTorqueFilter_T *dbgTorqueFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgTorqueFilter_int32_T (dbgTorqueFilter_T *dbgTorqueFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "state::gear");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgTorqueFilter->state.gear = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, dbgTorqueFilter->state.gear));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_debugFilter_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_debugFilter_int32_T (debugFilter_T *debugFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_debugFilter_int32_T (debugFilter_T *debugFilter, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "watchdogCounter");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugFilter->watchdogCounter = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, debugFilter->watchdogCounter));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_debugControl_int32_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_debugControl_int32_T (debugControl_T *debugControl, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_debugControl_int32_T (debugControl_T *debugControl, int32_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, int32_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "watchdogCounter");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->watchdogCounter = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->watchdogCounter));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gearValid");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->gearValid = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->gearValid));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "gear");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->gear = (uint8_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->gear));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*------------------------------Ende Get/SetPropertyInt Sektion--------------------------------*/

/*------------------------------Start Get/SetPropertyFloat Sektion--------------------------------*/



static bool_T busProp_dbgDelay_real64_T (dbgDelay_T *dbgDelay, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dbgVelocityFilter_real64_T (dbgVelocityFilter_T *dbgVelocityFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_dbgTorqueFilter_real64_T (dbgTorqueFilter_T *dbgTorqueFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_debugFilter_real64_T (debugFilter_T *debugFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );
static bool_T busProp_debugControl_real64_T (debugControl_T *debugControl, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged );


/*! \brief busPropArray_dbgDelaydata_real64_T (real32_T *data, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
*   Schleifenz�hler = min( 25, MAX_LOOPCNT)
*   Funktion iteriert �ber die Variablen im Array */
/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busPropArray_dbgDelaydata_real64_T) */ 
static bool_T busPropArray_dbgDelaydata_real64_T (real32_T *data, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged ){
	bool_T bRet = false;
	uint16_T i;
	for( i = 0; i < min( 25, MAX_LOOPCNT); i++ )
	{
		bool_T bStrExist = false;
		char_T strBaseProperty[MAX_PROPERTY];
		char_T strName[MAX_PROPERTY];
		char_T strProperty[MAX_PROPERTY];
		strProperty[0] = 0; strName[0] = 0;
		if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
		sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
		if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s[%i]", strBaseProperty, i); if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; data[i] = (real32_T)(cbFunc(pFilterObject, strProperty, strName, data[i]));}; strProperty[0] = 0;};
	}
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgDelay_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgDelay_real64_T (dbgDelay_T *dbgDelay, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgDelay_real64_T (dbgDelay_T *dbgDelay, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "data");bRet = busPropArray_dbgDelaydata_real64_T (&dbgDelay->data[0], cbFunc, pFilterObject, strProperty, pstrPropertyChanged);};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgVelocityFilter_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgVelocityFilter_real64_T (dbgVelocityFilter_T *dbgVelocityFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgVelocityFilter_real64_T (dbgVelocityFilter_T *dbgVelocityFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "resistanceDeviation");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgVelocityFilter->resistanceDeviation = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dbgVelocityFilter->resistanceDeviation));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "rawVelocity");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgVelocityFilter->rawVelocity = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dbgVelocityFilter->rawVelocity));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "filteredVelocity");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgVelocityFilter->filteredVelocity = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dbgVelocityFilter->filteredVelocity));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_dbgTorqueFilter_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_dbgTorqueFilter_real64_T (dbgTorqueFilter_T *dbgTorqueFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_dbgTorqueFilter_real64_T (dbgTorqueFilter_T *dbgTorqueFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "state::rampFactor");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgTorqueFilter->state.rampFactor = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dbgTorqueFilter->state.rampFactor));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "state::acceleration");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgTorqueFilter->state.acceleration = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dbgTorqueFilter->state.acceleration));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "state::torque");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; dbgTorqueFilter->state.torque = (real32_T)(cbFunc(pFilterObject, strProperty, strName, dbgTorqueFilter->state.torque));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_debugFilter_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_debugFilter_real64_T (debugFilter_T *debugFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_debugFilter_real64_T (debugFilter_T *debugFilter, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	return bRet;
}


/*lint -esym(715,pstrPropertyChanged) */
/*lint -esym(621,busProp_debugControl_real64_T) */ 
/*lint --e{528} suppress f() not referencedbusProp_debugControl_real64_T (debugControl_T *debugControl, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )) */
static bool_T busProp_debugControl_real64_T (debugControl_T *debugControl, real64_T(cbFunc(const void* pThisPtr, const char_T* strProperty, const char_T* strName, real64_T Value )), const void* pFilterObject, const char_T* pstrBaseProperty, const char_T* pstrPropertyChanged )
{
	bool_T bRet = false;
	bool_T bStrExist = false;
	char_T strBaseProperty[MAX_PROPERTY];
	char_T strName[MAX_PROPERTY];
	char_T strProperty[MAX_PROPERTY];
	strProperty[0] = 0; strName[0] = 0;
	if( strlen(pstrPropertyChanged) > 0 ) { bStrExist = true; };
	if( strstr( pstrPropertyChanged, "IsChanged" ) != 0 ) return true;
	if( pstrBaseProperty ) sprintf_s(strBaseProperty, MAX_PROPERTY, "%s::", pstrBaseProperty);
	else sprintf_s(strBaseProperty, MAX_PROPERTY, "");
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "acceleration");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->acceleration = (real32_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->acceleration));}; strProperty[0] = 0;strName[0] = 0;};
	if ((bRet == false) || (bStrExist == false)) {sprintf_s(strProperty, MAX_PROPERTY, "%s%s", strBaseProperty, "totalTorque");sprintf_s(strName, MAX_PROPERTY, "%s","");if ((bStrExist == false) || (strcmp(strProperty, pstrPropertyChanged) == 0)) { bRet = true; debugControl->totalTorque = (real32_T)(cbFunc(pFilterObject, strProperty, strName, debugControl->totalTorque));}; strProperty[0] = 0;strName[0] = 0;};
	return bRet;
}


/*------------------------------Ende Get/SetPropertyFloat Sektion--------------------------------*/


/*lint -restore */

#endif
