#include "debugController.h"
#include "debugController_private.h"

#include <math.h>

#include "common/vehicleObserverCommon/vehicleObserver_private.h"
#include "common/vehicleModel/vehicleModel.h"
#include "common/vehicleModel/vmdlMap.h"
#include "common/vehicleModel/vehicleModel_private.h"
#include "simulation/filterTools/comFilter.h"

#include "simulation/parameterSet/parameterSetSimu.h"
#include "dbclTorque.h"

#include <BusSignals_enums.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_Unknown)


static void				  dbclGetTransRatio(IN	const	vehicleModel_T			*vehicleModel,
											IN	const	uint8_T					 gear,
											OUT			real32_T				*ratio)
{
	real32_T gearRatio;

	/* Berechnen der Getriebe�bersetzung. Im Segeln wird ersatzweise mit dem h�chsten Gang gerechnet. */
	gearRatio = vehicleModel->gearBox.gear[(gear == gearCoast) ? (vehicleModel->gearBox.numGears - 1) : gear].transmissionRatio;

	/* Berechnen der Gesamt�bersetzung */
	*ratio = gearRatio * vehicleModel->gearBox.iDiff / vehicleModel->gearBox.wheelRadius;
}


static bool_T		dbclGetResistanceTorque(IN	const	vehicleModel_T			*vehicleModel,
											IN	const	real32_T				 slope,
											IN	const	real32_T				 resistanceDeviation,
											IN	const	real32_T				 velocity,
											IN	const	uint8_T					 gear,
											OUT			real32_T				*resistanceTorque,
											OUT			real32_T				*resistanceForce)
{
	real32_T	force;
	real32_T	torque;
	real32_T	ratio;

	diagFF(vmdlGetResistanceForce( vehicleModel,
								   velocity,
								   0.0f,
								   slope,
								   resistanceDeviation,
								  &force));

	dbclGetTransRatio( vehicleModel,
					   gear,
					  &ratio);

	torque = force / ratio;

	*resistanceTorque	= torque;
	*resistanceForce	= force;

	return true;
}


static bool_T			   dbclGetMaxTorque(IN	const	uint8_T					 gear,
											OUT			real32_T				*maxTorque)
{
	real32_T	torque = INVALID_VALUE;

	/* Beim Segeln wird das maximal m�gliche Moment auf 0 begrenzt. */
	if(gear == (uint8_T)gearCoast) {
		torque = min(torque, 0.0f);
	}

	*maxTorque = torque;

	return true;
}


static bool_T	  dbclGetActualAcceleration(IN	const	vehicleModel_T			*vehicleModel,
											IN	const	real32_T				 velocity,
											IN	const	real32_T				 slope,
											IN	const	uint8_T					 gear,
											IN	const	real32_T				 resDeviation,
											IN	const	real32_T				 accelerationRequest,
											IN	const	real32_T				 rampFactor,
											IN	const	real32_T				 maxTorque,
											OUT			real32_T				*accelerationActual)
{
	real32_T	torque;
	real32_T	omega;
	real32_T	resistance;
	real32_T	acceleration;

	diagFF(vmdlGetResistanceForce( vehicleModel,
								   velocity,
								   0.0f,
								   slope,
								   resDeviation,
								  &resistance));

	diagFF(vmdlGetAccelerationTorque( vehicleModel,
									  accelerationRequest,
									  resistance,
									  velocity,
									  gear,
									 &torque,
									 &omega));


	/* Ggf. wird die Anforderung mit dem Ramp Factor "skaliert" */
	torque	*= rampFactor;

	/* Begrenzen des angeforderten Moments auf den momentan m�glichen Bereich */
	torque	 = min(torque, maxTorque);

	diagFF(vmdlGetTorqueAcceleration( vehicleModel,
									  0.0f,
									  slope,
									  velocity,
									  gear,
									  torque,
									  resDeviation,
									 &acceleration));

	*accelerationActual		= acceleration;

	return true;
}


static void					   dbclGetOmega(IN	const	vehicleModel_T			*vehicleModel,
											IN	const	real32_T				 velocity,
											IN	const	uint8_T					 gear,
											OUT			real32_T				*omega)
{
	real32_T ratio;

	dbclGetTransRatio(vehicleModel, gear, &ratio);

	*omega = velocity * ratio;
}


static bool_T			dbclGetThrustTorque(IN	const	vehicleModel_T			*vehicleModel,
											IN	const	real32_T				 velocity,
											IN	const	uint8_T					 gear,
											OUT			real32_T				*torque)
{
	real32_T omega;
	real32_T scaled;

	dbclGetOmega( vehicleModel,
				  velocity,
				  gear,
				 &omega);

	/* Abfragen der Kennlinie */
	diagFF(vmdlMapLineInterp(&vehicleModel->engine.thrustLine.omega,
							  vehicleModel->engine.thrustLine.numOmega,
							  omega,
							  vehicleModel->engine.thrustLine.torque.data,
							 &scaled));

	*torque = vehicleModel->engine.thrustLine.torque.min + (scaled * vehicleModel->engine.thrustLine.torque.factor);


	return true;
}


static bool_T	 dbclGetLimitedAcceleration(IN	const	real32_T				 jerkPositive,
											IN	const	real32_T				 jerkNegative,
											IN	const	real32_T				 lastAcceleration,
											IN	const	real32_T				 targetAcceleration,
											OUT			real32_T				*nextAcceleration)
{
	const parameterSetSimu_T *paramSet = prmGetParameterSetSimu();

	real32_T	acceleration;

	acceleration		= targetAcceleration;

	acceleration		= min(acceleration, lastAcceleration + jerkPositive * controlCYCLETIME);
	acceleration		= max(acceleration, lastAcceleration - jerkNegative * controlCYCLETIME);
	acceleration		= min(acceleration, paramSet->debugController.acceleration.max);
	acceleration		= max(acceleration, paramSet->debugController.acceleration.min);

	*nextAcceleration	= acceleration;

	return true;
}


static bool_T		   dbclGetTorqueRequest(IN	const	vehicleModel_T			*vehicleModel,
											IN	const	real32_T				 resistanceForce,
											IN	const	real32_T				 velocity,
											IN	const	uint8_T					 gear,
											IN	const	real32_T				 accelerationRequest,
											IN	const	real32_T				 maxTorque,
											OUT			real32_T				*torqueRequest)
{
	real32_T	torque;
	real32_T	omega;

	diagFF(vmdlGetAccelerationTorque( vehicleModel,
									  accelerationRequest,
									  resistanceForce,
									  velocity,
									  gear,
									 &torque,
									 &omega));


	/* Begrenzen des angeforderten Moments auf den momentan m�glichen Bereich */
	torque	 = min(torque, maxTorque);

	*torqueRequest = torque;

	return true;
}


static bool_T		  dbclGetFilteredTorque(IN	const	bool_T					 ptSwitch,
											IN	const	real32_T				 unfilteredTorque,
											IN	const	real32_T				 lastTorque,
											IN	const	real32_T				 maxTorque,
											IN	const	real32_T				 deltaTime,
											MEMORY		comFilter_T				*torqueFilter,
											MEMORY		bool_T					*filterRelevant,
											OUT			real32_T				*filteredTorque)
{
	const parameterSetSimu_T *paramSet = prmGetParameterSetSimu();
	real32_T	torque = 0.0f;

	if(ptSwitch) {
		/* Wenn der Filter noch nicht aktiv ist, wird er mit dem letzten geforderten Moment initialisiert */
		if(!*filterRelevant) {
			diagFF(comLowPassInit(torqueFilter, deltaTime, paramSet->debugController.torqueLowPass.cutoffFreq));
			diagFF(comFilterSetMem(torqueFilter, lastTorque));
		}

		*filterRelevant = true;
	}

	if(*filterRelevant) {
		diagFF(comFilterUpdate(torqueFilter, unfilteredTorque, &torque));

		if(fabsf(torque - unfilteredTorque) < paramSet->debugController.torqueLowPass.revertTolerance) {
			*filterRelevant = false;
		}
	}

	if(!*filterRelevant) {
		torque = unfilteredTorque;
	}

	/* Begrenzen des angeforderten Moments auf den momentan m�glichen Bereich */
	torque	 = min(torque, maxTorque);

	*filteredTorque = torque;

	return true;
}


bool_T					   dbclUpdateTorque(MEMORY		dbgTorqueFilter_T		*filter,
											IN	const	vehicleModel_T			*vehicleModel,
											IN	const	flexrayOutput_T			*flexrayOutput,
											IN	const	real32_T				 velocity,
											IN	const	real32_T				 slope,
											IN	const	uint8_T					 gear,
											IN	const	real32_T				 resDeviation,
											IN	const	real32_T				 deltaTime,
											OUT			real32_T				*torque,
											OUT			real32_T				*acceleration)
{
	const parameterSetSimu_T *paramSet = prmGetParameterSetSimu();

	real32_T	resistanceTorque;
	real32_T	resistanceForce;
	real32_T	maxTorque;

	real32_T	maxAcceleration;
	real32_T	minAcceleration;

	real32_T	thrustTorque;
	real32_T	thrustAcceleration;
	real32_T	targetAcceleration;

	real32_T	possibleAcceleration;
	real32_T	limitedAcceleration;

	real32_T	unfilteredTorque;
	bool_T		ptSwitch;

	real32_T	filteredTorque;


	/* Update des rampFactor */
	if(flexrayOutput->DePACC02_Systemstatus == DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt || flexrayOutput->DePACC02_Systemstatus == DeFRInnoDriveOut_DePACC02_Systemstatus_Cx4_PASSIV) {
		filter->state.rampFactor += deltaTime / paramSet->debugController.rampTime;
	}
	else {
		filter->state.rampFactor = 0.0f;
	}

	filter->state.rampFactor = min(filter->state.rampFactor, 1.0f);
	filter->state.rampFactor = max(filter->state.rampFactor, 0.0f);


	/* Was ist das aktuelle umgerechnete Fahrwiderstandmoment? */
	diagFF(dbclGetResistanceTorque( vehicleModel,
								    slope == INVALID_VALUE ? 0.0f: slope,
								    resDeviation,
								    velocity,
								    gear,
								   &resistanceTorque,
								   &resistanceForce));


	/* Berechnen des zul�ssigen Beschleunigungsbands */
	maxAcceleration		= flexrayOutput->DePACC02_Sollbeschleunigung + flexrayOutput->DePACC02_zul_Regelabw_oben;
	minAcceleration		= flexrayOutput->DePACC02_Sollbeschleunigung;


	/* Berechnen der Schub- bzw. Segelbeschleunigung */
	diagFF(dbclGetThrustTorque( vehicleModel,
							    velocity,
							    gear,
							   &thrustTorque));


	diagFF(vmdlGetTorqueAcceleration( vehicleModel,
									  0.0f,
									  slope == INVALID_VALUE ? 0.0f: slope,
									  velocity,
									  gear,
									  thrustTorque,
									  resDeviation,
									 &thrustAcceleration));


	/* Die Zielbeschleunigung ergibt sich aus Nullmomentenbeschleunigung und dem zul�ssigen Toleranzband */
	targetAcceleration	= thrustAcceleration;

	targetAcceleration	= min(targetAcceleration, maxAcceleration);
	targetAcceleration	= max(targetAcceleration, minAcceleration);


	/* Bestimmen des aktuellen Maximalmoments */
	diagFF(dbclGetMaxTorque( gear,
							&maxTorque));


	/* Berechnung der zu erwartenden Beschleunigung basierend auf der angeforderten Sollbeschleunigung. */
	diagFF(dbclGetActualAcceleration( vehicleModel,
									  velocity,
									  slope == INVALID_VALUE ? 0.0f: slope,
									  gear,
									  resDeviation,
									  targetAcceleration,
									  filter->state.rampFactor,
									  maxTorque,
									 &possibleAcceleration));


	/* Ber�cksichtigen der Ruck- und Beschleunigungsgrenzen. */
	diagFF(dbclGetLimitedAcceleration( flexrayOutput->DePACC02_pos_Sollbeschl_Grad,
									   flexrayOutput->DePACC02_neg_Sollbeschl_Grad,
									   filter->state.acceleration,
									   possibleAcceleration,
									  &limitedAcceleration));


	/* Berechnen der tats�chlichen Momentenanforderung */
	diagFF(dbclGetTorqueRequest( vehicleModel,
								 resistanceForce,
								 velocity,
								 gear,
								 limitedAcceleration,
								 maxTorque,
								&unfilteredTorque));


	/* Hat sich im Triebstrang seit dem letzten Zeitschritt etwas dramatisch ge�ndert? */
	ptSwitch = (gear != filter->state.gear) ? true : false;


	/* Berechnen der gefilterten Momentenanforderung */
	diagFF(dbclGetFilteredTorque( ptSwitch,
								  unfilteredTorque,
								  filter->state.torque,
								  maxTorque,
								  deltaTime,
								 &filter->torqueLowPass.filter,
								 &filter->torqueLowPass.relevant,
								 &filteredTorque));


	/* Update des Filterzustands */
	filter->state.acceleration	= limitedAcceleration;
	filter->state.torque		= filteredTorque;
	filter->state.gear			= gear;


	*torque			= filteredTorque;
 	*acceleration	= limitedAcceleration;

	return true;

}



