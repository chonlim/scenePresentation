#ifndef guard_dbclVelocity_h
#define guard_dbclVelocity_h


#ifdef __cplusplus
extern "C" {
#endif


	bool_T		 dbclVelocityFilter(MEMORY		dbgVelocityFilter_T		*filter,				/**< interner Zustand des Geschwindigkeitsfilters */
									IN	const	bool_T					 active,				/**< Ist die Regelung aktiv? */
									IN	const	bool_T					 relevant,				/**< Ist die Beschleunigungsanforderung relevant f�r die Fehlersch�tzung? */
									IN	const	real32_T				 acceleration,			/**< von der Regelung geforderte L�ngsbeschleunigung */
									IN	const	real32_T				 deltaTime,				/**< Zeit seit letzter Ausf�hrung */
									IN	const	real32_T				 unfilteredVelocity		/**< Rohwert Geschwindigkeit */
									);


#ifdef __cplusplus
}
#endif

#endif
