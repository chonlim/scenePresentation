#ifndef guard_dbclOutput_h
#define guard_dbclOutput_h


#ifdef __cplusplus
extern "C" {
#endif


	bool_T			  dbclGetOutput(IN	const	vehicleModel_T		*vehicleModel,
									IN	const	flexrayOutput_T		*flexrayOutput,
									IN	const	real32_T			 acceleration,
									IN	const	real32_T			 torque,
									IN	const	uint8_T				 watchdogCounter,
									OUT			debugControl_T		*debugControl
									);


#ifdef __cplusplus
}
#endif


#endif
