#include "debugController.h"
#include "debugController_private.h"

#include "dbclOutput.h"
#include "common/vehicleModel/vehicleModel.h"
#include "common/vehicleModel/vehicleModel_private.h"

#include <BusSignals_enums.h>

#include "common/platformInterface/pltfDiag.h"
diagDeclareModule(diagModule_Unknown)


static bool_T		   dbclGetGearFromRatio(IN	const	vehicleModel_T		*vehicleModel,
											IN	const	real32_T			 transRatio,
											OUT			uint8_T				*gear)
{
	bool_T	found = false;
	uint8_T	index;

	diagFF(vehicleModel->valid);
	diagFF(vehicleModel->gearBox.numGears > 0);

	for(index = 0; index < vehicleModel->gearBox.numGears; index++) {
		if(transRatio == vehicleModel->gearBox.gear[index].transmissionRatio) {
			found = true;
			*gear = index;
		}
	}

	diagFF(found);


	return true;
}


bool_T			  dbclGetOutput(IN	const	vehicleModel_T		*vehicleModel,
								IN	const	flexrayOutput_T		*flexrayOutput,
								IN	const	real32_T			 acceleration,
								IN	const	real32_T			 torque,
								IN	const	uint8_T				 watchdogCounter,
								OUT			debugControl_T		*debugControl)
{
	uint8_T	gear;

	/* Aus der Wunsch�bersetzung einen Gang zur�ckrechnen */
	if(flexrayOutput->DePACC02_Wunschuebersetzung > DeFRInnoDriveOut_DePACC02_Wunschuebersetzung_DEFAULT) {
		diagFF(dbclGetGearFromRatio( vehicleModel,
									 flexrayOutput->DePACC02_Wunschuebersetzung,
									&gear));
	}
	else {
		gear = 0;
	}


	/* Sollbeschleunigung und -moment */
	debugControl->valid				= (flexrayOutput->DePACC02_Systemstatus == DeFRInnoDriveOut_DePACC02_Systemstatus_Cx3_AKTIV_regelt) || (flexrayOutput->DePACC02_Systemstatus == DeFRInnoDriveOut_DePACC02_Systemstatus_Cx4_PASSIV);
	debugControl->acceleration		= acceleration;
	debugControl->totalTorque		= torque;


	/* Segelanforderung */
	debugControl->coastValid		= (flexrayOutput->DePACC02_Ausrollmanoever == DeFRInnoDriveOut_DePACC02_Ausrollmanoever_Cx1_Segelbetrieb_gewuenscht) || (flexrayOutput->DePACC02_Ausrollmanoever == DeFRInnoDriveOut_DePACC02_Ausrollmanoever_Cx2_Schubbetrieb_gewuenscht);
	debugControl->coastRequest		= (flexrayOutput->DePACC02_Ausrollmanoever == DeFRInnoDriveOut_DePACC02_Ausrollmanoever_Cx1_Segelbetrieb_gewuenscht);


	/* Ganganforderung */
	debugControl->gearValid			= (flexrayOutput->DePACC02_Wunschuebersetzung > DeFRInnoDriveOut_DePACC02_Wunschuebersetzung_DEFAULT);
	debugControl->gear				= gear;


	/* Watchdog */
	debugControl->watchdogCounter	= watchdogCounter;


	return true;
}
