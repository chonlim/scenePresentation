/*** Module Rte_CtApInnoDriveControl, written by TTX-                      ***/
/*** Mwcodegenerator/Contract_Header.py (Version 0.14.2, 04-May-2017) on   ***/
/*** Mon 16-Jul-2018 16:06:55                                              ***/
/*** IFSet version: 3.1.1                                                  ***/
/* PRQA S 0602 4                                                             */

/** \file Rte_CtApInnoDriveControl.h */

/* double include prevention */
#ifndef _RTE_CTAPINNODRIVECONTROL_H
# define _RTE_CTAPINNODRIVECONTROL_H

#ifndef RTE_CORE
# ifdef RTE_APPLICATION_HEADER_FILE
#     error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
#endif /* ifndef RTE_CORE */

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_Type.h"



/* PRQA S 0602, 0777, 0779, 0639, 4901 EOF                                   */
/*   0602: Allow TTTech-python-C-libs and CGL; usage of names starting with  */
/* _.                                                                        */
/*   0639: number of members in struct: supported by used compilers,         */
/* unacceptable increase in complexity if split.                             */
/*   0777/0779: Allow usage of names from model longer than 31 chars.        */

/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

#ifndef RTE_CORE
  # define Rte_InitValue_PpDiagCoding_DePermitCodingPersistence (0U)
  # define Rte_InitValue_PpFRRGout_DePduGrp_SDF2_Pos_01 (FALSE)
  # define Rte_InitValue_PpPFHwMeasurements_DeTHS (0U)
  # define Rte_InitValue_PpPFProvidedData_DeCurConsecutiveSysRestartCnt (65535U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSAPHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSMVHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSSRHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSSSHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSSystemState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeTotalSysRestartCnt (4294967295U)
  # define Rte_InitValue_PpPFProvidedData_DeVARHWVariant (0U)
  # define Rte_InitValue_PpRGLVZE_DePduGrp_BVTS_xx (FALSE)
  # define Rte_InitValue_PpRGLVZE_DePduGrp_VZE_01 (FALSE)
  # define Rte_InitValue_PpRGLVZE_DePduGrp_VZE_02 (FALSE)
  # define Rte_InitValue_PpRGLVZE_DePduGrp_VZE_03 (FALSE)
  # define Rte_InitValue_PpRGLVZE_DePduGrp_VZE_05 (FALSE)
  # define Rte_InitValue_PpFRInnoDriveOut_DePduGrp_PACC02_01 (FALSE)
  # define Rte_InitValue_PpFRInnoDriveOut_DePduGrp_PACC02_02 (FALSE)
  # define Rte_InitValue_PpFRInnoDriveOut_DePduGrp_PACC02_03 (FALSE)
  # define Rte_InitValue_PpFRInnoDriveOut_DePduGrp_PIF_01 (FALSE)
#endif /* ifndef RTE_CORE */



# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
/** \brief get one entry from a queued RTE buffer
 *
 * \param data receive buffer for element 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Receive_CtApInnoDriveControl_PpDiagGlobalRead_DeFSPCleared] {1247796}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Receive_CtApInnoDriveControl_PpDiagGlobalRead_DeFSPCleared (P2VAR(Dt_BOOL, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief get one entry from a queued RTE buffer
 *
 * \param data receive buffer for element 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Receive_CtApInnoDriveControl_PpEML_DeEML] {1247796}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Receive_CtApInnoDriveControl_PpEML_DeEML (P2VAR(Dt_RECORD_EML, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveControl_PpDiagCoding_DeCoding] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveControl_PpDiagCoding_DeCoding (P2VAR(Dt_RECORD_Diag_Coding, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveControl_PpDiagCoding_DeCoding] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveControl_PpDiagCoding_DeCoding (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveControl_PpDiagCoding_DePermitCodingPersistence] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveControl_PpDiagCoding_DePermitCodingPersistence (P2VAR(Dt_ENUM_PermitCodingPersistence, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveControl_PpDiagCoding_DePermitCodingPersistence] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveControl_PpDiagCoding_DePermitCodingPersistence (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA (P2VAR(Dt_RECORD_Anpassung_Deactivate_hardware_in_the_loop_mode_0x0BEA, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 (P2VAR(Dt_RECORD_Anpassung_Platform_zFAS_hil_mode_0x0500, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB (P2VAR(Dt_RECORD_Anpassung_Roller_Test_Stand_Mode_0x04FB, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_InnoDriveControlParameterSetCtrl,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_InnoDriveControlVehicleModel,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_InnoDriveStrategyParameterSetStgy,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpFoDFunctionActivationState_DeFoDFunctionActivationState] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_FoDFunctionActivationState,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpFoDFunctionActivationState_DeFoDFunctionActivationState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpFoDFunctionActivationState_DeFoDFunctionActivationState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpFoDFunctionActivationState_DeFoDFunctionActivationState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpFRInnoDriveIn_DeFRInnoDriveIn] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_FRInnoDriveIn,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpFRInnoDriveIn_DeFRInnoDriveIn (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpFRInnoDriveIn_DeFRInnoDriveIn] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpFRInnoDriveIn_DeFRInnoDriveIn (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpFRRGout_DeFRRGout] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_FRRGout,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpFRRGout_DeFRRGout (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpFRRGout_DeFRRGout] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpFRRGout_DeFRRGout (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpFRRGout_DePduGrp_SDF2_Pos_01] {1357185}
 **/
extern FUNC(Dt_BOOL_PduGroup, RTE_CODE) Rte_IRead_RInnoDriveControl_PpFRRGout_DePduGrp_SDF2_Pos_01 (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpFRRGout_DePduGrp_SDF2_Pos_01] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpFRRGout_DePduGrp_SDF2_Pos_01 (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpFRRGout_DeTraceData] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_TraceData,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpFRRGout_DeTraceData (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpFRRGout_DeTraceData] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpFRRGout_DeTraceData (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpOBFLightOutObjects_DeObjectListOBFLightOut] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_ObjectListOBFLightOut,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpOBFLightOutObjects_DeObjectListOBFLightOut (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpOBFLightOutObjects_DeObjectListOBFLightOut] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpOBFLightOutObjects_DeObjectListOBFLightOut (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPemPlanning_DePemPlanning] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_PemPlanning,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPemPlanning_DePemPlanning (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPemPlanning_DePemPlanning] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPemPlanning_DePemPlanning (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFHwMeasurements_DeTHS] {1357185}
 **/
extern FUNC(Dt_ENUM_ThermalHealthStatus, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFHwMeasurements_DeTHS (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFHwMeasurements_DeTHS] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFHwMeasurements_DeTHS (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFHwMeasurements_DeVBAT_MAIN] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_VBatMain,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFHwMeasurements_DeVBAT_MAIN (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFHwMeasurements_DeVBAT_MAIN] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFHwMeasurements_DeVBAT_MAIN (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeCurConsecutiveSysRestartCnt] {1357185}
 **/
extern FUNC(Dt_UINT16_1_0, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeCurConsecutiveSysRestartCnt (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeCurConsecutiveSysRestartCnt] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeCurConsecutiveSysRestartCnt (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeIFSETVersion] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_SWC_VersionIFSET,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeIFSETVersion (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeIFSETVersion] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeIFSETVersion (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSAPHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSAPHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSAPHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSAPHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSMVHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSMVHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSMVHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSMVHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSSRHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSSRHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSSRHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSSRHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSSSHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSSSHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSSSHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSSSHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSSystemState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeLCSSystemState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSSystemState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeLCSSystemState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeTotalSysRestartCnt] {1357185}
 **/
extern FUNC(Dt_UINT32_1_0, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeTotalSysRestartCnt (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeTotalSysRestartCnt] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeTotalSysRestartCnt (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeVARHWVariant] {1357185}
 **/
extern FUNC(Dt_ENUM_VAR_HWVariant, RTE_CODE) Rte_IRead_RInnoDriveControl_PpPFProvidedData_DeVARHWVariant (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeVARHWVariant] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpPFProvidedData_DeVARHWVariant (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGExtPSD_DeRGExtPSD] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_RGExtractorPSD,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGExtPSD_DeRGExtPSD (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGExtPSD_DeRGExtPSD] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGExtPSD_DeRGExtPSD (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLanes_DeLanes] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_GeometryLanes,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLanes_DeLanes (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLanes_DeLanes] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLanes_DeLanes (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DeBVTS] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_BVTS,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DeBVTS (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DeBVTS] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DeBVTS (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_BVTS_xx] {1357185}
 **/
extern FUNC(Dt_BOOL_PduGroup, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_BVTS_xx (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_BVTS_xx] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_BVTS_xx (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_01] {1357185}
 **/
extern FUNC(Dt_BOOL_PduGroup, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_01 (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_01] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_01 (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_02] {1357185}
 **/
extern FUNC(Dt_BOOL_PduGroup, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_02 (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_02] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_02 (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_03] {1357185}
 **/
extern FUNC(Dt_BOOL_PduGroup, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_03 (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_03] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_03 (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_05] {1357185}
 **/
extern FUNC(Dt_BOOL_PduGroup, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_05 (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_05] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DePduGrp_VZE_05 (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DeTraceData] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_TraceData,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DeTraceData (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DeTraceData] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DeTraceData (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveControl_PpRGLVZE_DeVZE] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_VZE,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveControl_PpRGLVZE_DeVZE (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveControl_PpRGLVZE_DeVZE] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveControl_PpRGLVZE_DeVZE (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Write_CtApInnoDriveControl_PpDiagInnoDriveControlWrite_DeMesswerte_InnoDriveControl] {1246332}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CtApInnoDriveControl_PpDiagInnoDriveControlWrite_DeMesswerte_InnoDriveControl (P2CONST(Dt_RECORD_Messwert_InnoDriveControl, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) data);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFoDReadyToRun_InnoDrive2_DeFoDReadyToRun_InnoDrive2] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFoDReadyToRun_InnoDrive2_DeFoDReadyToRun_InnoDrive2 (P2CONST(Dt_RECORD_FoDReadyToRun, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFoDReadyToRun_InnoDrive2_DeFoDReadyToRun_InnoDrive2] {1246847}
 **/
extern FUNC_P2VAR(Dt_RECORD_FoDReadyToRun,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFoDReadyToRun_InnoDrive2_DeFoDReadyToRun_InnoDrive2 (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DeFRInnoDriveOut] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DeFRInnoDriveOut (P2CONST(Dt_RECORD_FRInnoDriveOut, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DeFRInnoDriveOut] {1246847}
 **/
extern FUNC_P2VAR(Dt_RECORD_FRInnoDriveOut,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DeFRInnoDriveOut (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_01] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_01 (Dt_BOOL_PduGroup data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_01] {1246847}
 **/
extern FUNC_P2VAR(Dt_BOOL_PduGroup,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_01 (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_02] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_02 (Dt_BOOL_PduGroup data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_02] {1246847}
 **/
extern FUNC_P2VAR(Dt_BOOL_PduGroup,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_02 (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_03] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_03 (Dt_BOOL_PduGroup data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_03] {1246847}
 **/
extern FUNC_P2VAR(Dt_BOOL_PduGroup,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PACC02_03 (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PIF_01] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PIF_01 (Dt_BOOL_PduGroup data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PIF_01] {1246847}
 **/
extern FUNC_P2VAR(Dt_BOOL_PduGroup,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DePduGrp_PIF_01 (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DeTraceData] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpFRInnoDriveOut_DeTraceData (P2CONST(Dt_RECORD_TraceData, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DeTraceData] {1246847}
 **/
extern FUNC_P2VAR(Dt_RECORD_TraceData,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpFRInnoDriveOut_DeTraceData (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveControl_PpPemControl_DePemControl] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveControl_PpPemControl_DePemControl (P2CONST(Dt_RECORD_PemControl, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveControl_PpPemControl_DePemControl] {1246847}
 **/
extern FUNC_P2VAR(Dt_RECORD_PemControl,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveControl_PpPemControl_DePemControl (void);
/** \brief call the runnable GetEventStatus
 *
 * \param EventId
 * \param EventStatusExtended
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpEventHandling_GetEventStatus( Dem_EventIdType EventId, P2VAR(Dem_EventStatusExtendedType, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) EventStatusExtended);
/** \brief call the runnable SetEventStatus
 *
 * \param EventId
 * \param EventStatus
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpEventHandling_SetEventStatus( Dem_EventIdType EventId, Dem_EventStatusType EventStatus);
/** \brief call the runnable MW_SetSwcInfo
 *
 * \param swc_id
 * \param swc_info
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpPFServer_MW_SetSwcInfo( Dt_ENUM_SWCID swc_id, P2CONST(Dt_RECORD_SWC_Identification, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) swc_info);
/** \brief call the runnable TS_ConvertAgt2Zgt
 *
 * \param agtTimestamp
 * \param zgtTimestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpPFServer_TS_ConvertAgt2Zgt( P2CONST(Dt_RECORD_TimestampAGT, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) agtTimestamp, P2VAR(Dt_RECORD_Timestamp, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) zgtTimestamp);
/** \brief call the runnable TS_ConvertZgt2Agt
 *
 * \param zgtTimestamp
 * \param agtTimestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpPFServer_TS_ConvertZgt2Agt( P2CONST(Dt_RECORD_Timestamp, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) zgtTimestamp, P2VAR(Dt_RECORD_TimestampAGT, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) agtTimestamp);
/** \brief call the runnable TS_GetAgtTimestamp
 *
 * \param agtTimestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpPFServer_TS_GetAgtTimestamp (P2VAR(Dt_RECORD_TimestampAGT, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) agtTimestamp);
/** \brief call the runnable TS_GetRemainingTimeBudget
 *
 * \param RemainingTimeBudget
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpPFServer_TS_GetRemainingTimeBudget (P2VAR(Dt_SINT32_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) RemainingTimeBudget);
/** \brief call the runnable TS_GetZgtTimestamp
 *
 * \param Timestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpPFServer_TS_GetZgtTimestamp (P2VAR(Dt_RECORD_Timestamp, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) Timestamp);
/** \brief call the runnable RGApi_GetAttribute
 *
 * \param errorCode
 * \param type
 * \param segmentId
 * \param offsetStart
 * \param searchDistance
 * \param searchDirection
 * \param resultAttribute
 * \param itAttribute
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetAttribute( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 type, Dt_UINT8_1_0 segmentId, Dt_UINT16_1_0 offsetStart, Dt_UINT32_1_0 searchDistance, Dt_UINT8_1_0 searchDirection, P2VAR(Dt_RECORD_RGResultAttribute, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) resultAttribute, P2VAR(Dt_RECORD_RGAttributeIterator, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) itAttribute);
/** \brief call the runnable RGApi_GetAttributeData
 *
 * \param errorCode
 * \param attributeIndex
 * \param attribute
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetAttributeData( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT16_1_0 attributeIndex, P2VAR(Dt_RECORD_RGAttribute, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) attribute);
/** \brief call the runnable RGApi_GetChildrenCount
 *
 * \param errorCode
 * \param id
 * \param childrenCount
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetChildrenCount( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 id, P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) childrenCount);
/** \brief call the runnable RGApi_GetChildSegment
 *
 * \param errorCode
 * \param segmentId
 * \param searchDirection
 * \param resultSegment
 * \param itSegment
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetChildSegment( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 segmentId, Dt_UINT8_1_0 searchDirection, P2VAR(Dt_RECORD_RGSegment, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) resultSegment, P2VAR(Dt_RECORD_RGSegmentIterator, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) itSegment);
/** \brief call the runnable RGApi_GetCurrentTimestamp
 *
 * \param errorCode
 * \param timestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetCurrentTimestamp( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT32_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) timestamp);
/** \brief call the runnable RGApi_GetGpsData
 *
 * \param errorCode
 * \param gpsPosition
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetGpsData( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGGpsPosition, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) gpsPosition);
/** \brief call the runnable RGApi_GetLoadAttributePool
 *
 * \param errorCode
 * \param load
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetLoadAttributePool( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) load);
/** \brief call the runnable RGApi_GetLoadSegments
 *
 * \param errorCode
 * \param load
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetLoadSegments( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) load);
/** \brief call the runnable RGApi_GetLoadSpeedLimitPool
 *
 * \param errorCode
 * \param load
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetLoadSpeedLimitPool( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) load);
/** \brief call the runnable RGApi_GetModuleVersion
 *
 * \param errorCode
 * \param moduleVersion
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetModuleVersion( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGVersion, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) moduleVersion);
/** \brief call the runnable RGApi_GetNearestAttributes
 *
 * \param errorCode
 * \param type
 * \param segmentId
 * \param offsetStart
 * \param searchDistance
 * \param resultOrder
 * \param maxResults
 * \param results
 * \param foundAttributes
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNearestAttributes( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 type, Dt_UINT8_1_0 segmentId, Dt_UINT16_1_0 offsetStart, Dt_UINT32_1_0 searchDistance, Dt_UINT8_1_0 resultOrder, Dt_UINT16_1_0 maxResults, P2VAR(Dt_RECORD_RGResultAttribute, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) results, P2VAR(Dt_UINT16_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) foundAttributes);
/** \brief call the runnable RGApi_GetNextAttribute
 *
 * \param errorCode
 * \param resultAttribute
 * \param itAttribute
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNextAttribute( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGResultAttribute, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) resultAttribute, P2CONST(Dt_RECORD_RGAttributeIterator, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) itAttribute);
/** \brief call the runnable RGApi_GetNextSibling
 *
 * \param errorCode
 * \param resultSegment
 * \param itSegment
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNextSibling( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGSegment, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) resultSegment, P2VAR(Dt_RECORD_RGSegmentIterator, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) itSegment);
/** \brief call the runnable RGApi_GetNextSpeedLimit
 *
 * \param errorCode
 * \param resultSpeedLimit
 * \param itSpeedLimit
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNextSpeedLimit( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGResultSpeedLimit, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) resultSpeedLimit, P2VAR(Dt_RECORD_RGSpeedLimitIterator, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) itSpeedLimit);
/** \brief call the runnable RGApi_GetPositionData
 *
 * \param errorCode
 * \param position
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetPositionData( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGPosition, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) position);
/** \brief call the runnable RGApi_GetQuality
 *
 * \param errorCode
 * \param ehrStatus
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetQuality( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) ehrStatus);
/** \brief call the runnable RGApi_GetRootSegment
 *
 * \param errorCode
 * \param idRoot
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootSegment( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) idRoot);
/** \brief call the runnable RGApi_GetRootTreeStateAttributeValue
 *
 * \param errorCode
 * \param type
 * \param value
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootTreeStateAttributeValue( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 type, P2VAR(Dt_UINT16_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) value);
/** \brief call the runnable RGApi_GetRootTreeStateSpeedLimitIndex
 *
 * \param errorCode
 * \param scope
 * \param origin
 * \param speedLimitIndex
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootTreeStateSpeedLimitIndex( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 scope, Dt_UINT8_1_0 origin, P2VAR(Dt_UINT16_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) speedLimitIndex);
/** \brief call the runnable RGApi_GetSegmentData
 *
 * \param errorCode
 * \param id
 * \param segment
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSegmentData( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 id, P2VAR(Dt_RECORD_RGSegment, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) segment);
/** \brief call the runnable RGApi_GetSpeedLimit
 *
 * \param errorCode
 * \param scope
 * \param origin
 * \param unit
 * \param segmentId
 * \param offsetStart
 * \param searchDistance
 * \param searchDirection
 * \param resultSpeedLimit
 * \param itSpeedLimit
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSpeedLimit( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT8_1_0 scope, Dt_UINT8_1_0 origin, Dt_UINT8_1_0 unit, Dt_UINT8_1_0 segmentId, Dt_UINT16_1_0 offsetStart, Dt_UINT32_1_0 searchDistance, Dt_UINT8_1_0 searchDirection, P2VAR(Dt_RECORD_RGResultSpeedLimit, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) resultSpeedLimit, P2VAR(Dt_RECORD_RGSpeedLimitIterator, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) itSpeedLimit);
/** \brief call the runnable RGApi_GetSpeedLimitData
 *
 * \param errorCode
 * \param speedLimitIndex
 * \param currentUnit
 * \param requestedUnit
 * \param speedLimit
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSpeedLimitData( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, Dt_UINT16_1_0 speedLimitIndex, Dt_UINT8_1_0 currentUnit, Dt_UINT8_1_0 requestedUnit, P2VAR(Dt_RECORD_RGSpeedLimit, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) speedLimit);
/** \brief call the runnable RGApi_GetSystemData
 *
 * \param errorCode
 * \param systemData
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSystemData( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGSystemData, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) systemData);
/** \brief call the runnable RGApi_GetTreeChangeCount
 *
 * \param errorCode
 * \param changeCount
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetTreeChangeCount( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_UINT16_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) changeCount);
/** \brief call the runnable RGApi_GetTreeConfiguration
 *
 * \param errorCode
 * \param treeConfiguration
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetTreeConfiguration( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2VAR(Dt_RECORD_RGTreeConfiguration, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) treeConfiguration);
/** \brief call the runnable RGApi_Query
 *
 * \param errorCode
 * \param query
 * \param queryResult
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_Query( P2VAR(Dt_UINT8_1_0, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) errorCode, P2CONST(Dt_RECORD_RGQuery, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_DATA) query, P2VAR(Dt_RECORD_RGQuery, AUTOMATIC, RTE_CTAPINNODRIVECONTROL_APPL_VAR) queryResult);


# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_IRead_<r>_<p>_<d>
 * Rte_IStatus_<r>_<p>_<d>
 * Rte_IWrite_<r>_<p>_<d>
 * Rte_IWriteRef_<r>_<p>_<d>
 * Rte_IInvalidate_<r>_<p>_<d>
 *********************************************************************************************************************/

#ifndef RTE_CORE 

/**********************************************************************************************************************
 * Rte_Receive_<p>_<d> (explicit S/R communication with isQueued = true)
 *********************************************************************************************************************/
# define Rte_Receive_PpDiagGlobalRead_DeFSPCleared Rte_Receive_CtApInnoDriveControl_PpDiagGlobalRead_DeFSPCleared
# define Rte_Receive_PpEML_DeEML Rte_Receive_CtApInnoDriveControl_PpEML_DeEML




/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_PpDiagCoding_DeCoding Rte_Read_CtApInnoDriveControl_PpDiagCoding_DeCoding
# define Rte_Read_PpDiagCoding_DePermitCodingPersistence Rte_Read_CtApInnoDriveControl_PpDiagCoding_DePermitCodingPersistence
# define Rte_Read_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA
# define Rte_Read_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500
# define Rte_Read_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB Rte_Read_CtApInnoDriveControl_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB


/**********************************************************************************************************************
 * Rte_IsUpdated_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_IsUpdated_PpDiagCoding_DeCoding Rte_IsUpdated_CtApInnoDriveControl_PpDiagCoding_DeCoding
# define Rte_IsUpdated_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA
# define Rte_IsUpdated_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500
# define Rte_IsUpdated_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB Rte_IsUpdated_CtApInnoDriveControl_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB
# define Rte_IsUpdated_PpRGLanes_DeLanes Rte_IsUpdated_CtApInnoDriveControl_PpRGLanes_DeLanes


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PpDiagInnoDriveControlWrite_DeMesswerte_InnoDriveControl Rte_Write_CtApInnoDriveControl_PpDiagInnoDriveControlWrite_DeMesswerte_InnoDriveControl


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/

# define Rte_Call_PpEventHandling_GetEventStatus Rte_Call_CtApInnoDriveControl_PpEventHandling_GetEventStatus
# define Rte_Call_PpEventHandling_SetEventStatus Rte_Call_CtApInnoDriveControl_PpEventHandling_SetEventStatus
# define Rte_Call_PpPFServer_MW_SetSwcInfo Rte_Call_CtApInnoDriveControl_PpPFServer_MW_SetSwcInfo
# define Rte_Call_PpPFServer_TS_ConvertAgt2Zgt Rte_Call_CtApInnoDriveControl_PpPFServer_TS_ConvertAgt2Zgt
# define Rte_Call_PpPFServer_TS_ConvertZgt2Agt Rte_Call_CtApInnoDriveControl_PpPFServer_TS_ConvertZgt2Agt
# define Rte_Call_PpPFServer_TS_GetAgtTimestamp Rte_Call_CtApInnoDriveControl_PpPFServer_TS_GetAgtTimestamp
# define Rte_Call_PpPFServer_TS_GetRemainingTimeBudget Rte_Call_CtApInnoDriveControl_PpPFServer_TS_GetRemainingTimeBudget
# define Rte_Call_PpPFServer_TS_GetZgtTimestamp Rte_Call_CtApInnoDriveControl_PpPFServer_TS_GetZgtTimestamp
# define Rte_Call_PpRGApiLight_RGApi_GetAttribute Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetAttribute
# define Rte_Call_PpRGApiLight_RGApi_GetAttributeData Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetAttributeData
# define Rte_Call_PpRGApiLight_RGApi_GetChildSegment Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetChildSegment
# define Rte_Call_PpRGApiLight_RGApi_GetChildrenCount Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetChildrenCount
# define Rte_Call_PpRGApiLight_RGApi_GetCurrentTimestamp Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetCurrentTimestamp
# define Rte_Call_PpRGApiLight_RGApi_GetGpsData Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetGpsData
# define Rte_Call_PpRGApiLight_RGApi_GetLoadAttributePool Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetLoadAttributePool
# define Rte_Call_PpRGApiLight_RGApi_GetLoadSegments Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetLoadSegments
# define Rte_Call_PpRGApiLight_RGApi_GetLoadSpeedLimitPool Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetLoadSpeedLimitPool
# define Rte_Call_PpRGApiLight_RGApi_GetModuleVersion Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetModuleVersion
# define Rte_Call_PpRGApiLight_RGApi_GetNearestAttributes Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNearestAttributes
# define Rte_Call_PpRGApiLight_RGApi_GetNextAttribute Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNextAttribute
# define Rte_Call_PpRGApiLight_RGApi_GetNextSibling Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNextSibling
# define Rte_Call_PpRGApiLight_RGApi_GetNextSpeedLimit Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetNextSpeedLimit
# define Rte_Call_PpRGApiLight_RGApi_GetPositionData Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetPositionData
# define Rte_Call_PpRGApiLight_RGApi_GetQuality Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetQuality
# define Rte_Call_PpRGApiLight_RGApi_GetRootSegment Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootSegment
# define Rte_Call_PpRGApiLight_RGApi_GetRootTreeStateAttributeValue Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootTreeStateAttributeValue
# define Rte_Call_PpRGApiLight_RGApi_GetRootTreeStateSpeedLimitIndex Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetRootTreeStateSpeedLimitIndex
# define Rte_Call_PpRGApiLight_RGApi_GetSegmentData Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSegmentData
# define Rte_Call_PpRGApiLight_RGApi_GetSpeedLimit Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSpeedLimit
# define Rte_Call_PpRGApiLight_RGApi_GetSpeedLimitData Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSpeedLimitData
# define Rte_Call_PpRGApiLight_RGApi_GetSystemData Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetSystemData
# define Rte_Call_PpRGApiLight_RGApi_GetTreeChangeCount Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetTreeChangeCount
# define Rte_Call_PpRGApiLight_RGApi_GetTreeConfiguration Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_GetTreeConfiguration
# define Rte_Call_PpRGApiLight_RGApi_Query Rte_Call_CtApInnoDriveControl_PpRGApiLight_RGApi_Query



#endif /* #ifndef RTE_CORE */ 



# define RTE_START_SEC_CTAPINNODRIVECONTROL_APPL_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: RInnoDriveControl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_RInnoDriveControl RInnoDriveControl
/** \brief Runnable entity: RInnoDriveControl,
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 * \param void
 * \return void
 **/
extern FUNC(void, RTE_CTAPINNODRIVECONTROL_APPL_CODE) RInnoDriveControl(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: RInnoDriveControlInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_RInnoDriveControlInit RInnoDriveControlInit
/** \brief Runnable entity: RInnoDriveControlInit,
 * Executed once after the RTE is started
 * \param void
 * \return void
 **/
extern FUNC(void, RTE_CTAPINNODRIVECONTROL_APPL_CODE) RInnoDriveControlInit(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CTAPINNODRIVECONTROL_APPL_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

#ifndef RTE_CORE
  # define RTE_E_PiPFServer_MW_E_TIMESTAMP (16U)
#endif /* ifndef RTE_CORE */

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

/* begin Fileversion check */
#ifndef RTE_CORE
# ifndef SKIP_MAGIC_NUMBER
#  ifdef RTE_MAGIC_NUMBER
#   if RTE_MAGIC_NUMBER != 1531732217
#    error "The magic number is different. Please check time and date of the generated RTE files!"
#   endif
#  else
#   define RTE_MAGIC_NUMBER 1531732217
#  endif  /* RTE_MAGIC_NUMBER */
# endif  /* SKIP_MAGIC_NUMBER */
#endif /* ifndef RTE_CORE */
/* end Fileversion check */

#endif /* _RTE_CTAPINNODRIVECONTROL_H */
