#ifndef SWCMUTEX_H
#define SWCMUTEX_H

#include "Std_Types.h"

/* ------------------------------------------------------------------------- */
/* ------------------------------ Data Types ------------------------------- */
/* ------------------------------------------------------------------------- */
/** \typedef e_swcmutex_return_type
 *  \brief Return type for the Mutex functions.
 *  \decomposed_from[e_swcmutex_return_type] {1847134}
 */
typedef enum {
    SWCMUTEX_OK = 0x00u, /**< Function finished successfully */
    SWCMUTEX_NOK_LOCKED = 0x01u,    /**< Mutex object cannot be obtained:
                                      at least one mutex variable already locked */
    SWCMUTEX_NOK_UNLOCKED = 0x02u,  /**< Mutex object cannot be released:
                                      at least one mutex variable not locked */
    SWCMUTEX_NOK_INVALID_ID = 0x03u /**< Invalid mutex object ID */
} e_swcmutex_return_type;

/** \typedef t_swcmutex_object_id_type
 *  \brief Mutex object identification type - each mutex has a unique ID.
 *  \decomposed_from[t_swcmutex_object_id_type] {1847323}
 */
typedef uint32 t_swcmutex_object_id_type;

/* ------------------------------------------------------------------------- */
/* ------------------------- Configuration Defines ------------------------- */
/* ------------------------------------------------------------------------- */
/** \brief Mutex object ID for InnoDriveControl.
 *  \decomposed_from[SWCMUTEX_MUTEX_ID_READER1] {1847325}
 */
#define SWCMUTEX_MUTEX_ID_READER1 0u
/** \brief Mutex object ID for TSF.
 *  \decomposed_from[SWCMUTEX_MUTEX_ID_READER2] {1847325}
 */
#define SWCMUTEX_MUTEX_ID_READER2 1u
/** \brief Mutex object ID for RoadGraphLight.
 *  \decomposed_from[SWCMUTEX_MUTEX_ID_WRITER] {1847325}
 */
#define SWCMUTEX_MUTEX_ID_WRITER  2u

/* ------------------------------------------------------------------------- */
/* -------------------------- Function Prototypes -------------------------- */
/* ------------------------------------------------------------------------- */
extern e_swcmutex_return_type Mutex_GetMutex (t_swcmutex_object_id_type mutex_id);
extern e_swcmutex_return_type Mutex_ReleaseMutex (t_swcmutex_object_id_type mutex_id);

#endif /* SWCMUTEX_H */
