/**************************************************************************
 * Copyright (C) 2011-2012 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietory
 * Sch�nbrunnerstra�e 7, A-1040 Wien, Austria. office@tttech-automotive.com
 *  *
 * Name
 *    Platform_Types.h
 *
 * Purpose
 *   Definition of Standard Types
 *   This is a minimal implementation of an Autosar compatible Std_Types.h
 *   file for the Remote Access Library
 *
 * Revisions
 *
 *    16-Oct-2013  (BLE) Creation
 **************************************************************************/

#ifndef STD_TYPES_H
#define STD_TYPES_H

/**************************************************************************
 * INCLUDES
 **************************************************************************/

#ifdef _WIN32
     /* Attention: These constants are redefined.
      * For CONST there won't be a problem since the original definition in
      * windef.h is also "#define CONST const".
      * E_PENDING is more tricky since the value is changed to 2.
      */
    #undef E_PENDING
    #undef CONST
#endif

# include "Platform_Types.h"
# include "Compiler.h"

/**************************************************************************
 *  GLOBAL CONSTANT MACROS
 **************************************************************************/


# define STD_HIGH     1u /* Physical state 5V or 3.3V */
# define STD_LOW      0u /* Physical state 0V */

# define STD_ACTIVE   1u /* Logical state active */
# define STD_IDLE     0u /* Logical state idle */

# define STD_ON       1u
# define STD_OFF      0u

/**************************************************************************
 *  GLOBAL FUNCTION MACROS
 **************************************************************************/


/**************************************************************************
 *  GLOBAL DATA TYPES AND STRUCTURES
 **************************************************************************/

/* This typedef has been added for OSEK compliance */
# ifndef STATUSTYPEDEFINED
#  define STATUSTYPEDEFINED
#  define E_OK      0u
typedef unsigned char StatusType; /* OSEK compliance */
# endif

# define E_NOT_OK  1u

#  define E_PENDING 2u

/* XXX handle conflict with LIN driver (workaround Z40) */
# ifndef __INClinIfTypesh
typedef uint8 Std_ReturnType;
# endif /* __INClinIfTypesh */

typedef struct
{
   uint16 vendorID;
   uint16 moduleID;
   uint8  instanceID;
   uint8  sw_major_version;
   uint8  sw_minor_version;
   uint8  sw_patch_version;
} Std_VersionInfoType;

/**************************************************************************
 *  GLOBAL DATA PROTOTYPES
 **************************************************************************/


/**************************************************************************
 *  GLOBAL FUNCTION PROTOTYPES
 **************************************************************************/


#endif  /* STD_TYPES_H */

/**************************************************************************
 *  END OF FILE: Std_Types.h
 **************************************************************************/
