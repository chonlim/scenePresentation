/*******************************************************************************
 * Copyright (C) 2014 TTTech Automotive GmbH. All rights reserved              *
 * Schoenbrunnerstrasse 7, A-1040 Wien, Austria. office\tttech-automotive.com  *
 ******************************************************************************/
/**
 *  \file
 *      NonRteInterfaces.h
 *  \brief
 *       zFAS Non-Rte Interfaces for APH HW-Abstraction
 *        - Renaming of the internal used functions to the zFAS SystemLevel functions
 *     It describes the API of the Non-Rte Interfaces.
 *
 * \page zFAS APH Non-Rte Interfaces
 *
 * The APH offers some Non-Rte Interfaces, for the usage of some PF-Ressources like Hardware.
 *
 * They consist of:
 *   \ref Speaker
 *   \ref Swinging-Logo
 *   \ref Park-PanelSwitch
 *   \ref LIN
 *   \ref EyeQ
 *   \ref FVcamera
 *   \ref TVcamera
 *   \ref Cleaning
 *   \ref Reset-Reason
 *   \ref SWC Mutex
 *
 *
 *\par Version
 *\code
 *  version 1.0.0
 *          [19-MAR-2015] [MKO]        File creation
 *
 *  version 1.0.1
 *          [23-MAR-2015] [MKO][74982] Added FV-Camera Interfaces
 *
 *  version 1.0.2
 *          [26-MAR-2015] [MKO]        Added Non-Rte Interfaces Types\n
 *
 *  version 1.1.0
 *          [08-JUN-2015] [MKO][75404] Added TV-Camera Interfaces
 *          [08-JUN-2015] [MKO]        Fixed typing error at GetSpeakerLinCS_SEL0
 *
 *  version 1.2.0
 *          [12-JUN-2015] [MKO][78722] Introduced new ParkPanel Switch Interface
 *
 *  version 1.2.1
 *          [30-JUN-2015] [MKO][80388] Updated PWM-Speaker NonRteInterfaces (SetSpeakerFrequencyPwm, SetSpeakerVolumePwm)
 *
 *  version 1.2.2
 *          [20-JUL-2015] [MKO][81281] Updated naming of GetTVCamPower --> GetTVCamPowerGood
 *                             [80388] Period parameter of all PWM Interfaces is now a uint16 type *
 *
 *  version 1.3.0
 *          [27-JUL-2015] [MKO][80425] Fixed ref clock for Swinging-Logo PWM, to achieve required frequency-range
 *                                     Updated Speaker PWM documentation (SetSpeakerFrequencyPwm, SetSpeakerVolumePwm)
 *  version 1.4.0
 *          [27-AUG-2015] [MKO][83644] Added Variant/Version support
 *
 *  version 1.5.0
 *          [27-AUG-2015] [MKO][80990] Added Cleaning Interface
 *  version 1.5.1
 *          [27-MAY-2016] [eDDA]       TV Camera ADC Get functions updated, raw functions added
 *
 *  version 1.5.1
 *          [11-MAR-2016] [VLE]        Updated MobilEye-EyeQ3 interfaces
 *
 *  version 1.5.2
 *          [18-APR-2016] [VLE]        Updated FVCamera interfaces
 *
 *  version 1.5.3
 *          [20-JUN-2016] [eDDA]       Cleaning Interface Get functions added
 *
 *  version 1.5.4
 *          [22-JUL-2016] [eDDA]       Speaker and LIN power supply interfaces
 *                                     added, HSS multiplexed signals
 *  version 1.5.5
 *          [22-JUL-2016] [eDDA]       Speaker and LIN power supply interfaces
 *                                     removed, msg901955
 *  version 1.5.6
 *          [26-JAN-2017] [VLE] [110710] Fixed FVCamera type FVCamera_I2C_BusActionType
 *                                       enumeration defines according to SD_TSC.
 *  version 1.5.7
 *          [10-OCT-2017] [CBR]        added Reset-Reason interface
 *
 *  version 1.5.8
 *          [15-JAN-2018] [VLE] [124359] added SWC Mutex interfaces
 *\endcode
 *
 *
 *
 *
 */

/*******************************************************************************
 **                            Function Macros                                **
 ******************************************************************************/

/* +---------------------------------+
   |             Speaker             |
   +---------------------------------+                                       */
/** defgroup Speaker Speaker Interfaces
 *  {
 */

/** \brief Enables/disables the power of the REAR speaker circuit.
 *
 *
 * \param level [uint8]       Pin Level which should be set
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH --> Output high          |
 *    | STD_LOW  --> Output low           |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                            on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 */
 /** \decomposed_from[SetSpeakerPSEnableRear] {1065235, 592855} */
#define  SetSpeakerPSEnableRear(level)  \
             CdIoHwAbQM_Dio_WriteChannel_SPKPS_EN_REAR(level)


/** \brief Enables/disables the power of the FRONT speaker circuit.
 *
 *
 * \param level [uint8]        Pin Level which should be set
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH --> Output high          |
 *    | STD_LOW  --> Output low           |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSpeakerPSEnableFront] {1065241, 592855} */
#define  SetSpeakerPSEnableFront(level)  \
             CdIoHwAbQM_Dio_WriteChannel_SPKPS_EN_FRONT(level)


/** \brief Reads the power status of REAR speaker.
 *
 *
 * \param p_level [*uint8]         Pointer to which the current Pin Level should be read
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH --> Output high          |
 *    | STD_LOW  --> Output low           |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSpeakerPSEnableRear] {1065237, 592867} */
#define  GetSpeakerPSEnableRear(p_level)  \
             CdIoHwAbQM_Dio_ReadChannel_SPKPS_EN_REAR(p_level)

/** \brief Reads the power status of FRONT speaker.
 *
 *
 * \param p_level [*uint8]         Pointer to which the current Pin Level should be read
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH --> Output high          |
 *    | STD_LOW  --> Output low           |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSpeakerPSEnableFront] {1065239, 592867} */
#define  GetSpeakerPSEnableFront(p_level)  \
             CdIoHwAbQM_Dio_ReadChannel_SPKPS_EN_FRONT(p_level)


/** \brief Enables/Disables the REAR speaker.
 *
 *
 * \param level [uint8]        Pin Level which should be set
 *    | Possible Values             |
 *    | :----                       |
 *    | STD_HIGH --> Output high    |
 *    | STD_LOW  --> Output low     |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSpeakerEnableRear] {592037, 592855} */
#define  SetSpeakerEnableRear(level)  \
             CdIoHwAbQM_Dio_WriteChannel_SPK_EN_REAR(level)

/** \brief Enables/Disables the FRONT speaker.
 *
 *
 * \param level [uint8]         Pin Level which should be set
 *    | Possible Values             |
 *    | :----                       |
 *    | STD_HIGH --> Output high    |
 *    | STD_LOW  --> Output low     |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSpeakerEnableFront] {665825, 592855} */
#define  SetSpeakerEnableFront(level)  \
             CdIoHwAbQM_Dio_WriteChannel_SPK_EN_FRONT(level)

/** \brief Reads the REAR Speaker status.
 *
 *
 * \param p_level [*uint8]         Pointer to which the current Pin Level should be read
 *    | Possible Values             |
 *    | :----                       |
 *    | STD_HIGH --> Output high    |
 *    | STD_LOW  --> Output low     |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSpeakerEnableRear] {665827, 592867} */
#define  GetSpeakerEnableRear(p_level)  \
             CdIoHwAbQM_Dio_ReadChannel_SPK_EN_REAR(p_level)


/** \brief Reads the FRONT Speaker status.
 *
 *
 * \param p_level [*uint8]         Pointer to which the current Pin Level should be read
 *    | Possible Values             |
 *    | :----                       |
 *    | STD_HIGH --> Output high    |
 *    | STD_LOW  --> Output low     |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSpeakerEnableFront] {954058, 592867} */
#define  GetSpeakerEnableFront(p_level)  \
             CdIoHwAbQM_Dio_ReadChannel_SPK_EN_FRONT(p_level)


/** \brief Reads the Pin Level of Pin SPK_DIAG_REAR_GND.
 *
 *
 * \param p_level [*uint8]        Pointer to which the current Pin Level should be read
 *    | Possible Values |
 *    | :----           |
 *    | STD_HIGH        |
 *    | STD_LOW         | 
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
*
 */
 /** \decomposed_from[GetSpeakerDiagRearGND] {665843, 592867, 592849} */
#define  GetSpeakerDiagRearGND(p_level)  \
             CdIoHwAbQM_Dio_ReadChannel_SPK_DIAG_REAR_GND(p_level)


/** \brief Reads the Pin Level of Pin SPK_DIAG_FRONT_GND.
 *
 *
 * \param p_level [*uint8]        Pointer to which the current Pin Level should be read
 *    | Possible Values |
 *    | :----           |
 *    | STD_HIGH        |
 *    | STD_LOW         | 
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSpeakerDiagFrontGND] {665845, 592867, 592849} */
#define  GetSpeakerDiagFrontGND(p_level)  \
             CdIoHwAbQM_Dio_ReadChannel_SPK_DIAG_FRONT_GND(p_level)


/** \brief Service to set the required duty cycle and period of the PWM
 *          signal from channel SPK_FRQ.
 *
 *
 * \param period [uint16]       Period of the PWM signal in absolute ticks with
 *                        a reference clock of 24414 Hz.
 *    | Possible Values |
 *    | :----           |
 *    | 0x0 - 0xFFFE    |
 *
 * \param dutycycle [uint16]    Dutycycle of the PWM signal in percentage,
 *                       relative to period.
 *    | Possible values                 |
 *    | :----                           |
 *    | 0x0 (= 0%) - 0x8000 (= 100%)    |
 *
 *
 *    | Example of use                                                                  |
 *    | :----                                                                           |
 *    | period (ticks) = reference_clock_frequency (Hz) / pwm_frequency (Hz)            |
 *    | \n                                                                              |
 *    | Calculation for 1000 Hz PWM with 50% duty-cycle:                                |
 *    | period = 24414 Hz / 1000 Hz =~ 24 ticks --> 0x18                                |
 *    | SetSpeakerFrequencyPwm(0x18, 0x4000);                                           |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    PWM successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available *
 *                                               on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSpeakerFrequencyPwm] {665833, 592871} */
#define  SetSpeakerFrequencyPwm(period, dutycycle)  \
        CdIoHwAbQM_Pwm_SetChannel_SPK_FRQ(period, dutycycle)

 /** \brief Service to set the required duty cycle and period of the PWM signal
  *          from channel SPK_VOL.
 *
 *
 * \param period [uint16]       Period of the PWM signal in absolute ticks with
 *                        a reference clock of 390625 Hz.
 *    | Possible Values |
 *    | :----           |
 *    | 0x0 - 0xFFFE    |
 *
 * \param dutycycle [uint16]    Dutycycle of the PWM signal in percentage,
 *                        relative to period.
 *    | Possible values                 |
 *    | :----                           |
 *    | 0x0 (= 0%) - 0x8000 (= 100%)    |
 *
 *
 *    | Example of use                                                                  |
 *    | :----                                                                           |
 *    | period (ticks) = reference_clock_frequency (Hz) / pwm_frequency (Hz)            |
 *    | \n                                                                              |
 *    | Calculation for 20000 Hz PWM with 50% duty-cycle:                               |
 *    | period = 390625 Hz / 20000 Hz =~ 20 ticks --> 0x14                              |
 *    | SetSpeakerVolumePwm(0x14, 0x4000);                                              |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    PWM successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSpeakerVolumePwm] {665835, 592871} */
 #define  SetSpeakerVolumePwm(period, dutycycle)  \
             CdIoHwAbQM_Pwm_SetChannel_SPK_VOL(period, dutycycle)


/** \brief Returns the value of the measured ADC from channel SPK_DIAG in as RAW ADC value (0-4095)
 *
 *
 * \param p_voltage [*uint16]       Pointer to which the measured the RAW ADC value should be read
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSpeakerDiagVoltage] {665853, 598854} */
#define  GetSpeakerDiagVoltage(p_voltage)  \
             CdIoHwAbQM_Adc_Get_SPK_DIAG(p_voltage)

/* End of Speaker group */
/**}*/


/* +---------------------------------+
   |         Swinging Logo           |
   +---------------------------------+                                       */
/** defgroup Swinging-Logo Swinging-Logo Interfaces
 *  {
 */

/** \brief Service to set the required duty cycle and period of the PWM signal from channel ASW_LOGO_1.
 *
 *
 * \param period [uint16]   Period of the PWM signal in absolute ticks with a reference clock of 24414 Hz.
 *    | Possible Values |
 *    | :----           |
 *    | 0x0 - 0xFFFE    |
 *
 * \param dutycycle [uint16]     Dutycycle of the PWM signal in percentage, relative to period.
 *    | Possible values                 |
 *    | :----                           |
 *    | 0x0 (= 0%) - 0x8000 (= 100%)    |
 *
 *
 *    | Example of use                                                                  |
 *    | :----                                                                           |
 *    | period (ticks) = reference_clock_frequency (Hz) / pwm_frequency (Hz)            |
 *    | \n                                                                              |
 *    | Calculation for 1000 Hz PWM with 50% duty-cycle:                                |
 *    | period = 24414 Hz / 1000 Hz =~ 24 ticks --> 0x18                                |
 *    | SetLogoPwmFront(0x18, 0x4000);                                                   |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    PWM successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
/** \decomposed_from[SetLogoPwmFront] {665879, 592871} */
#define  SetLogoPwmFront(period, dutycycle)  \
             CdIoHwAbQM_SetPwm_SW_LogoFront(period, dutycycle)


/** \brief Service to set the required duty cycle and period of the PWM signal from channel ASW_LOGO_2.
 *
 *
 * \param period [uint16]   Period of the PWM signal in absolute ticks with a reference clock of 24414 Hz.
 *    | Possible Values |
 *    | :----           |
 *    | 0x0 - 0xFFFE    |
 *
 * \param dutycycle [uint16]     Dutycycle of the PWM signal in percentage, relative to period.
 *    | Possible values                 |
 *    | :----                           |
 *    | 0x0 (= 0%) - 0x8000 (= 100%)    |
 *
 *
 *    | Example of use                                                                  |
 *    | :----                                                                           |
 *    | period (ticks) = reference_clock_frequency (Hz) / pwm_frequency (Hz)            |
 *    | \n                                                                              |
 *    | Calculation for 1000 Hz PWM with 50% duty-cycle:                                |
 *    | period = 24414 Hz / 1000 Hz =~ 24 ticks --> 0x18                                |
 *    | SetLogoPwmRear(0x18, 0x4000);                                                   |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    PWM successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
/** \decomposed_from[SetLogoPwmRear] {665881, 592871} */
#define  SetLogoPwmRear(period, dutycycle)  \
             CdIoHwAbQM_SetPwm_SW_LogoRear(period, dutycycle)

/** \brief Returns the value of the measured front tLOW time period from channel MIB_SW_LOGO_2_SENSE in MiliVolt [mV].
 *
 *
 * \param p_tLow [uint32*] Pointer to which the measured front tLOW values are in ms.
 *
 *
 * \return Status of the executed function
 *
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetMaxLowPeriodFront] {665883} */
#define  GetMaxLowPeriodFront(p_tLow)  \
             CdIoHwAbQM_SWLogo_GetMaxLowPeriodFront(p_tLow)

/** \brief Returns the value of the measured rear tLOW time period from
 *       channel MIB_SW_LOGO_1_SENSE in MiliVolt [mV].
 *
 *
 * \param p_tLow [uint32*] Pointer to which the measured rear tLOW values are in ms.
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetMaxLowPeriodRear] {1021636} */
#define  GetMaxLowPeriodRear(p_tLow)  \
             CdIoHwAbQM_SWLogo_GetMaxLowPeriodeRear(p_tLow)

/* End of Swinging Logo group */
/**}*/


/* +---------------------------------+
   |           Park Panel            |
   +---------------------------------+                                       */
/** defgroup Park-PanelSwitch Park-Panel Switch Interfaces
 *  {
 */

/** \brief Reads the status of the ParkPanel Switch
 *  *
 *
 * \param p_status [\ref Dt_ENUM_ParkPanelSwitchStatus*]
 *                     Pointer to which the switch status should be read
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Switch-status successfully read
 * \retval CDIOHWABQM_E_NOT_OK                ParkPanelSwitch could not be evaluated any more
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetParkPanelSwitchStatus] {665895} */
#define  GetParkPanelSwitchStatus(p_status)  \
                          CdIoHwAbASIL_GetParkPanelSwitchStatusAdc(p_status)

/* End of Park-Panel group */
/**}*/


/* +---------------------------------+
   |              LIN                |
   +---------------------------------+                                       */
/** defgroup LIN LIN Interfaces
 *  {
 */

/** \brief Sets the Pin Level of Pin SUPLIN_FRNT_EN.
 *
 *
 * \param level [uint8]        Pin Level which should be set
 *    | Possible Values                    |
 *    | :----                              |
 *    | STD_HIGH --> US PowerSupply On     |
 *    | STD_LOW  --> US PowerSupply Off    |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSupLinEnableFront] {665946} */
#define  SetSupLinEnableFront(level)  \
             CdIoHwAbQM_Dio_Set_SUPLIN_FRTN_EN(level)

/** \brief Reads the Pin Level of Pin SUPLIN_FRNT_EN.
 *
 *
 * \param p_level [*uint8]       Pin Level
 *    | Possible Values                    |
 *    | :----                              |
 *    | STD_HIGH --> US PowerSupply On     |
 *    | STD_LOW  --> US PowerSupply Off    |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSupLinEnableFront] {665948} */
#define  GetSupLinEnableFront(p_level)  \
             CdIoHwAbQM_Dio_Get_SUPLIN_FRTN_EN(p_level)

/** \brief Sets the Pin Level of Pin SUPLIN_REAR_EN.
 *
 *
 * \param level [uint8]   Pin Level which should be set
 *    | Possible Values                    |
 *    | :----                              |
 *    | STD_HIGH --> US PowerSupply On     |
 *    | STD_LOW  --> US PowerSupply Off    |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetSupLinEnableRear] {719106} */
#define  SetSupLinEnableRear(level)  \
             CdIoHwAbQM_Dio_Set_SUPLIN_REAR_EN (level)

/** \brief Reads the Pin Level of Pin SUPLIN_REAR_EN.
 *
 *
 * \param p_level [*uint8]        Pin Level
 *    | Possible Values                    |
 *    | :----                              |
 *    | STD_HIGH --> US PowerSupply On     |
 *    | STD_LOW  --> US PowerSupply Off    |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSupLinEnableRear] {719108} */
#define  GetSupLinEnableRear(p_level)  \
             CdIoHwAbQM_Dio_Get_SUPLIN_REAR_EN(p_level)

/** \brief Returns the raw value (12 bits)
 *  of the measured ADC from channel SUP_LIN_FRNT_SENSE.
 *
 *
 * \param p_adc_value [*uint16] Pointer to which the RAW measured ADC value should be read
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSupLinSenseVoltageFront] {665966} */
#define  GetSupLinSenseVoltageFront(p_adc_value)  \
             CdIoHwAbQM_Adc_Get_SUP_LIN_FRNT_SENSE(p_adc_value)

/** \brief Returns the raw value (12 bits)
 *  of the measured ADC from channel SUP_LIN_REAR_SENSE.
 *
 *
 * \param p_adc_value [*uint16] Pointer to which the RAW measured ADC value should be read
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetSupLinSenseVoltageRear] {665968} */
#define  GetSupLinSenseVoltageRear(p_adc_value)  \
             CdIoHwAbQM_Adc_Get_SUP_LIN_REAR_SENSE(p_adc_value)

/* End of LIN group */
/**}*/


/* +---------------------------------+
   |         MobilEye EyeQ3          |
   +---------------------------------+                                       */
/** defgroup EyeQ MobilEye-EyeQ3 ASIL B Interfaces
 *  {
 */

/** \brief Enumeration return type SendDataSpiEyeQ_ReturnType. Refer to function
 *  SendDataSpiEyeQ for description of the return values.
 *
 *  \var SENDDATASPIEYEQ_E_OK
 *  \var SENDDATASPIEYEQ_E_NOK_WRONG_SIZE
 *  \var SENDDATASPIEYEQ_E_NOK_TX_IN_PROGRESS
 *  \var SENDDATASPIEYEQ_UNDEFINED
 *
 */
 /** \decomposed_from[SendDataSpiEyeQ_ReturnType] {1093935} */
#define SendDataSpiEyeQ_ReturnType           e_cdiohwabasil_eyeqcom_getstatus_returntype
#define SENDDATASPIEYEQ_E_OK                 CDIOHWABASIL_EYEQCOM_SENDDATA_E_OK
#define SENDDATASPIEYEQ_E_NOK_WRONG_SIZE     CDIOHWABASIL_EYEQCOM_SENDDATA_E_NOK_WRONG_SIZE
#define SENDDATASPIEYEQ_E_NOK_TX_IN_PROGRESS CDIOHWABASIL_EYEQCOM_SENDDATA_E_NOK_TX_IN_PROGRESS
#define SENDDATASPIEYEQ_UNDEFINED            CDIOHWABASIL_EYEQCOM_SENDDATA_STATUS_UNDEFINED

/** \brief Initiates the transmission of numberOfFrames frames from location
 * p_dataPtr.
 *
 * \param p_dataPtr [*uint32]     Pointer to the data to be send
 * \param numberOfFrames [uint8]  Number of frames (128 bytes each) to be sent
 *
 * \return Status of the executed function
 * \retval SENDDATASPIEYEQ_E_OK
 *              The request has been proceed successfully.
 * \retval SENDDATASPIEYEQ_E_NOK_TX_IN_PROGRESS
 *              A transmission is currently ongoing.
 * \retval SENDDATASPIEYEQ_E_NOK_WRONG_SIZE
 *              The size given is wrong or not supported.
 * \retval SENDDATASPIEYEQ_UNDEFINED
 *              Undefined status.
 * \time_behavior_input 
 *
 */
 /** \decomposed_from[SendDataSpiEyeQ] {1093940} */
#define SendDataSpiEyeQ(p_dataPtr, numberOfFrames) \
    CdIoHwAbASIL_EyeQCom_SendData(p_dataPtr, numberOfFrames)

/** \brief Checks whether new data was received from MVH over SPI and returns
 *         its size and a pointer to it via the output parameters.
 *
 * \param p_dataPtr [**uint32] pointer to an array of uint32 words containing
 *        the received data. It is only valid if
 *        *p_numberOfPositionsToBeRead > 0.
 * \param p_numberOfPositionsToBeRead [*uint16] contains the number of
 *        received uint32 words (32 words per 128 byte frame).
 *        0 if no frames are received.
 *
 * \return Status of the executed function
 * \retval E_OK
 *        No error was detected. The output parameters have valid values.
 * \retval E_NOT_OK
 *        An error was detected. The output parameters might be invalid.
 * \time_behavior_input 
 *
 */
 /** \decomposed_from[GetDataSpiEyeQ] {1093842} */
#define GetDataSpiEyeQ(p_dataPtr, p_numberOfPositionsToBeRead) \
    CdIoHwAbASIL_EyeQCom_GetData(p_dataPtr, p_numberOfPositionsToBeRead)

/** \brief Informs the lower layer that the buffer provided by GetDataSpiEyeQ()
 *         is read and is not needed any more.
 *
 * \param numberOfWordsConsumed [uint16]: how many 32 bit words were read from
 *        the receive buffer and can be freed.
 *
 * \return Status of the executed function
 * \retval E_OK
 *        No error was detected.
 * \retval E_NOT_OK
 *        An error was detected.
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[DataConsumedSpiEyeQ] {1093861} */
#define DataConsumedSpiEyeQ(numberOfWordsConsumed) \
    CdIoHwAbASIL_EyeQCom_DataConsumed(numberOfWordsConsumed)

/** \brief Enumeration return type GetStatusSpiEyeQ_ReturnType. Refer to function
 *  GetStatusSpiEyeQ for description of the return values.
 *
 *  \var GETSTATUSSPIEYEQ_TX_CHANNEL_IDLE
 *  \var GETSTATUSSPIEYEQ_TX_CHANNEL_BUSY
 *  \var GETSTATUSSPIEYEQ_UNDEFINED
 *
 */
 /** \decomposed_from[GetStatusSpiEyeQ_ReturnType] {1093950} */
#define GetStatusSpiEyeQ_ReturnType      e_cdiohwabasil_eyeqcom_getstatus_returntype
#define GETSTATUSSPIEYEQ_TX_CHANNEL_IDLE CDIOHWABASIL_EYEQCOM_STATUS_TX_CHANNEL_IDLE
#define GETSTATUSSPIEYEQ_TX_CHANNEL_BUSY CDIOHWABASIL_EYEQCOM_STATUS_TX_CHANNEL_BUSY
#define GETSTATUSSPIEYEQ_UNDEFINED       CDIOHWABASIL_EYEQCOM_STATUS_UNDEFINED

/** \brief Provides the status of the SPI transmit channel.
 *         If the transmit channel is in status idle it can send data frames.
 *
 *
 * \return Status of the executed function
 * \retval GETSTATUSSPIEYEQ_TX_CHANNEL_IDLE
 *            The SPI Master channel is currently idle and can be used.
 * \retval GETSTATUSSPIEYEQ_TX_CHANNEL_BUSY
 *            The SPI Master channel is currently sending frames.
 * \retval GETSTATUSSPIEYEQ_UNDEFINED
 *            Undefined status.
 *
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetStatusSpiEyeQ] {1093952} */
#define GetStatusSpiEyeQ \
    CdIoHwAbASIL_EyeQCom_GetStatus

/** \brief Resets the underlying SPI Slave module.
 *
 *
 * \return Status of the executed function
 * \retval E_OK
 *         No error was detected.
 * \retval E_NOT_OK
 *         An error was detected.
 *
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[ResetModuleSpiAurix] {1093912} */
#define ResetModuleSpiAurix \
    CdIoHwAbASIL_EyeQCom_ResetModule

/** \brief Resets the EyeQ microcontroller.
 *
 *
 * \return Status of the executed function
 * \retval E_OK
 *         No error was detected.
 * \retval E_NOT_OK
 *         An error was detected.
 *
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[ResetEyeQ] {1093968} */
/* TODO: This is a development feature, can be removed in the future. */
#define ResetEyeQ \
    CdIoHwAbASIL_EyeQCom_ResetEyeQ

/** \brief Provides the total number of received 128 byte frames since last restart.
 *
 *
 * \return Status of the executed function
 * \retval The number of received SPI frames since last restart.
 *
 */
 /** \decomposed_from[GetRxFrameCountSinceBootSpiEyeQ] {1093908} */
/* TODO: This is a development feature, can be removed in the future. */
#define GetRxFrameCountSinceBootSpiEyeQ \
    CdIoHwAbASIL_EyeQCom_GetSpiFrameCountSinceBoot

/** \brief SPI slave reset functionality [91384]
 *
 *

 */
 /** \decomposed_from[ReInitSpiAurix] {} */
#define  ReInitSpiAurix  \
             CdIoHwAbQM_EyeQCom_ReInit


/* End of MobilEye-EyeQ3 group */
/**}*/

/* +---------------------------------+
   |            FV Camera            |
   +---------------------------------+                                       */
/** defgroup FVcamera FV Camera Interfaces
 *  {
 */

/** \brief Enables/disables heating of the FV Camera.
 *
 *
 * \param level [uint8]    Pin Level which should be set
 *    | Possible Values             |
 *    | :----                       |
 *    | STD_HIGH --> Heating On     |
 *    | STD_LOW  --> Heating Off    |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 *
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetFVControlHeating] {592855} */
#define  SetFVControlHeating(level)  \
             CdIoHwAbQM_Dio_Set_AURIX_FV_GPIO0(level)


/** \brief Reads the heating status of FV Camera.
 *
 *
 * \param p_level [*uint8] Pointer to which the current Pin Level should be read
 *    | Possible Values             |
 *    | :----                       |
 *    | STD_HIGH --> Heating On     |
 *    | STD_LOW  --> Heating Off    |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 *
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetFVControlHeating] {592867} */
#define  GetFVControlHeating(p_level)  \
             CdIoHwAbQM_Dio_Get_AURIX_FV_GPIO0(p_level)

/** \brief Enumeration return type FVCamera_I2C_ReturnType. Refer to functions
 *  FVCameraI2CSyncWrite, FVCameraI2CSyncRead, FVCameraI2CSyncWriteRead for
 *  description of the return values.
 *
 *  \var FVCAMERA_I2C_OK
 *  \var FVCAMERA_I2C_ERROR
 *  \time_behavior_constant
 *
 */
 /** \decomposed_from[FVCamera_I2C_ReturnType] {1122777} */
#define FVCamera_I2C_ReturnType e_i2c_return
#define FVCAMERA_I2C_OK         I2C_OK
#define FVCAMERA_I2C_ERROR      I2C_ERROR

/** \brief Enumeration return type FVCamera_I2C_ReturnType. Refer to functions
 *  FVCameraI2CSyncWrite, FVCameraI2CSyncRead, FVCameraI2CSyncWriteRead for
 *  description of the values.
 *
 *  \var FVCAMERA_I2C_STATUS_OK
 *  \var FVCAMERA_I2C_STATUS_NOK
 *  \var FVCAMERA_I2C_STATUS_PENDING
 *
 */
 /** \decomposed_from[FVCamera_I2C_StatusType] {1122781} */
#define FVCamera_I2C_StatusType     e_i2c_status
#define FVCAMERA_I2C_STATUS_OK      I2C_OK
#define FVCAMERA_I2C_STATUS_NOK     I2C_ERROR
#define FVCAMERA_I2C_STATUS_PENDING I2C_ERROR

/** \brief Enumeration return type FVCamera_I2C_BusActionType. Refer to functions
 *  FVCameraI2CSyncWrite, FVCameraI2CSyncRead, FVCameraI2CSyncWriteRead for
 *  description of the values.
 *
 *  \var FVCAMERA_I2C_BUS_RELEASE
 *  \var FVCAMERA_I2C_BUS_RESTART
 *  \var FVCAMERA_I2C_BUS_NO_ACTION
 *
 */
 /** \decomposed_from[FVCamera_I2C_BusActionType] {1122783} */
#define FVCamera_I2C_BusActionType  e_i2c_bus
#define FVCAMERA_I2C_BUS_RELEASE   I2C_BUS_RELEASE
#define FVCAMERA_I2C_BUS_RESTART   I2C_BUS_RESTART
#define FVCAMERA_I2C_BUS_NO_ACTION I2C_BUS_NO_ACTION

/** \brief Enumeration chip ID type FVCamera_I2C_ChipIdType. Refer to functions
 *  FVCameraI2CSyncWrite, FVCameraI2CSyncRead, FVCameraI2CSyncWriteRead for
 *  description of the values.
 *
 *  \var FVCAMERA_I2C_CHIP_0X58
 *  \var FVCAMERA_I2C_CHIP_0X90
 *  \var FVCAMERA_I2C_CHIP_0X80
 *  \var FVCAMERA_I2C_CHIP_0X30
 *  \var FVCAMERA_I2C_CHIP_0X40
 *
 */
 /** \decomposed_from[FVCamera_I2C_ChipIdType] {1167774} */
#define FVCamera_I2C_ChipIdType  e_CdIoHwAbASIL_FVCam
#define FVCAMERA_I2C_CHIP_0X58   CDIOHWABASIL_FVCAM_0X58
#define FVCAMERA_I2C_CHIP_0X90   CDIOHWABASIL_FVCAM_0X90
#define FVCAMERA_I2C_CHIP_0X80   CDIOHWABASIL_FVCAM_0X80
#define FVCAMERA_I2C_CHIP_0X30   CDIOHWABASIL_FVCAM_0X30
#define FVCAMERA_I2C_CHIP_0X40   CDIOHWABASIL_FVCAM_0X40

/** \brief FVCameraI2CAsyncWrite
 *
 * \return Status of the executed function
 * \retval FVCAMERA_I2C_OK
 *         I2C operation request was scheduled successfully.
 * \retval FVCAMERA_I2C_NOK
 *         An error was detected.
 * \time_behavior_unbounded
 *
 */
 /** \decomposed_from[FVCameraI2CAsyncWrite] {1122637} */
#define FVCameraI2CAsyncWrite \
    CdIoHwAbASIL_FVCam_AsyncWrite

/** \brief FVCameraI2CAsyncRead
 *
 * \return Status of the executed function
 * \retval FVCAMERA_I2C_OK
 *         I2C operation request was scheduled successfully.
 * \retval FVCAMERA_I2C_NOK
 *         An error was detected.
 * \time_behavior_unbounded
 *
 */
 /** \decomposed_from[FVCameraI2CAsyncRead] {1122639} */
#define FVCameraI2CAsyncRead \
    CdIoHwAbASIL_FVCam_AsyncRead

/** \brief FVCameraI2CAsyncWriteRead
 *
 * \return Status of the executed function
 * \retval FVCAMERA_I2C_OK
 *         I2C operation request was scheduled successfully.
 * \retval FVCAMERA_I2C_NOK
 *         An error was detected.
 * \time_behavior_unbounded
 *
 */
 /** \decomposed_from[FVCameraI2CAsyncWriteRead] {1122641} */
#define FVCameraI2CAsyncWriteRead \
    CdIoHwAbASIL_FVCam_AsyncWriteRead

/** \brief FVCameraI2CDisableBus
 *
 * \return Status of the executed function
 * \retval FVCAMERA_I2C_OK
 *         I2C operation was completed successfully.
 * \retval FVCAMERA_I2C_NOK
 *         An error was detected.
 * \time_behavior_unbounded
 *
 */
 /** \decomposed_from[FVCameraI2CDisableBus] {1150392} */
#define FVCameraI2CDisableBus \
    CdIoHwAbASIL_FVCam_DisableBus

/** \brief FVCameraI2CEnableBus
 *
 * \return Status of the executed function
 * \retval FVCAMERA_I2C_OK
 *         I2C operation was completed successfully.
 * \retval FVCAMERA_I2C_NOK
 *         An error was detected.
 * \time_behavior_unbounded
 *
 */
 /** \decomposed_from[FVCameraI2CEnableBus] {1150394} */
#define FVCameraI2CEnableBus \
    CdIoHwAbASIL_FVCam_EnableBus

/* End of FV Camera group */
/**}*/



/* +---------------------------------+
   |            TV Camera            |
   +---------------------------------+                                       */
/** defgroup TVcamera TV Camera Interfaces
 *  {
 */

/** \brief Reads the power good line of the TV Camera (VDD_CAM_PG)
 *
 *
 * \param p_level [*uint8]       Pointer to which the current Pin Level should be read
 *    | Possible Values            |
 *    | :----                      |
 *    | STD_HIGH --> Power OK      |
 *    | STD_LOW  --> Power NOT OK  |
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVCamPowerGood] {592867} */
#define   GetTVCamPowerGood(p_level)  \
              CdIoHwAbQM_Dio_Get_VDD_CAM_PG(p_level)






/** \brief Sets the value of the selected (tv_idx) port PINof the measured ADC
 *         x = 1 : AURIX_TV1_DISABLE_HWCFG0
 *         x = 2 : AURIX_TV2_DISABLE_HWCFG1
 *         x = 3 : AURIX_TV3_DISABLE_HWCFG4
 *         x = 4 : AURIX_TV4_DISABLE_HWCFG5
 *
 *
 * \param tv_idx  [uint16]       Index (x : 1-4) of the Disable Pin
 * \param p_level [uint8]        PIN Level
 *                               +) STD_HIGH = 1
 *                               +) STD_LOW  = 0�
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    call  ok successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                tv_idx out of range
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetAURIXTVxDISABLE] {1290305} */
#define   SetAURIXTVxDISABLE(tv_idx, level)  \
              CdIoHwAbQM_Dio_Set_AURIXTVxDISABLE   (tv_idx, level)


/** \brief Gets the value of the selected (tv_idx) port PINof the measured ADC
 *         x = 1 : AURIX_TV1_DISABLE_HWCFG0
 *         x = 2 : AURIX_TV2_DISABLE_HWCFG1
 *         x = 3 : AURIX_TV3_DISABLE_HWCFG4
 *         x = 4 : AURIX_TV4_DISABLE_HWCFG5
 *
 *
 * \param tv_idx  [uint16]       Index (x : 1-4) of the Disable Pin
 * \param p_level [uint8*]       Pointer to store the result of the pin read
 *                               +) STD_HIGH = 1
 *                               +) STD_LOW  = 0�
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    call  ok successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                tv_idx out of range
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetAURIXTVxDISABLE] {1290312} */
#define   GetAURIXTVxDISABLE(tv_idx, p_level)  \
              CdIoHwAbQM_Dio_Get_AURIXTVxDISABLE   (tv_idx, p_level)






/** \brief Returns the value of the measured ADC
 *    from channel TV1_VCC_SENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVVoltageVCC_TV1] {923420} */
#define   GetTVVoltageVCC_TV1(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV1_VCC_SENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV2_VCC_SENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVVoltageVCC_TV2] {923420} */
#define   GetTVVoltageVCC_TV2(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV2_VCC_SENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV3_VCC_SENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVVoltageVCC_TV3] {923420} */
#define   GetTVVoltageVCC_TV3(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV3_VCC_SENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV4_VCC_SENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVVoltageVCC_TV4] {923420} */
#define   GetTVVoltageVCC_TV4(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV4_VCC_SENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV1_ISENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVCurrent_TV1] {923421} */
#define   GetTVCurrent_TV1(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV1_ISENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV2_ISENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVCurrent_TV2] {923421} */
#define   GetTVCurrent_TV2(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV2_ISENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV3_ISENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored. Values are in MV
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVCurrent_TV3] {923421} */
#define   GetTVCurrent_TV3(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV3_ISENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel TV4_ISENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored.  Values are in mV
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVCurrent_TV4] {923421} */
#define   GetTVCurrent_TV4(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_TV4_ISENSE(p_adc_value,p_is_updated)


/** \brief Returns the value of the measured ADC
 *    from channel VCC_CAM_SENSE in MiliVolt [mV].
 *
 *
 * \param p_adc_value  [uint32*]       Pointer to variable where ADC value should be stored.  Values are in mV
 * \param p_is_updated [boolean*]      Pointer to is_updated ADC value status
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Voltage successfully measured
 * \retval CDIOHWABQM_E_NOT_OK                Measurement failed
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetTVCamVoltageVCC] {923423} */
#define   GetTVCamVoltageVCC(p_adc_value,p_is_updated)  \
              CdIoHwAbQM_Adc_Get_VCC_CAM_SENSE(p_adc_value,p_is_updated)


/* End of TV Camera group */
/**}*/


/* +---------------------------------+
   |             Cleaning            |
   +---------------------------------+                                       */
/** defgroup Cleaning Cleaning Interfaces
 *  {
 */

/** \brief Enables/disables the cleaning functionality.
 *
 *
 * \param level [uint8]       Pin Level which should be set
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH |
 *    | STD_LOW  |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetCleaningEnableFront] {726675, 592855} */
#define  SetCleaningEnableFront(level)  \
             CdIoHwAbQM_Dio_WriteChannel_AURIX_CLEAN_FRONT(level)

/** \brief Enables/disables the cleaning functionality.
 *
 *
 * \param level [uint8]       Pin Level which should be set
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH |
 *    | STD_LOW  |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully set
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[SetCleaningEnableRear] {726677, 592855} */
#define  SetCleaningEnableRear(level)  \
             CdIoHwAbQM_Dio_WriteChannel_AURIX_CLEAN_REAR(level)

/** \brief Check Front cleaning functionality status.
 *
 *
 * \param level [uint8]       Pin Level which should be read
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH |
 *    | STD_LOW  |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetCleaningEnableFront] {1094714} */
#define  GetCleaningEnableFront(level)  \
             CdIoHwAbQM_Dio_ReadChannel_AURIX_CLEAN_FRONT(level)

/** \brief Check Rear cleaning functionality status.
 *
 *
 * \param level [uint8]       Pin Level which should be read
 *    | Possible Values                   |
 *    | :----                             |
 *    | STD_HIGH |
 *    | STD_LOW  |
 *
 *
 * \return Status of the executed function
 * \retval CDIOHWABQM_E_OK                    Pin Level successfully read
 * \retval CDIOHWABQM_E_PARAM_INVALID         Wrong input parameter detected
 * \retval CDIOHWABQM_E_NO_HW_SUPPORT         Interface not available
 *                                              on this HW Variant/Version
 * \time_behavior_constant
 * \available_in_init_yes
 *
 */
 /** \decomposed_from[GetCleaningEnableFront] {1094716} */
#define  GetCleaningEnableRear(level)  \
             CdIoHwAbQM_Dio_ReadChannel_AURIX_CLEAN_REAR(level)

/* End of Cleaning group */
/**}*/

/* +---------------------------------+
   |           Reset-Reason          |
   +---------------------------------+                                       */
/** defgroup Reset-Reason Interfaces
*  {
*/

/** \brief Check Reset-Status if warm or cold
*
* \return Reset
* \retval TRUE                               warm-reset
* \retval FALSE                              cold-reset
*
* \time_behavior_constant
* \available_in_init_yes
*
*/
/** \decomposed_from[GetWarmResetStatus] {} */
#define GetWarmResetStatus() \
	        ((Scu_SRR_GetSavedResetReason() == 0x02u)||(Scu_SRR_GetSavedResetReason() == 0x06u))

/* End of Reset-Reason group */
/**}*/


/* +---------------------------------+
   |            SWC Mutex            |
   +---------------------------------+                                       */
/** defgroup SWC Mutex Interfaces
*  {
*/

/** \brief Tries to get a reader lock for the RG-Database for software component
 *         InnoDriveControl and returns immediately with the result.
 *
 * \return Result of the operation
 * \retval SWCMUTEX_OK          Mutex obtained successfully
 * \retval SWCMUTEX_NOK_LOCKED  Mutex was not obtained - already locked
 * \decomposed_from[GetRGDatabaseMutex_InnoDriveControl] {1842327}
 */
#define GetRGDatabaseMutex_InnoDriveControl() Mutex_GetMutex(SWCMUTEX_MUTEX_ID_READER1)

/** \brief Releases the reader lock for the RG-Database for software component
 *         InnoDriveControl. Must only be called if the lock has been obtained in
 *         a previous step.
 *
 * \return Result of the operation
 * \retval SWCMUTEX_OK            Mutex released successfully
 * \retval SWCMUTEX_NOK_UNLOCKED  Mutex was already released (mutex state unchanged)
 * \decomposed_from[ReleaseRGDatabaseMutex_InnoDriveControl] {1842333}
 */
#define ReleaseRGDatabaseMutex_InnoDriveControl() Mutex_ReleaseMutex(SWCMUTEX_MUTEX_ID_READER1)

/** \brief Tries to get a reader lock for the RG-Database for software component
 *         TSF and returns immediately with the result.
 *
 * \return Result of the operation
 * \retval SWCMUTEX_OK          Mutex obtained successfully
 * \retval SWCMUTEX_NOK_LOCKED  Mutex was not obtained - already locked
 * \decomposed_from[GetRGDatabaseMutex_TSF] {1842329}
 */
#define GetRGDatabaseMutex_TSF() Mutex_GetMutex(SWCMUTEX_MUTEX_ID_READER2)

/** \brief Releases the reader lock for the RG-Database for software component
 *         TSF. Must only be called if the lock has been obtained in
 *         a previous step.
 *
 * \return Result of the operation
 * \retval SWCMUTEX_OK            Mutex released successfully
 * \retval SWCMUTEX_NOK_UNLOCKED  Mutex was already released (mutex state unchanged)
 * \decomposed_from[ReleaseRGDatabaseMutex_TSF] {1842335}
 */
#define ReleaseRGDatabaseMutex_TSF() Mutex_ReleaseMutex(SWCMUTEX_MUTEX_ID_READER2)

/** \brief Tries to get a writer lock for the RG-Database for software component
 *         RoadGraphLight and returns immediately with the result.
 *
 * \return Result of the operation
 * \retval SWCMUTEX_OK          Mutex obtained successfully
 * \retval SWCMUTEX_NOK_LOCKED  Mutex was not obtained - already locked
 * \decomposed_from[GetRGDatabaseMutex_RoadGraphLight] {1842331}
 */
#define GetRGDatabaseMutex_RoadGraphLight() Mutex_GetMutex(SWCMUTEX_MUTEX_ID_WRITER)

/** \brief Releases the writer lock for the RG-Database for software component
 *         RoadGraphLight. Must only be called if the lock has been obtained in
 *         a previous step.
 *
 * \return Result of the operation
 * \retval SWCMUTEX_OK            Mutex released successfully
 * \retval SWCMUTEX_NOK_UNLOCKED  Mutex was already released (mutex state unchanged)
 * \decomposed_from[ReleaseRGDatabaseMutex_RoadGraphLight] {1842337}
 */
#define ReleaseRGDatabaseMutex_RoadGraphLight() Mutex_ReleaseMutex(SWCMUTEX_MUTEX_ID_WRITER)

/* End of SWC Mutex Interfaces group */
/**}*/
