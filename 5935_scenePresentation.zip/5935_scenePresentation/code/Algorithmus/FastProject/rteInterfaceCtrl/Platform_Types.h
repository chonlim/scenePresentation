/**************************************************************************
 * Copyright (C) 2011-2013 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietory
 * Sch�nbrunnerstra�e 7, A-1040 Wien, Austria. office@tttech-automotive.com
 *  *
 * Name
 *    Platform_Types.h
 *
 * Purpose
 *   Definition of Platform Types for the Remote Access Library. These
 *   types shall work for MS Visual C and GCC both for 32 and 64 bit.
 *
 * Revisions
 *
 *   20-Sep-2012 (PNI) Creation
 *   17-Jun-2013 (MGL) Fixed sint32/uint32 type
 *   16-Oct-2013 (BLE) Created separate version for the RA lib
 **************************************************************************/

#ifndef PLATFORM_TYPES_H
#define PLATFORM_TYPES_H

/**************************************************************************
 * INCLUDES
 **************************************************************************/

/**************************************************************************
 *  GLOBAL CONSTANT MACROS
 **************************************************************************/

#ifndef TRUE
   #define TRUE   1
#endif

#ifndef FALSE
   #define FALSE  0
#endif

/**************************************************************************
 *  GLOBAL FUNCTION MACROS
 **************************************************************************/



/**************************************************************************
 *  GLOBAL DATA TYPES AND STRUCTURES
 **************************************************************************/

typedef unsigned char         boolean;       /*        TRUE .. FALSE         */

typedef signed char           sint8;         /*        -128 .. +127          */
typedef unsigned char         uint8;         /*           0 .. 255           */
typedef signed short          sint16;        /*      -32768 .. +32767        */
typedef unsigned short        uint16;        /*           0 .. 65535         */
typedef signed int            sint32;        /* -2147483648 .. +2147483647   */
typedef unsigned int          uint32;        /*           0 .. 4294967295    */

                                            /*  9223372036854775807           */
typedef unsigned long long    uint64;         /*           0 ..                 */
typedef signed long long      sint64;


typedef float                 float32;
typedef double                float64;

/**************************************************************************
 *  GLOBAL DATA PROTOTYPES
 **************************************************************************/


/**************************************************************************
 *  GLOBAL FUNCTION PROTOTYPES
 **************************************************************************/


#endif  /* PLATFORM_TYPES_H */

/**************************************************************************
 *  END OF FILE: Platform_Types.h
 **************************************************************************/
