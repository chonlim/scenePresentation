/***********************************************************************//**
 * \copyright
 * Copyright (C) 2014 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietary
 * Schoenbrunnerstrasse 7, A-1040 Wien, Austria. office@tttech-automotive.com
 * \end
 *
 * \mainpage zFAS Logging API
 *
 * \version 2.0.1
 * \date    26.08.2014
 *
 * This document describes the API of the zFAS Logging Module:
 * - \ref Log.h                "Logging Module API"
 * - \ref Log_Types.h          "Logging Module Data Types"
 *
 * \file  
 \todo Log.h
 * \brief Logging Module API
 *
 * \Revision History
 *    15-Mai-2014 (BGL)  Creation
 *    14-aug-2014 (eSIG) Added per-component build separation
 *    26-aug-2014 (eSIG) fixed 'const' warning when calling AddMsg
 *    27-aug-2014 (eSIG) MISRA-2012 compliance fixes
 *    27-aug-2014 (BGL)  Remove tracing function and other internally used elements
 *    16-dec-2014 (eSIG) Removed MemDump functionality
 *    13-jan-2014 (eSIG) Removed (blank) LOG_E_NOT_CONFIGURED macros
 *    25-mar-2015 (BGL)  Update doxygen UART output description
 *    10-nov-2016 (eMPR) Added debug mode directive. 
 *    05-dec-2016 (eMPR) Added precompiler directives for SIL build.
 *    19-Dec-2016 (MST)  Renamed precompiler directives for SIL build.
 *    
 *
 * \end
 **************************************************************************/

#ifndef LOG_H_
#define LOG_H_

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#include "Rte_Type.h"
#include "Log_Types.h"
#include "stdarg.h"
#include "Debug_Mode.h"
/**
 * \def Log_AddMsg(id, group, option, ...)
 * \brief Logging macro.
 *
 *  Adds a log entry to the log buffer. The log buffer will be flushed to the UART/Ethernet in a
 *  low priority task.
 *
 *  \par Compile time enable/disable
 *  This macro will expand: \n
 *    1) to _Log_Add() if \c LOG_COMPILE_ENABLE is defined (can be defined by
 *    adding \c -DLOG_COMPILE_ENABLE to compiler flags) \n
 *    2) to nothing if \c LOG_COMPILE_ENABLE is not defined
 *
 * \par Log options
 *  The following log options are enabled at startup by default: \n
 *     1) SWC log level (each group): \ref LOG_ERROR ,  \n
 *     2) Global log level: All enabled
 *
 *  It's possible to enable/disable certain log options for each SWC and
 *  group during runtime by sending an ethernet configuration frame.
 *
 *  \par Log message
 *  The max. length of a single log message (excl. timestamp, id, group, option) including parameters
 *  is 114 Byte, if the message is too large it will be discarded and an error signaled on the configured sink.
 *  The number of parameters is limited to 6, and the size of these parameters is limited to 24 bytes. Thus if all parameters are type float (8 byte representation), the maximum number of parameters is 3.
 *
 *  A new line is automatically appended to each log message.
 *
 *  \par API usage example:
   \code
    Log_AddMsg(SWCID_MySwcId, 2, LOG_ERROR, "Error %d occurred", errorID);
   \endcode
 *
 *  The resulting log will be formatted as: \n
    \code
    <HostID | EntryType> <ZGT in us> <SWCID>-<LogOption>:<Message Counter>:<Message Length>|<Log Message>\n

    65 18407933098 207-1:231:18|Error 5 occurred
	
	<HostID | EntryType> is used only when Logging data is sent via Ethernet frames. Has no meaning for UART output.
    \endcode

 *
 * \param[in] ID            The ID of the logging SWC
 * \param[in] Group         The group which shall be logged for the SWC.
 *                          The group can be individually used to differentiate
 *                          between sub modules of the same SWC (e.g. module A
 *                          (\ref LOG_GROUP_1) of SWC 1 is configured to log only
 *                          \ref LOG_ERROR and module B (\ref LOG_GROUP_2) of the
 *                          same SWC is configured to log \ref LOG_ERROR and
 *                          \ref LOG_WARNING)
 * \param[in] Option        The Logging option of the log message: \ref LOG_ERROR, \ref LOG_WARNING,  \ref LOG_INFO
 * \param[in] ...           The format and variable list of arguments of the
 *                          log message, following format string specifiers are valid:
 * | Specifier | Output                                                                  | Example |
 * | :----:    | :----                                                                   |:----:   |
 * | d         | Signed decimal integer                                                  | -392    |
 * | u         | Unsigned decimal integer                                                | 7235    |
 * | x or X    | Unsigned hexadecimal integer (uppercase)                                | 0x37FA  |
 * | c         | Character                                                               | a       |
 * | s         | String of characters                                                    | sample  |
 * | f         | float                                                                   |22.621   |
 * | %         | A % followed by another % character will write a single % to the stream | %       |
 * \n
 * \n
 * \n
 * All data types have a size of 4 bytes except float which is represented on 8 bytes. 
 * The use shall take care that the used parameters do not exceed 24 bytes in size.
*/

#if defined(LOG_COMPILE_ENABLE) && !defined(ZFAS_SIL_SWC_BUILD)
 #define Log_AddMsg(ID, Group, Option, ...)\
   do{ \
       if ( 0U != IsDebugModeActive() ) \
       { \
           _Log_AddMsg(ID, Group, Option, __VA_ARGS__); \
       } \
       else{ ; } \
   } \
   while (0)
#else 
   #if defined(LOG_COMPILE_ENABLE)
      #define Log_AddMsg(ID, Group, Option, ...)        _Log_AddMsg(ID, Group, Option, __VA_ARGS__)
   #endif
#endif   
  
#ifndef LOG_COMPILE_ENABLE
  #define Log_AddMsg(ID, Group, Option, ...)
#endif
 
/**
 * \brief Function used by Log_AddMsg(ID, Group, Option, *Format, ...) macro. Adds Messages(Error, Warning, Info) to the logging buffer.
 *
 *
 * \param[in] ID            The ID of the component, which creates the logging entry
 * \param[in] Group         The group of the logging entry. Used to provide fine filtering of debug output. 
 *                          8 groups are defined. Users can assign them to logging calls as needed.
 * \param[in] Option        The Logging option of the log message. Error, Warning, Info are valid values
 * \param[in] Format        The format of the log message
 * \param[in] ...           variable list of arguments of the log message
 *
 * \return void:
 * \time_behavior_input
 * \available_in_init_yes
*/
 
void _Log_AddMsg
   ( Dt_ENUM_SWCID ID 
   , Log_Group Group 
   , Log_LogOption Option
   , const Log_MessageFormat *Format
   , ... );


#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* LOG_H_ */

