/**************************************************************************
 * Copyright (C) 2011-2012 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietory
 * Sch�nbrunnerstra�e 7, A-1040 Wien, Austria. office@tttech-automotive.com
 *  *
 * Name
 *    Compiler.h
 *
 *   This is a minimal implementation of an Autosar compiler abstraction
 *   header file for the Remote Access Library
 *
 * Revisions
 *
 *    16-Oct-2013  (BLE) Creation, based on Linux_Autosar/Compiler.h
 **************************************************************************/

/*
 * TODO some defines (e.g.INLINE) are definitely wrong for _WIN32.
 * As long as the are not used in RA lib related code we are fine.
 */

#ifndef COMPILER_H
#define COMPILER_H

/***************************************************************************
 * INCLUDES
 **************************************************************************/

#include "Compiler_Cfg.h"

/***************************************************************************
 *  GLOBAL CONSTANT MACROS
 **************************************************************************/

/* AUTOMATIC used for the declaration of local pointers */
# define AUTOMATIC

/* TYPEDEF shall be used within type definitions, where no memory qualifier can be specified.*/
# define TYPEDEF

/* STATIC define for abstraction of compiler keyword static*/
#  define STATIC     static

/* NULL_PTR define with a void pointer to zero definition*/
# ifndef NULL_PTR
#  define NULL_PTR  ((void *)0)
# endif

/* INLINE  define for abstraction of the keyword inline*/
//# define INLINE     inline

/* LOCAL_INLINE define for abstraction of the keyword inline in functions with "static" scope.
   Different compilers may require a different sequence of the keywords "static" and "inline"
   if this is supported at all. */
//# define LOCAL_INLINE    static inline

/* FUNC macro for the declaration and definition of functions, that ensures correct syntax of function declarations
   rettype     return type of the function
   memclass    classification of the function itself*/
# define FUNC(rettype, memclass) rettype memclass

/* FUNC_P2CONST macro for declaration and definition of functions returning a pointer to a constant, that ensures
     correct syntax of function declarations.
   rettype     return type of the function
   ptrclass    defines the classification of the pointer�s distance
   memclass    classification of the function itself*/
# define FUNC_P2CONST(rettype, ptrclass, memclass) const rettype ptrclass * memclass

/* FUNC_P2VAR macro for the declaration and definition of functions returning a pointer to a variable, that ensures
     correct syntax of function declarations
   rettype     return type of the function
   ptrclass    defines the classification of the pointer�s distance
   memclass    classification of the function itself*/
# define FUNC_P2VAR(rettype, ptrclass, memclass) rettype ptrclass * memclass

/* P2VAR macro for the declaration and definition of pointers in RAM, pointing to variables
   ptrtype     type of the referenced variable memclass
   memclass    classification of the pointer�s variable itself
   ptrclass    defines the classification of the pointer�s distance
 */
# define P2VAR(ptrtype, memclass, ptrclass) memclass ptrtype ptrclass *

/* P2CONST macro for the declaration and definition of pointers in RAM pointing to constants
   ptrtype     type of the referenced data
   memclass    classification of the pointer's variable itself
   ptrclass    defines the classification of the pointer's distance
 */
# define P2CONST(ptrtype, memclass, ptrclass) const memclass ptrtype ptrclass *

/* CONSTP2VAR macro for the declaration and definition of constant pointers accessing variables
   ptrtype     type of the referenced data
   memclass    classification of the pointer's variable itself
   ptrclass    defines the classification of the pointer's distance
 */
# define CONSTP2VAR(ptrtype, memclass, ptrclass) memclass ptrtype ptrclass * const

/* CONSTP2CONST macro for the declaration and definition of constant pointers accessing constants
   ptrtype     type of the referenced data
   memclass    classification of the pointer's variable itself
   ptrclass    defines the classification of the pointer's distance
 */
# define CONSTP2CONST(ptrtype, memclass, ptrclass) const memclass ptrtype ptrclass * const

/* P2FUNC macro for the type definition of pointers to functions
   rettype     return type of the function
   ptrclass    defines the classification of the pointer's distance
   fctname     function name respectivly name of the defined type
 */
# define P2FUNC(rettype, ptrclass, fctname) rettype (ptrclass * fctname)

/* CONST macro for the declaration and definition of constants
   type        type of the constant
   memclass    classification of the constant itself
 */
# define CONST(type, memclass) const type memclass

/* VAR macro for the declaration and definition of variables
   vartype        type of the variable
   memclass    classification of the variable itself
 */
# define VAR(vartype, memclass) vartype memclass

#endif  /* COMPILER_H */

/***************************************************************************
 *  END OF FILE: Compiler.h
 **************************************************************************/
