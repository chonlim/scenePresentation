/*** ********************************************************************* ***/
/*** Copyright (C) 2014 TTTech Automotive GmbH. All rights reserved        ***/
/*** Schoenbrunnerstrasse 7, A-1040 Wien, Austria. office\tttech-          ***/
/*** automotive.com                                                        ***/
/*** ********************************************************************* ***/
/*** Module Rte_MemMap, written by TTX-Mwcodegenerator/MemMapGen (Version  ***/
/*** 0.14.2, 04-May-2017) on Mon 16-Jul-2018 16:08:42                      ***/

/* --------------------------------------------------------------------------*/
/* SUPRESSED MISRA VIOLATONS                                                 */
/* --------------------------------------------------------------------------*/
/* Error Message: Precautions shall be taken in order to prevent the contents*/
/*                of a header file being included more then once             */
/* Justification: MemMap works with multiple inclusion according to Autosar  */
/* Suppress :                                                                */
/*            PRQA S 0883 EOF                                                */
/*---------------------------------------------------------------------------*/
/* Error Message: #undef should not be used                                  */
/* Justification: MemMap works with #undef according to Autosar              */
/* Suppress :                                                                */
/*            PRQA S 0841 EOF                                                */
/*---------------------------------------------------------------------------*/





/*** ************************************ ***
               standard sections      
 *** ************************************ ***/

#ifdef RTE_START_SEC_CTAPINNODRIVECONTROL_APPL_CODE
  #undef RTE_START_SEC_CTAPINNODRIVECONTROL_APPL_CODE 
  #define CtApInnoDriveControl_START_SEC_CODE 
#endif /* ifdef RTE_START_SEC_CTAPINNODRIVECONTROL_APPL_CODE */
#ifdef RTE_STOP_SEC_CTAPINNODRIVECONTROL_APPL_CODE
  #undef RTE_STOP_SEC_CTAPINNODRIVECONTROL_APPL_CODE 
  #define CtApInnoDriveControl_STOP_SEC_CODE 
#endif /* ifdef RTE_STOP_SEC_CTAPINNODRIVECONTROL_APPL_CODE */

/*** ************************************ ***
           CtApInnoDriveControl sections 
 *** ************************************ ***/

#ifdef CtApInnoDriveControl_START_SEC_CONST_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_CONST_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_CONST_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CONST_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_CONST_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_CONST_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_CONST_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CONST_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_CONST_8BIT
  #undef CtApInnoDriveControl_START_SEC_CONST_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_CONST_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CONST_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_CONST_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_CONST_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_CONST_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CONST_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_CONST_16BIT
  #undef CtApInnoDriveControl_START_SEC_CONST_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_CONST_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CONST_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_CONST_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_CONST_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_CONST_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CONST_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_CONST_32BIT
  #undef CtApInnoDriveControl_START_SEC_CONST_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_CONST_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CONST_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_CONST_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_CONST_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_CONST_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CONST_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_CONST_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_CONST_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_CONST_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CONST_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_CONST_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_CONST_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_CONST_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CONST_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_CODE
  #undef CtApInnoDriveControl_START_SEC_CODE 
  #define OsApp_InnoDriveControl_START_SEC_CODE 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CODE */

#ifdef CtApInnoDriveControl_STOP_SEC_CODE
  #undef CtApInnoDriveControl_STOP_SEC_CODE 
  #define OsApp_InnoDriveControl_STOP_SEC_CODE 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CODE */

#ifdef CtApInnoDriveControl_START_SEC_CODE_FAST
  #undef CtApInnoDriveControl_START_SEC_CODE_FAST 
  #define OsApp_InnoDriveControl_START_SEC_CODE_FAST 
#endif /* ifdef CtApInnoDriveControl_START_SEC_CODE_FAST */

#ifdef CtApInnoDriveControl_STOP_SEC_CODE_FAST
  #undef CtApInnoDriveControl_STOP_SEC_CODE_FAST 
  #define OsApp_InnoDriveControl_STOP_SEC_CODE_FAST 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_CODE_FAST */

#ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_INIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_INIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_INIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_INIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_INIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_INIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_NON_CACHED_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_NON_CACHED_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_EMEM_CACHED_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_NON_SHARED_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_EMEM_CACHED_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_NON_SHARED_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_INIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_INIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_BOOLEAN
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_BOOLEAN 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_BOOLEAN 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_BOOLEAN */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_8BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_8BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_8BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_8BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_8BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_16BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_16BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_16BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_16BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_16BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_32BIT
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_32BIT
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_32BIT 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_32BIT 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_32BIT */

#ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_START_SEC_VAR_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_START_SEC_VAR_FAST_ASIL_NOINIT_UNSPECIFIED */

#ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_UNSPECIFIED
  #undef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_UNSPECIFIED 
  #define OsApp_InnoDriveControl_STOP_SEC_VAR_NOINIT_UNSPECIFIED 
#endif /* ifdef CtApInnoDriveControl_STOP_SEC_VAR_FAST_ASIL_NOINIT_UNSPECIFIED */