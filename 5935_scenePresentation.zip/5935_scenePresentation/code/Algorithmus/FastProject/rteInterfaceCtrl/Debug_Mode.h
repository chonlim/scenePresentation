/***********************************************************************//**
 * \copyright
 * Copyright (C) 2016 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietary
 * Schoenbrunnerstrasse 7, A-1040 Wien, Austria. office@tttech-automotive.com
 * \end
 *
 * \page zFAS Debug Mode Information
 *
 * \version 1.0.0
 * \date    12.07.2016
 *
 * This document describes the API of the zFAS Debug Mode Information Module
 * - \ref Debug_Mode.h                "Debug Mode Information API"
 *
 * \file  Algorithmus/FastProject/rteInterfaceCtrl/Debug_Mode.h
 * \brief Debug Mode Information API
 *
 * \Revision History
 *    12-Jul-2016 (MRO)  Creation
 *
 * \end
 **************************************************************************/

#ifndef DEBUG_MODE_H_
#define DEBUG_MODE_H_

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#include "Platform_Types.h"

#define DEVEL_UNLOCK_SIZE 2

/** \brief Provide information, whether zFAS is in Debug Mode or not
 *
 * \return Debug Mode information
 * \retval TRUE          zFAS is in Debug Mode
 * \retval FALSE         zFAS is not in Debug Mode
 * \time_behavior_constant
 * \available_in_init_yes
 * \decomposed_from [IsDebugModeActive] {1217761}
 */

extern void    Dmiu_Init (void* Platform_Dataset);
extern boolean IsDebugModeActive (void);
extern boolean IsDebugModeLevel2Active (void);

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* DEBUG_MODE_H_ */
