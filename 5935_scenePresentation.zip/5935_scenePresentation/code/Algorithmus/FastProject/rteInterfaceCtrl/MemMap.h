/**************************************************************************
 * Copyright (C) 2011-2012 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietory
 * Sch�nbrunnerstra�e 7, A-1040 Wien, Austria. office@tttech-automotive.com
 *  *
 * Name
 *    MemMap.h
 *
 * Purpose
 *   This file has to be extended with the memory section defines for all
 *   modules which where used.
 *
 * Revisions
 *
 *    20-Sep-2012  (PNI) Creation
 *   ��revision-date�����
 **************************************************************************/

#ifndef MEMMAP_H
#define MEMMAP_H

#include "Rte_MemMap.h"



#endif  /* MEMMAP_H */
