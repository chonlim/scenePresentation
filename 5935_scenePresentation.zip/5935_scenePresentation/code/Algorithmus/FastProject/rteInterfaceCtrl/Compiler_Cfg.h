/**************************************************************************
 * Copyright (C) 2011-2012 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietory
 * Sch�nbrunnerstra�e 7, A-1040 Wien, Austria. office@tttech-automotive.com
 *  *
 * Name
 *    Compiler_Cfg.h
 *
 * Purpose
 *   Compiler specific configurations, compliant to AUTOSAR include model
 *
 * Revisions
 *
 *    20-Sep-2012  (PNI) creation
 *    17-Apr-2014  (PPA) added __attribute__ macro to be able to ommit 
 *                       unsupported syntax/tags in the MVSC compiler 
 **************************************************************************/

#ifndef COMPILER_CFG_H
#define COMPILER_CFG_H

#ifndef NO_RTE_CONFIGURATION
#include "Rte_Compiler_Cfg.h"
#endif

#define __attribute__(x)

#endif  /* COMPILER_CFG_H */

