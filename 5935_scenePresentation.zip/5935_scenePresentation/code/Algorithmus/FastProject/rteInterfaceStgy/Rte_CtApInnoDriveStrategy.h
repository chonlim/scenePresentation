/*** Module Rte_CtApInnoDriveStrategy, written by TTX-                     ***/
/*** Mwcodegenerator/Contract_Header.py (Version 0.14.2, 04-May-2017) on   ***/
/*** Mon 16-Jul-2018 16:06:51                                              ***/
/*** IFSet version: 3.1.1                                                  ***/
/* PRQA S 0602 4                                                             */

/** \file Rte_CtApInnoDriveStrategy.h */

/* double include prevention */
#ifndef _RTE_CTAPINNODRIVESTRATEGY_H
# define _RTE_CTAPINNODRIVESTRATEGY_H

#ifndef RTE_CORE
# ifdef RTE_APPLICATION_HEADER_FILE
#     error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
#endif /* ifndef RTE_CORE */

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_Type.h"



/* PRQA S 0602, 0777, 0779, 0639, 4901 EOF                                   */
/*   0602: Allow TTTech-python-C-libs and CGL; usage of names starting with  */
/* _.                                                                        */
/*   0639: number of members in struct: supported by used compilers,         */
/* unacceptable increase in complexity if split.                             */
/*   0777/0779: Allow usage of names from model longer than 31 chars.        */

/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

#ifndef RTE_CORE
  # define Rte_InitValue_PpDiagCoding_DePermitCodingPersistence (0U)
  # define Rte_InitValue_PpPFHwMeasurements_DeTHS (0U)
  # define Rte_InitValue_PpPFProvidedData_DeCurConsecutiveSysRestartCnt (65535U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSAPHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSMVHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSSRHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSSSHState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeLCSSystemState (0U)
  # define Rte_InitValue_PpPFProvidedData_DeTotalSysRestartCnt (4294967295U)
  # define Rte_InitValue_PpPFProvidedData_DeVARHWVariant (0U)
#endif /* ifndef RTE_CORE */



# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
/** \brief get one entry from a queued RTE buffer
 *
 * \param data receive buffer for element 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Receive_CtApInnoDriveStrategy_PpDiagGlobalRead_DeFSPCleared] {1247796}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Receive_CtApInnoDriveStrategy_PpDiagGlobalRead_DeFSPCleared (P2VAR(Dt_BOOL, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) data);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveStrategy_PpDiagCoding_DeCoding] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveStrategy_PpDiagCoding_DeCoding (P2VAR(Dt_RECORD_Diag_Coding, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagCoding_DeCoding] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagCoding_DeCoding (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveStrategy_PpDiagCoding_DePermitCodingPersistence] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveStrategy_PpDiagCoding_DePermitCodingPersistence (P2VAR(Dt_ENUM_PermitCodingPersistence, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagCoding_DePermitCodingPersistence] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagCoding_DePermitCodingPersistence (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA (P2VAR(Dt_RECORD_Anpassung_Deactivate_hardware_in_the_loop_mode_0x0BEA, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 (P2VAR(Dt_RECORD_Anpassung_Platform_zFAS_hil_mode_0x0500, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 (void);
/** \brief copy data from the RTE buffer to the buffer provided by the consumer
 *
 * \param data buffer provided 
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB] {1330078}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB (P2VAR(Dt_RECORD_Anpassung_Roller_Test_Stand_Mode_0x04FB, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) data);
/** \brief update status of a data element
 *
 * \param void 
 *
 * \return TRUE if unread, FALSE if already seen
 * \decomposed_from [Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB] {1247458}
 **/
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_InnoDriveControlParameterSetCtrl,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlParameterSetCtrl (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_InnoDriveControlVehicleModel,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveCtrlVehicleModel (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_InnoDriveStrategyParameterSetStgy,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpDsInnoDriveDataSet_DeInnoDriveStrategyParameterSet (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPemControl_DePemControl] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_PemControl,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPemControl_DePemControl (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPemControl_DePemControl] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPemControl_DePemControl (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFHwMeasurements_DeTHS] {1357185}
 **/
extern FUNC(Dt_ENUM_ThermalHealthStatus, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFHwMeasurements_DeTHS (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFHwMeasurements_DeTHS] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFHwMeasurements_DeTHS (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFHwMeasurements_DeVBAT_MAIN] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_VBatMain,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFHwMeasurements_DeVBAT_MAIN (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFHwMeasurements_DeVBAT_MAIN] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFHwMeasurements_DeVBAT_MAIN (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeCurConsecutiveSysRestartCnt] {1357185}
 **/
extern FUNC(Dt_UINT16_1_0, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeCurConsecutiveSysRestartCnt (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeCurConsecutiveSysRestartCnt] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeCurConsecutiveSysRestartCnt (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeIFSETVersion] {1357185}
 **/
extern FUNC_P2CONST(Dt_RECORD_SWC_VersionIFSET,AUTOMATIC, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeIFSETVersion (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeIFSETVersion] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeIFSETVersion (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSAPHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSAPHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSAPHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSAPHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSMVHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSMVHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSMVHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSMVHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSSRHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSSRHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSSRHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSSRHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSSSHState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSSSHState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSSSHState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSSSHState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSSystemState] {1357185}
 **/
extern FUNC(Dt_ENUM_LCS_State, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeLCSSystemState (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSSystemState] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeLCSSystemState (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeTotalSysRestartCnt] {1357185}
 **/
extern FUNC(Dt_UINT32_1_0, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeTotalSysRestartCnt (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeTotalSysRestartCnt] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeTotalSysRestartCnt (void);
/** \brief get a pointer to the RTE buffer where the consumer runnable can read the data
 *
 * \param void 
 *
 * \return readable RTE buffer
 * \decomposed_from [Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeVARHWVariant] {1357185}
 **/
extern FUNC(Dt_ENUM_VAR_HWVariant, RTE_CODE) Rte_IRead_RInnoDriveStrategy_PpPFProvidedData_DeVARHWVariant (void);
/** \brief current status of the data element
 *
 * \param void 
 *
 * \return status of the RTE buffer page (RTE_E_OK, error code)
 * \decomposed_from [Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeVARHWVariant] {1247091}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_IStatus_RInnoDriveStrategy_PpPFProvidedData_DeVARHWVariant (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveStrategy_PpInnoDriveStrategyTraceData_DeTraceData] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveStrategy_PpInnoDriveStrategyTraceData_DeTraceData (P2CONST(Dt_RECORD_TraceData, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_DATA) data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveStrategy_PpInnoDriveStrategyTraceData_DeTraceData] {1246847}
 **/
extern FUNC_P2VAR(Dt_RECORD_TraceData,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveStrategy_PpInnoDriveStrategyTraceData_DeTraceData (void);
/** \brief copy data of an element from the buffer provided by the producer runnable into the RTE buffer
 *
 * \param data element data provided 
 *
 * \return void
 * \decomposed_from [Rte_IWrite_RInnoDriveStrategy_PpPemPlanning_DePemPlanning] {1246460}
 **/
extern FUNC(void, RTE_CODE) Rte_IWrite_RInnoDriveStrategy_PpPemPlanning_DePemPlanning (P2CONST(Dt_RECORD_PemPlanning, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_DATA) data);
/** \brief provide a writeable RTE buffer
 *
 * \param void 
 *
 * \return pointer to RTE buffer
 * \decomposed_from [Rte_IWriteRef_RInnoDriveStrategy_PpPemPlanning_DePemPlanning] {1246847}
 **/
extern FUNC_P2VAR(Dt_RECORD_PemPlanning,AUTOMATIC, RTE_CODE) Rte_IWriteRef_RInnoDriveStrategy_PpPemPlanning_DePemPlanning (void);
/** \brief call the runnable GetEventStatus
 *
 * \param EventId
 * \param EventStatusExtended
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpEventHandling_GetEventStatus( Dem_EventIdType EventId, P2VAR(Dem_EventStatusExtendedType, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) EventStatusExtended);
/** \brief call the runnable SetEventStatus
 *
 * \param EventId
 * \param EventStatus
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpEventHandling_SetEventStatus( Dem_EventIdType EventId, Dem_EventStatusType EventStatus);
/** \brief call the runnable MW_SetSwcInfo
 *
 * \param swc_id
 * \param swc_info
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpPFServer_MW_SetSwcInfo( Dt_ENUM_SWCID swc_id, P2CONST(Dt_RECORD_SWC_Identification, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_DATA) swc_info);
/** \brief call the runnable TS_ConvertAgt2Zgt
 *
 * \param agtTimestamp
 * \param zgtTimestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_ConvertAgt2Zgt( P2CONST(Dt_RECORD_TimestampAGT, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_DATA) agtTimestamp, P2VAR(Dt_RECORD_Timestamp, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) zgtTimestamp);
/** \brief call the runnable TS_ConvertZgt2Agt
 *
 * \param zgtTimestamp
 * \param agtTimestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_ConvertZgt2Agt( P2CONST(Dt_RECORD_Timestamp, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_DATA) zgtTimestamp, P2VAR(Dt_RECORD_TimestampAGT, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) agtTimestamp);
/** \brief call the runnable TS_GetAgtTimestamp
 *
 * \param agtTimestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_GetAgtTimestamp (P2VAR(Dt_RECORD_TimestampAGT, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) agtTimestamp);
/** \brief call the runnable TS_GetRemainingTimeBudget
 *
 * \param RemainingTimeBudget
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_GetRemainingTimeBudget (P2VAR(Dt_SINT32_1_0, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) RemainingTimeBudget);
/** \brief call the runnable TS_GetZgtTimestamp
 *
 * \param Timestamp
 *
 * \return status of the operation (RTE_E_OK, error code)
 * \decomposed_from [Rte_Call_<s>_<p>_<f>] {1247618}
 **/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_GetZgtTimestamp (P2VAR(Dt_RECORD_Timestamp, AUTOMATIC, RTE_CTAPINNODRIVESTRATEGY_APPL_VAR) Timestamp);


# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_IRead_<r>_<p>_<d>
 * Rte_IStatus_<r>_<p>_<d>
 * Rte_IWrite_<r>_<p>_<d>
 * Rte_IWriteRef_<r>_<p>_<d>
 * Rte_IInvalidate_<r>_<p>_<d>
 *********************************************************************************************************************/

#ifndef RTE_CORE 

/**********************************************************************************************************************
 * Rte_Receive_<p>_<d> (explicit S/R communication with isQueued = true)
 *********************************************************************************************************************/
# define Rte_Receive_PpDiagGlobalRead_DeFSPCleared Rte_Receive_CtApInnoDriveStrategy_PpDiagGlobalRead_DeFSPCleared




/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_PpDiagCoding_DeCoding Rte_Read_CtApInnoDriveStrategy_PpDiagCoding_DeCoding
# define Rte_Read_PpDiagCoding_DePermitCodingPersistence Rte_Read_CtApInnoDriveStrategy_PpDiagCoding_DePermitCodingPersistence
# define Rte_Read_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA
# define Rte_Read_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500
# define Rte_Read_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB Rte_Read_CtApInnoDriveStrategy_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB


/**********************************************************************************************************************
 * Rte_IsUpdated_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_IsUpdated_PpDiagCoding_DeCoding Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagCoding_DeCoding
# define Rte_IsUpdated_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DeDeactivate_hardware_in_the_loop_mode_0x0BEA
# define Rte_IsUpdated_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500 Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DePlatform_zFAS_hil_mode_0x0500
# define Rte_IsUpdated_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB Rte_IsUpdated_CtApInnoDriveStrategy_PpDiagGlobalRead_DeRoller_Test_Stand_Mode_0x04FB




/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/

# define Rte_Call_PpEventHandling_GetEventStatus Rte_Call_CtApInnoDriveStrategy_PpEventHandling_GetEventStatus
# define Rte_Call_PpEventHandling_SetEventStatus Rte_Call_CtApInnoDriveStrategy_PpEventHandling_SetEventStatus
# define Rte_Call_PpPFServer_MW_SetSwcInfo Rte_Call_CtApInnoDriveStrategy_PpPFServer_MW_SetSwcInfo
# define Rte_Call_PpPFServer_TS_ConvertAgt2Zgt Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_ConvertAgt2Zgt
# define Rte_Call_PpPFServer_TS_ConvertZgt2Agt Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_ConvertZgt2Agt
# define Rte_Call_PpPFServer_TS_GetAgtTimestamp Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_GetAgtTimestamp
# define Rte_Call_PpPFServer_TS_GetRemainingTimeBudget Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_GetRemainingTimeBudget
# define Rte_Call_PpPFServer_TS_GetZgtTimestamp Rte_Call_CtApInnoDriveStrategy_PpPFServer_TS_GetZgtTimestamp



#endif /* #ifndef RTE_CORE */ 



# define RTE_START_SEC_CTAPINNODRIVESTRATEGY_APPL_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: RInnoDriveStrategy
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 40ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_RInnoDriveStrategy RInnoDriveStrategy
/** \brief Runnable entity: RInnoDriveStrategy,
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 40ms
 * \param void
 * \return void
 **/
extern FUNC(void, RTE_CTAPINNODRIVESTRATEGY_APPL_CODE) RInnoDriveStrategy(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: RInnoDriveStrategyInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_RInnoDriveStrategyInit RInnoDriveStrategyInit
/** \brief Runnable entity: RInnoDriveStrategyInit,
 * Executed once after the RTE is started
 * \param void
 * \return void
 **/
extern FUNC(void, RTE_CTAPINNODRIVESTRATEGY_APPL_CODE) RInnoDriveStrategyInit(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CTAPINNODRIVESTRATEGY_APPL_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

#ifndef RTE_CORE
  # define RTE_E_PiPFServer_MW_E_TIMESTAMP (16U)
#endif /* ifndef RTE_CORE */

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

/* begin Fileversion check */
#ifndef RTE_CORE
# ifndef SKIP_MAGIC_NUMBER
#  ifdef RTE_MAGIC_NUMBER
#   if RTE_MAGIC_NUMBER != 1531725280
#    error "The magic number is different. Please check time and date of the generated RTE files!"
#   endif
#  else
#   define RTE_MAGIC_NUMBER 1531725280
#  endif  /* RTE_MAGIC_NUMBER */
# endif  /* SKIP_MAGIC_NUMBER */
#endif /* ifndef RTE_CORE */
/* end Fileversion check */

#endif /* _RTE_CTAPINNODRIVESTRATEGY_H */
