/***********************************************************************//**
 * \copyright
 * Copyright (C) 2013 TTTech Automotive GmbH. All rights reserved.
 * Confidential proprietary
 * Schoenbrunnerstrasse 7, A-1040 Wien, Austria. office@tttech-automotive.com
 * \end
 *
 * \file  Algorithmus/FastProject/rteInterfaceStgy/Log_Types.h
 * \brief Logging Module Data Types
 *
 * \Revision History
 *    15-Mai-2014 (BGL)  Creation
 *    27-aug-2014 (eSIG) MISRA-2012 compliance fixes
 *    27-aug-2014 (BGL)  Removed elements used only internally
 *    16-dec-2014 (eSIG) Updated for new/expanded tracing interface
 *    13-jan-2014 (eSIG) Removed (blank) LOG_E_NOT_CONFIGURED macros
 * \end
 **************************************************************************/

#ifndef LOG_TYPES_H_
#define LOG_TYPES_H_

/**
* \brief Available Log-Options (Levels)
*/
typedef uint8 Log_LogOption;

/* These defines are only used for configuration and not in the log API call in embedded SW */
#define LOG_ERROR   (uint8)0x01 /*!< Level for severe errors */
#define LOG_WARNING (uint8)0x02 /*!< Level for minor errors */
#define LOG_INFO    (uint8)0x04 /*!< Informational/debug messages */

/* functional, but not to be used for Z030 - conf is slightly different - due to the specs change */
#define LOG_CODING  (uint8)0x40 /*!< Used for configuration of coded log messages */

/**
* \brief Available Log Groups for each SWC (used to differentiate between sub modules)
*/
typedef uint8 Log_Group;

/**
*  Enumeration Type of available Logging Sinks
*/
/* This data type is only used for configuration and not in the log API call in embedded SW */
typedef enum
{ LOG_SINK_UART = 0x01 /*!< UART as logging sink */
, LOG_SINK_ETH  = 0x02 /*!< Ethernet as logging sink */
}Log_ENUM_SinkConfigType;


/**
* Data type of an Event Type used by the tracing interface. To be defined as needed by users. 
*/
typedef enum
{ TRACE_START_RUNNABLE = 0  /* Runnble start indication */
, TRACE_STOP_RUNNABLE  = 1  /* Runnble stop indication */
, TRACE_TASK_SWITCH    = 2  /* Task switch indication */
, TRACE_INTERRUPT      = 3  /* Interrupt runtime measurement */
, TRACE_START_DRIVER   = 4  /* Start driver indication */
, TRACE_STOP_DRIVER    = 5  /* Stop driver indication */
, TRACE_STATE_CHANGE   = 6  /* State change indication */
, TRACE_CHECKPOINT     = 7 /* Checkpoint indication */
, TRACE_INPUT_SIGNAL   = 8 /* Input signal indication */
, TRACE_ZGT_CORRECTION = 9 /* ZGT correctionn indication */
, PM_STACK_PEAK        = 10 /* Stack peak indication */
, PM_RUNTIME           = 11 /* Runtime calculated on the target> */
, PM_HEAP              = 12 /* Heap usage */
, PM_R_NETTIME         = 13
, TRACE_TASK_SWITCH_STOPSTART  =18
}Dt_ENUM_EventType;

#define LOG_GROUP_1 (uint8)0x01 /*!< Log group 1 */
#define LOG_GROUP_2 (uint8)0x02 /*!< Log group 2*/
#define LOG_GROUP_3 (uint8)0x04 /*!< Log group 3*/
#define LOG_GROUP_4 (uint8)0x08 /*!< Log group 4*/
#define LOG_GROUP_5 (uint8)0x10 /*!< Log group 5*/
#define LOG_GROUP_6 (uint8)0x20 /*!< Log group 6*/
#define LOG_GROUP_7 (uint8)0x40 /*!< Log group 7*/
#define LOG_GROUP_8 (uint8)0x80 /*!< Log group 8*/

/* startup checkpoints, see section 4.13.3.2.2.2 in SAD */

#define CP_DRV0       ((uint16)0x01)
#define CP_DRV1       ((uint16)0x02)
#define CP_DRV3       ((uint16)0x03)
#define CP_BIST       ((uint16)0x04)
#define CP_FR_NORM    ((uint16)0x05)
#define CP_FR_SYNC    ((uint16)0x06)
#define CP_SWCINIT_START   ((uint16)0x07)
#define CP_SWCINIT_NEXT    ((uint16)0x08)
#define CP_SWCINIT_END     ((uint16)0x09)
#define CP_SYNC       ((uint16)0x0b)
#define CP_INIT       ((uint16)0x0c)
#define CP_TTSCHED_START  ((uint16)0x0D)

/* shutdown checkpoints, see section 4.13.3.2.2.3 in SAD */

#define CP_PERW_START     ((uint16)0x10)
#define CP_PERW_END       ((uint16)0x11)
#define CP_FR_SLEEP       ((uint16)0x12)
#define CP_SHUBIST_START  ((uint16)0x13)
#define CP_SHUBIST_END    ((uint16)0x14)


/* The following execution checkpoints are defined for the system based on events and external triggers:  */
#define CP_KS01KL15_ON 	    0xF0 
#define CP_KS01KL15_OFF 	0xF1 


/* The following execution checkpoints are defined for the system shutdown procedure:  */

/* APH Cp */
#define CP_APH_PERW_START 	    0x0010 
#define CP_APH_PERW_END 	    0x0011 
#define CP_APH_RECW_START 	    0x0012 
#define CP_APH_RECW_END 	    0x0013 
#define CP_APH_EDRW_START 	    0x0014 
#define CP_APH_EDRW_END 	    0x0015 
#define CP_APH_FR_SLEEP 	    0x0016 
#define CP_APH_SHUBIST_START 	0x0017 
#define CP_APH_SHUBIST_END   	0x0018
/* SSH Cp */
#define CP_SSH_PERW_START 	    0x1010 
#define CP_SSH_PERW_END     	0x1011 
#define CP_SSH_RECW_START    	0x1012 
#define CP_SSH_RECW_END 	    0x1013 
#define CP_SSH_EDRW_START 	    0x1014 
#define CP_SSH_EDRW_END 	    0x1015 
#define CP_SSH_SHUBIST_START 	0x1016 
#define CP_SSH_SHUBIST_END 	    0x1017
/* SRH Cp */
#define CP_SRH_PERW_START 	    0x2010 
#define CP_SRH_PERW_END 	    0x2011 
#define CP_SRH_RECW_START 	    0x2012 
#define CP_SRH_RECW_END 	    0x2013 
#define CP_SRH_EDRW_START 	    0x2014 
#define CP_SRH_EDRW_END 	    0x2015 
#define CP_SRH_SHUBIST_START 	0x2016 
#define CP_SRH_SHUBIST_END   	0x2017 




/**
* \brief Data type of logging message
*/
typedef char Log_MessageFormat;


#endif 
